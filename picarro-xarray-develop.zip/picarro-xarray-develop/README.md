# picarro-xarray

picarro-xarray

## About

`picarro-xarray` is a Python package for working with Picarro timeseries and spectral data using xarray.
For more information, see the docs [picarro-xarray-docs](http://10.100.1.222/picarro-x-array/introduction.html) (you must be on the Picarro network to view this link).

## Installation

The preferred method is to install via `pip`. If you are a developer, you can use `make` to develop locally.

```bash
make develop
```

This will create a `virtualenv` environment with the name `venv`. The environment should be activated and deactivated with the commands `source venv/bin/activate` and `deactivate`, respectively, from the root of this code repository.

## Tests

Use the following command to run unit tests, integration tests, doctests, and coverage analysis.

```bash
make test
```

## Auto-documentation

You can generate the docs locally. Use the following command to generate local Sphinx documentation.

```bash
make docs
```

See [here](https://www.sphinx-doc.org/en/master/usage/quickstart.html) for more information on [sphinx](https://www.sphinx-doc.org/en/master/index.html)

---

## Docker

Tests and Auto-documentation can also be run/generated using Docker

### Docker Tests

```bash
docker-compose run tests
```

### Docker Auto-Documentation

```bash
docker-compose run docs
```

---

## Usage

TODO: Add example usage here

## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## License

Copyright 2023 Picarro Inc.
