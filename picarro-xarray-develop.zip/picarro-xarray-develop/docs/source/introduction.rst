Introduction
------------

.. tip::

    These docs are best viewed in light mode

Timeseries data
^^^^^^^^^^^^^^^

Timeseries data, such as concentration measurements from a Picarro analyzer, can be
easily represented as a 2D table, using tools such as `pandas <https://pandas.pydata.org/>`_ DataFrame
structure; for example, each row can represent a measurement at a particular time,
and each column can represent a different variable, such as the concentration of a chemical species.
In `picarro-xarray` context, we will refer to this type of data as *timeseries* data.

In combo-logs, timeseries data is called :strong:`fitter_values`, and is indexed by two coordinates,
:strong:`_datetime` and :strong:`fitter_var`.

.. raw:: html
   :file: ./_static/fitter_values.html


Spectral data
^^^^^^^^^^^^^

Combo-logs also contain spectral data, which can be expressed as a 3D structure,
where each row represents a measurement at a particular time, each column represents a
different variable, and each layer represents a different wavelength.
Spectral data in `picarro-xarray` combo-logs is called *spectral_values*,
and is indexed by three coordinates, ``_datetime``, ``spectral_var``, and ``mode``.

.. raw:: html
   :file: ./_static/spectral_values.html

.. note::

    The ``mode`` coordinate is a special coordinate that is not present in the original
    combo-log file. It is added by `picarro-xarray` to make it easier to work with spectral data, specifically
    to put the spectral data "on a grid".

What is a ``mode``?
^^^^^^^^^^^^^^^^^^^

The formal definition of a ``mode`` is documented
on `Confluence <https://picarro.atlassian.net/wiki/spaces/VD/pages/2290122814/Spectral+Arithmetic#Compacting-data>`_.

Frequency data is continuous by nature, but for convenience we perform statistical binning
by grouping frequencies into a smaller number of "bins", called modes.

The concept of mode hence allows us to transition from continuous measured values of frequency (wavenumber)
to a discrete frequency grid.

This is powerful because the broadband analyzer commonly measures
only at some discrete wavelength values along a frequency "comb"
with teeth equally spaced and with distance equal to ``FSR``
(Free Spectral Range, of the cavity).

If we define one of these tooth as a reference tooth (at wavenumber ``f0``),
we can describe the position of the other
teeth by referring to
their relative distance from the reference tooth in terms of integer multiples of ``FSR``.

For example, mode ``1`` refers to the tooth with wavenumber equal to ``f0 + 1 * FSR``,
while mode ``-1`` refers to the tooth with wavenumber ``f0 - 1 * FSR``.

Only a specific set of modes is scanned for a specific dataset, depending on the
application and which gases we are interested in measuring; the set of modes that
an analyzer uses is commonly referred to as ``scheme``.

For more details, please talk to a spectroscopist.
