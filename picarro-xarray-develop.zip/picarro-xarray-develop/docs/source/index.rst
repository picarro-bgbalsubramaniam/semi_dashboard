.. picarro-xarray documentation master file, created by
   sphinx-quickstart on Fri Jan 12 12:50:51 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

picarro-xarray documentation
============================

.. tip::

    These docs are best viewed in light mode


`picarro-xarray` is a Python package for working with Picarro timeseries and spectral data using `xarray <https://docs.xarray.dev/en/stable/index.html>`_.

`picarro-xarray` is built on top of `xarray <https://docs.xarray.dev/en/stable/index.html>`_ and `dask <https://dask.org/>`_.
Xarray provides powerful data structures for working with multi-dimensional labelled data, and dask provides a
framework for scheduling and parallel computing.


.. raw:: html Example dataset
   :file: ./_static/xarray_dataset.html


Why picarro-xarray?
-------------------

`picarro-xarray` allows you to:

    - pack timeseries data and spectral data into a single data structure
    - access spectral data and timeseries data using a single ``_datetime`` index
    - perform operations, such as aggregations, on spectral data and timeseries data simultaneously
    - perform common domain-specific operations (compactify, zero-reference, allan deviation,
      least squares refitting, compound search, and more) easily and efficiently
    - perform operations on datasets that are too large to fit in memory, using `dask <https://dask.org/>`_
      as backend
    - easily obtain statistics along different dimensions of the dataset, such as time, wavelength, and
      spectral/timeseries variable)



.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: Contents:

   introduction
   User guide <user_guide_docs/index>
