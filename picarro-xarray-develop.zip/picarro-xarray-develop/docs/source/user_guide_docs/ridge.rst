Ridge regression refit of raw data
==================================

Ridge regression allows you to fit spectra with a penalized loss function,
using a linear model with an L2 regularization term.

Why? Benefits in High Multicollinearity Scenarios
-------------------------------------------------

Ridge regression is particularly useful when dealing with high-dimensional data
where features (in this case, spectra of different chemical compounds) are highly correlated.
In our case, this high correlation devolves into multicollinearity, where some features are almost linear combinations of others.
Standard linear regression (and the derived coefficients, i.e., concentrations) can become unstable due to this multicollinearity, and
it cannot be solved directly when the number of features is larger than the number of frequencies.

Ridge regression mitigates these issues by introducing a penalty term that
shrinks the coefficients of highly correlated features.
This regularization helps in obtaining a more stable and interpretable model.


Pros:

- Decreases variance: Ridge regression reduces the impact of multicollinearity by shrinking the coefficients of correlated predictors towards each other.
- Improves model stability: By reducing the sensitivity to small changes in the input data, ridge regression produces more stable and reliable estimates.
- Prevents overfitting: The L2 penalty helps to control model complexity, making it less likely to overfit the training data.


Cons:

- Slight increase in bias: The regularization introduces a small amount of bias in the model, as it pulls coefficients towards zero.
- Slight increase in RMSE *when OLS and Ridge are fit on the same data*

Despite the minor increase in bias, the significant reduction in variance often
leads to better overall predictive performance,
especially in cases of high multicollinearity.

Ridge Regression and Singular Value Decomposition
-------------------------------------------------

The methods are evaluated in the singular value decomposition (SVD) context.
This approach is particularly efficient since the ordinary least squares fitting problem is
usually solved using SVD, and ridge regression is just a small step away from OLS.


1. Ordinary least squares (OLS) regression:

   .. math::

      \hat{\beta} = (X^T X)^{-1} X^T y

   Notice how the inverse problem is problematic with high-dimensionality and/or correlation

2. Ridge regression:

   .. math::

      \hat{\beta}_{\text{ridge}} = (X^T X + \lambda I)^{-1} X^T y

   where :math:`\lambda` is the regularization parameter.

3. Using SVD, we can decompose X as:

   .. math::

      X = U \Sigma V^T

   where U and V are orthogonal matrices and Σ is a diagonal matrix
   with singular values :math:`\sigma_i` on its diagonal.

4. The OLS solution using SVD:

   .. math::

      \hat{\beta} =  V (\Sigma^2)^{-1} \Sigma U^T y = V D U^T y

   with:

   .. math::

      D_{ii} = \frac{\sigma_i}{\sigma_i^2} = \frac{1}{\sigma_i}

   The ridge regression solution (or Tikhonov regularized solution) using SVD:

   .. math::

      \hat{\beta}_{\text{ridge}} = V (\Sigma^2 + \lambda I)^{-1} \Sigma U^T y = V D U^T y

   .. math::

      D_{ii} = \frac{\sigma_i}{\sigma_i^2 + \lambda}


Here, :math:`\sigma_i` are the diagonal terms of the :math:`\Sigma` matrix from the SVD decomposition,
and :math:`\lambda` is the regularization parameter.

This formulation provides further insight into how ridge regression works:

- The regularization effect is stronger for smaller singular values.
- As :math:`\lambda` increases, the impact of smaller singular values is reduced more significantly.

This helps address the multicollinearity issue by dampening the effect of near-linear dependencies in the data.


This SVD formulation provides computational advantages, especially for high-dimensional data:

- It's numerically stable, even with high multicollinearity.
- It allows efficient computation of the solution for multiple λ values, even starting from the OLS SVD solution
- It provides insights into how ridge regression shrinks coefficients based on the singular values.



Hyperparameter estimation methods
---------------------------------

The strength of the ridge regularization (λ) can be determined using various methods. Here are the available approaches:

1. `Cross-validation (CV) <https://www.cs.cmu.edu/~psarkar/sds383c_16/lecture9_scribe.pdf>`_ methods:

   - ``cross_validate_opt``: Selects the λ that minimizes the mean squared error across CV folds.
   - ``cross_validate_se``: Uses the "one standard error" rule to select a more parsimonious model.

   These methods are robust but computationally expensive, especially for large datasets.

2. `L-curve method <https://www.sintef.no/globalassets/project/evitameeting/2005/lcurve.pdf>`_:

   ``l_curve`` balances the trade-off between the residual norm and the solution norm.
   It's less computationally intensive than CV and can provide a visual interpretation.

3. Analytical estimators:

   - ``k4``: `k4 AD estimator <https://www.sciencedirect.com/science/article/pii/S1815385213000199#b0060>`_ Uses the Harmonic Mean approach (Dorugade, 2014).
   - ``hkb``: `Hoerl-Kennard-Baldwin estimator <https://www.scirp.org/journal/paperinformation?paperid=72617>`_ (Hoerl et al., 1975).
   - ``kb3``: `Kibria's KB3 estimator <https://jmasm.com/index.php/jmasm/article/view/797/798>`_, combining multiple analytical approaches (Kibria, 2016).

   These methods are fast and don't require iterative computations, but may be less adaptive to specific dataset characteristics.

Each method has its strengths and may be more suitable for different scenarios:

- CV methods are generally reliable but slow
- The L-curve method provides a good balance between computation speed and adaptability.
- Analytical estimators are very fast but may not always provide the optimal solution for all datasets

Refit with ridge
----------------

Ridge regression follows a similar pattern and structure to ordinary least squares (OLS) fitting in ``picarro-xarray``.

Using the accessor
^^^^^^^^^^^^^^^^^^

For OLS, we used ``llsq``, while for ridge regression, we use ``ridge``:

.. code-block:: python

    import picarro_xarray.accessors.refit_accessor  # noqa: F401

    # OLS
    refit_concs_da = ds.refit.llsq(lsq=lsq)

    # Ridge
    refit_concs_da = ds.refit.ridge(lsq=lsq)

Using function call
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

For OLS, we used ``fit_dataset``, while for ridge regression, we use ``ridge_fit_dataset``:

.. code-block:: python

    # OLS
    from picarro_xarray.compute.least_squares.least_squares_fitter import fit_dataset

    refit_concs_da = fit_dataset(
        dataset=ds,
        lsq_fitter=lsq,
    )

    # Ridge
    from picarro_xarray.compute.least_squares.least_squares_fitter import ridge_fit_dataset

    refit_concs_da = ridge_fit_dataset(
        dataset=ds,
        lsq_fitter=lsq,
    )

Specifying the hyperparameter method
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1. Using a built-in method (L-curve):

   .. code-block:: python

       import picarro_xarray.accessors.refit_accessor  # noqa: F401

       refit_concs_da = ds.refit.ridge(lsq=lsq, method="l_curve")

2. Using a custom method (constant hyperparameter):

   .. code-block:: python

       import picarro_xarray.accessors.refit_accessor  # noqa: F401
       refit_concs_da = ds.refit.ridge(lsq=lsq, method=lambda X, y: 1E-6)

3. Chaining from an existing built-in method:

   .. code-block:: python

       from picarro_xarray.compute.least_squares.ridge_hyperparameter import _k4

       def change_k4(X, y, **kwargs):
           return 0.25 * _k4(X, y)

       import picarro_xarray.accessors.refit_accessor  # noqa: F401
       refit_concs_da = ds.refit.ridge(lsq=lsq, method=change_k4)

4. Custom estimator:

    .. code-block:: python

        def custom_estimator(X: np.ndarray, y: np.ndarray, **kwargs) -> float:
            # Custom estimation logic here, estimated_lambda = ...
            return estimated_lambda

        import picarro_xarray.accessors.refit_accessor  # noqa: F401
        refit_concs_da = ds.refit.ridge(lsq=lsq, method=custom_estimator)


Comparison with OLS on Picarro data
------------------------------------

In this section, we compare the original solution with a recalculated OLS solution and ridge solutions 
with different hyperparameter estimation methods.

First, let's look at the model functions correlation heatmap. You see some clusters of highly correlated model functions, 
such as ``6556`` and ``6360``, ``7843`` and ``8003``, ``6556`` and ``7843``, etc. Those species are the ones 
where we expect to see the most benefit from the ridge regularization.
Other model functions, such as ``222`` and ``948`` are not as correlated, 
and we do not expect to see a benefit from the ridge regularization for these.

.. raw:: html
   :file: ../_static/ridge_mf_heatmap.html

For completeness, let's condense these concepts by looking at the Variance Inflation Factors (``VIF``) 
for the same fitter model functions. 
The ``std_err_increase`` column indicates how much the standard error of the fitter coefficients increases 
compared to a scenario where the predictor variable is uncorrelated with the other predictor variables.
A VIF value above 10 generally indicates a high correlation between the predictor variable and the others. 
You can notice that this fitter model is highly problematic and over-specified. Ridge regression can help in 
mitigating some of these issues.

.. csv-table:: Variance Inflation Factors (VIF)
   :file: ../_static/ridge_vif.csv
   :header-rows: 1

The code below was used to generate the results.

.. code-block:: python

   from picarro_xarray.compute.least_squares.least_squares_fitter import ridge_fit_dataset
   from picarro_xarray.compute.least_squares.ridge_hyperparameter import _k4, _get_optimal_lambda_se

   def k4_03(X, y, **kwargs):
    return 0.3 * _k4(X, y)

   def se_75(X, y, **kwargs):
      return _get_optimal_lambda_se(X, y, se=0.75)

   options = {
      "ols": lambda X, y: 1e-20,  # very small lambda to approximate OLS
      "cross_validate_se": "cross_validate_se",
      "cross_validate_opt": "cross_validate_opt",
      "cross_validate_se_075": se_75,
      "l_curve": "l_curve",
      "hkb": "hkb",
      "kb3": "kb3",
      "custom_03_k4": k4_03,
   }

   for name, method in options.items():
      with performance_report(filename=base_folder / f"{name}.html"):
         result_lsq = ridge_fit_dataset(dataset=ds, lsq_fitter=lsq, method=method)

In the figure below (interactive), you can see the original vs. OLS vs. ridge solutions, one parameter (species concentration) at a time. 
The RMSE, offset, and slope terms are available as well.

The solutions are ordered left to right from least to most regularized. The first solution on the left is the original solution, 
the second on the left is the OLS solution, and the remaining solutions are ridge solutions with different levels of regularization. 
The right-most solution is the most regularized.

From ``fitter_var = "lsq_rmse"`` you can notice how the RMSE is slightly larger for the ridge solutions than for the OLS solution.
For correlated model functions, the OLS solution can be noisy, and the ridge solutions are more robust and with significantly less variance.
Be mindful that this is a very conservative regularization example, and you can reap even more benefits 
(in terms of variance reduction) by applying a more aggressive regularization.

.. raw:: html
   :file: ../_static/ridge_solutions_comparisons.html

Last but not least, let's look at the performance summary in terms of compute time.
Notice how the OLS solution is the fastest, as expected, and cross validation methods are by far the slowest.
Other methods are comparable to OLS in terms of computational speed.

.. csv-table:: Compute time: 4 workers, 8 threads, 16GiB memory, 38064 time samples
   :file: ../_static/ridge_performance_summary.csv
   :header-rows: 1