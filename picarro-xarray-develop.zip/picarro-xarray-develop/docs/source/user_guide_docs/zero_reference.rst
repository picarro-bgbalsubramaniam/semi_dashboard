Zero Reference
==============

Zero referencing is a technique used to correct for drift and offsets present in the raw data by designating some portion 
of the raw data as reference, a "floor" upon which the data is referenced.

Usually, the reference data refers to periods of time when the instrument is measuring a well-known zero, 
such as a reference gas, or most often a catalytic converter or 
a PAIAC: these constitute our best knowledge of what the instrument experiences as a true zero.

When we perform the zero-referencing, we separate the signal from the reference baseline. 
First, we identify the component of the data that corresponds to the reference. 
Then we subtract this reference from the raw data to isolate the true signal - 
the differential contribution between the measured values and the reference.

.. warning::
    **Look-ahead bias fixed in version 0.1.0:**
    Prior to version 0.1.0, even when ``center=False`` (right-aligned windows), 
    zero-referencing had subtle look-ahead bias due to linear interpolation between reference points.
    This meant the reference baseline used future information when interpolating between reference measurements.
    
    **Version 0.1.0 eliminates this look-ahead bias** by using forward-fill propagation instead of 
    interpolation when ``center=False``. This ensures truly causal zero-referencing using only 
    past and present reference information.
    
    If you need the old interpolation behavior, set ``center=True``.

Use cases
---------

**Time-series data**

For time-series data, a common need is to zero reference the concentration data over time. 
When measuring reference samples, concentration values may not be centered at zero but could be slightly positive or negative. 
Zero-referencing centers the reference data at zero by applying a correction (typically a simple offset) to address this deviation. 
This correction is applied to the entire dataset, including non-reference measurements, variable-by-variable, and with a rolling time window. 
This approach assumes that the same underlying instrumental response affects both reference and sample measurements, 
and that the offset simply represents a shift in the zero point.

**Spectral data**

Another use case is the referencing of spectral data. In this case, the reference is the spectral data collected when measuring a reference gas, 
and the zero-referencing operation removes the spectral features of the reference gas from all spectra.
This is particularly helpful due to the complex behavior of the cavity baseline in our instruments, 
which has been observed to drift and shift over time.
By assuming that cavity effects have characteristic times that are slow compared to our correction window, 
we effectively remove these cavity effects from the spectral data through the zero-referencing operation.
The correction is applied to the entire dataset, including non-reference measurements, variable-by-variable, mode-by-mode, 
and with a rolling time window.

How it works
------------

The zero-referencing process involves several steps:

1. **Identify reference data**: Find all instances where the transition variable equals the reference value
2. **Calculate reference aggregates**: Aggregate (mean or median) the data values during each reference period
3. **Compute rolling average**: Apply a rolling window to the reference aggregates to smooth the data
4. **Create continuous baseline**: 
   - When ``center=False`` (default): Forward-fill the last known reference value until the next reference point (no look-ahead)
   - When ``center=True``: Interpolate between reference points to create a continuous baseline (includes look-ahead)
5. **Zero reference**: Subtract the reference baseline from the original data

Demo Videos
-----------

Below are demonstration videos showing zero referencing with different parameters.

You can think of the time-series below as the concentration measurement for a species over time (i.e., ``fitter_values``, 
given a single ``fitter_var``, say ``gasConcs_11``) over different sampling ports.

Alternatively, you can think of it as a time-series of the ``spectral_values`` for a given ``mode`` (a frequency bin) and a 
given ``spectral_var`` (``partial_fit``). 

**Case 1 - Causal Zero-Referencing (Recommended)**

Configuration:

    - Window width of 5 measurement intervals
    - Reference intervals are aligned to the right of the measurement interval
    - Reference intervals are aggregated using the median
    - **No look-ahead bias** (as of version 0.1.0): Uses forward-fill propagation

.. raw:: html

    <video width="720" controls>
        <source src="../_static/zeroref_median_5_right.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>

**Case 2 - Centered Windows (Look-ahead)**

Configuration:

    - Window width of 5 measurement intervals
    - Reference intervals are centered on the measurement interval (includes look-ahead)
    - Reference intervals are aggregated using the median

.. warning::

    Since the window is centered, we are performing a look-ahead operation by design, 
    using future reference information to create the baseline. 
    **We recommend using right-aligned windows (Case 1) instead** for truly causal zero-referencing.

.. raw:: html

   <video width="720" controls>
     <source src="../_static/zeroref_median_5_centered.mp4" type="video/mp4">
     Your browser does not support the video tag.
   </video>


Example
-------

In the following example, we assume that our dataset ``ds`` has a ``fitter_var`` named ``ValveMask`` 
that indicates which valve/port the sample is coming from, 
with a specific value (1.0) indicating when a reference gas is being measured.

.. code-block:: python

    from picarro_xarray.compute.zero_reference import get_zero_referenced_data

    zero_referenced = get_zero_referenced_data(
        data=ds,
        transition_variable="ValveMask", 
        reference_value=1.0
    )

What this means is:

- The function identifies points where ``ValveMask`` equals the reference value (1.0)
- It calculates the aggregate (median) value during these reference periods
- It performs a rolling average of the reference data points
- It creates a continuous baseline by forward-filling reference values (no look-ahead as of v0.1.0)
- It subtracts this baseline from the original data

Customize window settings
-------------------------

You can control how the reference windows are processed:

.. code-block:: python

    zero_referenced = get_zero_referenced_data(
        data=ds,
        transition_variable="ValveMask", 
        reference_value=1.0,
        event_window_width=4,     # Width of rolling window (default 4)
        center=False,             # Whether rolling window is centered (default False)
        data_aggregation="median" # How to aggregate reference data (default "median")
    )

