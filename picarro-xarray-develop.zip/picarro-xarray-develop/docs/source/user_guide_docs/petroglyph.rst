Using Petroglyph model functions
================================

Petroglyph is a self-contained spectral library client written in Rust, it allows the use of a file-based spectral library, and 
allows ``picarro-xarray`` to minimize the memory footprint of least squares fitting operations.

.. warning::
    The integration of Petroglyph with ``picarro-xarray`` is experimental, 
    and its API is in flux.

For more information on Petroglyph, see the `Petroglyph Github page <https://github.com/picarro/petroglyph>`_.

Installing Petroglyph
----------------------

Petroglyph can be installed via pip:

.. code-block:: bash

    pip install picarro-petroglyph

.. warning::
    If you encounter issues, you will need to compile the ``picarro-petroglyph`` package.
    This requires ``cargo`` and ``rust`` to be installed. ``rustup`` (link `here <https://rustup.rs/>`_) 
    is the recommended way to install them.
    After installing ``rustup``, restart your shell and retry the 
    pip install command above.

Retrieving Petroglyph model functions file
------------------------------------------

Petroglyph uses a file-based spectral library. For info on how to generate this file,
see the `Petroglyph Github page <https://github.com/picarro/petroglyph>`_.


Using Petroglyph in a ``LinearLeastSquares`` fitter
-----------------------------------------------------
.. _petroglyph-least-squares:

Petroglyph will allow significantly lower memory usage for least squares fitting operations. 
This is especially critical for dynamic fitting.

You can use the ``get_petroglyph_least_squares`` function to create a ``LinearLeastSquares`` fitter 
and then proceed as usual.

.. code-block:: python

    from functools import partial 
    import petroglyph as pg
    from picarro_xarray.compute.least_squares.experimental import get_petroglyph_least_squares

    pressure = 450
    cids = [176, 222, 180, 3776]  # cids for the fitter
    library = pg.SpectralLibrary("spectral-library.pg")
    model_functions = library.select_empirical(pressure)
    lsq = get_petroglyph_least_squares(
        model_functions=model_functions,
        cids=cids,
        pressure=pressure,
    )


Using Petroglyph to set model functions in a ``CompoundSearchAccessor``
-----------------------------------------------------------------------

You can use Petroglyph model functions in the ``set_model_functions`` method of 
the ``CompoundSearchAccessor``. You will first need to prefill the ``pressure`` field of the Petroglyph model functions.

.. code-block:: python

    from functools import partial
    import petroglyph as pg

    pressure = 450
    library = pg.SpectralLibrary("spectral-library.pg")
    model_functions = library.select_empirical(pressure)

    splines = {
        cid: partial(model_functions[cid], pressure=pressure) for cid in model_functions
    }

    import picarro_xarray.accessors.compound_search_accessor  # noqa
    ds = xr.open_dataset("path/to/dataset.nc") # your dataset
    ds.compound_search.set_model_functions(model_functions=splines)

    
