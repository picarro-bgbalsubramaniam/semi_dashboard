Compactify
----------

.. warning::

    The documentation for the ``compactify`` operation is currently a work in progress.


The ``compactify`` operation is used to perform a ``groupby`` operation
on a spectral dataset along the `_datetime` dimension.
The resulting dataset contains the means of each group, and some statistics like
standard deviation, standard error, and Allan deviation.

Say we have a spectral dataset ``ds`` as below.

.. raw:: html
   :file: ../_static/groupby_dataset.html

Let's compactify it and look at the result.

.. code-block:: python

    import picarro_xarray.accessors.compactify_accessor # noqa
    compact_ds = ds.compactify.compact(
        groupby="ValveMask",
        consecutive=True
    )


.. raw:: html
   :file: ../_static/compactify_dataset.html


You can see that `11` groups were detected,
with ``[45, 106, 105, 105, 105, 105, 105, 105, 106, 105, 8]`` samples in each group.
The sum of the samples is 1000, which is the same as the original dataset (in this case).

The ``n_samples`` coordinate shows the number of value pairs used to compute the Allan deviation
for each group.

The ``fitter_values`` and ``spectral_values`` variables represent the mean of the
fitter values and spectral values for each group. For spectral values, the mean is weighted
by the ``npoints`` spectral variable. The spectral variable ``npoints`` has preferential treatment,
and the result from compactify is the *sum* of the ``npoints`` variable for each group, rather than
the mean.

The ``fitter_values_stats`` and ``spectral_values_stats`` variables represent the statistics of the
fitter and spectral values for each group. There is a new indexing dimension called ``stat``,
with the following values: ``'std_dev', 'std_err', 'allan_dev', 'allan_std_err'``.

The coordinate ``tau_scaled`` represents the median time delta between time samples for each group.

You can see that the ``mode`` dimension significantly reduced in size. This is because some of the modes
were dropped during compactification as they did not have enough samples (if at all) to be relevant.
The logs for the operation reflect the mode changes::

    2024-01-31 14:55:44,302 INFO     [picarro_xarray.compute.compactify:LineNo:229] 990 invalid modes out of 1366 total modes. 376 remaining modes

More on this later.


.. note::

   It is called ``compactify`` and not ``groupby`` because spectral data has to undergo some special treatment,
   as different spectral variables have different meaning.

The compactify ``grouper``
~~~~~~~~~~~~~~~~~~~~~~~~~~

The groupby operation is performed along the ``_datetime`` axis.

Say you have a dataset with 100 data points along the time axis,
and the following grouper variable:

.. code-block:: python

        grouper = [1] * 10 + [2] * 50 + [3] * 40

You have 3 consecutive groups, the first with 10 elements, the second 50 elements,
the third 40 elements.

The compactify operation will then return a dataset with 3 elements, each with a ``_datetime``
coordinate value equal to the **first** `_datetime` of each group.

The `grouper` is provided in the ``groupby`` argument in
:py:func:`picarro_xarray.compute.compactify.compactify`.

There are a few data types accepted as ``groupby`` argument:

- ``None``: the full dataset is compactified into a single `_datetime` element.
- ``str``: the name of the variable to group by.
  The variable name must be present in the ``fitter_var`` dimension
- ``xr.DataArray``: a 1D Xarray DataArray a dimension ``_datetime`` with the same
  length as the `_datetime` dimension of the original dataset.


How to create a custom grouper
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Say you have a dataset ``ds`` with 1000 elements along the `_datetime` axis.

.. raw:: html
   :file: ../_static/groupby_dataset.html


And you want to create a custom grouping strategy (100, 500, 400 elements).

.. code-block:: python

    # Create a dataarray with the same length as the original dataset
    da_grouper = xr.DataArray(
        [1] * 100 + [2] * 500 + [3] * 400,
        dims=['_datetime'],
        coords={'_datetime': ds._datetime.values}
    )


The result is a suitable grouper for the compactify operation.

.. raw:: html
   :file: ../_static/grouper_dataarray.html


Group population check
~~~~~~~~~~~~~~~~~~~~~~

The compactify operation will check the population of each group and drop groups
with less than ``min_points_per_group`` samples. The default value is ``3``,
to avoid computing statistics for groups with too few samples, which would
lead to unreliable results.

Notably, the compactify accessor :py:class:`picarro_xarray.accessors.compactify.CompactifyAccessor`
does not expose this parameter, but the underlying function :py:func:`picarro_xarray.compute.compactify.compactify` does,
and it in general allows for more fine-grained control over the compactify operation.

In the original example, all groups had more than 3 samples, so no groups (that is `_datetime` elements) were dropped.


Mode population check
~~~~~~~~~~~~~~~~~~~~~

The compactify operation will check the population of each mode and mark for deletion modes
with less than ``minimum_mode_occupancy`` fraction. The default value is ``0.8``,
meaning for each group, a mode will **not** be marked for deletion if at least 80%
of the `_datetime` elements are not null for that mode. In other words, a mode
will be marked for deletion if more than 20% of the `_datetime` elements
spectral values are null for that mode.


In the example above, the first group had 44 `_datetime` elements, let's check the modes with non-null values.

.. code-block:: python

    control_spectral_vars = ["nu_prime", "partial_fit", "npoints"]  # check these spectral variables for nans
    time_len = 44  # number of time elements
    nonnull_modes = ds.isel(_datetime=slice(0, time_len)).sel(spectral_var=control_spectral_vars).spectral_values.notnull().all(dim="spectral_var").sum(dim="_datetime").compute()

.. raw:: html
   :file: ../_static/nonnull_modes.html

Let's check the mode occupancy, and let's create a boolean mask with the modes to **keep**.

.. code-block:: python

    mode_occupancy = nonnull_modes / time_len
    mask = mode_occupancy > 0.8

.. raw:: html
    :file: ../_static/modes_keep_mask.html

The result in this case is that 990 modes were marked for deletion, and 376 modes were kept.

If our dataset consisted of a single group, those 990 modes would have been effectively deleted from the dataset.
However, if we have multiple groups, it might happen that a mode is marked for deletion in one group, but not in another.
In our dataset, the boolean mask from the example above is extended to the ``group`` dimension, and it has
dimensions ``[group x mode]``, while in the example above it had dimensions ``[mode]``.

The first layer of mode filtering (performed on the boolean mask):

.. important::

    If a mode is marked for deletion in **all** groups, it is deleted from the dataset

This is what happened in our original example, where 990 modes were marked for deletion for _all_ 11 groups.

The second layer of mode filtering (performed using the boolean mask):

.. important::
   If a mode is marked for deletion in **some** groups, all spectral values
   for that mode are set to ``NaN`` for those groups

In this case, the mode itself will **not** be deleted, it will simply be empty (i.e., ``NaN``)
for some groups (where it was marked for deletion).

This will make sure that we do not drop a lot of modes when analyzing long-duration datasets
where the schema (i.e., modes locations where the instrument was purposely taking measurements at)
was changed over time.

It also mean that the compact dataset is not necessarily full by design, but it can contain null values
in the spectral data.

If the ``spectral_values`` for a compact dataset for a specific group
and a specific mode are ``NaN``, it means that in the correspondent time interval in the original dataset
that mode was either not scanned, or not scanned *enough* -- but the same mode was successfully scanned
in other time intervals.

If a mode was present in the original dataset, but it is not present in the compact dataset, it means that
the mode was not scanned at all in the original dataset, or it was not scanned enough for *any* group.

