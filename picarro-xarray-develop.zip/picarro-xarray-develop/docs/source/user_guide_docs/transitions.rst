Trim transitions
--------------------

Data collected around port transitions is often unreliable as:

- port switching can generate pressure oscillations that affect the readings
- the sample from the new port has to flow to the analyzer through the tubing, which can take time

The ``trim_transitions`` operation is used to remove data around sampling port transitions, i.e.,
removing data along the `_datetime` axes when we think it is not reliable.


Example
~~~~~~~

In the following example, we assume that our dataset ``ds`` has a ``fitter_var`` coordinate named ``ValveMask``,
and we assume that ``ValveMask`` indicates which port the sample is coming from. It is expected that ``ValveMask``
values can (and will) repeat over time, once the sampling cycle restarts.

.. code-block:: python

    from picarro_xarray.preprocess.trim_transition import trim_transitions
    trimmed_ds = trim_transitions(
            data=ds,
            grouper_da="ValveMask",
            min_duration_seconds=5,
            trim_start_seconds=30,
            trim_end_seconds=10,
        )



What this means is:

- we define a counter variable UID (unique identifier) that increases every time the ``ValveMask`` changes
- we will group the data by the ``UID`` variable
- we will remove the first 30 seconds of each UID section
- we will remove the last 10 seconds of each UID section
- we will remove any UID section with less than 5 seconds remaining after the transition trimming

In the diagram below, we see the values of ``ValveMask`` over time, and the transitions between them (bold line).
The samples highlighted in green are kept, while the ones in red are removed.
The last section (`UID=3`) has one data point left after the transition trim,
but it is removed because the remaining section is less than 5 seconds long.

.. note::

    The first and the last sections are special, as in:

    - we do not drop the initial seconds of the first section
    - we do not drop the last seconds of the last section


.. image:: ../_static/transition_uid.svg


Other option: use a different ``fitter_var``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

It is possible to use other variables other than ``ValveMask`` to group the data. The variable
must be present in the ``fitter_var`` dimension of the dataset.


Other option: use a custom grouper
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Alternatively, you can pass in a Xarray DataArray with the same length as the `_datetime` dimension,
and the operation will group the data by the values of the DataArray.

For example, to achieve the same functionality of the example you would do:

.. code-block:: python

    from picarro_xarray.preprocess.trim_transition import trim_transitions
    from picarro_xarray.compute.zero_reference import get_transition_uid

    transition_uid = get_transition_uid(
        transition_data=ds.sel(fitter_var="ValveMask").fitter_values
    )

    # or specify it manually
    transition_uid = xr.DataArray(
        data=[0] * 6 + [1] * 7 + [2] * 7 + [3] * 4,
        dims=["_datetime"],
        coords={"_datetime": ds._datetime.values},

    )

    ds = trim_transitions(
        data=ds,
        grouper_da=transition_uid,
        min_duration_seconds=5,
        trim_start_seconds=30,
        trim_end_seconds=10,
    )
