Partial fit integral
=====================

You can compute the partial fit integral for every datetime of your
dataset by calling the :py:func:`picarro_xarray.compute.spectra_integral.partial_fit_integral`
function on the dataset.

.. code-block:: python

    from picarro_xarray.compute.spectra_integral import partial_fit_integral

    partial_fit_da = partial_fit_integral(
        data=ds,
    )


.. raw:: html
   :file: ../_static/pfi.html


The partial fit integral is computed by using a **trapezoidal rule** to find the area under the
wavenumber-signal curve (i.e., ``nu_prime`` vs ``partial_fit``) for each datetime in the dataset.

The dataset must therefore be a combolog dataset, with a ``spectral_var`` coordinate that includes
``partial_fit`` and ``nu_prime``.


Partial fit integral scaled in CIDs-equivalents
-------------------------------------------------

You can also compute the partial fit integral scaled in CIDs-equivalents by calling the
:py:func:`picarro_xarray.compute.spectra_integral.partial_fit_integral_equivalent` function on the dataset.

A common use case is to compute the IPA-equivalent partial fit integral. In the past,
this was done by computing the partial fit integral and then multiplying by a scaling factor 
(calibration constant) for each compound. However, the scaling factor can in principle change at 
each time step based on the schema (i.e., frequencies/mode being measured at).

With the following function, the calibration constants are automatically applied for you (and calculated 
from the data itself).

.. code-block:: python

    from picarro_xarray.compute.spectra_integral import partial_fit_integral_equivalent

    pfi_ipa_equivalent = partial_fit_integral_equivalent(
        data=ds,
        cids=[3776],
    )

You can also compute the partial fit integral scaled in CIDs-equivalents for multiple compounds:

.. code-block:: python

    from picarro_xarray.compute.spectra_integral import partial_fit_integral_equivalent

    pfi_ipa_equivalent = partial_fit_integral_equivalent(
        data=ds,
        cids=[3776, 1140],
    )

.. note::

    The function :py:func:`picarro_xarray.compute.spectra_integral.partial_fit_integral_equivalent`
    requires the ``compound_search`` accessor to be registered on the dataset in order to retrieve and 
    evaluate the model functions at the frequencies/modes being measured.
    Make sure to register the accessor (``import picarro_xarray.accessors.compound_search_accessor``) 
    and set the model functions (``ds.compound_search.set_model_functions(model_functions)``) 
    before calling the function.


Computing the calibration constants for different CIDs
-----------------------------------------------------------

The calibration constants for different CIDs can be computed by using the
:py:func:`picarro_xarray.compute.spectra_integral.integrate_da` together with 
the :py:meth:`picarro_xarray.accessors.compound_search_accessor.CompoundSearchAccessor.get_model_functions` method.

.. code-block:: python

    import picarro_xarray.accessors.compound_search_accessor
    from picarro_xarray.compute.spectra_integral import integrate_da

    interest_cids = [3776, 1140]

    ds.compound_search.set_model_functions(model_functions)

    cids_spectra = ds.compound_search.get_model_functions(cids=interest_cids)

    nu_prime = ds.sel(spectral_var="nu_prime").spectral_values

    # areas [pfi units per ppb of compound]
    areas = integrate_da(x=nu_prime, y=cids_spectra, integral_dim="mode")

    constants = 1 / areas
    
This will return a dataset with the calibration constants for each compound.
If ``nu_prime`` has a ``_datetime`` coordinate, the calibration constants will be 
time-dependent, too: this is useful for situations where the frequency-measurement 
schema is changing over time.

The procedure above is what is done in the 
:py:func:`picarro_xarray.compute.spectra_integral.partial_fit_integral_equivalent` function
under the hood, but here we compute the calibration constants for each compound separately.
    
    
Integrals of other spectral variables
-------------------------------------

You can compute the integral of any DataArray in the dataset by calling the
:py:func:`picarro_xarray.compute.spectra_integral.integrate_da` function on the dataset.

The function call does not limit the options, but it is recommended for the ``x``
variable to be a monotonically increasing variable, such as ``nu`` or ``nu_prime``.

For example, to calculate the integral under the ``wavenumber``-``absorbance`` curve,
you can call:

.. code-block:: python

    from picarro_xarray.compute.spectra_integral import integrate_da

    integral_da = integrate_da(
        x=ds.sel(spectral_var="nu_prime").spectral_values,
        y=ds.sel(spectral_var="absorbance").spectral_values,
        integral_dim="mode",
    )


The :py:func:`picarro_xarray.compute.spectra_integral.partial_fit_integral`
function is a special case of the
:py:func:`picarro_xarray.compute.spectra_integral.integrate_da` function:


.. code-block:: python

    from picarro_xarray.compute.spectra_integral import integrate_da

    integral_da = integrate_da(
        x=ds.sel(spectral_var="nu_prime").spectral_values,
        y=ds.sel(spectral_var="partial_fit").spectral_values,
        integral_dim="mode",
    )


Other integral functions
------------------------

By default, the integral functions use the trapezoidal rule to compute the integral.
You can pass an additional argument ``integral_func`` to :py:func:`picarro_xarray.compute.spectra_integral.partial_fit_integral`
or :py:func:`picarro_xarray.compute.spectra_integral.integrate_da` to compute the integral using
a different formulation.

The ``integral_func`` argument must be a function of shape ``IntegralCallable``,
i.e., a function that returns a float number and takes in three arguments:

- ``x``: the x values
- ``y``: the y values
- ``mask``: a boolean mask to select the values to integrate (to discard ``NaN`` values)


For example, to compute the integral using the Simpson's rule, you can call:

.. code-block:: python

    from picarro_xarray.compute.spectra_integral import integrate_da
    from scipy.integrate import simpson

    integral_da = integrate_da(
        x=ds.sel(spectral_var="nu_prime").spectral_values,
        y=ds.sel(spectral_var="partial_fit").spectral_values,
        integral_func=lambda x, y, mask: simpson(x=x[mask], y=y[mask]),
        integral_dim="mode",
    )


Partial fit integrals over time
--------------------------------

We talked about integrals over frequencies/modes, but you can also compute the partial fit integral over time using 
the :py:func:`picarro_xarray.compute.spectra_integral.integrate_da` function.

First, you might want to set a start time, and express each time in the dataset relative to that start time.

.. code-block:: python

    from picarro_xarray.compute.spectra_integral import integrate_da

    start_time = pd.to_datetime(ds._datetime.values[0]) 

    # or equivalently:
    start_time = pd.to_datetime("2024-01-01 00:00:00")

    total_seconds = xr.DataArray(
        (ds._datetime.to_pandas() - start_time).dt.total_seconds(),
        dims="_datetime",
        coords={"_datetime": ds._datetime},
    )

    pfi = partial_fit_integral(
        data=ds,
    )

    # now you can pass the total_seconds DataArray to the integrate_da function:
    pfi_time_integral = integrate_da(
        x=total_seconds,
        y=pfi,
        integral_dim="_datetime",
    )

You can also compute the partial fit integral scaled in CIDs-equivalents over time by calling the
:py:func:`picarro_xarray.compute.spectra_integral.partial_fit_integral_equivalent` function. 
In the case below, you will have two different representations of the total partial fit integral over time, 
one in units of partial fit integral of ``3776``, and one in units of partial fit integral of ``1140``.

.. code-block:: python

    from picarro_xarray.compute.spectra_integral import partial_fit_integral_equivalent

    pfi_equivalent = partial_fit_integral_equivalent(
        data=ds,
        cids=[3776, 1140],
    )

    # now you can pass the total_seconds DataArray to the integrate_da function:
    pfi_equivalent_time_integral = integrate_da(
        x=total_seconds,
        y=pfi_equivalent,
        integral_dim="_datetime",
    )
