Least squares refit of raw data
===============================

The refitting process computes concentrations from spectral data for each time point present in the initial dataset.

Requirements
------------

To compute concentrations, you need the following ``spectral_var`` coordinates to be present in the dataset:

- ``partial_fit``: the spectra to be fitted (dimensions ``[_datetime, mode]``)
- ``nu_prime``: the wavenumbers at which the spectra are measured, used to evaluate the model function for each
  species in the fitter (dimensions ``[_datetime, mode]``)
- ``npoints``: the number of ringdowns/measurements that were averaged together
  to get a ``partial_fit`` measurement at a given time point and mode (wavenumber) (dimensions ``[_datetime, mode]``)


Generate a fitter
-----------------

From Petroglyph
~~~~~~~~~~~~~~~

Petroglyph is a Rust client that allows you to use a file-based spectral library.
It offers several advantages in terms of memory usage and performance, and is the 
recommended approach, especially for dynamic fitting.

However, Petroglyph is not yet fully integrated with ``picarro-xarray``, so 
the API is in flux and subject to change.

To see how to use Petroglyph to generate a fitter, 
see the :ref:`Using Petroglyph in a LinearLeastSquares fitter <petroglyph-least-squares>` section.


From MongoDB
~~~~~~~~~~~~

To refit, you will need a fitter, generated starting from a list of species you want to refit.
Currently, you will need to use ``spectral-toolkit``` to generate a fitter.

.. code-block:: python

    from spectral_toolkit.reprocess_combo import get_least_squares  # spectral-toolkit is NOT a requirement for this repo

    nu_min = 5800
    nu_max = 6200
    pressure = 140.0

    cids = [176, 180, 222, 284, 948, 3776, 7900, 7946]
    lsq = get_least_squares(cids, nominal_pressure=450)

From statically evaluated model functions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

There are instances where we want to refit a small dataset, but 
we don't have access to model functions.
It could be that someone saved the dataset and passed it to us to refit it, 
or maybe we can carry data with us but not model functions, 
either because of safety concerns or memory usage 
(model functions take a lot of memory space).
For these use cases, you can proceed as below:

1. Load the ``compound_search`` accessor
2. In the part of code where you have access to model functions, retrieve model functions (usually from database)
3. Set the model functions in your dataset using
   :py:meth:`picarro_xarray.accessors.compound_search_accessor.CompoundSearchAccessor.set_model_functions`.
   This will evaluate the model functions at the median ``nu_prime``, and store the result in the dataset.
4. In the part of code where you don't have access to model functions but want to create a fitter and use it
   for refitting,
   use the method :py:meth:`picarro_xarray.accessors.compound_search_accessor.CompoundSearchAccessor.generate_least_squares_fitter`
   to generate a fitter
5. Use the fitter as usual

This new fitter will not evaluate model functions splines at the given ``nu_prime`` as usual, 
but it will use a sort of lookup table for values of the stored model functions in proximity of ``nu_prime``, 
as long as the available lookup frequencies are within a certain tolerance ``nu_tol``.

.. important::

    Since we initially evaluate and store the values of the model functions in correspondence to the median
    ``nu_prime`` for each mode, it is essential that the individual mode frequencies are as close as possible to
    the median frequency (i.e., they are within tolerance). This is often a valid assumption in short duration
    datasets where the port transitions are removed (because pressure changes often result in mode misalignment) and/or
    compacted dataset where by definition the stored frequencies have already been averaged.

For example, we can retrieve and set the model functions when we still have access to them:

.. code-block:: python

    # retrieve model functions
    from spectral_toolkit.db_clients.mongo_spectral_library import get_mongo_spectral_library_client
    from spectral_toolkit.model_function.mongodb import get_model_functions
    client = get_mongo_spectral_library_client()
    mfs = get_model_functions(client, nominal_pressure=450)
    client.client.close()

    # set model functions
    import picarro_xarray.accessors.compound_search_accessor  # noqa
    ds.compound_search.set_model_functions(mfs)


We can then generate a new fitter in a section of code that doesn't have access to the model functions
by using the stored evaluated absorbance of each compound.


.. code-block:: python

    lsq = ds.compound_search.generate_least_squares_fitter(cids=[1140, 15404, 35784], nu_tol=0.01)  # nu_tol is optional

    # any refitting you want
    refit_da = ds.refit.bounded_llsq(lsq, bounds=bounds)
    # or refit_da = ds.refit.llsq(lsq)


Refit with least squares fitter
-------------------------------

To refit, you will need to call the :py:meth:`picarro_xarray.accessors.refit_accessor.RefitAccessor.llsq` method on the dataset,
passing the fitter as an argument.

.. code-block:: python

    import picarro_xarray.accessors.refit_accessor  # noqa: F401
    refit_concs_da = ds.refit.llsq(lsq=lsq, positive=False)


Alternatively, you can use the :py:func:`picarro_xarray.compute.least_squares.least_squares_fitter.fit_dataset`
function.

.. code-block:: python

    from picarro_xarray.compute.least_squares.least_squares_fitter import fit_dataset

    refit_concs_da = fit_dataset(
        dataset=ds,
        lsq_fitter=lsq,
        positive=False
    )


Refit with non-negative least squares fitter
---------------------------------------------

Similarly, you can refit with a non-negative least squares fitter by calling the same
functions with ``positive=True``.

.. important::

    The intercept (offset) in the non-negative least squares fitter is **allowed to be negative**, unlike
    the other predictors and the frequency slope, which are all constrained by the non-negativity of the solution.


Refit with bounded least squares fitter
---------------------------------------
The bounded least squares fitter allows you to set bounds for the concentrations of each species in the fitter.
Moreover, you can also set bounds for the offset and slope terms (relative to ``nu_center``).

.. note::

    If you don't provide bounds for a species, the fitter will use the default bounds of ``(-np.inf, np.inf)``.
    If you don't provide bounds for any species, your solution will be the same as the unbounded least squares fitter.

Say we want to impose that the concentrations of species ``222`` and ``180`` are within ``-5`` and ``100`` ppb, and
we want to impose positive offset (``0``) and slope (``1``) terms, then we can prepare the ``bounds`` argument as follows:

.. code-block:: python

    bounds = {
            222: (-5, 100),
            180: (-5, 100),
            0: (0, np.inf),  # offset term
            1: (0, np.inf),  # slope term
    }


To refit, you will need to call the :py:meth:`picarro_xarray.accessors.refit_accessor.RefitAccessor.bounded_llsq` method
on the dataset, passing the fitter and the bounds as arguments.

.. code-block:: python

    import picarro_xarray.accessors.refit_accessor  # noqa: F401
    refit_concs_da = ds.refit.bounded_llsq(lsq=lsq, bounds=bounds)


Alternatively, you can use the :py:func:`picarro_xarray.compute.least_squares.least_squares_fitter.bounded_fit_dataset`
function.

.. code-block:: python

    from picarro_xarray.compute.least_squares.least_squares_fitter import bounded_fit_dataset

    refit_concs_da = bounded_fit_dataset(
        dataset=ds,
        lsq_fitter=lsq,
        bounds=bounds
    )


.. important::

    In general, it is preferable to use the :py:meth:`picarro_xarray.accessors.refit_accessor.RefitAccessor.llsq` method
    least squares fitter, as it is significantly faster.


Dynamic fitter: use different fitters for different times
----------------------------------------------------------

It is often helpful to fit different species at different times.

For example, if we are measuring at two different locations ``A`` and ``B``,
it is possible that the gas chemical composition at the two locations is different.
Usually, you would add both species associated to ``A`` and species associated to ``B`` in your fitter, then refit
the entire dataset (using all species at all times).

This has a few disadvantages:

- our model functions are mildly to severely correlated, therefore by adding more species we pay a cost in terms of
  large variance in the coefficients estimations (see variance inflation factor)
- fitting more species takes more time

If we can associate species to different time portions of the dataset,
either through compound hunting or prior knowledge, we can map the knowledge into the fitting process.

In turn, this solution has the disadvantage of discontinuous, sparse results. Please make sure that this is
acceptable in your analysis code.

The function :py:func:`picarro_xarray.compute.least_squares.least_squares_fitter.fit_dataset` takes an argument
``cid_fitter_mask``, a boolean xarray DataArray of shape ``(_datetime, fitter_var)``, where the ``fitter_var``
coordinate values correspond to ``lsq_fitter.get_results_keys(baseline_order=1)`` (with the exception of the last
term, ``rmse``, which is **not** represented in the map).

.. note::

    By default, ``cid_fitter_mask`` is set to ``None``, and all species
    present in the least squares fitter object ``lsq_fitter`` are fitted.

How to generate a fitter mask
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The convenience function :py:func:`picarro_xarray.compute.least_squares.fitter_mask.mask_from_map` can be used
to create a boolean mask for the CIDs present in ``lsq`` based on group mappings.
The mask has dimensions ``(_datetimes x fitter_var)``, indicating which species should be used for each datetime.
Baseline terms (offset, slope) are always set to ``True`` in the resulting mask.

.. important::

    All cids that you wish to use during fitting **must** be present in ``lsq``.

Let's go over an example.


.. code-block:: python

    from picarro_xarray.compute.least_squares.fitter_mask import mask_from_map
    mask = mask_from_map(
        lsq=lsq,
        groups=groups, # each time corresponds to a group
        groups_cid_map=groups_cid_map,  # each group is mapped to a list of cids
        default_cids=[104],  # unmapped group are assigned a default list of cids
        always_cids=[103] # some cids can be always set to True regardless of groups
    )


For ``groups``, you can intuitively think of something like ``ValveMask`` or ``PortId`` fitter values,
a xarray DataArray of dimension ``(_datetime)`` that tells you which group each datapoint belongs to:

.. code-block:: python

    groups = xr.DataArray(
        np.array([1, 1, 1, 2, 2]),
        dims=[TIME_DIM],
        coords={TIME_DIM: pd.date_range("2021-01-01", periods=5)},
    )



A group is associated to a list of cids through the dictionary ``groups_cid_map``; for example, to associate
group ``1`` with CIDs ``100`` and ``101``:

.. code-block:: python

    groups_cid_map = {1: [100, 101]}



Your ``lsq`` fitter must include all species you are going to use. In this case,
it must contain CIDs ``100, 101`` (present in the map), ``104`` (used for groups that don't have a specific mapping),
``103`` (CID that is added and fitted for all groups).

.. code-block:: python

    from spectral_toolkit.reprocess_combo import get_least_squares
    all_cids = [100, 101, 103, 104]
    lsq = get_least_squares(all_cids, nominal_pressure=450)


The resulting ``fitter_mask`` will be::

    fitter_var  lsq_base_0  lsq_gasConcs_100  lsq_gasConcs_101  lsq_gasConcs_102 lsq_gasConcs_103  lsq_gasConcs_104
    _datetime
    2021-01-01        True              True              True             False             True             False
    2021-01-02        True              True              True             False             True             False
    2021-01-03        True              True              True             False             True             False
    2021-01-04        True             False             False             False             True              True
    2021-01-05        True             False             False             False             True              True



Manually generate a fitter mask
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

You can generate a fitter mask however you wish, remembering the basic rules:

- it is a boolean xarray DataArray with dimensions ``(_datetimes x fitter_var)``
- the ``fitter_var`` coordinate values correspond to ``lsq_fitter.get_results_keys(baseline_order=1)[:-1]``
  (the last term, ``rmse``, is dropped cause it will **not** be represented in the map)
- baseline terms (offset, slope) are always set to ``True`` in the mask

.. code-block:: python

    # generate a fitter
    from spectral_toolkit.reprocess_combo import get_least_squares
    all_cids = [178, 179, 180]
    lsq = get_least_squares(all_cids, nominal_pressure=450)

    # get the coordinates for the data array
    times = ds["_datetime"]
    fitter_keys = lsq_fitter.get_results_keys(baseline_order=1)[:-1]  # drop rmse

    # generate empty mask of the correct size and dtype
    mask = np.full((len(times), len(fitter_keys)), 1).astype(bool)

    # do not fit 178, 179, set them to false
    mask[:, 2:4] = False

    # move mask into a DataArray
    fitter_mask_da = xr.DataArray(
        mask,
        dims=["_datetime", "fitter_var"],
        coords={"_datetime": times, "fitter_var": fitter_keys}
    )

The result is a suitable fitter mask, with only the baseline terms and ``180`` being fitted:

.. raw:: html
   :file: ../_static/fitter_mask.html


How to use a fitter mask
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Say you generated a ``fitter_mask`` from the steps above, and you want to use it to fit your dataset,
just pass your fitter mask to :py:func:`picarro_xarray.compute.least_squares.least_squares_fitter.fit_dataset` using
the ``cid_fitter_mask`` argument.

.. code-block:: python

    from picarro_xarray.compute.least_squares.least_squares_fitter import fit_dataset

    refit_concs_da = fit_dataset(
        dataset=ds,
        lsq_fitter=lsq,
        positive=False,
        cid_fitter_mask=fitter_mask
    )


This is the corresponding result, where you can see that the other (masked) terms values equal ``nan``:

.. raw:: html
   :file: ../_static/result_fitter_mask.html


Individual compound contributions
----------------------------------

Often, we would like to know the contribution of each compound to the partial fit (and partial fit integral).

We can use the :py:meth:`picarro_xarray.accessors.compound_search_accessor.CompoundSearchAccessor.get_model_functions` 
method together with the :py:meth:`picarro_xarray.accessors.refit_accessor.RefitAccessor.llsq` method to compute the 
contribution of each compound to the partial fit.

.. code-block:: python

    import picarro_xarray.accessors.compound_search_accessor  # noqa: F401
    import picarro_xarray.accessors.refit_accessor  # noqa: F401

    # set model functions (dictionary of model functions cid -> Spline)
    ds.compound_search.set_model_functions(model_functions=model_functions)

    # obtain refit concentrations
    refit_da = ds.refit.llsq(lsq=lsq, positive=False)

    # obtain evaluated model functions
    mf_da = ds.compound_search.get_model_functions(cids=lsq.cid_list, prefix=f"{lsq.prefix}_gasConcs_")

    # compute contributions, dimensions ``(_datetime, mode, fitter_var)``
    contribution_da = refit_da * mf_da

The sum of contributions across ``fitter_var`` will be equal 
to the ``partial_fit`` (excluding the baseline terms, offset and slope).

Removing contributions of compounds from the partial fit integral
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

We can estimate how much area each compounds covers in the partial fit integral 
by integrating the contribution of each compound across the ``mode`` dimension.

.. code-block:: python

    from picarro_xarray.compute.spectra_integral import integrate_da

    nu_prime_da = ds.sel(spectral_var="nu_prime").spectral_values
    
    pfi_contribution_da = integrate_da(
        x=nu_prime_da,
        y=contribution_da,
        integral_dim="mode",
    )

This is particularly useful to retrieve a partial fit integral without the contribution of specific compound(s).
A common example is to remove the ``3776`` and ``180`` contribution to the partial fit integral.

.. code-block:: python

    from picarro_xarray.compute.spectra_integral import partial_fit_integral

    # get the indices of the compounds to remove
    cids_to_remove = [3776, 180]
    
    mf_remove_da = ds.compound_search.get_model_functions(cids=cids_to_remove, prefix=f"{lsq.prefix}_gasConcs_")

    contribution_remove_da = refit_da * mf_remove_da

    # individual contributions of compounds to remove
    pfi_remove_contribution_da = integrate_da(
        x=nu_prime_da,
        y=contribution_remove_da,
        integral_dim="mode",
    )

    # overall contribution of compounds to remove
    overall_remove_pfi_da = pfi_remove_contribution_da.sum(dim="fitter_var")

    # original partial fit integral
    pfi_da = partial_fit_integral(ds)

    # remove the contribution of compounds to remove
    pfi_without = pfi_da - overall_remove_pfi_da


.. note::

    The compounds to remove **must** be present in the fitter, otherwise the contribution will be ignored.

.. note::

    The removal is meaningful when the gas sample is well characterized by the fitter (i.e., correct cids in the refit). 
    
.. important::

    The removal of compounds whose model functions are highly correlated (with other compounds in the fitter) is 
    a source of error, since when compounds are highly correlated their individual contributions cannot be fully separated. 
    In the extreme case of two compounds being identical, their contributions will often be equal and opposite, 
    with oscillating sign, and the removal of a single one of these compounds would be hardly meaningful.


Speed considerations
--------------------

The refitting process is computationally expensive, as it involves solving a least squares problem for each time point
in the dataset. The time complexity of the refitting process is roughly ``O(N^2 * M)`` where ``M`` is the number of
wavenumbers, ``N`` is the number of species, and the process is repeated ``T`` times (the number of time points in the dataset).
This complexity is for the unbounded least squares fitter, and it is significantly higher for the non-negative least squares
and the bounded least squares fitters, as it involves solving a constrained optimization problem (iteratively).

As a reference, using the unbounded least squares fitter on a dataset
with ``N=9``, ``M=400``, and ``T=800_000`` time points:

- unbounded least squares fitter: 4.5 minutes
- non-negative least squares fitter: 12 minutes
- bounded least squares fitter: 78 minutes

Keep in mind that the iterative results are also affected by the data itself and the specific cids and bounds provided,
as they can affect the convergence rate (in fact, setting ``bounds=None`` for the bounded least squares fitter results
in a compute time of 4.9 minutes).

The compute time can be spread across multiple workers if a distributed system is used, the previous
example running on 4 workers (8 threads) took:

- unbounded least squares fitter: 42 seconds
- non-negative least squares fitter: 100 seconds
- bounded least squares fitter: 10 minutes

Behind the scenes of refitting
------------------------------

The fitter carries around the model function objects, which need to be evaluated
at ``nu_prime`` for each species.

Say:

- the fitter has been generated with a list of ``N`` species
- the dataset has ``M`` modes
- the dataset has ``T`` time points

Then, the process of refitting is as follows:

1. At time point ``i`` in the dataset, the fitter evaluates the model
   function for each of the ``N`` species at the ``M`` wavenumbers present in the dataset.
   This step generates a matrix of shape ``(M, N + 2)``, where the first ``N`` columns are
   the model function evaluations at the wavenumbers, and the last two columns are the offset
   and the slope terms relative to ``nu_center`` (present in ``fitter_var``).
2. The fitter then solves the least squares problem,
   using the matrix generated in step 1 and the ``partial_fit`` data at time point ``i``.
3. The rmse is added to the species concentration values, resulting in a array of shape ``(N + 3,)``.
4. The process is repeated for every time point `t` in the dataset, resulting in an output of
   shape ``(T, N + 3)``.

Consider a practical example with ``N = 15``, ``M = 400``, and ``T = 20_000``, with typical dataset
chunk structure is ``{"_datetime": 10_000, "mode": 200, "spectral_var": 1}``.
To clarify, **a chunk is the minimum amount of data that is read from disk and loaded into memory at once**,
and in this case each chunk is ``10_000 x 200 x 1 x 8B ~ 15.26MB``: you cannot release memory or write
results of an operation on a chunk to disk until the entire chunk has been processed.

We need to load six chunks to solve for time ``i = 0``, two to cover the entire wavenumber range, and three to load
the three ``spectral_var`` coordinates needed. This results in a total of ``6 x 15.26MB = 91.56MB`` of data
loaded into memory. This is a low amount of data, no problem.

However, we also generate ``10_000`` of the ``(400, 15 + 3) x 8B ~ 56kB`` of data, for a total of ``~549MB``.

This number is still manageable, but it is important to keep in mind that the memory usage scales with the number
of species and wavenumbers. For example, if ``M=1_000``, ``N=18``, the memory usage will raise to ``>1.5GB``.
The time points in the dataset have an effect too, but that can be limited by chunking! Additionally,
if a distributed system is used each worker can work independently on different time chunks,
quickly increasing the memory usage. Evaluating the model functions is an expensive operation as well.

It is therefore advantageous to limit the number of times the model functions are evaluated, and
``picarro-xarray`` does this by **evaluating the model functions only once per chunk**, using the mean wavenumber
(mean of ``nu_prime`` along the ``_datetime`` dimension, per mode, for each chunk).
This is a good compromise, as we can assume that in the short period (i.e., one time chunk) the wavenumber axis is
sufficiently stable to use the mean wavenumber. This assumption is exploited also in other aspects of our typical
spectral analysis pipeline, such as during the ``compactify`` operation or compound hunting on a mean spectrum.



.. important::

   The model functions matrix is generated only once per chunk along the ``_datetime`` dimension,
   for faster compute and less memory usage.


Example
-------

This is a guided example to compare the concentrations obtained from the least squares refit
vs the non-negative least squares refit.

First, load a dataset:

.. code-block:: python

    import xarray as xr

    from picarro_xarray.preprocess.trim_transition import trim_transitions

    ds = xr.open_zarr(zarr_path)
    ds = trim_transitions(
        data=ds,
        grouper_da="ValveMask",
    )


.. raw:: html
   :file: ../_static/refit_start.html

Create a fitter:

.. code-block:: python

    from spectral_toolkit.reprocess_combo import get_least_squares  # spectral-toolkit is NOT a requirement for this repo

    nu_min = 5800
    nu_max = 6200

    cids = [176, 180, 222, 284, 3776, 7900, 7946, 10911, 10914, 13387, 24764, 66110, 6344, 6360]
    lsq = get_least_squares(cids, nominal_pressure=450)
    lsq.prefix = "refit"


Compute concentrations:

.. code-block:: python

    import picarro_xarray.accessors.refit_accessor  # noqa: F401
    refit_all = ds.refit.llsq(lsq=lsq, positive=False)
    refit_pos = ds.refit.llsq(lsq=lsq, positive=True)

Result for unbounded least squares:

.. raw:: html
   :file: ../_static/refit_all.html

Result for non-negative least squares:

.. raw:: html
   :file: ../_static/refit_positive.html

Compare the results:

.. figure:: ../_static/refit_species_timeline.png
   :width: 1000
   :align: center

   Unbounded fitter results (blue) vs non-negative fitter results (red)

.. raw:: html

   <div style="margin-top: 20px;"></div>


.. figure:: ../_static/refit_species_summary.png
   :width: 1000
   :align: center

   Unbounded fitter results (blue) vs non-negative fitter results (red)


