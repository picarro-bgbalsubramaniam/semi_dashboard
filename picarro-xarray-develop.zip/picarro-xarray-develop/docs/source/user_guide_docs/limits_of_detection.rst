Limits of detection
-------------------

We are often interested in establishing the limits of detection (LOD) from a given dataset, describing
the lowest magnitude of an effect that we can measure (detect) with statistical significance.

It is best to start with the definition of the reference data.

Reference data
~~~~~~~~~~~~~~

Given a timeseries dataset, reference data means that we know or we assume
that for this time-series there are no contaminants or other transient processes:
it is the best "zero" (or reference) that we can have.

Usually, this can mean a PAIAC output, or other reference port data.

We assume this measurement to be affected only by white noise, with a stationary underlying process.


Allan deviation and measurement noise
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Say that our time-series has  data points, at regular intervals :math:`\tau` (measured in seconds).
For example, if :math:`\tau = 3`, we have one data-point every 3 seconds.
We want to quantify how stable our data is, from one data point (at time :math:`t_i`) to the
next (at time :math:`t_{i+1}`), for all times :math:`N`. That is,
we would like to quantify the noise/uncertainty of our raw data.

As we are interested in a single metric indicating point-to-point stability (meaning from one point to the next),
we can use the Allan deviation of our reference signal measurement.

The first term of the Allan deviation is defined as:

.. math::

    \sigma (\tau) = \sqrt{\frac{1}{2 N} \sum_{i=1}^{N} (x_{i+1} - x_i)^2}

where:

- :math:`N` is the number of samples along the `_datetime` dimension
- :math:`x_i` is the value of the timeseries variable at time :math:`i`

In our case, we might have uncertainty on :math:`\tau` : we usually assume
that the *median* time delta is a representative proxy of :math:`\tau` .


Raw limit of detection
~~~~~~~~~~~~~~~~~~~~~~~

Assuming that:

- the underlying process is dominated by random Gaussian noise
- :math:`\sigma (\tau)` is a measure of uncertainty in our reference data

The raw limit of detection is calculated as:

.. math::

    LOD (\tau) = 3 \sigma (\tau)

where:

- :math:`\sigma (\tau)` is the first term of the Allan deviation of our reference signal measurement
- :math:`\tau` is the time interval between samples

The factor of 3 is a common choice, as it corresponds to a 99.7% confidence interval for a Gaussian distribution:
this means that approximately 99.7% of the deviations from the mean of the reference data will be less
than :math:`\pm 3 \sigma`, under the assumption of normally distributed fluctuations.

In other words, if we observe a signal deviation that is larger than :math:`3 \sigma (\tau)`, we can say that
the signal is statistically significant, and not due to random noise.


More practically, assuming:

- `vars_` is a list of variables (concentrations) that we want to evaluate the LOD for
- the dataset has a coordinate ``ValveMask`` in ``fitter_var`` to identify reference data
- the reference value is ``ValveMask = 1``

We can evaluate the raw limits of detection with ``picarro-xarray`` as follows:

.. code-block:: python

    from picarro_xarray.compute.detection_limits import limits_of_detection

    vars_ = [v for v in ds.fitter_var.values if "gasConcs" in v]

    lod_raw = limits_of_detection(
        data=ds.sel(fitter_var=vars_).fitter_values,
        transition_variable=ds.sel(fitter_var="ValveMask").fitter_values,
        reference_value=1,
        averaging_time_seconds=None
    )


Looking at the result, you can see the LOD for each species, evaluated at
the median time delta :math:`\tau=5.472` s.

.. raw:: html
   :file: ../_static/lod_raw_ts.html


Limit of detection at a different averaging time
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Say that we want to evaluate our limit of detection at a different averaging time :math:`T > \tau`.

For example, if we scan different ports for :math:`T = 10` minutes, and we compute port averages,
we might want to compare these port averages to our limit of detection evaluated at :math:`T`.

How do we translate the raw LOD from :math:`\tau` to :math:`T`?

For the Allan deviation:

.. math::

     \sigma (T) =  \sigma (\tau) \cdot \sqrt{\frac{\tau}{T}}

For the limit of detection:

.. math::

     LOD (T) =  LOD (\tau) \cdot \sqrt{\frac{\tau}{T}}

This is valid for a white frequency noise process,
where the Allan variance is inversely proportional to the sampling interval :math:`\tau`.

We can evaluate the raw limits of detection at a different averaging time :math:`T=600` s
with ``picarro-xarray`` as follows:

.. code-block:: python

    from picarro_xarray.compute.detection_limits import limits_of_detection

    vars_ = [v for v in ds.fitter_var.values if "gasConcs" in v]

    lod_raw = limits_of_detection(
        data=ds.sel(fitter_var=vars_).fitter_values,
        transition_variable=ds.sel(fitter_var="ValveMask").fitter_values,
        reference_value=1,
        averaging_time_seconds=600
    )


Looking at the result, you can see the LOD for each species, evaluated at
 :math:`\tau=600` s.

.. raw:: html
   :file: ../_static/lod_600_ts.html


Limit of detection for spectral data
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Evaluating the limit of detection for the concentration of different species is a great tool to
understand the quality of the data and the detection limits of the instrument with a specific fitter, with a
certain set of species. If we change the species in the fitter, and we evaluate the LOD using the same reference data,
we might obtain different results.

With ``picarro-xarray``, it is possible to study the problem upstream, evaluating the limits of detection on the
measured spectral data. What this means is that we can evaluate the LOD for a time-series of spectral data
for each measured mode (frequency).

While this is still an unexplored area, it is a promising approach to:

- evaluate mode-specific performance of the instrument
- perform event detection at the spectral level

It is fairly straightforward to evaluate the LOD for spectral data with ``picarro-xarray``, we simply
need to pass all data (i.e., both ``fitter_values`` **and** ``spectral_values``) to the function:

.. code-block:: python

    from picarro_xarray.compute.detection_limits import limits_of_detection

    vars_ = [v for v in ds.fitter_var.values if "gasConcs" in v]

    lod_raw = limits_of_detection(
        data=ds.sel(fitter_var=vars_),
        transition_variable=ds.sel(fitter_var="ValveMask").fitter_values,
        reference_value=1,
        averaging_time_seconds=None
    )


As you can see from the output below, the limits of detection calculation will "collapse" the ``_datetime`` dimension
into a single value. This means that ``fitter_values`` will go from dimensions ``(_datetime, fitter_var)`` to
``(fitter_var)``, and ``spectral_values`` will go from dimensions ``(_datetime, spectral_var, mode)`` to
``(spectral_var, mode)``.

.. raw:: html
   :file: ../_static/lod_raw_all.html

You can visualize the spectral limits of detection using :code:`lod_raw.spectral_values.to_pandas().T`
(showing only the first few modes):

.. raw:: html
   :file: ../_static/spectral_lods.html

Figure of Merit
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The Figure of Merit (FOM) is a metric that indicates whether a signal is statistically significant compared to noise. 
It is calculated by normalizing zero-referenced data by the limits of detection.

When the Figure of Merit is greater than 1, it indicates that the signal is statistically significant - 
meaning we can be confident (at the confidence level used to calculate the LOD, typically 3-sigma) 
that the observed signal is not just noise.

Using the Figure of Merit
^^^^^^^^^^^^^^^^^^^^^^^^^

To calculate the Figure of Merit with ``picarro-xarray``, you need:

1. Zero-referenced data
2. Limits of detection data 
3. (Optional) A grouping variable

Here's how to calculate the Figure of Merit:

.. code-block:: python

    import picarro_xarray.accessor.zero_reference_accessor  # noqa
    from picarro_xarray.compute.detection_limits import limits_of_detection
    from picarro_xarray.compute.figure_of_merit import figure_of_merit

    # 1. Get zero-referenced data
    zero_da = ds.fitter_values.zero_reference.zero_reference("ValveMask", 1)

    # 2. Calculate limits of detection
    lod_da = limits_of_detection(
        data=ds.fitter_values,
        transition_variable="ValveMask",
        reference_value=1,
        averaging_time_seconds=100,
    )

    # 3. Calculate figure of merit
    fom = figure_of_merit(
        zero_referenced_data=zero_da,
        lod_data=lod_da,
        groupby="ValveMask",
    )

Transitioning from deprecated API
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

If you were using the now-deprecated ``get_figure_of_merit`` function (deprecated as of version ``0.0.17``), here's how to transition to the new API:

**Old approach:**

.. code-block:: python

    import picarro_xarray.accessors.allan_accessor  # noqa
    import picarro_xarray.accessor.zero_reference_accessor  # noqa

    # Get zero-referenced data
    zero_da = ds.fitter_values.zero_reference.zero_reference("ValveMask", 1)

    # Calculate FOM (deprecated)
    fom = get_figure_of_merit(
        zero_referenced_data=zero_da,
        transition_variable_data=ds.fitter_values.sel(fitter_var="ValveMask").fitter_values,
        reference_sigma_tau=reference_ds.fitter_values.allan.allan_dev(complete=False),
    )

**New approach:**

.. code-block:: python

    import picarro_xarray.accessor.zero_reference_accessor  # noqa
    from picarro_xarray.compute.detection_limits import limits_of_detection
    from picarro_xarray.compute.figure_of_merit import figure_of_merit

    # Get zero-referenced data
    zero_da = ds.fitter_values.zero_reference.zero_reference("ValveMask", 1)

    # Calculate limits of detection
    lod_da = limits_of_detection(
        data=ds.fitter_values,
        transition_variable="ValveMask",
        reference_value=1,
        averaging_time_seconds=100,
    )

    # Calculate figure of merit
    fom = figure_of_merit(
        zero_referenced_data=zero_da,
        lod_data=lod_da,
        groupby="ValveMask",
    )

