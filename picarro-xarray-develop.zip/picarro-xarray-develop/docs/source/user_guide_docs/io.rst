Reading files
-------------

`picarro-xarray` provides support for reading standard xarray file formats, such as netCDF and Zarr, and
it provides functions to read Picarro data files.


.. important::

    The time axis in the zarr store (and associated dataset) must be monotonically increasing.
    If daylight saving time ends during the course of the experiment (clocks are set back one hour),
    the time axis will not be monotonically increasing, and an error will be raised when reading the data.
    You can prevent this error by reading data with ``local_time_zone=UTC``.


Reading combo logs files
^^^^^^^^^^^^^^^^^^^^^^^^

You can read combo log files (with extension ``.h5``) using the function
:py:func:`picarro_xarray.io.combolog.combo_log_spectra.read_combo_logs`.
The function scans a directory (recursively) for combologs, it "pools" them into a zarr store,
and it returns the path to the zarr store. You can then open the zarr store using xarray.

Example:

.. code-block:: python

    import xarray as xr
    from picarro_xarray.io.combolog.combo_log_spectra import read_combo_logs

    # source files
    combo_path = "/mnt/r/crd_G9000/xxxxx/20231205-xxxx/Combo"

    # destination folder where the zarr store will be created
    dest_folder = "/Users/andrea/pools"

    # Read combo logs
    zarr_store = read_combo_logs(
        folder_path=combo_path,
        local_time_zone="US/Pacific",
        path_to_zarr=dest_folder,
    )

    # Open the zarr store using xarray
    ds = xr.open_zarr(zarr_store)


.. note::
    Remember that
    combo logs are originally written in the h5 files with UTC timezone, but
    the `_datetime` axis in the xarray Dataset is converted
    to the specified ``local_time_zone`` when
    the zarr store is created.



Reading private logs
^^^^^^^^^^^^^^^^^^^^

You can read private log files (with extension ``.zip``) using the function
:py:func:`picarro_xarray.io.privatelog.private_log_results.read_private_logs`.
The function scans a directory (recursively) for private logs, it "pools" them into a zarr store,
and it returns the path to the zarr store. You can then open the zarr store using xarray.

Example:

.. code-block:: python

    import xarray as xr
    from picarro_xarray.io.privatelog.private_log_results import read_private_logs

    # source files
    private_path = "/mnt/r/crd_G9000/xxxxx/20231205-xxxx/Private"

    # destination folder where the zarr store will be created
    dest_folder = "/Users/andrea/pools"

    # Read private logs
    zarr_store = read_private_logs(
        folder_path=private_path,
        local_time_zone="US/Pacific",
        path_to_zarr=dest_folder,
    )

    # Open the zarr store using xarray
    ds = xr.open_zarr(zarr_store)


.. hint::

    When using only private log data (2D), it is more convenient to operate using Pandas DataFrames.
    After the pooling procedure above, you can get private log data from an Xarray Dataset into
    a Pandas DataFrame with ``df = ds.private_values.to_pandas()``.


Reading mixed logs
^^^^^^^^^^^^^^^^^^

You can read both combo and private log files related to the same experiment using the function
:py:func:`picarro_xarray.io.read_files.pool_data_to_zarr`.
This function **requires** the presence of a ``combolog_folder_path``, but the ``privatelog_folder_path``
is optional: this highlights the first class importance of combo log data with respect to private log data.

The function scans the ``combolog_folder_path`` for combo logs, and it scans the
``privatelog_folder_path`` for private logs. It "pools" the logs into a zarr store, and it returns
the path to the zarr store. You can then open the zarr store using xarray.

Example:

.. code-block:: python

    import xarray as xr
    from picarro_xarray.io.read_files import pool_data_to_zarr

    # source files
    combo_path = "/mnt/r/crd_G9000/xxxxx/20231205-xxxx/Combo"
    private_path = "/mnt/r/crd_G9000/xxxxx/20231205-xxxx/Private"

    # destination folder where the zarr store will be created
    dest_folder = "/Users/andrea/pools"

    zarr_path = pool_data_to_zarr(
        combolog_folder_path=combo_path,
        privatelog_folder_path=private_path,  # optional
        path_to_zarr=exp_folder,
        local_time_zone="US/Pacific",
    )

    # Open the zarr store using xarray
    ds = xr.open_zarr(zarr_path)


.. important::
    The combo log and private log time axis (timestamp) might be different inside the h5 files.
    The function will try to align the private log time axis to the combo log time axis, if the
    timestamp are within a tolerance (1 second).