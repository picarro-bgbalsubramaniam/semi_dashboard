Spectral Operations
===================

You can perform operations between ``CompactDataSet``'s using
the :py:class:`spectral operations accessor<picarro_xarray.accessors.spectral_operations_accessor.SpectralOperationsAccessor>`.

Currently, the available **high-level operations** are :py:meth:`subtraction <picarro_xarray.accessors.spectral_operations_accessor.SpectralOperationsAccessor.subtract>`
, :py:meth:`addition <picarro_xarray.accessors.spectral_operations_accessor.SpectralOperationsAccessor.add>`
, :py:meth:`multiplication <picarro_xarray.accessors.spectral_operations_accessor.SpectralOperationsAccessor.multiply>`
, :py:meth:`union <picarro_xarray.accessors.spectral_operations_accessor.SpectralOperationsAccessor.union>`
, :py:meth:`intersection <picarro_xarray.accessors.spectral_operations_accessor.SpectralOperationsAccessor.intersection>`
, :py:meth:`arithmetic mean <picarro_xarray.accessors.spectral_operations_accessor.SpectralOperationsAccessor.arithmetic_mean>`.

In a spectral operation, you have two operands:

- the first operand, i.e., the dataset you are using to call the accessor, must be a ``CompactDataSet``
- the second operand can be a scalar (``int``, ``float``) or a ``CompactDataSet`` of length ``1`` along the ``_datetime`` axis

In the example below ``ds`` is the first operand, and ``other`` is the second operand.

.. code-block:: python

    import picarro_xarray.accessor.spectral_operations_accessor  # noqa
    result = ds.spectral_ops.subtract(other)

The requirement of operands being ``CompactDataSet``'s mean that they must be the result of
a :py:func:`compactify operation <picarro_xarray.compute.compactify.compactify>`. You can see more details about
compactify in the user guide.

In the example above:

- ``ds`` is a ``CompactDataSet``, possibly containing more than one compact spectrum (i.e.,
  ``_datetime`` dimension length is greater or equal than 1)
- and ``other`` is a ``CompactDataSet`` containing only **one** compact spectrum
- the subtraction operation takes every spectrum in ``ds`` along the ``_datetime`` axis and
  subtracts the ``other`` compact spectrum
- hence, the result has the same shape of ``ds`` along the ``_datetime`` axis.

.. important::

    - spectral operations can be used only after performing the
      :py:func:`compactify <picarro_xarray.compute.compactify.compactify>` operation on raw datasets
    - the second operand must have only **one** ``_datetime`` (or be a scalar)


Base operations versus high-level operations
-----------------------------------------------

You have already seen above some high-level operations, such as
:py:meth:`subtract<picarro_xarray.accessors.spectral_operations_accessor.SpectralOperationsAccessor.subtract>`.

Our dataset contains different variables, time-series variables (``fitter_values``) and spectral-time-series variables
(``spectral_values``). Variables, especially spectral variables, can have different meaning and therefore require
different aggregations: when performing a subtraction operation, the ``npoints`` variable can be awkward to manage, as
performing a straight subtraction can result in zero or even negative values, losing all the meaning behind that variable.
This sort of idiosyncrasies are already managed for you when you use high-level operations
through the accessor with high-level operations: in the case of ``subtract``,
a ``UNION`` base operation is performed on the ``npoints`` variable (for now, think of
union as a sort of mean value).

.. important::

    **Base operations are the lowest level abstractions for spectral operations**:
    a base operation defines how two operands and their respective uncertainties combine into
    a result and its uncertainty.

The base operations are mapped in the class
:py:class:`Operation<picarro_xarray.compute.spectral_operations.operations.Operation>`, and include sum, difference,
product, division, union, intersection, minimum, maximum, arithmetic mean, passthrough.

.. important::

    A high-level operation maps different base operations
    onto different time-series and spectral-time-series variables.

For example, the
:py:meth:`subtract<picarro_xarray.accessors.spectral_operations_accessor.SpectralOperationsAccessor.subtract>`
operation might map for ``spectral_values`` as:

.. code-block::

    {
        <Operation.UNION: 'union'>: ['nu', 'nu_prime'],
        <Operation.MINIMUM: 'minimum'>: ['npoints'],
        <Operation.DIFFERENCE: 'difference'>: ['residuals', 'big3', 'model', 'partial_fit', 'absorbance']
    }


and for ``fitter_values`` as:

.. code-block::

    {
        <Operation.DIFFERENCE: 'difference'>: ['AmbientPressure', 'ValveMask', ... , 'tunerValueStd', 'fsr']
    }


Combine base operations for custom high-level operations
--------------------------------------------------------

If you wish to apply a different
:py:class:`Operation<picarro_xarray.compute.spectral_operations.operations.Operation>`
to time-series data (``fitter_values``) when performing
:py:meth:`subtract<picarro_xarray.accessors.spectral_operations_accessor.SpectralOperationsAccessor.subtract>`,
you can pass the operation to the ``timeseries_operation`` argument.

|

If you wish to apply different operations to
different ``fitter_var`` coordinate values, you can still use the ``timeseries_operation`` argument and pass a dictionary with
operations as keys, and lists of ``fitter_var`` variables as values.

For example, to apply ``Operation.PASSTHROUGH`` to ``ValveMask`` only:

.. code-block:: python


    import picarro_xarray.accessor.spectral_operations_accessor  # noqa
    from picarro_xarray.compute.spectral_operations.operations import Operation

    passthrough_vars = ["ValveMask"]
    timeseries_op_map = {
        Operation.PASSTHROUGH: passthrough_vars,
        Operation.DIFFERENCE: list(set(ds.fitter_var.values).difference(passthrough_vars)),  # all other variables
    }
    result = ds.spectral_ops.subtract(other, timeseries_operation=timeseries_op_map)

|

If you wish even more flexibility and want to run a custom high-level operation, you can use the
:py:meth:`custom_operation<picarro_xarray.accessors.spectral_operations_accessor.SpectralOperationsAccessor.custom_operation>`
method. With this method you can perform different base operation on both time-series data (``fitter_values``)
and spectral-time-series data (``spectral_values``).

.. code-block:: python


    import picarro_xarray.accessor.spectral_operations_accessor  # noqa
    from picarro_xarray.compute.spectral_operations.operations import Operation

    passthrough_vars = ["ValveMask"]
    timeseries_op_map = {
        Operation.PASSTHROUGH: passthrough_vars,
        Operation.DIFFERENCE: list(set(ds.fitter_var.values).difference(passthrough_vars)),  # all other variables
    }
    result = ds.spectral_ops.custom_operation(
        other,
        operation_timeseries=timeseries_op_map,
        operation_spectra=Operation.DIFFERENCE
    )


Error propagation
-----------------

Error propagation models describe how the uncertainty associated to two measurements combine.
They are essential into understanding base operations, as each base operation will be using one of these
error propagation model under the hood.

Errors in quadrature
~~~~~~~~~~~~~~~~~~~~~

Calculate the propagated uncertainty for the
sum or difference of two quantities.

This function computes the uncertainty in the sum or difference of two quantities
when their uncertainties are known. It uses the quadratic sum rule for error propagation.
The rule is used when the uncertainties are independent and random.

Suppose that ``x`` and ``y`` are two quantities that are measured with uncertainties ``δx`` and ``δy``.
The uncertainty can be expressed as a standard deviation or a standard error
(just be consistent with quantities inside the formula).

The sum or difference of the two quantities is then given by:

.. math::

    q = x ± y

And to estimate the uncertainty in the sum or difference, we use the quadratic sum rule:

.. math::

    δq = \sqrt{δx^2 + δy^2}

where ``δq`` is the propagated error for the sum or difference, and ``δx`` and ``δy``
are the uncertainties of the individual quantities.

Fractional errors in quadrature
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Calculate the propagated uncertainty for the product or quotient of two quantities.

This function computes the uncertainty in the product or quotient
of two quantities based on their individual uncertainties and means.
When the uncertainties of two quantities are known and are independent and random,
the fractional uncertainty in their product is the sum in quadrature of the original
fractional uncertainties.
The formula is derived from the general principle of error propagation for products and quotients.

Let ``δx`` and ``δy`` be the uncertainties, and ``x`` and ``y`` be the means of the quantities.
The uncertainty can be expressed as a standard deviation or a standard error
(just be consistent with quantities inside the formula).

The product or quotient of the two quantities is then given by:

.. math::
    q = x \cdot y  \qquad \text{or} \qquad q = x / y

Where q is the product or quotient of the two quantities.
The fractional uncertainties are ``(δx/x)`` and ``(δy/y)``.
The propagated uncertainty for the product is given by:

.. math::

    δq = q \cdot \sqrt{ (δx/x)^2 + (δy/y)^2 }

.. _weighted-mean-error-propagation:

Weighted mean error propagation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Compute the weighted mean of two quantities.

This function calculates the weighted average of two measurements taking into account
their uncertainties.
Each measurement is weighted by the inverse of the square of its uncertainty.

Let ``x_1`` and ``x_2`` be the means, and ``δ_1`` and ``δ_2`` be the uncertainties of the measurements.
The weights for each measurement, ``w_1`` and ``w_2``, are computed as:

.. math::

    w_i = 1 / δ_i^2 \quad \text{for} \qquad i=1,2


The weighted mean is given by:

.. math::

    x_{wav} = \frac{w_1 \, x_1 + w_2 \, x_2}{w_1 + w_2}

The combined uncertainty is the reciprocal square root of the sum of the individual weights:

.. math::

    σ_{wav} = \sqrt{1/(w_1 + w_2)}


If errors for a measurement are zero,
the weights are infinite, and the weighted average calculation would
be undefined. In that case, the weights are replaced with the count of samples,
allowing the calculation to proceed with count-based weighting in these cases.

If the second operand is a scalar, the error from the first operand is propagated.


Base operations
----------------

The base operations currently include sum, difference, product, division, union,
intersection, minimum, maximum, arithmetic mean, passthrough.

|

We can take a look at the current low-level implementation of the ``SUM`` base operation to get a glimpse
into a spectral operation. We can see two parts, the first tells you how to combine the (mean value of) measurements,
and the second how to combine their uncertainty/error. In this case, the mean values are added together, and the
errors are combined in quadrature.

.. code-block:: python

    def _perform_sum(
        mean_1: xr.DataArray,
        mean_2: xr.DataArray,
        errors_1: xr.DataArray,
        errors_2: xr.DataArray,
    ):
    """
    Computes the sum of two data arrays.

    Args:
        mean_1 (xr.DataArray): The first data array.
        mean_2 (xr.DataArray): The second data array.
        errors_1 (xr.DataArray): The error associated with the first data array.
        errors_2 (xr.DataArray): The error associated with the second data array.

    Returns:
        tuple[xr.DataArray, xr.DataArray]: The sum of the two data arrays and the combined error.
    """
    result_sum = mean_1 + mean_2
    error = errors_quadrature(errors_1=errors_1, errors_2=errors_2)
    return result_sum, error

Current operations are:

- ``SUM``: sum arrays, errors in quadrature
- ``DIFFERENCE``: subtract arrays, errors in quadrature
- ``PRODUCT``: multiply arrays, fractional errors in quadrature
- ``DIVISION``: divide arrays, fractional error in quadrature
- ``UNION``: a weighted "mean" operation where all modes/frequencies are kept, error is reciprocal square root of weights
- ``INTERSECTION``: a weighted "mean" operation where only common modes/frequencies are kept, error is reciprocal square root of weights
- ``MINIMUM``: minimum of arrays, keep error associated to the minimum array
- ``MAXIMUM``: maximum of arrays, keep error associated to the maximum array
- ``ARITHMETIC_MEAN``: arithmetic mean of arrays, errors in quadrature
- ``PASSTHROUGH``: Passthrough the first operand and its error

You can take a look at an example below where different operations are applied to the same two operands.
Operand 1 consists of 3 spectra of length 5, and operand 2 is a single spectrum of length 5 as well. Each operand
has its own uncertainty: for compact data, the standard error is used by default as uncertainty measurement.

.. raw:: html

   <video width="720" controls>
     <source src="../_static/spectral_operations.mp4" type="video/mp4">
     Your browser does not support the video tag.
   </video>

Variables with different coordinates (modes/frequencies)
--------------------------------------------------------

If operand 1 and operand 2 come from a different dataset, different section of a dataset, or different
``compactify`` operations, they might have discrepancies on the frequency axis (``mode``).

In that case, a spectral operation will operate only on the common modes (intersection),
and the remaining ones will be discarded.

The exception to this rule is the ``UNION`` base operation, where the ``mode`` coordinate of the result will be
the union between operand 1 and operand 2 ``mode`` coordinates.

.. note::

    If a high-level operation includes a ``UNION`` together with another non-``UNION`` base operation,
    the ``mode`` coordinate of the result will be the **intersection** between
    operand 1 and operand 2 ``mode`` coordinates.


Compact an already compact dataset
-----------------------------------
Sometimes we have a compact dataset and we want to compact it into a single spectrum. For example,
we might have all the (compacted) occurrences of a reference port scan, and we want to merge them into a 
single spectrum to be used as reference for the whole dataset.

We can do this with the
:py:func:`merge_compact<picarro_xarray.compute.spectral_operations.spectral_operations.merge_compact>` function,
or equivalently with the :py:meth:`merge_compact<picarro_xarray.accessors.spectral_operations_accessor.SpectralOperationsAccessor.merge_compact>`
method through the accessor.

It performs a :ref:`weighted mean error propagation <weighted-mean-error-propagation>`,
as seen in the section above, with multiple operands ``(x_i, δ_i)``,
each a ``_datetime`` point in the original compact dataset (with its own mean and uncertainty).

.. code-block:: python

    import picarro_xarray.accessors.spectral_operations_accessor  # noqa
    result = compact_ds.spectral_ops.merge_compact()

Or equivalently:

.. code-block:: python

    from picarro_xarray.compute.spectral_operations.spectral_operations import merge_compact
    result = merge_compact(compact_ds)

Alternatively, and preferably, you can avoid the issue by either running a different compactify,
or write a different grouper (and run a compactify).


.. code-block:: python

    import picarro_xarray.accessors.compactify_accessor # noqa
    import picarro_xarray.accessor.spectral_operations_accessor  # noqa
    reference_port = 1

    compact_ds = ds.compactify.compact(
        groupby="ValveMask",
        consecutive=True
    )

    valve_mask = compact_ds.sel(fitter_var=transition_var, drop=True).fitter_values == reference_port
    reference_compact_ds = compact_ds.where(valve_mask.compute(), drop=True)

    # I want all my reference into a single compact spectra! What do I do?

    # preferred
    compact_ds = ds.compactify.compact(
        groupby="ValveMask",
        consecutive=False
    )
    valve_mask = compact_ds.sel(fitter_var=transition_var, drop=True).fitter_values == reference_port
    reference_compact_single_ds = compact_ds.where(valve_mask.compute(), drop=True)

    # easier alternative, but formally less correct
    reference_compact_single_ds = reference_compact_ds.spectral_ops.merge_compact()


Guidelines and common misunderstanding
--------------------------------------

Second operand contains multiple spectra
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

There is currently no way of processing a spectral operation where the second operand is
a dataset with ``_datetime`` dimension larger than one. This is because that operation would be
a cartesian product, expensive in terms of computation, data size, and bookkeeping.

.. code-block:: python

    import picarro_xarray.accessor.spectral_operations_accessor  # noqa
    # ds has 500 datetimes
    # other has 30 datetimes
    result = ds.spectral_ops.subtract(other)  # Currently not allowed, result would be 15_000 "_datetime"'s



