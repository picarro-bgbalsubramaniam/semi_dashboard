User guide
----------

Here you will find examples and explanations of how to use the `picarro-xarray`.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Reading files <io>
   Trim transitions <transitions>
   Zero-reference data <zero_reference>
   Limits of detection <limits_of_detection>
   Least squares refit <refit>
   Regularized refit with ridge <ridge>
   Compactify <compactify>
   Partial fit integral <spectra_integral>
   Operations between spectra <spectral_operations>
   Using Petroglyph <petroglyph>
