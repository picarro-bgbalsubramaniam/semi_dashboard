class AllanDevNotEnoughSamples(Exception):
    """
    Exception raised when Allan deviation
    is computed for an insufficient number of samples.
    """

    def __init__(self, n_samples: int):
        self.message = f"{n_samples=} is too small, needs at least 2 samples"
        super().__init__(self.message)
