import numpy as np
from pydantic import validate_call, Field
import xarray as xr

from picarro_xarray.compute.zero_reference import get_transition_uid
from picarro_xarray.data_models.constants import TIME_DIM
from picarro_xarray.data_models.data_types import (
    TimeseriesDataArray,
    TimeseriesDataSet,
    TimeBounds,
)
from picarro_xarray.time_utils.timeutils import _parse_grouper


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def trim_transitions(
    data: TimeseriesDataArray | TimeseriesDataSet,
    grouper_da: TimeseriesDataArray | str,
    min_duration_seconds: int = Field(default=50, ge=0),
    trim_start_seconds: int = Field(default=30, ge=0),
    trim_end_seconds: int = Field(default=10, ge=0),
) -> TimeseriesDataArray | TimeseriesDataSet:
    """
    Trim the transitions in time series data.
    - drop transitions with duration less than `min_duration_seconds`
    - trim `trim_start_seconds` from the start of each transition
    - trim `trim_end_seconds` from the end of each transition

    A transition is defined as a time range where the
    data is grouped by `grouper_da`.

    Args:
        data (TimeseriesDataArray | TimeseriesDataSet): Time series data to trim.
        grouper_da (TimeseriesDataArray | str):
            DataArray used for grouping time points.
            Can be a string representing a variable name in ``fitter_var`` in ``data``,
            or a custom 1D TimeseriesDataArray indicating how to form groups
            (must have the same time length as ``data``, and must be 1D).
            For example, ``grouper_da = get_transition_uid(ds.sel(fitter_var='ValveMask').fitter_values)``
            or ``grouper_da="ValveMask"``.
        min_duration_seconds (int): Minimum duration in seconds for a time range to be kept.
        trim_start_seconds (int): Number of seconds to trim from the start of each time range.
        trim_end_seconds (int): Number of seconds to trim from the end of each time range.

    Returns:
        TimeseriesDataArray | TimeseriesDataSet: Trimmed time series data.
    """
    groupby = _parse_grouper(data=data, grouper=grouper_da)
    groupby = get_transition_uid(transition_data=groupby)

    time_bounds_da = get_groups_time_bounds(
        time_da=data[TIME_DIM], grouper_da=groupby
    )
    time_bounds_da = drop_short_transitions(
        time_bounds_da=time_bounds_da, min_duration_seconds=min_duration_seconds
    )
    time_bounds_da = trim_transitions_edges(
        time_bounds_da=time_bounds_da,
        trim_start_seconds=trim_start_seconds,
        trim_end_seconds=trim_end_seconds,
    )
    datetime_mask = _boolean_mask_datetime(
        datetime_np=data[TIME_DIM].values,
        datetime_mins=time_bounds_da.sel(stats="min").values,
        datetime_maxs=time_bounds_da.sel(stats="max").values,
    )
    datetimes_keep = data[TIME_DIM].values[datetime_mask]
    return data.sel({TIME_DIM: datetimes_keep})


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_groups_time_bounds(
    time_da: TimeseriesDataArray,
    grouper_da: TimeseriesDataArray,
) -> TimeBounds:
    """
    Groups a data array based on another grouper data array and
    returns a data array with time bounds (min and max)
    of each group.

    Args:
        time_da (TimeseriesDataArray):
            The original time series DataArray.
            Usually it is ds['_datetime']
        grouper_da (TimeseriesDataArray):
            DataArray used for grouping time_da.
            Usually it is a transition_uid from `.get_transition_uid()`

    Returns:
        TimeBounds: A DataArray with the min and max of each group.
    """

    # Group by the provided grouper data array
    group_da = time_da[TIME_DIM].groupby(grouper_da)

    # Extract the keys representing each group
    groups = list(group_da.groups.keys())

    # Find the min and max time for each group
    groups_min = group_da.min(dim=TIME_DIM)
    groups_max = group_da.max(dim=TIME_DIM)

    # Create a new DataArray to store these min and max times
    time_bounds_da = xr.DataArray(
        data=[groups_min, groups_max],
        dims=["stats", "group"],
        coords={
            "stats": ["min", "max"],
            "group": groups,
        },
    )

    return time_bounds_da


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def drop_short_transitions(
    time_bounds_da: TimeBounds, min_duration_seconds: int = Field(default=50, ge=0)
) -> xr.DataArray:
    """
    Drop short transitions in time bounds DataArray based on minimum duration.

    Args:
        time_bounds_da (TimeBounds):
           The original DataArray containing time bounds from `.group_time_axis()`
        min_duration_seconds (int, default=50):
            Minimum duration of transition in seconds.
            Must be non-negative.

    Returns:
        xr.DataArray:
            A new DataArray with short transitions dropped.
    """
    # Calculate the duration for each time bound
    duration = time_bounds_da.sel(stats="max") - time_bounds_da.sel(stats="min")

    # Create a boolean mask for durations greater than the minimum duration
    duration_mask = duration > np.timedelta64(min_duration_seconds, "s")

    # Filter the original DataArray based on the duration mask
    return time_bounds_da.where(duration_mask, drop=True)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def trim_transitions_edges(
    time_bounds_da: TimeBounds,
    trim_start_seconds: int = Field(default=30, ge=0),
    trim_end_seconds: int = Field(default=10, ge=0),
) -> TimeBounds:
    """
    Adjusts the time bounds DataArray by trimming start and end seconds.

    Args:
        time_bounds_da (DataArray):
            The original DataArray containing time bounds.
        trim_start_seconds (int): Number of seconds to trim from the start time.
        trim_end_seconds (int): Number of seconds to trim from the end time.

    Returns:
        DataArray: A new DataArray with adjusted time bounds.
    """
    new_bounds_da = time_bounds_da.copy(deep=True)

    # trim start and end time
    new_bounds_da.loc["min"] += np.timedelta64(trim_start_seconds, "s")
    new_bounds_da.loc["max"] -= np.timedelta64(trim_end_seconds, "s")

    # Remove short transitions with zero duration
    new_bounds_da = drop_short_transitions(
        time_bounds_da=new_bounds_da, min_duration_seconds=0
    )

    return new_bounds_da


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _boolean_mask_datetime(
    datetime_np: np.ndarray, datetime_mins: np.ndarray, datetime_maxs: np.ndarray
) -> np.ndarray:
    """
    Create a boolean mask based on datetime intervals.

    Generate a boolean mask where each element in `datetime_np` is checked to see
    if it lies within any of the intervals defined by `datetime_mins` and `datetime_maxs`.

    Important:

        * It is assumed that datetime_np is monotonically increasing (sorted),
          as well as datetime_mins and datetime_maxs.

        * It is assumed that the intervals defined by `datetime_mins` and `datetime_maxs`
          are disjoint (do not overlap). This allows us to find indexes for datetime_min
          only rather than doing it for both datetime_min and datetime_max.

    Args:
        datetime_np (np.ndarray): datetime64 array (#datetimes).
        datetime_mins (np.ndarray):
            Lower bounds for datetime intervals. Must be the same length as `datetime_maxs`.
        datetime_maxs (np.ndarray):
            Upper bounds for datetime intervals. Must be the same length as `datetime_mins`.

    Returns:
        np.ndarray:
            A boolean mask with the same length as `datetime_np`.
            True if the corresponding element in `datetime_np` is within any interval
            defined by `datetime_mins` and `datetime_maxs`.
            False otherwise (to be dropped).

    Notes:
        Assume datetime_min and datetime_max have length ``m``.
        Each of the ``m`` interval is defined as [datetime_min, datetime_max],
        think of them as ``m`` interval tuples.

        In the calculations, ``min_indices`` has length ``len(datetime_np)``.
        Each element represents the index of the interval tuple that the corresponding
        element in ``datetime_np`` should be compared against.

    Example:

        >>> vals = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13])
        >>> mins = np.array([3, 9, 12])
        >>> maxs = np.array([5, 10, 13])
        >>> _boolean_mask_datetime(vals, mins, maxs)  # doctest: +NORMALIZE_WHITESPACE +ELLIPSIS
        array([False, False,  True,  True,  True, False, False, False,  True,
            True, False, True, True])

    In the example above::

        interval_indices = np.array([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 2, 2])

    Raises:
        ValueError: If `datetime_mins` and `datetime_maxs` are not of the same length.
    """

    if len(datetime_mins) != len(datetime_maxs):
        raise ValueError(
            "`datetime_mins` and `datetime_maxs` must have the same length."
        )

    if len(datetime_mins) == 0:
        return np.full(len(datetime_np), False)

    interval_indices = np.searchsorted(datetime_mins, datetime_np, side="right") - 1
    interval_indices = np.clip(interval_indices, 0, len(datetime_mins) - 1)

    # compare mask
    greater_equal_mask = datetime_np >= datetime_mins[interval_indices]
    less_equal_mask = datetime_np <= datetime_maxs[interval_indices]

    # both conditions must be true
    boolean_mask = greater_equal_mask & less_equal_mask

    return boolean_mask
