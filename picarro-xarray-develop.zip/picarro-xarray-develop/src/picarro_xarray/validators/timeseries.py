import numpy as np
import xarray as xr

from picarro_xarray.data_models.constants import MODE_DIM, STATS_DIM, TIME_DIM


def verify_time_dimension(input: xr.DataArray | xr.Dataset):
    if TIME_DIM not in input.dims:
        raise ValueError(f"input must have a `{TIME_DIM}` dimension")

    if not np.issubdtype(input[TIME_DIM].dtype, np.datetime64):
        msg = (
            f"The input `{TIME_DIM}` coordinate must have a dtype that is a subtype of `np.datetime64`."
            f"Please convert it. Example: "
            f"input['{TIME_DIM}'] = input['{TIME_DIM}'].astype('datetime64[ns]')"
        )
        raise ValueError(msg)

    return input


def verify_mode_dimension(input: xr.DataArray | xr.Dataset):
    if MODE_DIM not in input.dims:
        raise ValueError(f"input must have a `{MODE_DIM}` dimension")

    return input


def verify_combo_data(input: xr.Dataset):
    _ = verify_mode_dimension(input)

    if "fitter_var" not in input.dims:
        raise ValueError("input must have a `fitter_var` dimension")

    if "spectral_var" not in input.dims:
        raise ValueError("input must have a `spectral_var` dimension")

    return input


def verify_compact_data(input: xr.Dataset):
    if STATS_DIM not in input.dims:
        raise ValueError("input must have a `stat` dimension")

    if "spectral_values_stats" not in input:
        raise ValueError("input must have a `spectral_values_stats` variable")

    return input


def verify_bounds_array(input: xr.DataArray):
    if "stats" not in input.dims:
        raise ValueError("input must have a `stats` dimension")

    if "group" not in input.dims:
        raise ValueError("input must have a `group` dimension")

    if "min" not in input.coords["stats"].values:
        raise ValueError("input must have a `min` coordinate")

    if "max" not in input.coords["stats"].values:
        raise ValueError("input must have a `max` coordinate")

    return input


def verify_allan_array(input: xr.DataArray | xr.Dataset):
    try:
        _ = input["tau"]
    except KeyError:
        raise ValueError("input must have a `tau` dimension")

    try:
        _ = input["n_samples"]
    except KeyError:
        raise ValueError("input must have a `n_samples` dimension")

    return input
