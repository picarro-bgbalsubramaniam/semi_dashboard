from typing import Annotated

import xarray as xr
from pydantic import AfterValidator

from picarro_xarray.validators.timeseries import (
    verify_time_dimension,
    verify_bounds_array,
    verify_allan_array,
    verify_combo_data,
    verify_mode_dimension, verify_compact_data,
)

TimeseriesDataArray = Annotated[xr.DataArray, AfterValidator(verify_time_dimension)]
TimeseriesDataSet = Annotated[xr.Dataset, AfterValidator(verify_time_dimension)]
ComboDataSet = Annotated[
    xr.Dataset, AfterValidator(verify_time_dimension), AfterValidator(verify_combo_data)
]
SpectralDataArray = Annotated[xr.DataArray, AfterValidator(verify_mode_dimension)]
SpectralTimeseriesDataArray = Annotated[
    xr.DataArray,
    AfterValidator(verify_mode_dimension),
    AfterValidator(verify_time_dimension),
]
CompactDataSet = Annotated[
    xr.Dataset,
    AfterValidator(verify_mode_dimension),
    AfterValidator(verify_time_dimension),
    AfterValidator(verify_compact_data),
]
AllanDataSet = Annotated[xr.Dataset, AfterValidator(verify_allan_array)]
AllanDataArray = Annotated[xr.DataArray, AfterValidator(verify_allan_array)]
TimeBounds = Annotated[xr.DataArray, AfterValidator(verify_bounds_array)]
