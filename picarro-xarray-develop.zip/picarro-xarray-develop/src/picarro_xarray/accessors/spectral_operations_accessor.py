"""Xarray accessor for spectral ops"""

import xarray as xr

from picarro_xarray.compute.spectral_operations.operations import Operation
from picarro_xarray.compute.spectral_operations.spectral_operations import (
    merge_compact,
    perform_compact_operation,
)
from picarro_xarray.data_models.constants import MODE_DIM, STATS_DIM, TIME_DIM
from picarro_xarray.data_models.data_types import CompactDataSet, verify_time_dimension
from picarro_xarray.validators.timeseries import (
    verify_compact_data,
    verify_mode_dimension,
)


@xr.register_dataset_accessor("spectral_ops")
class SpectralOperationsAccessor:
    """
    Xarray accessor for spectral ops
    """

    def __init__(self, xarray_obj: xr.Dataset | xr.DataArray):
        """
        Initialize Xarray accessor for spectral operations
        with a CompactDataSet.
        If the input is not a CompactDataSet,
        a TypeError is raised, as the use of this accessor is not
        permitted.

        Args:
            xarray_obj (xr.Dataset | xr.DataArray):
                Xarray object to be used for spectral operations

        Raises:
            TypeError: If the input is not a CompactDataSet.
        """
        try:
            _ = verify_time_dimension(xarray_obj)
            _ = verify_mode_dimension(xarray_obj)
            _ = verify_compact_data(xarray_obj)
        except ValueError as e:
            raise TypeError(
                f"'compactify' accessor is implemented only for xarray "
                f"CompactDataSet with {TIME_DIM}, {MODE_DIM}, {STATS_DIM}"
                f" coordinates and `spectral_values_stats` variable"
            ) from e

        self._obj = xarray_obj

    def custom_operation(
        self,
        other: CompactDataSet | int | float,
        operation_spectra: Operation | dict[Operation, list[str]] = Operation.UNION,
        operation_timeseries: Operation | dict[Operation, list[str]] = Operation.UNION,
    ) -> CompactDataSet:
        """
        Custom operation of the current CompactDataSet and other.

        An operation can be specified for the spectral data and for the timeseries data as
        a single operation, or as a dictionary mapping operations to the spectral/fitter variables.

        When a single spectral operation is specified (say ``Operation.DIFFERENCE``), some spectral variables
        might be processed differently (for instance, ``nu`` and ``nu_prime`` undergo a ``UNION`` operation,
        while ``npoints`` undergoes a ``MINIMUM`` operation). For details regarding these default
        operations,
        see :func:`.compute.spectral_operations.operations_mapping._get_default_spectral_operation_map`.

        However, when a dictionary is specified, the operations are applied to the spectral variables
        as specified in the dictionary. For instance, if the dictionary is
        ``{Operation.DIFFERENCE: ['nu', 'nu_prime'], Operation.UNION: ['npoints']}``,
        then the ``nu`` and ``nu_prime`` variables will undergo a ``DIFFERENCE`` operation,
        while the ``npoints`` variable will undergo a ``UNION`` operation.
        The rest of the spectral variables will undergo the
        default operation (``UNION``), so it is preferable to provide a complete mapping for all the
        spectral variables in the ``operation_spectra`` dictionary.

        Similarly, for ``operation_timeseries``.

        Examples of map behavior:

        .. code-block:: python

            operation_spectra = Operation.UNION   # Union of the spectral data (except npoints, nu, nu_prime)


        .. code-block:: python

            # Difference of nu and nu_prime, union of npoints, union of the rest of the spectral variables
            operation_spectra = {Operation.DIFFERENCE: ['nu', 'nu_prime'], Operation.UNION: ['npoints']}

        Args:
            other (CompactDataSet | int | float):
                CompactDataSet, int, or float to compute the custom operation with the current CompactDataSet.

            operation_spectra (Operation | dict[Operation, list[str]]):
                Operation to perform on the spectral data.
                It can be a single operation or a dictionary mapping operations
                to the spectral variables they apply to.
                Defaults to ``Operation.UNION``.

            operation_timeseries (Operation | dict[Operation, list[str]]):
                Operation to perform on the timeseries data.
                It can be a single operation or a dictionary mapping operations
                to the spectral variables they apply to.
                Defaults to ``Operation.UNION``.

        Returns:
            CompactDataSet: Result of the custom operation.
        """
        return perform_compact_operation(
            operand_1=self._obj,
            operand_2=other,
            operation_spectra=operation_spectra,
            operation_timeseries=operation_timeseries,
        )

    def subtract(
        self,
        other: CompactDataSet | int | float,
        timeseries_operation: Operation
        | dict[Operation, list[str]] = Operation.DIFFERENCE,
    ) -> CompactDataSet:
        """
        Subtract other from the current CompactDataSet.

        Args:
            other (CompactDataSet | int | float):
                CompactDataSet, int, or float to subtract from the current CompactDataSet.

            timeseries_operation (Operation):
                Operation to perform on the timeseries data (fitter_values).
                It can be a single operation or a dictionary mapping operations
                to the spectral variables they apply to.
                Defaults to ``Operation.DIFFERENCE``.

        Returns:
            CompactDataSet: Result of the subtraction.
        """
        return perform_compact_operation(
            operand_1=self._obj,
            operand_2=other,
            operation_spectra=Operation.DIFFERENCE,
            operation_timeseries=timeseries_operation,
        )

    def add(
        self,
        other: CompactDataSet | int | float,
        timeseries_operation: Operation | dict[Operation, list[str]] = Operation.SUM,
    ) -> CompactDataSet:
        """
        Add other from the current CompactDataSet.

        Args:
            other (CompactDataSet | int | float):
                CompactDataSet, int, or float to add to the current CompactDataSet.

            timeseries_operation (Operation):
                Operation to perform on the timeseries data (fitter_values).
                It can be a single operation or a dictionary mapping operations
                to the spectral variables they apply to.
                Defaults to ``Operation.SUM``.

        Returns:
            CompactDataSet: Result of the addition.
        """
        return perform_compact_operation(
            operand_1=self._obj,
            operand_2=other,
            operation_spectra=Operation.SUM,
            operation_timeseries=timeseries_operation,
        )

    def multiply(
        self,
        other: CompactDataSet | int | float,
        timeseries_operation: Operation
        | dict[Operation, list[str]] = Operation.PRODUCT,
    ) -> CompactDataSet:
        """
        Multiply other from the current CompactDataSet.

        Args:
            other (CompactDataSet | int | float):
                CompactDataSet, int, or float to multiply to the current CompactDataSet.

            timeseries_operation (Operation):
                Operation to perform on the timeseries data (fitter_values).
                It can be a single operation or a dictionary mapping operations
                to the spectral variables they apply to.
                Defaults to ``Operation.PRODUCT``.

        Returns:
            CompactDataSet: Result of the multiplication.
        """
        return perform_compact_operation(
            operand_1=self._obj,
            operand_2=other,
            operation_spectra=Operation.PRODUCT,
            operation_timeseries=timeseries_operation,
        )

    def union(
        self,
        other: CompactDataSet | int | float,
        timeseries_operation: Operation | dict[Operation, list[str]] = Operation.UNION,
    ) -> CompactDataSet:
        """
        Union of the current CompactDataSet and other.

        Args:
            other (CompactDataSet | int | float):
                CompactDataSet, int, or float to compute the union with the current CompactDataSet.

            timeseries_operation (Operation):
                Operation to perform on the timeseries data (fitter_values).
                It can be a single operation or a dictionary mapping operations
                to the spectral variables they apply to.
                Defaults to ``Operation.UNION``.

        Returns:
            CompactDataSet: Result of the union.
        """
        return perform_compact_operation(
            operand_1=self._obj,
            operand_2=other,
            operation_spectra=Operation.UNION,
            operation_timeseries=timeseries_operation,
        )

    def intersection(
        self,
        other: CompactDataSet | int | float,
        timeseries_operation: Operation
        | dict[Operation, list[str]] = Operation.INTERSECTION,
    ) -> CompactDataSet:
        """
        Intersection of the current CompactDataSet and other.

        Args:
            other (CompactDataSet | int | float):
                CompactDataSet, int, or float to compute the intersection with the current CompactDataSet.

            timeseries_operation (Operation):
                Operation to perform on the timeseries data (fitter_values).
                It can be a single operation or a dictionary mapping operations
                to the spectral variables they apply to.
                Defaults to ``Operation.INTERSECTION``.

        Returns:
            CompactDataSet: Result of the intersection.
        """
        return perform_compact_operation(
            operand_1=self._obj,
            operand_2=other,
            operation_spectra=Operation.INTERSECTION,
            operation_timeseries=timeseries_operation,
        )

    def arithmetic_mean(
        self,
        other: CompactDataSet | int | float,
        timeseries_operation: Operation
        | dict[Operation, list[str]] = Operation.ARITHMETIC_MEAN,
    ) -> CompactDataSet:
        """
        Arithmetic mean of the current CompactDataSet and other.

        Args:
            other (CompactDataSet | int | float):
                CompactDataSet, int, or float to compute the arithmetic mean with the current CompactDataSet.

            timeseries_operation (Operation):
                Operation to perform on the timeseries data (fitter_values).
                It can be a single operation or a dictionary mapping operations
                to the spectral variables they apply to.
                Defaults to ``Operation.UNION``.

        Returns:
            CompactDataSet: Result of the arithmetic mean.
        """
        return perform_compact_operation(
            operand_1=self._obj,
            operand_2=other,
            operation_spectra=Operation.ARITHMETIC_MEAN,
            operation_timeseries=timeseries_operation,
        )

    def merge_compact(self) -> CompactDataSet:
        """
        Merge a compact dataset into a single spectrum.

        Returns:
            CompactDataSet: Merged compact dataset.
        """
        return merge_compact(self._obj)
