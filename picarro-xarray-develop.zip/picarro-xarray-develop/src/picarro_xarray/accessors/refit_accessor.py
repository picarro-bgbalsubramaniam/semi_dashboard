"""Xarray accessor for LLSQ refitting of data."""

from typing import Callable, Optional

import numpy as np
import xarray as xr
from pydantic import Field, validate_call
from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from picarro_xarray.compute.least_squares.least_squares_fitter import (
    bounded_fit_dataset,
    fit_dataset,
    ridge_fit_dataset,
)
from picarro_xarray.compute.least_squares.ridge_hyperparameter import MethodType
from picarro_xarray.data_models.constants import CID_DIM, MODE_DIM, TIME_DIM
from picarro_xarray.data_models.data_types import (
    TimeseriesDataArray,
    verify_combo_data,
    verify_time_dimension,
)


@xr.register_dataset_accessor("refit")
class RefitAccessor:
    """
    Xarray accessor to refit spectral data
    """

    def __init__(self, xarray_obj: xr.Dataset):
        """
        Initialize Xarray accessor for refit computation
        with a ComboDataset.
        If the input is not a ComboDataset,
        a TypeError is raised, as the use of this accessor is not
        permitted.

        Args:
            xarray_obj (xr.Dataset | xr.DataArray):
                Xarray object to be used.

        Raises:
            TypeError: If the input is not a ComboDataSet.
        """
        try:
            _ = verify_time_dimension(xarray_obj)
        except ValueError as e:
            raise TypeError(
                f"'refit' accessor is implemented only for xarray "
                f"DataSet or DataArray with a {TIME_DIM} coordinate"
            ) from e

        try:
            _ = verify_combo_data(xarray_obj)
        except ValueError as e:
            raise TypeError(
                "'refit' accessor is implemented only for xarray "
                "DataSet with `fitter_var`, `spectral_var`, "
                "and `mode` dimensions"
            ) from e

        self._obj = xarray_obj

    def llsq(
        self,
        lsq: LinearLeastSquares,
        positive: bool = False,
        cid_fitter_mask: Optional[TimeseriesDataArray] = None,
    ) -> xr.DataArray:
        """
        Refit the data using the given least squares fitter.


        Args:
            lsq (LinearLeastSquares): Least squares fitter to use.
            positive (bool):
                If False, the least squares algorithm is used.
                If True, the non-negative least squares algorithm is used.
                Defaults to False.
            cid_fitter_mask (TimeseriesDataArray):
                A boolean mask of dimensions ``(_datetimes x fitter_var)``
                mapping baseline terms and CIDs to be used for each datetime.
                The ``fitter_var`` coordinate values should match
                ``lsq_fitter.get_results_keys(baseline_order=1)[:-1]``.

        Returns:
            xr.DataArray:
                Refit data. (cids x _datetime)
        """
        return fit_dataset(
            dataset=self._obj,
            lsq_fitter=lsq,
            positive=positive,
            cid_fitter_mask=cid_fitter_mask,
        )

    def bounded_llsq(
        self,
        lsq: LinearLeastSquares,
        bounds: Optional[dict[int, tuple[float, float]]] = None,
    ) -> xr.DataArray:
        """
        Refit the data using the given least squares fitter and
        find a solution within the provided bounds.

        Args:
            lsq (LinearLeastSquares):
                Least squares fitter to use.
            bounds (dict[int, tuple[float, float]], optional):
                A dictionary where the keys are the cids and the values are tuples
                containing the lower and upper bounds for the cids.
                If not provided, no bounds are imposed.
                Defaults to None.

                Example, set bounds for offset and cid 222:

                    {0: (-5, np.inf), 222: (0, 100)}

        Returns:
            xr.DataArray:
                Refit data. (cids x _datetime)
        """
        return bounded_fit_dataset(
            dataset=self._obj,
            lsq_fitter=lsq,
            bounds=bounds,
        )

    @validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
    def ridge(
        self,
        lsq: LinearLeastSquares,
        method: MethodType
        | Callable[[np.ndarray, np.ndarray], float] = "cross_validate_se",
        baseline_order: int = Field(default=1, ge=0, le=2),
        mode_dim: str = MODE_DIM,
        cid_dim: str = CID_DIM,
        **kwargs,
    ) -> xr.DataArray:
        return ridge_fit_dataset(
            dataset=self._obj,
            lsq_fitter=lsq,
            method=method,
            baseline_order=baseline_order,
            mode_dim=mode_dim,
            cid_dim=cid_dim,
            **kwargs,
        )
