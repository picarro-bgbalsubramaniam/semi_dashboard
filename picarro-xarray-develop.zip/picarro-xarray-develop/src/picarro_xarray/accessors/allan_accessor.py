"""Xarray accessor for Allan variance computation"""
from typing import Optional

from picarro_xarray.data_models.constants import TIME_DIM
from picarro_xarray.data_models.data_types import verify_time_dimension
from picarro_xarray.compute.allan_deviation import (
    compute_allan_dev,
    _allan_std_err,
    _allan_var,
)
import xarray as xr


@xr.register_dataset_accessor("allan")
@xr.register_dataarray_accessor("allan")
class AllanVarXAccessor:
    """
    Xarray accessor for Allan variance computation
    """

    def __init__(self, xarray_obj: xr.Dataset | xr.DataArray):
        """
        Initialize Xarray accessor for Allan variance computation
        with a TimeSeriesDataArray or TimeSeriesDataSet.
        If the input is not a TimeSeriesDataArray or TimeSeriesDataSet,
        a TypeError is raised, as the use of this accessor is not
        permitted.

        Args:
            xarray_obj (xr.Dataset | xr.DataArray):
                Xarray object to be used for Allan variance computation.

        Raises:
            TypeError: If the input is not a TimeSeriesDataArray or TimeSeriesDataSet.
        """
        try:
            _ = verify_time_dimension(xarray_obj)
        except ValueError as e:
            raise TypeError(
                f"'allan' accessor is implemented only for xarray "
                f"DataSet or DataArray with a {TIME_DIM} coordinate"
            ) from e

        self._obj = xarray_obj

    def allan_dev(
        self,
        complete=False,
        groupby: Optional[xr.DataArray] = None,
        group_name: str = "group",
    ):
        """
        Compute Allan deviation for the input data.

        The result is lazy. To materialize it,
        call the ``load()`` or method on the returned object.

        Examples:

            .. code-block:: python

                import xarray as xr
                import picarro_xarray.accessors.allan_accessor
                ds = xr.open_dataset('some/data.nc')  # your data
                allan_ds = ds.allan.allan_dev(complete=True)
                allan_ds.load()  # materialize the result if needed

        Args:
            complete (bool, optional):
                If True, complete Allan deviation is computed.
                If False, only the first term is computed.
                Defaults to True.
            groupby (Optional[xr.DataArray], optional):
                Specific TimeseriesDataArray to be used
                for grouping data along the time dimension.
                If None, a default grouper is used. Defaults to None.

            group_name (str, optional):
                Name to be assigned to the grouping dimension. Defaults to ``group``.
        Returns:
            xr.Dataset | xr.DataArray: Allan deviation.
        """
        allan_deviation = compute_allan_dev(
            data=self._obj,
            complete=complete,
            groupby=groupby,
            group_name=group_name,
        )
        return allan_deviation

    def allan_std_err(
        self,
        complete=False,
        groupby: Optional[xr.DataArray] = None,
        group_name: str = "group",
    ):
        """
        Compute Allan standard error for the input data.

        The result is lazy. To materialize it,
        call the ``load()`` or method on the returned object.
        (See example in :func:`allan_dev` docstring.)

        Args:
            complete (bool, optional):
                If ``True``, complete Allan deviation is computed.
                If ``False``, only the first term is computed.
                Defaults to True.
            groupby (Optional[xr.DataArray], optional):
                Specific TimeseriesDataArray to be used
                for grouping data along the time dimension.
                If None, a default grouper is used. Defaults to None.

            group_name (str, optional):
                Name to be assigned to the grouping dimension. Defaults to "group".

        Returns:
            xr.Dataset | xr.DataArray: Allan standard error.
        """
        allan_deviation = self.allan_dev(
            complete=complete, groupby=groupby, group_name=group_name
        )
        return _allan_std_err(allan_deviation)

    def allan_var(
        self,
        complete=False,
        groupby: Optional[xr.DataArray] = None,
        group_name: str = "group",
    ):
        """
        Compute Allan variance for the input data.

        The result is lazy. To materialize it,
        call the `load()` or method on the returned object.
        (See example in :func:`allan_dev` docstring.)

        Args:
            complete (bool, optional):
                If True, complete Allan deviation is computed.
            groupby (Optional[xr.DataArray], optional):
                Specific TimeseriesDataArray to be used
                for grouping data along the time dimension.
                If None, a default grouper is used. Defaults to None.

            group_name (str, optional):
                Name to be assigned to the grouping dimension. Defaults to "group".

        Returns:
            xr.Dataset | xr.DataArray: Allan variance.
        """
        allan_deviation = self.allan_dev(
            complete=complete, groupby=groupby, group_name=group_name
        )
        return _allan_var(allan_deviation)
