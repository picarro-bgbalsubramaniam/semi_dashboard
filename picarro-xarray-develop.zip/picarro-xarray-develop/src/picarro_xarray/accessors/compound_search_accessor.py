from typing import Literal, Optional

import pandas as pd
import xarray as xr
from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from picarro_xarray.compute.least_squares.model_functions_utils import (
    get_static_least_squares_fitter,
)
from picarro_xarray.data_models.constants import MODE_DIM, TIME_DIM
from picarro_xarray.data_models.data_types import verify_time_dimension
from picarro_xarray.logger.logger import get_logger
from picarro_xarray.validators.timeseries import verify_mode_dimension

MSG_NOT_FITTED = (
    "Transformer not fit yet. Please fit the selector first. Example:"
    "ds.compound_search.fit(selector=selector)"
)

MSG_SET_MODEL_FUNCTIONS = (
    "Model functions not set yet. Please set model functions first "
    "using the set_model_functions method. Example: "
    "ds.compound_search.set_model_functions(model_functions=model_functions)"
)

MSG_NU_NAN = (
    "Some modes do not contain spectral data. "
    "Please remove them before running compound search. Example: "
    "ds = ds.dropna(dim='mode', how='all', subset=['spectral_values'])"
)

SPECTRUM_KEY = "partial_fit"
NU_KEY = "nu_prime"
NU_CENTER = "fitData_fitdata_params_nucenter"

LOGGER = get_logger(__name__)


@xr.register_dataset_accessor("compound_search")
class CompoundSearchAccessor:
    """
    Xarray accessor to perform compound search/hunting
    on a spectral dataset.

    Attributes are private and computed lazily.

    Important:

        * if a spectral ``mode`` does not contain spectral data
          for its ``nu_prime`` variable, ``ValueError`` is raised.
          Please remove the modes without spectral data
          before running compound search

        * the case where the spectral data (``partial_fit``)
          contains sparse NaNs shall be managed at the selector level,
          i.e., the selector shall be able to handle NaNs


    Example:

    .. code-block:: python

        # load data
        ds = xr.open_dataset("path/to/dataset.nc")

        # load model functions
        from spectral_toolkit.model_function.mongodb import get_model_functions
        mfs = get_model_functions(...)

        # set model functions in the accessor
        ds.compound_search.set_model_functions(model_functions=model_functions)

        # if you also want offset and slope columns in your X matrix
        ds.compound_search.set_model_functions(model_functions=model_functions, baseline_order=1)

        # get selector from archive
        selector = ...

        # fit the selector
        ds.compound_search.fit(selector=selector)

        # get selected features
        ds.compound_search.get_feature_names_out()

        # alternatively, the methods can be chained directly
        ds.compound_search.set_model_functions(model_functions).fit(
            selector
        ).get_feature_names_out()


    """

    def __init__(self, xarray_obj: xr.Dataset):
        try:
            _ = verify_time_dimension(xarray_obj)
            _ = verify_mode_dimension(xarray_obj)
        except ValueError as e:
            raise TypeError(
                f"'compound_search' accessor is implemented only for xarray "
                f"DataSet with {TIME_DIM}, {MODE_DIM} coordinates"
            ) from e

        self._obj = xarray_obj
        self._nu = None
        self._nu_center = None
        self._X = None
        self._Y = None
        self._selector_ = None

    @property
    def nu(self):
        """
        Extract the nu values from the dataset
        by taking the mean of ``nu_prime`` along the
        time dimension for every ``mode``.

        Returns:
            pd.Series: nu values
        """
        if self._nu is None:
            self._nu = (
                self._obj.sel(spectral_var=NU_KEY)
                .spectral_values.mean(dim=TIME_DIM)
                .to_pandas()
            )

        if self._nu.isna().any():
            raise ValueError(MSG_NU_NAN)
        return self._nu

    @property
    def nu_center(self):
        """
        Extract the nu_center mean value from the dataset

        Returns:
            float: nu_center value

        """
        if self._nu_center is None:
            self._nu_center = (
                self._obj.sel(fitter_var=NU_CENTER, drop=True)
                .fitter_values.mean(dim=TIME_DIM)
                .compute()
                .item()
            )

        return self._nu_center

    @property
    def X(self):
        """
        Model functions matrix.

        Returns:
            pd.DataFrame: X matrix (nu x cids)
        """
        if self._X is None:
            raise ValueError(MSG_SET_MODEL_FUNCTIONS)
        return self._X

    @property
    def Y(self):
        """
        Spectra matrix (or vector, if only one
        point is present along the time dimension).

        Returns:
            np.ndarray: Spectra (nu x _datetime) or spectrum (nu)
        """
        if self._Y is None:
            self._Y = self._extract_y()
        return self._Y

    @property
    def feature_names_in_(self):
        """
        Get the feature names (cids) from the model functions.

        Returns:
            list[str]: Feature names (cids)
        """
        if self._X is None:
            raise ValueError(MSG_SET_MODEL_FUNCTIONS)
        return list(self._X.columns)

    def set_model_functions(
        self,
        model_functions: dict[int | str, callable],
        baseline_order: Optional[int] = None,
    ):
        """
        Set the model functions to be used for compound search.

        Args:
            model_functions (dict[int | str, callable]):
                Dictionary of model functions, where the keys are
                the compounds (cids) and the values are the
                model functions (splines/callables).
            baseline_order (Optional[int], optional):
                Specify order of baseline columns.
                If None (default), do not add baseline columns.

        Returns:
            self
        """
        self._X = self._extract_x(
            model_functions=model_functions, baseline_order=baseline_order
        )
        return self

    def get_model_functions(
        self, cids: list[int | str], prefix: Optional[str] = "lsq_gasConcs_"
    ):
        """
        Get the model functions for the given cids.

        Args:
            cids (list[int | str]): List of cids to get the model functions for.
            prefix (Optional[str], optional):
                Prefix to add to the fitter_var column.
                Defaults to ``lsq_gasConcs_``.

        Returns:
            dict[int | str, callable]: Dictionary of model functions.
        """
        if self._X is None:
            raise ValueError(MSG_SET_MODEL_FUNCTIONS)

        # check if cids are in the columns of X or report which ones are not
        missing_cids = [cid for cid in cids if cid not in self._X.columns]

        if missing_cids:
            raise ValueError(
                f"Not all requested CIDs are in the model functions. Missing: {missing_cids}"
            )

        prefix_text = prefix if prefix else ""
        selected_X = self._X[cids]
        selected_X.index = pd.Index(self._obj.mode.values, name="mode")
        selected_X.columns = [f"{prefix_text}{col}" for col in selected_X.columns]
        selected_X.columns.name = "fitter_var"
        selected_da = selected_X.stack().to_xarray()
        selected_da.name = "spectral_values"
        return selected_da

    def generate_least_squares_fitter(
        self, cids: list[int | str], nu_tol: float | None = None
    ) -> LinearLeastSquares:
        """
        Creates a static LinearLeastSquares fitter
        for the specified compounds.

        This method generates a LinearLeastSquares object
        using the stored data for the given CIDs.
        The resulting fitter uses static model
        functions, which are lookup tables rather than splines.

        Args:
            cids (list[int | str]):
                A list of CIDs to include in the fitter.
            nu_tol (float | None):
                Tolerance for nu values when evaluating model
                functions. If None, the default tolerance is used.

        Returns:
            LinearLeastSquares:
                A static LinearLeastSquares object.
        """
        X_df = self.get_model_functions(cids=cids, prefix=None).to_pandas()
        X_df.columns = X_df.columns.astype(int)
        X_df.index = pd.Index(self.nu, name="nu")

        kwargs = {} if nu_tol is None else {"nu_tol": nu_tol}

        return get_static_least_squares_fitter(
            model_function_matrix=X_df, cids=cids, **kwargs
        )

    def _extract_x(
        self,
        model_functions: dict[int | str, callable],
        baseline_order: Optional[int] = None,
    ):
        """
        Extract the X matrix (model functions) from the dataset
        by applying the model functions to the nu values.

        Args:
            model_functions (dict[int | str, callable]):
                Dictionary of model functions, where the keys are
                the compounds (cids) and the values are the
                model functions (splines/callables).
            baseline_order (Optional[int], optional):
                Specify order of baseline columns.
                If None (default), do not add baseline columns.

        Returns:
            pd.DataFrame: X matrix (nu x cids)

        """
        X = pd.DataFrame(
            data={cid: mf(self.nu) for cid, mf in model_functions.items()},
            index=self.nu,
        )

        if baseline_order is not None:
            for order in range(baseline_order + 1):
                # adds offset (order=0) with label 0 at location 0
                X.insert(order, order, (self.nu.values - self.nu_center) ** order)

        return X

    def _extract_y(self):
        """
        Extract the Y matrix (spectra to be fitted)
        from the dataset `partial_fit` spectral variable.

        Returns:
            pd.DataFrame | pd.Series:
                Dimensions (nu x _datetime) or (nu)
        """
        y = (
            self._obj.sel(spectral_var=SPECTRUM_KEY)
            .spectral_values.transpose(MODE_DIM, TIME_DIM)
            .squeeze()
            .to_pandas()
        )
        y.index = self.nu
        return y

    def fit(self, selector, allow_multitask: bool = True, **kwargs):
        """
        Fit the selector to the X and Y matrices.

        Args:
            selector (SelectorMixin):
                Selector to be used for feature selection.
                Must be a scikit-learn selector.
            allow_multitask (bool):
                Whether to allow multi-task learning.
                If True, then the selector is fitted
                on the whole Y matrix.
                If False, then the selector is fitted
                on the average of the Y matrix along
                the time dimension.
            **kwargs (dict):
                Additional keyword arguments to be passed
                to the selector's fit method.
                NOTE: kwargs shall be data-related, not
                model-related. Model-related parameters
                must be set in the selector's constructor.

        Returns:
            self
        """
        _validate_selector(selector=selector)

        if self._X is None:
            raise ValueError(MSG_SET_MODEL_FUNCTIONS)

        if self.Y.ndim > 1 and not allow_multitask:
            msg = (
                "y is a multi-output array, but allow_multitask=False. "
                "Will proceed by averaging spectra along the time dimension. "
                "If you do not want to average, set allow_multitask=True."
            )
            LOGGER.info(msg)
            y = self.Y.mean(axis=1)  # average along time dimension
        else:
            y = self.Y

        self._selector_ = selector.fit(self.X, y, **kwargs)
        return self

    def get_feature_names_out(self):
        """
        Get the feature names (cids) from the selector,
        if the selector has been fitted.

        Returns:
            list[str]: Feature names (cids)
        """
        if self._selector_ is None:
            raise ValueError(MSG_NOT_FITTED)
        return self._selector_.get_feature_names_out()

    @property
    def feature_importances_(self):
        """
        Get the feature importances from the selector,
        if the selector has been fitted.

        Returns:
            np.ndarray: Feature importances (higher is better)
        """
        if self._selector_ is None:
            raise ValueError(MSG_NOT_FITTED)
        return self._selector_.feature_importances_

    @property
    def get_selected_features_importance_(self) -> pd.Series:
        """
        Get the selected features and their importance
        from the selector, if the selector has been fitted.
        The features are sorted by importance (higher is better).

        Returns:
            pd.Series: Selected features and their importance (higher is better)
        """
        importance = pd.Series(
            self.feature_importances_,
            index=self._selector_.feature_names_in_,
            name="importance",
        )
        return importance[self._selector_.get_support()].sort_values(ascending=False)

    @property
    def threshold_(self) -> float:
        """
        Get the threshold from the selector,
        if the selector has been fitted.

        Returns:
            float: Threshold
        """
        if self._selector_ is None:
            raise ValueError(MSG_NOT_FITTED)
        return self._selector_.threshold_

    def get_regression_summary(
        self,
        multioutput_coefs: Literal[
            "raw_values", "uniform_average", "median"
        ] = "raw_values",
        multioutput_scores: Literal[
            "raw_values", "uniform_average", "median"
        ] = "median",
    ) -> tuple[pd.DataFrame | pd.Series, pd.DataFrame | pd.Series]:
        """
        Get the regression summary from the selector,
        if the selector has been fitted.

        Args:
            multioutput_coefs (Literal["raw_values", "uniform_average", "median"], optional):
                Method to aggregate coefficients if Y is multi-output. Defaults to "raw_values".
            multioutput_scores (Literal["raw_values", "uniform_average", "median"], optional):
                Method to aggregate scores if Y is multi-output. Defaults to "median".

        Returns:
            tuple [pd.DataFrame | pd.Series, pd.DataFrame | pd.Series]:
                coefficients, metrics
        """
        try:
            from spectral_toolkit.compound_search.scorers.regression_summary import (
                regression_summary,
            )
        except ImportError as e:
            raise ImportError(
                "Please install 'spectral-toolkit>=0.1.27' to use 'get_regression_summary'"
            ) from e

        if self._selector_ is None:
            raise ValueError(MSG_NOT_FITTED)

        return regression_summary(
            X=self._selector_.transform(self.X),
            Y=self.Y,
            multioutput_coefs=multioutput_coefs,
            multioutput_scores=multioutput_scores,
        )


def _validate_selector(selector):
    """
    Validate that the selector is a scikit-learn selector.

    Args:
        selector (SelectorMixin):
            Selector to be used for feature selection.
            Must be a scikit-learn selector.
    """
    check_attributes = [
        "get_feature_names_out",
        "get_support",
        "fit",
    ]

    if not all(hasattr(selector, attr) for attr in check_attributes):
        raise TypeError("Selector must be a scikit-learn selector.")
