"""Xarray accessor for zero reference computation"""
from os import PathLike
from typing import Optional

from picarro_xarray.compute.zero_reference import get_zero_referenced_data
from picarro_xarray.data_models.constants import TIME_DIM, NU_VARS, NPOINTS
from picarro_xarray.data_models.data_types import (
    verify_time_dimension,
    TimeseriesDataArray,
)
import xarray as xr

from picarro_xarray.io.combolog.combo_log_prescan import DEFAULT_NU_CENTER_KEYS


@xr.register_dataset_accessor("zero_reference")
@xr.register_dataarray_accessor("zero_reference")
class ZeroReferenceAccessor:
    """
    Xarray accessor for zero reference computation
    """

    def __init__(self, xarray_obj: xr.Dataset | xr.DataArray):
        """
        Initialize Xarray accessor for zero reference computation
        with a TimeSeriesDataArray or TimeSeriesDataSet.
        If the input is not a TimeSeriesDataArray or TimeSeriesDataSet,
        a TypeError is raised, as the use of this accessor is not
        permitted.

        Args:
            xarray_obj (xr.Dataset | xr.DataArray):
                Xarray object to be used for zero reference computation.

        Raises:
            TypeError: If the input is not a TimeSeriesDataArray or TimeSeriesDataSet.
        """
        try:
            _ = verify_time_dimension(xarray_obj)
        except ValueError as e:
            raise TypeError(
                f"'zero_reference' accessor is implemented only for xarray "
                f"DataSet or DataArray with a {TIME_DIM} coordinate"
            ) from e

        self._obj = xarray_obj

    def zero_reference(
        self,
        transition_variable: str | TimeseriesDataArray,
        reference_value: str | float | int,
        event_window_width: int = 2,
        time_dim: str = TIME_DIM,
        passthrough_spectral_vars: list[str] = NU_VARS + NPOINTS,
        passthrough_fitter_vars: list[str] = DEFAULT_NU_CENTER_KEYS,
        temp_storage: Optional[str | PathLike] = None,
    ):
        """
        Compute zero reference for the input data.

        The result is lazy. To materialize it,
        call the ``load()`` or method on the returned object.

        Examples:

        .. code-block:: python

            import xarray as xr
            import picarro_xarray.accessors.zero_reference_accessor
            ds = xr.open_dataset('some/data.nc')  # your data
            zero_ref_ds = ds.zero_reference.zero_reference("ValveMask", 1)
            zero_ref_ds.load()  # materialize the result if needed

        Args:
            transition_variable (str):
                The variable name that represents transitions in the data.
                For example, `ValveMask`.
            reference_value (str | float | int):
                The value of the transition variable that
                represents the reference state.
            event_window_width (int, optional):
                The width of the event window.
                Defaults to 2.
            passthrough_spectral_vars (list[str], optional):
                The list of spectral variables to pass through without
                zero-referencing. Defaults to ``NU_VARS``.
            passthrough_fitter_vars (list[str], optional):
                The list of fitter variables to pass through without
                zero-referencing. Defaults to ``DEFAULT_NU_CENTER_KEYS``.
            temp_storage (str | None, optional):
                The temporary storage path to cache the data.
                Defaults to None (streaming operation).

        Returns:
            xr.Dataset | xr.DataArray: Zero referenced data.
        """
        zero_referenced_data = get_zero_referenced_data(
            data=self._obj,
            transition_variable=transition_variable,
            reference_value=reference_value,
            event_window_width=event_window_width,
            time_dim=time_dim,
            passthrough_spectral_vars=passthrough_spectral_vars,
            passthrough_fitter_vars=passthrough_fitter_vars,
            temp_storage=temp_storage
        )
        return zero_referenced_data
