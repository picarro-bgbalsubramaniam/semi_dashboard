"""Xarray accessor to perform the compactify operation"""
from picarro_xarray.compute.compactify import compactify
from picarro_xarray.data_models.constants import TIME_DIM, MODE_DIM
from picarro_xarray.data_models.data_types import verify_time_dimension, TimeseriesDataArray
import xarray as xr

from picarro_xarray.validators.timeseries import verify_mode_dimension


@xr.register_dataset_accessor("compactify")
class CompactifyAccessor:
    """
    Xarray accessor to perform the compactify operation.

    Example:

        .. code-block:: python

            import xarray as xr
            import picarro_xarray.accessors.compactify_accessor
            ds = xr.open_dataset('some/data.nc')  # your data
            compact_ds = ds.compactify.compact(groupby="ValveMask")

    """

    def __init__(self, xarray_obj: xr.Dataset | xr.DataArray):
        """
        Initialize Xarray accessor for compactification
        with a ComboDataset.
        If the input is not a ComboDataset,
        a TypeError is raised, as the use of this accessor is not
        permitted.

        Args:
            xarray_obj (xr.Dataset | xr.DataArray):
                Xarray object to be used for Allan variance computation.

        Raises:
            TypeError: If the input is not a ComboDataset.
        """
        try:
            _ = verify_time_dimension(xarray_obj)
            _ = verify_mode_dimension(xarray_obj)
        except ValueError as e:
            raise TypeError(
                f"'compactify' accessor is implemented only for xarray "
                f"ComboDataset with {TIME_DIM}, {MODE_DIM}"
                f"coordinates"
            ) from e

        self._obj = xarray_obj

    def compact(
        self,
        groupby: str | TimeseriesDataArray | None = None,
        consecutive: bool = True,
        group_name: str = "group",
    ):
        """
        Compactify a ComboDataset grouping along the time dimension.
        For more details, see :func:`.compute.compactify.compactify`.

        Args:
            groupby (str | TimeseriesDataArray):
                Grouping variable. If str, it must be a variable name
                in the `fitter_var` of ComboDataset.
                If TimeseriesDataArray, it must be a 1D array with
                the same length as the time dimension of the ComboDataset.
            consecutive (bool, optional):
                If True, consecutive groups are compactified.
                If False, all groups are compactified together regardless
                of when they occur.
            group_name (str, optional):
                Name of the groupby variable in the compactified dataset.

        Returns:
            xr.Dataset: Compact Dataset.
        """
        return compactify(
            data=self._obj,
            groupby=groupby,
            consecutive=consecutive,
            group_name=group_name,
        )


