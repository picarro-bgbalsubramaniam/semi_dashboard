from datetime import MINYEAR, datetime
from datetime import datetime as dt
from os import PathLike
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import pytz
import xarray as xr
from pydantic import validate_call

from picarro_xarray.data_models.constants import TIME_DIM
from picarro_xarray.data_models.data_types import TimeseriesDataArray, TimeseriesDataSet
from picarro_xarray.io.utils.api_utils import DATE_FORMAT

ORIGIN = pytz.utc.localize(datetime(MINYEAR, 1, 1, 0, 0, 0, 0))


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _convert_h5_timestamp(timestamp: np.ndarray) -> pd.DatetimeIndex:
    # The timestamp field is milliseconds from 01-01-01 00:00:00
    original_time = np.array(timestamp).astype("timedelta64[ms]")
    original_time = original_time + np.datetime64(ORIGIN.replace(tzinfo=None))

    # Re-align naive datetime (UTC-based)
    datetime_utc_naive = pd.to_datetime(original_time, utc=True).tz_localize(None)
    datetime_utc_naive = datetime_utc_naive.as_unit("ns")
    return datetime_utc_naive


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def convert_timezone(
    ds: xr.Dataset | xr.DataArray, new_timezone: str
) -> xr.Dataset | xr.DataArray:
    """
    Convert ds in dataset to different/local timezone

    Arguments:
        ds (xr.Dataset or xr.DataArray):
            xarray dataset or dataarray
            Must have dimension `_datetime` and attribute `tz`
        new_timezone (str): new pytz timezone str

    Returns:
        xr.DataSet with new tz attribute and shifted times
    """
    if new_timezone not in pytz.all_timezones:
        raise ValueError(f"{new_timezone} is not a valid timezone")

    if "_datetime" not in ds.dims:
        raise ValueError("ds must have dimension `_datetime`")

    if "tz" not in ds.attrs:
        raise ValueError("ds must have attribute `tz`")

    new_datetime = (
        ds["_datetime"]
        .to_index()
        .tz_localize(ds.attrs["tz"])
        .tz_convert(pytz.timezone(new_timezone))
        .tz_localize(None)
    )

    ds["_datetime"] = new_datetime
    ds.attrs["tz"] = new_timezone
    ds.attrs["Start"] = f"{new_datetime[0].tz_localize(None):{DATE_FORMAT}}"
    ds.attrs["Stop"] = f"{new_datetime[-1].tz_localize(None):{DATE_FORMAT}}"

    return ds


@validate_call(validate_return=True)
def get_start_end_time(
    path_to_zarr: str | PathLike,
    time_zone: Optional[str] = None,
    return_format: str = "%Y-%m-%d %H:%M:%S",
) -> tuple[str, str]:
    """
    Get the possible start and stop times for a pool path in a given time zone

    Arguments:
        path_to_zarr (str): full path to zarr store
        time_zone Optional(str): pytz timezone to get start and end time in, if no
                                 timezone then will just return start and stop

    Returns:
        Tuple(str, str): start and stop string representations
    """
    if time_zone is not None and time_zone not in pytz.all_timezones:
        raise ValueError(
            f"Provided Time Zone ({time_zone}) for start/stop times not a valid timezone"
        )

    if not Path(path_to_zarr).exists():
        raise ValueError(f"zarr store {path_to_zarr} does not exist")

    ds = xr.open_zarr(path_to_zarr)
    tz = pytz.timezone(ds.attrs["tz"])

    if time_zone is None:
        start = dt.strptime(ds.attrs["Start"], "%Y-%m-%d %H:%M:%S").strftime(
            return_format
        )
        stop = dt.strptime(ds.attrs["Stop"], "%Y-%m-%d %H:%M:%S").strftime(
            return_format
        )
    else:
        # Localize to existing timezone and shift to requested time zone
        start = tz.localize(dt.strptime(ds.attrs["Start"], "%Y-%m-%d %H:%M:%S"))
        start = start.astimezone(tz=pytz.timezone(time_zone)).strftime(return_format)
        stop = tz.localize(dt.strptime(ds.attrs["Stop"], "%Y-%m-%d %H:%M:%S"))
        stop = stop.astimezone(tz=pytz.timezone(time_zone)).strftime(return_format)

    ds.close()

    return start, stop


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_median_time_delta_seconds(
    data: TimeseriesDataArray | TimeseriesDataSet,
    groupby: Optional[TimeseriesDataArray] = None,
    group_name: str = "group",
    time_dim: str = TIME_DIM,
) -> xr.DataArray:
    """
    Calculate the median time difference between consecutive data points in seconds,
    grouped by an optional grouping parameter.

    This function takes a dataset or data array and computes the median time delta
    between successive measurements. These time deltas are then grouped, if a grouping
    parameter is provided, and the median of these groups is calculated. The time
    deltas are computed in seconds.

    Args:
        data (Union[TimeseriesDataArray, TimeseriesDataSet]): The input timeseries data,
            which must include a time dimension.
        groupby (Optional[TimeseriesDataArray], optional):
            An optional data array used
            for grouping the input data when calculating the median time delta.
            If not provided, the calculation is performed on the entire dataset
            without splitting into groups. Defaults to None.
        group_name (str, optional):
           The name to assign to the group dimension.
        time_dim (str, optional):
            The name of the time dimension in 'data'. This
            function assumes that time differences should be calculated along this
            dimension. Defaults to ``TIME_DIM``.

    Returns:
        xr.DataArray:
            A DataArray containing the median time delta in seconds for each group
            specified by 'groupby'

    Note:
        The function drops the first time point in the 'diff' operation.
        Therefore, the first group will have one fewer point than the rest.
    """
    grouper = _parse_grouper(
        data=data, grouper=groupby, group_name=group_name, time_dim=time_dim
    )

    time_diffs = data[time_dim].to_pandas().diff().iloc[1:]

    median_deltat = time_diffs.groupby(grouper.values[1:]).median()

    delta_seconds = median_deltat / np.timedelta64(1, "s")

    delta_seconds.name = "_datetime"
    delta_seconds.index.name = grouper.name

    return delta_seconds.to_xarray()


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _parse_grouper(
    data: TimeseriesDataArray | TimeseriesDataSet,
    grouper: str | TimeseriesDataArray | None = None,
    group_name: str = "group",
    time_dim: str = TIME_DIM,
) -> TimeseriesDataArray:
    """
    Parse the groupby argument and return a grouper TimeseriesDataArray.
    If no grouper is provided, a default grouper is created with the
    same grouping for all time points.

    Args:
        data (Union[TimeseriesDataArray, TimeseriesDataSet]):
            The input timeseries data, which must include a time dimension.
        grouper (Optional[TimeseriesDataArray], optional):
            Specific TimeseriesDataArray to be used
            for grouping data along the time dimension.
            If None, a default grouper is used. Defaults to None.
        group_name (str, optional):
           Name to be assigned to the grouping dimension. Defaults to "group".
        time_dim (str, optional):
            Name of the time dimension along which to group data. Defaults to ``TIME_DIM``.

    Returns:
        TimeseriesDataArray:
           The grouper TimeseriesDataArray for groupby operations.
    """
    if grouper is None:
        grouper_return = xr.DataArray(
            np.ones(data.sizes[time_dim]),
            dims=time_dim,
            coords={time_dim: data[time_dim].values},
        )
    elif isinstance(grouper, str):
        if grouper not in data.fitter_var:
            raise ValueError(f"Grouping variable {grouper} not found in fitter_var")

        grouper_return = data.sel(fitter_var=grouper, drop=True)
        grouper_return = (
            grouper_return.fitter_values
            if isinstance(data, xr.Dataset)
            else grouper_return
        )
    else:
        grouper_return = grouper.copy(deep=True)

    if grouper_return.sizes[time_dim] != data.sizes[time_dim]:
        raise ValueError(
            f"Grouping dimension {time_dim} must have the same size "
            f"as the time dimension of the input data. Expected "
            f"{data.sizes[time_dim]}, got {grouper_return.sizes[time_dim]}"
        )

    if len(grouper_return.dims) > 1:
        msg = (
            f"Grouping variable must be 1D, with `_datetime` as the only dimension. "
            f"Got {len(grouper_return.dims)} dimensions. "
            f"Remember to select your grouper variable with the `sel` clause and `drop=True`. "
            f"Example: `ds.sel(fitter_var='ValveMask', drop=True).fitter_values`. "
        )
        raise ValueError(msg)

    grouper_return.name = group_name
    return grouper_return.compute()
