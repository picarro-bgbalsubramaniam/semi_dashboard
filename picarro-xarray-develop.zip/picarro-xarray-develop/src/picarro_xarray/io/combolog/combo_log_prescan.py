from enum import Enum
from os import PathLike
from pathlib import Path
from typing import Literal, NamedTuple

import dask.array as da
import dask.bag as db
import h5py
import numpy as np
import pandas as pd
import pytz
import xarray as xr
from dask.diagnostics import ProgressBar
from pydantic import validate_call
from spectral_arithmetic.nu_operations import calc_fsr, create_mode_index, nu_transform

from picarro_xarray.io.data_models.h5_structures import NuTransformInfo
from picarro_xarray.io.data_models.prescan_data_structures import ComboLogInfo
from picarro_xarray.io.utils.dataset_attributes_setting import set_time_attributes
from picarro_xarray.logger.logger import get_logger

LOGGER = get_logger(__name__)

DEFAULT_NU_CENTER_KEYS = [
    "fitData_fitdata_params_nucenter",
    "fitData_nu_transform_nnuc",
]
DEFAULT_NU_SHIFT_KEYS = ["fitData_nu_transform_n0"]
DEFAULT_NU_SHIFT_VALUE = 0.0
DEFAULT_NU_SQUISH_KEYS = ["fitData_nu_transform_n1"]
DEFAULT_NU_SQUISH_VALUE = 0.0
DEFAULT_F0_KEYS = ["f0"]
DEFAULT_NU_CENTER_VALUE = 6056.504
DEFAULT_F0_VALUE = 6056.5068
SUCCESS_MESSAGE = "OK"
FAIL_MESSAGE = "Failed to process H5 file. Corrupted?"


class ScanKey(Enum):
    """Enumeration of keys used to scan a combo log file."""

    SPECTRAL_VARIABLES = "spectral_variables"
    MODES = "scanned_modes"
    FITTER_VARIABLES = "variables"


class ScanResult(NamedTuple):
    """Result of scanning a combo log file."""

    original_file: str | PathLike
    output_file: str | PathLike | None = None
    success: bool = False
    error_message: str | None = None


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _safe_scan_combo_log(
    filename: str | PathLike, export_folder: str | PathLike
) -> ScanResult:
    """Wrapper around _scan_combo_log that catches exceptions and returns error messages"""
    try:
        output_file = _scan_combo_log(filename, export_folder)
        return ScanResult(original_file=filename, output_file=output_file, success=True)
    except Exception as e:
        return ScanResult(
            original_file=filename,
            success=False,
            error_message=f"{FAIL_MESSAGE}. Error: {e}",
        )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def prescan_combo_logs(
    files_list: list[str | PathLike],
    tmp_dir: str | PathLike,
    on_error: Literal["raise", "ignore"] = "raise",
) -> dict[str | PathLike, str | PathLike]:
    """Scans a list of combologs for FSR, nu_prime, and modes to return a
    dict of the source h5 combologs and the temporary path to the
    prescanned h5 file.

    Args:
        files_list (list[str | PathLike]): list of h5 combolog files.
        tmp_dir (str | PathLike): path to a temporary directory to store the prescan files.
        on_error (Literal["raise", "ignore"], optional):
            What to do if an error is encountered. Defaults to "raise".

    Returns:
        dict[str | PathLike, str | PathLike]:
            A dictionary mapping original file paths to their corresponding
            prescan file paths.
    """
    files_list = [str(file) for file in files_list]

    with ProgressBar():
        results = (
            db.from_sequence(files_list)
            .map(_safe_scan_combo_log, export_folder=tmp_dir)
            .compute()
        )

    successful_results = {}
    for result in results:
        if result.success:
            successful_results[result.original_file] = result.output_file
        else:
            msg = f"Failed to process {result.original_file}: {result.error_message}"
            if on_error == "raise":
                raise ValueError(msg)
            else:
                LOGGER.warning(msg)

    if len(successful_results) < len(files_list):
        LOGGER.warning(
            f"Successfully processed {len(successful_results)} out of {len(files_list)} files"
        )

    return successful_results


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_unique_values(
    files_list: list[str | PathLike], key_: ScanKey
) -> list[str | int]:
    """
    Get unique values for a given key in a list
    of H5 files.

    Args:
        files_list (list[str | PathLike]):
            list of H5 files.
        key_ (ScanKey):
            Key to query in the H5 files.

    Returns:
        list[str | int]:
            list of unique values for the given key
            in the H5 files.
    """
    unique_vars = set()

    # Iterate through each array and add its elements to the set
    for temp_file in files_list:
        with h5py.File(temp_file, "r") as h5file:
            try:
                key_values = list(h5file[f"{key_.value}"][()])
            except KeyError as err:
                raise KeyError(f"Could not find {key_.value} in {temp_file}") from err

        unique_vars.update(key_values)

    # If elements are string, I need to decode them from bytes
    if isinstance(key_values[0], bytes):
        unique_vars = {var.decode() for var in unique_vars}

    # Convert the set back to a sorted list
    unique_list = sorted(list(unique_vars))
    return unique_list


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_nu_key(
    h5file: h5py.File, query_keys: list[str], default_value: float = np.nan
) -> np.ndarray:
    """
    The value corresponding
    to the first key of ``query_keys`` that
    is present in ``h5file`` RESULTS group is returned.
    If no key is present in RESULTS group, use a default value.
    If no default value is provided, raise an error.

    Args:
        h5file (h5py.File):
            H5 file object.
        query_keys (list[str]):
            Possible keys that identify the requested
            variable in RESULTS group, in decreasing
            priority order (that first key that is
            found is the one that will be used).
        default_value (float):
            Default value to return if no key is
            not present in the data.

    Returns:
        np.ndarray:
            Array of length #TIMESTAMP in RESULTS group.
            If the default value is used, then the default
            value is repeated #TIMESTAMP-times in the array.
    """

    time_array = h5file.get("results/timestamp", None)
    if time_array is None:
        raise KeyError(f"Group RESULTS/TIMESTAMP not present in {h5file.filename}")

    for query_key in query_keys:
        if query_key in h5file["results"].keys():
            result = h5file[f"results/{query_key}"][()]
            break
    else:
        # I did not find any of the spectral keys provided
        if not np.isnan(default_value):
            LOGGER.warning(
                f"No key in {query_keys} found in {h5file.filename} RESULTS group:"
                f" using default value {default_value}"
            )
            result = np.full_like(time_array, fill_value=default_value)
        else:
            raise KeyError(
                f"No spectral keys in {query_keys} "
                f"present in {h5file.filename} RESULTS group."
                f" No default value was provided"
            )
    return result


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_nu_data(h5file: h5py.File) -> NuTransformInfo:
    """
    Get the spectral info
    needed to perform nu_transform
    for mode binning.

    The values needed are:
    f0, nu_center, nu_squish, nu_shift.
    They are read from an H5 file
    (RESULTS group).

    Args:
        h5file (h5py.File):
            H5 file object.

    Returns:
        NuTransformInfo:
            Spectral info for
            ``nu_transform`` for the
            file.
    """
    f0_value = _get_nu_key(
        h5file=h5file, query_keys=DEFAULT_F0_KEYS, default_value=DEFAULT_F0_VALUE
    )
    nu_center = _get_nu_key(
        h5file=h5file,
        query_keys=DEFAULT_NU_CENTER_KEYS,
        default_value=DEFAULT_NU_CENTER_VALUE,
    )
    nu_squish = _get_nu_key(
        h5file=h5file,
        query_keys=DEFAULT_NU_SQUISH_KEYS,
        default_value=DEFAULT_NU_SQUISH_VALUE,
    )
    nu_shift = _get_nu_key(
        h5file=h5file,
        query_keys=DEFAULT_NU_SHIFT_KEYS,
        default_value=DEFAULT_NU_SHIFT_VALUE,
    )

    spectral_info = NuTransformInfo(
        f0=f0_value, nu_center=nu_center, nu_squish=nu_squish, nu_shift=nu_shift
    )
    return spectral_info


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _scan_combo_log(
    filename: str | PathLike, export_folder: str | PathLike
) -> str | PathLike:
    """
    Scan a combo log file and write the
    results to an H5 file.

    Results include nu_prime, FSR, and modes.

    Args:
        filename (str | PathLike):
            Path to the combo log file.
        export_folder (str | PathLike):
            Path to the folder where a temporary
            H5 file containing the prescan
            info will be written.

    Returns:
        str | PathLike:
            Path to the temporary H5 file
            containing the prescan info.
    """
    with h5py.File(str(filename), "r") as h5file:
        try:
            timestamp = np.array(h5file["results/timestamp"]).astype(int)
        except KeyError as err:
            raise KeyError(f"Could not find RESULTS/TIMESTAMP in {filename}") from err

        fitter_vars = []
        for fitter_var in h5file["results"].keys():
            if h5file["results"][fitter_var].dtype.kind in ["i", "u", "f"]:
                fitter_vars.append(fitter_var)
            else:
                LOGGER.warning(f"Variable {fitter_var} is not numeric, skipping")

        # all the spectral variables
        spectral_vars = list(
            {
                spectral_key
                for spectrum in h5file["spectra"].values()
                for spectral_key in spectrum.keys()
            }
        )

        spectra_keys = list(h5file["spectra"].keys())

        # Get spectral info to perform nu_transform operation
        spectral_info = _get_nu_data(h5file)

        fsr_list = []
        nu_prime_list = []
        modes_list = []
        modes_bin_errors_count = 0

        # For each spectrum
        for time_index, time in enumerate(h5file["spectra"].keys()):
            try:
                wavenumber_nu = h5file[f"spectra/{time}/nu"][()]
            except KeyError as err:
                raise KeyError(
                    f"Could not find NU in SPECTRA group of {h5file} at time index {time_index}"
                ) from err

            fsr = calc_fsr(wavenumber_nu)
            fsr_list.append(fsr)

            nu_prime, fsr_prime, f0_prime = nu_transform(
                wavenumber_nu,
                spectral_info.nu_squish[time_index],
                spectral_info.nu_shift[time_index],
                spectral_info.f0[time_index],
                spectral_info.nu_center[time_index],
                fsr,
            )
            nu_prime_list.append(nu_prime)

            try:
                mode_idxs = create_mode_index(nu_prime, fsr_prime, f0_prime)
            except ValueError as err:
                LOGGER.warning(
                    f"Issues with getting mode grid: {err} "
                    f"File: {h5file}, Time index: {time_index}"
                )
                modes_list.append(np.array([]))
                modes_bin_errors_count += 1
            else:
                modes_list.append(mode_idxs)

    log_info = ComboLogInfo(
        timestamp=timestamp,
        variables=fitter_vars,
        spectra_keys=spectra_keys,
        spectral_variables=spectral_vars,
        modes=modes_list,
        nu_prime=nu_prime_list,
        fsr=np.array(fsr_list),
        mode_bin_errors=modes_bin_errors_count,
    )

    export_folder = Path(export_folder)
    export_folder.mkdir(exist_ok=True, parents=True)
    export_path = export_folder / f"{Path(filename).stem}_scan.h5"

    log_info.to_h5(export_path=export_path)

    return export_path


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _allocate_combo_zarr_store(
    zarr_path: str | PathLike,
    local_time_zone: str,
    datetime: pd.DatetimeIndex,
    fitter_vars: list[str],
    spectral_vars: list[str],
    modes: np.ndarray,
    analyzer_name: str,
    fitter_logs_origin: xr.DataArray,
    chunks: dict[str, int],
) -> str:
    """
    Preallocate a virtual zarr store based
    on the pre-scan info.

    Args:
        zarr_path (str):
            Location where to create a zarr store.
            Please use a ``.zarr`` extension.
            Example: ``my_path/my_store.zarr``
        local_time_zone (str):
            Local time zone.
            Used for metadata.
            Example: ``US/Pacific``
        allocation_info (H5SpectralInfo):
            Info from H5 files pre-scan
            from :py:func:`picarro_xarray.io.combolog.combo_log_prescan._pre_scan_h5_files`
        analyzer_name (str):
            Name of the analyzer.
            Used for metadata.
            Example: ``NUV1041``
        time_chunk_size (int):
            Chunk size for Dask arrays along the time axis.

    Returns:
        str: "OK" if successful.
    """
    time_len = len(datetime)
    fitter_vars_len = len(fitter_vars)

    if "_datetime" not in fitter_logs_origin.dims:
        raise ValueError("private_logs_origin must have dimension '_datetime'")

    if fitter_logs_origin.sizes["_datetime"] != time_len:
        raise ValueError("private_logs_origin must have the same length as _datetime")

    if local_time_zone not in pytz.all_timezones:
        raise ValueError(
            f"Time zone {local_time_zone} is not in list of pytz timezones"
        )

    LOGGER.info(f"Pre-allocating virtual zarr store at {zarr_path}")

    spectra_vars_len = len(spectral_vars)

    modes_len = len(modes)

    # Dummy lazy dask array
    dummies_spectra = da.zeros(
        (time_len, spectra_vars_len, modes_len),
        chunks=[chunks.get(k, -1) for k in ["_datetime", "spectral_var", "mode"]],
    )
    dummies_fitter = da.zeros(
        (time_len, fitter_vars_len),
        chunks=[chunks.get(k, -1) for k in ["_datetime", "fitter_var"]],
    )

    ds_dummy = xr.Dataset(
        {
            "spectral_values": (("_datetime", "spectral_var", "mode"), dummies_spectra),
            "fitter_values": (("_datetime", "fitter_var"), dummies_fitter),
            "fitter_origin_file": fitter_logs_origin,
        }
    )
    ds_dummy = ds_dummy.assign_coords(
        {
            "_datetime": datetime,
            "spectral_var": spectral_vars,
            "fitter_var": fitter_vars,
            "mode": modes,
        }
    )

    ds_dummy.attrs["tz"] = local_time_zone
    ds_dummy.attrs["analyzer"] = analyzer_name
    ds_dummy = set_time_attributes(ds_dummy)

    ds_dummy.to_zarr(
        store=zarr_path, mode="w", compute=False
    )  # It is a delayed operation
    LOGGER.info(f"Virtual pre-allocation successful \n {ds_dummy}")
    return "OK"
