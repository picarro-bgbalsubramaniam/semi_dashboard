"""Read SPECTRA group from H5 combo logs files"""

import os
import shutil
from os import PathLike
from pathlib import Path
from typing import Literal, Optional

import h5py
import numpy as np
import pandas as pd
import pytz
import xarray as xr
from dask.distributed import Client, LocalCluster, Lock, progress, wait
from pydantic import validate_call
from tqdm import tqdm

from picarro_xarray.io.combolog.combo_log_prescan import (
    ScanKey,
    _allocate_combo_zarr_store,
    _get_unique_values,
    prescan_combo_logs,
)
from picarro_xarray.io.data_models.h5_structures import DEFAULT_CHUNKS
from picarro_xarray.io.data_models.prescan_data_structures import (
    ComboLogInfo,
    PrivateLogInfo,
)
from picarro_xarray.io.merging.merge_datasets import concat_zarr_stores
from picarro_xarray.io.utils.api_utils import (
    FileTypeEnum,
    check_for_overlapping_files,
    get_analyzer_name,
    get_h5_combolog_paths,
)
from picarro_xarray.io.utils.prescan_utils import (
    _get_file_origin,
    _get_time_regions,
    _verify_intervals_distinct,
)
from picarro_xarray.logger.logger import get_logger

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def read_combo_logs(
    folder_path: str | PathLike,
    local_time_zone: str,
    path_to_zarr: str | PathLike,
    analyzer_name: Optional[str] = None,
    fitter_name: str = "broadband",
    chunks: dict[str, int] = DEFAULT_CHUNKS,
    allowed_spectral_vars: Optional[list[str]] = None,
    on_error: Literal["raise", "ignore"] = "raise",
) -> Path:
    """
    Read combologs data (both spectra and timeseries data)
    from H5 combo logs files to a zarr store.

    Args:
        folder_path (str | PathLike):
            Path where H5 files are located.
            The search is recursive.
        local_time_zone (str):
            Local time zone.
            Example `US/Pacific`.
        path_to_zarr (str | PathLike):
            Location (folder) of the exported zarr store.
            The zarr store path is going to be:
            ``path_to_zarr/analyzer_name.zarr``.
        analyzer_name (str):
            Name of the analyzer. Example "NUV1044".
            Used in the name of the zarr store.
        fitter_name (str):
             Requested fitter data.
             Example: ``""broadband""``.
        chunks (dict[str, int]):
            Chunk size for Dask arrays.
            Key is the dimension name and value is the chunk size.
            If a dimension is not present in the dictionary, no chunking
            will be applied to that dimension (i.e., chunk size of -1)
            See https://docs.dask.org/en/stable/array-best-practices.html#select-a-good-chunk-size
            Example: ``{"_datetime": 1000}``.
            Defaults to DEFAULT_CHUNKS.
        allowed_spectral_vars (list[str], optional | None):
            List of spectral variables to be included in the zarr store.
            If not provided, all spectral variables found in the files will be included.
            Example, ``["npoints", "partial_fit"]``.
            Note that ``nu_prime`` is a calculated spectral variable (originally not present
            in the H5 files) and will always be included.
        on_error (Literal["raise", "ignore"]):
            What to do if an error occurs while reading the H5 files.
            If "raise", the error will be raised.
            If "ignore", the error will be ignored and the file will be skipped.
            Defaults to "raise".

    Returns:
        Path: Path of the zarr store
    """
    if local_time_zone not in pytz.all_timezones:
        raise ValueError("Time zone not in list of pytz timezones")

    folder_path = Path(folder_path)

    # Location for caching files scan data (deleted after pooling)
    cache_path = folder_path / "_tmp_"
    shutil.rmtree(cache_path, ignore_errors=True)

    files_list = get_h5_combolog_paths(folder_path=folder_path, fitter_name=fitter_name)

    if analyzer_name is None:
        analyzer_name = get_analyzer_name(files_list[0])

    # Location for a temporary zarr store where the data will be pooled
    new_data_path = Path(path_to_zarr) / f"new_{analyzer_name}_combologs.zarr"

    zarr_store_path = Path(path_to_zarr) / f"{analyzer_name}_combologs.zarr"
    initial_len = len(files_list)
    files_list = check_for_overlapping_files(
        files_list, zarr_store_path, FileTypeEnum.combologs
    )
    if not files_list:
        LOGGER.info(
            "No unique files found in combo log file list. "
            "Returning existing zarr store path."
        )
        return zarr_store_path
    else:
        LOGGER.info(
            f"Found {initial_len - len(files_list)} overlapping files, "
            f"pooling {len(files_list)} files"
        )

    LOGGER.info("Pre-scan files")
    scan_info = prescan_combo_logs(
        files_list=files_list,
        tmp_dir=cache_path,
        on_error=on_error,
    )

    LOGGER.info("Gathering time axis information")
    time_info = {
        original_filename: PrivateLogInfo.import_from_h5(import_path=scan_filename)
        for original_filename, scan_filename in scan_info.items()
    }

    LOGGER.info("Sorting files based on timestamp")
    time_info_sorted = {
        original_filename: file_time_info
        for original_filename, file_time_info in sorted(
            time_info.items(), key=lambda item: item[1].start
        )
    }

    LOGGER.info("Checking for overlapping files")
    _verify_intervals_distinct(time_info_sorted)

    # sorting the file list as the time_info_sorted
    sorted_scan_info = {
        original_filename: scan_info[original_filename]
        for original_filename in time_info_sorted.keys()
    }

    LOGGER.info("Get file origin")
    file_origin = _get_file_origin(
        files_info=time_info_sorted,
        local_time_zone=local_time_zone,
        time_chunk=chunks.get("_datetime", -1),
    )

    LOGGER.info("Get time regions")
    regions = _get_time_regions(time_info_sorted)

    LOGGER.info("Get unique coordinates")
    spectral_vars = _get_unique_values(
        files_list=list(sorted_scan_info.values()), key_=ScanKey.SPECTRAL_VARIABLES
    )
    if allowed_spectral_vars:
        spectral_vars = list(set(allowed_spectral_vars).intersection(spectral_vars))

    spectral_vars.append("nu_prime")

    modes = np.array(
        _get_unique_values(
            files_list=list(sorted_scan_info.values()), key_=ScanKey.MODES
        )
    ).astype(np.int32)

    fitter_vars = _get_unique_values(
        files_list=list(sorted_scan_info.values()), key_=ScanKey.FITTER_VARIABLES
    )
    fitter_vars.append("fsr")

    _allocate_combo_zarr_store(
        zarr_path=new_data_path,
        local_time_zone=local_time_zone,
        datetime=pd.DatetimeIndex(file_origin["_datetime"].values),
        fitter_vars=fitter_vars,
        spectral_vars=spectral_vars,
        modes=modes,
        analyzer_name=analyzer_name,
        fitter_logs_origin=file_origin,
        chunks=chunks,
    )

    _write_combologs_to_zarr(
        files_info=sorted_scan_info,
        regions=regions,
        allocated_store_path=new_data_path,
    )

    file_origin.to_zarr(new_data_path, mode="r+")

    LOGGER.info("Removing temporary H5 files")
    for f in tqdm(sorted_scan_info.values()):
        shutil.rmtree(Path(f).parent, ignore_errors=True)

    if Path(zarr_store_path).exists():
        LOGGER.info(
            f"Found existing combo log store at {zarr_store_path}, appending data"
        )
        destination_store_path = (
            Path(path_to_zarr) / f"concat_{analyzer_name}_combologs.zarr"
        )
        concat_zarr_stores(
            sources=[zarr_store_path, new_data_path],
            destination=destination_store_path,
            chunk_time_size=chunks.get("_datetime", -1),
        )

        LOGGER.info(
            f"Removing temporary zarr stores: {new_data_path}, {zarr_store_path}"
        )
        shutil.rmtree(new_data_path)
        shutil.rmtree(zarr_store_path)
        LOGGER.info(
            f"Moving concat store {destination_store_path} to {zarr_store_path}"
        )
        os.rename(destination_store_path, zarr_store_path)
    else:
        LOGGER.info(f"Moving tmp store {new_data_path} to {zarr_store_path}")
        os.rename(new_data_path, zarr_store_path)

    LOGGER.info("...operation completed")
    return zarr_store_path


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _write_individual_combolog(
    h5file_path: str | PathLike,
    prescan_path: str | PathLike,
    zarr_path: str | PathLike,
    time_region: slice,
) -> str:
    """
    Write combo log file content to an
    allocated zarr store.

    Args:
        h5file_path (str):
            Path of the H5 file.
        prescan_path (str):
            Path of the prescan file
            from `.prescan_combo_logs()`.
        zarr_path (str):
            Path of the allocated zarr store.
        time_region (slice):
            Time region to write to.

    Returns:
        str: "OK" if successful.

    Raises:
        ValueError: If `nu_prime` is not in `spectra_vars_all`.
        ValueError: If `fsr` is not in `fitter_vars_all`.
        ValueError: If there is an error while reading the prescan H5 file.
        ValueError: If there is an error while reindexing the dataset to the
            coordinates present in the zarr store.
    """
    with Lock("reading_in_zarr"):
        # read existing dimensions from the allocated zarr store
        ds = xr.open_zarr(zarr_path)
        modes_all = list(ds.mode.values.astype(int))
        spectra_vars_all = list(ds.spectral_var.values.astype(str))
        fitter_vars_all = list(ds.fitter_var.values.astype(str))
        ds.close()

    if "nu_prime" not in spectra_vars_all:
        raise ValueError("nu_prime must be in spectra_vars")

    if "fsr" not in fitter_vars_all:
        raise ValueError("fsr must be in fitter_vars")

    try:
        data = _read_combolog_to_dataset(
            h5file_path=h5file_path, prescan_path=prescan_path
        )
    except (KeyError, ValueError) as err:
        raise ValueError(
            f"Error while reading {h5file_path} (prescan = {prescan_path})"
        ) from err

    before = data.sizes

    try:
        data = data.reindex(
            spectral_var=spectra_vars_all,
            fitter_var=fitter_vars_all,
            mode=modes_all,
        )
    except ValueError as err:
        raise ValueError("Error while reindexing xr.Dataset") from err

    LOGGER.debug(
        f"{Path(h5file_path).name}: before {before}, after reindex {data.sizes}"
    )

    region = {
        "_datetime": time_region,
        "spectral_var": slice(0, len(spectra_vars_all)),
        "mode": slice(0, len(modes_all)),
        "fitter_var": slice(0, len(fitter_vars_all)),
    }
    LOGGER.debug(f"Writing to region: {region}")

    with Lock("writing_in_zarr"):
        data.to_zarr(
            zarr_path,
            region=region,
            safe_chunks=True,
        )

    return "OK"


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _read_combolog_to_dataset(
    h5file_path: str | PathLike,
    prescan_path: str | PathLike,
) -> xr.Dataset:
    """
    Read combo log file content to
    a Xarray Dataset.

    Args:
        h5file_path (str):
            Path of the H5 file.
        prescan_path (str):
            Path of the prescan file
            from `.prescan_combo_logs()`.

    Returns:
        xr.Dataset: Dataset with the combo log file content.
    """
    prescan_info = ComboLogInfo.import_from_h5(import_path=prescan_path)

    with h5py.File(h5file_path, "r") as original_file:
        try:
            timestamp = np.array(original_file["results/timestamp"][()]).astype(int)
        except (KeyError, ValueError) as err:
            raise KeyError(
                f"Need TIMESTAMP in the RESULT group of H5 file ({h5file_path})"
            ) from err

        if (timestamp[0], timestamp[-1], len(timestamp)) != (
            prescan_info.start,
            prescan_info.stop,
            prescan_info.n_points,
        ):
            raise ValueError(f"Timestamp mismatch in H5 file ({h5file_path})")

        fitter_var = prescan_info.variables
        fitter_data = {
            "coords": {
                "fitter_var": {
                    "dims": "fitter_var",
                    "data": fitter_var,
                },
            },
            "dims": ["fitter_var", "_datetime"],
            "data": [original_file[f"results/{key_}"][()] for key_ in fitter_var],
            "name": "fitter_values",
        }
        fitter_da = xr.DataArray.from_dict(fitter_data).transpose(
            "_datetime", "fitter_var"
        )

        # append fsr to fitter values
        fsr_da = xr.DataArray(prescan_info.fsr, dims=["_datetime"]).expand_dims(
            {"fitter_var": ["fsr"]}
        )
        fitter_da = xr.concat([fitter_da, fsr_da], dim="fitter_var")

        spectral_variables_len = len(prescan_info.spectral_variables)
        spectral_temp = np.full(
            (
                prescan_info.n_points,
                spectral_variables_len + 1,  # +1 for nu_prime
                len(prescan_info.scanned_modes),
            ),
            np.nan,
        )

        for time_index, time in enumerate(original_file["spectra"].keys()):
            nu_prime = prescan_info.nu_prime[time_index]
            modes = prescan_info.modes[time_index]

            if modes.shape[0] == 0:
                LOGGER.warning(
                    f"Skip spectra key {time} of {Path(h5file_path).name}: mode bins not found ('nu' not on FSR grid?)"
                )
                continue

            modes_indexes = np.searchsorted(prescan_info.scanned_modes, modes).astype(
                int
            )

            for spectral_var_index, spectral_var in enumerate(
                prescan_info.spectral_variables
            ):
                try:
                    spectral_temp[time_index, spectral_var_index, modes_indexes] = (
                        original_file[f"spectra/{time}/{spectral_var}"][()]
                    )
                except KeyError as err:
                    LOGGER.warning(
                        f"Spectral variable {spectral_var} not found at spectra key {time} "
                        f"of {Path(h5file_path).name}: {err}"
                    )

            # add nu prime
            spectral_temp[time_index, spectral_variables_len, modes_indexes] = nu_prime

        ds_file = xr.Dataset(
            {
                "spectral_values": (
                    ["_datetime", "spectral_var", "mode"],
                    spectral_temp,
                ),
                "fitter_values": fitter_da,
            },
            coords={
                "fitter_var": list(fitter_da.fitter_var.values),
                "spectral_var": prescan_info.spectral_variables + ["nu_prime"],
                "mode": prescan_info.scanned_modes,
            },
        )
        return ds_file


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _write_combologs_to_zarr(
    files_info: dict[str | PathLike, str | PathLike[str, PathLike]],
    regions: dict[str, slice],
    allocated_store_path: str | PathLike,
    show_progress: bool = True,
    n_workers: Optional[int] = None,
) -> None:
    """
    Write combo log files content to
    an allocated zarr store.

    Args:
        files_info (dict[str, str]):
            Dictionary with the original and prescan
            file paths from `.prescan_combo_logs()`.
        regions (dict[str, slice]):
            Dictionary with the time regions to write
            to the zarr store for each combo log file.
        allocated_store_path (str):
            Path of the allocated zarr store.
        show_progress:
        n_workers:

    Returns:

    """
    if set(files_info.keys()) != set(regions.keys()):
        raise ValueError(
            "files_info and regions must have the same keys (original filenames)"
        )

    LOGGER.info("Reading and saving H5 combolog data to zarr store")

    with LocalCluster(
        n_workers=n_workers, processes=True, threads_per_worker=1
    ) as cluster, Client(cluster) as client:
        # Create a list of delayed objects
        futures = [
            client.submit(
                _write_individual_combolog,
                original_filename,
                prescan_filename,
                allocated_store_path,
                regions[original_filename],
            )
            for original_filename, prescan_filename in files_info.items()
        ]

        if show_progress:
            progress(futures)

        wait(futures)

    for future in futures:
        if future.status == "error":
            LOGGER.warning(future.exception())

    LOGGER.info("Combolog data was written successfully")
