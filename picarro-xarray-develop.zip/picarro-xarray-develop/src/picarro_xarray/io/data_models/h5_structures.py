import numpy as np
import pandas as pd


from pydantic import ConfigDict, BaseModel

from picarro_xarray.data_models.constants import TIME_DIM, MODE_DIM

ANALYZER_NAME_PATTERN = r"[A-Z]{2,}\d{4,}"
TIME_CHUNK_SIZE = 10000

DEFAULT_CHUNKS = {
    TIME_DIM: TIME_CHUNK_SIZE,
    MODE_DIM: 200,
    "spectral_var": 1,
    "fitter_var": 200,
}


class H5SpectralInfo(BaseModel):
    files_info: pd.DataFrame
    scanned_modes: list[int]
    spectral_variables: list[str]
    fitter_variables: list[str]
    datetime_coordinate_utc: pd.DatetimeIndex
    fsr: pd.Series
    reported_errors: int
    model_config = ConfigDict(arbitrary_types_allowed=True)


class NuTransformInfo(BaseModel):
    f0: np.ndarray
    nu_center: np.ndarray
    nu_squish: np.ndarray
    nu_shift: np.ndarray
    model_config = ConfigDict(arbitrary_types_allowed=True)
