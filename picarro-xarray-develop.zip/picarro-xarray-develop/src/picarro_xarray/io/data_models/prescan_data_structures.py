from functools import cached_property
from os import PathLike
from pathlib import Path


import h5py
import numpy as np
from pydantic import field_validator, model_validator, ConfigDict, BaseModel


class PrivateLogInfo(BaseModel):
    """
    This model represents info extracted from
    a private log file to preallocate
    a zarr store.

    Parameters:
        timestamp (np.ndarray):
            Timestamps in the private log file.
            Must be sorted in ascending order.
        variables (list[str]):
            list of variables in the private log file.

    """

    timestamp: np.ndarray
    variables: list[str]
    model_config = ConfigDict(arbitrary_types_allowed=True)

    @property
    def start(self) -> int:
        try:
            return self.timestamp[0]
        except IndexError:
            raise IndexError("No timestamp found")

    @property
    def stop(self) -> int:
        try:
            return self.timestamp[-1]
        except IndexError:
            raise IndexError("No timestamp found")

    @property
    def n_points(self) -> int:
        return len(self.timestamp)

    @field_validator("timestamp")
    def _timestamp_ascending(cls, v):
        if not np.all(np.diff(v) >= 0):
            raise ValueError("Timestamps shall be sorted in ascending order")
        return v

    @classmethod
    def import_from_h5(cls, import_path: str | PathLike) -> "PrivateLogInfo":
        with h5py.File(import_path, "r") as h5file:
            required_keys = [
                "timestamp",
                "variables",
            ]

            if not all(key in h5file for key in required_keys):
                raise ValueError(
                    f"{required_keys} are required in the H5 file {Path(import_path).name}"
                )

            # Read individual variables from the H5 file
            timestamp = h5file["timestamp"][()]
            variables = list(h5file["variables"][()].astype(str))

            my_model = cls(
                timestamp=timestamp,
                variables=variables,
            )
            return my_model


class ComboLogInfo(PrivateLogInfo):
    """
    This model represents info extracted from
    a combo log file to preallocate
    a zarr store.

    Parameters:
        spectral_variables (list[str]):
            list of spectral variables in the combo log file.
        spectra_keys (list[str]):
            list of spectra keys in the combo log file.
        modes (list[np.ndarray]):
            list of ``mode`` in the combo log file.
        nu_prime (list[np.ndarray]):
            list of ``nu_prime`` in the combo log file.
        fsr (np.ndarray):
            list of ``fsr`` in the combo log file.
        mode_bin_errors (int):
            mode binning errors while scanning combo log file
    """

    spectral_variables: list[str]
    spectra_keys: list[str]
    modes: list[np.ndarray]
    nu_prime: list[np.ndarray]
    fsr: np.ndarray
    mode_bin_errors: int
    model_config = ConfigDict(
        arbitrary_types_allowed=True, ignored_types=(cached_property,)
    )

    @cached_property
    def scanned_modes(self) -> list[int]:
        unique_values_set = set()

        # Iterate through each array and add its elements to the set
        for array in self.modes:
            unique_values_set.update(array)

        # Convert the set back to a list (if needed)
        unique_values_list = sorted(list(unique_values_set))
        return unique_values_list

    @model_validator(mode="after")
    def check_time_length_match(self):
        timestamp = self.timestamp
        modes = self.modes
        nu_prime = self.nu_prime
        fsr = self.fsr

        if len(modes) != len(timestamp):
            raise ValueError(
                f"Length of modes list {len(modes)} must "
                f"match length of timestamp {len(timestamp)}"
            )

        if len(nu_prime) != len(timestamp):
            raise ValueError(
                f"Length of nu_prime list {len(nu_prime)} must "
                f"match length of timestamp {len(timestamp)}"
            )

        if len(fsr) != len(timestamp):
            raise ValueError(
                f"Length of fsr {len(fsr)} must "
                f"match length of timestamp {len(timestamp)}"
            )
        return self

    def to_h5(self, export_path: str | PathLike) -> str | PathLike:
        with h5py.File(export_path, "w") as h5file:
            h5file["timestamp"] = self.timestamp
            h5file["variables"] = self.variables
            h5file["spectral_variables"] = self.spectral_variables

            for i_key, spectra_key in enumerate(self.spectra_keys):
                h5file[f"spectra/{spectra_key}/modes"] = self.modes[i_key]
                h5file[f"spectra/{spectra_key}/nu_prime"] = self.nu_prime[i_key]
                h5file[f"spectra/{spectra_key}/fsr"] = self.fsr[i_key]

            h5file["mode_bin_errors"] = self.mode_bin_errors
            h5file["start"] = self.start
            h5file["stop"] = self.stop
            h5file["n_points"] = self.n_points
            h5file["scanned_modes"] = self.scanned_modes
        return export_path

    @classmethod
    def import_from_h5(cls, import_path: str | PathLike) -> "ComboLogInfo":
        with h5py.File(import_path, "r") as h5file:
            # Verify that the required keys exist in the H5 file
            required_keys = [
                "timestamp",
                "variables",
                "spectral_variables",
                "mode_bin_errors",
                "start",
                "stop",
                "n_points",
                "scanned_modes",
            ]

            spectra_keys = list(h5file["spectra"].keys())
            required_keys.extend([f"spectra/{key}/modes" for key in spectra_keys])
            required_keys.extend([f"spectra/{key}/nu_prime" for key in spectra_keys])
            required_keys.extend([f"spectra/{key}/fsr" for key in spectra_keys])

            if not all(key in h5file for key in required_keys):
                raise ValueError(
                    f"{required_keys} are required in the H5 file {Path(import_path).name}"
                )

            # Read individual variables from the H5 file
            timestamp = h5file["timestamp"][()]
            variables = list(h5file["variables"][()])
            variables = [variable.decode() for variable in variables]
            spectral_variables = list(h5file["spectral_variables"][()])
            spectral_variables = [variable.decode() for variable in spectral_variables]

            # Create empty lists to store the spectra data
            modes = []
            nu_prime = []
            fsr = []

            # Loop through the spectra keys and read the data
            for spectra_key in spectra_keys:
                modes.append(
                    h5file[f"spectra/{spectra_key}/modes"][()].astype(np.int32)
                )
                nu_prime.append(h5file[f"spectra/{spectra_key}/nu_prime"][()])
                fsr.append(h5file[f"spectra/{spectra_key}/fsr"][()])

            fsr = np.array(fsr).astype(np.float64)

            # Read other variables
            mode_bin_errors = h5file["mode_bin_errors"][()].astype(int)

            my_model = cls(
                timestamp=timestamp,
                variables=variables,
                spectral_variables=spectral_variables,
                spectra_keys=spectra_keys,
                modes=modes,
                nu_prime=nu_prime,
                fsr=fsr,
                mode_bin_errors=mode_bin_errors,
            )
            return my_model
