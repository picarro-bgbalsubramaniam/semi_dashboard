from collections import namedtuple
from os import PathLike
from pathlib import Path

import numpy as np
import pandas as pd
import xarray as xr
from pydantic import PositiveInt, validate_call

from picarro_xarray.io.data_models.h5_structures import TIME_CHUNK_SIZE
from picarro_xarray.io.utils.api_utils import DATE_FORMAT, get_dataset_summary
from picarro_xarray.io.utils.dataset_attributes_setting import (
    set_files_attributes,
    set_time_attributes,
)
from picarro_xarray.logger.logger import get_logger

Bounds = namedtuple("Bounds", ["start", "stop"])

LOGGER = get_logger(__name__)
FILE_ORIGINS = ["private_logs_origin", "fitter_origin_file"]


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def merge_combo_zarr_stores(
    destination_zarr_store: str | PathLike,
    other_zarr_store: str | PathLike,
    chunk_time_size: int,
) -> str:
    """
    Merge other zarr store onto
    a destination zarr store.

    Args:
        destination_zarr_store (str):
            Path of the destination zarr store.

        other_zarr_store (str):
            Path of the source zarr store.

        chunk_time_size (int):
            Chunk size for Dask arrays along the time axis.

    Return:
        str: Path of merged zarr store

    """
    if chunk_time_size < 0:
        raise ValueError("Chunk size must be positive")

    original_ds = xr.open_zarr(destination_zarr_store)
    new_ds = xr.open_zarr(other_zarr_store)

    # Update start and end values
    new_start = min(
        pd.Timestamp(original_ds.attrs["Start"]),
        pd.Timestamp(new_ds.attrs["Start"]),
    )
    new_end = max(
        pd.Timestamp(original_ds.attrs["Stop"]),
        pd.Timestamp(new_ds.attrs["Stop"]),
    )

    # Update files
    files = (
        original_ds.fitter_origin_file.attrs["files"]
        + new_ds.fitter_origin_file.attrs["files"]
    )

    # Merge the new store in and set the new attributes
    merged_ds = xr.merge([original_ds, new_ds], compat="no_conflicts")

    merged_ds.attrs["Start"] = f"{new_start:{DATE_FORMAT}}"
    merged_ds.attrs["Stop"] = f"{new_end:{DATE_FORMAT}}"
    merged_ds.fitter_origin_file.attrs["files"] = files

    new_ds.close()
    original_ds.close()

    merged_ds = merged_ds.chunk({"_datetime": chunk_time_size, "fitter_var": -1})

    # Uncertain why this is needed, but we think it's because it's dask array
    merged_ds["fitter_origin_file"] = merged_ds["fitter_origin_file"].astype(str)
    merged_ds["fitter_var"] = merged_ds["fitter_var"].astype(str)

    try:
        merged_ds.to_zarr(destination_zarr_store, mode="w", safe_chunks=True)
        merged_ds.close()
    except (TypeError, ValueError) as e:
        LOGGER.error(f"Merging of combo logs to zarr path failed{e}")

    return destination_zarr_store


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def merge_private_zarr_stores(
    zarr_store_path: str | PathLike,
    private_ds: xr.Dataset,
    chunk_time_size: int,
) -> str | PathLike:
    """
    Merge the new private data into existing zarr store

    Args:
        zarr_store_path (str): Path to existing zarr store
        private_ds (xr.Dataset):
            Dataset of new private data.
            Must have variable `private_values`, and dimensions
            `_datetime` and `private_var`.
        chunk_time_size (int):
            Chunk size for Dask arrays along the time axis.
            Must be positive.

    Returns:
        str: Path to the private logs zarr store.


    """
    if chunk_time_size < 0:
        raise ValueError("Chunk size must be positive")

    if "private_values" not in private_ds.data_vars:
        raise ValueError("private_values variable not found in private_ds")

    if not all([dim_ in private_ds.dims for dim_ in ["_datetime", "private_var"]]):
        raise ValueError(
            "private_ds must have dimensions `_datetime` and `private_var`"
        )

    original_ds = xr.open_zarr(zarr_store_path)
    # Update start and end values
    new_start = min(
        pd.Timestamp(original_ds.attrs["Start"]),
        pd.Timestamp(private_ds.attrs["Start"]),
    )
    new_end = max(
        pd.Timestamp(original_ds.attrs["Stop"]),
        pd.Timestamp(private_ds.attrs["Stop"]),
    )

    # Update files
    files = (
        original_ds.private_logs_origin.attrs["files"]
        + private_ds.private_logs_origin.attrs["files"]
    )

    # Merge datasets
    new_ds = xr.merge([original_ds, private_ds], compat="no_conflicts")

    original_ds.close()
    private_ds.close()

    new_ds.attrs["Start"] = f"{new_start:{DATE_FORMAT}}"
    new_ds.attrs["Stop"] = f"{new_end:{DATE_FORMAT}}"
    new_ds.private_logs_origin.attrs["files"] = files

    new_ds["private_logs_origin"] = new_ds["private_logs_origin"].astype(str)
    new_ds["private_var"] = new_ds["private_var"].astype(str)
    new_ds = new_ds.chunk({"_datetime": chunk_time_size, "private_var": -1})

    try:
        new_ds.to_zarr(zarr_store_path, mode="w", safe_chunks=True)
        new_ds.close()
    except (TypeError, ValueError) as e:
        raise ValueError("Merging of private logs to zarr path failed") from e

    return zarr_store_path


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def append_private_logs_to_spectral_zarr(
    ds_private: xr.Dataset,
    zarr_store_path: str,
    chunk_time_size: int = TIME_CHUNK_SIZE,
):
    if not Path(zarr_store_path).exists():
        raise FileNotFoundError("Zarr store not found")

    if chunk_time_size < 0:
        raise ValueError("Chunk size must be positive")

    ds_spectral = xr.open_zarr(zarr_store_path)

    ds_private = ds_private.reindex_like(
        other=ds_spectral,
        fill_value=np.nan,
        tolerance=pd.Timedelta("1s"),
        method="nearest",
    )

    # Overwrite attrs
    ds_private.attrs = ds_spectral.attrs
    ds_spectral.close()

    # Chunk time axis
    ds_private = ds_private.chunk(
        {"_datetime": chunk_time_size, "private_var": ds_private.private_var.shape[0]}
    )

    # Make sure strings are saved as strings after rechunking
    ds_private["private_logs_origin"] = ds_private["private_logs_origin"].astype(str)
    ds_private["private_var"] = ds_private["private_var"].astype(str)

    LOGGER.info("Appending private data to zarr store...")
    ds_private.to_zarr(store=zarr_store_path, mode="a")
    LOGGER.info("...operation completed")


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def concat_zarr_stores(
    sources: list[str | PathLike],
    destination: str | PathLike,
    chunk_time_size: PositiveInt = TIME_CHUNK_SIZE,
):
    """
    Concatenate multiple zarr stores along the '_datetime'
    dimension into a single one.
    """
    aligned_sources = _sort_and_align_datetimes(sources)

    # update the objects list based on the non-overlapping time intervals
    objs_use = []
    for fname, time_boundaries in aligned_sources.items():
        if time_boundaries:
            tmp = xr.open_zarr(fname).sel(
                _datetime=slice(time_boundaries.start, time_boundaries.stop)
            )
            if tmp.sizes["_datetime"] > 0:
                objs_use.append(tmp)
                LOGGER.info(f" ✓ {get_dataset_summary(tmp)}")
            else:
                LOGGER.info(
                    f"No data after removing overlapping"
                    f" datetimes for dataset at {fname}. Skip."
                )
            tmp.close()

    # check attributes
    required_attrs = ["tz", "analyzer"]
    if not all(all(attr in obj.attrs for attr in required_attrs) for obj in objs_use):
        raise ValueError("Missing attributes in source zarr stores")

    if len(objs_use) < 2:
        raise ValueError("No datasets to concatenate")

    merged_ds = xr.concat(
        objs=objs_use,
        dim="_datetime",
        combine_attrs="drop",
        data_vars="all",
        coords="minimal",
        compat="equals",
    )

    # Update start and end datetimes attributes
    merged_ds = set_time_attributes(merged_ds)
    merged_ds.attrs["tz"] = objs_use[0].attrs["tz"]  # all object have same tz
    merged_ds.attrs["analyzer"] = objs_use[0].attrs["analyzer"]

    # update 'files' attributes
    for coord in FILE_ORIGINS:
        try:
            da = merged_ds[coord]
        except KeyError:
            continue

        da = set_files_attributes(da)
        merged_ds[coord] = da.astype(str)

    # chunk only _datetime dimension
    chunks = {
        dim_name: chunk_time_size if dim_name == "_datetime" else -1
        for dim_name in merged_ds.dims
    }
    merged_ds = merged_ds.chunk(chunks)

    LOGGER.info(f" ▶︎ {get_dataset_summary(merged_ds)}")
    merged_ds.to_zarr(destination, mode="w")
    merged_ds.close()


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _sort_and_align_datetimes(
    sources: list[str | PathLike],
) -> dict[str | PathLike, Bounds]:
    """
    Sources are sorted by '_datetime' ascending.
    If the time intervals of the sources overlap, the overlapping
    time intervals are removed from the sources.


    Example:
    If zarr1 and zarr2 (chronologically ordered) have
    the following time intervals:
    zarr1: [2020-01-01T00:00:00, 2020-01-01T00:05:00]
    zarr2: [2020-01-01T00:04:00, 2020-01-01T00:10:00]
    The resulting time intervals are:
    zarr1: [2020-01-01T00:00:00, 2020-01-01T00:05:00]
    zarr2: [2020-01-01T00:05:00, 2020-01-01T00:10:00]
    The overlap is always removed from the second zarr store.

    If two stores have the same start time, the first store
    in the sources list is kept and the overlap is removed
    from the second store.

    If a store has no data after removing the overlap, it is
    the interval is not returned.

    Args:
        sources (list[str | PathLike]):
            list of paths to zarr stores.
            Examples: ['/path/to/zarr1.zarr', '/path/to/zarr2.zarr']

    Returns:
        dict[str | PathLike, Tuple[np.datetime64, np.datetime64]]:
            Dictionary with the paths to the zarr stores as keys and
            the corresponding time intervals as values.
            Example::

                 {
                 '/path/to/zarr1.zarr': (np.datetime64('2020-01-01T00:00:00'),
                                        np.datetime64('2020-01-01T00:05:00')),
                 '/path/to/zarr2.zarr': (np.datetime64('2020-01-01T00:06:00'),
                                        np.datetime64('2020-01-01T00:10:00'))}

    """
    objects = {fname: xr.open_zarr(fname) for fname in sources}

    # check tz matches
    tz_reference = None
    for obj in objects.values():
        try:
            tz_current = obj.attrs["tz"]
        except KeyError:
            raise KeyError("Timezone not found in attributes")

        if tz_reference is not None and tz_current != tz_reference:
            raise ValueError(
                f"Timezones do not match. Expected {tz_reference}, found {tz_current}"
            )
        tz_reference = tz_current

    bounds = {
        fname: Bounds(obj["_datetime"].values[0], obj["_datetime"].values[-1])
        for fname, obj in objects.items()
    }

    sorted_bounds = dict(sorted(bounds.items(), key=lambda item: item[1].start))

    use_limits = {}
    previous_interval = None

    for fname, current_interval in sorted_bounds.items():
        if previous_interval and current_interval.start <= previous_interval.stop:
            # Get the first datetime after the previous interval stop
            new_start_index = np.searchsorted(
                objects[fname]["_datetime"].values, previous_interval.stop, side="right"
            )

            try:
                new_start = objects[fname]["_datetime"].values[new_start_index]
                use_limits[fname] = Bounds(new_start, current_interval.stop)
            except IndexError:
                LOGGER.warning(f"{fname} has no data after {previous_interval.stop}. ")
        else:
            use_limits[fname] = current_interval

        previous_interval = current_interval

    for obj in objects.values():
        obj.close()

    return use_limits
