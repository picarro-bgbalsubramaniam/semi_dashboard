import enum
import re
import shutil
import zipfile
from os import PathLike
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import xarray as xr
from pydantic import validate_call

from picarro_xarray.io.data_models.h5_structures import ANALYZER_NAME_PATTERN
from picarro_xarray.logger.logger import get_logger

LOGGER = get_logger(__name__)
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


class FileTypeEnum(str, enum.Enum):
    """
    All plot types that can be cached
    """

    combologs = "combologs"
    privatelogs = "privatelogs"


@validate_call(validate_return=True)
def get_analyzer_name(file: str) -> str:
    """
    Get the analyzer name via regex from a file in file list to pool

    Arguments:
        file (str):
            any file that has properly formatted naming convention
            (private or combo)

    Returns:
        str: Name of analyzer found with regex

    Raises:
        ValueError if the naming convention is different or file poorly formatted
    """
    try:
        analyzer_name = re.search(ANALYZER_NAME_PATTERN, file).group(0)
    except AttributeError as err:
        raise ValueError(
            f"Improperly formatted file name.  Unable to find analyzer name: {err}. "
            f"Please pass in a valid analyzer name"
        ) from err

    return analyzer_name


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def check_for_overlapping_files(
    files_list: list[str], path_to_zarr: str | PathLike, file_type: FileTypeEnum
) -> list[str]:
    """
    Function to check for overlapping files and return unpooled files files

    Args:
        files_list (list[str]): list of files to pool, this includes path
        path_to_zarr (str | Pathlike): full path to the zarr store to pool to
        file_type (FileTypeEnum): type of log file

    Returns:
        list(str): list of files that haven't yet been pooled in specified zarr store
    """
    path_to_zarr = Path(path_to_zarr)
    if path_to_zarr.exists():
        LOGGER.info("Found existing zarr store, checking for overlapping files")
        zarr_store = xr.open_zarr(str(path_to_zarr))
        if file_type is FileTypeEnum.combologs:
            existing_files = zarr_store.fitter_origin_file.attrs["files"]
        elif file_type is FileTypeEnum.privatelogs:
            existing_files = zarr_store.private_logs_origin.attrs["files"]
        else:
            raise NotImplementedError(f"Unsupported file type {file_type}")
        files_list = [f for f in files_list if Path(f).name not in existing_files]
        zarr_store.close()

    return files_list


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_private_logs_files_paths(
    folder_path: str | PathLike, privatelog_key: Optional[str] = None
) -> list[str]:
    """
    Get new fitter H5 files from unzipping
    zip files from a folder (to a temporary folder).
    The search is recursive.

    Args:
        folder_path (str):
            Path to inspect.

        privatelog_key (Optional[str]):
            Private log key to use in regex, usually "NewFitter".
            If None (default), it will simply check that all private log file
            have at least one alphanumeric character in the
            privatelog_key field (to avoid old fitter files).

    Returns:
        list[str]: list of files.

    Raises:
        FileNotFoundError: If no zip files are found.
        ValueError: If multiple different privatelog_key are found in the files.
    """
    # Get the regex used to filter private logs files
    filter_regex = re.compile(_get_privatelogs_regex(privatelog_key=privatelog_key))

    folder_path = Path(folder_path)
    ziplist = folder_path.rglob("*.zip")
    ziplist = [str(file) for file in ziplist if file.is_file()]

    if len(ziplist) == 0:
        raise FileNotFoundError("No zip files found in the directory.")

    # Store found prefixes to check for duplicates
    found_prefixes = set()

    LOGGER.info(f"Inspecting folder {folder_path}, found {len(ziplist)} zip files")

    flist = []
    for file in ziplist:
        with zipfile.ZipFile(file) as z:
            for h5file_name in z.namelist():
                match = filter_regex.search(h5file_name)

                if match:
                    LOGGER.debug("Reading %s private log", str(h5file_name))
                    flist.append(
                        z.extract(member=h5file_name, path=Path(folder_path) / "tmp")
                    )

                    fitter_prefix = match.group("fitter_prefix")
                    found_prefixes.add(fitter_prefix)

    found_prefixes = list(found_prefixes)
    LOGGER.info(f"Found private logs prefixes: {found_prefixes}")

    if len(found_prefixes) > 1:
        shutil.rmtree(Path(folder_path) / "tmp")

        raise ValueError(
            f"Found {len(found_prefixes)} different private logs designations "
            f"in the provided files. Found: {found_prefixes}. Please restrict "
            f"to a single designation by using the `privatelog_key` argument. "
        )

    LOGGER.info(f"Extracted {len(flist)} H5 files in {Path(folder_path) / 'tmp'}")
    return flist


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def private_xarray_to_pandas(
    ds: xr.Dataset,
    start: Optional[str] = None,
    stop: Optional[str] = None,
    columns: Optional[list[str]] = None,
) -> pd.DataFrame:
    """
    Convert private log dataset to pandas dataframe

    Arguments:
        ds: xarray dataset produced from pooling to zarr
        start (Optional[str]): beginning timestamp Format in '2022-03-10 13:17:08'
        stop (Optional[str]): ending timestamp Format in '2022-03-10 13:17:08'
        columns: list of columns we'd like to access i.e. ["ValveMask", "ACETIC_ACID_raw"]

    Returns:
        pd.DataFrame with requested data
    """

    # Check which of the columns are available
    if columns:
        keep_variables = list(set(ds.private_var.values).intersection(columns))
    else:
        keep_variables = list(ds.private_var.values)

    # Pull out time range if specified, defaults to full dataset
    ds = ds.sel(_datetime=slice(start, stop), private_var=keep_variables)

    # Create dataframe
    private_df = ds.private_values.to_pandas()

    return private_df


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _tmp_files_cleanup(tmp_folder: str | PathLike):
    tmp_folder = Path(tmp_folder)

    try:
        shutil.rmtree(tmp_folder)
    except Exception:
        LOGGER.error(f"Error while removing the directory {tmp_folder.name}")
        raise
    else:
        LOGGER.info("Temporary files removed")


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_h5_combolog_paths(folder_path: str | PathLike, fitter_name: str) -> list[str]:
    """
    Get fitter-specific H5 files from a folder.
    The search is recursive.

    Args:
        folder_path (str):
            Path to inspect.

        fitter_name (str):
             Requested fitter data.

    Returns:
        list[str]: list of files.

    """
    folder_path = Path(folder_path)
    files_list = folder_path.rglob(f"*_{fitter_name}_*.h5")
    files_list = [str(file) for file in files_list if file.is_file()]

    if len(files_list) == 0:
        raise FileNotFoundError("No H5 files found in the directory.")

    LOGGER.info(
        f"Inspecting folder {folder_path.name}, found {len(files_list)} H5 files"
    )
    return files_list


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_dataset_summary(ds: xr.Dataset) -> str:
    if "_datetime" not in ds.dims:
        raise ValueError("Dataset must have dimension `_datetime`")

    start = np.datetime_as_string(ds["_datetime"].values[0], unit="ms")
    stop = np.datetime_as_string(ds["_datetime"].values[-1], unit="ms")

    dims_info = ", ".join([f"{dim} = {size}" for dim, size in ds.sizes.items()])

    ret_str = f"start = {start}, stop = {stop}, dimensions: {dims_info}"
    return ret_str


@validate_call(validate_return=True)
def _get_privatelogs_regex(
    privatelog_key: Optional[str] = None, passthrough_key: str = r"\w+"
) -> str:
    """
    Get the regex for private logs files.

    Args:
        privatelog_key (Optional[str]):
            Private log key to use in regex, usually "NewFitter".
            If None, use passthrough_key
            (at least one alphanumeric character).

    Returns:
        str: regex.

    >>> _get_privatelogs_regex(passthrough_key= r"\w+")
    '(DataLog_)(?P<fitter_prefix>\\\\w+)(_Private)'

    >>> _get_privatelogs_regex(privatelog_key="NewFitter")
    '(DataLog_)(?P<fitter_prefix>NewFitter)(_Private)'

    """
    use_key = privatelog_key or passthrough_key
    return rf"(DataLog_)(?P<fitter_prefix>{use_key})(_Private)"


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_existing_zarr_store_path(location_path: str | PathLike) -> Path | None:
    """
    Searches for existing zarr stores in a specified location
    and handles different scenarios based on the number of stores found.

    This function checks for zarr stores in the given location and behaves as follows:

        - If exactly one zarr store is found,
          it logs the information and returns the path to the store.
        - If more than one zarr store is found, it raises a ValueError
          indicating the need to resolve the ambiguity.
        - If no zarr stores are found, it raises a FileNotFoundError.

    Args:
        location_path (str | PathLike):
            The path where zarr stores are to be searched.

    Returns:
        PathLike: The path to the found zarr store if exactly one is found.

    Raises:
        ValueError: If more than one zarr store is found at the location.
        FileNotFoundError: If no zarr stores are found at the location.
    """
    zarr_files = list(Path(location_path).glob("*.zarr"))
    zarr_count = len(zarr_files)

    if zarr_count == 1:
        zarr_path = zarr_files[0]
        LOGGER.info(
            f"Found a zarr store at {zarr_path}. "
            f"Will not re-pool data (if required, "
            f"manually delete zarr store and re-run)"
        )
        return zarr_path
    elif zarr_count > 1:
        raise ValueError(
            f"Found {zarr_count} zarr files at the specified location. "
            f"Please keep only the zarr store you want to use."
        )
    else:
        return None
