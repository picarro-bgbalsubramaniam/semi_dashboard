from os import PathLike
from pathlib import Path


import pandas as pd
import numpy as np
import xarray as xr
from pydantic import validate_call

from picarro_xarray.io.utils.api_utils import DATE_FORMAT
from picarro_xarray.logger.logger import get_logger

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def set_time_attributes(ds: xr.Dataset) -> xr.Dataset:
    """
    Set the Start and Stop attributes of the dataset based on the first and last
    datetime values of the dataset.

    >>> test_ds = xr.Dataset({"_datetime": pd.date_range(start="2021-01-01", end="2021-01-02", freq="D")})
    >>> test_ds = set_time_attributes(test_ds)
    >>> test_ds.attrs["Start"]
    '2021-01-01 00:00:00'
    >>> test_ds.attrs["Stop"]
    '2021-01-02 00:00:00'


    >>> set_time_attributes(xr.Dataset({"abc": [1, 2, 3]}))  # doctest: +ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    ValueError: Dataset must have dimension `_datetime`...

    >>> set_time_attributes(xr.Dataset({"_datetime": ["2021-01-01", "2021-01-02"]}))  # doctest: +ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    ValueError: Dataset must have dimension `_datetime` of type `np.datetime64`...


    >>> test_ds = xr.Dataset({"_datetime": pd.to_datetime(["2021-01-02", "2021-01-01"])})
    >>> test_ds = set_time_attributes(test_ds)  # doctest: +ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    ValueError: Datetime dimension must be sorted ascending...


    >>> test_ds = xr.Dataset({"_datetime": pd.date_range(start="2021-01-02", end="2021-01-01", freq="D")})
    >>> test_ds = set_time_attributes(test_ds)  # doctest: +ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    ValueError: Datetime dimension must have at least one value...


    Args:
        ds (xr.Dataset):
            Dataset to set the attributes on.

    Returns:
        xr.Dataset: Dataset with the attributes set.

    """
    if "_datetime" not in ds.dims:
        raise ValueError("Dataset must have dimension `_datetime`")

    if not pd.DatetimeIndex(ds["_datetime"].values).is_monotonic_increasing:
        raise ValueError("Datetime dimension must be sorted ascending")

    if len(ds["_datetime"]) == 0:
        raise ValueError("Datetime dimension must have at least one value")

    if not isinstance(ds["_datetime"].values[0], np.datetime64):
        raise ValueError(
            "Dataset must have dimension `_datetime` of type `np.datetime64`"
        )

    ds.attrs["Start"] = f"{pd.Timestamp(ds['_datetime'].values[0]):{DATE_FORMAT}}"
    ds.attrs["Stop"] = f"{pd.Timestamp(ds['_datetime'].values[-1]):{DATE_FORMAT}}"
    return ds


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def set_files_attributes(da: xr.DataArray) -> xr.DataArray:
    """
    Set the 'files' attribute of the DataArray based on the unique values in the DataArray.

    >>> test_da = xr.DataArray(["1", "2", "3"], dims=["_datetime"])
    >>> test_da = set_files_attributes(test_da)
    >>> set(test_da.attrs["files"]) == {"1", "2", "3"}
    True

    >>> test_da = xr.DataArray(["path/to/file1.h5", "path/to/file1.h5", "path/to/file2.h5"], dims=["_datetime"])
    >>> test_da = set_files_attributes(test_da)
    >>> set(test_da.attrs["files"]) == {"file1.h5", "file2.h5"}
    True

    >>> test_da = xr.DataArray([1, 2, 3], dims=["_datetime"])
    >>> test_da = set_files_attributes(test_da)
    >>> test_da.attrs["files"]
    []


    >>> test_da = xr.DataArray([1, 2, 3], dims=["abc"])
    >>> test_da = set_files_attributes(test_da)  # doctest: +ELLIPSIS +NORMALIZE_WHITESPACE
    Traceback (most recent call last):
    ...
    ValueError: DataArray must have dimension `_datetime`...



    Args:
        da (xr.DataArray):
            DataArray to set the 'files' attribute on.

    Returns:
        xr.DataArray: DataArray with the 'files' attribute set.

    """
    if "_datetime" not in da.dims:
        raise ValueError("DataArray must have dimension `_datetime`")

    unique_files = list(set(da.values))
    unique_files_list = [Path(file).name for file in unique_files if isinstance(file, (str, PathLike))]
    da.attrs["files"] = unique_files_list
    return da
