from pathlib import Path

import numpy as np
import pytz
import xarray as xr
from pydantic import validate_call

from picarro_xarray.io.data_models.prescan_data_structures import PrivateLogInfo
from picarro_xarray.time_utils.timeutils import _convert_h5_timestamp


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _verify_intervals_distinct(sorted_files_info: dict[str, PrivateLogInfo]):
    """
    Verify that the intervals of the private log files do not overlap.

    >>> info_ = {
    ...     '0.h5': PrivateLogInfo(timestamp=np.array([1, 2]), variables=['a']),
    ...     '1.h5': PrivateLogInfo(timestamp=np.array([3, 4]), variables=['a']),
    ...     '2.h5': PrivateLogInfo(timestamp=np.array([5, 6]), variables=['a']),
    ... }
    >>> _verify_intervals_distinct(info_)

    >>> info_ = {
    ...     '0.h5': PrivateLogInfo(timestamp=np.array([1, 2]), variables=['a']),
    ...     '1.h5': PrivateLogInfo(timestamp=np.array([2, 3]), variables=['a']),
    ...     '2.h5': PrivateLogInfo(timestamp=np.array([5, 6]), variables=['a']),
    ... }
    >>> _verify_intervals_distinct(info_)  # doctest: +NORMALIZE_WHITESPACE +ELLIPSIS
    Traceback (most recent call last):
    ...
    ValueError: Overlapping...


    Args:
        sorted_files_info (dict[str, PrivateLogInfo]):
            Dictionary of PrivateLogInfo objects, sorted by start timestamp.
            From :func:`.io.privatelog.private_log_prescan.prescan_private_logs`.

    Returns:
        None

    Raises:
        ValueError: If the intervals overlap.
    """
    previous_interval = None
    previous_fname = None

    for filename, file_info in sorted_files_info.items():
        if previous_interval is not None and file_info.start <= previous_interval.stop:
            raise ValueError(
                f"Overlapping time intervals scanned in files {previous_fname} and {filename}. "
                f"Previous interval: ({previous_interval.start}, {previous_interval.stop}). "
                f"Current interval: ({file_info.start}, {file_info.stop})."
            )

        previous_interval = file_info
        previous_fname = filename


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_file_origin(
    files_info: dict[str, PrivateLogInfo],
    local_time_zone: str = "US/Pacific",
    time_chunk: int = -1,
) -> xr.DataArray:
    """
    Get the origin file for each datetime recorded in the dataset
    starting from the pre-scan info from
    :func:`.io.privatelog.private_log_prescan.prescan_private_logs`.

    >>> info_ = {
    ...     '0.h5': PrivateLogInfo(timestamp=np.array([63825842106000]), variables=['a', 'b']),
    ...     '1.h5': PrivateLogInfo(timestamp=np.array([63825842107000]), variables=['b', 'c']),
    ...     '2.h5': PrivateLogInfo(timestamp=np.array([63825842108000]), variables=['c', 'd']),
    ... }
    >>> _get_file_origin(info_, local_time_zone="US/Pacific").compute()  # doctest: +NORMALIZE_WHITESPACE +ELLIPSIS
    <xarray.DataArray 'fitter_origin_file' (_datetime: 3)>...
    array(['0.h5', '1.h5', '2.h5'], dtype='<U4')
    Coordinates:
      * _datetime  (_datetime) datetime64[ns] ...
    Attributes:
        files:    ['0.h5', '1.h5', '2.h5']


    Args:
        files_info (dict[str, PrivateLogInfo]):
            Dictionary of PrivateLogInfo objects, sorted by start timestamp.
        local_time_zone (str):
            Local time zone in pytz format.

    Returns:
        xr.DataArray:
            DataArray containing the origin file for each datetime recorded in the dataset.
            It has an attribute "files" containing the unique files list.

    """
    if local_time_zone not in pytz.all_timezones:
        raise ValueError(
            f"Time zone {local_time_zone} is not in list of pytz timezones"
        )

    unique_files_list = [Path(file).name for file in files_info.keys()]

    timestamps = np.array([])
    files_list = []

    for k, v in files_info.items():
        filename = Path(k).name
        timestamps = np.append(timestamps, v.timestamp)
        files_list.extend([filename] * v.n_points)

    datetime = _convert_h5_timestamp(timestamps)
    datetime = datetime.tz_localize("UTC").tz_convert(local_time_zone).tz_localize(None)

    file_origin = xr.DataArray(
        files_list,
        dims="_datetime",
        coords={"_datetime": datetime},
        name="file_origin",
        attrs={"files": unique_files_list},
    )
    file_origin = file_origin.chunk({"_datetime": time_chunk}).astype(str)
    file_origin.name = "fitter_origin_file"
    return file_origin


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_time_regions(
    files_info: dict[str, PrivateLogInfo],
) -> dict[str, slice]:
    """
    Get the indexes of the time regions corresponding to each file.

    >>> info_ = {
    ...     '0.h5': PrivateLogInfo(timestamp=np.array([1, 2, 3]), variables=['a', 'b']),
    ...     '1.h5': PrivateLogInfo(timestamp=np.array([4, 5, 6]), variables=['b', 'c']),
    ...     '2.h5': PrivateLogInfo(timestamp=np.array([7, 8, 9]), variables=['c', 'd']),
    ... }
    >>> _get_time_regions(info_)
    {'0.h5': slice(0, 3, None), '1.h5': slice(3, 6, None), '2.h5': slice(6, 9, None)}

    Args:
        files_info (dict[str, PrivateLogInfo]):
            Dictionary of PrivateLogInfo objects, sorted by start timestamp.

    Returns:
        dict[str, slice]:
            Dictionary of slices, sorted by start timestamp.
            Keys are the filenames. Values are the slices.

            Examples::

                {'2020-10-01_000000.h5': slice(0, 1000, None)}

    """
    time_slices = {}
    start_time = 0
    for filename, ti in files_info.items():
        time_slices[filename] = slice(start_time, start_time + ti.n_points)
        start_time += ti.n_points

    return time_slices
