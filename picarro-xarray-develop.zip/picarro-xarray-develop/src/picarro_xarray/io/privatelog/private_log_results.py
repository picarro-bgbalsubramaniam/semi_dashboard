"""Read RESULTS group from H5 private logs files"""
import os
import shutil
from pathlib import Path

from os import PathLike
from typing import Optional

from dask.distributed import Lock, LocalCluster, Client, progress, wait

import h5py
import numpy as np
import pandas as pd
import pytz
import xarray as xr
from pydantic import validate_call

from picarro_xarray.io.data_models.h5_structures import TIME_CHUNK_SIZE
from picarro_xarray.io.data_models.prescan_data_structures import PrivateLogInfo
from picarro_xarray.io.merging.merge_datasets import merge_private_zarr_stores, concat_zarr_stores
from picarro_xarray.io.privatelog.private_log_prescan import (
    prescan_private_logs,
    _get_private_vars,
    _preallocate_private_zarr_store,
)
from picarro_xarray.io.utils.api_utils import (
    get_private_logs_files_paths,
    get_analyzer_name,
    check_for_overlapping_files,
    FileTypeEnum,
    _tmp_files_cleanup,
)
from picarro_xarray.io.utils.prescan_utils import _get_file_origin, _get_time_regions
from picarro_xarray.logger.logger import get_logger

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def read_private_logs(
    folder_path: str | PathLike,
    local_time_zone: str,
    path_to_zarr: str | PathLike,
    analyzer_name: Optional[str] = None,
    chunk_time_size: int = TIME_CHUNK_SIZE,
    privatelog_key: Optional[str] = None,
) -> Path:
    """
    Reads RESULTS group (timeseries data)
    from private logs H5 files.

    Args:
        folder_path (str):
            Folder path where the private logs
             .zip files are located.
        local_time_zone (str):
            Local time zone.
            Example `US/Pacific`.
        path_to_zarr (str):
            Location (folder) of the exported zarr store.
            The zarr store path is going to be:
            ``path_to_zarr/analyzer_name.zarr``.
        analyzer_name (str):
             Analyzer name. If None (default), it will be
            inferred from the first H5 file found at
            ``folder_path``.
        chunk_time_size (int):
            Chunk size for Dask arrays along the time axis.
            See https://docs.dask.org/en/stable/array-best-practices.html#select-a-good-chunk-size
        privatelog_key (str):
            Key to the private log designation in the H5 file, typically "NewFitter"
            If None (default), all designations will be considered.

    Returns:
        str: Path to the private logs zarr store.
    """

    if chunk_time_size < 0:
        raise ValueError("Chunk size must be positive")

    if local_time_zone not in pytz.all_timezones:
        raise ValueError("Time zone not in list of pytz timezones")

    folder_path = Path(folder_path)
    files_list = get_private_logs_files_paths(folder_path=folder_path, privatelog_key=privatelog_key)

    if analyzer_name is None:
        analyzer_name = get_analyzer_name(files_list[0])

    zarr_store_path = Path(f"{path_to_zarr}/{analyzer_name}_privatelogs.zarr")
    initial_len = len(files_list)
    files_list = check_for_overlapping_files(
        files_list, zarr_store_path, FileTypeEnum.privatelogs
    )

    if not files_list:
        LOGGER.info("No unique files found in private log file list. "
                    "Returning existing zarr store path.")
        return zarr_store_path
    else:
        LOGGER.info(
            f"Found {initial_len - len(files_list)} overlapping files, "
            f"pooling {len(files_list)} files"
        )

    new_data_path = Path(f"{path_to_zarr}/new_{analyzer_name}_privatelogs.zarr")

    LOGGER.info("Pre-scan files")
    files_info = prescan_private_logs(files_list)

    LOGGER.info("Get private variables")
    private_vars = _get_private_vars(
        files_info=files_info,
    )

    LOGGER.info("Get file origin")
    file_origin = _get_file_origin(
        files_info=files_info, local_time_zone=local_time_zone
    )

    LOGGER.info("Get time axis")
    datetime_ = pd.to_datetime(file_origin["_datetime"].values)

    _preallocate_private_zarr_store(
        zarr_path=new_data_path,
        local_time_zone=local_time_zone,
        datetime=datetime_,
        private_vars=private_vars,
        analyzer_name=analyzer_name,
        time_chunk_size=chunk_time_size,
        private_logs_origin=file_origin,
    )

    _h5s_privatelogs_to_zarr(
        files_info=files_info,
        allocated_store_path=new_data_path,
    )

    LOGGER.info(f"Removing temporary H5 files from {folder_path / 'tmp'}...")
    _tmp_files_cleanup(tmp_folder=str(folder_path / "tmp"))

    if zarr_store_path.exists():
        LOGGER.info(
            f"Found existing private log store at {zarr_store_path}, appending data"
        )
        destination_store_path = Path(path_to_zarr) / f"concat_{analyzer_name}_privatelogs.zarr"
        concat_zarr_stores(
            sources=[zarr_store_path, new_data_path],
            destination=destination_store_path,
            chunk_time_size=chunk_time_size,
        )

        LOGGER.info(f"Removing temporary zarr stores: {new_data_path}, {zarr_store_path}")
        shutil.rmtree(new_data_path)
        shutil.rmtree(zarr_store_path)
        LOGGER.info(f"Moving concat store {destination_store_path} to {zarr_store_path}")
        os.rename(destination_store_path, zarr_store_path)
    else:
        LOGGER.info(f"Moving tmp store {new_data_path} to {zarr_store_path}")
        os.rename(new_data_path, zarr_store_path)

    return zarr_store_path


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _process_h5_privatelog_file(
    filename: str | PathLike,
    zarr_path: str | PathLike,
    file_info: PrivateLogInfo,
    time_region: slice,
    private_vars: list[str],
) -> str:
    """
    Read an H5 file and writes it
    into a zarr store at a specified location.

    Args:
        filename (str):
            H5 file path to the file to be read.
        zarr_path (str):
            Zarr store path where to write.
        file_info (PrivateLogInfo):
            Info from H5 file pre-scan related to
            the current file in filename.
        time_region (slice):
            Time region to write into the zarr store.
        private_vars (list[str]):
            list of private variables to write into the zarr store.
            If they are different than the ones in the H5 file,
            their values will be filled with nans.

    Returns:
        str: "OK" if successful.

    """
    data = _read_individual_privatelog_h5(h5file_path=filename, file_info=file_info)
    data = data.reindex(private_var=private_vars)

    with Lock("writing_in_zarr"):
        data.to_zarr(
            zarr_path,
            region={
                "_datetime": time_region,
                "private_var": slice(0, len(private_vars)),
            },
            safe_chunks=True,
        )

    return "OK"


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _read_individual_privatelog_h5(
    h5file_path: str | PathLike, file_info: PrivateLogInfo
) -> xr.Dataset:
    with h5py.File(h5file_path, "r") as h5file:
        try:
            timestamp = np.array(h5file["results"]["timestamp"]).astype(int)
        except (KeyError, ValueError) as err:
            raise KeyError(
                f"Need TIMESTAMP in the RESULT group of H5 file ({h5file_path})"
            ) from err

        if (timestamp[0], timestamp[-1], len(timestamp)) != (
            file_info.start,
            file_info.stop,
            file_info.n_points,
        ):
            raise ValueError(f"Timestamp mismatch in H5 file ({h5file_path})")

        values = np.array(h5file["results"][()].tolist())

        ds_temp = xr.Dataset(
            {"private_values": (("_datetime", "private_var"), values)},
            coords={
                "private_var": list(h5file["results"].dtype.names),
            },
        )
        return ds_temp


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _h5s_privatelogs_to_zarr(
    files_info: dict[str, PrivateLogInfo],
    allocated_store_path: str | PathLike,
    show_progress: bool = True,
    n_workers: Optional[int] = None,
) -> None:
    """
    Create and execute action list to read H5 files
     spectral data into a zarr store.

    Args:
        pre_scan_info (H5SpectralInfo):
            Info from H5 files pre-scan
            from :py:func:`._pre_scan_h5_files`
        allocated_store_path (str):
            Zarr store location.
        show_progress (bool):
            If true, show a Dask progress bar.
        n_workers (int):
            Number of workers for dask local cluster.
            If None, all cores will be used.

    Returns:
        list: list of results.

    """
    time_regions = _get_time_regions(
        files_info=files_info,
    )

    private_vars = _get_private_vars(
        files_info=files_info,
    )

    LOGGER.info("Reading and saving H5 private data to zarr store")

    with LocalCluster(
        n_workers=n_workers, processes=True, threads_per_worker=1
    ) as cluster, Client(cluster) as client:
        # Create a list of delayed objects
        futures = [
            client.submit(
                _process_h5_privatelog_file,
                filename,
                allocated_store_path,
                file_info,
                time_regions[filename],
                private_vars,
            )
            for filename, file_info in files_info.items()
        ]

        if show_progress:
            progress(futures)

        wait(futures)

    for future in futures:
        if future.status == 'error':
            LOGGER.warning(future.exception())

    LOGGER.info("Private data was written successfully")
