from os import PathLike


import h5py
import pandas as pd
import pytz
from dask.diagnostics import ProgressBar
import dask.array as da
import numpy as np
import dask.bag as db
import xarray as xr
from pydantic import validate_call

from picarro_xarray.io.data_models.h5_structures import TIME_CHUNK_SIZE
from picarro_xarray.io.data_models.prescan_data_structures import PrivateLogInfo
from picarro_xarray.io.utils.dataset_attributes_setting import set_time_attributes
from picarro_xarray.io.utils.prescan_utils import _verify_intervals_distinct
from picarro_xarray.logger.logger import get_logger

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def prescan_private_logs(files_list: list[str | PathLike]) -> dict[str, PrivateLogInfo]:
    """
    Scan a list of private log files and return a dictionary of PrivateLogInfo objects.
    The dictionary is sorted by start timestamp.

    Args:
        files_list (list[str | PathLike]):
            list of paths to the private log files.

    Returns:
        dict[str, PrivateLogInfo]:
            Dictionary of PrivateLogInfo objects, sorted by start timestamp.
            Keys are the filenames.

    """
    files_list = [str(file) for file in files_list]

    with ProgressBar():
        results = db.from_sequence(files_list).map(_scan_private_log).compute()

    result_sorted = dict(zip(files_list, results))

    # sort by start timestamp (ascending)
    result_sorted = {
        k: v for k, v in sorted(result_sorted.items(), key=lambda item: item[1].start)
    }

    # check that intervals do not overlap
    _verify_intervals_distinct(result_sorted)

    return result_sorted


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _scan_private_log(filename: str | PathLike) -> PrivateLogInfo:
    """
    Scan a private log file and return a PrivateLogInfo object.

    Args:
        filename (str | PathLike):
            Path to the private log file.

    Returns:
        PrivateLogInfo:
            PrivateLogInfo object.

    Raises:
        KeyError: If the private log file does not contain a TIMESTAMP in the RESULT group.

    """

    with h5py.File(str(filename), "r") as h5file:
        try:
            timestamp = np.array(h5file["results"]["timestamp"]).astype(int)
        except (KeyError, ValueError) as err:
            raise KeyError(
                f"Need TIMESTAMP in the RESULT group of H5 file ({filename})"
            ) from err

        variables = list(h5file["results"].dtype.names)

        log_info = PrivateLogInfo(timestamp=timestamp, variables=variables)

        return log_info


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _preallocate_private_zarr_store(
    zarr_path: str | PathLike,
    local_time_zone: str,
    datetime: pd.DatetimeIndex,
    private_vars: list[str],
    analyzer_name: str,
    private_logs_origin: xr.DataArray,
    time_chunk_size: int = TIME_CHUNK_SIZE,
):
    """
    Preallocate a virtual zarr store based
    on the pre-scan info.

    Args:
        zarr_path (str):
            Path to the zarr store.
        local_time_zone (str):
            Local time zone in pytz format.
        _datetime (pd.DatetimeIndex):
            Datetime index of the private log files.
            It is one of the coordinates of the dataset.
        private_vars (list[str]):
            list of private variables. It is the other
            coordinate of the dataset.
        analyzer_name (str):
            Name of the analyzer. Used as an attribute.
        private_logs_origin (xr.DataArray):
            DataArray containing the origin file
            for each datetime recorded in the dataset.
            Must have dimension ``_datetime`` with the
            same length as ``_datetime``.
        time_chunk_size (int):
            Chunk size for the time dimension.
    Returns:
        None

    Raises:
        ValueError: If _datetime is not a coordinate of private_logs_origin.
        ValueError: If private_logs_origin _datetime does not have the same length as _datetime.
        ValueError: If local_time_zone is not in pytz.all_timezones.

    """
    time_len = len(datetime)
    private_vars_len = len(private_vars)

    if "_datetime" not in private_logs_origin.dims:
        raise ValueError("private_logs_origin must have dimension '_datetime'")

    if private_logs_origin.sizes["_datetime"] != time_len:
        raise ValueError("private_logs_origin must have the same length as _datetime")

    if local_time_zone not in pytz.all_timezones:
        raise ValueError(
            f"Time zone {local_time_zone} is not in list of pytz timezones"
        )

    LOGGER.info(f"Pre-allocating virtual zarr store at {zarr_path}")

    # Dummy lazy dask array
    dummies = da.zeros((time_len, private_vars_len), chunks=(time_chunk_size, -1))

    ds_dummy = xr.Dataset(
        {
            "private_values": (("_datetime", "private_var"), dummies),
            "private_logs_origin": private_logs_origin,
        }
    )
    ds_dummy = ds_dummy.assign_coords(
        {
            "_datetime": datetime,
            "private_var": private_vars,
        }
    )

    ds_dummy.attrs["tz"] = local_time_zone
    ds_dummy.attrs["analyzer"] = analyzer_name
    ds_dummy = set_time_attributes(ds_dummy)

    ds_dummy.to_zarr(
        store=zarr_path, mode="w", compute=False
    )  # It is a delayed operation

    LOGGER.info(
        f"Virtual pre-allocation successful. Private values size: {dummies.shape}"
    )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_private_vars(
    files_info: dict[str, PrivateLogInfo],
) -> list[str]:
    """
    Get the list of private variables from the pre-scan info.
    A private variable is included in the result as long
    as it is present in at least one of the private log files.

    >>> info_ = {
    ...     '0.h5': PrivateLogInfo(timestamp=np.array([1]), variables=['a', 'b']),
    ...     '1.h5': PrivateLogInfo(timestamp=np.array([2]), variables=['b', 'c']),
    ...     '2.h5': PrivateLogInfo(timestamp=np.array([3]), variables=['c', 'd']),
    ... }
    >>> _get_private_vars(info_)
    ['a', 'b', 'c', 'd']

    Args:
        files_info (dict[str, PrivateLogInfo]):
            Dictionary of PrivateLogInfo objects, sorted by start timestamp.

    Returns:
        list[str]:
            list of private variables.

    """
    all_vars = set()
    for v in files_info.values():
        all_vars.update(v.variables)
    all_vars = sorted(list(all_vars))
    return all_vars
