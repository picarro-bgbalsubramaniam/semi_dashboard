import shutil
from os import PathLike
from pathlib import Path
from typing import Optional

import pytz
import xarray as xr
from pydantic import PositiveInt, validate_call

from picarro_xarray.io.combolog.combo_log_spectra import read_combo_logs
from picarro_xarray.io.data_models.h5_structures import TIME_CHUNK_SIZE
from picarro_xarray.io.merging.merge_datasets import (
    append_private_logs_to_spectral_zarr,
)
from picarro_xarray.io.privatelog.private_log_results import read_private_logs
from picarro_xarray.io.utils.api_utils import get_existing_zarr_store_path
from picarro_xarray.logger.logger import get_logger

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def pool_data_to_zarr(
    combolog_folder_path: str | PathLike,
    path_to_zarr: str | PathLike,
    local_time_zone: str,
    privatelog_folder_path: Optional[str | PathLike] = None,
    fitter_name: str = "broadband",
    chunk_time_size: PositiveInt = TIME_CHUNK_SIZE,
    exist_ok: bool = True,
    privatelog_key: Optional[str] = None,
) -> Path:
    """
    Pool combologs data into a zarr store.
    If a privatelogs_path is provided, also the
    private logs are added to the zarr store.

    Args:
        combolog_folder_path (str):
            Path where `combo` data is located.
        path_to_zarr (str):
            Location (folder) of the exported zarr store.
        local_time_zone (str):
            Timezone in pytz format.
        privatelog_folder_path (str):
            Path where `private` data is located.
        fitter_name (str):
            Name of the combologs fitter used.
            Default is `broadband`.
        chunk_time_size (int):
            Chunk size of the time dimension.
            Default is 1000.
        exist_ok (bool):
            If a zarr store is already present,
            and exist_ok is True, the existing
            zarr store will be read (without
            loading the data from the H5 files).
            Default is True.
        privatelog_key (str):
            Key to the private log designation in the H5 file, typically "NewFitter"
            If None (default), all designations will be considered.
    Returns:
        str: Path of the zarr store
    Raises:
        ValueError: If the time zone is not valid.
        FileExistsError: If a zarr store already exists and exist_ok is False.
    """
    if local_time_zone not in pytz.all_timezones:
        raise ValueError("Time zone not in list of pytz timezones")

    combolog_folder_path = Path(combolog_folder_path)
    path_to_zarr = Path(path_to_zarr)

    existing_zarr_path = get_existing_zarr_store_path(path_to_zarr)

    if existing_zarr_path:
        if exist_ok:
            return existing_zarr_path
        else:
            raise FileExistsError(
                f"Zarr store already exists at {existing_zarr_path}. "
                "Please remove it or set exist_ok=True."
            )

    zarr_path = read_combo_logs(
        folder_path=combolog_folder_path,
        local_time_zone=local_time_zone,
        path_to_zarr=path_to_zarr,
        fitter_name=fitter_name,
        chunk_time_size=chunk_time_size,
    )

    if privatelog_folder_path and Path(privatelog_folder_path).exists():
        LOGGER.info("Private folder found. Reading private logs")

        private_zarr_path = read_private_logs(
            folder_path=privatelog_folder_path,
            local_time_zone=local_time_zone,
            path_to_zarr=path_to_zarr,
            chunk_time_size=chunk_time_size,
            privatelog_key=privatelog_key,
        )
        private_ds = xr.open_zarr(private_zarr_path)

        append_private_logs_to_spectral_zarr(
            ds_private=private_ds, zarr_store_path=str(zarr_path)
        )

        private_ds.close()
        shutil.rmtree(private_zarr_path)
    else:
        LOGGER.info("Did not find private logs. Proceeding with fitter data only.")

    LOGGER.info(f"Pooled data successfully at: {zarr_path}")
    return zarr_path
