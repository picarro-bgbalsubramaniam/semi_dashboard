from typing import Callable

from pydantic import validate_call
from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from picarro_xarray.compute.least_squares.bounded_least_squares import (
    bounded_lsq_fit_xarray,
)
from picarro_xarray.compute.least_squares.regular_least_squares import lsq_fit_xarray
from picarro_xarray.compute.least_squares.ridge_hyperparameter import MethodType
from picarro_xarray.compute.least_squares.ridge_regression import ridge_fit_xarray
from picarro_xarray.compute.least_squares.utils import (
    NPOINTS,
    SPECTRUM_KEY,
    STAT_ERROR_KEY,
    _extract_spectral_error,
    _filter_dataset_modes,
    _retrieve_max_true_values,
    _validate_combo_dataset,
)
from picarro_xarray.data_models.constants import MODE_DIM
from picarro_xarray.data_models.data_types import (
    ComboDataSet,
    CompactDataSet,
    TimeseriesDataArray,
)

NU_KEY = "nu_prime"
NU_CENTER = "fitData_fitdata_params_nucenter"


def _preprocess_dataset(
    dataset: ComboDataSet | CompactDataSet,
    n_predictors: int,
    spectrum_key: str = SPECTRUM_KEY,
    nu_key: str = NU_KEY,
    npoints_key: str = NPOINTS,
    nu_center_key: str = NU_CENTER,
) -> ComboDataSet | CompactDataSet:
    """
    Preprocess the dataset for least squares fitting.

    First, validate the dataset by checking if it has the required keys
    in spectral and fitter variables. Then, filter the dataset to drop
    empty modes. Finally, select the required keys for the least squares
    fitting.

    Args:
        dataset (ComboDataSet | CompactDataSet):
            The input dataset containing spectral and timeseries data
        n_predictors (int):
            Number of predictors to be used in the least squares fitting.
            It is used to check if the dataset has enough modes to fit the
            current CID list.
        spectrum_key (str, optional):
            Key to access the spectrum in the dataset. Default is ``SPECTRUM_KEY``.
        nu_key (str, optional):
            Key to access the wavenumber in the dataset. Default is ``NU_KEY``.
        npoints_key (str, optional):
            Key to access the number of points in the dataset. Default is ``NPOINTS``.
        nu_center_key (str, optional):
            Key to access the central frequency in the dataset. Default is ``NU_CENTER``.

    Returns:
        ComboDataSet | CompactDataSet: Preprocessed dataset.

    """
    # Validate the dataset
    _validate_combo_dataset(
        dataset,
        spectral_keys=[spectrum_key, nu_key, npoints_key],
        fitter_keys=[nu_center_key],
    )

    # Filter the dataset dropping empty modes
    dataset = _filter_dataset_modes(dataset, spectrum_key)

    if dataset.sizes[MODE_DIM] < n_predictors:
        msg = (
            f"Too many CIDs with respect to available modes: "
            f"dataset has {dataset.sizes[MODE_DIM]} modes, but the least squares fitter "
            f"requires at least {n_predictors} modes to fit the current CID list"
        )
        raise ValueError(msg)

    dataset = dataset.sel(
        spectral_var=[spectrum_key, npoints_key, nu_key], fitter_var=[nu_center_key]
    )
    return dataset


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def fit_dataset(
    dataset: ComboDataSet | CompactDataSet,
    lsq_fitter: LinearLeastSquares,
    cid_fitter_mask: TimeseriesDataArray | None = None,
    positive: bool = False,
    spectrum_key: str = SPECTRUM_KEY,
    nu_key: str = NU_KEY,
    npoints_key: str = NPOINTS,
    nu_center_key: str = NU_CENTER,
    error_statistic_key: str = STAT_ERROR_KEY,
) -> TimeseriesDataArray:
    """
    Fits the dataset using least squares method.
    If it is a compact dataset, use the error on the
    spectrum key as spectral error.
    If it is a combo dataset, use ``sqrt(1/npoints)`` as spectral error.

    This function assumes that:
    - each mode can be represented by a single wavenumber value, its median
    - the nu_center can be represented by a single value, its median

    Args:
        dataset (ComboDataSet):
            The input dataset containing spectral and timeseries data
        lsq_fitter (LinearLeastSquares):
            Instance of the least squares fitter to be used.
        cid_fitter_mask (TimeseriesDataArray):
            A boolean mask of dimensions ``(_datetimes x fitter_var)``
            mapping baseline terms and CIDs to be used for each datetime.
            The ``fitter_var`` coordinate values should match
            ``lsq_fitter.get_results_keys(baseline_order=1)[:-1]``.
            If not provided, all the baseline terms and CIDs are used.
        positive (bool, optional):
            If False, the least squares algorithm is used.
            If True, the non-negative least squares algorithm is used.
            Defaults to False.
        spectrum_key (str, optional): Key to access the spectrum in the dataset. Default is ``SPECTRUM_KEY``.
        nu_key (str, optional): Key to access the wavenumber in the dataset. Default is ``NU_KEY``.
        npoints_key (str, optional): Key to access the number of points in the dataset. Default is ``NPOINTS``.
        nu_center_key (str, optional): Key to access the central frequency in the dataset. Default is ``NU_CENTER``.
        error_statistic_key (str, optional):
            Key to access the error statistic in the dataset. Default is ``STAT_ERROR_KEY``.

    Returns:
        xr.DataArray: DataArray of fitted values.
    """
    if cid_fitter_mask is None:
        # if no cid_fitter_mask is provided, all vars are used
        n_predictors = len(lsq_fitter.get_results_keys())
    else:
        # if cid_fitter_mask is provided, only the active vars are used
        n_predictors = _retrieve_max_true_values(cid_fitter_mask)

    dataset = _preprocess_dataset(
        dataset=dataset,
        n_predictors=n_predictors,
        spectrum_key=spectrum_key,
        nu_key=nu_key,
        npoints_key=npoints_key,
        nu_center_key=nu_center_key,
    )

    spectrum_error_values = _extract_spectral_error(
        dataset,
        spectrum_key=spectrum_key,
        npoints_key=npoints_key,
        error_statistic_key=error_statistic_key,
    )

    return lsq_fit_xarray(
        spectrum=dataset.sel(spectral_var=spectrum_key).spectral_values,
        spectrum_error=spectrum_error_values,
        wavenumber=dataset.sel(spectral_var=nu_key).spectral_values,
        nu_center=dataset.sel(fitter_var=nu_center_key).fitter_values,
        lsq_fitter=lsq_fitter,
        positive=positive,
        cid_fitter_mask=cid_fitter_mask,
    )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def bounded_fit_dataset(
    dataset: ComboDataSet | CompactDataSet,
    lsq_fitter: LinearLeastSquares,
    bounds: dict[int, tuple[float, float]] | None = None,
    cid_fitter_mask: TimeseriesDataArray | None = None,
    spectrum_key: str = SPECTRUM_KEY,
    nu_key: str = NU_KEY,
    npoints_key: str = NPOINTS,
    nu_center_key: str = NU_CENTER,
    error_statistic_key: str = STAT_ERROR_KEY,
) -> TimeseriesDataArray:
    """
    Fits the dataset using least squares method, with
    bounds on the fitted parameters.
    If it is a compact dataset, use the error on the
    spectrum key as spectral error.
    If it is a combo dataset, use ``sqrt(1/npoints)`` as spectral error.

    This function assumes that:
    - each mode can be represented by a single wavenumber value, its median
    - the nu_center can be represented by a single value, its median

    Args:
        dataset (ComboDataSet):
            The input dataset containing spectral and timeseries data
        lsq_fitter (LinearLeastSquares):
            Instance of the least squares fitter to be used.
        bounds (dict[int, tuple[float, float]]):
            A dictionary where the keys are the cids and the values are tuples
            containing the lower and upper bounds for the cids.
            If not provided, no bounds are imposed.
            Defaults to None.

            Example, set bounds for offset and cid 222:

                {0: (-5, np.inf), 222: (0, 100)}

        cid_fitter_mask (TimeseriesDataArray):
            A boolean mask of dimensions ``(_datetimes x fitter_var)``
            mapping baseline terms and CIDs to be used for each datetime.
            The ``fitter_var`` coordinate values should match
            ``lsq_fitter.get_results_keys(baseline_order=1)[:-1]``.
            If not provided, all the baseline terms and CIDs are used.
        spectrum_key (str, optional): Key to access the spectrum in the dataset. Default is ``SPECTRUM_KEY``.
        nu_key (str, optional): Key to access the wavenumber in the dataset. Default is ``NU_KEY``.
        npoints_key (str, optional): Key to access the number of points in the dataset. Default is ``NPOINTS``.
        nu_center_key (str, optional): Key to access the central frequency in the dataset. Default is ``NU_CENTER``.
        error_statistic_key (str, optional):
            Key to access the error statistic in the dataset. Default is ``STAT_ERROR_KEY``.

    Returns:
        xr.DataArray: DataArray of fitted values.
    """
    if cid_fitter_mask is None:
        # if no cid_fitter_mask is provided, all vars are used
        n_predictors = len(lsq_fitter.get_results_keys())
    else:
        # if cid_fitter_mask is provided, only the active vars are used
        n_predictors = _retrieve_max_true_values(cid_fitter_mask)

    dataset = _preprocess_dataset(
        dataset=dataset,
        n_predictors=n_predictors,
        spectrum_key=spectrum_key,
        nu_key=nu_key,
        npoints_key=npoints_key,
        nu_center_key=nu_center_key,
    )

    spectrum_error_values = _extract_spectral_error(
        dataset,
        spectrum_key=spectrum_key,
        npoints_key=npoints_key,
        error_statistic_key=error_statistic_key,
    )

    return bounded_lsq_fit_xarray(
        spectrum=dataset.sel(spectral_var=spectrum_key).spectral_values,
        spectrum_error=spectrum_error_values,
        wavenumber=dataset.sel(spectral_var=nu_key).spectral_values,
        nu_center=dataset.sel(fitter_var=nu_center_key).fitter_values,
        lsq_fitter=lsq_fitter,
        bounds=bounds,
        cid_fitter_mask=cid_fitter_mask,
    )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def ridge_fit_dataset(
    dataset: ComboDataSet | CompactDataSet,
    lsq_fitter: LinearLeastSquares,
    cid_fitter_mask: TimeseriesDataArray | None = None,
    method: MethodType | Callable = "cross_validate_se",
    spectrum_key: str = SPECTRUM_KEY,
    nu_key: str = NU_KEY,
    npoints_key: str = NPOINTS,
    nu_center_key: str = NU_CENTER,
    error_statistic_key: str = STAT_ERROR_KEY,
    **kwargs,
) -> TimeseriesDataArray:
    """
    Fits the dataset using ridge regression method.
    If it is a compact dataset, use the error on the
    spectrum key as spectral error.
    If it is a combo dataset, use ``sqrt(1/npoints)`` as spectral error.

    This function assumes that:
    - each mode can be represented by a single wavenumber value, its median
    - the nu_center can be represented by a single value, its median

    Args:
        dataset (ComboDataSet):
            The input dataset containing spectral and timeseries data
        lsq_fitter (LinearLeastSquares):
            Instance of the least squares fitter to be used.
        cid_fitter_mask (TimeseriesDataArray):
            A boolean mask of dimensions ``(_datetimes x fitter_var)``
            mapping baseline terms and CIDs to be used for each datetime.
            The ``fitter_var`` coordinate values should match
            ``lsq_fitter.get_results_keys(baseline_order=1)[:-1]``.
        method (MethodType | Callable):
            Method to estimate the ridge parameter. Defaults to ``"cross_validate_se"``.
            For more details, see
            :py:func:`picarro_xarray.compute.least_squares.ridge_hyperparameter.estimate_ridge_parameter`.
        spectrum_key (str, optional): Key to access the spectrum in the dataset. Default is ``SPECTRUM_KEY``.
        nu_key (str, optional): Key to access the wavenumber in the dataset. Default is ``NU_KEY``.
        npoints_key (str, optional): Key to access the number of points in the dataset. Default is ``NPOINTS``.
        nu_center_key (str, optional): Key to access the central frequency in the dataset. Default is ``NU_CENTER``.
        error_statistic_key (str, optional):
            Key to access the error statistic in the dataset. Default is ``STAT_ERROR_KEY``.
        **kwargs:
            Arguments to be passed to the ridge hyperparameter estimator.

    Returns:
        xr.DataArray: DataArray of fitted values.
    """
    if cid_fitter_mask is None:
        # if no cid_fitter_mask is provided, all vars are used
        n_predictors = len(lsq_fitter.get_results_keys())
    else:
        # if cid_fitter_mask is provided, only the active vars are used
        n_predictors = _retrieve_max_true_values(cid_fitter_mask)

    dataset = _preprocess_dataset(
        dataset=dataset,
        n_predictors=n_predictors,
        spectrum_key=spectrum_key,
        nu_key=nu_key,
        npoints_key=npoints_key,
        nu_center_key=nu_center_key,
    )

    spectrum_error_values = _extract_spectral_error(
        dataset,
        spectrum_key=spectrum_key,
        npoints_key=npoints_key,
        error_statistic_key=error_statistic_key,
    )

    return ridge_fit_xarray(
        spectrum=dataset.sel(spectral_var=spectrum_key).spectral_values,
        spectrum_error=spectrum_error_values,
        wavenumber=dataset.sel(spectral_var=nu_key).spectral_values,
        nu_center=dataset.sel(fitter_var=nu_center_key).fitter_values,
        lsq_fitter=lsq_fitter,
        cid_fitter_mask=cid_fitter_mask,
        method=method,
        **kwargs,
    )
