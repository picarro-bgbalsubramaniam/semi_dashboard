from typing import Optional

import numpy as np
import xarray as xr
from numpy.linalg import svd
from pydantic import Field, validate_call
from scipy.optimize import nnls
from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from picarro_xarray.compute.least_squares.block_fitter import _lsq_fit_time_block
from picarro_xarray.compute.least_squares.fitter_mask import (
    _generate_default_fitter_mask,
)
from picarro_xarray.compute.least_squares.utils import (
    _filter_and_weight_spectral_data,
)
from picarro_xarray.data_models.constants import CID_DIM, MODE_DIM, TIME_DIM
from picarro_xarray.data_models.data_types import TimeseriesDataArray


def _nnlsq_fit_single_spectrum(
    spectrum: np.ndarray,
    error: np.ndarray,
    fitter_var_mask: np.ndarray,
    model_function_matrix: np.ndarray,
) -> np.ndarray:
    """
    Fits a single spectrum using singular value decomposition.
    The output is an array of concentration values.

    Args:
        spectrum (np.ndarray):
            Spectrum values (partial fit) of shape (mode).
        error (np.ndarray):
            Error associated with each spectrum value. It has shape (mode).
        fitter_var_mask (np.ndarray):
            Boolean mask, True for compounds to be fitted, False for compounds to ignore.
            It has shape (cid).
        model_function_matrix (np.ndarray):
            Design matrix of shape (mode, cid). Typically,
            also contains terms associated to the baseline offset and slope.
    Returns:
        np.ndarray: Fitted values (concentrations) from the least squares operation.
    """
    y_matrix_weighted, y_data_weighted = _filter_and_weight_spectral_data(
        spectrum=spectrum,
        error=error,
        model_function_matrix=model_function_matrix[:, fitter_var_mask],
    )
    sol, _ = nnls(y_matrix_weighted, y_data_weighted)
    results = np.full(fitter_var_mask.shape, np.nan)
    results[fitter_var_mask] = sol
    return results


def _lsq_fit_single_spectrum(
    spectrum: np.ndarray,
    error: np.ndarray,
    fitter_var_mask: np.ndarray,
    model_function_matrix: np.ndarray,
) -> np.ndarray:
    """
    This is a ``Callable`` function that fits a
    single spectrum using singular value decomposition.
    The output is an array of concentration values.

    Args:
        spectrum (np.ndarray):
            Spectrum values (partial fit) of shape (mode).
        error (np.ndarray):
            Error associated with each spectrum value. It has shape (mode).
        fitter_var_mask (np.ndarray):
            Boolean mask, True for compounds to be fitted, False for compounds to ignore.
            It has shape (cid).
        model_function_matrix (np.ndarray):
            Design matrix of shape (mode, cid). Typically,
            also contains terms associated to the baseline offset and slope.
    Returns:
        np.ndarray: Fitted values (concentrations) from the least squares operation.
    """
    y_matrix_weighted, y_data_weighted = _filter_and_weight_spectral_data(
        spectrum=spectrum,
        error=error,
        model_function_matrix=model_function_matrix[:, fitter_var_mask],
    )
    U, S, V = svd(y_matrix_weighted, full_matrices=False)
    results = np.full(fitter_var_mask.shape, np.nan)
    results[fitter_var_mask] = V.T @ np.diag(1 / S) @ U.T @ y_data_weighted
    return results


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def lsq_fit_xarray(
    spectrum: TimeseriesDataArray,
    spectrum_error: TimeseriesDataArray,
    wavenumber: TimeseriesDataArray,
    nu_center: TimeseriesDataArray,
    lsq_fitter: LinearLeastSquares,
    cid_fitter_mask: Optional[TimeseriesDataArray] = None,
    positive: bool = False,
    baseline_order: int = Field(default=1, ge=0, le=2),
    mode_dim: str = MODE_DIM,
    cid_dim: str = CID_DIM,
    time_dim: str = TIME_DIM,
) -> TimeseriesDataArray:
    """
    Fits the data from xarray DataArrays
    using the provided least squares fitter.

    To guard against convergence issues, only the modes
    with errors greater than 0 are fitted. Modes with
    errors less than or equal to 0 are set to NaN in
    the spectrum to be fit.

    Args:
        spectrum (TimeseriesDataArray):
            The spectrum to fit. It has shape (_datetime, mode).
            Example, ``ds.sel(spectral_var="partial_fit").spectral_values``
        spectrum_error (TimeseriesDataArray):
            Errors associated with spectrum values. It has shape (_datetime, mode).
        wavenumber (TimeseriesDataArray):
            The wavenumber values. It has shape (_datetime, mode).
            Example, ``ds.sel(spectral_var="nu_prime").spectral_values``
        nu_center (TimeseriesDataArray):
            The center wavenumber. It has shape (_datetime).
            Example, ``ds.sel(fitter_var="fitData_fitdata_params_nucenter").fitter_values``
        lsq_fitter (LinearLeastSquares):
            The least squares fitter to use. It is used to obtain the model functions.
        cid_fitter_mask (Optional[TimeseriesDataArray]):
            Boolean mask to tell the fitter which cids to fit at which time.
            It has shape (_datetime, cid).
            It can be generated from :py:func:`.mask_from_map`.
            If None (default), all cids in ``lsq_fitter`` are used at each time.
        positive (bool, optional):
            If False, the least squares algorithm is used.
            If True, the non-negative least squares algorithm is used.
            Defaults to False.
        baseline_order (int, optional):
            Order of the baseline. Defaults to 1 (offset + slope).
        mode_dim (str, optional): Name of the mode dimension. Defaults to ``MODE_DIM``.
        cid_dim (str, optional): Name of the cid dimension. Defaults to ``CID_DIM``.
        time_dim (str, optional): Name of the time dimension. Defaults to ``TIME_DIM``.

    Returns:
        xr.DataArray:
            DataArray of fitted values.
            It has shape (_datetime, cid).
            The cid coordinate can include offset and slope results.
    """
    output_keys = lsq_fitter.get_results_keys(baseline_order=baseline_order)[:-1]

    if cid_fitter_mask is None:
        cid_fitter_mask = _generate_default_fitter_mask(
            time_length=spectrum.sizes[time_dim],
            fitter_var_length=len(output_keys),
            cid_dim=cid_dim,
            time_dim=time_dim,
            compute=not spectrum.chunksizes,
            chunks={time_dim: spectrum.chunksizes.get(time_dim, -1)},
        )
        cid_fitter_mask[cid_dim] = output_keys

    if set(output_keys) != set(cid_fitter_mask.fitter_var.values):
        msg = (
            f"`fitter_var` coordinate values in `cid_fitter_mask` do not match "
            f"the `lsq_fitter` output keys. Expected {output_keys}, "
            f"found {list(cid_fitter_mask.fitter_var.values)}"
        )
        raise ValueError(msg)

    # temporary reference to fitter dim for fitter mask
    temp_dim = "temp_dim_name"

    output_keys += [f"{lsq_fitter.prefix}_rmse"]

    solver = _nnlsq_fit_single_spectrum if positive else _lsq_fit_single_spectrum

    vectorized_solver = np.vectorize(
        solver,
        excluded=["model_function_matrix"],
        signature="(n),(n),(k)->(m)",  # k is m - 1 (without rmse)
    )

    results = xr.apply_ufunc(
        _lsq_fit_time_block,
        spectrum,
        spectrum_error,
        wavenumber,
        nu_center.reset_coords(drop=True),
        cid_fitter_mask.rename({cid_dim: temp_dim}),
        input_core_dims=[[mode_dim], [mode_dim], [mode_dim], [], [temp_dim]],
        output_core_dims=[[cid_dim]],
        vectorize=False,
        dask="parallelized",
        dask_gufunc_kwargs={
            "allow_rechunk": True,
            "output_sizes": {cid_dim: len(output_keys)},
        },
        kwargs={
            "lsq_fitter": lsq_fitter,
            "solver": vectorized_solver,
        },
        output_dtypes=[float],
    )
    results = results.assign_coords({cid_dim: (cid_dim, output_keys)})
    return results
