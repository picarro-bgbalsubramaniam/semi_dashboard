"""
This module contains functions for estimating the ridge regularization parameter for linear regression.

The main function is `estimate_ridge_parameter`, which provides a unified
interface for the hyperparameter estimation methods.

Available methods:

- `cross_validate_opt`: Cross-validation (select minimum mean squared error)
- `cross_validate_se`: Cross-validation with standard error rule
- `l_curve`: L-curve estimator
- `k4`: K4 estimator
- `hkb`: HKB estimator
- `kb3`: KB3 estimator

Approaches that use cross-validation are computationally intensive and slow,
but they guarantee a good and robust estimate of the hyperparameter.

You can also use a custom estimator function.

Examples:

Using a built-in method:

.. code-block:: python

    lambda_value = estimate_ridge_parameter(X, y, method='cross_validate_opt')

Using a custom estimator:

.. code-block:: python

    def my_custom_estimator(X: np.ndarray, y: np.ndarray, **kwargs) -> float:
        # Custom estimation logic here
        return estimated_lambda

    lambda_value = estimate_ridge_parameter(X, y, method=my_custom_estimator)

Passing additional arguments to the estimator:

.. code-block:: python

    lambda_value = estimate_ridge_parameter(X, y, method='cross_validate', lambdas=np.logspace(-6, 6, 100))

Using a constant lambda:

.. code-block:: python

    def my_custom_estimator(X: np.ndarray, y: np.ndarray, **kwargs) -> float:
        return 1E-6

    lambda_value = estimate_ridge_parameter(X, y, method=my_custom_estimator)
"""

from typing import Callable, Literal, Union

import numpy as np
from pydantic import validate_call
from scipy import linalg
from sklearn.model_selection import ShuffleSplit

MethodType = Literal[
    "cross_validate_opt", "cross_validate_se", "l_curve", "k4", "hkb", "kb3"
]

DEFAULT_CV = ShuffleSplit(n_splits=5, train_size=0.7, test_size=0.3)
DEFAULT_LAMBDAS = np.logspace(-5, 1, 100)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def estimate_ridge_parameter(
    X: np.ndarray,
    y: np.ndarray,
    method: Union[
        MethodType, Callable[[np.ndarray, np.ndarray], float]
    ] = "cross_validate_se",
    **kwargs,
) -> float:
    """
    Estimate the ridge regularization parameter using the specified method.

    Args:
        X (np.ndarray): Input features, shape (n_samples, n_features).
        y (np.ndarray): Target values, shape (n_samples,).
        method (Union[str, Callable]):
            Method to use for estimation.
            Can be either a string ('cross_validate_opt', 'cross_validate_se', 'l_curve', 'k4', 'hkb', or 'kb3') or
            a callable function with the signature ``f(X: np.ndarray, y: np.ndarray, **kwargs) -> float``
        **kwargs: Additional keyword arguments to pass to the estimation method.

    Returns:
        float: Estimated ridge regularization parameter.

    Raises:
        ValueError: If an invalid method string is specified.
    """
    methods = {
        "cross_validate_opt": _get_optimal_lambda,
        "cross_validate_se": _get_optimal_lambda_se,
        "l_curve": _l_curve,
        "k4": _k4,
        "hkb": _hkb,
        "kb3": _kb3,
    }

    if callable(method):
        return method(X, y, **kwargs)
    elif method in methods:
        return methods[method](X, y, **kwargs)
    else:
        raise ValueError(
            f"Invalid method: {method}. Choose from {list(methods.keys())} or provide a custom function."
        )


def __cross_validate_ridge(
    X: np.ndarray, y: np.ndarray, lambdas: np.ndarray, cv=DEFAULT_CV, **kwargs
) -> np.ndarray:
    """
    Performs cross-validation for ridge regression to compute mean squared error (MSE) scores for different lambda values.

    Args:
        X (np.ndarray): Input features, shape (n_samples, n_features).
        y (np.ndarray): Target values, shape (n_samples,).
        lambdas (np.ndarray): Array of lambda values to evaluate.
        cv (ShuffleSplit, optional): Cross-validation object. Defaults to DEFAULT_CV.
        **kwargs: Additional keyword arguments.

    Returns:
        np.ndarray: MSE scores for each lambda value across folds, shape (n_lambdas, n_splits).
    """
    mse_scores = np.zeros((len(lambdas), cv.n_splits))

    for fold, (train_index, val_index) in enumerate(cv.split(X)):
        X_train, X_val = X[train_index], X[val_index]
        y_train, y_val = y[train_index], y[val_index]

        # Compute SVD of X_train once for efficiency
        U, S, V = np.linalg.svd(X_train, full_matrices=False)

        for i, lambda_ in enumerate(lambdas):
            d = S / (S**2 + lambda_)
            beta = V.T @ np.diag(d) @ U.T @ y_train
            y_pred = X_val @ beta
            mse_scores[i, fold] = np.mean((y_val - y_pred) ** 2)

    return mse_scores


def _get_optimal_lambda(
    X: np.ndarray, y: np.ndarray, lambdas: np.ndarray = DEFAULT_LAMBDAS, **kwargs
) -> float:
    """
    Computes the optimal lambda value for ridge regression based on cross-validation.

    Args:
        X (np.ndarray): Input features, shape (n_samples, n_features).
        y (np.ndarray): Target values, shape (n_samples,).
        lambdas (np.ndarray, optional): Array of lambda values to evaluate. Defaults to DEFAULT_LAMBDAS.
        **kwargs: Additional keyword arguments.

    Returns:
        float: The optimal lambda value that results in the lowest MSE.
    """
    mse_scores = __cross_validate_ridge(X, y, lambdas)
    mean_mse_scores = np.mean(mse_scores, axis=1)
    optimal_lambda_index = np.argmin(mean_mse_scores)
    optimal_lambda = lambdas[optimal_lambda_index]
    return optimal_lambda


def _get_optimal_lambda_se(
    X: np.ndarray,
    y: np.ndarray,
    se: float = 1,
    lambdas: np.ndarray = DEFAULT_LAMBDAS,
    **kwargs,
) -> float:
    """
    Computes the optimal lambda value for ridge regression based on cross-validation with standard error rule.

    Args:
        X (np.ndarray): Input features, shape (n_samples, n_features).
        y (np.ndarray): Target values, shape (n_samples,).
        se (float, optional): Standard error multiplier. Defaults to 1.
        lambdas (np.ndarray, optional): Array of lambda values to evaluate. Defaults to DEFAULT_LAMBDAS.
        **kwargs: Additional keyword arguments.

    Returns:
        float: The optimal lambda value within `se` standard errors of the best model.
    """
    mse_scores = __cross_validate_ridge(X, y, lambdas)
    mean_mse_scores = np.mean(mse_scores, axis=1)
    std_mse_scores = np.std(mse_scores, axis=1) / np.sqrt(mse_scores.shape[1])

    min_mse_index = np.argmin(mean_mse_scores)
    min_mse = mean_mse_scores[min_mse_index]
    min_mse_se = std_mse_scores[min_mse_index]

    # Find the most parsimonious model within `se` standard errors of the best model
    threshold = min_mse + se * min_mse_se
    valid_indices = np.where(mean_mse_scores <= threshold)[0]

    # Choose the largest lambda that meets the criterion, or the minimum MSE lambda
    optimal_lambda_index = (
        valid_indices[-1] if len(valid_indices) > 0 else min_mse_index
    )
    return lambdas[optimal_lambda_index]


def _k4(X: np.ndarray, y: np.ndarray, **kwargs) -> float:
    """
    Computes the k4 estimator for ridge parameter using the Harmonic Mean approach.

    Eqn. 32 on A.V. Dorugade (2014) "New ridge parameters for ridge regression".

    Args:
        X (np.ndarray): Input features, shape (n_samples, n_features).
        y (np.ndarray): Target values, shape (n_samples,).
        **kwargs: Additional keyword arguments.

    Returns:
        float: The estimated ridge parameter k4.
    """
    n, p = X.shape

    # Compute OLS estimator
    U, S, V = np.linalg.svd(X, full_matrices=False)

    # Compute OLS solution
    beta_ols = V.T @ np.diag(1 / S) @ U.T @ y

    # Compute residuals and estimate sigma^2
    residuals = y - X @ beta_ols
    sigma_squared = np.sum(residuals**2) / (n - p - 1)

    # Compute the largest eigenvalue of X'X
    lambda_max = np.linalg.eigvals(X.T @ X).max()

    # Compute individual ki(AD) values
    k_i_ad = 2 * p * sigma_squared / (lambda_max * beta_ols**2)

    # Compute k4 using Harmonic Mean
    k4 = 2 * p / lambda_max * np.sum(1 / k_i_ad)

    return k4


def _hkb(X: np.ndarray, y: np.ndarray, **kwargs) -> float:
    """
    Computes the HKB estimator for the ridge regularization parameter.

    Hoerl & Kennard & Baldwin (1975) "Ridge regression: some simulations".

    Args:
        X (np.ndarray): Input features, shape (n_samples, n_features).
        y (np.ndarray): Target values, shape (n_samples,).
        **kwargs: Additional keyword arguments.

    Returns:
        float: The estimated HKB ridge regularization parameter.
    """
    # Compute SVD of X
    U, S, V = np.linalg.svd(X, full_matrices=False)

    # Compute OLS solution
    beta_ols = V.T @ np.diag(1 / S) @ U.T @ y

    # Estimate error variance (sigma^2)
    n, p = X.shape
    y_pred = X @ beta_ols
    residuals = y - y_pred
    sigma_squared = np.sum(residuals**2) / (n - p)

    # Compute HKB estimate
    lambda_hkb = (p * sigma_squared) / np.sum(beta_ols**2)

    return lambda_hkb


def _kb3(X: np.ndarray, y: np.ndarray, **kwargs) -> float:
    """
    Estimates KB3 as the maximum of GM, MED, KM3, HMO, CJH, and FG estimators.

    Kibria (2016) "Some Ridge Regression Estimators and Their Performances"

    Args:
        X (np.ndarray): Input features, shape (n_samples, n_features).
        y (np.ndarray): Target values, shape (n_samples,).
        **kwargs: Additional keyword arguments.

    Returns:
        float: The estimated kb3 ridge parameter.
    """
    n, p = X.shape

    # Compute OLS estimator
    beta_ols = np.linalg.inv(X.T @ X) @ X.T @ y

    # Compute residuals and estimate sigma^2
    residuals = y - X @ beta_ols
    sigma_squared = np.sum(residuals**2) / (n - p)

    # Compute eigenvalues of X'X
    lambdas = np.linalg.eigvals(X.T @ X)

    # Helper function to compute alpha_i^2
    def alpha_squared(i):
        return beta_ols[i] ** 2 / sigma_squared

    # Implement individual estimators
    def estimate_gm():
        return sigma_squared / np.prod(alpha_squared(np.arange(p))) ** (1 / p)

    def estimate_med():
        return np.median(sigma_squared / alpha_squared(np.arange(p)))

    def estimate_km3():
        return np.max(np.sqrt(sigma_squared / alpha_squared(np.arange(p))))

    def estimate_hmo():
        return (
            p
            * sigma_squared
            / np.sum(
                alpha_squared(np.arange(p))
                / (
                    1
                    + np.sqrt(
                        1 + lambdas * (alpha_squared(np.arange(p)) / sigma_squared)
                    )
                )
            )
        )

    def estimate_cjh():
        J = np.eye(p) * sigma_squared
        diff = np.outer(beta_ols, np.ones(p)) - J
        left_term = diff @ diff.T
        right_term = sigma_squared * np.trace(np.linalg.inv(X.T @ X))

        condition = np.trace(left_term) > right_term
        if condition:
            return p * sigma_squared / np.trace(left_term)
        else:
            return p * sigma_squared / (np.trace(left_term) - right_term)

    def estimate_fg():
        return (
            p
            * sigma_squared
            / np.sum(
                alpha_squared(np.arange(p))
                * (
                    (alpha_squared(np.arange(p)) / (4 * sigma_squared))
                    + (6 * sigma_squared * lambdas / sigma_squared) ** 0.5
                    - (6 * sigma_squared * lambdas / sigma_squared)
                )
            )
        )

    # Compute kb3 as the maximum of all estimators
    kb3 = max(
        estimate_gm(),
        estimate_med(),
        estimate_km3(),
        estimate_hmo(),
        estimate_cjh(),
        estimate_fg(),
    )

    return kb3


def _l_curve(
    X: np.ndarray, y: np.ndarray, lambdas: np.ndarray = DEFAULT_LAMBDAS, **kwargs
) -> float:
    """
    Finds the optimal ridge regression parameter using the L-curve method. Thanks, Stephen.

    Hansen (2005) "The L-curve and its use in the numerical treatment of inverse problems"

    Args:
        X (np.ndarray): Input features, shape (n_samples, n_features).
        y (np.ndarray): Target values, shape (n_samples,).
        lambdas (np.ndarray, optional):
            Array of regularization parameters to test.
            Defaults to DEFAULT_LAMBDAS.
        **kwargs: Additional keyword arguments.

    Returns:
        float: The optimal ridge regression parameter.
    """
    rho, eta = __calculate_l_curve(X, y, lambdas)

    # Calculate the curvature of the L-curve
    d_rho = np.gradient(np.log(rho))
    d_eta = np.gradient(np.log(eta))
    d2_rho = np.gradient(d_rho)
    d2_eta = np.gradient(d_eta)

    curvature = (d_rho * d2_eta - d2_rho * d_eta) / (d_rho**2 + d_eta**2) ** (3 / 2)

    # Find the index of maximum curvature
    optimal_index = np.argmax(curvature)

    return lambdas[optimal_index]


def __calculate_l_curve(X: np.ndarray, y: np.ndarray, lambdas: np.ndarray) -> tuple:
    """
    Calculates the L-curve for ridge regression.

    Args:
        X (np.ndarray): Input features, shape (n_samples, n_features).
        y (np.ndarray): Target values, shape (n_samples,).
        lambdas (np.ndarray): Array of regularization parameters to test.

    Returns:
        tuple:
            rho, The residual norm (||Ax - b||^2),
            and eta, The solution norm (||x||^2).
    """
    U, s, Vt = linalg.svd(X, full_matrices=False)

    m, n = X.shape
    s = s[:n]
    U = U[:, :n]

    beta = np.dot(U.T, y)

    rho = np.zeros(len(lambdas))
    eta = np.zeros(len(lambdas))

    for i, alpha in enumerate(lambdas):
        # Calculate the filter factors
        f = s**2 / (s**2 + alpha)

        # Calculate the solution
        x_alpha = np.dot(Vt.T, f * beta / s)

        # Calculate the residual norm (rho)
        rho[i] = linalg.norm(y - np.dot(X, x_alpha)) ** 2

        # Calculate the solution norm (eta)
        eta[i] = linalg.norm(x_alpha) ** 2

    return rho, eta
