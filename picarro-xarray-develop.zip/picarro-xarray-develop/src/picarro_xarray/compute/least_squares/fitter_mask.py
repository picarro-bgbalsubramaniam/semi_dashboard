"""
Functions to create a boolean mask
of dimensions (#datetimes x #cids)
to toggle on/off the fitting of certain
species at certain times
"""

import itertools
import re
from typing import Optional, Sequence

import numpy as np
import xarray as xr
import dask.array as da
from pydantic import validate_call, Field
from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from picarro_xarray.data_models.constants import TIME_DIM, CID_DIM
from picarro_xarray.data_models.data_types import TimeseriesDataArray
from picarro_xarray.logger.logger import get_logger

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def mask_from_map(
    lsq: LinearLeastSquares,
    groups: TimeseriesDataArray,
    groups_cid_map: dict[int | str, list[int]],
    always_cids: Optional[list[int]] = None,
    default_cids: Optional[list[int]] = None,
    baseline_order: Optional[int] = 1,
    cid_dim: str = "fitter_var",
) -> TimeseriesDataArray:
    """
    Create a mask for the CIDs present in ``lsq`` based on group mappings.

    This function generates a boolean mask of dimensions ``(#datetimes x #cids)``
    indicating which CIDs should be used for each datetime.

    Baseline terms are always set to ``True`` in the resulting mask.

    Args:
        lsq (LinearLeastSquares):
            LinearLeastSquares object containing CIDs information.
        groups (TimeseriesDataArray):
            DataArray of dimensions `(#datetimes)` containing group information
            used to map certain cids to certain groups.
        groups_cid_map (dict[int | str, list[int]]):
            Mapping of every group to the corresponding CIDs list.
        always_cids (Optional[list[int]], optional):
            List of CIDs to include for all groups. Defaults to ``None``.
        default_cids (Optional[list[int]], optional):
            List of CIDs to use for groups not in ``groups_cid_map``. Defaults to ``None``.
        baseline_order (int, optional):
            Order of the baseline to be used. Defaults to 1 (offset + slope).
        cid_dim (str, optional):
            Name of the dimension for CIDs in the output.
            Defaults to "fitter_var".

    Returns:
        xr.DataArray: Boolean mask indicating which CIDs to use for each group.

    Raises:
        ValueError: If any CIDs in the mapping are missing from the LinearLeastSquares fitter.

    """
    groups_cid_map = _fill_cids_map(
        groups=groups,
        groups_cid_map=groups_cid_map,
        always_cids=always_cids,
        default_cids=default_cids,
    )

    all_mapped_cids = set(itertools.chain.from_iterable(groups_cid_map.values()))
    missing_mapped_cids = all_mapped_cids - set(lsq.cid_list)

    if missing_mapped_cids:
        msg = (
            f"{len(missing_mapped_cids)} CIDs are missing from "
            f"the LinearLeastSquares fitter: {list(missing_mapped_cids)}. "
            f"Please generate a new LinearLeastSquares that includes those species. "
            f"(all required species for the fitter are {list(all_mapped_cids)})"
        )
        raise ValueError(msg)

    mask = _mask_from_complete_map(
        lsq=lsq,
        groups=groups,
        groups_cid_map=groups_cid_map,
        baseline_order=baseline_order,
        cid_dim=cid_dim,
    )

    return mask


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _fill_cids_map(
    groups: TimeseriesDataArray,
    groups_cid_map: dict[int | str, list[int]],
    always_cids: Optional[list[int]] = None,
    default_cids: Optional[list[int]] = None,
) -> dict[int | str, list[int]]:
    """
    Fill and update a cid map for given groups.

    Takes a mapping of groups-to-CIDs and ensures all groups in the input
    DataArray have some corresponding CIDs.

    It also adds the specified 'always_cids' CIDs to all groups.

    Args:
        groups (xr.DataArray):
            DataArray containing group information.
        groups_cid_map (dict):
            Initial mapping of groups to their corresponding CIDs.
        always_cids (Optional[list[int]], optional):
            List of CIDs to add to all groups. Defaults to None.
        default_cids (Optional[list[int]], optional):
            List of CIDs to use for groups not in groups_cid_map. Defaults to None.

    Returns:
        dict: Updated mapping of groups to CIDs.

    Note:
        - If groups are found in 'groups' that are not in 'groups_cid_map', they will be
          assigned the 'default_cids'.
        - The 'always_cids' will be added to all groups, including newly added ones.
        - If 'always_cids' or 'default_cids' are not provided, they default to empty lists.
    """
    cid_map = groups_cid_map.copy()

    always_cids = always_cids or []
    default_cids = default_cids or []

    all_groups = set(np.unique(groups))
    mapped_groups = set(cid_map.keys())

    # check for groups that are not mapped
    missing_groups = all_groups - mapped_groups

    if missing_groups:
        LOGGER.info(
            f"Found {len(missing_groups)} missing groups out "
            f"of {len(all_groups)}: filling with default cids"
        )
        cid_map.update({group: default_cids for group in missing_groups})

    # add the always cids to all groups
    if always_cids is not None:
        cid_map = {
            group: list(set(cids).union(always_cids)) for group, cids in cid_map.items()
        }
    return cid_map


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _mask_from_complete_map(
    lsq: LinearLeastSquares,
    groups: TimeseriesDataArray,
    groups_cid_map: dict[int | str, list[int]],
    baseline_order: Optional[int] = 1,
    cid_dim: str = "fitter_var",
    baseline_qualifier_str: str = "base",
    cid_qualifier_str: str = "gasConcs",
) -> TimeseriesDataArray:
    """
    Create a mask for the CIDs present in ``lsq`` based on group mappings.

    This function generates a boolean mask of dimensions ``(#datetimes x #cids)``
    indicating which CIDs should be used for each datetime.

    Baseline terms are always set to ``True`` in the resulting mask.
    The rmse is not included in the resulting mask.

    Args:
        lsq (LinearLeastSquares):
            LinearLeastSquares object containing CIDs information.
        groups (xr.DataArray):
            DataArray of dimensions `(#datetimes)` containing group information
            used to map certain cids to certain groups.
        groups_cid_map (dict):
            Mapping of every group to the corresponding CIDs list.
        baseline_order (int, optional):
            Order of the baseline to be used. Defaults to 1 (offset + slope).
        cid_dim (str, optional):
            Name of the dimension for CIDs in the output.
            Defaults to "fitter_var".
        baseline_qualifier_str (str, optional):
            How the baseline terms are named in ``lsq`` fitter. Defaults to "base".
        cid_qualifier_str (str, optional):
            How the cids/gasconcs are named in ``lsq`` fitter. Defaults to "gasConcs".

    Returns:
        xr.DataArray: Boolean mask indicating which CIDs to use for each group.

    """

    # Function to check presence of cids based on mapping
    def _mark_cid_presence(group, group_map, available_cids):
        row_cids = group_map.get(group, [])
        return np.array([cid in row_cids for cid in available_cids], dtype=bool)

    output_keys = lsq.get_results_keys(baseline_order=baseline_order)
    output_keys = output_keys[:-1]  # drop rmse
    baseline_keys = [v for v in output_keys if baseline_qualifier_str in v]

    cid_re = re.compile(rf".*{cid_qualifier_str}_(?P<cid>\d+)")
    cid_int_keys = [
        int(match.group("cid")) if (match := cid_re.match(v)) else np.nan
        for v in output_keys
    ]

    cids_mask = xr.apply_ufunc(
        _mark_cid_presence,
        groups,
        kwargs={"group_map": groups_cid_map, "available_cids": cid_int_keys},
        input_core_dims=[[]],
        output_core_dims=[[cid_dim]],
        dask_gufunc_kwargs={
            "output_sizes": {cid_dim: len(output_keys)},
        },
        vectorize=True,
        dask="parallelized",
        output_dtypes=[bool],
    )
    cids_mask = cids_mask.assign_coords({cid_dim: (cid_dim, output_keys)})
    cids_mask.loc[{cid_dim: baseline_keys}] = True  # always fit baseline terms
    return cids_mask


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _generate_default_fitter_mask(
    time_length: int = Field(gt=0),
    fitter_var_length: int = Field(gt=0),
    compute: bool = False,
    chunks: Optional[dict[str, int | Sequence[int]]] = None,
    time_dim: str = TIME_DIM,
    cid_dim: str = CID_DIM,
) -> xr.DataArray:
    """
    Generate a default fitter mask as a TimeseriesDataArray

    This function creates a 2D boolean mask of size ``(time_length, fitter_var_length)``,
    with dtype ``bool`` and filled with ``True`` values. It can be optionally materialized.

    Args:
        time_length (int): Length of the _datetime dimension.
        fitter_var_length (int): Length of the fitter variable dimension.
        compute (bool, optional): If True, compute the mask immediately. Defaults to False.
        chunks (Optional[dict[str, int | Sequence[int]]], optional):
            Chunk sizes for dask array. Defaults to None.
            Key is the name of the dimension, value is the associated chunk size.
        time_dim (str, optional): Name of the time dimension. Defaults to TIME_DIM.
        cid_dim (str, optional): Name of the fitter variable dimension. Defaults to CID_DIM.

    Returns:
        xr.DataArray: A 2D boolean mask as a xr.DataArray.

    Example:

        >>> mask = _generate_default_fitter_mask(100, 10, compute=True)
        >>> mask.shape
        (100, 10)

    """
    if chunks is None:
        chunks = {}

    shape = (time_length, fitter_var_length)

    cid_fitter_mask = xr.DataArray(
        da.full(shape=shape, fill_value=True, chunks=chunks, name="cid_fitter_mask"),
        dims=[time_dim, cid_dim],
    )

    if compute:
        cid_fitter_mask = cid_fitter_mask.compute()

    return cid_fitter_mask
