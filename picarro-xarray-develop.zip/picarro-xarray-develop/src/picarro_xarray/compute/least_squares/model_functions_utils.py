"""
Utilities for creating least squares fitters with static model functions.
Useful to create a fitter without having access or having to recompute
the model functions splines.
"""

from typing import Callable

import numpy as np
import pandas as pd
from pydantic import validate_call
from spectral_arithmetic.data_models.model_function import ModelFunctions
from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from picarro_xarray.logger.logger import get_logger

NU_TOL = 0.005

LOGGER = get_logger(__name__)


@validate_call(config={"arbitrary_types_allowed": True}, validate_return=True)
def get_static_least_squares_fitter(
    model_function_matrix: pd.DataFrame, cids: list[int | str], nu_tol: float = NU_TOL
) -> LinearLeastSquares:
    """
    Create a static LinearLeastSquares object.

    Static means that the model functions are not splines to be evaluated
    at arbitrary nu values, but rather are lookup tables (from nu to absorbance).

    Args:
        model_function_matrix (pd.DataFrame):
            DataFrame containing model functions data.
            It has dimensions (nu x cid).
            The index is the nu values.
        cids (list[int | str]):
            List of component CIDs to use in the fitter.
            They must be present in the columns of X.
        nu_tol (float, optional):
            Tolerance for nu values when evaluating model functions.
            If the nu value is not within nu_tol of a model function nu value,
            a warning is issued.
            Defaults to NU_TOL.

    Returns:
        LinearLeastSquares:
            A static LinearLeastSquares object with lookup table model functions.
    """
    static_mf = _create_static_model_functions(model_function_matrix, cids, nu_tol)
    nu_min, nu_max = (
        model_function_matrix.index.values.min(),
        model_function_matrix.index.values.max(),
    )
    model_functions = ModelFunctions(funcs=static_mf, nu_min=nu_min, nu_max=nu_max)
    lsq = LinearLeastSquares(model_functions=model_functions)
    return lsq


@validate_call(config={"arbitrary_types_allowed": True}, validate_return=True)
def _create_static_model_functions(
    model_function_matrix: pd.DataFrame, cids: list[int], nu_tol: float = NU_TOL
) -> dict[int, Callable[[np.ndarray], np.ndarray]]:
    """
    Create static model functions for each CID.

    Args:
        model_function_matrix (pd.DataFrame): DataFrame containing model functions data.
        cids (list[int]): List of CIDs.
        nu_tol (float, optional): Tolerance for nu values. Defaults to NU_TOL.

    Returns:
        dict[int, Callable[[np.ndarray], np.ndarray]]:
            Dictionary of static model functions for each CID.
    """
    return {
        cid: _create_static_model_function(model_function_matrix[cid], nu_tol)
        for cid in cids
    }


def _create_static_model_function(
    cid_absorbance: pd.Series, nu_tol: float = NU_TOL
) -> Callable[[np.ndarray], np.ndarray]:
    """
    Create a static model function for a single CID.

    Args:
        cid_absorbance (pd.Series):
            Series containing absorbance data for a CID.
            The index is the nu values.
        nu_tol (float, optional):
            Tolerance for nu values when evaluating model functions.
            If the nu value is not within nu_tol of a model function nu value,
            a warning is issued.
            Defaults to NU_TOL.

    Returns:
        Callable[[np.ndarray], np.ndarray]:
            A function that takes nu values and returns corresponding absorbance
            values.
    """
    absorbance = cid_absorbance.values
    nu_mf = cid_absorbance.index.values

    def wrapper_function(nu_array: np.ndarray) -> np.ndarray:
        """
        Retrieve absorbance values for given nu values.

        Args:
            nu_array (np.ndarray):
                Array of nu values to retrieve absorbance for.

        Returns:
            np.ndarray:
                Array of absorbance values (same length as nu_array).
        """
        closest_indices = np.argmin(np.abs(nu_mf[:, np.newaxis] - nu_array), axis=0)
        nu_closest = nu_mf[closest_indices]

        within_tolerance = np.abs(nu_closest - nu_array) <= nu_tol

        result = np.full(len(nu_array), np.nan)

        result[within_tolerance] = absorbance[closest_indices[within_tolerance]]

        out_of_tolerance = ~within_tolerance
        if np.any(out_of_tolerance):
            for nu, nu_close in zip(
                nu_array[out_of_tolerance], nu_closest[out_of_tolerance]
            ):
                LOGGER.warning(
                    f"Nu difference is out of tolerance: "
                    f"requested {nu:.4f}, found {nu_close:.4f}, "
                    f"difference is {nu_close - nu:.4f}, "
                    f"tolerance is {nu_tol:.4f}"
                )

        return result

    return wrapper_function
