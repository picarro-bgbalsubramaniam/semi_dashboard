"""
Fitter that fits a block of spectra (time, mode) at once.
These functions are used in the context of a dask-chunked computation,
such as a xarray apply_ufunc with dask = "parallelized".
"""

from typing import Callable, NamedTuple

import numpy as np
from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from picarro_xarray.compute.least_squares.utils import (
    EMPTY_MODES_CHUNK_THRESHOLD,
    _filter_valid_modes_time_block,
    design_matrix,
)


def _compute_residuals(
    spectrum: np.ndarray,
    results: np.ndarray,
    full_model_function_matrix: np.ndarray,
    cids_mask: np.ndarray,
) -> np.ndarray:
    """
    Compute residuals between observed and fitted spectrum.

    Args:
        spectrum (np.ndarray): The observed spectrum (time, mode)
        results (np.ndarray): Solution matrix (time, cids)
        full_model_function_matrix (np.ndarray): The full model function matrix (mode, cids)
        cids_mask (np.ndarray):
            Boolean mask for CIDs (cids,). Not all cids are active at all times
            in this block, so we can reduce the computation by only considering
            the active CIDs.

    Returns:
        np.ndarray: Residuals between observed and fitted spectrum (time, mode)
    """
    term1 = (
        full_model_function_matrix[:, cids_mask]
        @ np.nan_to_num(results[:, cids_mask], nan=0).T
    ).T
    return spectrum - term1


def _compute_intercept(
    spectrum_mean: np.ndarray,
    center_mfs: np.ndarray,
    results: np.ndarray,
    cids_mask: np.ndarray,
) -> np.ndarray:
    """
    Compute the intercept term for the least squares solution.

    Args:
        spectrum_mean (np.ndarray): Mean of spectrum along mode dimension (time,)
        center_mfs (np.ndarray): Center of model functions (cids,)
        results (np.ndarray): Solution matrix (time, cids)
        cids_mask (np.ndarray):
            Boolean mask for CIDs (cids,). Not all cids are active at all times
            in this block, so we can reduce the computation by only considering
            the active CIDs.

    Returns:
        np.ndarray: Intercept values (time,)
    """
    term1 = center_mfs[cids_mask] @ np.nan_to_num(results[:, cids_mask], nan=0).T
    intercept = spectrum_mean - term1
    return intercept


class ScaledData(NamedTuple):
    centered_spectrum: np.ndarray  # (time, mode)
    normalized_matrix: np.ndarray  # (mode, cids)
    spectrum_mean: np.ndarray  # (time,)
    columns_scale: np.ndarray  # (cids,)
    center_mfs: np.ndarray  # (cids,)


def _scale_data(
    spectrum: np.ndarray,
    model_function_matrix: np.ndarray,
    n_intercept_cols: int = 1,
) -> ScaledData:
    """
    Scale and center the spectrum and model function matrix.

    Centering is done by subtracting the mean, scaling is done by
    dividing the centered data by the standard deviation of the data.

    Args:
        spectrum (np.ndarray): The spectrum to scale, shape (time, mode)
        model_function_matrix (np.ndarray): The model function matrix, shape (mode, cids)
        n_intercept_cols (int, optional):
            Number of intercept columns. Defaults to 1.

    Returns:
        ScaledData:
            A tuple containing:

            - ``cids_reduced``: cids - n_intercept_cols
            - ``centered_spectrum``: Centered spectrum. Each time has mean zero.
              (time, mode)
            - ``normalized_matrix``: Normalized model function matrix. Each column has
              unit variance and zero mean. (mode, cids_reduced)
            - ``spectrum_mean``: Mean of spectrum along mode dimension (time,)
            - ``columns_scale``: Scale factors for columns, i.e. standard
              deviation of each cid/column. (cids_reduced,)
            - ``center_mfs``: Center of model functions, i.e. mean of the model
              functions for each cid/column. (cids_reduced,)
    """
    # drop the offset (first column), we will compute the offset manually
    model_function_matrix = model_function_matrix[:, n_intercept_cols:]

    # center the model function matrix
    center_mfs = np.average(model_function_matrix, axis=0)
    centered_matrix = model_function_matrix - center_mfs

    # scale the model function matrix
    columns_scale = np.std(centered_matrix, axis=0)
    normalized_matrix = centered_matrix / columns_scale

    # center the spectra, could be sparse
    spectrum_mean = np.nanmean(spectrum, axis=1)
    centered_spectrum = spectrum - spectrum_mean[:, np.newaxis]

    return ScaledData(
        centered_spectrum=centered_spectrum,
        normalized_matrix=normalized_matrix,
        spectrum_mean=spectrum_mean,
        columns_scale=columns_scale,
        center_mfs=center_mfs,
    )


def _scale_and_solve(
    spectrum: np.ndarray,
    spectral_error: np.ndarray,
    full_model_function_matrix: np.ndarray,
    fitter_var_mask: np.ndarray,
    solver: Callable,
    n_intercept_cols: int = 1,
    **kwargs,
) -> np.ndarray:
    """
    Scale the data, solve the least squares problem, and compute the final solution.

    Args:
        spectrum (np.ndarray): The spectrum to fit (time, mode)
        spectral_error (np.ndarray): The spectral error (time, mode)
        full_model_function_matrix (np.ndarray): The full model function matrix (mode, cids)
        fitter_var_mask (np.ndarray): Boolean mask for fitter variables (time, cids)
        solver (Callable): The solver function
        n_intercept_cols (int, optional):
            Number of intercept columns. Defaults to 1.
            Intercept values are computed separately and attached to the solution.
        kwargs: Additional arguments for the solver

    Returns:
        np.ndarray: Solution matrix with RMSE appended as the last column (time, cids+1)
    """
    scaled_data = _scale_data(
        spectrum=spectrum,
        model_function_matrix=full_model_function_matrix,
        n_intercept_cols=n_intercept_cols,
    )

    current_kwargs = kwargs.copy()

    if "lb" in current_kwargs and "ub" in current_kwargs:
        # if bounds are provided, scale them to the same scale as the data
        lb_orig = np.asarray(current_kwargs["lb"], dtype=float)
        ub_orig = np.asarray(current_kwargs["ub"], dtype=float)

        lb_scaled, ub_scaled = _scale_bounds_for_solver(
            lb_original=lb_orig,
            ub_original=ub_orig,
            columns_scale=scaled_data.columns_scale,
        )

        current_kwargs["lb"] = lb_scaled
        current_kwargs["ub"] = ub_scaled

    fitter_mask_wo_intercept = fitter_var_mask[:, n_intercept_cols:]

    results = solver(
        spectrum=scaled_data.centered_spectrum,
        error=spectral_error,
        model_function_matrix=scaled_data.normalized_matrix,
        fitter_var_mask=fitter_mask_wo_intercept,
        **current_kwargs,
    )
    results /= scaled_data.columns_scale

    cids_mask = fitter_var_mask.any(axis=0)
    cids_mask_wo_intercept = cids_mask[n_intercept_cols:]

    intercept = _compute_intercept(
        spectrum_mean=scaled_data.spectrum_mean,
        center_mfs=scaled_data.center_mfs,
        results=results,
        cids_mask=cids_mask_wo_intercept,
    )

    results = np.column_stack((intercept, results))

    residuals = _compute_residuals(
        spectrum=spectrum,
        results=results,
        full_model_function_matrix=full_model_function_matrix,
        cids_mask=cids_mask,
    )

    rmse = np.sqrt(np.nanmean(residuals**2, axis=1))
    return np.column_stack((results, rmse))


def _lsq_fit_time_block(
    spectrum: np.ndarray,
    spectral_error: np.ndarray,
    nu_prime: np.ndarray,
    nu_center: np.ndarray,
    fitter_var_mask: np.ndarray,
    lsq_fitter: LinearLeastSquares,
    solver: Callable,
    **kwargs,
) -> np.ndarray:
    """
    Perform a least squares fit on a spectral time block using model functions.

    This function processes a block of spectral data to perform least squares fitting:
    1. Filters out invalid modes based on NaN threshold
    2. Creates a design matrix using model functions
    3. Scales and centers the data for stability and to compute the intercept separately
    4. Applies the solver to find the least squares solution
    5. Computes residuals and RMSE

    Args:
        spectrum: The spectrum to fit, shape (time, mode)
        spectral_error: The spectral error values, shape (time, mode)
        nu_prime: The wavenumber values, shape (time, mode)
        nu_center: The center wavenumber, shape (time)
        fitter_var_mask: Boolean mask for fitter variables, shape (time, cid)
        lsq_fitter: The least squares fitter providing model functions
        solver: The solver function to use for least squares fitting
            Must have signature: solver(spectrum, error, model_function_matrix, \\*\\*kwargs)
        kwargs: Additional arguments passed to the solver

    Returns:
        np.ndarray: Solution matrix of shape (time, cid+1) where:
            - First column is the intercept
            - Middle columns are coefficients for model functions
            - Last column is RMSE of the fit
    """
    # Filter valid modes
    spectrum, spectral_error, nu_prime = _filter_valid_modes_time_block(
        spectrum=spectrum,
        spectral_error=spectral_error,
        nu_prime=nu_prime,
        threshold=EMPTY_MODES_CHUNK_THRESHOLD,
    )

    # Prepare model functions and masks
    cids = lsq_fitter.cid_list
    model_functions = {cid: lsq_fitter.model_functions.funcs[cid] for cid in cids}
    cids_mask = fitter_var_mask.any(axis=0)
    nu_prime_med = np.nanmedian(nu_prime, axis=0)

    # Create design matrix
    full_model_function_matrix = design_matrix(
        nu_array=nu_prime_med,
        model_functions=model_functions,
        nu_center=nu_center.mean(),
        baseline_terms=[0, 1],  # offset and slope
        cids_mask=cids_mask,
    )

    # Filter valid modes in the model function matrix
    valid_modes_mask = ~np.all(np.isnan(full_model_function_matrix), axis=1)
    full_model_function_matrix = full_model_function_matrix[valid_modes_mask]
    spectrum = spectrum[:, valid_modes_mask]
    spectral_error = spectral_error[:, valid_modes_mask]

    # Scale and solve
    return _scale_and_solve(
        spectrum=spectrum,
        spectral_error=spectral_error,
        full_model_function_matrix=full_model_function_matrix,
        fitter_var_mask=fitter_var_mask,
        solver=solver,
        n_intercept_cols=1,
        **kwargs,
    )


def _scale_bounds_for_solver(
    lb_original: np.ndarray,
    ub_original: np.ndarray,
    columns_scale: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Scales the lower and upper bounds using the provided column scales.

    Args:
        lb_original: The original lower bounds.
        ub_original: The original upper bounds.
        columns_scale: The scaling factors for each column/variable.

    Returns:
        A tuple containing the scaled lower bounds and scaled upper bounds.

    Raises:
        ValueError: If there is a shape mismatch between bounds and columns_scale.
    """
    if (
        lb_original.shape != columns_scale.shape
        or ub_original.shape != columns_scale.shape
    ):
        raise ValueError(
            "Shape mismatch between bounds and columns_scale. "
            f"lb shape: {lb_original.shape}, ub shape: {ub_original.shape}, "
            f"scale shape: {columns_scale.shape}"
        )

    lb_scaled = np.empty_like(lb_original, dtype=float)
    ub_scaled = np.empty_like(ub_original, dtype=float)

    zero_scale_mask = columns_scale == 0.0
    non_zero_scale_mask = ~zero_scale_mask

    # For zero scale factors, scaled bounds become [0, 0]
    # This forces the scaled coefficient to be 0.
    lb_scaled[zero_scale_mask] = 0.0
    ub_scaled[zero_scale_mask] = 0.0

    # For non-zero scale factors, multiply original bounds by the scale.
    # np.multiply handles infinities correctly (e.g., np.inf * scale = np.inf for scale > 0)
    lb_scaled[non_zero_scale_mask] = np.multiply(
        lb_original[non_zero_scale_mask], columns_scale[non_zero_scale_mask]
    )
    ub_scaled[non_zero_scale_mask] = np.multiply(
        ub_original[non_zero_scale_mask], columns_scale[non_zero_scale_mask]
    )
    return lb_scaled, ub_scaled
