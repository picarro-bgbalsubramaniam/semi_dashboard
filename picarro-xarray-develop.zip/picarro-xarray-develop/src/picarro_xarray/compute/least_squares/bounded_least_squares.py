from typing import Optional

import numpy as np
import xarray as xr
from pydantic import Field, validate_call
from scipy.optimize import lsq_linear
from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from picarro_xarray.compute.least_squares.block_fitter import _lsq_fit_time_block
from picarro_xarray.compute.least_squares.fitter_mask import (
    _generate_default_fitter_mask,
)
from picarro_xarray.compute.least_squares.utils import (
    _filter_and_weight_spectral_data,
)
from picarro_xarray.data_models.constants import CID_DIM, MODE_DIM, TIME_DIM
from picarro_xarray.data_models.data_types import TimeseriesDataArray
from picarro_xarray.logger.logger import get_logger

DEFAULT_BOUNDS = (-np.inf, np.inf)
LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_solution_bounds(
    baseline_terms: list[int],
    cid_list: list[int],
    bounds: Optional[dict[int, tuple[float, float]]] = None,
    default_bounds: tuple[float, float] = DEFAULT_BOUNDS,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Generate the lower and upper bounds for a solution based on given constraints.

    By default, all bounds for baseline and cids are set to ``default_bounds``.

    If user-provided bounds are given for one or more cids through the
    argument ``bounds``, the default bounds are overwritten with the custom bounds.

    A warning is issued if extra bounds (bounds that are not included in
    ``cid_list`` or ``baseline_terms``) are provided, and
    the corresponding bounds are ignored.

    It is possible to impose bounds on the baseline terms: for example,
    key ``1`` refers to the slope term, and so on.

    Args:
        baseline_terms (list[int]):
            A list of baseline terms to consider (other than offset).
            For example, ``[1]`` for slope term.
        cid_list (list[int]):
            A list of cids present in the fitter,
            used to generate default bounds for the cids not provided in ``bounds``.
        bounds (dict[int, tuple[float, float]]):
            A dictionary where the keys are the cids and the values are tuples
            containing the lower and upper bounds for the cids.
        default_bounds (tuple[float, float], optional):
            Default bounds to use when no bounds are provided. Defaults to (-np.inf, np.inf).

    Returns:
        tuple[np.ndarray, np.ndarray]:
            Two numpy arrays, the first containing the lower bounds
            and the second containing the upper bounds for the solution.
    """
    if bounds is None:
        bounds = {}

    # create default bounds for the baseline terms and the cids of the fitter
    # and then overwrite with user provided bounds only the terms in all_bounds
    bounds_baseline = {k: default_bounds for k in baseline_terms}
    bounds_cids = {k: default_bounds for k in cid_list}
    allowed_bounds = {**bounds_baseline, **bounds_cids}

    # check if any bounds were provided for non-existent cids/baseline terms
    extra_bounds = set(bounds.keys()).difference(allowed_bounds.keys())

    if extra_bounds:
        LOGGER.warning(
            f"Extra bounds were provided for cids or baseline terms {list(extra_bounds)}, "
            f"that are not among the allowed bounds for the fitter. Ignoring these bounds."
        )

    # keep only the bounds that were provided for cids present in the fitter
    keep_bounds_keys = set(bounds.keys()).intersection(allowed_bounds.keys())

    user_bounds = {k: bounds[k] for k in keep_bounds_keys}

    allowed_bounds.update(user_bounds)

    LOGGER.info(f"Parsed solution bounds: {allowed_bounds}")

    lower_bounds = np.array([v[0] for v in allowed_bounds.values()])
    upper_bounds = np.array([v[1] for v in allowed_bounds.values()])
    return lower_bounds, upper_bounds


def _bounded_lsq_fit_single_spectrum(
    spectrum: np.ndarray,
    error: np.ndarray,
    fitter_var_mask: np.ndarray,
    model_function_matrix: np.ndarray,
    lb: np.ndarray,
    ub: np.ndarray,
) -> np.ndarray:
    """
    Fits a single spectrum and find a solution that respects the bounds.
    The output is an array of concentration values.

    Args:
        spectrum (np.ndarray):
            Spectrum values (partial fit) of shape (mode).
        error (np.ndarray):
            Error associated with each spectrum value. It has shape (mode).
        fitter_var_mask (np.ndarray):
            Boolean mask, True for compounds to be fitted, False for compounds to ignore.
            It has shape (cid).
        model_function_matrix (np.ndarray):
            Design matrix of shape (mode, cid). Typically,
            also contains terms associated to the baseline offset and slope.
        lb (np.ndarray):
            Lower bounds for the solution. It has shape (cid).
        ub (np.ndarray):
            Upper bounds for the solution. It has shape (cid).
    Returns:
        np.ndarray: Fitted values (concentrations) from the least squares operation.
    """
    y_matrix_weighted, y_data_weighted = _filter_and_weight_spectral_data(
        spectrum=spectrum,
        error=error,
        model_function_matrix=model_function_matrix[:, fitter_var_mask],
    )

    try:
        sol = lsq_linear(
            A=y_matrix_weighted,
            b=y_data_weighted,
            bounds=(lb[fitter_var_mask], ub[fitter_var_mask]),
        ).x
    except Exception as e:
        LOGGER.error(f"Failed to solve bounded least squares problem: {e}")
        sol = np.full(len(lb[fitter_var_mask]), np.nan)

    results = np.full(fitter_var_mask.shape, np.nan)
    results[fitter_var_mask] = sol
    return results


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def bounded_lsq_fit_xarray(
    spectrum: TimeseriesDataArray,
    spectrum_error: TimeseriesDataArray,
    wavenumber: TimeseriesDataArray,
    nu_center: TimeseriesDataArray,
    lsq_fitter: LinearLeastSquares,
    baseline_order: int = Field(default=1, ge=0, le=2),
    bounds: Optional[dict[int, tuple[float, float]]] = None,
    cid_fitter_mask: Optional[TimeseriesDataArray] = None,
    mode_dim: str = MODE_DIM,
    cid_dim: str = CID_DIM,
    time_dim: str = TIME_DIM,
) -> TimeseriesDataArray:
    """
    Fits the data from xarray DataArrays
    using a bounded least squares fitter.

    Args:
        spectrum (TimeseriesDataArray):
            The spectrum to fit. It has shape (_datetime, mode).
            Example, ``ds.sel(spectral_var="partial_fit").spectral_values``
        spectrum_error (TimeseriesDataArray):
            Errors associated with spectrum values. It has shape (_datetime, mode).
        wavenumber (TimeseriesDataArray):
            The wavenumber values. It has shape (_datetime, mode).
            Example, ``ds.sel(spectral_var="nu_prime").spectral_values``
        nu_center (TimeseriesDataArray):
            The center wavenumber. It has shape (_datetime).
            Example, ``ds.sel(fitter_var="fitData_fitdata_params_nucenter").fitter_values``
        lsq_fitter (LinearLeastSquares):
            The least squares fitter to use. It is used to obtain the model functions.
        bounds (dict[int, tuple[float, float]], optional):
            A dictionary where the keys are the cids and the values are tuples
            containing the lower and upper bounds for the cids.
            If not provided, no bounds are imposed.
            Defaults to None.

            Example, set bounds for offset and cid 222:

                {0: (-5, np.inf), 222: (0, 100)}
        cid_fitter_mask (TimeseriesDataArray, optional):
            Boolean mask to tell the fitter which cids to fit at which time.
            It has shape (_datetime, cid).
            It can be generated from :py:func:`.mask_from_map`.
            If None (default), all cids in ``lsq_fitter`` are used at each time.
        baseline_order (int, optional):
            Order of the baseline. Defaults to 1 (offset + slope).
        mode_dim (str, optional): Name of the mode dimension. Defaults to ``MODE_DIM``.
        cid_dim (str, optional): Name of the cid dimension. Defaults to ``CID_DIM``.
        time_dim (str, optional): Name of the time dimension. Defaults to ``TIME_DIM``.
    Returns:
        xr.DataArray:
            DataArray of fitted values.
            It has shape (_datetime, cid).
            The cid coordinate can include offset and slope results.
    """
    output_keys = lsq_fitter.get_results_keys(baseline_order=baseline_order)[:-1]

    if cid_fitter_mask is None:
        cid_fitter_mask = _generate_default_fitter_mask(
            time_length=spectrum.sizes[time_dim],
            fitter_var_length=len(output_keys),
            cid_dim=cid_dim,
            time_dim=time_dim,
            compute=not spectrum.chunksizes,
            chunks={time_dim: spectrum.chunksizes.get(time_dim, -1)},
        )
        cid_fitter_mask[cid_dim] = output_keys

    if set(output_keys) != set(cid_fitter_mask.fitter_var.values):
        msg = (
            f"`fitter_var` coordinate values in `cid_fitter_mask` do not match "
            f"the `lsq_fitter` output keys. Expected {output_keys}, "
            f"found {list(cid_fitter_mask.fitter_var.values)}"
        )
        raise ValueError(msg)

    # temporary reference to fitter dim for fitter mask
    temp_dim = "temp_dim_name"

    output_keys += [f"{lsq_fitter.prefix}_rmse"]

    # use 1 as start for baseline terms to ignore offset (always unbounded)
    baseline_terms = list(range(1, baseline_order + 1))

    lb, ub = _get_solution_bounds(
        bounds=bounds, baseline_terms=baseline_terms, cid_list=lsq_fitter.cid_list
    )

    solver = np.vectorize(
        _bounded_lsq_fit_single_spectrum,
        excluded=["model_function_matrix", "lb", "ub"],
        signature="(n),(n),(k)->(m)",  # k is m - 1 (without rmse)
    )

    results = xr.apply_ufunc(
        _lsq_fit_time_block,
        spectrum,
        spectrum_error,
        wavenumber,
        nu_center.reset_coords(drop=True),
        cid_fitter_mask.rename({cid_dim: temp_dim}),
        input_core_dims=[[mode_dim], [mode_dim], [mode_dim], [], [temp_dim]],
        output_core_dims=[[cid_dim]],
        vectorize=False,
        dask="parallelized",
        dask_gufunc_kwargs={
            "allow_rechunk": True,
            "output_sizes": {cid_dim: len(output_keys)},
        },
        kwargs={
            "lsq_fitter": lsq_fitter,
            "solver": solver,
            "lb": lb,
            "ub": ub,
        },
        output_dtypes=[float],
    )
    results = results.assign_coords({cid_dim: (cid_dim, output_keys)})
    return results
