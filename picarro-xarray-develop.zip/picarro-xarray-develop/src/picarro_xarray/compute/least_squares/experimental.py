"""
Least squares fitter experimental utilities.
This module is experimental and subject to change without notice.
"""

from functools import partial
from typing import Callable

from spectral_arithmetic.linear_least_squares import LinearLeastSquares, ModelFunctions

DONT_FIT: list[int] = [947, 977, 280, 977, 947, 297, 962]


def get_petroglyph_least_squares(
    model_functions: dict[int, Callable],
    cids: list[int],
    pressure: float,
    nu_min: int = 5800,
    nu_max: int = 6300,
    dont_fit: list[int] = DONT_FIT,
) -> LinearLeastSquares:
    """
    Get lsq fitter from list of cids and petroglyph model functions.

    .. warning::
        This function is experimental and subject to change without notice.

    Args:
        model_functions (dict[int, Callable]):
            Dictionary of model functions from petroglyph.
        cids (list[int]):
            List of cids to fit.
        pressure (float):
            Pressure to use when evaluating model functions.
        nu_min (int, optional):
            Minimum wavenumber to use for the fit. Defaults to 5800.
        nu_max (int, optional):
            Maximum wavenumber to use for the fit. Defaults to 6300.
        dont_fit (list[int], optional):
            List of cids to not fit. Defaults to ``DONT_FIT``.
            Corresponds to CIDs that are known to be problematic
            or that are fitted by other designated fitters.

    Returns:
        LinearLeastSquares:
            Least squares fitter instance.

    Example:

    .. code-block:: python

        library = pg.SpectralLibrary(".../output_lines.sl")
        model_functions = library.select_empirical(pressure)
        lsq = get_petroglyph_least_squares(
            model_functions,
            cids,
            pressure,
        )

    """
    splines = {
        cid: partial(model_functions[cid], pressure=pressure)
        for cid in cids
        if cid not in dont_fit
    }
    mf = ModelFunctions(nu_min=nu_min, nu_max=nu_max, funcs=splines)
    return LinearLeastSquares(mf)
