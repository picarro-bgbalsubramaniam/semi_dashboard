from typing import Callable

import numpy as np
from numpy.typing import ArrayLike
from pydantic import Field, validate_call

from picarro_xarray.data_models.constants import (
    FITTER_VARNAME,
    MODE_DIM,
    STATS_DIM,
    TIME_DIM,
)
from picarro_xarray.data_models.data_types import (
    ComboDataSet,
    CompactDataSet,
    TimeseriesDataArray,
)
from picarro_xarray.logger.logger import get_logger

SPECTRUM_KEY = "partial_fit"
NPOINTS = "npoints"
STAT_ERROR_KEY = "std_err"
EMPTY_MODES_CHUNK_THRESHOLD = (
    0.03  # min acceptable fraction of modes emptiness in a chunk
)

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _validate_combo_dataset(
    dataset: ComboDataSet,
    spectral_keys: list[str],
    fitter_keys: list[str],
):
    """
    Validates the given dataset against the provided spectral and fitter keys.

    Args:
        dataset (ComboDataSet): The input dataset to validate.
        spectral_keys (list[str]): List of keys to check in the ``spectral_var`` dimension.
        fitter_keys (list[str]): List of keys to check in the `fitter_var` dimension.

    Raises:
    ValueError: If any of the required keys are missing in the dataset.
    """

    missing_spectral_keys = [
        key for key in spectral_keys if key not in dataset.spectral_var
    ]
    if missing_spectral_keys:
        raise ValueError(
            f"Dataset is missing the following keys in `spectral_var` dimension: {missing_spectral_keys}. "
            f"Found: {dataset.spectral_var.values}"
        )

    missing_fitter_keys = [key for key in fitter_keys if key not in dataset.fitter_var]
    if missing_fitter_keys:
        raise ValueError(
            f"Dataset is missing the following keys in `fitter_var` dimension: {missing_fitter_keys}. "
            f"Found: {dataset.fitter_var.values}"
        )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _filter_dataset_modes(
    dataset: ComboDataSet, spectrum_key: str, mode_dim: str = MODE_DIM
) -> ComboDataSet:
    """
    Filters the dataset by dropping modes where the
    spectrum contains all NaNs for the given spectrum key.

    Args:
        dataset (ComboDataSet): The input dataset to filter.
        spectrum_key (str):
          The key against which to check for all NaNs in the ``spectral_var`` dimension.

    Returns:
        ComboDataSet: Filtered dataset.
    """
    empty_modes_bool = (
        dataset.sel(spectral_var=spectrum_key)
        .spectral_values.isnull()
        .all(dim=TIME_DIM)
        .compute()
    )
    empty_modes_list = empty_modes_bool.where(empty_modes_bool, drop=True).mode.values
    return dataset.drop_sel({mode_dim: empty_modes_list})


def _filter_and_weight_spectral_data(
    spectrum: np.ndarray, error: np.ndarray, model_function_matrix: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """
    Filters the spectral data from empty modes
    and weights it by the error.
    Returns the weighted model function matrix and
    the weighted spectrum.
    This is a preprocessing step for the least
    squares fitting operation.

    Args:
        spectrum (np.ndarray):
            Spectrum values (partial fit). Array of shape (mode).
        error (np.ndarray):
            Error associated with each spectrum value. Array of shape (mode).
        model_function_matrix (np.ndarray):
            Design matrix of shape (mode, cid).
            Typically, also contains terms associated
            to the baseline offset and slope.
    Returns:
        tuple[np.ndarray, np.ndarray]:
            Weighted model function matrix and weighted spectrum, with
            empty modes removed.
    """
    valid_modes_mask = ~np.isnan(spectrum) & (error > 0)
    error = error[valid_modes_mask]
    spectrum_weighted = spectrum[valid_modes_mask] / error
    model_function_matrix_weighted = (
        model_function_matrix[valid_modes_mask] / error[:, np.newaxis]
    )
    return model_function_matrix_weighted, spectrum_weighted


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _extract_spectral_error(
    dataset: ComboDataSet | CompactDataSet,
    spectrum_key: str = SPECTRUM_KEY,
    npoints_key: str = NPOINTS,
    error_statistic_key: str = STAT_ERROR_KEY,
    stats_dim: str = STATS_DIM,
) -> TimeseriesDataArray:
    """
    Extracts the spectral error from the provided dataset based on the specified keys.

    If the dataset is a compact dataset, the error is extracted
    from the ``spectral_values_stats`` variable for ``spectrum_key`` with statistic
    ``error_statistic_key``.

    If the dataset is a combo dataset, the error is extracted
    from the ``npoints_key`` variable (from ``spectral_var``).

    Args:
        dataset (ComboDataSet | CompactDataSet):
            The dataset from which to extract the spectral error.
            It can be a combo dataset or a compact dataset.
        spectrum_key (str, optional):
            The key associated with the spectrum variable to fit. Defaults to ``SPECTRUM_KEY``.
        npoints_key (str, optional):
            The key associated with the number of points spectral variable. Defaults to ``NPOINTS``.
        error_statistic_key (str, optional):
            The key associated with the statistical error. Defaults to ``STAT_ERROR_KEY``.
        stats_dim (str, optional):
            The statistical dimension of interest in the compact dataset. Defaults to ``STATS_DIM``.

    Returns:
        xarray.DataArray: The extracted spectral error values.

    Raises:
        ValueError: If the provided dataset does not contain the necessary dimensions or variables based on the keys.
    """
    if stats_dim in dataset.dims:
        LOGGER.info(
            f"Detected compact dataset: using {spectrum_key} "
            f"{error_statistic_key} as spectral error"
        )
        return dataset.sel(
            spectral_var=spectrum_key, stat=error_statistic_key
        ).spectral_values_stats
    else:
        LOGGER.info(f"Detected combo dataset: using 1/{npoints_key} as spectral error")
        return np.sqrt(1 / dataset.sel(spectral_var=npoints_key).spectral_values)


def _create_valid_modes_mask(
    spectrum: np.ndarray,
    threshold: float = Field(default=EMPTY_MODES_CHUNK_THRESHOLD, ge=0, lt=1),
) -> np.ndarray:
    """
    Creates a boolean mask for valid modes in a spectrum based on a threshold of non-NaN values.

    This function considers a mode (column) valid if the fraction of non-NaN values
    in that mode is greater than or equal to the specified threshold.

    Args:
        spectrum (numpy.ndarray):
            2D array where rows represent time and
            columns represent modes.
        threshold (float, optional):
            Minimum fraction of non-NaN values required
            for a mode to be considered valid. Defaults to EMPTY_MODES_CHUNK_THRESHOLD.

    Returns:
        numpy.ndarray:
            Boolean array where True indicates a valid mode (column)
            and False indicates an invalid mode.
    """
    return np.mean(~np.isnan(spectrum), axis=0) >= threshold


def design_matrix(
    nu_array: ArrayLike,
    model_functions: dict[int | str, Callable],
    nu_center: float,
    cids_mask: np.ndarray,
    baseline_terms: list[int] | None = None,
) -> np.ndarray:
    """Creates a design matrix for least squares fitting.

    This function constructs a design matrix by combining baseline polynomial terms
    and model function evaluations. The design matrix is used in linear least squares
    fitting to represent the model components.

    Args:
        nu_array (ArrayLike): Array of frequency/wavelength values. Shape (mode,).
        model_functions (dict[int | str, Callable]):
            Dictionary mapping CID (int or str) to callable
            model functions. Each function should accept nu_array and return a column
            for the design matrix.
        nu_center (float):
            Center frequency/wavelength value for baseline polynomial calculation.
        cids_mask (np.ndarray):
            Boolean array indicating which CIDs to include in the model.
            It should have the same length as the number of available CIDs.
        baseline_terms (list[int] | None, optional):
            List of polynomial powers to include in the baseline model.
            Set to None (default) to exclude baseline terms.
            Set to [0, 1] to include constant (offset) and linear term (slope).

    Returns:
        np.ndarray:
            Design matrix with shape (mode, n_components),
            where n_components is the sum of baseline terms and model functions.
    """
    # compute baseline columns if baseline_terms is not empty or None
    baseline_columns = (
        [(nu_array - nu_center) ** power for power in baseline_terms]
        if baseline_terms
        else []
    )
    n_baseline_terms = len(baseline_columns)
    cids_mask = cids_mask[n_baseline_terms:]

    # get available CIDs from model functions
    available_cids = list(model_functions.keys())

    assert len(cids_mask) == len(available_cids)

    # empty model function to use if a CID is not requested
    empty_model_function = np.full_like(nu_array, np.nan, dtype=float)  # (mode,)

    # compute model columns - use dictionary comprehension to create a mapping
    # for all available CIDs, avoiding model function evaluation for CIDs not requested
    model_columns_dict = {
        cid: (model_functions[cid](nu_array) if cids_mask[i] else empty_model_function)
        for i, cid in enumerate(available_cids)
    }

    model_columns = [model_columns_dict[cid] for cid in available_cids]

    # Combine baseline and model columns and transpose to get shape (len(nu_array), n_components)
    return np.column_stack(baseline_columns + model_columns)


def _filter_valid_modes_time_block(
    spectrum: np.ndarray,
    spectral_error: np.ndarray,
    nu_prime: np.ndarray,
    threshold: float = Field(default=EMPTY_MODES_CHUNK_THRESHOLD, ge=0, lt=1),
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Filters the data from invalid modes.

    Invalid modes are defined as modes that have less than ``threshold``
    fraction of non-NaN values.

    Args:
        spectrum (np.ndarray): The spectrum to filter (time, mode).
        spectral_error (np.ndarray): The spectral error to filter (time, mode).
        nu_prime (np.ndarray): The nu_prime to filter (time, mode).
        threshold (float): The threshold for the fraction of non-NaN values.

    Returns:
        tuple[np.ndarray, np.ndarray, np.ndarray]:
            The filtered spectrum, spectral error, and nu_prime.
            Each array has shape (time, filtered_modes), where
            filtered_modes < modes, after filtering out the invalid modes.
    """
    # keep only modes that have at least 3% non-NaN value in the time block
    valid_modes_mask = _create_valid_modes_mask(spectrum=spectrum, threshold=threshold)

    # filter valid modes
    spectrum = spectrum[:, valid_modes_mask]
    spectral_error = spectral_error[:, valid_modes_mask]
    nu_prime = nu_prime[:, valid_modes_mask]
    return spectrum, spectral_error, nu_prime


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _retrieve_max_true_values(
    data: TimeseriesDataArray,
    fitter_dim: str = FITTER_VARNAME,
    time_dim: str = TIME_DIM,
) -> int:
    """Retrieve the maximum number of true values from a timeseries dataarray.

    This will help us determine the maximum number of predictors used, which we
    can compare to the number of modes available to check whether we can refit
    the data or not.

    First we sum over the fitter_var dimension to get the number of true values
    for each timestamp. Then we take the maximum over the _datetime dimension
    to get the maximum number of true values.

    Args:
        data (TimeseriesDataArray):
            TimeseriesDataArray with boolean values indicating
            whether the data is active or not.
            It has dimensions (_datetime, fitter_var).
        fitter_dim (str, optional):
            The dimension of the fitter variables. Defaults to ``FITTER_VARNAME``.
        time_dim (str, optional):
            The dimension of the time. Defaults to ``TIME_DIM``.

    Returns:
        int: The maximum number of true fitter variables across all timestamps.
    """
    return data.sum(dim=fitter_dim).max(dim=time_dim).compute().item()
