from typing import Callable, Optional

import numpy as np
import xarray as xr
from numpy.linalg import svd
from pydantic import Field, validate_call
from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from picarro_xarray.compute.least_squares.block_fitter import _lsq_fit_time_block
from picarro_xarray.compute.least_squares.fitter_mask import (
    _generate_default_fitter_mask,
)
from picarro_xarray.compute.least_squares.ridge_hyperparameter import (
    MethodType,
    estimate_ridge_parameter,
)
from picarro_xarray.compute.least_squares.utils import (
    _filter_and_weight_spectral_data,
)
from picarro_xarray.data_models.constants import CID_DIM, MODE_DIM, TIME_DIM
from picarro_xarray.data_models.data_types import TimeseriesDataArray


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def ridge_fit_xarray(
    spectrum: TimeseriesDataArray,
    spectrum_error: TimeseriesDataArray,
    wavenumber: TimeseriesDataArray,
    nu_center: TimeseriesDataArray,
    lsq_fitter: LinearLeastSquares,
    cid_fitter_mask: Optional[TimeseriesDataArray] = None,
    method: MethodType
    | Callable[[np.ndarray, np.ndarray], float] = "cross_validate_se",
    baseline_order: int = Field(default=1, ge=0, le=2),
    mode_dim: str = MODE_DIM,
    cid_dim: str = CID_DIM,
    time_dim: str = TIME_DIM,
    **kwargs,
) -> TimeseriesDataArray:
    """
    Fits the data from xarray DataArrays
    using a ridge regression fitter.

    Args:
        spectrum (TimeseriesDataArray):
            The spectrum to fit. It has shape (_datetime, mode).
            Example, ``ds.sel(spectral_var="partial_fit").spectral_values``
        spectrum_error (TimeseriesDataArray):
            Errors associated with spectrum values. It has shape (_datetime, mode).
        wavenumber (TimeseriesDataArray):
            The wavenumber values. It has shape (_datetime, mode).
            Example, ``ds.sel(spectral_var="nu_prime").spectral_values``
        nu_center (TimeseriesDataArray):
            The center wavenumber. It has shape (_datetime).
            Example, ``ds.sel(fitter_var="fitData_fitdata_params_nucenter").fitter_values``
        lsq_fitter (LinearLeastSquares):
            The least squares fitter to use. It is used to obtain the model functions.
        cid_fitter_mask (Optional[TimeseriesDataArray]):
            Boolean mask to tell the fitter which cids to fit at which time.
            It has shape (_datetime, cid).
            It can be generated from :py:func:`.mask_from_map`.
            If None (default), all cids in ``lsq_fitter`` are used at each time.
        method (MethodType | Callable[[np.ndarray, np.ndarray], float], optional):
            Method to use for estimation.
            For more details, see
            :py:func:`picarro_xarray.compute.least_squares.ridge_hyperparameter.estimate_ridge_parameter`.
            Can be either a string ('cross_validate_opt', 'cross_validate_se', 'l_curve', 'k4', 'hkb', or 'kb3') or
            a callable function with the signature ``f(X: np.ndarray, y: np.ndarray, **kwargs) -> float``
        baseline_order (int, optional):
            Order of the baseline. Defaults to 1 (offset + slope).
        mode_dim (str, optional): Name of the mode dimension. Defaults to ``MODE_DIM``.
        cid_dim (str, optional): Name of the cid dimension. Defaults to ``CID_DIM``.
        time_dim (str, optional): Name of the time dimension. Defaults to ``TIME_DIM``.
        **kwargs: Additional keyword arguments to pass to the hyper-parameter estimation method.

    Returns:
        xr.DataArray:
            DataArray of fitted values.
            It has shape (_datetime, cid).
            The cid coordinate can include offset and slope results.
    """
    output_keys = lsq_fitter.get_results_keys(baseline_order=baseline_order)[:-1]

    if cid_fitter_mask is None:
        cid_fitter_mask = _generate_default_fitter_mask(
            time_length=spectrum.sizes[time_dim],
            fitter_var_length=len(output_keys),
            cid_dim=cid_dim,
            time_dim=time_dim,
            compute=not spectrum.chunksizes,
            chunks={time_dim: spectrum.chunksizes.get(time_dim, -1)},
        )
        cid_fitter_mask[cid_dim] = output_keys

    if set(output_keys) != set(cid_fitter_mask.fitter_var.values):
        msg = (
            f"`fitter_var` coordinate values in `cid_fitter_mask` do not match "
            f"the `lsq_fitter` output keys. Expected {output_keys}, "
            f"found {list(cid_fitter_mask.fitter_var.values)}"
        )
        raise ValueError(msg)

    # temporary reference to fitter dim for fitter mask
    temp_dim = "temp_dim_name"

    output_keys += [f"{lsq_fitter.prefix}_rmse"]

    solver = np.vectorize(
        _ridge_fit_single_spectrum,
        excluded=["model_function_matrix", "method"],
        signature="(n),(n),(k)->(m)",  # k is m - 1 (without rmse)
    )

    results = xr.apply_ufunc(
        _lsq_fit_time_block,
        spectrum,
        spectrum_error,
        wavenumber,
        nu_center.reset_coords(drop=True),
        cid_fitter_mask.rename({cid_dim: temp_dim}),
        input_core_dims=[[mode_dim], [mode_dim], [mode_dim], [], [temp_dim]],
        output_core_dims=[[cid_dim]],
        vectorize=False,
        dask="parallelized",
        dask_gufunc_kwargs={
            "allow_rechunk": True,
            "output_sizes": {cid_dim: len(output_keys)},
        },
        kwargs={
            "lsq_fitter": lsq_fitter,
            "solver": solver,
            "method": method,
            **kwargs,
        },
        output_dtypes=[float],
    )
    results = results.assign_coords({cid_dim: (cid_dim, output_keys)})
    return results


def _ridge_fit_single_spectrum(
    spectrum: np.ndarray,
    error: np.ndarray,
    fitter_var_mask: np.ndarray,
    model_function_matrix: np.ndarray,
    method: MethodType | Callable,
    **kwargs,
) -> np.ndarray:
    """
    This is a ``Callable`` function that fits a
    single spectrum using singular value decomposition.
    The output is an array of concentration values.

    Args:
        spectrum (np.ndarray):
            Spectrum values (partial fit) of shape (mode).
        error (np.ndarray):
            Error associated with each spectrum value. It has shape (mode).
        fitter_var_mask (np.ndarray):
            Boolean mask, True for compounds to be fitted, False for compounds to ignore.
            It has shape (cid).
        model_function_matrix (np.ndarray):
            Design matrix of shape (mode, cid). Typically,
            also contains terms associated to the baseline offset and slope
        method (MethodType | Callable[[np.ndarray, np.ndarray], float]):
            Method to use for estimation.
            For more details, see
            :py:func:`picarro_xarray.compute.least_squares.ridge_hyperparameter.estimate_ridge_parameter`.
            Can be either a string ('cross_validate_opt', 'cross_validate_se', 'l_curve', 'k4', 'hkb', or 'kb3') or
            a callable function with the signature ``f(X: np.ndarray, y: np.ndarray, **kwargs) -> float``
    Returns:
        np.ndarray: Fitted values (concentrations) from the least squares operation.
    """
    y_matrix_weighted, y_data_weighted = _filter_and_weight_spectral_data(
        spectrum=spectrum,
        error=error,
        model_function_matrix=model_function_matrix[:, fitter_var_mask],
    )
    lambda_ = estimate_ridge_parameter(
        y_matrix_weighted, y_data_weighted, method=method, **kwargs
    )
    U, S, V = svd(y_matrix_weighted, full_matrices=False)
    d = S / (S**2 + lambda_)
    results = np.full(fitter_var_mask.shape, np.nan)
    results[fitter_var_mask] = V.T @ np.diag(d) @ U.T @ y_data_weighted
    return results
