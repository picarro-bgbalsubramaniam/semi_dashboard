"""
Error propagation rules for the sum, difference, product, and quotient of two quantities.
"""

import xarray as xr
from pydantic import validate_call


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def errors_quadrature(
    errors_1: xr.DataArray,
    errors_2: xr.DataArray,
) -> xr.DataArray:
    """
    Calculate the propagated uncertainty for the
    sum or difference of two quantities.

    This function computes the uncertainty in the sum or difference of two quantities
    when their uncertainties are known. It uses the quadratic sum rule for error propagation.
    The rule is used when the uncertainties are independent and random.

    Suppose that x and y are two quantities that are measured with uncertainties ``δx`` and ``δy``.
    The uncertainty can be expressed as a standard deviation or a standard error
    (just be consistent with quantities inside the formula).

    The sum or difference of the two quantities is then given by:

    .. math::

        q = x ± y

    And to estimate the uncertainty in the sum or difference, we use the quadratic sum rule:

    .. math::

        δq = \sqrt{δx^2 + δy^2}

    where ``δq`` is the propagated error for the sum or difference, and ``δx`` and ``δy``
    are the uncertainties of the individual quantities.

    Args:
        errors_1 (xr.DataArray):
           Uncertainty (standard deviation) associated with the first quantity (``δx``).
        errors_2 (xr.DataArray):
           Uncertainty (standard deviation) associated with the second quantity (``δy``).

    Returns:
        xr.DataArray:
           Propagated uncertainty for the sum or difference of the two quantities (``δq``).

    Example:

    >>> import numpy as np
    >>> err_1 = xr.DataArray([0.1, 0.8])
    >>> err_2 = xr.DataArray([0.2, 0.1])
    >>> expected = np.array([0.2236068, 0.80622577])
    >>> np.allclose(errors_quadrature(err_1, err_2).values, expected)
    True

    """
    errors_1_sq = errors_1**2
    errors_2_sq = errors_2**2

    return (errors_1_sq + errors_2_sq) ** 0.5


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def errors_product(
    errors_1: xr.DataArray,
    means_1: xr.DataArray,
    errors_2: xr.DataArray,
    means_2: xr.DataArray,
    means_result: xr.DataArray,
):
    """
    Calculate the propagated uncertainty for the product or quotient of two quantities.

    This function computes the uncertainty in the product or quotient
    of two quantities based on their individual uncertainties and means.
    When the uncertainties of two quantities are known and are independent and random,
    the fractional uncertainty in their product is the sum in quadrature of the original
    fractional uncertainties.
    The formula is derived from the general principle of error propagation for products and quotients.

    Let ``δx`` and ``δy`` be the uncertainties, and ``x`` and ``y`` be the means of the quantities.
    The uncertainty can be expressed as a standard deviation or a standard error
    (just be consistent with quantities inside the formula).

    The product or quotient of the two quantities is then given by:

    .. math::
        q = x \cdot y  \qquad \\text{or} \qquad q = x / y

    Where q is the product or quotient of the two quantities.
    The fractional uncertainties are ``(δx/x)`` and ``(δy/y)``.
    The propagated uncertainty for the product is given by:

    .. math::

        δq = q * \sqrt{ (δx/x)^2 + (δy/y)^2 }

    Args:
        errors_1 (xr.DataArray): Uncertainty associated with the first quantity (``δx``).
        means_1 (xr.DataArray): Mean of the first quantity (``x``).
        errors_2 (xr.DataArray): Uncertainty associated with the second quantity (``δy``).
        means_2 (xr.DataArray): Mean of the second quantity (``y``).
        means_result (xr.DataArray):
           Product or quotient of the two quantities (``q = x * y`` or ``q = x / y``).

    Returns:
        xr.DataArray:
           Propagated uncertainty for the product of the two quantities (``δq``).

    Note:
        This function utilizes the :func:`errors_quadrature` function for
        computing the sum in quadrature of fractional uncertainties.
    """
    ratios_1_sq = errors_1 / means_1
    ratios_2_sq = errors_2 / means_2
    quadrature_err = errors_quadrature(ratios_1_sq, ratios_2_sq)
    return means_result * quadrature_err
