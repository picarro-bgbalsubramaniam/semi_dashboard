from typing import Optional

from pydantic import validate_call

from picarro_xarray.compute.spectral_operations.operations import (
    Operation,
    OperationFactory,
)
import xarray as xr

from picarro_xarray.data_models.constants import TIME_DIM, COUNT_DIM
from picarro_xarray.data_models.data_types import TimeseriesDataArray
from picarro_xarray.logger.logger import get_logger

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _prepare_operators(
    mean_1: xr.DataArray,
    mean_2: xr.DataArray | int | float,
    errors_1: xr.DataArray,
    errors_2: Optional[xr.DataArray] = None,
    time_dim: str = TIME_DIM,
    count_coord: str = COUNT_DIM,
) -> tuple[xr.DataArray, xr.DataArray, xr.DataArray, xr.DataArray]:
    """
    Prepares the operands for mathematical operations.

    This function adjusts the second mean and error operands,
    ensuring that they are compatible with the first ones for subsequent operations.
    It converts scalar means to arrays and assigns zero-error
    if no errors are provided for the second operand.

    If the second mean is a scalar, the second error does not
    have count coordinate.

    Args:
        mean_1 (xr.DataArray):
            The first operand representing mean values.
        mean_2 (xr.DataArray | int | float):
            The second operand representing mean values, which can be a scalar.
        errors_1 (xr.DataArray):
            The errors corresponding to the first operand.
        errors_2 (Optional[xr.DataArray]):
            The errors corresponding to the second operand.
            If None, it is assumed there are no errors
            on this measure.
        time_dim (str):
            The key for the time dimension expected in the data arrays.
            The default is ``TIME_DIM``.
        count_coord (str):
            The key for the count coordinate expected in the data arrays.
            The default is COUNT_DIM.

    Returns:
        tuple[xr.DataArray, xr.DataArray, xr.DataArray, xr.DataArray]:
            A tuple containing adjusted mean_1, mean_2, errors_1, and errors_2.

    """
    if isinstance(mean_2, (int, float)):
        msg = "Operation requested on a constant. Expand the constant to an array."
        LOGGER.debug(msg)
        mean_2 = xr.ones_like(mean_1).isel({time_dim: 0}).expand_dims(time_dim) * mean_2

    if errors_2 is None:
        msg = "No errors provided for second operand. Using zeros."
        LOGGER.debug(msg)
        errors_2 = xr.zeros_like(errors_1).isel({time_dim: 0}).expand_dims(time_dim)
        errors_2 = errors_2.drop_vars(count_coord)  # A scalar error has no count coordinate

    return mean_1, mean_2, errors_1, errors_2


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _check_and_cast_dimensions(
    mean_1: xr.DataArray,
    mean_2: xr.DataArray,
    errors_1: xr.DataArray,
    errors_2: xr.DataArray,
    time_dim: str = TIME_DIM,
) -> tuple[xr.DataArray, xr.DataArray, xr.DataArray, xr.DataArray]:
    """
    Validates and adjusts the time dimension of the operands.

    This function checks that the second mean and error data arrays
    have a time_dim size of 1.
    If the condition is not met, it raises a ValueError.
    If the condition is met, it removes the singular time dimension (if present)
    for easier arithmetic operations through broadcasting.

    Args:
        mean_1 (xr.DataArray):
            The first operand, representing the mean values for the first dataset.
        mean_2 (xr.DataArray):
            The second operand, representing the mean values for the second dataset.
            It shall have a time dimension of size 1.
        errors_1 (xr.DataArray):
            The errors corresponding to the first operand.
        errors_2 (xr.DataArray):
            The errors corresponding to the second operand.
            It shall have a time dimension of size 1.
        time_dim (str):
            The key for the time dimension expected in the data arrays.
            The default is ``TIME_DIM``.

    Returns:
        tuple[xr.DataArray, xr.DataArray]:
           A tuple containing the potentially modified mean_1 and mean_2,
           along with the original errors_1 and errors_2.

    Raises:
        ValueError: If mean_2 or errors_2 has more than one time point in the time dimension.
    """

    if (mean_2.sizes[time_dim] != 1) | (errors_2.sizes[time_dim] != 1):
        msg = ("Second operand of a spectral operation shall "
               "be a compact dataset with length 1"
               " along the datetime dimension.")
        raise ValueError(msg)

    mean_2 = mean_2.squeeze(time_dim)
    errors_2 = errors_2.squeeze(time_dim)
    return mean_1, mean_2, errors_1, errors_2


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def operation_dispatcher(
    operation: Operation,
    mean_1: TimeseriesDataArray,
    mean_2: TimeseriesDataArray | int | float,
    errors_1: TimeseriesDataArray,
    errors_2: Optional[TimeseriesDataArray] = None,
) -> tuple[TimeseriesDataArray, TimeseriesDataArray]:
    """
    Performs a mathematical operation on the input operands.

    This function first prepares the operands by calling the internal
    `_prepare_operators` function and then performs the specified operation on them.
    The operation is executed by a function retrieved from the OperationFactory.

    A SpectralTimeseriesDataArray is a xarray DataArray with
    a spectral_var dimension and a time dimension.

    Args:
        operation (Operation):
            The operation to be performed on the operands.
        mean_1 (TimeseriesDataArray):
            The first operand representing mean values.
        mean_2 (TimeseriesDataArray | int | float):
            The second operand representing mean values, which can be a scalar.
        errors_1 (TimeseriesDataArray):
            The errors corresponding to the first operand.
        errors_2 (Optional[TimeseriesDataArray]):
            The errors corresponding to the second operand.
            If None, it is assumed there are no errors associated to this measure.

    Returns:
        tuple[xr.DataArray, xr.DataArray]:
            A tuple containing the results of the operation on the means and the errors.

    """

    mean_1, mean_2, errors_1, errors_2 = _prepare_operators(
        mean_1=mean_1,
        mean_2=mean_2,
        errors_1=errors_1,
        errors_2=errors_2,
    )

    mean_1, mean_2, errors_1, errors_2 = _check_and_cast_dimensions(
        mean_1=mean_1,
        mean_2=mean_2,
        errors_1=errors_1,
        errors_2=errors_2,
    )

    operation_function = OperationFactory.create_operation(operation)
    return operation_function(mean_1, mean_2, errors_1, errors_2)
