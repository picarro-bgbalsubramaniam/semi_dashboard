import functools
from collections import defaultdict
from typing import Type

from pydantic import validate_call
import xarray as xr

from picarro_xarray.compute.spectral_operations.operations import Operation
from picarro_xarray.logger.logger import get_logger

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_default_spectral_operation_map(
    operation: Operation,
    second_operator_type: Type,
    variables: list[str],
    nu_vars: list[str],
    npoints_vars: list[str],
) -> dict[Operation, list[str]]:
    """
    Determine the mapping of operations to spectral variables based on the type
    of the second operator.

    Examples:

    >>> res = _get_default_spectral_operation_map(
    ...     operation=Operation.SUM,
    ...     second_operator_type=int,
    ...     variables=["partial_fit", "absorbance"],
    ...     nu_vars=["nu"],
    ...     npoints_vars=["npoints"],
    ... ) # doctest: +NORMALIZE_WHITESPACE +ELLIPSIS
    >>> assert set(res[Operation.PASSTHROUGH]) == {"nu", "npoints"}
    >>> assert set(res[Operation.SUM]) == {"partial_fit", "absorbance"}

    Args:
        operation (Operation): The operation to be performed. This operation
            applies to variables other than nu_vars and npoints_vars.
        second_operator_type (Type): The type of the second operator in the
            operation. It determines the kind of operation to apply to the
            spectral variables. Acceptable types are int, float, xr.DataArray,
            and xr.Dataset.
        variables (List[str]): List of all spectral variables involved in
            the operation.
        nu_vars (List[str]): List of nu variables. These are treated separately
            based on the second operator's type.
        npoints_vars (List[str]): List of npoints variables. These are treated
            separately based on the second operator's type.

    Returns:
        Dict[Operation, List[str]]:
            A dictionary mapping operations to the spectral variables they apply to.

    Raises:
        NotImplementedError: Raises if the second operator type is not among the
            supported types (int, float, xr.DataArray, xr.Dataset).
    """
    other_spectral_vars = list(set(variables).difference(nu_vars, npoints_vars))

    operation_map = defaultdict(list)

    if second_operator_type in (int, float):
        operation_map[Operation.PASSTHROUGH].extend(nu_vars + npoints_vars)
        operation_map[operation].extend(other_spectral_vars)
    elif second_operator_type in (xr.DataArray, xr.Dataset):
        operation_map[Operation.UNION].extend(nu_vars)
        operation_map[Operation.MINIMUM].extend(npoints_vars)
        operation_map[operation].extend(other_spectral_vars)
    else:
        raise NotImplementedError(
            f"Second operator type {second_operator_type} not supported"
        )
    LOGGER.debug(f"Spectral operation map: {operation_map}")
    return dict(operation_map)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_default_fitter_operation_map(
    operation: Operation,
    second_operator_type: Type,
    variables: list[str],
) -> dict[Operation, list[str]]:
    """
    Determine the mapping of operations to fitter variables based on the type
    of the second operator.

    Args:
        operation (Operation):
            The operation to be performed.
        second_operator_type (Type): The type of the second operator in the
            operation. It determines the kind of operation to apply to the
            fitter variables. Acceptable types are int, float, xr.DataArray,
            and xr.Dataset.
        variables (List[str]):
            List of all fitter variables involved in
            the operation.
    Returns:
        Dict[Operation, List[str]]:
            A dictionary mapping operations to the fitter variables they apply to.

    Raises:
        NotImplementedError: Raises if the second operator type is not among the
            supported types (int, float, xr.DataArray, xr.Dataset).
    """
    operation_map = dict()

    if second_operator_type not in (xr.DataArray, xr.Dataset, int, float):
        raise NotImplementedError(
            f"Second operator type {second_operator_type} not supported."
            f" Only int, float, Xarray DataArray, Xarray Dataset are supported."
        )

    operation_map[operation] = variables
    LOGGER.debug(f"Fitter operation map: {operation_map}")
    return operation_map


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _fill_operation_map_with_default(
    operation_map: dict[Operation, list[str]],
    required_variables: list[str],
    default_operation: Operation = Operation.UNION,
) -> dict[Operation, list[str]]:
    """
    Fills in the operation map with default operations for any missing variables.

    This function ensures all required variables are associated with some operation.
    If any are missing in the operation map, they are added with a default operation.

    Missing variables are logged as a warning.

    Args:
        operation_map (dict[Operation, list[str]]):
            A dictionary mapping operations to lists of variable names.
        required_variables (list[str]):
            A list of all variables that need operations.
        default_operation (Operation, optional):
            The operation to assign to variables missing from the operation map.
            Defaults to Operation.UNION.

    Returns:
        dict[Operation, list[str]]:
            The updated operation map, now including all required variables.
    """
    operation_variables = set(
        val for sublist in operation_map.values() for val in sublist
    )

    operation_map = defaultdict(list, operation_map)

    if not set(required_variables).issubset(operation_variables):
        variables_not_found = list(
            set(required_variables).difference(operation_variables)
        )
        operation_map[default_operation].extend(variables_not_found)
        msg = (
            f"Variables {variables_not_found} were present in the dataset but "
            f"were not found in operation map. "
            f"Using default operation {default_operation} for these variables."
        )
        LOGGER.warning(msg)

    return dict(operation_map)


def parse_operation(
    operation: Operation | dict[Operation, list[str]],
    second_operator_type: Type,
    is_spectral_operation: bool,
    required_variables: list[str],
    nu_vars: list[str],
    npoints_vars: list[str],
    default_operation: Operation = Operation.UNION,
) -> dict[Operation, list[str]]:
    """
    Parses the operation input and determines the appropriate operation map.

    Depending on the type of operation (spectral or not),
    this function delegates the generation of the operation map to the respective default map function.
    It handles both singular operations and dictionaries of operations.

    Args:
        operation (Operation | dict[Operation, list[str]]):
            The operation(s) to parse. This can either be a
            singular operation or a dictionary mapping operations to variables.
        second_operator_type (Type):
            The type of the second operand in the operation.
        is_spectral_operation (bool):
            A flag indicating if the operation is on spectra.
        required_variables (list[str]):
            A list of variables required for the operation.
        nu_vars (list[str]):
            Variables for the nu dimension in spectra, if relevant.
        npoints_vars (list[str]):
            Variables for the number of points in spectra, if relevant.
        default_operation (Operation, optional):
            The default operation to use for any variables not explicitly
            included in an operation map. Defaults to Operation.UNION.

    Returns:
        dict[Operation, list[str]]: A dictionary mapping operations to lists of variables.

    Raises:
        NotImplementedError: If the operation type is not supported.
    """

    _get_default_spectral_operation_map_preset = functools.partial(
        _get_default_spectral_operation_map, nu_vars=nu_vars, npoints_vars=npoints_vars
    )

    get_default_map = (
        _get_default_spectral_operation_map_preset
        if is_spectral_operation
        else _get_default_fitter_operation_map
    )

    if isinstance(operation, Operation):
        return get_default_map(
            operation=operation,
            second_operator_type=second_operator_type,
            variables=required_variables,
        )
    elif isinstance(operation, dict):
        return _fill_operation_map_with_default(
            operation_map=operation,
            required_variables=required_variables,
            default_operation=default_operation,
        )
    else:
        raise NotImplementedError(f"Operation type {type(operation)} not supported")
