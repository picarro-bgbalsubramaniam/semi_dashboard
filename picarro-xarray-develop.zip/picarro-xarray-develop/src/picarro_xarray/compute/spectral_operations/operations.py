from enum import Enum

import numpy as np
import xarray as xr

from picarro_xarray.compute.spectral_operations.error_propagation import (
    errors_product,
    errors_quadrature,
)
from picarro_xarray.data_models.constants import COUNT_DIM, TIME_DIM


class Operation(Enum):
    """Enumeration of supported spectral operations.

    This enum defines the various mathematical operations that can be performed
    on spectral data arrays, including arithmetic operations, set operations,
    and statistical operations.
    """

    SUM = "sum"
    DIFFERENCE = "difference"
    PRODUCT = "product"
    DIVISION = "division"
    UNION = "union"  # a "mean" operation where all modes/frequencies are kept
    INTERSECTION = "intersection"  # a "mean" operation where only modes/frequencies present in both arrays are kept
    MINIMUM = "minimum"
    MAXIMUM = "maximum"
    ARITHMETIC_MEAN = "arithmetic_mean"
    PASSTHROUGH = "passthrough"


class OperationFactory:
    @staticmethod
    def create_operation(operation: Operation):
        match operation:
            case Operation.SUM:
                return _perform_sum
            case Operation.DIFFERENCE:
                return _perform_difference
            case Operation.PRODUCT:
                return _perform_product
            case Operation.DIVISION:
                return _perform_division
            case Operation.UNION:
                return _perform_union
            case Operation.INTERSECTION:
                return _perform_intersection
            case Operation.MINIMUM:
                return _perform_minimum
            case Operation.MAXIMUM:
                return _perform_maximum
            case Operation.ARITHMETIC_MEAN:
                return _perform_arithmetic_mean
            case Operation.PASSTHROUGH:
                return _perform_passthrough
            case _:
                raise NotImplementedError(f"Unsupported operation: {operation}")


def _merge_compact(
    mean_da: xr.DataArray,
    error_da: xr.DataArray,
    time_dim: str = TIME_DIM,
    count_coord: str = COUNT_DIM,
    error_used: str = "std_err",
) -> tuple[xr.DataArray, xr.DataArray]:
    """
    Merges compactified data arrays along the time dimension.

    The merged data array has a time dimension of length 1.
    It proceeds by calculating the weighted mean of the input data arrays,
    using the error associated with the ``error_used`` error type,
    exactly like the :py:func:`_perform_weighted_mean` function.

    Args:
        mean_da (xr.DataArray):
            Data array containing the mean values.
        error_da (xr.DataArray):
            Data array containing the error values.
        time_dim (str, optional):
            Name of the time dimension. Defaults to ``TIME_DIM``.
        count_coord (str, optional):
            Name of the coordinate in the error DataArray containing the count of samples.
            Defaults to ``COUNT_DIM``. Used to address the case where the error is
            zero (and the weight infinite), and the weighted mean operation would
            be undefined. In that case, the count is used as a weight.
        error_used (str, optional):
            Type of error to use for the weighted mean. Defaults to ``std_err``.

    Returns:
        tuple[xr.DataArray, xr.DataArray]:
            A tuple of two xarray DataArrays containing the compactified mean and error.
    """
    if count_coord not in error_da.coords:
        raise ValueError(
            f"Error array error_da for weighted average "
            f"must have a '{count_coord}' coordinate."
        )

    weights = 1 / error_da**2

    # use counts if any weights are infinite
    weights_selected = weights.sel(stat=error_used)
    use_counts_condition = np.isinf(weights_selected).any(dim=time_dim).load()
    weights_use = weights_selected[count_coord].where(
        use_counts_condition, weights_selected
    )

    result_mean = (weights_use * mean_da).sum(dim=time_dim) / weights_use.sum(
        dim=time_dim
    )
    error = weights.sum(dim=time_dim) ** -0.5

    result_mean = result_mean.expand_dims(dim=time_dim)
    error = error.expand_dims(dim=time_dim)

    return result_mean, error


def _get_weights_for_weighted_average(
    weights_1: xr.DataArray,
    weights_2: xr.DataArray,
    time_dim: str = TIME_DIM,
    count_coord: str = COUNT_DIM,
) -> tuple[xr.DataArray, xr.DataArray]:
    """
    Calculates the adjusted weights for the weighted average calculation.

    If any weight for a variable along the time dimension is infinite
    (which happens when the sample standard error is zero),
    this function replaces the weights for that variable with the count of samples
    along the time dimension, allowing the calculation to proceed with count-based weighting
    in these cases.

    This ensures that the weighted average calculation is well-defined
    also for operations between variables that are constants in time
    (i.e., they have standard deviation and standard error equal to zero)

    The presence of infinite weights is expected in cases where the sample standard errors
    are zero, as the weights are calculated as the inverse of the square of the errors.
    In that case, the weights are infinite, and the weighted average calculation would
    be undefined. By replacing the infinite weights with the count, the calculation
    proceeds as a weighted average based on the number of samples.

    ``Weights_2`` can lack the dimension ``count_coord``: this happens when an operation
    between a dataset and a scalar was requested. The scalar does not have an associated
    count. In that case, the count from ``weights_1`` is used.

    Args:
        weights_1 (xr.DataArray):
            Weights associated with the first dataset. Expecting
            non-negative values, with possible infinities.
            Shall have a count coordinate.
        weights_2 (xr.DataArray):
            Weights associated with the second dataset.
            Can have infinite values.
        time_dim (str, optional):
            Name of the time dimension used in weights DataArrays.
            Defaults to ``TIME_DIM``.
        count_coord (str, optional):
            Name of the coordinate in the weights DataArrays
            containing the count of samples. This is used for
            replacing infinite weights. This coordinate has dimensions ``TIME_DIM``.
            Defaults to ``COUNT_DIM``.

    Returns:
        tuple[xr.DataArray, xr.DataArray]:
            A tuple of two xarray DataArrays containing
            the adjusted weights for each original input
            weights DataArray.

    Raises:
        ValueError:
            If weights_1 DataArray does not contain the 'count' coordinate.
            This does not happen if the dataarray is the result of the compactify operation.
    """
    if count_coord not in weights_1.coords:
        raise ValueError(
            f"Weights array weights_1 for weighted average "
            f"must have a '{count_coord}' coordinate."
        )

    if count_coord not in weights_2.coords:
        # A scalar error has no count coordinate, take it from the first array
        weights_2 = weights_2.expand_dims(dim={time_dim: weights_1[time_dim].values})
        weights_2[count_coord] = weights_1[count_coord]

    infinite_1 = np.isinf(weights_1)
    infinite_2 = np.isinf(weights_2)

    use_counts_condition = infinite_1.any(dim=time_dim) | infinite_2
    use_counts_condition.load()  # load needed, to use this in the where statement

    weights_1_use = weights_1[count_coord].where(use_counts_condition, weights_1)
    weights_2_use = weights_2[count_coord].where(use_counts_condition, weights_2)

    return weights_1_use, weights_2_use


def _perform_weighted_mean(
    mean_1: xr.DataArray,
    mean_2: xr.DataArray,
    errors_1: xr.DataArray,
    errors_2: xr.DataArray,
    error_used: str = "std_err",
    shared_frequencies_only: bool = True,
    count_coord: str = COUNT_DIM,
) -> tuple[xr.DataArray, xr.DataArray]:
    """
    Compute the weighted mean of two quantities.

    This function calculates the weighted average of two measurements taking into account
    their uncertainties.
    Each measurement is weighted by the inverse of the square of its uncertainty.

    Let ``x_1`` and ``x_2`` be the means, and ``δ_1`` and ``δ_2`` be the uncertainties of the measurements.
    The weights for each measurement, ``w_1`` and ``w_2``, are computed as

    .. math::
        w_i = 1 / δ_i^2 \\quad \\text{for } i=1,2


    The weighted mean is given by

    .. math::
        x_{wav} = (w_1*x_1 + w_2*x_2) / (w_1 + w_2)

    The combined uncertainty is the reciprocal square root of the sum of the individual weights

    .. math::
        σ_{wav} = \\sqrt{1/(w_1 + w_2)}


    If errors are zero for any variable along the time axis,
    the weights are infinite, and the weighted average calculation would
    be undefined. In that case, the weights are replaced with the count of samples,
    allowing the calculation to proceed with count-based weighting in these cases.

    If ``errors_2`` does not have a count coordinate, it is assumed that it
    is a scalar operation, and the error from ``error_1`` is propagated.

    Args:
        mean_1 (xr.DataArray): Mean of the first measurement (x_1).
        mean_2 (xr.DataArray): Mean of the second measurement (x_2).
        errors_1 (xr.DataArray): Uncertainty associated with the first measurement (δ_1).
        errors_2 (xr.DataArray): Uncertainty associated with the second measurement (δ_2).
        error_used (str, optional): Type of uncertainty to use for the weighted mean. Defaults to ``std_err``.
        shared_frequencies_only (bool, optional):
            If True, only modes (frequencies) present in both measurements
            mean_1 and mean_2 are used.
            If False, all modes (frequencies) are used, regardless of whether they are present
            in both measurements or not.
            Defaults to True.
        count_coord (str, optional):
            Name of the coordinate in the error DataArrays containing the count of samples.
            Defaults to ``COUNT_DIM``.

    Returns:
        tuple:
            - xr.DataArray: Weighted mean of the two measurements (``x_wav``).
            - xr.DataArray: Combined uncertainty for the weighted mean (``σ_wav``).
    """

    if shared_frequencies_only:
        mean_1, mean_2 = xr.align(mean_1, mean_2, join="inner")
        errors_1, errors_2 = xr.align(errors_1, errors_2, join="inner")
    else:
        mean_1, mean_2 = xr.align(mean_1, mean_2, join="outer")
        errors_1, errors_2 = xr.align(errors_1, errors_2, join="outer")

    weights_1 = 1 / errors_1**2
    weights_2 = 1 / errors_2**2

    weight_1_for_averaging, weight_2_for_averaging = _get_weights_for_weighted_average(
        weights_1=weights_1.sel(stat=error_used),
        weights_2=weights_2.sel(stat=error_used),
    )

    result_mean = (
        weight_1_for_averaging * mean_1 + weight_2_for_averaging * mean_2
    ) / (weight_1_for_averaging + weight_2_for_averaging)

    if count_coord not in weights_2.coords:
        # It is a scalar operation, just propagate first error
        error = errors_1
    else:
        error = (weights_1 + weights_2) ** -0.5

    return result_mean, error


def _perform_union(
    mean_1: xr.DataArray,
    mean_2: xr.DataArray,
    errors_1: xr.DataArray,
    errors_2: xr.DataArray,
    error_used: str = "std_err",
):
    """
    Performs the union of two data arrays.
    The union is the mean of the two data arrays,
    with all modes (frequencies) present in either data array.

    Args:
        mean_1 (xr.DataArray): The first data array.
        mean_2 (xr.DataArray): The second data array.
        errors_1 (xr.DataArray): The error associated with the first data array.
        errors_2 (xr.DataArray): The error associated with the second data array.
        error_used (str, optional): The type of error used. Defaults to ``std_err``.

    Returns:
        tuple[xr.DataArray, xr.DataArray]:
            The union of the two data arrays and the associated error.
    """
    return _perform_weighted_mean(
        mean_1=mean_1,
        mean_2=mean_2,
        errors_1=errors_1,
        errors_2=errors_2,
        error_used=error_used,
        shared_frequencies_only=False,
    )


def _perform_intersection(
    mean_1: xr.DataArray,
    mean_2: xr.DataArray,
    errors_1: xr.DataArray,
    errors_2: xr.DataArray,
    error_used: str = "std_err",
):
    """
    Performs the intersection of two data arrays.
    The intersection is the mean of the two data arrays,
    with only modes (frequencies) present in both data arrays.

    Args:
        mean_1 (xr.DataArray): The first data array.
        mean_2 (xr.DataArray): The second data array.
        errors_1 (xr.DataArray): The error associated with the first data array.
        errors_2 (xr.DataArray): The error associated with the second data array.
        error_used (str, optional): The type of error used. Defaults to ``std_err``.

    Returns:
        tuple[xr.DataArray, xr.DataArray]:
            The intersection of the two data arrays and the associated error.
    """

    return _perform_weighted_mean(
        mean_1=mean_1,
        mean_2=mean_2,
        errors_1=errors_1,
        errors_2=errors_2,
        error_used=error_used,
        shared_frequencies_only=True,
    )


def _perform_sum(
    mean_1: xr.DataArray,
    mean_2: xr.DataArray,
    errors_1: xr.DataArray,
    errors_2: xr.DataArray,
):
    """
    Computes the sum of two data arrays.

    Args:
        mean_1 (xr.DataArray): The first data array.
        mean_2 (xr.DataArray): The second data array.
        errors_1 (xr.DataArray): The error associated with the first data array.
        errors_2 (xr.DataArray): The error associated with the second data array.

    Returns:
        tuple[xr.DataArray, xr.DataArray]: The sum of the two data arrays and the combined error.
    """
    result_sum = mean_1 + mean_2
    error = errors_quadrature(errors_1=errors_1, errors_2=errors_2)
    return result_sum, error


def _perform_difference(
    mean_1: xr.DataArray,
    mean_2: xr.DataArray,
    errors_1: xr.DataArray,
    errors_2: xr.DataArray,
) -> tuple[xr.DataArray, xr.DataArray]:
    """
    Computes the difference of two data arrays.

    Args:
        mean_1 (xr.DataArray): The first data array.
        mean_2 (xr.DataArray): The second data array.
        errors_1 (xr.DataArray): The error associated with the first data array.
        errors_2 (xr.DataArray): The error associated with the second data array.

    Returns:
        tuple[xr.DataArray, xr.DataArray]:
            The difference of the two data arrays and the combined error.
    """
    result_sum = mean_1 - mean_2
    error = errors_quadrature(errors_1=errors_1, errors_2=errors_2)
    return result_sum, error


def _perform_product(
    mean_1: xr.DataArray,
    mean_2: xr.DataArray,
    errors_1: xr.DataArray,
    errors_2: xr.DataArray,
) -> tuple[xr.DataArray, xr.DataArray]:
    """
    Computes the product of two data arrays.

    Args:
        mean_1 (xr.DataArray): The first data array.
        mean_2 (xr.DataArray): The second data array.
        errors_1 (xr.DataArray): The error associated with the first data array.
        errors_2 (xr.DataArray): The error associated with the second data array.

    Returns:
        tuple[xr.DataArray, xr.DataArray]:
            The product of the two data arrays and the combined error.
    """
    result_product = mean_1 * mean_2
    error = errors_product(
        errors_1=errors_1,
        means_1=mean_1,
        errors_2=errors_2,
        means_2=mean_2,
        means_result=result_product,
    )
    return result_product, error


def _perform_division(
    mean_1: xr.DataArray,
    mean_2: xr.DataArray,
    errors_1: xr.DataArray,
    errors_2: xr.DataArray,
) -> tuple[xr.DataArray, xr.DataArray]:
    """
    Computes the division of two data arrays.

    Args:
        mean_1 (xr.DataArray): The first data array.
        mean_2 (xr.DataArray): The second data array.
        errors_1 (xr.DataArray): The error associated with the first data array.
        errors_2 (xr.DataArray): The error associated with the second data array.

    Returns:
        tuple[xr.DataArray, xr.DataArray]:
            The division of the two data arrays and the combined error.
    """
    result_div = mean_1 / mean_2
    error = errors_product(
        errors_1=errors_1,
        means_1=mean_1,
        errors_2=errors_2,
        means_2=mean_2,
        means_result=result_div,
    )
    return result_div, error


def _perform_minimum(
    mean_1: xr.DataArray,
    mean_2: xr.DataArray,
    errors_1: xr.DataArray,
    errors_2: xr.DataArray,
) -> tuple[xr.DataArray, xr.DataArray]:
    """
    Calculates the element-wise minimum between two data arrays
    and selects the corresponding errors.

    This function compares the mean values in two data arrays and
    selects the minimum value at each position.
    It then chooses the error from the array which had the minimum mean value.
    The operation is performed element-wise.

    Args:
        mean_1 (xr.DataArray): The first data array containing mean values.
        mean_2 (xr.DataArray): The second data array containing mean values.
        errors_1 (xr.DataArray): The errors corresponding to the first mean data array.
        errors_2 (xr.DataArray): The errors corresponding to the second mean data array.

    Returns:
        tuple[xr.DataArray, xr.DataArray]:
            A tuple containing the data array of minimum values and the
            corresponding errors, both selected element-wise.
    """
    condition = mean_1 < mean_2
    result = xr.where(condition, mean_1, mean_2)
    error = xr.where(condition, errors_1, errors_2)
    return result, error


def _perform_maximum(
    mean_1: xr.DataArray,
    mean_2: xr.DataArray,
    errors_1: xr.DataArray,
    errors_2: xr.DataArray,
) -> tuple[xr.DataArray, xr.DataArray]:
    """
    Calculates the element-wise maximum between two data arrays and selects the corresponding errors.

    This function compares the mean values in two data arrays and selects the maximum
    value at each position. It then chooses the error from the array which had the maximum value.
    The operation is performed element-wise.

    Args:
        mean_1 (xr.DataArray): The first data array containing mean values.
        mean_2 (xr.DataArray): The second data array containing mean values.
        errors_1 (xr.DataArray): The errors corresponding to the first mean data array.
        errors_2 (xr.DataArray): The errors corresponding to the second mean data array.

    Returns:
        tuple[xr.DataArray, xr.DataArray]:
            A tuple containing the data array of maximum values and the
            corresponding errors, both selected element-wise.
    """
    condition = mean_1 > mean_2
    result = xr.where(condition, mean_1, mean_2)
    error = xr.where(condition, errors_1, errors_2)
    return result, error


def _perform_arithmetic_mean(
    mean_1: xr.DataArray,
    mean_2: xr.DataArray,
    errors_1: xr.DataArray,
    errors_2: xr.DataArray,
):
    """
    Computes the arithmetic mean of two data arrays.

    Args:
        mean_1 (xr.DataArray): The first data array.
        mean_2 (xr.DataArray): The second data array.
        errors_1 (xr.DataArray): The error associated with the first data array.
        errors_2 (xr.DataArray): The error associated with the second data array.

    Returns:
        tuple[xr.DataArray, xr.DataArray]:
            The arithmetic mean of the two data arrays and the combined error.
    """
    result, error = _perform_sum(
        mean_1=mean_1,
        mean_2=mean_2,
        errors_1=errors_1,
        errors_2=errors_2,
    )
    result /= 2
    return result, error


def _perform_passthrough(
    mean_1: xr.DataArray,
    mean_2: xr.DataArray,
    errors_1: xr.DataArray,
    errors_2: xr.DataArray,
) -> tuple[xr.DataArray, xr.DataArray]:
    """
    Passthrough the first array and its error.

    Args:
        mean_1 (xr.DataArray): The first data array.
        mean_2 (xr.DataArray): The second data array.
        errors_1 (xr.DataArray): The error associated with the first data array.
        errors_2 (xr.DataArray): The error associated with the second data array.

    Returns:
        tuple[xr.DataArray, xr.DataArray]:
           The first data array and error.
    """
    return mean_1, errors_1
