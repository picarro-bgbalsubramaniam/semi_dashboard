from collections import namedtuple

import xarray as xr
from pydantic import validate_call

from picarro_xarray.compute.spectral_operations.calculator import operation_dispatcher
from picarro_xarray.compute.spectral_operations.operations import (
    Operation,
    _merge_compact,
)
from picarro_xarray.compute.spectral_operations.operations_mapping import (
    parse_operation,
)
from picarro_xarray.data_models.constants import NPOINTS, NU_VARS, TIME_DIM
from picarro_xarray.data_models.data_types import CompactDataSet
from picarro_xarray.logger.logger import get_logger

LOGGER = get_logger(__name__)


# Define a namedtuple type with specified field names.
CompactVariableType = namedtuple(
    "CompactVariableType",
    ["MEAN_VARIABLE_NAME", "ERROR_VARIABLE_NAME", "COORDINATE_INDEXER_NAME"],
)

SPECTRAL = CompactVariableType(
    MEAN_VARIABLE_NAME="spectral_values",
    ERROR_VARIABLE_NAME="spectral_values_stats",
    COORDINATE_INDEXER_NAME="spectral_var",
)

FITTER = CompactVariableType(
    MEAN_VARIABLE_NAME="fitter_values",
    ERROR_VARIABLE_NAME="fitter_values_stats",
    COORDINATE_INDEXER_NAME="fitter_var",
)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def merge_compact(
    operand: CompactDataSet,
) -> CompactDataSet:
    """
    Merges a compact dataset along the time dimension.

    The merged dataset has a time dimension of length 1.
    The operation proceeds by calculating the weighted mean
    of the input data arrays, using the error associated with the ``std_err``
    error type.

    Args:
        operand (CompactDataSet):
            The compact dataset to merge.

    Returns:
        CompactDataSet:
            A compact dataset with the same time dimension as the input dataset,
            but with only one time point.
    """
    # the result dataset will have only one time point
    result_ds = operand.isel(_datetime=[0]).copy()

    mean_fv, errors_fv = operand.fitter_values, operand.fitter_values_stats
    mean_sv, errors_sv = operand.spectral_values, operand.spectral_values_stats

    mean_fv, errors_fv = _merge_compact(mean_fv, errors_fv)
    mean_sv, errors_sv = _merge_compact(mean_sv, errors_sv)

    result_ds[FITTER.MEAN_VARIABLE_NAME] = mean_fv
    result_ds[FITTER.ERROR_VARIABLE_NAME] = errors_fv
    result_ds[SPECTRAL.MEAN_VARIABLE_NAME] = mean_sv
    result_ds[SPECTRAL.ERROR_VARIABLE_NAME] = errors_sv

    return result_ds


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def perform_compact_operation(
    operand_1: CompactDataSet,
    operand_2: CompactDataSet | int | float,
    operation_spectra: Operation | dict[Operation, list[str]],
    operation_timeseries: Operation | dict[Operation, list[str]],
    nu_vars: list[str] = None,
    npoints_vars: list[str] = None,
) -> CompactDataSet:
    """
    Perform a spectral operation between two compact data sets or
    between a compact dataset and a scalar.

    A CompactDataSet is a dataset with ``spectral_values``
    and ``spectral_values_stat`` variables, and
    ``spectral_var``, ``mode``, and ``_datetime`` dimensions.

    A timeseries operation is also performed on the fitter_values.

    If the operation is a dict, it is assumed to be a mapping of
    operations to variables.

    Example:

    .. code-block:: python

        operation_spectra={Operation.DIFFERENCE: ["absorbance"]}
        operation_timeseries={Operation.PASSTHROUGH: ["ValveMask"]}


    In these cases, all other variables are assigned to a default operation,
    that is ``Operation.UNION``.
    Please make sure when using operation dictionaries that all variables
    are assigned to an operation, otherwise the default one will apply.

    Args:
        operand_1 (CompactDataSet):
            First operand, which is a dataset or data array.
        operand_2 (Union[CompactDataSet, int, float]):
            Second operand, which could be a dataset, data array, or scalar.
        operation_spectra (Operation | dict[Operation, list[str]]):
            The operation to be performed on the spectra.
            It can be a single operation (expected behaviour)
            or a mapping of operations to variables.
        operation_timeseries (Operation | dict[Operation, list[str]]):
            The operation to be performed on the timeseries.
            It can be a single operation (expected behaviour)
            or a mapping of operations to variables.
        nu_vars (List[str], optional):
            Nu variables of spectral_var.
            Defaults to global NU_VARS if None.
        npoints_vars (List[str], optional):
            Npoints variable(s) of spectral_var.
            Defaults to global NPOINTS if None.

    Returns:
        CompactDataSet:
            Same as the initial dataset operand_1, but with
            the ``spectral_values`` and ``spectral_values_stats`` variables
            replaced by the result of the operation,
            and the ``fitter_values`` and ``fitter_values_stats`` variables
            replaced by the result of the timeseries operation.

    Raises:
        NotImplementedError: If an unsupported operation is passed.
    """
    if isinstance(operand_2, xr.Dataset):
        operand_1, operand_2 = xr.align(
            operand_1, operand_2, join="inner", exclude=TIME_DIM
        )

    # Set default values if None
    nu_vars = nu_vars if nu_vars is not None else NU_VARS
    nu_vars = [nu_var for nu_var in nu_vars if nu_var in operand_1.spectral_var]

    npoints_vars = npoints_vars if npoints_vars is not None else NPOINTS
    npoints_vars = [
        npoints_var
        for npoints_var in npoints_vars
        if npoints_var in operand_1.spectral_var
    ]

    # Parse the requested operations into a map
    spectral_operation_map = parse_operation(
        operation=operation_spectra,
        second_operator_type=type(operand_2),
        is_spectral_operation=True,
        required_variables=operand_1.spectral_var.values.tolist(),
        nu_vars=nu_vars,
        npoints_vars=npoints_vars,
    )

    timeseries_operation_map = parse_operation(
        operation=operation_timeseries,
        second_operator_type=type(operand_2),
        is_spectral_operation=False,
        required_variables=operand_1.fitter_var.values.tolist(),
        nu_vars=nu_vars,
        npoints_vars=npoints_vars,
    )

    return _dispatch_compact_operation_from_maps(
        operand_1=operand_1,
        operand_2=operand_2,
        operation_spectra_map=spectral_operation_map,
        operation_timeseries_map=timeseries_operation_map,
    )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _extract_results_and_errors(
    data: CompactDataSet | int | float,
    selected_variables: list[str],
    variable_type: CompactVariableType,
) -> tuple[xr.DataArray | int | float, xr.DataArray | None]:
    """
    Extracts values and their statistics (error) from the data
    for specified variables given a variable type.

    Args:
        data (Union[xr.DataArray, xr.Dataset, int, float]):
            The input data, which could be a DataArray, Dataset, or a scalar.
        selected_variables (List[str]):
            Variables to select from the data.

    Returns:
        Tuple[Union[xr.DataArray, xr.Dataset, int, float], Union[xr.DataArray, xr.Dataset, None]]:
            Mean values and their statistics (errors).
            For scalar input, statistics will be None.
    """
    if isinstance(data, (int, float)):
        return data, None  # For constants, we don't have statistical errors.

    data_selection = data.sel(
        {variable_type.COORDINATE_INDEXER_NAME: selected_variables}
    )
    return (
        data_selection[variable_type.MEAN_VARIABLE_NAME],
        data_selection[variable_type.ERROR_VARIABLE_NAME],
    )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _dispatch_compact_operation_from_maps(
    operand_1: CompactDataSet,
    operand_2: CompactDataSet | int | float,
    operation_spectra_map: dict[Operation, list[str]],
    operation_timeseries_map: dict[Operation, list[str]],
) -> CompactDataSet:
    """
    Executes operations based on provided maps, updating the compact dataset
    of operand_1.

    This function carries out the specified operations on the datasets, updating both
    spectral and timeseries data based on the provided operation maps.
    It applies these operations to the ``spectral_values`` and ``fitter_values``, respectively,
    and integrates the results into a new CompactDataSet.

    Args:
        operand_1 (CompactDataSet): The first operand, a compact dataset.
        operand_2 (CompactDataSet | int | float): The second operand, either a compact dataset or a scalar value.
        operation_spectra_map (dict[Operation, list[str]]): A map defining operations for spectral data.
        operation_timeseries_map (dict[Operation, list[str]]): A map defining operations for timeseries data.

    Returns:
        CompactDataSet:
            A compact dataset derived from operand_1, updated with the results of the operations.
    """
    result_ds = operand_1.copy()

    # spectral values
    op_type = SPECTRAL
    results, errors = _compute_operations_from_map(
        operand_1=operand_1,
        operand_2=operand_2,
        operation_map=operation_spectra_map,
        operation_type=op_type,
    )
    result_ds[op_type.MEAN_VARIABLE_NAME] = results
    result_ds[op_type.ERROR_VARIABLE_NAME] = errors

    # fitter values
    op_type = FITTER
    results, errors = _compute_operations_from_map(
        operand_1=operand_1,
        operand_2=operand_2,
        operation_map=operation_timeseries_map,
        operation_type=op_type,
    )
    result_ds[op_type.MEAN_VARIABLE_NAME] = results
    result_ds[op_type.ERROR_VARIABLE_NAME] = errors
    return result_ds


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _compute_operations_from_map(
    operand_1: CompactDataSet,
    operand_2: CompactDataSet | int | float,
    operation_map: dict[Operation, list[str]],
    operation_type: CompactVariableType,
) -> tuple[xr.DataArray, xr.DataArray]:
    """
    Performs operations according to the specified operation map and variable type.

    This function computes operations on selected variables based on the operation map.
    It loops through each operation and its associated variables in the operation map,
    extracts the results and errors for operand_1 and 2, and then performs the operation
    on the results and errors.
    The results and errors are then concatenated along the appropriate dimension.

    Args:
        operand_1 (CompactDataSet): The first operand, a compact dataset.
        operand_2 (CompactDataSet | int | float):
            The second operand, either a compact dataset or a scalar value.
        operation_map (dict[Operation, list[str]]):
            A dictionary mapping operations to lists of variable names.
        operation_type (CompactVariableType):
            An indicator of the variable type being operated on (e.g., spectral, fitter).

    Returns:
        tuple[xr.DataArray, xr.DataArray]:
            Two xarray DataArrays containing the results of the operations and any associated errors.
    """
    result = []
    errors = []

    # Loop through each operation and its associated variables in the operation map
    for operation, selected_variables in operation_map.items():
        mean_1, errors_1 = _extract_results_and_errors(
            data=operand_1,
            selected_variables=selected_variables,
            variable_type=operation_type,
        )
        mean_2, errors_2 = _extract_results_and_errors(
            data=operand_2,
            selected_variables=selected_variables,
            variable_type=operation_type,
        )

        op_result, op_error = operation_dispatcher(
            operation,
            mean_1=mean_1,
            errors_1=errors_1,
            mean_2=mean_2,
            errors_2=errors_2,
        )

        result.append(op_result)
        errors.append(op_error)

    # Concatenate results along the 'spectral_var' dimension.
    concatenated_result = xr.concat(
        result,
        dim=operation_type.COORDINATE_INDEXER_NAME,
        coords="minimal",
        compat="override",
    )
    concatenated_errors = xr.concat(
        errors,
        dim=operation_type.COORDINATE_INDEXER_NAME,
        coords="minimal",
        compat="override",
    )
    return concatenated_result, concatenated_errors
