import numpy as np
import xarray as xr
from pydantic import Field, validate_call

import picarro_xarray.accessors.allan_accessor  # noqa
from picarro_xarray.compute.compactify import _parse_prepare_compactify_grouper
from picarro_xarray.compute.zero_reference import (
    get_contiguous_group_averages,
)
from picarro_xarray.data_models.constants import TIME_DIM
from picarro_xarray.data_models.data_types import (
    AllanDataArray,
    TimeseriesDataArray,
    TimeseriesDataSet,
)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_figure_of_merit(
    zero_referenced_data: TimeseriesDataArray,
    transition_variable_data: TimeseriesDataArray,
    reference_sigma_tau: AllanDataArray,
    sigma_confidence_level: int = Field(default=3, ge=1),
    group_name: str = "group",
    time_dim: str = TIME_DIM,
) -> TimeseriesDataArray:
    raise NotImplementedError(
        "The function `get_figure_of_merit` is deprecated as of version 0.0.17. "
        "Please use the `figure_of_merit` function instead. "
        "Refer to the user guide for more information on transitioning to the new API."
    )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def figure_of_merit(
    zero_referenced_data: TimeseriesDataArray | TimeseriesDataSet,
    lod_data: xr.DataArray | xr.Dataset,
    groupby: str | TimeseriesDataArray | None = None,
    consecutive: bool = True,
    group_name: str = "group",
    time_dim: str = TIME_DIM,
) -> TimeseriesDataArray | TimeseriesDataSet:
    """
    Calculate the figure of merit based on zero-referenced data and limits of detection.

    More info on Confluence:
    `Limits of detection <https://picarro.atlassian.net/l/cp/5GiTejs2>`_.

    Example

        .. code-block:: python

            import picarro_xarray.accessor.zero_reference_accessor  # noqa
            from picarro_xarray.compute.detection_limits import limits_of_detection

            zero_da = ds.fitter_values.zero_reference.zero_reference("ValveMask", 1)

            lod_da = limits_of_detection(
                data=ds.fitter_values,
                transition_variable="ValveMask",
                reference_value=1,
                averaging_time_seconds=100,
            )

            fom = figure_of_merit(
                zero_referenced_data=zero_da,
                lod_data=lod_da,
                groupby="ValveMask",
            )

    Args:
        zero_referenced_data (TimeseriesDataArray | TimeseriesDataSet):
            Data that is zero-referenced, from :func:`.zero_reference.get_zero_referenced_data`.
        lod_data (xr.DataArray | xr.Dataset):
            The limits of detection data, from :func:`.detection_limits.limits_of_detection`.
            Must be the same type as ``zero_referenced_data``.
        groupby (str | TimeseriesDataArray):
            Parameter used for creating groups along the `_datetime` dimension.
            Can be a string representing a variable name in ``fitter_var`` in ``data``,
            a custom 1D TimeseriesDataArray indicating how to form groups
            (must have the same time length as ``data``, and must be 1D),
            or None to indicate no grouping.
            If None (default), the figure of merit is calculated for each time point
            for the entire dataset, and the output data is going to have
            the same size as the input data.
        consecutive (bool, optional):
            If True, enables consecutive grouping, treating continuous identical values
            in groupby as a single group.
            If False, group values together even if they are not consecutive.
            Defaults to True.
        group_name (str):
            Name assigned to the new coordinate representing groups in the output dataset.
            Defaults to "group".
        time_dim (str, optional):
            The name of the time dimension in the data arrays. Defaults to ``TIME_DIM``.

    Returns:
        TimeseriesDataArray | TimeseriesDataSet:
            The computed figure of merit for the provided data.

    Raises:
        ValueError: If ``zero_referenced_data`` and ``lod_data`` are not of the same type.

    Note:
        The figure of merit is calculated by taking the zero-referenced data,
        segmenting it into contiguous groups as indicated by groupby (if provided),
        and then normalizing by a scaled version of the limits of detection.
        The limits of detection are scaled to translate the raw
        limits of detection into the limits of detection we would expect at each
        averaging level (i.e., time duration of each group).
        If no groupby is provided, the limits of detection will not be scaled,
        assuming that the raw limits of detection are at the same time scale as
        the raw zero referenced data.
    """
    if type(zero_referenced_data) != type(lod_data):
        raise ValueError(
            f"zero_referenced_data and lod_data must be of the same type, "
            f"but got {type(zero_referenced_data)} and {type(lod_data)}"
        )

    if groupby is None:
        return zero_referenced_data / lod_data

    groupby = _parse_prepare_compactify_grouper(
        data=zero_referenced_data,
        groupby=groupby,
        group_name=group_name,
        time_dim=time_dim,
        consecutive=consecutive,
    ).compute()

    # get the average for each group
    group_averages = get_contiguous_group_averages(
        data=zero_referenced_data.reset_coords(drop=True),
        grouper_da=groupby,
        datetime_axis_aggregation="first",
        group_name=group_name,
        time_dim=time_dim,
    )

    # add a reference to the original grouper variable value as a coordinate
    group_averages[group_name] = (
        time_dim,
        groupby.sel({time_dim: group_averages[time_dim]}, method="nearest").values,
    )

    # averaging time at which the reference sigma_tau was calculated
    averaging_time = lod_data.tau_scaled.item()

    # need to scale the averaging time to the duration of each group
    sigma_scaling_factor = np.sqrt(averaging_time / group_averages["duration_seconds"])

    # scale the sigma_tau to the duration of each group
    lod_scaled = lod_data * sigma_scaling_factor

    return group_averages / lod_scaled
