from os import PathLike
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import xarray as xr
from pydantic import Field, validate_call

import picarro_xarray.accessors.allan_accessor  # noqa
from picarro_xarray.compute.allan_deviation import (
    _allan_std_err,
    compute_allan_dev,
)
from picarro_xarray.compute.utils import (
    _filter_groups_population,
    remove_non_numeric_variables,
)
from picarro_xarray.compute.zero_reference import get_transition_uid
from picarro_xarray.data_models.constants import (
    TIME_DIM,
    STATS_DIM,
    MODE_DIM,
    NU_KEY,
    NPOINTS_KEY,
    SPECTRUM_KEY,
    CHUNKSIZE_GROUP,
)
from picarro_xarray.data_models.data_types import (
    ComboDataSet,
    SpectralTimeseriesDataArray,
    TimeseriesDataArray,
    TimeseriesDataSet,
)
from picarro_xarray.logger.logger import get_logger
from picarro_xarray.time_utils.timeutils import _parse_grouper
from picarro_xarray.compute.utils import maybe_cache

LOGGER = get_logger(__name__)

FRAC_THRESH = 0.8  # minimum fraction of occupancy a mode should have to be retained
NPOINTS_SPECTRAL_VAR = (
    "npoints"  # name of the spectral variable representing the number of points
)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def compactify(
    data: ComboDataSet,
    groupby: str | TimeseriesDataArray | None = None,
    consecutive: bool = True,
    min_points_per_group: int = Field(default=3, ge=3),
    minimum_mode_occupancy: float = Field(default=FRAC_THRESH, ge=0.0, le=1.0),
    group_name: str = "group",
    npoints: str = NPOINTS_SPECTRAL_VAR,
    time_dim: str = TIME_DIM,
    stats_dim: str = STATS_DIM,
    mode_dim: str = MODE_DIM,
    control_spectral_vars: list[str] = [NU_KEY, SPECTRUM_KEY, NPOINTS_KEY],
    temp_storage: Optional[str | PathLike] = None,
    group_chunk_size: int = Field(default=CHUNKSIZE_GROUP, ge=1),
) -> xr.Dataset:
    """
    Group the dataset and compactify each group's data along the time dimension.

    This function takes a dataset and a ``groupby`` parameter to organize the data into groups.
    Each group's data is then compactified.
    The function allows for consecutive grouping, identified by continuous identical values.

    Args:
        data (ComboDataSet):
            The input combolog dataset containing spectral and fitter values.
        groupby (str | TimeseriesDataArray):
            Parameter used for creating groups.
            Can be a string representing a variable name in ``fitter_var`` in ``data``,
            a custom 1D TimeseriesDataArray indicating how to form groups
            (must have the same time length as ``data``, and must be 1D),
            or None to indicate no grouping (a single group is formed).
        consecutive (bool):
            If True, enables consecutive grouping, treating continuous identical values
            in groupby as a single group.
            If False, group values together even if they are not consecutive.
            Defaults to True.
        min_points_per_group (int):
            Minimum number of points per group required to compute compactification.
            Defaults to 3.
        minimum_mode_occupancy (float):
            The minimum fraction of occupancy a mode should have to be retained.
            Defaults to ``FRAC_THRESH``.
        group_name (str):
            Name assigned to the new coordinate representing groups in the output dataset.
            Defaults to "group".
        npoints (str):
            Name of the spectral variable representing the number of points.
            Defaults to ``NPOINTS_SPECTRAL_VAR``.
        time_dim (str):
            Name of the time dimension in ``data``, used for aligning the ``groupby``.
            Defaults to ``TIME_DIM``.
        stats_dim (str):
            Name of the dimension for statistical data.
            Defaults to ``STATS_DIM``.
        mode_dim (str):
            Name of the frequency dimension in 'data'.
            Defaults to ``MODE_DIM``.
        control_spectral_vars (list[str]):
            The spectral variables to use for determining the validity of a datetime.
            Defaults to ``[NU_KEY, SPECTRUM_KEY, NPOINTS_KEY]``.
        temp_storage (str | None, optional):
            The temporary storage path to cache the data.
            Defaults to None (streaming operation).
        group_chunk_size (int, optional):
            The chunk size for the group dimension.
            Defaults to ``CHUNKSIZE_GROUP``.
            If chunk size for group is too large, grouped operations
            such as ``ds.groupby(grouper) - ds.groupby(grouper).mean()``
            increase memory pressure significantly and
            can result in spilling

    Returns:
        xr.Dataset:
            Compact Dataset with groups represented as a new coordinate.
            Each group is transformed from ``n`` datetimes to ``1`` datetime,
            where ``n`` is the number of points in the group.
    """
    temp_storage = Path(temp_storage) if temp_storage else None

    chunks = {k: v[0] for k, v in data.chunks.items()} if data.chunks else None
    LOGGER.debug(f"Data sizes: {data.sizes}. Chunks: {chunks}")

    prepared_data = remove_non_numeric_variables(data)

    groupby = _parse_prepare_compactify_grouper(
        data=prepared_data,
        groupby=groupby,
        group_name=group_name,
        consecutive=consecutive,
        min_points_per_group=min_points_per_group,
        time_dim=time_dim,
    )
    groupby.persist()

    prepared_data = _prepare_compactify_data(
        data=prepared_data,
        groupby=groupby,
        time_dim=time_dim,
        mode_dim=mode_dim,
        minimum_mode_occupancy=minimum_mode_occupancy,
        control_spectral_vars=control_spectral_vars,
        temp_storage=temp_storage / "prepare" if temp_storage else None,
        group_chunk_size=group_chunk_size,
    )

    if chunks:
        prepared_data = prepared_data.chunk(
            {k: v for k, v in chunks.items() if k in prepared_data.dims}
        )
    prepared_data = maybe_cache(prepared_data, "prepared_data.zarr", temp_storage)

    # fitter values
    fitter_mean, fitter_std, fitter_std_err = _get_compact_stats(
        data=prepared_data.fitter_values,
        groupby=groupby,
        temp_storage=temp_storage / "fitter" if temp_storage else None,
        group_chunk_size=group_chunk_size,
    )

    # spectral values
    spectral_weights = prepared_data.sel(
        spectral_var=npoints, drop=True
    ).spectral_values
    spectral_weights = maybe_cache(
        spectral_weights, "spectral_weights.zarr", temp_storage
    )

    spectral_mean, spectral_std, spectral_std_err = _get_compact_stats(
        data=prepared_data.spectral_values,
        groupby=groupby,
        weights=spectral_weights,
        temp_storage=temp_storage / "spectral" if temp_storage else None,
        group_chunk_size=group_chunk_size,
    )

    # replace spectral values npoints with sum (instead of mean)
    n_points_var = spectral_weights.groupby(groupby).sum()
    spectral_mean.loc[dict(spectral_var=npoints)] = n_points_var

    # allan statistics
    allan_dev = compute_allan_dev(
        data=prepared_data,
        groupby=groupby,
        complete=False,
        time_dim=time_dim,
        group_name=group_name,
    )
    if chunks:
        allan_dev = allan_dev.chunk(
            {k: v for k, v in chunks.items() if k in allan_dev.dims}
        )

    allan_dev = maybe_cache(allan_dev, "allan_dev.zarr", temp_storage)
    allan_dev = allan_dev.swap_dims({time_dim: group_name})

    allan_std_err = _allan_std_err(allan_dev)
    allan_std_err = maybe_cache(allan_std_err, "allan_std_err.zarr", temp_storage)

    LOGGER.debug("Format compact dataset")
    result = _format_compact_dataset(
        fitter_mean=fitter_mean,
        fitter_std=fitter_std,
        fitter_std_err=fitter_std_err,
        spectral_mean=spectral_mean,
        spectral_std=spectral_std,
        spectral_std_err=spectral_std_err,
        allan_dev=allan_dev,
        allan_std_err=allan_std_err,
        time_dim=time_dim,
        stats_dim=stats_dim,
        group_name=group_name,
    )

    # add the number of aggregated points per group
    result = result.assign_coords(
        count=(time_dim, groupby[time_dim].groupby(groupby).count().values)
    )

    return result


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _valid_modes_from_mask(
    mode_mask: xr.DataArray, group_dim: str, mode_dim: str = MODE_DIM
) -> np.ndarray:
    """
    Get the valid modes from a boolean mask.
    A mode is considered valid if it has at least one valid group occurrence.

    Args:
        mode_mask (xr.DataArray):
            A 2D boolean validity mask (group x mode) indicating
            modes/groups with enough population.
            From :func:`get_populated_modes_mask`.
        group_dim (str):
            The name of the group dimension.
        mode_dim (str, optional):
            The name of the mode dimension. Defaults to ``MODE_DIM``.

    Returns:
        np.ndarray:
            The valid modes.
    """
    keep_modes = mode_mask.any(dim=group_dim)
    keep_modes = keep_modes.where(keep_modes.compute(), drop=True).mode.values

    initial_modes_count = mode_mask.sizes[mode_dim]
    valid_modes_count = len(keep_modes)

    if initial_modes_count != valid_modes_count:
        LOGGER.info(
            f"{initial_modes_count - valid_modes_count} invalid modes out of {initial_modes_count} total modes. "
            f"{valid_modes_count} remaining modes."
        )
        LOGGER.debug(
            f"Invalid modes: {set(mode_mask.mode.values).difference(keep_modes)}"
        )
    return keep_modes


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _parse_prepare_compactify_grouper(
    data: TimeseriesDataArray | TimeseriesDataSet,
    groupby: str | TimeseriesDataArray | None = None,
    group_name: str = "group",
    consecutive: bool = True,
    min_points_per_group: int = Field(default=3, ge=3),
    time_dim: str = TIME_DIM,
) -> xr.DataArray:
    """
    Parses and prepares the grouper for compactifying operations.

    Args:
        data (ComboDataSet): The data set to operate on.
        groupby (str | TimeseriesDataArray | None, optional):
            Parameter used for creating groups.
            Can be a string representing a variable name in ``fitter_var`` in ``data``,
            a custom 1D TimeseriesDataArray indicating how to form groups
            (must have the same time length as ``data``, and must be 1D),
            or None to indicate no grouping (a single group is formed).
        group_name (str, optional): The name of the group. Defaults to "group".
        consecutive (bool, optional):
            If True, enables consecutive grouping, treating continuous identical values
            in groupby as a single group.
            If False, group values together even if they are not consecutive.
            Defaults to True.
        min_points_per_group (int, optional):
           The minimum number of points per group.
           Defaults to 3 and must be greater than or equal to 3.
        time_dim (str, optional):
            The time dimension to consider. Defaults to ``TIME_DIM``.

    Returns:
        xr.DataArray:
            A DataArray to be used for grouping
    """
    groupby = _parse_grouper(
        data=data, grouper=groupby, group_name=group_name, time_dim=time_dim
    )

    if consecutive:
        groupby = get_transition_uid(transition_data=groupby)

    return _filter_groups_population(groupby=groupby, min_points=min_points_per_group)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _prepare_compactify_data(
    data: ComboDataSet,
    groupby: TimeseriesDataArray,
    minimum_mode_occupancy: float = Field(default=FRAC_THRESH, ge=0.0, le=1.0),
    control_spectral_vars: list[str] = [NU_KEY, SPECTRUM_KEY, NPOINTS_KEY],
    time_dim: str = TIME_DIM,
    mode_dim: str = MODE_DIM,
    temp_storage: Optional[str | PathLike] = None,
    group_chunk_size: int = Field(default=CHUNKSIZE_GROUP, ge=1),
) -> ComboDataSet:
    """
    Prepares the data for compactification based on
    given groupings and mode occupancies.

    If a mode has less than ``minimum_mode_occupancy`` fraction of valid datetimes for all
    groups, it is dropped from the output dataset.

    If a mode has less than ``minimum_mode_occupancy`` fraction of valid datetimes for some
    groups, its spectral data is filled with NaNs for those groups.

    If the ``groupby`` array name is already present as coordinate in ``data``, the
    coordinate is dropped. If it is present as dimension, a ValueError is raised.

    The returned data is a subset of the input data:

    * The time dimension is filtered to align with groupby
    * The mode dimension is filtered to only include modes with at least
      ``minimum_mode_occupancy`` fraction of occupancy.
    * Non-numeric variables are removed.

    Args:
        data (ComboDataSet):
            The data set to be prepared for compactification.
        groupby (TimeseriesDataArray):
            The array defining groupings for compactification.
        minimum_mode_occupancy (Field):
            Minimum fraction of mode occupancy for inclusion.
            Defaults to ``FRAC_THRESH`` constant.
        control_spectral_vars (list[str], optional):
            The spectral variables to use for determining the validity of a datetime.
            Defaults to ``[NU_KEY, SPECTRUM_KEY, NPOINTS_KEY]``.
        time_dim (str, optional):
            The name of the time dimension in the data set.
            Defaults to ``TIME_DIM``
        mode_dim (str, optional):
            The name of the frequency dimension in the data set.
            Defaults to ``MODE_DIM``.
        temp_storage (str | None, optional):
            The temporary storage path to cache the data.
            Defaults to None (streaming operation).
        group_chunk_size (int, optional):
            The chunk size for the group dimension.
            Defaults to ``CHUNKSIZE_GROUP``.

    Returns:
        xr.Dataset:
           A time and mode subset of the starting ComboDataset
    """
    if groupby.name in data.coords:
        if groupby.name in data.dims:
            raise ValueError(
                f"{groupby.name} is a dimension of the "
                f"dataset. Please choose a different "
                f"grouper name"
            )
        else:
            LOGGER.info(
                f"{groupby.name} is already a coordinate in the dataset. "
                f"Will drop it from the dataset before compactifying."
            )
            data = data.drop_vars(groupby.name)

    # drop datetimes not belonging to a group
    prepared_data = data.sel({time_dim: groupby[time_dim].values})

    # boolean mask of valid spectra [datetime x mode]
    valid_spectra_mask = _get_spectra_validity_mask(
        spectral_data=prepared_data.spectral_values,
        control_spectral_vars=control_spectral_vars,
        temp_storage=temp_storage,
    )

    # total _datetimes elements per group
    total_counts_per_group = (
        prepared_data[time_dim].groupby(groupby).count(dim=time_dim).compute()
    )

    # get the valid modes mask [group x mode]
    keep_modes_mask = _get_populated_modes_mask(
        spectral_validity_mask=valid_spectra_mask,
        groupby=groupby,
        datetime_counts_per_group=total_counts_per_group,
        minimum_mode_occupancy=minimum_mode_occupancy,
        temp_storage=temp_storage,
        time_dim=time_dim,
        group_chunk_size=group_chunk_size,
    )

    # get the valid modes [mode]
    keep_modes = _valid_modes_from_mask(
        mode_mask=keep_modes_mask, group_dim=groupby.name, mode_dim=mode_dim
    )

    # keep valid modes only, drop others
    keep_modes_mask = keep_modes_mask.sel({mode_dim: keep_modes})
    prepared_data = prepared_data.sel({mode_dim: keep_modes})
    valid_spectra_mask = valid_spectra_mask.sel({mode_dim: keep_modes})

    # update spectral values with NaNs for modes/groups with low occupancy
    updated_spectral_values = _get_updated_spectral_values(
        spectral_data=prepared_data.spectral_values,
        spectral_validity_mask=valid_spectra_mask,
        populated_modes_mask=keep_modes_mask,
        groupby=groupby,
        temp_storage=temp_storage,
    )

    # update the dataset with the new spectral values
    prepared_data["spectral_values"] = updated_spectral_values

    return prepared_data


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_populated_modes_mask(
    spectral_validity_mask: SpectralTimeseriesDataArray,
    groupby: TimeseriesDataArray,
    datetime_counts_per_group: xr.DataArray,
    minimum_mode_occupancy: float = Field(default=FRAC_THRESH, ge=0.0, le=1.0),
    temp_storage: Optional[str | PathLike] = None,
    time_dim: str = TIME_DIM,
    group_chunk_size: int = Field(default=CHUNKSIZE_GROUP, ge=1),
) -> xr.DataArray:
    """
    Get a 2D boolean population mask (group x mode)
    indicating modes/groups with enough population.
    If group 1, mode 1 cell is True, it means that group 1
    has enough population for mode 1.
    If group 2, mode 1 cell is False, it means that group 2
    does not have enough population for mode 1.
    A mode/group is considered populated if that mode has at least
    ``minimum_mode_occupancy`` fraction of valid datetimes for that group.
    A datetime is considered valid if it is True in ``spectral_validity_mask``.

    Args:
        spectral_validity_mask (SpectralTimeseriesDataArray):
            The boolean spectral validity mask to use
            for computing the population mask.
            It has dimensions (_datetime x mode).
            From :func:`_get_spectra_validity_mask`.
        groupby (TimeseriesDataArray):
            The data array used for grouping the input data.
        minimum_mode_occupancy (float, optional):
            The minimum fraction of occupancy a mode should have to be retained.
            Defaults to ``FRAC_THRESH``.
        temp_storage (str | None, optional):
            The temporary storage path to cache the data.
            Defaults to None (streaming operation).
        time_dim (str, optional):
            The time dimension to consider. Defaults to ``TIME_DIM``.
        group_chunk_size (int, optional):
            The chunk size for the group dimension.
            Defaults to ``CHUNKSIZE_GROUP``.

    Returns:
        xr.DataArray:
            A 2D boolean validity mask (group x mode) indicating
            modes/groups with enough population.
    """
    if not groupby.name:
        raise ValueError("groupby DataArray must have a name")

    LOGGER.debug("Get group-spectral population mask")
    nonnull_per_group = spectral_validity_mask.groupby(groupby).sum(dim=time_dim)

    group_occupancy_fraction = nonnull_per_group / datetime_counts_per_group
    keep_modes_mask = group_occupancy_fraction >= minimum_mode_occupancy
    keep_modes_mask.name = "keep_modes_mask"

    if spectral_validity_mask.chunksizes:
        # read chunks from input data if present
        chunks = {k: v[0] for k, v in spectral_validity_mask.chunksizes.items()}
        chunks[groupby.name] = group_chunk_size

        keep_modes_mask = keep_modes_mask.chunk(
            chunks={k: v for k, v in chunks.items() if k in keep_modes_mask.dims}
        )

    keep_modes_mask = maybe_cache(keep_modes_mask, "keep_modes_mask.zarr", temp_storage)
    return keep_modes_mask


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_spectra_validity_mask(
    spectral_data: SpectralTimeseriesDataArray,
    control_spectral_vars: list[str] = [NU_KEY, SPECTRUM_KEY, NPOINTS_KEY],
    temp_storage: Optional[str | PathLike] = None,
) -> xr.DataArray:
    """
    Get a 2D boolean validity mask (_datetime x mode).
    A `(_datetime, mode)` cell is considered valid (True) if
    all control spectral variables are not null.

    Args:
        spectral_data (SpectralTimeseriesDataArray):
            The spectral data to use for computing the validity mask.
            Typically: ``ds.spectral_values``
        control_spectral_vars (list[str], optional):
            The spectral variables to use for determining the validity of a datetime.
            Defaults to ``[NU_KEY, SPECTRUM_KEY, NPOINTS_KEY]``.
        temp_storage (str | None, optional):
            The temporary storage path to cache the data.
            Defaults to None (streaming operation).

    Returns:
        xr.DataArray:
            A 2D boolean validity mask (_datetime x mode)
            indicating valid spectra
    """
    # get number of valid datetimes in each group (by mode)
    # a valid datetime must have all control spectral variables values not null
    LOGGER.debug("Get temporal-spectral validity mask")
    nonnull_total = (
        spectral_data.sel(spectral_var=control_spectral_vars)
        .notnull()
        .all(dim="spectral_var")
    )

    if spectral_data.chunksizes:
        # read chunks from input data if present
        chunks = {k: v[0] for k, v in spectral_data.chunksizes.items()}

        nonnull_total = nonnull_total.chunk(
            chunks={k: v for k, v in chunks.items() if k in nonnull_total.dims}
        )

    nonnull_total.name = "nonnull_total"
    nonnull_total = maybe_cache(nonnull_total, "nonnull_total.zarr", temp_storage)
    return nonnull_total


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_updated_spectral_values(
    spectral_data: SpectralTimeseriesDataArray,
    spectral_validity_mask: xr.DataArray,
    populated_modes_mask: xr.DataArray,
    groupby: TimeseriesDataArray,
    temp_storage: Optional[str | PathLike] = None,
) -> SpectralTimeseriesDataArray:
    """
    Get updated spectral values with NaNs for modes/groups with low occupancy.


    Args:
        spectral_data (SpectralTimeseriesDataArray):
            The spectral data to update.
            It has dimensions (_datetime, mode, spectral_var).
        spectral_validity_mask (xr.DataArray):
            The boolean spectral validity mask from
            :func:`_get_spectra_validity_mask`.
            It has dimensions (_datetime x mode).
            Each cell is True if the corresponding spectral
            data is valid.
        populated_modes_mask (xr.DataArray):
            The boolean mask indicating modes/groups with enough population,
            from :func:`_get_populated_modes_mask`.
            It has dimensions (group x mode).
            Each cell is True if the corresponding mode has enough
            population for the group.
        groupby (TimeseriesDataArray):
            The data array used for grouping the input data.
        temp_storage (str | None, optional):
            The temporary storage path to cache the data.
            Defaults to None (streaming operation).

    Returns:
        SpectralTimeseriesDataArray:
            The updated spectral values with NaNs for modes/groups with low occupancy.
    """
    chunks = (
        {k: v[0] for k, v in spectral_data.chunksizes.items()}
        if spectral_data.chunksizes
        else None
    )

    # multiply mask has the shape of spectral_values and contains
    # only nan/1 values. It is used to multiply the spectral values
    # to fill with NaNs the modes/groups with low occupancy
    LOGGER.debug("Get spectral values multiply mask")
    multiply_mask = spectral_validity_mask.astype(bool).where(
        spectral_validity_mask, other=np.nan
    ).groupby(groupby) * populated_modes_mask.where(populated_modes_mask, other=np.nan)

    multiply_mask.name = "multiply_mask"
    multiply_mask = multiply_mask.drop_vars(groupby.name)

    if chunks:
        multiply_mask = multiply_mask.chunk(
            chunks={k: v for k, v in chunks.items() if k in multiply_mask.dims}
        )

    multiply_mask = maybe_cache(multiply_mask, "multiply_mask.zarr", temp_storage)

    # fill spectral values with NaNs for modes/groups with low occupancy
    LOGGER.debug("Multiply spectral values by mask")
    new_spectral_values = spectral_data * multiply_mask
    new_spectral_values.name = "spectral_values"

    if chunks:
        new_spectral_values = new_spectral_values.chunk(
            {k: v for k, v in chunks.items() if k in new_spectral_values.dims}
        )

    new_spectral_values = maybe_cache(
        new_spectral_values, "new_spectral_values.zarr", temp_storage
    )
    return new_spectral_values


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_grouped_weighted_mean(
    data: TimeseriesDataArray,
    groupby: TimeseriesDataArray,
    weights: TimeseriesDataArray,
) -> xr.DataArray:
    """
    Compute the grouped weighted mean for timeseries data.

    Given a timeseries data array, this function calculates the weighted mean for each group
    defined by the ``groupby`` data array, using the provided weights. The calculation process
    adopts a two-step approach:

    1. Compute the arithmetic mean of the product of data values and their corresponding weights
       (i.e., arithmetic mean of ``w_i * x_i`` for each group).
    2. Compute the arithmetic mean of the weights for each group.

    The final grouped weighted mean for each group is then determined by dividing the result
    from step 1 by the result from step 2.

    The weighted mean formula is described as:

    .. math::

        𝑣_𝑚 = (𝑤_1 * 𝑥_1 + 𝑤_2 * 𝑥_2 + ... + 𝑤_𝑚 * 𝑥_𝑚) / (𝑤_1 + 𝑤_2 + ... + 𝑤_𝑚)

    which simplifies to:

    .. math::

        𝑣_𝑚 = Σ(𝑤_𝑖 * 𝑥_𝑖) / Σ𝑤_𝑖  \quad \\text{for i=1:m}

    By breaking the computation into these two steps, the function can efficiently handle
    the grouped weighted mean calculation.

    Args:
        data (TimeseriesDataArray):
            The timeseries data for which to calculate the weighted mean.
        groupby (TimeseriesDataArray):
            The data array used for grouping the input data
            during the weighted mean calculation.
            Each group's weighted mean is treated independently.
        weights (TimeseriesDataArray):
            The weights corresponding to the data values in ``data``.

    Returns:
        xr.DataArray: The grouped weighted mean values for each group defined by ``groupby``.

    Raises:
        ValueError: If the dimensions of ``data`` and ``weights`` do not match.
    """
    weighted_items = data * weights
    arithmetic_weighted_mean = weighted_items.groupby(groupby).mean()
    mean_weights = weights.groupby(groupby).mean()
    return arithmetic_weighted_mean / mean_weights


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_grouped_weighted_std(
    data: TimeseriesDataArray,
    groupby: TimeseriesDataArray,
    weights: TimeseriesDataArray,
    mean_by_group: Optional[xr.DataArray] = None,
    temp_storage: Optional[str | PathLike] = None,
    group_chunk_size: int = Field(default=CHUNKSIZE_GROUP, ge=1),
) -> xr.DataArray:
    """
    Compute the grouped weighted standard deviation of the given data.

    This function calculates the weighted standard deviation
    for each group in the provided data, using the specified
    weights. The computation is based on the formula:

    .. math::

        σ^2 = Σ w_i (x_i - μ^*)^2 / Σ w_i

    .. math::
        σ = \sqrt{σ^2}

    Where:

    * σ² : Weighted variance by group
    * σ : Weighted standard deviation by group
    * wᵢ : Weight of the ith data point
    * xᵢ : i-th data point
    * μ* : Mean of the group

    If the mean by group (``μ*``) is not provided, it will be computed using
    :func:`_get_grouped_weighted_mean`.

    Args:
        data (TimeseriesDataArray):
            Input data for which the grouped weighted standard deviation needs to be computed.
        groupby (TimeseriesDataArray):
            DataArray specifying the groups for the ``data``.
        weights (TimeseriesDataArray):
            Weights for each data point in ``data``. Must have the same dimensions as ``data``.
        mean_by_group (Optional[TimeseriesDataArray], default=None):
            Mean values by group. If not provided, they will be computed from the data.
        temp_storage (str | None, optional):
            The temporary storage path to cache the data.
            Defaults to None (streaming operation).
        group_chunk_size (int, optional):
            The chunk size for the group dimension.
            Defaults to ``CHUNKSIZE_GROUP``.

    Returns:
        xr.DataArray: Grouped weighted standard deviation for each group in the input ``data``.

    Raises:
        ValueError: If the dimensions of ``data`` and ``weights`` do not match.
    """
    if mean_by_group is None:
        mean_by_group = _get_grouped_weighted_mean(
            data=data, groupby=groupby, weights=weights
        )

    LOGGER.debug("Compute weights sum by group")
    weights_sum_by_group = weights.groupby(groupby).sum()

    LOGGER.debug("Compute differences")
    differences = data.groupby(groupby) - mean_by_group
    differences.name = "differences"

    if data.chunksizes:
        chunks = {k: v[0] for k, v in data.chunksizes.items()}
        chunks[groupby.name] = group_chunk_size
        differences = differences.chunk(
            {k: v for k, v in chunks.items() if k in differences.dims}
        )

    differences = maybe_cache(differences, "differences.zarr", temp_storage)

    weighted_squared_differences = (differences**2) * weights

    LOGGER.debug("Compute sum weighted squared diffs by group")
    sum_weighted_squared_diffs_by_group = weighted_squared_differences.groupby(
        groupby
    ).sum()
    return np.sqrt(sum_weighted_squared_diffs_by_group / weights_sum_by_group)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_compact_stats(
    data: TimeseriesDataArray,
    groupby: TimeseriesDataArray,
    weights: Optional[TimeseriesDataArray] = None,
    temp_storage: Optional[str | PathLike] = None,
    group_chunk_size: int = Field(default=CHUNKSIZE_GROUP, ge=1),
) -> tuple[xr.DataArray, xr.DataArray, xr.DataArray]:
    """
    Compute compact statistics on a TimeseriesDataArray.

    This function calculates and returns
    the weighted mean, standard deviation, standard error, using provided weights.

    Args:
        data (TimeseriesDataArray): The input data on which to compute the statistics
        groupby (TimeseriesDataArray):
            The data array used for grouping the input data.
            Each group's statistics are treated independently.
        weights (Optional[TimeseriesDataArray], optional):
            The weights to use for the calculations. Defaults to None.
            If None, a default uniform weighting will be used.
        temp_storage (str | None, optional):
            The temporary storage path to cache the data.
            Defaults to None (streaming operation).
        group_chunk_size (int, optional):
            The chunk size for the group dimension.
            Defaults to ``CHUNKSIZE_GROUP``.

    Returns:
        tuple[xr.DataArray, xr.DataArray, xr.DataArray]:
            A tuple containing the weighted mean, standard deviation,
            and standard error (grouped by ``groupby``).
    """
    chunks = None

    # prepare weights
    if weights is None:
        weights = data.notnull().astype(int)

    da_mean = _get_grouped_weighted_mean(
        data=data,
        groupby=groupby,
        weights=weights,
    )
    da_mean.name = "mean"

    if data.chunksizes:
        # read chunks from input data
        chunks = {k: v[0] for k, v in data.chunksizes.items()}
        chunks[groupby.name] = group_chunk_size

        LOGGER.debug(f"Data sizes: {data.sizes}. Chunks: {chunks}")
        chunks = {k: v for k, v in chunks.items() if k in da_mean.dims}
        da_mean = da_mean.chunk(chunks)

    da_mean = maybe_cache(da_mean, "da_mean.zarr", temp_storage)

    da_std = _get_grouped_weighted_std(
        data=data,
        groupby=groupby,
        weights=weights,
        mean_by_group=da_mean,
        temp_storage=temp_storage,
    )
    da_std.name = "std"
    da_std = da_std.chunk(chunks) if chunks else da_std
    da_std = maybe_cache(da_std, "da_std.zarr", temp_storage)

    counts = weights.groupby(groupby).sum()
    da_std_err = da_std / np.sqrt(counts)
    da_std_err.name = "std_err"
    da_std_err = da_std_err.chunk(chunks) if chunks else da_std_err
    da_std_err = maybe_cache(da_std_err, "da_std_err.zarr", temp_storage)
    return da_mean, da_std, da_std_err


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _move_stat_to_last_dim(
    data: xr.DataArray,
    stats_dim: str = STATS_DIM,
) -> xr.DataArray:
    """
    Rearrange the dimensions of a Dataset or DataArray such that
    the `stats_dim` becomes the last dimension.

    Args:
        data (xr.Dataset | xr.DataArray):
            The input dataset or data array whose dimensions are to be rearranged.
        stats_dim (str, optional):
            The name of the statistical dimension to move to the end.
            Defaults to ``STATS_DIM``.

    Returns:
        xr.Dataset | xr.DataArray:
           A rearranged dataset or data array with the ``stats_dim`` as the last dimension.
    """

    dims = list(data.dims)

    if stats_dim in dims:
        dims.remove(stats_dim)
        dims.append(stats_dim)

    return data.transpose(*dims)


def _format_compact_dataset(
    fitter_mean: xr.DataArray,
    spectral_mean: xr.DataArray,
    fitter_std: xr.DataArray,
    spectral_std: xr.DataArray,
    fitter_std_err: xr.DataArray,
    spectral_std_err: xr.DataArray,
    allan_dev: xr.Dataset,
    allan_std_err: xr.Dataset,
    group_name: str,
    stats_dim: str = STATS_DIM,
    time_dim: str = TIME_DIM,
) -> xr.Dataset:
    stats_index = pd.Index(
        ["std_dev", "std_err", "allan_dev", "allan_std_err"], name=stats_dim
    )
    fitter_mean.name = "fitter_values"
    spectral_mean.name = "spectral_values"

    ds_fitter_stats = xr.concat(
        [
            fitter_std,
            fitter_std_err,
            allan_dev.fitter_values,
            allan_std_err.fitter_values,
        ],
        dim=stats_index,
    )
    ds_fitter_stats.name = "fitter_values_stats"

    ds_spectral_stats = xr.concat(
        [
            spectral_std,
            spectral_std_err,
            allan_dev.spectral_values,
            allan_std_err.spectral_values,
        ],
        dim=stats_index,
    )
    ds_spectral_stats.name = "spectral_values_stats"

    result = xr.merge(
        [
            fitter_mean,
            spectral_mean,
            ds_fitter_stats,
            ds_spectral_stats,
        ],
        compat="override",
    )

    result[stats_dim] = result[stats_dim].astype(str)

    result = result.swap_dims({group_name: time_dim})

    # move stat coordinate to the end
    for var in result.data_vars:
        result[var] = _move_stat_to_last_dim(result[var])

    return result
