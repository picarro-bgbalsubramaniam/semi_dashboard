import numpy as np
import xarray as xr
from pydantic import Field, validate_call

from picarro_xarray.data_models.constants import NPOINTS_KEY, TIME_DIM
from picarro_xarray.data_models.data_types import (
    TimeseriesDataSet,
    ComboDataSet,
    verify_combo_data,
    verify_time_dimension,
)
from picarro_xarray.logger.logger import get_logger

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def filter_fitter_var(
    ds: ComboDataSet,
    fitter_var: str,
    lower_bound: float | None = None,
    upper_bound: float | None = None,
) -> TimeseriesDataSet:
    """
    Filters out times along _datetime coordinate where given fitter var
    fails to meet limits criteria

    Args:
        ds (xr.Dataset): Typical combolog dataset with timeseries data
        fitter_var (str): fitter var string name to filter on
        lower_bound (float | None): lower bound for fitter_var values
        upper_bound (float | None): upper bound for fitter_var values

        Example:
                .. code-block:: python

                    ds = filter_fitter_var(ds, "cavityPressureStd", lower_bound=0.0, upper_bound=0.5)

    Returns:
        ds (TimeseriesDataSet): Combolog dataset with fitlered values removed
    """

    try:
        _ = verify_time_dimension(ds)
        _ = verify_combo_data(ds)
    except ValueError as e:
        raise TypeError(
            f"Filtering fitter_var is implemented only for xarray "
            f"ComboDataset with {TIME_DIM} coordinates"
        ) from e

    if fitter_var not in ds.fitter_var:
        raise ValueError(f"{fitter_var} not found in Dataset")

    if lower_bound is None and upper_bound is None:
        raise ValueError("You must specify at least a lower or upper bound to filter")

    original_length = len(ds._datetime)

    if lower_bound is not None and upper_bound is not None:
        maskl = ds.sel(fitter_var=fitter_var, drop=True).fitter_values > lower_bound
        maskr = ds.sel(fitter_var=fitter_var, drop=True).fitter_values < upper_bound
        mask = (maskl) & (maskr)
    elif lower_bound is not None:
        mask = ds.sel(fitter_var=fitter_var, drop=True).fitter_values > lower_bound
    elif upper_bound is not None:
        mask = ds.sel(fitter_var=fitter_var, drop=True).fitter_values < upper_bound

    return_ds = ds.where(mask.compute(), drop=True)

    dropped_points = original_length - len(return_ds._datetime)
    LOGGER.info(f"Filtered {dropped_points} time coordinates")

    return return_ds


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def filter_npoints(
    ds: ComboDataSet,
    number_missing: int = Field(default=1, ge=0),
    fraction_of_median: float = Field(default=0.4, ge=0, le=1),
) -> TimeseriesDataSet:
    """
    Given a combo log dataset filter out modes with missing npoints.
    Typically used for short period with rapidly changing connctrations (TD/GC).
    Warning: Do not use on long periods of contiguous data, missing ring downs are common!

    Args:
        ds (xr.Dataset): Typical combolog dataset with timeseries data
        number_missing (int): Minimum number of times we can miss a fraction of the npoints
        fraction_of_median (float): fraction of median npoints missing to trigger a drop

    Example:
            .. code-block:: python

                ds = filter_npoints(ds, number_missing=6, fraction_of_median=0.5)

    Returns:
        ds (TimeseriesDataSet): Combolog dataset with fitlered values removed
    """

    med_npoints = ds.sel(spectral_var=NPOINTS_KEY).spectral_values.median(dim=TIME_DIM)

    mask_rd = (
        np.abs(ds.sel(spectral_var=NPOINTS_KEY, drop=True).spectral_values - med_npoints)
        > fraction_of_median * med_npoints
    ).sum(dim=TIME_DIM) >= number_missing

    sel_modes = mask_rd.where(mask_rd.compute(), drop=True).mode
    new_ds = ds.drop_sel(mode=sel_modes)

    LOGGER.info(f"Dropping modes {sel_modes.values} with missing npoints")

    return new_ds
