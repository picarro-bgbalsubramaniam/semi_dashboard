from math import sqrt
from typing import Optional

import xarray as xr
from pydantic import Field, validate_call

from picarro_xarray.compute.allan_deviation import compute_allan_dev
from picarro_xarray.compute.zero_reference import get_reference_transitions_uid
from picarro_xarray.data_models.constants import TIME_DIM
from picarro_xarray.data_models.data_types import (
    AllanDataArray,
    AllanDataSet,
    TimeseriesDataArray,
    TimeseriesDataSet,
)
from picarro_xarray.time_utils.timeutils import _parse_grouper


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_lods_from_allan_dev(
    sigma_tau: AllanDataSet | AllanDataArray,
    averaging_time_seconds: float = Field(default=100, ge=1),
    sigma_confidence_level: int = Field(default=3, ge=1),
) -> xr.DataArray | xr.Dataset:
    """
    Calculates the limits of detection based on provided
    of time series data Allan deviation.

    The limits of detection are calculated as::

        LOD = sigma_level * sigma_tau * sqrt(tau / averaging_time_seconds)

    where tau is the time difference between consecutive data points.
    More info on Confluence:
    `Limits of detection <https://picarro.atlassian.net/l/cp/5GiTejs2>`_.

    Args:
        sigma_tau (xr.DataArray):
            The input DataArray to be used for calculations.
            It is the noise of the time series data, with each data point
            being ''tau'' seconds away from the next.
            The provided sigma_tau is often calculated starting from the time
            series data of "reference" or "zero" gas.

            Example:
                .. code-block:: python

                    sigma_tau = reference_ds.fitter_values.allan.allan_dev()

        averaging_time_seconds (int, optional):
            Averaging time in seconds at which the limits of detection are calculated.
            Defaults to 100 seconds.

        sigma_level (int, optional):
            Sigma level for calculations.
            Defaults to 3.

    Returns:
        xr.DataArray: The calculated limits of detection as a DataArray.
    """

    if "tau" in sigma_tau.dims:
        sigma_tau = sigma_tau.isel(tau=0)

    tau_scaled = sigma_tau.tau_scaled.item()

    sigma_scaling_factor = sqrt(tau_scaled / averaging_time_seconds)
    detection_limits = sigma_confidence_level * sigma_tau * sigma_scaling_factor
    detection_limits["tau_scaled"] = averaging_time_seconds
    return detection_limits


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_limits_of_detection(
    sigma_tau: AllanDataSet | AllanDataArray,
    averaging_time_seconds: int = Field(default=100, ge=1),
    sigma_confidence_level: int = Field(default=3, ge=1),
) -> xr.DataArray:
    raise NotImplementedError(
        "The function `get_limits_of_detection` has been deprecated and is no longer available as of version 0.0.17. "
        "Please use the function `limits_of_detection` instead."
    )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def limits_of_detection(
    data: TimeseriesDataArray | TimeseriesDataSet,
    transition_variable: str | TimeseriesDataArray,
    reference_value: str | int | float,
    averaging_time_seconds: Optional[float] = Field(default=None, ge=1),
    sigma_confidence_level: int = Field(default=3, ge=1),
    time_dim: str = TIME_DIM,
) -> xr.DataArray | xr.Dataset:
    """
    Calculates the limits of detection based on provided
    of time series data.

    The limits of detection are calculated as::

        LOD = sigma_level * sigma_tau * sqrt(tau / averaging_time_seconds)

    where tau is the time difference between consecutive data points, and
    sigma_tau is the Allan deviation of the time series data.

    More info on Confluence:
    `Limits of detection <https://picarro.atlassian.net/l/cp/5GiTejs2>`_.

    Args:
        data (Union[TimeseriesDataArray, TimeseriesDataSet]):
            The input dataset or data array.
        transition_variable (str):
            The variable name that represents transitions in the data.
            For example, `ValveMask`.
        reference_value (Union[str, int, float]):
            The value of ``transition_variable`` that identifies the reference data.
        averaging_time_seconds (int, optional):
            Averaging time in seconds at which the limits of detection are calculated.
            Defaults to 100 seconds.
        sigma_confidence_level (int, optional):
            Sigma level for calculations.
            Defaults to 3.

    Returns:
        xr.DataArray: The calculated limits of detection as a DataArray.
    """
    transition_data = _parse_grouper(
        data=data, grouper=transition_variable, time_dim=time_dim
    )

    reference_uid = get_reference_transitions_uid(
        transition_variable_data=transition_data,
        reference_value=reference_value,
        time_dim=time_dim,
    )

    reference_data = data.sel(_datetime=reference_uid[time_dim].values)
    sigma_tau = compute_allan_dev(reference_data, complete=False)
    sigma_tau = sigma_tau.squeeze(time_dim)

    if averaging_time_seconds is None:
        averaging_time_seconds = sigma_tau.tau_scaled.item()

    lods = _get_lods_from_allan_dev(
        sigma_tau=sigma_tau,
        averaging_time_seconds=averaging_time_seconds,
        sigma_confidence_level=sigma_confidence_level,
    )
    return lods
