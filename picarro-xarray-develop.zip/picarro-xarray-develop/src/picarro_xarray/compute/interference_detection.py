from collections import namedtuple
from datetime import datetime
from enum import Enum
from itertools import groupby
from typing import (
    List,
    Literal,
    Optional,
    Union,
)

import numpy as np
import pandas as pd
import xarray as xr
from pydantic import BaseModel, Field, validate_call
from sklearn.impute import SimpleImputer
from sklearn.mixture import GaussianMixture

from picarro_xarray.data_models.constants import (
    CID_DIM,
    TIME_DIM,
    TRANSITION_VAR,
)
from picarro_xarray.data_models.data_types import TimeseriesDataArray


class InterferenceEvent(BaseModel):
    group_id: int
    fitter_var: str
    start_time: datetime
    end_time: datetime
    fom_excursion: float


FlagLocation = namedtuple(
    "FlagLocation", ["event_time", "group_id", "fitter_var", "fom_excursion"]
)
FlagLocationWithID = namedtuple("FlagLocationWithID", ["flag_location", "event_id"])


class InterferenceType(str, Enum):
    OUTLIER = "outlier"
    TRANSITION = "transition"
    OUTLIER_TRANSITION = "outlier_transition"

    def get_filter_function(self):
        match self:
            case InterferenceType.OUTLIER:
                return hampel_filter
            case InterferenceType.TRANSITION:
                return gmm_filter_xarray_ufunc
            case _:
                raise NotImplementedError(f"No filter defined for: {self}")


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_fom_as_dataframe(
    da: TimeseriesDataArray, transition_var: str = TRANSITION_VAR
) -> pd.DataFrame:
    """
    convert xarray to pandas dataframe
    """

    df = da.swap_dims({TIME_DIM: transition_var}).to_pandas()
    df = df.reset_index()
    df.index = da.to_pandas().index
    return df


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _multiindex_fom_df(
    fom_df: pd.DataFrame, transition_var: str = TRANSITION_VAR
) -> pd.DataFrame:
    """
    reindex fom with time and valvemask
    """

    temp = fom_df.copy()
    datetimes = temp.index
    valvemasks = temp[transition_var]
    temp = temp.drop(columns=transition_var)
    temp.index = [datetimes, valvemasks]
    return temp


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _mask_outliers(
    fom_df: pd.DataFrame,
    outlier_df: pd.DataFrame,
    val_at_mask: bool = True,
    transition_var: str = TRANSITION_VAR,
) -> pd.DataFrame:
    """
    mask dataframe with outlier dataframe
    """

    fom_r = _multiindex_fom_df(fom_df, transition_var=transition_var)
    outlier_r = _multiindex_fom_df(outlier_df, transition_var=transition_var)
    if val_at_mask:
        return fom_r[outlier_r]
    else:
        return fom_r[~outlier_r]


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _max_deltaT_df(
    fom_df: pd.DataFrame, valve: Union[float, int], transition_var: str = TRANSITION_VAR
) -> pd.Timedelta:
    # TODO: this needs to be made more robust
    dt_max = fom_df[fom_df[transition_var] == valve].index.to_series().diff()[1:].max()
    return dt_max


def _hampel_filter_core(
    data: TimeseriesDataArray,
    window_size: int,
    factor: float,
    time_dim: str,
) -> TimeseriesDataArray:
    """Core Hampel filter logic for a single DataArray (or a group)."""
    L = 1.4826

    # 1. Rolling median of the data
    rolling_median_da = (
        data.rolling({time_dim: window_size}, center=True)
        .construct("win")
        .median("win", skipna=True)
    )

    # 2. Construct windowed version of data
    # A unique name for the temporary window dimension
    temp_window_dim = f"__hampel_window_elements_{data.name or 'data'}"
    da_windowed = data.rolling({time_dim: window_size}, center=True).construct(
        temp_window_dim, fill_value=np.nan
    )

    # 3. Standard MAD calculation
    abs_dev_from_window_median = np.abs(da_windowed - rolling_median_da)
    std_mad = abs_dev_from_window_median.median(dim=temp_window_dim, skipna=True)

    # 4. Calculate threshold using the standard MAD
    threshold = factor * L * std_mad

    # 5. Calculate difference metric: |original_value - rolling_median_of_original_value|
    difference_metric = np.abs(data - rolling_median_da)

    # 6. Calculate potential outlier score
    score = difference_metric - threshold

    # Return the score only if it's positive AND the threshold was valid ( >= 0)
    # Otherwise, return NaN.
    out = score.where((score > 0) & (threshold >= 0))

    return out


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def hampel_filter(
    da: TimeseriesDataArray,
    group_by: TimeseriesDataArray | None = None,
    window_size: int = 7,
    factor: float = 3,
    time_dim: str = TIME_DIM,
) -> TimeseriesDataArray:
    """
    Applies a Hampel filter to timeseries data using a standard
    Median Absolute Deviation (MAD) calculation, optionally on a per-group basis.

    The filter identifies points that are a specified number of MADs away
    from the rolling median. The MAD is calculated for each window as:
    median(abs(window_values - median(window_values))).
    If `group_by` is provided, these calculations are performed independently
    for each group.

    Inputs:
        da (TimeseriesDataArray):
            The timeseries data. Must have a dimension named by `time_dim`.
        group_by (TimeseriesDataArray | None):
            If provided, the Hampel filter is applied independently to each group
            defined by this DataArray.
            The grouping DataArray should be alignable with `da`.
        window_size (int):
            Total size of the rolling window (including the sample)
            to compute the median and MAD. For example, a window_size of 7
            means 3 points on either side of the current value.
        factor (float):
            Threshold multiplier. A point is considered an outlier if its
            deviation from the rolling median is greater than
            `factor * L * MAD`.
        time_dim (str):
            The name of the time dimension. Default is `TIME_DIM`.

    Returns:
        TimeseriesDataArray:
            A DataArray indicating the extent of outlierness for each point,
            calculated with respect to its group if `group_by` is used.
            Positive values represent the amount by which a point's deviation
            from the local rolling median exceeds the scaled MAD threshold.
            Returns NaN if the local MAD is zero (e.g., for a window with
            constant values) or for points not considered outliers by this metric.
    """
    if group_by is None:
        return _hampel_filter_core(
            da,
            window_size=window_size,
            factor=factor,
            time_dim=time_dim,
        )
    else:
        return da.groupby(group_by).map(
            _hampel_filter_core,
            window_size=window_size,
            factor=factor,
            time_dim=time_dim,
        )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _gmm_filter_2D(y: np.ndarray, factor: float = 5) -> np.ndarray:
    """
    Applies a GMM filter to a 2D numpy array.

    Inputs:
        y (np.ndarray): A 2D array of shape (n_samples, n_features).
        factor (float): Threshold multiplier.

    Returns:
        out (np.ndarray): A masked 1D array (n_features).
    """

    yt = SimpleImputer().fit_transform(y.T)
    gmm = GaussianMixture(n_components=2, covariance_type="full", random_state=0).fit(
        yt
    )
    means = gmm.means_
    cov = gmm.covariances_
    mean_diff = np.abs(np.diff(means, axis=0))
    std_stacked = np.vstack([np.sqrt(np.diag(c)) for c in cov])
    mask = np.any(mean_diff > factor * std_stacked, axis=0)
    out = np.where(mask, mean_diff.reshape(-1), np.nan)
    return out


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _gmm_filter_loop(
    X: np.ndarray,
    factor: float = 5,
) -> np.ndarray:
    """
    Applies a GMM filter to a 3D numpy array.

    Inputs:
        X (np.ndarray): A 3D array of shape (n_datetimes, n_samples, n_fitter_vars).
        factor (float): Threshold multiplier.

    Returns:
        out (np.ndarray): A masked 2D array (n_datetimes, n_fitter_vars).
    """

    out = np.vstack([_gmm_filter_2D(x, factor=factor) for x in X])
    return out


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def gmm_filter_xarray_ufunc(
    da: xr.DataArray,
    factor: float = 5,
    window_size: int = 19,
    dask: Literal["forbidden", "allowed", "parallelized"] = "parallelized",
) -> xr.DataArray:
    """
    Applies a Gaussian Mixture Model (GMM) filter to xarray DataArray timeseries data.

    Inputs:
        da (xr.DataArray):
            Timeseries data.
        factor (float):
            Threshold multiplier to the standard deviation.
        window_size (int):
            Size of the rolling window in terms of number of `_datetime` datapoints.
            A larger window means more samples are included in the analysis.

    Returns:
        out (xr.DataArray):
            Masked timeseries data with a GMM filter applied.
            The filter assesses bimodality in the data.
            If the data is bimodal within the window, it returns the mean
            difference between the two modes.
            If the data is not bimodal within the window, NaN values are returned.

    """

    da = da.transpose(TIME_DIM, CID_DIM)
    da = da.dropna(CID_DIM, how="all")
    da = da.dropna(TIME_DIM, how="any")
    da_rolled = da.rolling({TIME_DIM: window_size}, center=True).construct("window")
    in_dims = list(da_rolled.dims)
    out_dims = [d for d in da_rolled.dims if d != "window"]
    out = xr.apply_ufunc(
        _gmm_filter_loop,
        da_rolled,
        input_core_dims=[in_dims],
        output_core_dims=[out_dims],
        dask=dask,
        vectorize=True,
        kwargs={"factor": factor},
    )
    return out


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _fom_outside_events(
    fom: xr.DataArray,
    interferents_list: List[InterferenceEvent],
    transition_var: str = TRANSITION_VAR,
) -> xr.DataArray:
    """
    Returns the figure of merit (FOM) outside specified event intervals.

    Inputs:
        fom (xr.DataArray): The figure of merit as an xarray DataArray.
        interferents_list (List[InterferenceEvent]): List of events

    Returns:
        fom_outside (xr.DataArray):
            The FOM values outside the specified event intervals.
    """

    fom_copy = fom.copy(deep=True).load()
    for interferent in interferents_list:
        tmptimes = fom_copy.where(
            (fom[transition_var] == interferent.group_id), drop=True
        ).sel({TIME_DIM: slice(interferent.start_time, interferent.end_time)})[TIME_DIM]
        fom_copy.loc[{TIME_DIM: tmptimes, CID_DIM: [interferent.fitter_var]}] = np.nan
    return fom_copy


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_flag_locations(
    figure_of_merit_da: TimeseriesDataArray,
    transition_var: str = TRANSITION_VAR,
    scale_by_filter: bool = True,
    interference_type: InterferenceType = InterferenceType.OUTLIER,
    window_size: int = Field(default=19, gt=3),
    scale_factor: float = Field(default=2, gt=1),
    dask: Literal["forbidden", "allowed", "parallelized"] = "parallelized",
) -> List[FlagLocation]:
    """
    Applies either a Hampel filter or a Gaussian Mixture Model (GMM) filter to identify
    locations (indices) where the filter was triggered in the timeseries data.

    Inputs:
        figure_of_merit_da (TimeseriesDataArray):
            The Figure of Merit timeseries data.
        transition_var (str):
            Transition variable used in the filter application.
        scale_by_filter (bool):
            Decides whether to return the raw Figure of Merit at the filter locations
            or the Figure of Merit value scaled by the appropriate value.
        interference_type (InterferenceType):
            Type of interference filter to apply.
        window_size (int):
            Size of the window for the filter. Must be greater than 3.
        scale_factor (float):
            Scaling factor used if `scale_by_filter` is True. Must be greater than 1.
        dask (Literal["forbidden", "allowed", "parallelized"]):
            Dask computation mode.

    Returns:
        List[FlagLocation]: Flagged locations
    """

    filter_fun = InterferenceType(interference_type).get_filter_function()
    filter_kwargs = dict(window_size=window_size, factor=scale_factor)
    if interference_type is InterferenceType.TRANSITION:
        filter_kwargs["dask"] = dask
    excursion = figure_of_merit_da.groupby(transition_var).map(
        filter_fun, **filter_kwargs
    )
    outliers = excursion > 0
    mask_df = _get_fom_as_dataframe(outliers, transition_var=transition_var)
    if scale_by_filter:
        df_to_mask = _get_fom_as_dataframe(excursion, transition_var=transition_var)
    else:
        df_to_mask = _get_fom_as_dataframe(
            figure_of_merit_da, transition_var=transition_var
        )
    fom_x = _mask_outliers(df_to_mask, mask_df, transition_var=transition_var)
    fom_dict = fom_x.dropna(axis=1, how="all").stack().to_dict()
    event_locations = [k + (np.abs(v),) for k, v in fom_dict.items()]
    flag_locations = [FlagLocation(*loc) for loc in event_locations]
    return flag_locations


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_sections_from_locations(
    flag_locations: List[FlagLocation],
    dt_max: pd.Timedelta,
    scale_window_edges: bool = True,
) -> List[InterferenceEvent]:
    """
    Extracts sections from a list of flag locations based on specified criteria.

    Args:
        flag_locations (List[FlagLocation]): A list of flag locations.
        dt_max (pd.Timedelta):
            The maximum time difference allowed between consecutive flagged events
            to consider them as part of the same section.
        scale_window_edges (bool):
            If True, scales padding on either side of the time slice by the event duration.

    Returns:
        List[InterferenceEvent]: A list of InterferenceEvent.
    """

    flag_times = [location.event_time for location in flag_locations]
    time_deltas = [np.timedelta64(0, "ns")] + [
        flag_times[i + 1] - flag_times[i] for i in range(len(flag_times) - 1)
    ]
    event_ids = []
    event_counter = 0
    for dt in time_deltas:
        if dt > dt_max:
            event_counter += 1
        event_ids.append(event_counter)
    locations_with_id = [
        FlagLocationWithID(*loc) for loc in zip(flag_locations, event_ids)
    ]
    locations_grouped_by_event = [
        list(grp) for _, grp in groupby(locations_with_id, key=lambda x: x.event_id)
    ]
    sections = []
    for group in locations_grouped_by_event:
        fitter_var = group[0].flag_location.fitter_var
        group_id = group[0].flag_location.group_id
        event_times = [g.flag_location.event_time for g in group]
        pad_deltaT = dt_max * len(event_times) if scale_window_edges else dt_max
        event_start = np.min(event_times) - pad_deltaT
        event_end = np.max(event_times) + pad_deltaT
        fom_excursion = max([g.flag_location.fom_excursion for g in group])
        event = InterferenceEvent(
            group_id=group_id,
            fitter_var=fitter_var,
            start_time=event_start.to_pydatetime(),
            end_time=event_end.to_pydatetime(),
            fom_excursion=fom_excursion,
        )
        sections.append(event)
    sections.sort(key=lambda x: x.start_time)
    return sections


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _merge_sections(sections_in: List[InterferenceEvent]) -> List[InterferenceEvent]:
    """
    Merges sections of interference events into consolidated sections if applicable.

    Args:
        sections_in (List[InterferenceEvent]): A list of InterferenceEvent objects

    Returns:
        sections_out (List[InterferenceEvent]):
            A list of merged InterferenceEvent objects
    """

    sections_in.sort(key=lambda x: x.start_time)
    sections_out = []
    cached_event = None
    for event in sections_in:
        if cached_event is None:
            cached_event = event
        elif event.start_time <= cached_event.end_time:
            cached_event.end_time = max(cached_event.end_time, event.end_time)
            cached_event.fom_excursion = max(
                event.fom_excursion, cached_event.fom_excursion
            )
        else:
            sections_out.append(cached_event)
            cached_event = event
    if cached_event:
        sections_out.append(cached_event)
    return sections_out


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_biggest_interferents(
    interferents_list: List[InterferenceEvent],
    big_how: Literal["largest", "longest"] = "largest",
) -> List[InterferenceEvent]:
    """
    Identifies the biggest interference events from a list based on specified criteria.

    Args:
        interferents_list (List[InterferenceEvent]):
            A list of InterferenceEvent objects
        big_how (Literal["largest", "longest"]):
            Method to characterize the biggest event. Defaults to 'largest'.
            'largest' returns the event with the highest FOM excursion.
            'longest' returns the event with the longest duration.

    Returns:
        biggest_interferents (List[InterferenceEvent]):
            A list of the biggest interference events for each start time
    """

    interferents_list = sorted(interferents_list, key=lambda x: x.start_time)
    interferents_grouped_by_start_time = [
        list(g)
        for _, g in groupby(
            interferents_list, key=lambda x: x.start_time.strftime("%y-%m-%d-%H-%M")
        )
    ]
    if big_how == "largest":
        biggest_interferents = [
            max(g, key=lambda x: x.fom_excursion)
            for g in interferents_grouped_by_start_time
        ]
    elif big_how == "longest":
        biggest_interferents = [
            max(g, key=lambda x: x.end_time - x.start_time)
            for g in interferents_grouped_by_start_time
        ]
    else:
        raise ValueError(
            "Wrong big_how argument. Should be either 'largest' or 'longest'"
        )
    return biggest_interferents


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _get_list_of_interferent_sections(
    fom: xr.DataArray,
    transition_var: str = TRANSITION_VAR,
    interference_type: InterferenceType = InterferenceType.OUTLIER,
    window_size: int = Field(default=19, gt=3),
    scale_factor: float = Field(default=2, gt=1),
    dask: Literal["forbidden", "allowed", "parallelized"] = "parallelized",
    scale_window_edges: bool = True,
    scale_by_filter: bool = True,
    automerge_sections: bool = True,
    biggest_in_port_only: bool = True,
    big_how: Literal["largest", "longest"] = "largest",
) -> List[InterferenceEvent]:
    """
    Extracts a list of interferent sections from timeseries data based on various
    criteria and filters.

    Args:
        fom (xr.DataArray):
            The Figure of Merit timeseries data.
        transition_var (str):
            Typically 'ValveMask' or 'port_id', used to identify transitions.
        interference_type (InterferenceType):
            Specifies the type of interference, e.g., OUTLIER.
        window_size (int):
            Size of the window for the filter, must be greater than 3.
        scale_factor (float):
            Factor used for scaling, must be greater than 1.
        dask (Literal["forbidden", "allowed", "parallelized"]):
            Strategy for Dask computation.
        scale_window_edges (bool):
            If True, scales padding on either side of the time window by the event
            duration.
        scale_by_filter (bool):
            If True, scales the output by the filter results.
        automerge_sections (bool):
            If True, automatically merges overlapping time sections. Defaults to True.
        biggest_in_port_only (bool):
            If True, only returns the biggest excursion events for each port start
            time. Defaults to True.
        big_how (Literal["largest", "longest"]):
            Criteria used by `_get_biggest_interferents` to determine the biggest
            events. 'largest' for the highest FOM excursion or 'longest' for the
            longest duration.

    Returns:
        List[InterferenceEvent]:
            A list of detected InterferenceEvent objects, potentially merged and
            filtered according to the specified criteria.
    """

    fom_df = _get_fom_as_dataframe(fom, transition_var=transition_var)
    all_groups = fom_df[transition_var].unique()
    all_fitter_vars = [
        c for c in fom_df.dropna(axis=1, how="all").columns if c != transition_var
    ]
    flagged_list = _get_flag_locations(
        fom,
        transition_var=transition_var,
        scale_by_filter=scale_by_filter,
        interference_type=interference_type,
        window_size=window_size,
        scale_factor=scale_factor,
        dask=dask,
    )
    out_list = []
    for group_id in all_groups:
        dt_max = _max_deltaT_df(fom_df, group_id, transition_var=transition_var)
        tmplist_in_port = []
        for fitter_var in all_fitter_vars:
            culled_list = [
                c
                for c in flagged_list
                if (c.fitter_var == fitter_var) and (c.group_id == group_id)
            ]
            tmplist = _get_sections_from_locations(
                culled_list,
                dt_max,
                scale_window_edges=scale_window_edges,
            )
            tmplist = _merge_sections(tmplist) if automerge_sections else tmplist
            tmplist_in_port += tmplist
        if biggest_in_port_only:
            tmplist_in_port = _get_biggest_interferents(
                tmplist_in_port, big_how=big_how
            )
        out_list += tmplist_in_port
    return out_list


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def filter_events_list(
    interferents_list: List[InterferenceEvent],
    fitter_vars: Optional[list[str]] = None,
    group_ids: Optional[list[int | str]] = None,
    min_duration: Optional[np.timedelta64] = None,
    min_fom_excursion: Optional[float] = Field(default=None, ge=0),
) -> List[InterferenceEvent]:
    """
    Filters a list of InterferenceEvent objects based on specified criteria.

    Args:
        interferents_list (List[InterferenceEvent]):
            List of InterferenceEvent objects to filter.
        fitter_vars (Optional[list[str]]):
            List of valid `fitter_vars` to select. If None, all `fitter_vars` are included.
        group_ids (Optional[list[int | str]]):
            List of valid `group_ids` to select. If None, all `group_ids` are included.
        min_duration (Optional[np.timedelta64]):
            Minimum duration of events to include. Events shorter than this are excluded.
        min_fom_excursion (Optional[float]):
            Minimum FOM excursion magnitude for an event to be included. Events with
            smaller excursions are excluded.

    Returns:
        List[InterferenceEvent]:
            The filtered list of InterferenceEvent objects, selected according to the
            specified criteria.
    """

    min_duration = np.timedelta64(0, "ns") if min_duration is None else min_duration
    min_fom_excursion = 0 if min_fom_excursion is None else min_fom_excursion

    interferents_list = (
        interferents_list
        if not fitter_vars
        else [l for l in interferents_list if l.fitter_var in fitter_vars]
    )

    interferents_list = (
        interferents_list
        if not group_ids
        else [l for l in interferents_list if l.group_id in group_ids]
    )

    interferents_list = [
        l for l in interferents_list if l.fom_excursion >= min_fom_excursion
    ]
    interferents_list = [
        l for l in interferents_list if (l.end_time - l.start_time) >= min_duration
    ]
    return interferents_list


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_outliers(
    figure_of_merit_da: TimeseriesDataArray,
    window_size: int = Field(default=21, gt=3),
    scale_factor: float = Field(default=2, gt=1),
    transition_var: str = TRANSITION_VAR,
) -> List[InterferenceEvent]:
    """
    Identifies outliers in the Figure of Merit timeseries data using a Hampel filter.

    Args:
        figure_of_merit_da (xr.DataArray):
            Figure of Merit data, typically obtained from
            :py:func:`compute.figure_of_merit.figure_of_merit`.
        window_size (int):
            Size of the window for the Hampel filter to compute the median.
            Example: a window_size of 7 means 3 data points on either side of the
            current value are considered.
        scale_factor (float):
            Threshold multiplier used to determine outliers. Default is 2.
            It specifies how many times a value may deviate from the median absolute
            deviation before being classified as an outlier. A higher factor results
            in fewer outliers detected, and a lower factor triggers more detections.
        transition_var (str):
            Name of the transition variable used in filtering.

    Returns:
        List[InterferenceEvent]:
            A list of detected InterferenceEvent objects, each representing an outlier
            in the data.
    """

    return _get_list_of_interferent_sections(
        figure_of_merit_da,
        interference_type=InterferenceType.OUTLIER,
        window_size=window_size,
        scale_factor=scale_factor,
        transition_var=transition_var,
        scale_window_edges=True,
        automerge_sections=True,
        biggest_in_port_only=True,
        big_how="largest",
    )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_transitions(
    figure_of_merit_da: TimeseriesDataArray,
    window_size: int = Field(default=21, gt=3),
    scale_factor: float = Field(default=4.5, gt=1),
    dask: Literal["forbidden", "allowed", "parallelized"] = "parallelized",
    transition_var: str = TRANSITION_VAR,
) -> List[InterferenceEvent]:
    """
    Identifies interferents in the Figure of Merit timeseries data using
    Gaussian mixture model (GMM) filter.

    Args:
        figure_of_merit_da (xr.DataArray):
            Figure of Merit data, typically obtained from
            :py:func:`compute.figure_of_merit.figure_of_merit`.
        window_size (int):
            Size of the rolling window for the GMM filter in terms of number of
            `_datetime` datapoints. A larger window size means more samples are
            analyzed together.
        scale_factor (float):
            Threshold multiplier for the GMM filter. Higher values result in fewer
            transitions detected, while lower values increase transition detection.
        dask (Literal["forbidden", "allowed", "parallelized"]):
            Specifies the Dask parallelization setting.
        transition_var (str):
            Name of the transition variable used in filtering processes.

    Returns:
        List[InterferenceEvent]:
            A list of detected InterferenceEvent objects, representing identified
            transitions in the data.
    """

    return _get_list_of_interferent_sections(
        figure_of_merit_da,
        interference_type=InterferenceType.TRANSITION,
        window_size=window_size,
        scale_factor=scale_factor,
        dask=dask,
        transition_var=transition_var,
        scale_window_edges=False,
        automerge_sections=True,
        biggest_in_port_only=True,
        big_how="largest",
    )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_outliers_and_transitions(
    figure_of_merit_da: TimeseriesDataArray,
    hampel_window_size: int = Field(default=21, gt=3),
    hampel_scale_factor: float = Field(default=2, gt=1),
    gmm_window_size: int = Field(default=21, gt=3),
    gmm_scale_factor: float = Field(default=4.5, gt=1),
    dask: Literal["forbidden", "allowed", "parallelized"] = "parallelized",
    transition_var: str = TRANSITION_VAR,
) -> List[InterferenceEvent]:
    """
    Identifies interferents in the Figure of Merit timeseries data using both Hampel
    and Gaussian Mixture Model (GMM) filters.

    Args:
        figure_of_merit_da (xr.DataArray):
            Figure of Merit data, typically obtained from
            :py:func:`compute.figure_of_merit.figure_of_merit`.
        hampel_window_size (int):
            Size of the window for the Hampel filter to compute the median.
            Example: a hampel_window_size of 7 means 3 data points on either side of
            the current value are considered.
        hampel_scale_factor (float):
            Threshold multiplier for the Hampel filter. Default is 2.
            Specifies how many times a value may deviate from the median absolute
            deviation before being classified as an outlier. Higher values result in
            fewer outliers detected, while lower values increase outlier detection.
        gmm_window_size (int):
            Size of the rolling window for the GMM filter in terms of number of
            `_datetime` datapoints.
        gmm_scale_factor (float):
            Threshold multiplier for the GMM filter. Higher values result in fewer
            transitions detected, while lower values increase transition detection.
        dask (Literal["forbidden", "allowed", "parallelized"]):
            Specifies the Dask parallelization setting. 'forbidden' disables Dask,
            'allowed' enables it without enforcing, and 'parallelized' enforces its use.
        transition_var (str):
            Name of the transition variable used in filtering.

    Returns:
        List[InterferenceEvent]:
            A list of detected InterferenceEvent objects, representing identified
            outliers and transitions in the data.
    """

    interferents_outlier = get_outliers(
        figure_of_merit_da,
        window_size=hampel_window_size,
        scale_factor=hampel_scale_factor,
        transition_var=transition_var,
    )
    fom_fo = _fom_outside_events(
        figure_of_merit_da, interferents_outlier, transition_var
    )
    interferents_transition = get_transitions(
        fom_fo,
        window_size=gmm_window_size,
        scale_factor=gmm_scale_factor,
        dask=dask,
        transition_var=transition_var,
    )
    all_interferents = sorted(
        interferents_outlier + interferents_transition, key=lambda x: x.start_time
    )
    return all_interferents
