from typing import Optional

import numpy as np
import xarray as xr
import math
from pydantic import Field, validate_call

from picarro_xarray.compute.utils import (
    _filter_groups_population,
    remove_non_numeric_variables,
)
from picarro_xarray.data_models.constants import TIME_DIM
from picarro_xarray.time_utils.timeutils import (
    get_median_time_delta_seconds,
    _parse_grouper,
)
from picarro_xarray.logger.exceptions import AllanDevNotEnoughSamples
from picarro_xarray.logger.logger import get_logger
from picarro_xarray.data_models.data_types import (
    TimeseriesDataArray,
    TimeseriesDataSet,
    AllanDataArray,
    AllanDataSet,
)

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def compute_allan_dev(
    data: TimeseriesDataArray | TimeseriesDataSet,
    groupby: Optional[TimeseriesDataArray] = None,
    complete: bool = False,
    group_name: str = "group",
    time_dim: str = TIME_DIM,
    group_min_points: int = Field(ge=2, default=2),
) -> AllanDataSet | AllanDataArray:
    """
    Computes the overlapping Allan deviation for a given timeseries dataset or data array.

    It generates the required tau values, converts frequency data to
    phase data, and computes the Allan deviation
    for the specified tau values.

    Args:
        data (TimeseriesDataArray | TimeseriesDataSet):
            The input timeseries data
        complete (bool, optional):
            If True, calculates Allan deviation for all tau values, otherwise
            only for the first tau value. Default is False.
        groupby (TimeseriesDataArray, optional):
            The variable to group by.
            If provided, the Allan deviation is computed
            for each group. Default is None.
        group_name (str, optional):
            The name of the groupby variable. Default is ``group``.
        time_dim (str, optional):
            The name of the time dimension. Default is ``TIME_DIM``.
        group_min_points (int, optional):
            The minimum number of points required to compute the Allan deviation
            for a group. Default is 2.

    Returns:
        AllanDataSet | AllanDataArray:
            The computed Allan deviation

    Note:
        The ``tau`` values are scaled by the median time delta in the returned result ``tau_scaled``.
    """
    LOGGER.debug("Drop non-numeric variables")
    numeric_data = remove_non_numeric_variables(data)

    if complete:
        if groupby is not None:
            raise NotImplementedError(
                "Groupby is not supported for complete Allan deviation."
            )

        LOGGER.debug("Computing complete Allan deviation")
        adev = _compute_complete_allan_dev(data=numeric_data, overlapping=True)
    else:
        LOGGER.debug("Computing Allan deviation for first tau value")
        grouper = _parse_grouper(
            data=numeric_data, grouper=groupby, group_name=group_name, time_dim=time_dim
        )

        grouper = grouper.reset_coords(drop=True)

        LOGGER.debug("filter groups population")
        # filter out groups with less than 3 points
        grouper = _filter_groups_population(
            groupby=grouper, min_points=group_min_points
        )
        numeric_data = numeric_data.sel({time_dim: grouper[time_dim].values})

        LOGGER.debug("Computing first term Allan deviation")
        adev = _compute_first_term_allan_dev(
            data=numeric_data, groupby=grouper, time_dim=time_dim
        )

    return adev


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _compute_first_term_allan_dev(
    data: TimeseriesDataArray | TimeseriesDataSet,
    groupby: TimeseriesDataArray,
    time_dim: str = TIME_DIM,
) -> AllanDataSet | AllanDataArray:
    """
    Compute the first term of the overlapping Allan deviation
    for the given timeseries data.

    It is Anirban algorithm, extended to work with groups.

    It first determines the median time delta within each group.
    It then uses a rolling window approach to calculate the squared differences
    of the consecutive data points. These squared differences are aggregated
    to calculate the Allan deviation for each group.

    If chunked along the time axis, the time chunks are re-chunked to half
    their size during the operation to decrease memory pressure, as
    the rolling window computation temporarily double the size (in byte) of
    each chunk.

    Args:
        data (Union[TimeseriesDataArray, TimeseriesDataSet]):
            The timeseries data for which
            to calculate the Allan deviation. Must include a time dimension.
        groupby (TimeseriesDataArray):
            The data array used for grouping the input data
            during the Allan deviation calculation. Each group is treated independently.
        time_dim (str, optional):
            The name of the time dimension. Defaults to ``TIME_DIM``.

    Returns:
        Union[AllanDataArray, AllanDataSet]:
            The Allan deviation values for each group.
            Includes additional coordinates for the median time delta ('tau_scaled'),
            the number of samples ('n_samples'), and the time coordinates for each group.
    """
    grouper = groupby.copy(deep=True)
    grouper.name = grouper.name or "group"

    LOGGER.debug("Computing median time delta")
    median_dt = get_median_time_delta_seconds(
        data=data, groupby=grouper, group_name=grouper.name
    )
    time_coord_values = data[time_dim].groupby(grouper).first()

    try:
        time_chunk = data.chunksizes[time_dim][0]
    except (KeyError, IndexError) as err:
        LOGGER.debug(f"No time chunk available: {err}")
    else:
        LOGGER.debug("Splitting time chunk in two for Allan dev calculation")
        time_chunk = int(time_chunk / 2)
        data = data.chunk({time_dim: time_chunk})

    rolling = data.rolling({time_dim: 2}, min_periods=2)

    time_window_name = "time_window"
    rolling_construct = rolling.construct({time_dim: time_window_name}, stride=1)
    rolling_diff_sq = (
        rolling_construct.diff(time_window_name).squeeze(time_window_name) ** 2
    )

    # Drop the first index of each group, since when doing diff
    # we would get a NaN value for the first index
    first_idxs = rolling_diff_sq[time_dim].groupby(grouper).first()

    rolling_diff_sq = rolling_diff_sq.drop_sel({time_dim: first_idxs})
    grouper = grouper.drop_sel({time_dim: first_idxs})

    sum_squares = rolling_diff_sq.groupby(grouper).sum()
    n_pairs = rolling_diff_sq.groupby(grouper).count()
    n_samples = rolling_diff_sq[time_dim].groupby(grouper).count()
    allan_dev = np.sqrt(sum_squares / (2 * n_pairs))

    allan_dev = allan_dev.assign_coords(tau=1, tau_scaled=median_dt, n_samples=n_samples)
    allan_dev = allan_dev.assign_coords({time_dim: time_coord_values}).swap_dims(
        {grouper.name: time_dim}
    )
    return allan_dev


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _compute_complete_allan_dev(
    data: TimeseriesDataArray | TimeseriesDataSet,
    overlapping: bool = True,
    time_dim: str = TIME_DIM,
) -> AllanDataSet | AllanDataArray:
    """
    Computes the complete Allan deviation
    for a given timeseries dataset or data array.

    It generates the required tau values, converts frequency data to
    phase data, and computes the Allan deviation
    for the specified tau values.

    Args:
        data (TimeseriesDataArray | TimeseriesDataSet):
            The input timeseries data
        overlapping (bool, optional):
            If True, uses overlapping Allan deviation, otherwise uses
            non-overlapping Allan deviation. Default is True (preferred).

    Returns:
        AllanDataSet | AllanDataArray:
            The computed Allan deviation

    Note:
        The ``tau`` values are scaled by the median time delta in the returned result.
    """
    taus = generate_taus(data.sizes[time_dim])
    phase = frequency_to_phase(data)

    adev = _allan_dev(phase=phase, taus=taus, overlapping=overlapping)

    median_dt = get_median_time_delta_seconds(data=data, groupby=None)
    median_dt = median_dt.item()

    adev = adev.assign_coords(tau_scaled=adev.tau * median_dt)

    return adev


@validate_call(validate_return=True)
def generate_taus(data_len: int = Field(ge=1)) -> list[int]:
    """
    Generate a list of time intervals (taus) based on the input data length.

    This function computes the unique list of time intervals or lags (taus)
    using the logarithm base 2 for a given data length. Only valid taus
    (i.e., taus < data_len and taus > 0) are considered.

    Args:
        data_len (int): The length of the data series for which taus are to be computed.

    Returns:
        list[int]: A list of unique and valid time intervals (taus).

    Raises:
        ValueError: If data_len is less than or equal to 0.

    Example:

    >>> generate_taus(16)
    [1, 2, 4, 8]

    """
    maxn = math.floor(math.log2(data_len))
    taus = [2**i for i in range(maxn + 1) if 1 <= 2**i < data_len]

    return taus


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def frequency_to_phase(
    data: TimeseriesDataArray | TimeseriesDataSet,
) -> xr.DataArray | xr.Dataset:
    """
    Converts fractional frequency data to phase data by integrating over time.

    Follows representation of package ``allantools``, including adding
    an initial zero value to the phase data for the centered
    finite difference at the starting bound.

    Args:
        data (TimeseriesDataArray | TimeseriesDataSet):
            An xarray DataArray or DataSet containing time series data.

    Returns:
        TimeseriesDataArray | TimeseriesDataSet:
            An xarray DataArray or DataSet representing the phase data obtained
            by the time integral of the fractional frequency data, in units of seconds.
    """
    phase = (data - data.mean(dim=TIME_DIM, skipna=True)).cumsum(dim=TIME_DIM)

    # make time axis a simple integer index
    phase[TIME_DIM] = np.arange(phase.sizes[TIME_DIM]) + 1

    # Need to add a zero at the beginning of phase data for
    # correct initial finite difference calculation
    initial_phase = phase.isel({TIME_DIM: slice(0, 1)}, drop=False).where(False, 0)
    initial_phase[TIME_DIM] = (TIME_DIM, [0])

    phase = xr.concat([initial_phase, phase], dim=TIME_DIM)
    return phase


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _calc_adev_phase(
    phase: xr.DataArray | xr.Dataset,
    mj: int = Field(ge=1),
    stride: int = Field(ge=1),
) -> AllanDataArray | AllanDataSet:
    """
    Computes Allan Deviation for the given phase data, considering the specified stride.

    This function applies the main algorithm used for calculating non-overlapping
    (``stride=mj``) and overlapping (``stride=1``) Allan deviations. The calculations are based
    on the deviation of phase data over different time intervals defined by the stride.

    Args:
        phase (TimeseriesDataArray | TimeseriesDataSet):
            Input phase data. Can be an xarray DataArray or DataSet.
        mj (int):
            The M index value defining the non-overlapping stride in time intervals.
        stride (int):
            The size of the stride. Use stride=1 for overlapping and stride=mj for
            non-overlapping Allan deviation.

    Returns:
        AllanDataArray | AllanDataSet:
            The computed Allan deviation values as an xarray DataArray or DataSet,
            with assigned coordinates for `tau` and `n_samples`.

    Raises:
        RuntimeError: If the number of samples is less than 2.

    References:
        * http://www.leapsecond.com/tools/adev_lib.c
        * http://en.wikipedia.org/wiki/Allan_variance
        * NIST SP1065 eqn (7) and (11) page 16
    """
    d0 = phase.isel({TIME_DIM: slice(None, None, stride)})
    d1 = phase.isel({TIME_DIM: slice(mj, None, stride)})
    d2 = phase.isel({TIME_DIM: slice(2 * mj, None, stride)})

    n_samples = d2.sizes[TIME_DIM]

    if n_samples < 2:
        raise AllanDevNotEnoughSamples(n_samples)

    d0 = d0.isel({TIME_DIM: slice(0, n_samples)})
    d1 = d1.isel({TIME_DIM: slice(0, n_samples)})

    # this is needed to get rid of axis label
    # otherwise xarray will try to align them
    fake_time_labels = np.arange(n_samples)
    d0 = d0.assign_coords({TIME_DIM: fake_time_labels})
    d1 = d1.assign_coords({TIME_DIM: fake_time_labels})
    d2 = d2.assign_coords({TIME_DIM: fake_time_labels})

    finite_diff_sq = (d2 - 2 * d1 + d0) ** 2
    sum_sq = finite_diff_sq.sum(TIME_DIM, skipna=False)
    two_n = 2.0 * n_samples
    adev_val = np.sqrt(sum_sq / two_n) / mj
    adev_val = adev_val.assign_coords(tau=mj, n_samples=n_samples)
    return adev_val


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _allan_dev(
    phase: xr.DataArray | xr.Dataset,
    taus: list[int],
    overlapping: bool = True,
) -> AllanDataArray | AllanDataSet:
    """
    Computes the Allan deviation for the given phase data and list of tau values.

    This function iterates over the specified tau values to calculate the Allan deviation
    for each, based on the provided phase data, and concatenates the resulting deviations
    along a new dimension ``tau``.

    Args:
        phase (TimeseriesDataArray | TimeseriesDataSet):
            The phase data for which the Allan deviation is to be calculated.
            From :func:`frequency_to_phase`
        taus (list[int]):
            A list of integer tau values for which Allan deviation is to be calculated.
            From :func:`generate_taus`
        overlapping (bool, optional):
            A boolean value indicating whether to calculate overlapping Allan deviation.
            Default is True, implying overlapping is used.

    Returns:
        AllanDataArray | AllanDataSet:
            The computed Allan deviation values as
            an xarray DataArray or DataSet,
            concatenated along the ``tau`` dimension.

    Note:
        When there is an error due to insufficient number of samples
        for a specific ``tau`` value, the function breaks out of the loop
        and returns the deviations calculated until that point.
    """

    results_adev = []

    for tau in taus:
        stride = 1 if overlapping else tau

        try:
            adev = _calc_adev_phase(phase, tau, stride)
        except AllanDevNotEnoughSamples as err:
            LOGGER.debug(f"Skipping tau={tau} due to insufficient samples: {err}")
            break
        else:
            results_adev.append(adev)

    adev = xr.concat(results_adev, dim="tau")

    return adev


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _allan_std_err(
    allan_dev_data: AllanDataSet | AllanDataArray,
) -> AllanDataSet | AllanDataArray:
    """
    Computes the standard error for the given Allan deviation data.

    This function takes Allan deviation data and computes the standard error
    for each deviation by dividing it by the square root of the corresponding
    number of samples.

    Args:
        allan_dev_data (AllanDataSet | AllanDataArray):
            The Allan deviation data.
            Should have ``n_samples`` as a coordinate representing
            the number of samples for each Allan deviation.

    Returns:
        AllanDataSet | AllanDataArray:
            The computed Allan standard error.
    """
    return allan_dev_data / np.sqrt(allan_dev_data["n_samples"])


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _allan_var(
    allan_dev_data: AllanDataSet | AllanDataArray,
) -> AllanDataSet | AllanDataArray:
    """
    Computes the Allan variance by squaring the given Allan deviation data.

    Args:
        allan_dev_data (AllanDataSet | AllanDataArray):
            The Allan deviation data
    Returns:
        AllanDataSet | AllanDataArray:
            The computed Allan variance as an xarray DataArray or DataSet
    """
    return allan_dev_data**2
