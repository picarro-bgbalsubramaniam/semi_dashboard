from typing import Callable

import numpy as np
import xarray as xr
from pydantic import validate_call
from scipy.integrate import trapezoid

from picarro_xarray.data_models.constants import MODE_DIM
from picarro_xarray.data_models.data_types import (
    ComboDataSet,
    SpectralDataArray,
    TimeseriesDataArray,
)

# integral function type, input is x, y, boolen keep mask, output is the integral
IntegralCallable = Callable[[np.ndarray, np.ndarray, np.ndarray], np.ndarray]

COMPOUND_SEARCH_ERROR_MSG = (
    "Error getting model functions: did you import the "
    "``compound_search`` accessor and set the model functions? "
    "``import picarro_xarray.accessors.compound_search_accessor`` and then "
    "``ds.compound_search.set_model_functions(your_model_functions)`` "
)


def _trapz(x: np.ndarray, y: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """
    Compute the trapezoidal integral of the given arrays,
    considering only the elements
    where the mask is True.

    Example

    >>> x = np.array([0, 1, 2, 3, 4])
    >>> y = np.array([0, 1, 4, 9, 16])
    >>> mask = np.array([True, False, True, True, False])
    >>> float(_trapz(x, y, mask))
    10.5

    Args:
        x (np.ndarray): The array of x values.
        y (np.ndarray): The array of y values.
        mask (np.ndarray): The boolean mask array indicating valid elements.

    Returns:
        np.ndarray: The computed integral.
    """
    return trapezoid(x=x[mask], y=y[mask])


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def integrate_da(
    x: xr.DataArray,
    y: xr.DataArray,
    integral_dim: str,
    integral_func: IntegralCallable = _trapz,
) -> xr.DataArray:
    """
    Apply an integral function to xarray DataArrays along a specified dimension.

    This function uses xarray's apply_ufunc to vectorize the integral operation
    across the data arrays.

    Args:
        x (xr.DataArray): The x-axis values for integration.
        y (xr.DataArray): The y-axis values to be integrated.
        integral_dim (str): The dimension along which to perform the integration.
        integral_func (IntegralCallable, optional): The integration function to use.
            Defaults to _trapz.

    Returns:
        xr.DataArray: The result of the integration operation.

    Note:
        This function assumes that x and y have the same shape and coordinates.
        It applies the integral_func to non-null values in both x and y.
    """
    return xr.apply_ufunc(
        integral_func,
        x,
        y,
        y.notnull() & x.notnull(),
        input_core_dims=[[integral_dim], [integral_dim], [integral_dim]],
        vectorize=True,
        dask="parallelized",
        dask_gufunc_kwargs={
            "allow_rechunk": True,
        },
        output_dtypes=[float],
    )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def spectrum_integral(
    x: SpectralDataArray,
    y: SpectralDataArray,
    integral_func: IntegralCallable = _trapz,
    mode_dim: str = MODE_DIM,
) -> TimeseriesDataArray:
    raise NotImplementedError(
        "This function is deprecated and will be removed in a future version. "
        "Use `integrate_da` instead. Example: ``integrate_da(x, y, integral_dim=mode_dim, integral_func=integral_func)``"
    )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def partial_fit_integral(
    data: ComboDataSet, integral_func: IntegralCallable = _trapz
) -> TimeseriesDataArray:
    """
    Calculate the ``partial_fit`` integral of a Dataset
    along the ``_datetime`` dimension.

    Args:
        data (ComboDataSet):
            The input combolog dataset containing spectral and fitter values.
        integral_func (IntegralCallable):
            The integral function to apply.
            Defaults to :py:func:`_trapz`

    Returns:
        xr.DataArray:
            The TimeseriesDataArray with the result of the integral.

    """
    required_vars = ["partial_fit", "nu_prime"]

    if not all([sv in data.spectral_var for sv in required_vars]):
        raise ValueError(
            f"Variables {required_vars} are required, but "
            f"found {list(data.spectral_var.values)} spectral variables"
        )

    return integrate_da(
        x=data.sel(spectral_var="nu_prime").spectral_values,
        y=data.sel(spectral_var="partial_fit").spectral_values,
        integral_func=integral_func,
        integral_dim=MODE_DIM,
    )


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def partial_fit_integral_equivalent(
    data: ComboDataSet,
    cids: list[int | str],
    prefix: str = "gasConcs_",
    integral_func: IntegralCallable = _trapz,
) -> TimeseriesDataArray:
    """
    Calculate the partial fit integral scaled in cids-equivalents.

    This function computes the ratio of the raw partial fit integral to the integral
    of the model functions for specified compounds.

    Args:
        data (ComboDataSet): The input dataset containing spectral data and model functions.
        cids (list[int | str]): List of CIDs to calculate the partial fit integral equivalent for.
        prefix (str, optional): Prefix for the gas concentration variables. Defaults to ``gasConcs_``.
        integral_func (IntegralCallable, optional): The integration function to use. Defaults to _trapz.

    Returns:
        TimeseriesDataArray: The ratio of the partial fit integral to the CIDs model functions integrals.

    Raises:
        ValueError: If the compound search accessor is not registered or if required spectral variables are missing.

    Note:
        This function requires the 'compound_search' accessor to be registered on the dataset.
        It also expects 'partial_fit' and 'nu_prime' to be present in the spectral variables.
    """
    required_vars = ["partial_fit", "nu_prime"]

    if not all([sv in data.spectral_var for sv in required_vars]):
        raise ValueError(
            f"Variables {required_vars} are required, but "
            f"found {list(data.spectral_var.values)} spectral variables"
        )

    try:
        cids_da = data.compound_search.get_model_functions(cids=cids, prefix=prefix)
    except AttributeError as e:
        raise ValueError(f"{COMPOUND_SEARCH_ERROR_MSG}{e}") from e

    original_integral = integrate_da(
        x=data.sel(spectral_var="nu_prime").spectral_values,
        y=data.sel(spectral_var="partial_fit").spectral_values,
        integral_func=integral_func,
        integral_dim=MODE_DIM,
    )

    cids_integral = integrate_da(
        x=data.sel(spectral_var="nu_prime").spectral_values,
        y=cids_da,
        integral_func=integral_func,
        integral_dim=MODE_DIM,
    )

    return original_integral / cids_integral
