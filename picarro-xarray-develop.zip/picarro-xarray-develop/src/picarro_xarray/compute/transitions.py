import numpy as np
import pandas as pd
from pydantic import validate_call

@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def split_transitions_by_duration(
    transition_uid: pd.Series,
    max_duration: pd.Timedelta | None = None,
) -> pd.Series:
    """
    Split contiguous runs of identical transition IDs into time-bounded segments.

    For a time-indexed Series of integer-like transition IDs, this function ensures
    each contiguous run (adjacent equal IDs) spans at most `max_duration`. When a run
    exceeds the allowed span, the ID is incremented to start a new segment. Offsets
    accumulate across runs to keep resulting IDs globally unique.

    Args:
        series (pd.Series): Time-indexed series of integer-like transition IDs.
            The index must be a monotonic increasing `DatetimeIndex` 
            (tz-naive or tz-aware) with no duplicate values.
        max_duration (pd.Timedelta | None): Maximum allowed duration for any contiguous
            run/segment. If None, no splitting is performed.

    Returns:
        pd.Series: Int64 Series with the same index and name. IDs are adjusted so each
        contiguous segment spans at most `max_duration`, and IDs remain unique globally.

    Raises:
        IndexError: If index is not a DatetimeIndex.
        ValueError: If index is not monotonic increasing, has duplicates, or values contain NA.
        TypeError: If values are not integer-like.
    """
    if not isinstance(transition_uid.index, pd.DatetimeIndex):
        raise IndexError("Series index must be a DatetimeIndex")
    
    if transition_uid.index.duplicated().any():
        raise ValueError("Series index contains duplicate values, use drop_duplicates to remove them")
    
    if not transition_uid.index.is_monotonic_increasing:
        raise ValueError("Index is not monotonic increasing")
    
    if max_duration is None or transition_uid.empty:
        return transition_uid.copy()
    
    if transition_uid.hasnans:
        raise ValueError("transition_uid contains NA; fill/drop before calling")

    base = transition_uid.to_numpy(copy=False)

    if base.dtype.kind not in "iu":
        raise TypeError(f"transition_uid must be integer-like; got dtype {base.dtype}")

    # nanoseconds since epoch (int64)
    idx_ns = transition_uid.index.view("i8").astype(np.int64)

    # Detect run starts and assign run IDs
    is_run_start = np.r_[True, base[1:] != base[:-1]]
    run_id = np.cumsum(is_run_start) - 1
    run_starts = np.flatnonzero(is_run_start)

    # Start time per row (from the run's first timestamp)
    start_ns_per_run = idx_ns[run_starts]
    start_ns_per_row = start_ns_per_run[run_id]

    # Elapsed nanoseconds from run start; subtract 1ns to allow equality at boundary
    elapsed_ns = idx_ns - start_ns_per_row
    elapsed_ns = np.maximum(elapsed_ns - 1, 0)

    max_ns = np.int64(max_duration.value)

    # Within-run segment index (0, 1, 2, ...)
    seg_idx = elapsed_ns // max_ns

    # Per-run maximum segment index (i.e., number of splits in the run)
    max_seg_idx_per_run = np.maximum.reduceat(seg_idx, run_starts)

    # Exclusive prefix sum of splits across prior runs, gives global offset per run
    prior_splits_per_run = np.empty_like(max_seg_idx_per_run)
    if max_seg_idx_per_run.size:
        np.cumsum(max_seg_idx_per_run, out=prior_splits_per_run)
        prior_splits_per_run -= max_seg_idx_per_run
    prior_splits_per_row = prior_splits_per_run[run_id]

    # Final IDs: base + splits from prior runs + within-run segment index
    res = base.astype(np.int64, copy=False) + prior_splits_per_row + seg_idx
    return pd.Series(res, index=transition_uid.index, name=transition_uid.name)
