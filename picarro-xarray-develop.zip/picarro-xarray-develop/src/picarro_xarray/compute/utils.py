import math
from os import PathLike
from pathlib import Path
from typing import Optional

import numpy as np
import xarray as xr
from pydantic import validate_call

from picarro_xarray.data_models.constants import CID_DIM, MODE_DIM, TIME_DIM
from picarro_xarray.data_models.data_types import TimeseriesDataArray, TimeseriesDataSet
from picarro_xarray.logger.logger import get_logger

LOGGER = get_logger(__name__)


def _filter_groups_population(
    groupby: TimeseriesDataArray,
    min_points: int,
) -> xr.DataArray:
    """
    Filter out groups with less than min_points.

    Args:
        groupby (TimeseriesDataArray):
            The input groupby data.
        min_points (int):
            Minimum number of points required to compute compactification.

    Returns:
        xr.DataArray:
            Array of groups with more than min_points.
    """
    # unique counts
    group_counts = groupby.to_pandas().value_counts()

    # filter out groups with less than min_points
    filtered_groups = group_counts[group_counts >= min_points].index.values

    dropped_groups = set(group_counts.index).difference(filtered_groups)

    for dropped_group in dropped_groups:
        LOGGER.info(
            f"Dropped group {dropped_group}: not enough points "
            f"(n={group_counts[dropped_group]} points, {min_points} required)"
        )

    return groupby.where(groupby.isin(filtered_groups).compute(), drop=True)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def maybe_cache(
    data: xr.Dataset | xr.DataArray,
    filename: str,
    temp_storage: Optional[str | PathLike] = None,
    delete_encoding: bool = True,
) -> xr.Dataset | xr.DataArray:
    """
    Conditionally caches a xarray dataset or data array to a zarr storage format.

    This function checks if a temporary storage path is provided. If so, it caches
    the provided data to a specified filename within this location in zarr format,
    and then reads and returns the data from the cache. If no temporary storage is
    provided, the input data is returned unchanged.

    Args:
        data (Union[xr.Dataset, xr.DataArray]):
            The xarray dataset or data array to be potentially cached.
        filename (str):
            The name of the file where the data should be cached.
        temp_storage (Optional[Union[str, PathLike]]):
            The path to a temporary storage directory.
            If provided, the function will cache the data to this location;
            otherwise, it returns the data unchanged.
        delete_encoding (bool):
            Whether to delete the encoding chunks attribute from the data
            before writing to zarr. Defaults to True.

    Returns:
        Union[xr.Dataset, xr.DataArray]:
            The original or cached Dataset or DataArray
    """
    if temp_storage is None:
        LOGGER.debug("No temporary storage provided; returning original data")
        return data

    LOGGER.debug(f"Caching data to {temp_storage}")
    temp_storage = Path(temp_storage)
    temp_storage.mkdir(parents=True, exist_ok=True)
    file_path = temp_storage / filename

    # remove encoding chunks attribute
    if delete_encoding:
        data = _remove_dask_encoding(data)

    suffix = Path(file_path).suffix
    if suffix == ".zarr":
        data.to_zarr(file_path, mode="w")
        data_out = xr.open_zarr(file_path)
    elif suffix == ".nc":
        data.to_netcdf(file_path, mode="w")
        data_out = xr.open_dataset(file_path)
    else:
        raise NotImplementedError(f"Unsupported file format {suffix}")

    return data_out if isinstance(data, xr.Dataset) else data_out[data.name]


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _remove_dask_encoding(data: xr.Dataset | xr.DataArray) -> xr.Dataset | xr.DataArray:
    """
    Remove the encoding chunks attribute from the data.

    Args:
        data (Union[xr.Dataset, xr.DataArray]):
            The input xarray dataset or data array.

    Returns:
        Union[xr.Dataset, xr.DataArray]:
            The input data with the encoding chunks attribute removed.
    """
    data_vars = (
        list(data.data_vars.keys()) if isinstance(data, xr.Dataset) else [data.name]
    )
    coord_vars = list(data.coords.keys())

    for var in data_vars + coord_vars:
        try:
            del data[var].encoding["chunks"]
        except KeyError:
            pass
    return data


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def remove_non_numeric_variables(
    data: TimeseriesDataArray | TimeseriesDataSet,
) -> TimeseriesDataArray | TimeseriesDataSet:
    """
    Removes non-numeric variables from the provided xarray DataArray or DataSet.

    Args:
        data (Union[xr.DataArray, xr.Dataset]):
            Input DataArray or DataSet.

    Returns:
        Union[xr.DataArray, xr.Dataset]:
            The input DataArray or DataSet with non-numeric variables removed.
            If the input is a DataArray with non-numeric dtype, a ``ValueError`` is raised.

    Raises:
        ValueError: Raised if the provided DataArray is not numeric.
    """
    if isinstance(data, xr.DataArray):
        if not np.issubdtype(data.dtype, np.number):
            raise ValueError(
                f"DataArray {data.name} has non-numeric dtype {data.dtype}"
            )
        return data

    non_numeric_vars = [
        var
        for var, da in data.data_vars.items()
        if not np.issubdtype(da.dtype, np.number)
    ]

    if non_numeric_vars:
        LOGGER.info(
            f"Non-numeric variables are not allowed when performing operations "
            f"on data. Found the following non-numeric variables: {non_numeric_vars}. "
            f"Those variables will be removed before proceeding with the computation."
        )
    return data.drop_vars(non_numeric_vars)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _rechunk_time(
    data: TimeseriesDataSet | TimeseriesDataArray,
    target_chunksize_mb: int = 100,
    time_dim: str = TIME_DIM,
) -> TimeseriesDataSet | TimeseriesDataArray:
    """
    Rechunks the data along the time dimension to a target chunksize in MB.

    This function optimizes the chunking strategy for xarray data by setting the time
    dimension to use a single chunk (all time points together) and calculating
    appropriate chunk sizes for other dimensions (MODE_DIM and CID_DIM) based on
    the target memory usage. This is a best-effort approach: specifying a chunk
    size that is too small will result in a single chunk along the time dimension,
    a single element across other dimensions, with a size larger than the target chunk size.

    The function assumes 8 bytes per element (float64) when calculating the number
    of elements that fit within the target chunk size.

    Args:
        data (Union[xr.Dataset, xr.DataArray]):
            The input xarray Dataset or DataArray to be rechunked.
        target_chunksize_mb (int, optional):
            Target chunk size in megabytes.
        time_dim (str, optional):
            Name of the time dimension. Defaults to TIME_DIM constant.

    Returns:
        Union[xr.Dataset, xr.DataArray]:
            The rechunked data with optimized chunk sizes. The time dimension
            will have a single chunk containing all time points, while MODE_DIM
            and CID_DIM will be chunked to approximate the target memory usage.

    Note:
        - The time dimension is always chunked as a single block (-1)
        - Other dimensions (MODE_DIM, CID_DIM) are chunked based on the calculated
          chunk size to stay within the target memory limit
        - The calculation assumes 8 bytes per element (float64 data)
    """
    n_elements = int(target_chunksize_mb * 1024 * 1024 / 8)
    time_size = data.sizes[time_dim]
    other_chunk_size = math.ceil(n_elements / time_size)
    return data.chunk(
        {
            time_dim: -1,
            **{
                dim: other_chunk_size for dim in (MODE_DIM, CID_DIM) if dim in data.dims
            },
        }
    )
