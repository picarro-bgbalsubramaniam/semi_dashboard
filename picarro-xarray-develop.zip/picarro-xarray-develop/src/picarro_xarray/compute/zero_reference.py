"""
This module contains functions to zero-reference data.

Example, assuming ds from a combolog zarr:

.. code-block:: python

    zero_referenced = get_zero_referenced_data(
        data=ds, transition_variable="ValveMask", reference_value=1.0
    )

"""

import os
from typing import Literal, Optional

import numpy as np
import xarray as xr
from flox.xarray import xarray_reduce
from pydantic import Field, validate_call

from picarro_xarray.compute.utils import (
    _rechunk_time,
    maybe_cache,
    remove_non_numeric_variables,
)
from picarro_xarray.data_models.constants import NPOINTS, NU_VARS
from picarro_xarray.data_models.data_types import TimeseriesDataArray, TimeseriesDataSet
from picarro_xarray.io.combolog.combo_log_prescan import DEFAULT_NU_CENTER_KEYS
from picarro_xarray.logger.logger import get_logger
from picarro_xarray.time_utils.timeutils import _parse_grouper
from picarro_xarray.validators.timeseries import TIME_DIM

CHUNK_VARIABLES_SIZE = 5
GROUP_NAME = "reference_uid"

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_zero_referenced_data(
    data: TimeseriesDataArray | TimeseriesDataSet,
    transition_variable: str | TimeseriesDataArray,
    reference_value: str | int | float,
    event_window_width: int = Field(default=4, ge=1),
    center: bool = False,
    time_dim: str = TIME_DIM,
    group_name: str = GROUP_NAME,
    data_aggregation: Literal["mean", "median"] = "median",
    passthrough_spectral_vars: list[str] = NU_VARS + NPOINTS,
    passthrough_fitter_vars: list[str] = DEFAULT_NU_CENTER_KEYS,
    temp_storage: Optional[str | os.PathLike] = None,
    target_chunksize_mb: int = Field(default=200, ge=50),
) -> TimeseriesDataArray | TimeseriesDataSet:
    """
    Obtains zero-referenced data from a given timeseries dataset.

    This function identifies transitions within the data based on the provided
    transition variable.
    The reference data is build by averaging the data for each unique transition
    where the transition variable is equal to the reference value.
    A rolling average is then calculated on the reference data.
    An interpolation is then performed to align the reference data with the original data.
    The interpolated zero is subtracted from the original data to zero-reference it.

    .. warning::
        Behavior changed in version 0.0.17:
        The default values were changed for ``center``, ``event_window_width``, and ``data_aggregation``:
        - ``center`` was changed from ``True`` to ``False``
        (to avoid looking ahead in time)
        - ``event_window_width`` was changed from 2 to 4.
        - ``data_aggregation`` was changed from ``mean`` to ``median``.
        To keep the same behavior as before, set ``center=True``, ``event_window_width=5``,
        and ``data_aggregation="mean"``.

    Args:
        data (Union[TimeseriesDataArray, TimeseriesDataSet]): The input dataset or data array.
        transition_variable (str):
            The variable name that represents transitions in the data. For example, `ValveMask`.
        reference_value (Union[str, int, float]):
            The value of ``transition_variable`` that identifies the reference data.
        event_window_width (int, optional):
            The width of the event window. Defaults to 2. Must be at least 1.
        center (bool, optional):
            If True, the rolling average is centered.
            If False, the rolling average is right-aligned.
            Defaults to True.
        time_dim (str, optional):
            The name of the time dimension. Defaults to ``TIME_DIM``.
        group_name (str, optional):
            The name to use for the grouping variable. Defaults to ``GROUP_NAME``.
        data_aggregation (str, optional):
            The aggregation method to use for the data.
            Possible values are 'mean' or 'median'.
            Defaults to 'mean'.
        passthrough_spectral_vars (list[str], optional):
            The list of spectral variables to pass through without
            zero-referencing. Defaults to ``NU_VARS``.
        passthrough_fitter_vars (list[str], optional):
            The list of fitter variables to pass through without
            zero-referencing. Defaults to ``DEFAULT_NU_CENTER_KEYS``.
        temp_storage (Path | os.PathLike, optional):
            The temporary storage location for caching. Defaults to None.
            If provided, the function will cache intermediate results to this location.
            This can be useful when operating on large datasets to avoid overwhelming
            the dask scheduler with too many sequential tasks and to avoid memory issues.
            If None, no caching is performed and the operation is performed in a streaming
            fashion. This can result in slower performance and memory spillage
            for large datasets.
        target_chunksize_mb (int, optional):
            The target chunk size in MB for the time dimension, if data is chunked.
            Defaults to 200MB. This is needed for the interpolation step, which requires
            the data to be in a single chunk along the time dimension. If you have a large
            amount of RAM, you can set this to a larger value.

    Returns:
        Union[TimeseriesDataArray, TimeseriesDataSet]: Zero-referenced dataset or data array.

    Raises:
        ValueError: If the transition variable is not found
            among the ``fitter_var`` variables in the data.

    Example, assuming ``ds`` is from a combolog zarr:

    .. code-block:: python

        zero_referenced = get_zero_referenced_data(
            data=ds, transition_variable="ValveMask", reference_value=1.0
        )

    """
    use_ds = data.to_dataset() if isinstance(data, xr.DataArray) else data
    use_ds = remove_non_numeric_variables(use_ds)

    # Use 'first' for forward-fill alignment when not centered
    # ('mean' would cause forward-fill to incorrectly split reference groups
    # across previous values), 'mean' for temporal centering when centered
    datetime_agg = "mean" if center else "first"

    # read chunks from input data
    chunks = {k: v[0] for k, v in use_ds.chunks.items()}

    # drop passthrough variables from the interpolation process
    use_ds = _filter_passthrough_variables(
        original_data=use_ds,
        passthrough_vars=passthrough_fitter_vars,
        passthrough_dim="fitter_var",
    )
    use_ds = _filter_passthrough_variables(
        original_data=use_ds,
        passthrough_vars=passthrough_spectral_vars,
        passthrough_dim="spectral_var",
    )

    LOGGER.debug(f"Use data sizes: {use_ds.sizes}. Chunks: {chunks}")

    transition_data = _parse_grouper(
        data=data, grouper=transition_variable, time_dim=time_dim
    )

    reference_uid = get_reference_transitions_uid(
        transition_variable_data=transition_data,
        reference_value=reference_value,
        time_dim=time_dim,
    )

    LOGGER.debug("Get reference averages")
    reference_data = get_contiguous_group_averages(
        data=use_ds,
        grouper_da=reference_uid,
        datetime_axis_aggregation=datetime_agg,
        data_aggregation=data_aggregation,
        group_name=group_name,
        time_dim=time_dim,
    )
    reference_data = reference_data.chunk(chunks)
    reference_data = maybe_cache(
        reference_data, "reference_data.zarr", temp_storage, delete_encoding=False
    )

    LOGGER.debug("Get rolling average")
    if time_dim in chunks:
        # rechunk before interpolation to make sure that the time
        # dimension is not chunked, and the remaining dimensions
        # are not too small
        reference_data = _rechunk_time(
            data=reference_data,
            target_chunksize_mb=target_chunksize_mb,
            time_dim=time_dim,
        )

    # rolling average of reference port data using #event_window_width transitions
    reference_roll = (
        reference_data.rolling(
            {time_dim: event_window_width}, center=center, min_periods=1
        )
        .construct("win")
        .mean("win")
    )
    reference_roll = reference_roll.chunk(chunks)
    reference_roll = maybe_cache(
        reference_roll, "reference_roll.zarr", temp_storage, delete_encoding=False
    )

    # interpolate averages on time_eval. Chunk time as existing data
    time_eval = xr.DataArray(
        data[time_dim],
        dims=[time_dim],
        coords={time_dim: data[time_dim]},
        name="time_eval",
    ).chunk({time_dim: chunks[time_dim]} if time_dim in chunks else {})

    if reference_roll.sizes[time_dim] <= 1:
        msg = (
            "No interpolation performed for reference data: "
            "only one contiguous instance of reference data was detected. "
            "Please try to provide more reference data instances for better"
            " zero-referencing results."
        )
        LOGGER.warning(msg)
        reference_interp = reference_roll.squeeze(time_dim).expand_dims(
            {time_dim: data[time_dim]}
        )
    else:
        if center:
            LOGGER.debug("Interpolate rolling average")
            reference_interp = get_interpolated_data(
                data=reference_roll,
                datetime_eval=time_eval,
            )
        else:
            # if not centered, we need to propagate the last reference value
            # forward to avoid the lookahead I would have if I interpolated
            LOGGER.debug("Propagate last reference value")
            reference_interp = propagate_reference_value(
                data=reference_roll,
                datetime_eval=time_eval,
            )

    reference_interp = reference_interp.chunk(chunks)
    reference_interp = maybe_cache(
        reference_interp, "reference_interp.zarr", temp_storage
    )

    LOGGER.debug("Reindex interpolated zero reference")
    reference_interp = reference_interp.reindex_like(
        data, fill_value=0, copy=False
    ).chunk(chunks)

    reference_interp = maybe_cache(
        reference_interp, "reference_interp_reindex.zarr", temp_storage
    )

    LOGGER.debug("Perform zero referencing")
    zero_ref = perform_zero_referencing(data=data, zero_reference_data=reference_interp)

    return zero_ref[data.name] if isinstance(data, xr.DataArray) else zero_ref


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _filter_passthrough_variables(
    original_data: TimeseriesDataArray | TimeseriesDataSet,
    passthrough_vars: list[str],
    passthrough_dim: str,
) -> TimeseriesDataArray | TimeseriesDataSet:
    """
    Filter out passthrough variables from the original data.
    Returns a new DataArray (or DataSet) with the passthrough
    variables removed, if present. Otherwise, returns the original data.

    Args:
        original_data (TimeseriesDataArray | TimeseriesDataSet):
            The original data array or dataset.
        passthrough_vars (list[str]):
            The list of passthrough variables to filter out.
            Examples: ``['nu_prime', 'npoints']``
        passthrough_dim (str):
            The name of the passthrough dimension.
            Example: ``'spectral_var'``.

    Returns:
        TimeseriesDataArray | TimeseriesDataSet:
            A DataArray or Dataset with the passthrough variables removed.
    """
    passthrough_vars = [
        var
        for var in passthrough_vars
        if var in original_data.coords.get(passthrough_dim, [])
    ]

    if passthrough_vars:
        LOGGER.info(
            f"Zero reference ({passthrough_dim}): passing through {passthrough_vars}"
        )
        return original_data.drop_sel({passthrough_dim: passthrough_vars})
    else:
        return original_data


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_transition_uid(
    transition_data: TimeseriesDataArray,
    time_dim: str = TIME_DIM,
) -> TimeseriesDataArray:
    """
    Calculate a unique identifier (UID) for transitions within a given TimeseriesDataArray.

    The function detects transitions by comparing each element with its preceding element.
    A cumulative sum is applied on the boolean transition mask to generate
    a unique identifier for each transition segment.

    Args:
        transition_data (TimeseriesDataArray):
            The data array containing timeseries data. Must have dimension `_datetime`.
            Each point is compared with the previous to detect transitions.

        time_dim (str, optional):
            The name of the time dimension.
            Defaults to ``TIME_DIM``.
            Example: ``_datetime``

    Returns:
        TimeseriesDataArray:
            A data array of the same shape as the input, containing unique
            identifiers for each transition segment.
            The first uid is always 1.

    Example:

    >>> import pandas as pd
    >>> dt = pd.date_range("2020-01-01", periods=6, freq="1D")
    >>> data = xr.DataArray([1, 1, 2, 2, 3, 3], dims=[TIME_DIM], coords={TIME_DIM: dt})
    >>> get_transition_uid(data)  # doctest: +ELLIPSIS
    <xarray.DataArray (_datetime: 6)>...
    array([1, 1, 2, 2, 3, 3])
    ...
    """
    mask = transition_data != transition_data.shift({time_dim: 1})
    port_id = mask.cumsum(dim=time_dim)
    return port_id


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_reference_transitions_uid(
    transition_variable_data: TimeseriesDataArray,
    reference_value: str | int | float,
    time_dim: str = TIME_DIM,
) -> TimeseriesDataArray:
    """
    Get the unique identifier (UID) for specific reference values within a TimeseriesDataArray.

    This function extracts unique identifiers corresponding to specific ``reference_value`` occurrences.
    First, the unique identifier for each transition is calculated using :func:`get_transition_uid`.
    Then, the data is filtered based on the given reference value.

    Example:

    >>> import pandas as pd
    >>> dt = pd.date_range("2020-01-01", periods=8, freq="1D")
    >>> data = xr.DataArray(
    ... [100, 100, 11, 11, 28, 28, 100, 100],
    ... coords={TIME_DIM: dt},
    ... dims=[TIME_DIM],
    ... )
    >>> get_reference_transitions_uid(data, reference_value=100)  # doctest: +ELLIPSIS
    <xarray.DataArray (_datetime: 4)>...
    array([1, 1, 4, 4])
    Coordinates:
    ...

    Args:
        transition_variable_data (TimeseriesDataArray):
            The data array containing timeseries data. Must have dimension ``_datetime``.
        reference_value (str | int | float):
            The value that is considered as a reference. Data points
            matching this value will be identified.
        time_dim (str, optional):
            The name of the time dimension.
            Defaults to ``TIME_DIM``.
            Example: `_datetime`

    Returns:
        TimeseriesDataArray:
            A data array containing unique identifiers for each consecutive occurrence of the
            given reference_value. The length of the data array is equal to the number
            of occurrences of the reference_value consecutive occurrences.
            As such, length of _datetime is not preserved.
    """

    # get unique transition id
    transition_uid = get_transition_uid(transition_data=transition_variable_data)

    # look only when a transition matches the reference value
    mask_transition = transition_variable_data == reference_value
    mask_transition = mask_transition.compute()

    all_false = not mask_transition.any().item()
    if all_false:
        raise ValueError(
            f"Reference value {reference_value} not found in transition variable data."
        )

    # get the time corresponding to the reference value
    mask_time = transition_variable_data[time_dim].where(mask_transition, drop=True)

    # get uid of different reference values occurrences
    reference_uid = transition_uid.sel({time_dim: mask_time})

    return reference_uid


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_contiguous_group_averages(
    data: TimeseriesDataArray | TimeseriesDataSet,
    grouper_da: TimeseriesDataArray,
    datetime_axis_aggregation: str = "mean",
    data_aggregation: Literal["mean", "median"] = "mean",
    group_name: str = GROUP_NAME,
    time_dim: str = TIME_DIM,
) -> TimeseriesDataArray | TimeseriesDataSet:
    """
    Calculate the average values for each consecutive reference occurrence
    in a timeseries dataarray.

    This function calculates average values of the data for each unique reference_uid.
    The averages are computed blockwise for computational efficiency.

    Example:

    >>> import pandas as pd
    >>> da = xr.DataArray(
    ... [
    ...     [1, 2, 3, 4, 5, 6, 7, 8],
    ...     [8, 7, 6, 5, 4, 3, 2, 1],
    ...     [0, 0, 0, 1, 1, 0, 0, 0],
    ... ],
    ... coords=[
    ...    ["A", "B", "port"],
    ...    pd.date_range("2020-01-01", periods=8, freq="1D")
    ... ],
    ... dims=["var_", TIME_DIM],
    ... )
    >>> ref_uid = get_reference_transitions_uid(da.sel(var_="port"), reference_value=0)
    >>> get_contiguous_group_averages(da, ref_uid)  # doctest: +ELLIPSIS +NORMALIZE_WHITESPACE
    <xarray.DataArray (var_: 3, _datetime: 2)>...
    array([[2., 7.],
          [7., 2.],
          [0., 0.]])
    Coordinates:
    ...


    Args:
        data (TimeseriesDataArray):
            The data array containing timeseries data. Must have a ``_datetime`` dimension.
        grouper_da (TimeseriesDataArray):
            The data array containing unique identifiers for each reference occurrence.
            These UIDs are used to subset the original data.
            From :func:`get_reference_transitions_uid`.
        datetime_axis_aggregation (str, optional):
            The aggregation method to use for the datetime axis.
            Defaults to 'mean'.
        data_aggregation (str, optional):
            The aggregation method to use for the data.
            Possible values are 'mean' or 'median'.
            Defaults to 'mean'.
        group_name (str, optional):
            The name of the group dimension.
            Defaults to ``GROUP_NAME``.
        time_dim (str, optional):
            The name of the time dimension.
            Defaults to ``TIME_DIM``.
            Example: ``_datetime``

    Returns:
        TimeseriesDataArray:
            A new data array containing the averages for each unique reference occurrence.
            The array has the same coordinates as the input ``data``,
            with ``_datetime`` being the new assigned coordinate
            (mean of each reference unique identifier datetimes).

    """
    # keep only the coordinates that are also dimensions
    grouper_da = _drop_non_dim_coords(grouper_da)
    grouper_da.name = group_name
    grouper_da.load()

    # flox needs to know beforehand the expected groups
    classes = np.unique(grouper_da)

    # get the reference port data
    reference_data = data.sel({time_dim: grouper_da[time_dim]})

    # get the average of the reference port data per transition
    # use flox, zeroes groups are very local
    # and not reoccuring (-> blockwise)
    reference_data = remove_non_numeric_variables(reference_data)

    if data_aggregation == "median":
        reference_avgs = xarray_reduce(
            reference_data,
            grouper_da,
            func="nanmedian",
            expected_groups=classes,
            method="blockwise",
        )
    else:
        reference_avgs = xarray_reduce(
            reference_data,
            grouper_da,
            func="nanmean",
            expected_groups=classes,
            method="blockwise",
        )

    # get the time of each reference uid
    interval_stats = (
        reference_data[time_dim]
        .to_pandas()
        .groupby(grouper_da.values)
        .agg(duration=np.ptp, ref_time=datetime_axis_aggregation)
    )

    # duration to seconds
    interval_stats["duration"] = interval_stats["duration"].dt.total_seconds()

    reference_avgs = reference_avgs.assign_coords(
        {
            time_dim: (group_name, interval_stats["ref_time"].values),
            "duration_seconds": (group_name, interval_stats["duration"].values),
        }
    )
    reference_avgs = reference_avgs.swap_dims({group_name: time_dim})

    return reference_avgs


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_interpolated_data(
    data: TimeseriesDataArray | TimeseriesDataSet,
    datetime_eval: TimeseriesDataArray,
    time_dim: str = TIME_DIM,
) -> TimeseriesDataArray | TimeseriesDataSet:
    """
    Interpolates the rolling average reference data
    to align with the original data's time coordinates.

    Args:
        data (TimeseriesDataArray):
            A data array containing the rolling average reference data
            from :func:`get_rolling_average`.
        datetime_eval (TimeseriesDataArray):
            A data array containing the ``_datetime`` coordinates of the original data.
            Example: ``ds['_datetime']``
        time_dim (str, optional):
            The name of the time dimension. Defaults to ``TIME_DIM``.

    Returns:
        TimeseriesDataArray:
            The interpolated rolling average reference data.

    Notes:
        From version 2025.3.0, xarray's interp uses apply_ufunc internally,
        which needs the data to be in a single chunk along the time dimension.
        Here, we explicitely do that, but caller needs to make sure that that's okay
        in terms of memory needs (better to reduce the chunk size along the other dimensions).
    """
    if data.chunks is not None:
        data = data.chunk({time_dim: -1})

    zero_reference_da = data.interp(
        _datetime=datetime_eval,
        assume_sorted=True,
        method="linear",
        kwargs={"fill_value": "extrapolate", "bounds_error": False},
    )
    return zero_reference_da


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def propagate_reference_value(
    data: TimeseriesDataArray | TimeseriesDataSet,
    datetime_eval: TimeseriesDataArray,
    time_dim: str = TIME_DIM,
) -> TimeseriesDataArray | TimeseriesDataSet:
    """
    Reindex data to the datetime_eval coordinates, and fill forward to propagate
    the last reference value. Additionally, fill backward to propagate the first
    reference value to the start of the data.

    Args:
        data (TimeseriesDataArray):
            A data array containing the rolling average reference data
            from :func:`get_rolling_average`.
        datetime_eval (TimeseriesDataArray):
            A data array containing the ``_datetime`` coordinates of the original data.
            Example: ``ds['_datetime']``
        time_dim (str, optional):
            The name of the time dimension. Defaults to ``TIME_DIM``.

    Returns:
        TimeseriesDataArray: The reindexed and filled data array.
    """
    reference_interp = data.reindex({time_dim: datetime_eval[time_dim]})
    reference_interp = reference_interp.ffill(time_dim).bfill(time_dim)
    return reference_interp


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def perform_zero_referencing(
    data: TimeseriesDataArray | TimeseriesDataSet,
    zero_reference_data: TimeseriesDataArray | TimeseriesDataSet,
) -> TimeseriesDataArray | TimeseriesDataSet:
    """
    Subtracts the zero_reference data array from the original data
    to zero-reference it.

    Args:
        data (TimeseriesDataArray):
            Original data array that needs to be zero-referenced.
        zero_reference_data (TimeseriesDataArray):
            Data array that contains the zero-reference values.

    Returns:
        TimeseriesDataArray: The zero-referenced data array.

    Notes:
        The function first re-chunks the zero_reference data array
        to match the chunk sizes
        of the original data before performing the subtraction.
    """
    return data - zero_reference_data


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def _drop_non_dim_coords(data: TimeseriesDataArray) -> TimeseriesDataArray:
    """
    Drop coordinates that are not dimensions.

    Args:
        data (TimeseriesDataArray):
            The data array containing timeseries data.

    Returns:
        TimeseriesDataArray:
            A data array containing only coordinates that are also dimensions.
    """
    drop_vars = [var for var in data.coords if var not in data.dims]
    return data.drop_vars(drop_vars)
