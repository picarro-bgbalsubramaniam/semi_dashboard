import unittest

import numpy as np
import xarray as xr
import pandas as pd
import pytest
from pydantic import ValidationError

from picarro_xarray.data_models.constants import TIME_DIM
from picarro_xarray.time_utils.timeutils import (
    _convert_h5_timestamp,
    get_median_time_delta_seconds, _parse_grouper,
)


def test_convert_h5_timestamp():
    with pytest.raises(ValidationError):
        _ = _convert_h5_timestamp("abc")

    with pytest.raises(ValidationError):
        _ = _convert_h5_timestamp(63798364799150.86)

    # GMT: Friday, September 9, 2022 11:59:59 PM
    # 63798364799.150 Seconds Since 0001-01-01 AD
    ts = 1e9 * np.arange(0, 30) + 63798364799150.86

    utc = _convert_h5_timestamp(ts)
    assert isinstance(utc, pd.DatetimeIndex)
    assert utc[0].year == 2022
    assert utc[0].month == 9
    assert utc[0].day == 9
    assert utc[0].hour == 23
    assert utc[0].minute == 59
    assert utc[0].second == 59


class TestGetMedianTimeDelta(unittest.TestCase):
    def setUp(self):
        dt = [
            "2021-09-01T12:00:00",
            "2021-09-01T12:05:00",
            "2021-09-01T12:10:00",
            "2021-09-01T12:15:00",
            "2021-09-01T12:20:00",
            "2021-09-01T12:25:00",
        ]
        self.time_da = xr.DataArray(
            np.arange(len(dt)),
            coords={TIME_DIM: pd.to_datetime(dt)},
            dims=TIME_DIM,
        )

    def test_success_no_group(self):
        median_time_delta = get_median_time_delta_seconds(
            self.time_da, group_name="test"
        )
        assert isinstance(median_time_delta, xr.DataArray)
        self.assertAlmostEqual(median_time_delta.item(), 300.0)
        assert "test" in median_time_delta.dims

    def test_success_group(self):
        group = xr.DataArray(
            data=["a", "a", "b", "b", "b", "b"],
            dims=TIME_DIM,
            coords={TIME_DIM: self.time_da[TIME_DIM].values},
        )

        median_time_delta = get_median_time_delta_seconds(
            data=self.time_da, groupby=group, group_name="test"
        )
        assert isinstance(median_time_delta, xr.DataArray)
        assert np.allclose(median_time_delta.values, [300.0, 300.0])
        assert "test" in median_time_delta.dims

    def test_success_ds_no_group(self):
        median_time_delta = get_median_time_delta_seconds(
            self.time_da.to_dataset(name="test")
        )
        assert isinstance(median_time_delta, xr.DataArray)
        self.assertAlmostEqual(median_time_delta.item(), 300.0)

    def test_no_time_dim(self):
        with self.assertRaises(ValueError):
            get_median_time_delta_seconds(self.time_da.rename({TIME_DIM: "time"}))


class TestGrouperParser(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds = request.getfixturevalue("combolog_ds")
        dt = [
            "2021-09-01T12:00:00",
            "2021-09-01T12:05:00",
            "2021-09-01T12:10:00",
            "2021-09-01T12:15:00",
            "2021-09-01T12:20:00",
            "2021-09-01T12:25:00",
        ]
        self.time_da = xr.DataArray(
            np.arange(len(dt)),
            coords={TIME_DIM: pd.to_datetime(dt)},
            dims=TIME_DIM,
        )

    def test_success_none(self):
        grouper = _parse_grouper(data=self.time_da)
        assert isinstance(grouper, xr.DataArray)
        assert np.allclose(grouper.values, np.ones(self.time_da.sizes[TIME_DIM]))

    def test_success_ds_str(self):
        res = _parse_grouper(
            data=self.ds,
            grouper="group_this",
            group_name="group_this",
        )
        assert isinstance(res, xr.DataArray)
        assert np.allclose(res.values, self.ds.sel(fitter_var='group_this').fitter_values.values)

    def test_fail_ds_str(self):
        with self.assertRaises(ValueError):
            _parse_grouper(
                data=self.ds,
                grouper="group_that",
            )

    def test_success_da(self):
        group = xr.DataArray(
            data=["a", "a", "b", "b", "b", "b"],
            dims=TIME_DIM,
            coords={TIME_DIM: self.time_da[TIME_DIM].values},
        )
        grouper = _parse_grouper(data=self.time_da, grouper=group, group_name='abc')
        assert isinstance(grouper, xr.DataArray)
        assert grouper.equals(group)
        assert grouper.name == 'abc'

    def test_success_da_str(self):
        res = _parse_grouper(
            data=self.ds.fitter_values,
            grouper="group_this",
            group_name="group_this",
        )
        assert isinstance(res, xr.DataArray)
        assert np.allclose(res.values, self.ds.sel(fitter_var='group_this').fitter_values.values)


    def test_fails_length(self):
        group = xr.DataArray(
            data=["a", "a", "b", "b", "b"],
            dims=TIME_DIM,
            coords={TIME_DIM: self.time_da[TIME_DIM].values[:-1]},
        )
        with self.assertRaises(ValueError):
            _parse_grouper(data=self.time_da, grouper=group)

    def test_fails_grouper_2d(self):
        group = xr.DataArray(
            data=[["a", "a", "b", "b", "b", "b"], ["a", "a", "b", "b", "b", "b"]],
            dims=["dim1", TIME_DIM],
            coords={TIME_DIM: self.time_da[TIME_DIM].values},
        )
        with self.assertRaises(ValueError):
            _parse_grouper(data=self.time_da, grouper=group)
