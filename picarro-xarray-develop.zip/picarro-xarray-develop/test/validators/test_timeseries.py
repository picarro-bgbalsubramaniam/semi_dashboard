import numpy as np
import pandas as pd
import pytest
import xarray as xr

from picarro_xarray.data_models.constants import TIME_DIM
from picarro_xarray.validators.timeseries import (
    verify_allan_array,
    verify_bounds_array,
    verify_combo_data,
    verify_compact_data,
    verify_mode_dimension,
    verify_time_dimension,
)


def test_verify_bounds():
    da = xr.DataArray(
        data=[
            ["2023-05-11T17:00:00", "2023-05-11T17:20:00"],  # min
            ["2023-05-11T17:02:00", "2023-05-11T17:23:00"],
        ],  # max
        dims=["stats", "group"],
        coords={"stats": ["min", "max"], "group": [1, 2]},
    ).astype("datetime64[ns]")

    with pytest.raises(ValueError):
        verify_bounds_array(da.rename({"stats": "stats2"}))

    with pytest.raises(ValueError):
        verify_bounds_array(da.rename({"group": "group2"}))

    with pytest.raises(ValueError):
        da2 = da.copy(deep=True)
        da2["stats"] = ["minnnnn", "max"]
        verify_bounds_array(da2)

    with pytest.raises(ValueError):
        da2 = da.copy(deep=True)
        da2["stats"] = ["min", "maxxxx"]
        verify_bounds_array(da2)


def test_verify_time_dimension():
    time_array = pd.date_range(
        "2023-01-01",
        periods=10,
        freq="5s",
    )
    da = xr.DataArray(
        data=np.arange(10),
        dims=[TIME_DIM],
        coords={TIME_DIM: time_array},
    )

    with pytest.raises(ValueError):
        da2 = da.copy(deep=True)
        da2 = da2.rename({TIME_DIM: "time"})
        verify_time_dimension(da2)

    with pytest.raises(ValueError):
        da2 = da.copy(deep=True)
        da2[TIME_DIM] = da2[TIME_DIM].astype(int)
        verify_time_dimension(da2)

    result = verify_time_dimension(da)
    assert result is da

    ds = da.to_dataset(name="test")
    result = verify_time_dimension(ds)
    assert result is ds

    idx = pd.date_range("2023-01-01", periods=10, freq="5s", name=TIME_DIM).astype(
        "datetime64[us]"
    )
    df = pd.DataFrame(np.random.rand(10, 2), index=idx, columns=list("AB"))
    result = verify_time_dimension(df.stack().to_xarray())
    assert isinstance(result, xr.DataArray)


def test_verify_mode_dimension(combolog_ds):
    ds = combolog_ds.copy()

    with pytest.raises(ValueError):
        verify_mode_dimension(ds.rename({"mode": "mode2"}))

    result = verify_mode_dimension(ds)
    assert result is ds

    da = ds.spectral_values
    result = verify_mode_dimension(da)
    assert result is da

    with pytest.raises(ValueError):
        verify_mode_dimension(da.rename({"mode": "mode2"}))


def test_verify_combo_data(combolog_ds):
    ds = combolog_ds.copy()

    with pytest.raises(ValueError):
        verify_combo_data(ds.rename({"fitter_var": "fitter_var2"}))

    with pytest.raises(ValueError):
        verify_combo_data(ds.rename({"spectral_var": "spectral_var2"}))

    with pytest.raises(ValueError):
        verify_combo_data(ds.rename({"mode": "mode2"}))

    result = verify_combo_data(ds)
    assert result is ds


def test_verify_compact_data(compat_dataset):
    ds = compat_dataset.copy()
    result = verify_compact_data(ds)
    assert result is ds

    # Missing 'stat' dimension
    ds_no_stat = ds.copy(deep=True)
    ds_no_stat = ds_no_stat.rename({"stat": "stat2"})
    with pytest.raises(ValueError, match="input must have a `stat` dimension"):
        verify_compact_data(ds_no_stat)

    # Missing 'spectral_values_stats' variable
    ds_no_var = ds.copy(deep=True)
    ds_no_var = ds_no_var.rename({"spectral_values_stats": "spectral_values_stats2"})
    with pytest.raises(
        ValueError, match="input must have a `spectral_values_stats` variable"
    ):
        verify_compact_data(ds_no_var)


def test_verify_allan_array(compat_dataset):
    ds = compat_dataset.copy()
    result = verify_allan_array(ds)
    assert result is ds

    # Missing 'tau' dimension
    ds_no_tau = ds.copy(deep=True)
    ds_no_tau = ds_no_tau.rename({"tau": "tau2"})
    with pytest.raises(ValueError, match="input must have a `tau` dimension"):
        verify_allan_array(ds_no_tau)

    # Missing 'n_samples' dimension
    ds_no_n_samples = ds.copy(deep=True)
    ds_no_n_samples = ds_no_n_samples.rename({"n_samples": "n_samples2"})
    with pytest.raises(ValueError, match="input must have a `n_samples` dimension"):
        verify_allan_array(ds_no_n_samples)
