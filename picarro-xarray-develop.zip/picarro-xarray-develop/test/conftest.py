import numpy as np
import pandas as pd
import pytest
import xarray as xr
from spectral_arithmetic.data_models.model_function import ModelFunctions
from spectral_arithmetic.linear_least_squares import LinearLeastSquares


@pytest.fixture
def privatelog_ds():
    my_paths = [f"my_private_path{i // 2}" for i in range(1, 100 + 1)]
    ds_private = xr.Dataset(
        data_vars={
            "private_values": (("_datetime", "private_var"), np.random.rand(100, 4)),
            "private_logs_origin": (
                "_datetime",
                my_paths,
                {"files": list(set(my_paths))},
            ),
        },
        coords={
            "_datetime": (
                "_datetime",
                pd.date_range("2022-10-17 00:00:01", periods=100, freq="4s"),
            ),
            "private_var": ("private_var", [f"my_var{i}" for i in range(4)]),
        },
        attrs={
            "tz": "US/Pacific",
            "analyzer": "my_analyzer",
        },
    )
    return ds_private


@pytest.fixture
def combolog_ds():
    paths = [f"my_path{i // 2}" for i in range(1, 10 + 1)]

    fitter_values = np.array(
        [
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            [10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
            [0, 0, 0, 1, 1, 0, 0, 0, 2, 2],
            [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
        ]
    ).transpose()

    spectral_values = np.arange(0, 480)
    spectral_values = spectral_values.reshape(10, 12, 4)

    ds_combo = xr.Dataset(
        data_vars={
            "spectral_values": (
                ("_datetime", "mode", "spectral_var"),
                spectral_values,
            ),
            "fitter_values": (("_datetime", "fitter_var"), fitter_values),
            "fitter_origin_file": ("_datetime", paths, {"files": list(set(paths))}),
        },
        coords={
            "_datetime": (
                "_datetime",
                pd.date_range("2020-01-01", periods=10, freq="D"),
            ),
            "mode": ("mode", [2 * i for i in range(12)]),
            "spectral_var": (
                "spectral_var",
                ["nu", "partial_fit", "npoints", "nu_prime"],
            ),
            "fitter_var": (
                "fitter_var",
                ["a", "b", "group_this", "fitData_fitdata_params_nucenter"],
            ),
        },
        attrs={
            "tz": "US/Pacific",
            "analyzer": "my_analyzer",
        },
    )
    return ds_combo


@pytest.fixture
def fom_data_array():
    data = np.array(
        [
            [0.23973062, 1.59627588],
            [0.1904888, 2.82078024],
            [0.01183944, 2.31371385],
            [0.23276116, 1.67222646],
            [0.21161534, 2.87487538],
            [0.17466845, 1.70766248],
            [0.34467474, 1.60447289],
            [0.19597722, 2.82179665],
            [0.32492324, 1.20087208],
            [2.04647139, 1.66850171],
            [0.20019883, 2.84826745],
            [0.47270244, 0.57778978],
            [6.34132375, -3.30418916],
            [1.17126538, 0.67982116],
            [0.62902414, -0.04070904],
            [1.56336218, 4.16227599],
            [1.19330726, 0.65133903],
            [0.81018293, 0.04081572],
            [-0.44269687, 1.70026316],
            [1.18278245, 0.7312303],
            [0.97006065, 0.56051584],
            [-0.917742, 1.59819025],
            [1.18618509, 0.72946527],
            [1.11038223, 1.23959608],
            [-0.90881626, 1.6178119],
            [1.18729387, 0.72440624],
            [1.28220047, 1.75725226],
            [-0.91756048, 1.62935834],
            [1.18733728, 0.73130648],
            [1.44455053, 2.34931409],
        ]
    )

    # Create datetime index
    datetimes = pd.date_range(start="2020-01-01", periods=30, freq="D")

    # Create coordinates
    fitter_var = np.array(["a", "b"])
    group_uid = np.arange(1, 31)
    duration_seconds = np.array(
        [14400, 10800, 7200] * 10,
    )

    abcde = np.tile([0.0, 1.0, 2.0], 10)

    # Create the DataArray
    da = xr.DataArray(
        data=data,
        dims=("_datetime", "fitter_var"),
        coords={
            "_datetime": datetimes,
            "fitter_var": fitter_var,
            "group_uid": ("_datetime", group_uid),
            "duration_seconds": ("_datetime", duration_seconds),
            "abcde": ("_datetime", abcde),
            "group": 1.0,
            "tau": 1,
            "tau_scaled": 3600.0,
            "n_samples": 119,
        },
    )

    return da


@pytest.fixture
def compat_dataset():
    # Coordinates
    fitter_var = [f"fvar{i}" for i in range(10)]
    stat = ["std_dev", "std_err", "allan_dev", "allan_err"]
    mode = np.arange(-2, 2, 1)
    spectral_var = ["nu", "nu_prime", "npoints", "partial_fit"]
    date_times = np.array(
        ["2023-05-11T01:00:00", "2023-05-11T02:00:00", "2023-05-11T03:00:00"],
        dtype="datetime64[ns]",
    )
    n_samples = np.array([10, 20, 30], dtype=np.int64)
    tau_scaled = np.array([1.1, 1.2, 1.3], dtype=np.float64)
    count = np.array([11, 21, 31], dtype=np.int64)

    n_fitter_var = len(fitter_var)
    n_stat = len(stat)
    n_datetime = len(date_times)
    n_mode = len(mode)
    n_spectral_var = len(spectral_var)

    # Data variables (initialized with random data for the example)
    fitter_values = np.random.rand(n_datetime, n_fitter_var)
    fitter_values_stats = np.random.rand(n_datetime, n_fitter_var, n_stat)
    spectral_values = np.random.rand(n_datetime, n_spectral_var, n_mode).astype(
        np.float32
    )
    spectral_values_stats = np.random.rand(n_datetime, n_spectral_var, n_mode, n_stat)

    # Create the xarray Dataset
    compat_ds = xr.Dataset(
        {
            "fitter_values": (["_datetime", "fitter_var"], fitter_values),
            "fitter_values_stats": (
                ["_datetime", "fitter_var", "stat"],
                fitter_values_stats,
            ),
            "spectral_values": (["_datetime", "spectral_var", "mode"], spectral_values),
            "spectral_values_stats": (
                ["_datetime", "spectral_var", "mode", "stat"],
                spectral_values_stats,
            ),
        },
        coords={
            "fitter_var": ("fitter_var", fitter_var),
            "stat": ("stat", stat),
            "mode": ("mode", mode),
            "spectral_var": ("spectral_var", spectral_var),
            "n_samples": ("_datetime", n_samples),
            "tau_scaled": ("_datetime", tau_scaled),
            "tau": ("_datetime", tau_scaled),
            "_datetime": ("_datetime", date_times),
            "count": ("_datetime", count),
        },
    )
    return compat_ds


@pytest.fixture
def model_functions_harness():
    nu_min = 6000.0
    nu_max = 6010.0
    funcs = {
        101: lambda x: np.array([1, 2, 3, 4]),
        102: lambda x: np.array([1, 3, 3, 1]),
        103: lambda x: np.array([4, 2, 2, 4]),
        104: lambda x: np.array([4, 3, 2, 1]),
    }
    return ModelFunctions(nu_min=nu_min, nu_max=nu_max, funcs=funcs)


@pytest.fixture
def lsq_harness(model_functions_harness):
    return LinearLeastSquares(model_functions=model_functions_harness)
