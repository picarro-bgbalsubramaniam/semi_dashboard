import unittest

import numpy as np
import pandas as pd
import xarray as xr
from pydantic import ValidationError

from picarro_xarray.compute.zero_reference import get_transition_uid
from picarro_xarray.preprocess.trim_transition import (
    _boolean_mask_datetime,
    trim_transitions_edges,
    drop_short_transitions,
    get_groups_time_bounds,
    trim_transitions)
from picarro_xarray.time_utils.timeutils import _parse_grouper
from picarro_xarray.validators.timeseries import TIME_DIM, verify_bounds_array


class TestBooleanMaskDatetime(unittest.TestCase):
    def test_standard(self):
        datetime_np = np.array(
            ["2023-05-11T17:00:00", "2023-05-11T17:10:00"], dtype="datetime64[ns]"
        )
        datetime_mins = np.array(
            ["2023-05-11T16:00:00", "2023-05-11T17:05:00"], dtype="datetime64[ns]"
        )
        datetime_maxs = np.array(
            ["2023-05-11T18:00:00", "2023-05-11T17:15:00"], dtype="datetime64[ns]"
        )

        result = _boolean_mask_datetime(datetime_np, datetime_mins, datetime_maxs)
        expected = np.array([True, True])

        np.testing.assert_array_equal(result, expected)

    def test_boundaries(self):
        datetime_np = np.array(
            ["2023-05-11T17:05:00", "2023-05-11T17:15:00"], dtype="datetime64[ns]"
        )
        datetime_mins = np.array(["2023-05-11T17:05:00"], dtype="datetime64[ns]")
        datetime_maxs = np.array(["2023-05-11T17:15:00"], dtype="datetime64[ns]")

        result = _boolean_mask_datetime(datetime_np, datetime_mins, datetime_maxs)
        expected = np.array([True, True])

        np.testing.assert_array_equal(result, expected)

    def test_no_overlap(self):
        datetime_np = np.array(
            ["2023-05-11T17:00:00", "2023-05-11T18:00:00"], dtype="datetime64[ns]"
        )
        datetime_mins = np.array(["2023-05-11T18:30:00"], dtype="datetime64[ns]")
        datetime_maxs = np.array(["2023-05-11T19:00:00"], dtype="datetime64[ns]")

        result = _boolean_mask_datetime(datetime_np, datetime_mins, datetime_maxs)
        expected = np.array([False, False])

        np.testing.assert_array_equal(result, expected)

    def test_mismatched_mins_maxs(self):
        datetime_np = np.array(["2023-05-11T17:00:00"], dtype="datetime64[ns]")
        datetime_mins = np.array(["2023-05-11T16:00:00"], dtype="datetime64[ns]")
        datetime_maxs = np.array([], dtype="datetime64[ns]")

        with self.assertRaises(ValueError):
            _boolean_mask_datetime(datetime_np, datetime_mins, datetime_maxs)

    def test_arguments(self):
        with self.assertRaises(ValidationError):
            _boolean_mask_datetime(1, 1, 1)

        with self.assertRaises(ValidationError):
            _boolean_mask_datetime(np.array([1, 2]), 1, 1)

        with self.assertRaises(ValidationError):
            _boolean_mask_datetime(np.array([1, 2]), np.array([1, 2]), 1)

        with self.assertRaises(ValidationError):
            _boolean_mask_datetime(1, np.array([1, 2]), np.array([1, 2, 3]))


class TestTrimTransitionsEdges(unittest.TestCase):
    def setUp(self):
        da = xr.DataArray(
            data=[
                ["2023-05-11T17:00:00", "2023-05-11T17:20:00"],  # min
                ["2023-05-11T17:02:00", "2023-05-11T17:23:00"],
            ],  # max
            dims=["stats", "group"],
            coords={"stats": ["min", "max"], "group": [1, 2]},
        ).astype("datetime64[ns]")
        self.bounds_da = da

    def test_all(self):
        result = trim_transitions_edges(self.bounds_da, 60, 60)
        assert isinstance(result, xr.DataArray)
        assert np.allclose(
            result.sel(stats="min").values.astype(int),
            (self.bounds_da.sel(stats="min").values + np.timedelta64(60, "s")).astype(
                int
            ),
        )
        assert np.allclose(
            result.sel(stats="max").values.astype(int),
            (self.bounds_da.sel(stats="max").values - np.timedelta64(60, "s")).astype(
                int
            ),
        )

    def test_no_trimming(self):
        result = trim_transitions_edges(self.bounds_da, 0, 0)
        xr.testing.assert_equal(result, self.bounds_da)

    def test_transition_dropped(self):
        result = trim_transitions_edges(self.bounds_da, 60, 60)
        assert isinstance(result, xr.DataArray)
        assert result.sizes["group"] == 1
        assert list(result.group.values) == [2]

    def test_all_transitions_dropped(self):
        result = trim_transitions_edges(self.bounds_da, 120, 120)
        assert isinstance(result, xr.DataArray)
        assert result.sizes["group"] == 0
        assert list(result.group.values) == []

    def test_arguments(self):
        with self.assertRaises(ValidationError):
            trim_transitions_edges(1, 1, 1)

        with self.assertRaises(ValidationError):
            trim_transitions_edges(self.bounds_da, 1, "abc")

        with self.assertRaises(ValidationError):
            trim_transitions_edges(self.bounds_da, 1, -1)

        with self.assertRaises(ValidationError):
            trim_transitions_edges(self.bounds_da, "abc", 1)


class TestDropShortTransitions(unittest.TestCase):
    def setUp(self):
        da = xr.DataArray(
            data=[
                ["2023-05-11T17:00:00", "2023-05-11T17:20:00"],  # min
                ["2023-05-11T17:02:00", "2023-05-11T17:23:00"],
            ],  # max
            dims=["stats", "group"],
            coords={"stats": ["min", "max"], "group": [1, 2]},
        ).astype("datetime64[ns]")
        self.bounds_da = da

    def test_all(self):
        result = drop_short_transitions(self.bounds_da, 60)
        assert isinstance(result, xr.DataArray)
        assert result.sizes["group"] == 2

    def test_one_transition_dropped(self):
        result = drop_short_transitions(self.bounds_da, 120)
        assert isinstance(result, xr.DataArray)
        assert result.sizes["group"] == 1
        assert list(result.group.values) == [2]

    def test_all_transitions_dropped(self):
        result = drop_short_transitions(self.bounds_da, 500)
        assert isinstance(result, xr.DataArray)
        assert result.sizes["group"] == 0
        assert list(result.group.values) == []

    def test_arguments(self):
        with self.assertRaises(ValidationError):
            drop_short_transitions(1, 1)

        with self.assertRaises(ValidationError):
            drop_short_transitions(self.bounds_da, -1)

        with self.assertRaises(ValidationError):
            drop_short_transitions(self.bounds_da, "abc")


class TestGroupTimeAxis(unittest.TestCase):
    def setUp(self):
        time_array = np.array(
                ["2021-09-01T12:00:00", "2021-09-01T12:05:00", "2021-09-01T12:10:00"],
                dtype="datetime64[ns]",
            )
        self.time_da = xr.DataArray(
            time_array,
            coords={TIME_DIM: time_array},
            dims=TIME_DIM,
        )

        self.grouper_da = xr.DataArray(
            np.array([1, 1, 2]),
            coords={
                TIME_DIM: time_array
            }, dims=TIME_DIM
        )

    def test_group_time_axis(self):
        result = get_groups_time_bounds(self.time_da, self.grouper_da)
        assert isinstance(result, xr.DataArray)
        assert result.sizes["group"] == 2

    def test_arguments(self):
        with self.assertRaises(ValidationError):
            get_groups_time_bounds(1, 1)

        with self.assertRaises(ValidationError):
            get_groups_time_bounds(self.time_da, 1)

        with self.assertRaises(ValidationError):
            get_groups_time_bounds(1, self.grouper_da)


class TestTrimTransitions(unittest.TestCase):
    def setUp(self):
        time_data = pd.date_range(
            start="2023-05-11T17:00:00",
            freq="5s",
            periods=100,
        )

        group_data = [1] * 30 + [2] * 10 + [3] * 30 + [4] * 30

        data = xr.DataArray(
            np.ones(len(time_data)), dims=[TIME_DIM], coords={TIME_DIM: time_data}
        )

        grouper_da = xr.DataArray(
            group_data, dims=[TIME_DIM], coords={TIME_DIM: time_data}
        )
        self.grouper_da = grouper_da
        self.data = data

    def test_all(self):
        result = trim_transitions(
            data=self.data,
            grouper_da=self.grouper_da,
            min_duration_seconds=5,
            trim_start_seconds=3,
            trim_end_seconds=3,
        )
        assert isinstance(result, xr.DataArray)

        # drop two datapoints per transition
        dropped = 2 * len(set(self.grouper_da.values))
        assert result.sizes[TIME_DIM] == self.data.sizes[TIME_DIM] - dropped

    def test_dataset(self):
        data_ds = self.data.to_dataset(name="abc")
        result = trim_transitions(
            data=data_ds,
            grouper_da=self.grouper_da,
            min_duration_seconds=30,
            trim_start_seconds=6,
            trim_end_seconds=6,
        )
        assert isinstance(result, xr.Dataset)
        dropped = 4 * len(set(self.grouper_da.values))
        assert result.abc.sizes[TIME_DIM] == self.data.sizes[TIME_DIM] - dropped

    def test_drop_duration(self):
        result = trim_transitions(
            data=self.data,
            grouper_da=self.grouper_da,
            min_duration_seconds=60,
            trim_start_seconds=0,
            trim_end_seconds=0,
        )
        assert isinstance(result, xr.DataArray)
        # group 2 is dropped (len 10)
        assert result.sizes[TIME_DIM] == self.data.sizes[TIME_DIM] - 10

    def test_all_dropped(self):
        result = trim_transitions(
            data=self.data,
            grouper_da=self.grouper_da,
            min_duration_seconds=3000,
            trim_start_seconds=0,
            trim_end_seconds=0,
        )
        assert isinstance(result, xr.DataArray)
        assert result.sizes[TIME_DIM] == 0

    def test_len_mismatch(self):
        with self.assertRaises(ValueError):
            trim_transitions(
                data=self.data,
                grouper_da=self.grouper_da.isel({TIME_DIM: slice(1, None)}),
                min_duration_seconds=5,
                trim_start_seconds=3,
                trim_end_seconds=3,
            )

    def test_equivalence(self):
        grouper = self.grouper_da.copy(deep=True)
        grouper.name = "group"

        grouper_new = _parse_grouper(data=self.data, grouper=grouper)
        grouper_new = get_transition_uid(transition_data=grouper_new)

        assert grouper_new.equals(grouper)


    def test_arguments(self):
        with self.assertRaises(ValidationError):
            trim_transitions(self.data, 1)

        with self.assertRaises(ValidationError):
            trim_transitions(1, self.grouper_da)

        with self.assertRaises(ValidationError):
            trim_transitions(self.data, self.grouper_da, -1)

        with self.assertRaises(ValidationError):
            trim_transitions(self.data, self.grouper_da, "abc")

        with self.assertRaises(ValidationError):
            trim_transitions(self.data, self.grouper_da, 1, -1)

        with self.assertRaises(ValidationError):
            trim_transitions(self.data, self.grouper_da, 1, 1, -1)



