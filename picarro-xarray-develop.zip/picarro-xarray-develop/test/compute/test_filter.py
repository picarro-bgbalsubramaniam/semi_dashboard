import pytest
import unittest
import pandas as pd
import xarray as xr
import pydantic_core
from picarro_xarray.compute.filter import filter_fitter_var, filter_npoints


class TestFilterFitterVar(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        self.ds = ds

    def test_arguments(self):
        with pytest.raises(ValueError):
            filter_fitter_var(self.ds, "a")

        with pytest.raises(ValueError):
            filter_fitter_var(self.ds, "fake_fitter_var", lower_bound=0)

        with pytest.raises(pydantic_core._pydantic_core.ValidationError):
            filter_fitter_var(xr.Dataset(), "a", lower_bound=0.1)

        with pytest.raises(pydantic_core._pydantic_core.ValidationError):
            filter_fitter_var(
                xr.Dataset(
                    coords={
                        "_datetime": (
                            "_datetime",
                            pd.date_range("2020-01-01", periods=10, freq="D"),
                        )
                    }
                ),
                "a",
                lower_bound=0.1,
            )

    def test_lower_bound(self):
        temp_ds = filter_fitter_var(self.ds, "a", lower_bound=2)
        assert temp_ds.sel(fitter_var="a").fitter_values.values.tolist() == list(range(3, 11))

    def test_upper_bound(self):
        temp_ds = filter_fitter_var(self.ds, "a", upper_bound=8)
        assert temp_ds.sel(fitter_var="a").fitter_values.values.tolist() == list(range(1, 8))

    def test_upper_and_lower_bound(self):
        temp_ds = filter_fitter_var(self.ds, "a", upper_bound=8, lower_bound=2)
        assert temp_ds.sel(fitter_var="a").fitter_values.values.tolist() == list(range(3, 8))


class TestFilterNPoints(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        self.ds = ds

    def test_arguments(self):
        with pytest.raises(pydantic_core._pydantic_core.ValidationError):
            filter_npoints(xr.Dataset())

        with pytest.raises(pydantic_core._pydantic_core.ValidationError):
            filter_npoints(
                xr.Dataset(
                    coords={
                        "_datetime": (
                            "_datetime",
                            pd.date_range("2020-01-01", periods=10, freq="D"),
                        )
                    }
                ),
            )

    def test_dropped_modes(self):
        # Default drops all modes based on np.arange approach in mock object
        res = filter_npoints(self.ds,)
        assert res.mode.values.tolist() == []

    def test_dropped_missing_num(self):
        # Not a great test, but to validate changes to algorithm produce same results
        res = filter_npoints(self.ds, number_missing=6, fraction_of_median=0.5)
        assert res.mode.values.tolist() == [12, 14, 16, 18, 20, 22]
