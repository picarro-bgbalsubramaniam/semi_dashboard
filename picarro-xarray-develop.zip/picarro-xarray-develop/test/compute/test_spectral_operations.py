import unittest

import pytest
import xarray as xr
from pydantic import ValidationError

from picarro_xarray.compute.compactify import compactify
from picarro_xarray.compute.spectral_operations.operations import Operation
from picarro_xarray.compute.spectral_operations.spectral_operations import (
    FITTER,
    SPECTRAL,
    _compute_operations_from_map,
    _dispatch_compact_operation_from_maps,
    _extract_results_and_errors,
    merge_compact,
    perform_compact_operation,
)
from picarro_xarray.data_models.constants import TIME_DIM, MODE_DIM


class TestComputeOperationsFromMap(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.compat = request.getfixturevalue("compat_dataset")

    def test_compute_operations_from_map_fitter(self):
        operand_1 = self.compat.isel({TIME_DIM: [0, 1]})
        operand_2 = self.compat.isel({TIME_DIM: [2]})

        mock_operation_map = {
            Operation.SUM: ["fvar1", "fvar2"],
        }

        # Call the function to be tested
        results, errors = _compute_operations_from_map(
            operand_1=operand_1,
            operand_2=operand_2,
            operation_map=mock_operation_map,
            operation_type=FITTER,
        )

        self.assertIsInstance(results, xr.DataArray)
        self.assertIsInstance(errors, xr.DataArray)
        assert results.sizes[TIME_DIM] == operand_1.sizes[TIME_DIM]
        assert errors.sizes[TIME_DIM] == operand_1.sizes[TIME_DIM]

    def test_compute_operations_from_map_spectral(self):
        operand_1 = self.compat.isel({TIME_DIM: [0, 1]})
        operand_2 = self.compat.isel({TIME_DIM: [2]})

        mock_operation_map = {
            Operation.INTERSECTION: ["nu", "partial_fit"],
        }

        # Call the function to be tested
        results, errors = _compute_operations_from_map(
            operand_1=operand_1,
            operand_2=operand_2,
            operation_map=mock_operation_map,
            operation_type=SPECTRAL,
        )

        self.assertIsInstance(results, xr.DataArray)
        self.assertIsInstance(errors, xr.DataArray)
        assert results.sizes[TIME_DIM] == operand_1.sizes[TIME_DIM]
        assert errors.sizes[TIME_DIM] == operand_1.sizes[TIME_DIM]


class TestDispatchFromMaps(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.compat = request.getfixturevalue("compat_dataset")

    def test_dispatch_array(self):
        operand_1 = self.compat.isel({TIME_DIM: [0, 1]})
        operand_2 = self.compat.isel({TIME_DIM: [2]})

        mock_operation_map_fitter = {
            Operation.SUM: ["fvar1", "fvar2"],
        }
        mock_operation_map_spectral = {
            Operation.INTERSECTION: ["nu", "partial_fit"],
        }

        # Call the function to be tested
        results = _dispatch_compact_operation_from_maps(
            operand_1=operand_1,
            operand_2=operand_2,
            operation_spectra_map=mock_operation_map_spectral,
            operation_timeseries_map=mock_operation_map_fitter,
        )

        self.assertIsInstance(results, xr.Dataset)
        assert results.sizes[TIME_DIM] == operand_1.sizes[TIME_DIM]

    def test_dispatch_int(self):
        operand_1 = self.compat.isel({TIME_DIM: [0, 1]})

        mock_operation_map_fitter = {
            Operation.SUM: ["fvar1", "fvar2"],
        }
        mock_operation_map_spectral = {
            Operation.INTERSECTION: ["nu", "partial_fit"],
        }

        # Call the function to be tested
        results = _dispatch_compact_operation_from_maps(
            operand_1=operand_1,
            operand_2=2,
            operation_spectra_map=mock_operation_map_spectral,
            operation_timeseries_map=mock_operation_map_fitter,
        )

        self.assertIsInstance(results, xr.Dataset)
        assert results.sizes[TIME_DIM] == operand_1.sizes[TIME_DIM]

    def test_dispatch_float(self):
        operand_1 = self.compat.isel({TIME_DIM: [0, 1]})

        mock_operation_map_fitter = {
            Operation.SUM: ["fvar1", "fvar2"],
        }
        mock_operation_map_spectral = {
            Operation.INTERSECTION: ["nu", "partial_fit"],
        }

        # Call the function to be tested
        results = _dispatch_compact_operation_from_maps(
            operand_1=operand_1,
            operand_2=1.0,
            operation_spectra_map=mock_operation_map_spectral,
            operation_timeseries_map=mock_operation_map_fitter,
        )

        self.assertIsInstance(results, xr.Dataset)
        assert results.sizes[TIME_DIM] == operand_1.sizes[TIME_DIM]


class TestExtractResultsErrors(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.compat = request.getfixturevalue("compat_dataset")

    def test_extract_array(self):
        vars_ = ["nu", "nu_prime"]
        res, err = _extract_results_and_errors(
            data=self.compat,
            selected_variables=vars_,
            variable_type=SPECTRAL,
        )
        self.assertIsInstance(res, xr.DataArray)
        self.assertIsInstance(err, xr.DataArray)
        assert res.sizes[TIME_DIM] == self.compat.sizes[TIME_DIM]
        assert err.sizes[TIME_DIM] == self.compat.sizes[TIME_DIM]
        assert set(vars_) == set(res[SPECTRAL.COORDINATE_INDEXER_NAME].values)
        assert res.name == SPECTRAL.MEAN_VARIABLE_NAME
        assert err.name == SPECTRAL.ERROR_VARIABLE_NAME

    def test_extract_array_fitter(self):
        vars_ = ["fvar1"]
        res, err = _extract_results_and_errors(
            data=self.compat,
            selected_variables=vars_,
            variable_type=FITTER,
        )
        self.assertIsInstance(res, xr.DataArray)
        self.assertIsInstance(err, xr.DataArray)
        assert res.sizes[TIME_DIM] == self.compat.sizes[TIME_DIM]
        assert err.sizes[TIME_DIM] == self.compat.sizes[TIME_DIM]
        assert set(vars_) == set(res[FITTER.COORDINATE_INDEXER_NAME].values)
        assert res.name == FITTER.MEAN_VARIABLE_NAME
        assert err.name == FITTER.ERROR_VARIABLE_NAME

    def test_extract_scalar(self):
        vars_ = ["nu", "nu_prime"]
        res, err = _extract_results_and_errors(
            data=1,
            selected_variables=vars_,
            variable_type=SPECTRAL,
        )
        self.assertIsInstance(res, int)
        assert err is None


class TestPerformCompactOperation(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.compat = request.getfixturevalue("compat_dataset")

    def test_array(self):
        operand_1 = self.compat.isel({TIME_DIM: [0, 1]})
        operand_2 = self.compat.isel({TIME_DIM: [2]})

        result = perform_compact_operation(
            operand_1=operand_1,
            operand_2=operand_2,
            operation_spectra=Operation.UNION,
            operation_timeseries=Operation.SUM,
        )

        self.assertIsInstance(result, xr.Dataset)
        assert result.sizes[TIME_DIM] == operand_1.sizes[TIME_DIM]

    def test_less_reference_modes(self):
        operand_1 = self.compat.isel({TIME_DIM: [0, 1]})
        operand_2 = self.compat.isel({TIME_DIM: [2]}).isel(mode=slice(None, -1))

        result = perform_compact_operation(
            operand_1=operand_1,
            operand_2=operand_2,
            operation_spectra=Operation.DIFFERENCE,
            operation_timeseries=Operation.DIFFERENCE,
        )

        self.assertIsInstance(result, xr.Dataset)
        assert result.sizes[TIME_DIM] == operand_1.sizes[TIME_DIM]
        assert result.sizes["mode"] == min(
            operand_1.sizes["mode"], operand_2.sizes["mode"]
        )

    def test_less_data_modes(self):
        operand_1 = self.compat.isel({TIME_DIM: [0, 1]}).isel(mode=slice(None, -1))
        operand_2 = self.compat.isel({TIME_DIM: [2]})

        result = perform_compact_operation(
            operand_1=operand_1,
            operand_2=operand_2,
            operation_spectra=Operation.UNION,
            operation_timeseries=Operation.SUM,
        )

        self.assertIsInstance(result, xr.Dataset)
        assert result.sizes[TIME_DIM] == operand_1.sizes[TIME_DIM]
        assert result.sizes["mode"] == min(
            operand_1.sizes["mode"], operand_2.sizes["mode"]
        )

    def test_less_spectral_vars(self):
        operand_1 = self.compat.isel({TIME_DIM: [0, 1]})
        operand_2 = self.compat.isel({TIME_DIM: [2]}).drop_sel(
            spectral_var=["nu", "nu_prime", "npoints"]
        )

        result = perform_compact_operation(
            operand_1=operand_1,
            operand_2=operand_2,
            operation_spectra=Operation.DIFFERENCE,
            operation_timeseries=Operation.SUM,
        )

        self.assertIsInstance(result, xr.Dataset)
        assert result.sizes[TIME_DIM] == operand_1.sizes[TIME_DIM]
        assert result.sizes["spectral_var"] == min(
            operand_1.sizes["spectral_var"], operand_2.sizes["spectral_var"]
        )

    def test_arguments(self):
        operand_1 = self.compat.isel({TIME_DIM: [0, 1]})
        operand_2 = self.compat.isel({TIME_DIM: [2]})

        with self.assertRaises(ValidationError):
            perform_compact_operation(
                operand_1=xr.Dataset(),
                operand_2=operand_2,
                operation_spectra=Operation.UNION,
                operation_timeseries=Operation.SUM,
            )

        with self.assertRaises(ValidationError):
            perform_compact_operation(
                operand_1=operand_1,
                operand_2="abc",
                operation_spectra=Operation.UNION,
                operation_timeseries=Operation.SUM,
            )

        with self.assertRaises(ValidationError):
            perform_compact_operation(
                operand_1=operand_1,
                operand_2=operand_2,
                operation_spectra="bakedjakldje",
                operation_timeseries=Operation.SUM,
            )

        with self.assertRaises(ValidationError):
            perform_compact_operation(
                operand_1=operand_1,
                operand_2=operand_2,
                operation_spectra=Operation.UNION,
                operation_timeseries=Operation.SUM,
                nu_vars=1,
            )


class TestIntegrationDifference(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds = request.getfixturevalue("combolog_ds")
        self.compat_ds = compactify(
            data=self.ds, groupby="group_this", consecutive=True
        )
        self.reference = self.compat_ds.isel({TIME_DIM: [0]})

    def test_difference(self):
        result = perform_compact_operation(
            operand_1=self.compat_ds,
            operand_2=self.reference,
            operation_spectra=Operation.DIFFERENCE,
            operation_timeseries=Operation.DIFFERENCE,
            nu_vars=["nu"],
            npoints_vars=["npoints"],
        )
        self.assertIsInstance(result, xr.Dataset)
        assert result.sizes[TIME_DIM] == self.compat_ds.sizes[TIME_DIM]

    def test_sum(self):
        result = perform_compact_operation(
            operand_1=self.compat_ds,
            operand_2=self.reference,
            operation_spectra=Operation.SUM,
            operation_timeseries=Operation.SUM,
            nu_vars=["nu"],
            npoints_vars=["npoints"],
        )
        self.assertIsInstance(result, xr.Dataset)
        assert result.sizes[TIME_DIM] == self.compat_ds.sizes[TIME_DIM]

    def test_itersection(self):
        result = perform_compact_operation(
            operand_1=self.compat_ds,
            operand_2=self.reference,
            operation_spectra=Operation.INTERSECTION,
            operation_timeseries=Operation.INTERSECTION,
            nu_vars=["nu"],
            npoints_vars=["npoints"],
        )
        self.assertIsInstance(result, xr.Dataset)
        assert result.sizes[TIME_DIM] == self.compat_ds.sizes[TIME_DIM]

    def test_union(self):
        result = perform_compact_operation(
            operand_1=self.compat_ds,
            operand_2=self.reference,
            operation_spectra=Operation.UNION,
            operation_timeseries=Operation.UNION,
            nu_vars=["nu"],
            npoints_vars=["npoints"],
        )
        self.assertIsInstance(result, xr.Dataset)
        assert result.sizes[TIME_DIM] == self.compat_ds.sizes[TIME_DIM]

    def test_arithmetic_mean(self):
        result = perform_compact_operation(
            operand_1=self.compat_ds,
            operand_2=self.reference,
            operation_spectra=Operation.ARITHMETIC_MEAN,
            operation_timeseries=Operation.ARITHMETIC_MEAN,
            nu_vars=["nu"],
            npoints_vars=["npoints"],
        )
        self.assertIsInstance(result, xr.Dataset)
        assert result.sizes[TIME_DIM] == self.compat_ds.sizes[TIME_DIM]

    def test_passthrough(self):
        result = perform_compact_operation(
            operand_1=self.compat_ds,
            operand_2=self.reference,
            operation_spectra=Operation.PASSTHROUGH,
            operation_timeseries=Operation.PASSTHROUGH,
            nu_vars=["nu"],
            npoints_vars=["npoints"],
        )
        self.assertIsInstance(result, xr.Dataset)
        assert result.sizes[TIME_DIM] == self.compat_ds.sizes[TIME_DIM]

    def test_mix_operation(self):
        result = perform_compact_operation(
            operand_1=self.compat_ds,
            operand_2=self.reference,
            operation_spectra=Operation.DIFFERENCE,
            operation_timeseries=Operation.INTERSECTION,
            nu_vars=["nu"],
            npoints_vars=["npoints"],
        )
        self.assertIsInstance(result, xr.Dataset)
        assert result.sizes[TIME_DIM] == self.compat_ds.sizes[TIME_DIM]


class TestMergeCompact(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.compat = request.getfixturevalue("compat_dataset")

    def test_merge_compact(self):
        result = merge_compact(self.compat)
        self.assertIsInstance(result, xr.Dataset)
        assert result.sizes[TIME_DIM] == 1
        assert result.sizes[MODE_DIM] == self.compat.sizes[MODE_DIM]
