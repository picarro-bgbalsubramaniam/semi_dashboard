import unittest

import numpy as np
import pytest
import xarray as xr

from picarro_xarray.compute.spectral_operations.operations import (
    Operation,
    OperationFactory,
    _get_weights_for_weighted_average,
    _merge_compact,
    _perform_arithmetic_mean,
    _perform_difference,
    _perform_division,
    _perform_intersection,
    _perform_maximum,
    _perform_minimum,
    _perform_passthrough,
    _perform_product,
    _perform_sum,
    _perform_union,
    _perform_weighted_mean,
)
from picarro_xarray.data_models.constants import (
    COUNT_DIM,
    MODE_DIM,
    STATS_DIM,
    TIME_DIM,
)


@pytest.fixture
def time_array():
    return np.array(
        ["2023-01-01T00:00", "2023-01-02T00:00", "2023-01-03T00:00"],
        dtype="datetime64[ns]",
    )


@pytest.fixture
def mean_1(time_array):
    mean_1 = xr.DataArray(
        [[1.0, 4.0, 2.0], [3.0, 1.5, 2.0]],
        dims=[MODE_DIM, TIME_DIM],
        coords={TIME_DIM: time_array, MODE_DIM: [1, 2]},
    )
    mean_1 = mean_1.assign_coords({COUNT_DIM: (TIME_DIM, [10, 20, 30])})
    return mean_1


@pytest.fixture
def mean_2():
    mean_2 = xr.DataArray([2.0, 0.5], dims=[MODE_DIM], coords={MODE_DIM: [1, 2]})
    mean_2 = mean_2.assign_coords({COUNT_DIM: 5})
    return mean_2


@pytest.fixture
def errors_1(time_array):
    errors_1 = xr.DataArray(
        [[0.1, 0.8, 1.0], [0.8, 0.1, 1.0]],
        dims=[MODE_DIM, TIME_DIM],
        coords={TIME_DIM: time_array, MODE_DIM: [1, 2]},
    )
    errors_1 = errors_1.assign_coords({COUNT_DIM: (TIME_DIM, [10, 20, 30])})
    errors_1 = errors_1.expand_dims(dim={STATS_DIM: ["std_err"]}).copy()
    return errors_1


@pytest.fixture
def errors_2():
    errors_2 = xr.DataArray([0.2, 0.1], dims=[MODE_DIM], coords={MODE_DIM: [1, 2]})
    errors_2 = errors_2.assign_coords({COUNT_DIM: 5})
    errors_2 = errors_2.expand_dims(dim={STATS_DIM: ["std_err"]}).copy()
    return errors_2


@pytest.fixture
def expected_quadrature_err():
    return np.array([[0.2236068, 0.8246, 1.0198], [0.80622577, 0.1414, 1.0049]])


@pytest.fixture
def expected_product_err():
    return np.array([[0.2828, 1.7885, 2.0396], [0.5, 0.1581, 0.5385]])


@pytest.fixture
def expected_weighted_err():
    return np.array([[[0.0894, 0.19403, 0.19612], [0.09923, 0.07071, 0.09950]]])


@pytest.fixture
def expected_weighted_mean():
    return np.array([[1.2, 2.1176, 2], [0.5385, 1, 0.514851]])


class TestGetWeightsForWeightedAverage(unittest.TestCase):
    def setUp(self):
        """Define the reusable components."""
        self.time_dim = TIME_DIM
        self.count_coord = COUNT_DIM
        self.time = np.array(
            ["2023-01-01T00:00", "2023-01-02T00:00"], dtype="datetime64[ns]"
        )

    def test_adjust_infinite_weights(self):
        """Test if the function correctly adjusts infinite weights."""

        # Create weights with infinite values on fitter_var = "a"
        weights_1 = xr.DataArray(
            [[np.inf, 1, 2], [3, 4, 5]],
            dims=[self.time_dim, "fitter_var"],
            coords={
                self.time_dim: self.time,
                "fitter_var": ["a", "b", "c"],
                self.count_coord: (self.time_dim, [6, 6]),
            },
        )
        weights_2 = xr.DataArray(
            [1, 2, 3],
            dims=["fitter_var"],
        )
        weights_2 = weights_2.assign_coords(count=12)

        # it should be detected that the weights are infinite
        # on fitter_var = "a"
        # so the count coordinate should be used as weights
        adjusted_weights_1, adjusted_weights_2 = _get_weights_for_weighted_average(
            weights_1, weights_2, time_dim=self.time_dim, count_coord=self.count_coord
        )

        assert np.allclose(adjusted_weights_1.values, np.array([[6, 1, 2], [6, 4, 5]]))
        assert np.allclose(adjusted_weights_2.values, np.array([12, 2, 3]))

    def test_adjust_infinite_weights_no_count(self):
        """Test if the function correctly adjusts infinite weights
        in the case where weights/error don't have a count
        coordinate (operations with a scalar)."""

        # Create weights with infinite values on fitter_var = "a"
        weights_1 = xr.DataArray(
            [[np.inf, 1, 2], [3, 4, 5]],
            dims=[self.time_dim, "fitter_var"],
            coords={
                self.time_dim: self.time,
                "fitter_var": ["a", "b", "c"],
                self.count_coord: (self.time_dim, [6, 6]),
            },
        )
        weights_2 = xr.DataArray(
            [1, 2, 3],
            dims=["fitter_var"],
        )

        # it should be detected that the weights are infinite
        # on fitter_var = "a"
        # so the count coordinate should be used as weights
        adjusted_weights_1, adjusted_weights_2 = _get_weights_for_weighted_average(
            weights_1, weights_2, time_dim=self.time_dim, count_coord=self.count_coord
        )

        assert np.allclose(adjusted_weights_1.values, np.array([[6, 1, 2], [6, 4, 5]]))

        # In this case the weights for the second operand are going to be the same
        # as operand 1 for fitter_var="a" (the one with inf weight)
        # to ensure an arithmetic mean operation
        # the other fitter_vars are broadcasted
        assert np.allclose(adjusted_weights_2.values, np.array([[6, 2, 3], [6, 2, 3]]))

    def test_missing_count_coordinate(self):
        """Test the behavior when the 'count' coordinate is missing."""

        weights_1 = xr.DataArray(
            [1, 1], dims=[self.time_dim], coords={self.time_dim: self.time}
        )
        weights_2 = xr.DataArray(
            [1, 1], dims=[self.time_dim], coords={self.time_dim: self.time}
        )

        with pytest.raises(ValueError, match=r"Weights array weights_1.*"):
            _get_weights_for_weighted_average(
                weights_1,
                weights_2,
                time_dim=self.time_dim,
                count_coord=self.count_coord,
            )


class TestPerformWeightedMean(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.mean_1 = request.getfixturevalue("mean_1")
        self.mean_2 = request.getfixturevalue("mean_2")
        self.errors_1 = request.getfixturevalue("errors_1")
        self.errors_2 = request.getfixturevalue("errors_2")
        self.error_expected = request.getfixturevalue("expected_weighted_err")
        self.mean_expected = request.getfixturevalue("expected_weighted_mean")

    def test_weighted_mean_shared(self):
        res, res_err = _perform_weighted_mean(
            mean_1=self.mean_1,
            mean_2=self.mean_2,
            errors_1=self.errors_1,
            errors_2=self.errors_2,
            shared_frequencies_only=True,
        )
        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(res_err.values, self.error_expected, atol=1e-3)
        assert np.allclose(res.values, self.mean_expected.T, atol=1e-3)

        # intersection is a special case of weighted mean
        res, res_err = _perform_intersection(
            mean_1=self.mean_1,
            mean_2=self.mean_2,
            errors_1=self.errors_1,
            errors_2=self.errors_2,
        )

        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(res_err.values, self.error_expected, atol=1e-3)
        assert np.allclose(res.values, self.mean_expected.T, atol=1e-3)

    def test_weighted_mean_not_shared(self):
        res, res_err = _perform_weighted_mean(
            mean_1=self.mean_1,
            mean_2=self.mean_2,
            errors_1=self.errors_1,
            errors_2=self.errors_2,
            shared_frequencies_only=False,
        )
        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(res_err.values, self.error_expected, atol=1e-3)
        assert np.allclose(res.values, self.mean_expected.T, atol=1e-3)

        # union is a special case of weighted mean
        res, res_err = _perform_union(
            mean_1=self.mean_1,
            mean_2=self.mean_2,
            errors_1=self.errors_1,
            errors_2=self.errors_2,
        )

        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(res_err.values, self.error_expected, atol=1e-3)
        assert np.allclose(res.values, self.mean_expected.T, atol=1e-3)

    def test_weighted_mean_shared_different_modes(self):
        res, res_err = _perform_weighted_mean(
            mean_1=self.mean_1,
            mean_2=self.mean_2.drop_isel({MODE_DIM: 0}),
            errors_1=self.errors_1,
            errors_2=self.errors_2.drop_isel({MODE_DIM: 0}),
            shared_frequencies_only=True,
        )
        err_expected = self.error_expected[:, 1, :]
        mean_expected = self.mean_expected[1, :]
        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(res_err.values.ravel(), err_expected.ravel(), atol=1e-3)
        assert np.allclose(res.values.ravel(), mean_expected.ravel(), atol=1e-3)

        # intersection is a special case of weighted mean
        res, res_err = _perform_intersection(
            mean_1=self.mean_1,
            mean_2=self.mean_2.drop_isel({MODE_DIM: 0}),
            errors_1=self.errors_1,
            errors_2=self.errors_2.drop_isel({MODE_DIM: 0}),
        )

        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(res_err.values.ravel(), err_expected.ravel(), atol=1e-3)
        assert np.allclose(res.values.ravel(), mean_expected.ravel(), atol=1e-3)

    def test_weighted_mean_not_shared_different_modes(self):
        res, res_err = _perform_weighted_mean(
            mean_1=self.mean_1,
            mean_2=self.mean_2.drop_isel({MODE_DIM: 0}),
            errors_1=self.errors_1,
            errors_2=self.errors_2.drop_isel({MODE_DIM: 0}),
            shared_frequencies_only=False,
        )
        err_expected = self.error_expected
        err_expected[:, 0, :] = np.full(res.sizes[TIME_DIM], np.nan)

        mean_expected = self.mean_expected
        mean_expected[0, :] = np.full(res.sizes[TIME_DIM], np.nan)
        mean_expected = mean_expected.T

        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(
            res_err.values.ravel(), err_expected.ravel(), atol=1e-3, equal_nan=True
        )
        assert np.allclose(
            res.values.ravel(), mean_expected.ravel(), atol=1e-3, equal_nan=True
        )

        # union is a special case of weighted mean
        res, res_err = _perform_union(
            mean_1=self.mean_1,
            mean_2=self.mean_2.drop_isel({MODE_DIM: 0}),
            errors_1=self.errors_1,
            errors_2=self.errors_2.drop_isel({MODE_DIM: 0}),
        )

        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(
            res_err.values.ravel(), err_expected.ravel(), atol=1e-3, equal_nan=True
        )
        assert np.allclose(
            res.values.ravel(), mean_expected.ravel(), atol=1e-3, equal_nan=True
        )

    def test_error_zero(self):
        # test to use count as weights when error is zero
        err_zero = self.errors_1.copy()
        err_zero.loc[dict(mode=1)] = 0

        res, res_err = _perform_weighted_mean(
            mean_1=self.mean_1,
            mean_2=self.mean_2,
            errors_1=err_zero,
            errors_2=self.errors_2,
            shared_frequencies_only=True,
        )

        mean_expected = self.mean_expected
        mean_expected[0, :] = np.array([1.333, 3.6, 2])  # weighted mean on count
        mean_expected = mean_expected.T

        err_expected = self.error_expected
        err_expected[:, 0, :] = np.array([0.0, 0.0, 0.0])

        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(
            res_err.values.ravel(), err_expected.ravel(), atol=1e-3, equal_nan=True
        )
        assert np.allclose(
            res.values.ravel(), mean_expected.ravel(), atol=1e-3, equal_nan=True
        )

    def test_no_counts(self):
        # when a constant is passed then err has no count
        # test to use count as weights when error is zero
        constant = xr.ones_like(self.mean_1).isel({TIME_DIM: 0}) * 2
        zero_error = (
            xr.zeros_like(self.errors_1).isel({TIME_DIM: 0}).drop_vars(COUNT_DIM)
        )

        res, res_err = _perform_weighted_mean(
            mean_1=self.mean_1,
            mean_2=constant,
            errors_1=self.errors_1,
            errors_2=zero_error,
            shared_frequencies_only=True,
        )

        mean_expected = np.array([[1.5, 3, 2], [2.5, 1.75, 2]]).T

        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(
            res_err.values.ravel(),
            self.errors_1.values.ravel(),
            atol=1e-3,
            equal_nan=True,
        )
        assert np.allclose(
            res.values.ravel(), mean_expected.ravel(), atol=1e-3, equal_nan=True
        )


class TestPerformSimpleOps(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.mean_1 = request.getfixturevalue("mean_1")
        self.mean_2 = request.getfixturevalue("mean_2")
        self.errors_1 = request.getfixturevalue("errors_1")
        self.errors_2 = request.getfixturevalue("errors_2")
        self.error_expected_quadrature = request.getfixturevalue(
            "expected_quadrature_err"
        )
        self.error_expected_product = request.getfixturevalue("expected_product_err")

    def test_sum(self):
        res, res_err = _perform_sum(
            mean_1=self.mean_1,
            mean_2=self.mean_2,
            errors_1=self.errors_1,
            errors_2=self.errors_2,
        )
        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(res.values, (self.mean_1 + self.mean_2).values, atol=1e-3)
        assert np.allclose(res_err.values, self.error_expected_quadrature, atol=1e-3)

    def test_arithmetic_mean(self):
        res, res_err = _perform_arithmetic_mean(
            mean_1=self.mean_1,
            mean_2=self.mean_2,
            errors_1=self.errors_1,
            errors_2=self.errors_2,
        )
        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(
            res.values, 0.5 * (self.mean_1 + self.mean_2).values, atol=1e-3
        )
        assert np.allclose(res_err.values, self.error_expected_quadrature, atol=1e-3)

    def test_passthrough(self):
        res, res_err = _perform_passthrough(
            mean_1=self.mean_1,
            mean_2=self.mean_2,
            errors_1=self.errors_1,
            errors_2=self.errors_2,
        )
        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]

        assert self.mean_1.equals(res)
        assert self.errors_1.equals(res_err)

    def test_diff(self):
        res, res_err = _perform_difference(
            mean_1=self.mean_1,
            mean_2=self.mean_2,
            errors_1=self.errors_1,
            errors_2=self.errors_2,
        )
        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(res.values, (self.mean_1 - self.mean_2).values, atol=1e-3)
        assert np.allclose(res_err.values, self.error_expected_quadrature, atol=1e-3)

    def test_prod(self):
        res, res_err = _perform_product(
            mean_1=self.mean_1,
            mean_2=self.mean_2,
            errors_1=self.errors_1,
            errors_2=self.errors_2,
        )
        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(res.values, (self.mean_1 * self.mean_2).values, atol=1e-3)
        assert np.allclose(
            res_err.values.ravel(), self.error_expected_product.ravel(), atol=1e-3
        )

    def test_div(self):
        res, res_err = _perform_division(
            mean_1=self.mean_1,
            mean_2=self.mean_2,
            errors_1=self.errors_1,
            errors_2=self.errors_2,
        )
        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert np.allclose(res.values, (self.mean_1 / self.mean_2).values, atol=1e-3)

    def test_min(self):
        res, res_err = _perform_minimum(
            mean_1=self.mean_1,
            mean_2=self.mean_2,
            errors_1=self.errors_1,
            errors_2=self.errors_2,
        )
        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        result = np.minimum(self.mean_1, self.mean_2)
        assert np.allclose(res.values, result.values, atol=1e-3)

        mask_min_from_1 = self.mean_1 < self.mean_2

        # Expected errors based on which dataset has the minimum
        expected_errors = xr.where(mask_min_from_1, self.errors_1, self.errors_2)

        # Assert that the errors from the result are what we expect based on the minimum values
        assert np.allclose(res_err.values, expected_errors.values, atol=1e-3)

    def test_max(self):
        res, res_err = _perform_maximum(
            mean_1=self.mean_1,
            mean_2=self.mean_2,
            errors_1=self.errors_1,
            errors_2=self.errors_2,
        )
        assert res.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        assert res_err.sizes[TIME_DIM] == self.mean_1.sizes[TIME_DIM]
        result = np.maximum(self.mean_1, self.mean_2)
        assert np.allclose(res.values, result.values, atol=1e-3)

        mask_max_from_1 = self.mean_1 > self.mean_2

        # Expected errors based on which dataset has the minimum
        expected_errors = xr.where(mask_max_from_1, self.errors_1, self.errors_2)

        # Assert that the errors from the result are what we expect based on the minimum values
        assert np.allclose(res_err.values, expected_errors.values, atol=1e-3)


class TestOperationFactory(unittest.TestCase):
    def test_create_operation(self):
        # You would add all the cases for your operations here
        test_cases = [
            (Operation.SUM, _perform_sum),
            (Operation.DIFFERENCE, _perform_difference),
            (Operation.PRODUCT, _perform_product),
            (Operation.DIVISION, _perform_division),
            (Operation.MINIMUM, _perform_minimum),
            (Operation.MAXIMUM, _perform_maximum),
            (Operation.ARITHMETIC_MEAN, _perform_arithmetic_mean),
            (Operation.PASSTHROUGH, _perform_passthrough),
            (Operation.UNION, _perform_union),
            (Operation.INTERSECTION, _perform_intersection),
        ]

        for operation, expected_function in test_cases:
            with self.subTest(operation=operation):
                result_function = OperationFactory.create_operation(operation)
                self.assertEqual(result_function, expected_function)

    def test_unsupported_operation(self):
        # Test the case when an unsupported operation is provided
        with self.assertRaises(NotImplementedError):
            OperationFactory.create_operation("unsupported_operation")


class TestMergeCompact(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.mean_1 = request.getfixturevalue("mean_1")
        self.errors_1 = request.getfixturevalue("errors_1")

    def test_merge_compact(self):
        res, res_err = _merge_compact(
            mean_da=self.mean_1,
            error_da=self.errors_1,
        )
        assert res.sizes[TIME_DIM] == 1
        assert res_err.sizes[TIME_DIM] == 1

        expected_mean = np.array([1.055453991, 1.527726996])
        expected_err = np.array([0.09874286, 0.09874286])

        assert np.allclose(res.values.flatten(), expected_mean, atol=1e-3)
        assert np.allclose(res_err.values.flatten(), expected_err, atol=1e-3)
