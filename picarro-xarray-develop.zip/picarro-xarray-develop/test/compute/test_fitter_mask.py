import unittest
from unittest.mock import Mock, patch

import numpy as np
import xarray as xr
import pandas as pd
from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from picarro_xarray.compute.least_squares.fitter_mask import (
    _fill_cids_map,
    _mask_from_complete_map,
    mask_from_map,
)
from picarro_xarray.data_models.constants import TIME_DIM


class TestFillCidsMap(unittest.TestCase):
    def setUp(self):
        self.sample_data = xr.DataArray(
            np.array([1, 2, 3, 1, 2]),
            dims=[TIME_DIM],
            coords={TIME_DIM: pd.date_range("2021-01-01", periods=5)},
        )

    def test_fill_cids_map_basic(self):
        groups_cid_map = {1: [100, 101], 2: [102, 103]}
        result = _fill_cids_map(groups=self.sample_data, groups_cid_map=groups_cid_map)
        self.assertEqual(set(result.keys()), {1, 2, 3})
        self.assertCountEqual(result[1], [100, 101])
        self.assertCountEqual(result[2], [102, 103])
        self.assertCountEqual(result[3], [])

    def test_fill_cids_map_with_always_cids(self):
        groups_cid_map = {1: [100, 101], 2: [102, 103]}
        always_cids = [999]
        result = _fill_cids_map(
            groups=self.sample_data,
            groups_cid_map=groups_cid_map,
            always_cids=always_cids,
        )
        self.assertEqual(set(result.keys()), {1, 2, 3})
        self.assertCountEqual(result[1], [100, 101, 999])
        self.assertCountEqual(result[2], [102, 103, 999])
        self.assertCountEqual(result[3], [999])

    def test_fill_cids_map_with_default_cids(self):
        groups_cid_map = {1: [100, 101], 2: [102, 103]}
        default_cids = [888]
        result = _fill_cids_map(
            groups=self.sample_data,
            groups_cid_map=groups_cid_map,
            default_cids=default_cids,
        )
        self.assertEqual(set(result.keys()), {1, 2, 3})
        self.assertCountEqual(result[1], [100, 101])
        self.assertCountEqual(result[2], [102, 103])
        self.assertCountEqual(result[3], [888])

    def test_fill_cids_map_with_always_and_default_cids(self):
        groups_cid_map = {1: [100, 101], 2: [102, 103]}
        always_cids = [999]
        default_cids = [888]
        result = _fill_cids_map(
            groups=self.sample_data,
            groups_cid_map=groups_cid_map,
            always_cids=always_cids,
            default_cids=default_cids,
        )
        self.assertEqual(set(result.keys()), {1, 2, 3})
        self.assertCountEqual(result[1], [100, 101, 999])
        self.assertCountEqual(result[2], [102, 103, 999])
        self.assertCountEqual(result[3], [888, 999])

    def test_fill_cids_map_with_string_keys(self):
        string_data = xr.DataArray(
            np.array(["A", "B", "C", "A", "B"]),
            dims=[TIME_DIM],
            coords={TIME_DIM: pd.date_range("2021-01-01", periods=5)},
        )
        groups_cid_map = {"A": [100, 101], "B": [102, 103]}
        result = _fill_cids_map(string_data, groups_cid_map)
        self.assertEqual(result, {"A": [100, 101], "B": [102, 103], "C": []})

    def test_fill_cids_map_input_validation(self):
        with self.assertRaises(ValueError):
            _fill_cids_map("invalid_input", {})  # type: ignore

    def test_fill_cids_map_return_validation(self):
        groups_cid_map = {1: [100, 101], 2: [102, 103]}
        result = _fill_cids_map(self.sample_data, groups_cid_map)
        self.assertIsInstance(result, dict)
        self.assertTrue(all(isinstance(k, (int, str)) for k in result.keys()))
        self.assertTrue(
            all(
                isinstance(v, list) and all(isinstance(i, int) for i in v)
                for v in result.values()
            )
        )


class TestMaskFromCompleteMap(unittest.TestCase):
    def setUp(self):
        self.mock_results_keys = [
            "lsq_base_0",
            "lsq_gasConcs_100",
            "lsq_gasConcs_101",
            "lsq_gasConcs_102",
            "lsq_gasConcs_103",
            "lsq_gasConcs_104",
            "lsq_rmse",
        ]

        # Create a mock LinearLeastSquares instance
        self.lsq = Mock(spec=LinearLeastSquares)
        self.lsq.get_results_keys.return_value = self.mock_results_keys

        self.groups = xr.DataArray(
            np.array([1, 2, 3, 1, 2]),
            dims=[TIME_DIM],
            coords={TIME_DIM: pd.date_range("2021-01-01", periods=5)},
        )
        self.groups_cid_map = {1: [100, 101], 2: [102, 103], 3: [104]}

    def test_basic_functionality(self):
        result = _mask_from_complete_map(
            lsq=self.lsq,
            groups=self.groups,
            groups_cid_map=self.groups_cid_map,
            cid_dim="fitter_var",
        )
        self.assertIsInstance(result, xr.DataArray)
        assert TIME_DIM in result.dims
        assert "fitter_var" in result.dims
        assert result.sizes[TIME_DIM] == self.groups.sizes[TIME_DIM]
        assert result.sizes["fitter_var"] == len(self.lsq.get_results_keys()) - 1  # no rmse
        assert not result.chunksizes  # no chunks

    def test_dask_preserve_time_chunks(self):
        groups = self.groups.chunk({TIME_DIM: 2})
        result = _mask_from_complete_map(
            lsq=self.lsq,
            groups=groups,
            groups_cid_map=self.groups_cid_map,
            cid_dim="fitter_var",
        )
        self.assertIsInstance(result, xr.DataArray)
        assert TIME_DIM in result.dims
        assert "fitter_var" in result.dims
        assert result.sizes[TIME_DIM] == self.groups.sizes[TIME_DIM]
        assert result.sizes["fitter_var"] == len(self.lsq.get_results_keys()) - 1  # no rmse
        assert result.chunksizes
        assert result.chunksizes[TIME_DIM] == groups.chunksizes[TIME_DIM]

    def test_baseline_always_true(self):
        result = _mask_from_complete_map(
            lsq=self.lsq,
            groups=self.groups,
            groups_cid_map=self.groups_cid_map,
            cid_dim="fitter_var",
        )
        self.assertTrue(result.sel(fitter_var="lsq_base_0").all())

    def test_correct_mask_values(self):
        result = _mask_from_complete_map(self.lsq, self.groups, self.groups_cid_map)
        # Check mask for group 1
        self.assertTrue(
            result.sel({TIME_DIM: "2021-01-01", "fitter_var": "lsq_gasConcs_100"})
        )
        self.assertTrue(
            result.sel({TIME_DIM: "2021-01-01", "fitter_var": "lsq_gasConcs_101"})
        )
        self.assertFalse(
            result.sel({TIME_DIM: "2021-01-01", "fitter_var": "lsq_gasConcs_102"})
        )
        # Check mask for group 2
        self.assertTrue(
            result.sel({TIME_DIM: "2021-01-02", "fitter_var": "lsq_gasConcs_102"})
        )
        self.assertTrue(
            result.sel({TIME_DIM: "2021-01-02", "fitter_var": "lsq_gasConcs_103"})
        )
        self.assertFalse(
            result.sel({TIME_DIM: "2021-01-02", "fitter_var": "lsq_gasConcs_100"})
        )

    def test_custom_baseline_order(self):
        new_results_keys = [
            "lsq_base_0",
            "lsq_base_1",
            "lsq_gasConcs_100",
            "lsq_gasConcs_101",
            "lsq_gasConcs_102",
            "lsq_gasConcs_103",
            "lsq_gasConcs_104",
            "lsq_rmse",
        ]

        with patch.object(self.lsq, "get_results_keys", return_value=new_results_keys):
            result = _mask_from_complete_map(
                lsq=self.lsq,
                groups=self.groups,
                groups_cid_map=self.groups_cid_map,
                cid_dim="fitter_var",
            )

            self.assertTrue(result.sel(fitter_var="lsq_base_0").all())
            self.assertTrue(result.sel(fitter_var="lsq_base_1").all())

    def test_custom_dimension_name(self):
        result = _mask_from_complete_map(
            self.lsq, self.groups, self.groups_cid_map, cid_dim="custom_dim"
        )
        self.assertIn("custom_dim", result.dims)

    def test_missing_cids(self):
        new_results_keys = ["lsq_base_0", "lsq_rmse"]

        with patch.object(self.lsq, "get_results_keys", return_value=new_results_keys):
            result = _mask_from_complete_map(
                lsq=self.lsq,
                groups=self.groups,
                groups_cid_map=self.groups_cid_map,
                cid_dim="fitter_var",
            )

            self.assertTrue(result.sel(fitter_var="lsq_base_0").all())
            assert result.sizes[TIME_DIM] == self.groups.sizes[TIME_DIM]
            assert result.sizes["fitter_var"] == len(self.lsq.get_results_keys()) - 1  # no rmse
            assert {"lsq_base_0"} == set(result.fitter_var.values)


class TestMaskFromMap(unittest.TestCase):
    def setUp(self):
        self.mock_results_keys = [
            "lsq_base_0",
            "lsq_gasConcs_100",
            "lsq_gasConcs_101",
            "lsq_gasConcs_102",
            "lsq_gasConcs_103",
            "lsq_gasConcs_104",
            "lsq_rmse",
        ]

        # Create a mock LinearLeastSquares instance
        self.lsq = Mock(spec=LinearLeastSquares)
        self.lsq.get_results_keys.return_value = self.mock_results_keys
        self.lsq.cid_list = [100, 101, 102, 103, 104]

        self.groups = xr.DataArray(
            np.array([1, 2, 3, 1, 2]),
            dims=[TIME_DIM],
            coords={TIME_DIM: pd.date_range("2021-01-01", periods=5)},
        )
        self.groups_cid_map = {1: [100, 101], 2: [102, 103]}

    def test_basic_functionality(self):
        result = mask_from_map(
            lsq=self.lsq, groups=self.groups, groups_cid_map=self.groups_cid_map
        )
        self.assertIsInstance(result, xr.DataArray)
        assert TIME_DIM in result.dims
        assert "fitter_var" in result.dims
        assert result.sizes[TIME_DIM] == self.groups.sizes[TIME_DIM]
        assert result.sizes["fitter_var"] == len(self.lsq.get_results_keys()) - 1  # no rmse
        assert not result.chunksizes  # no chunks

    def test_dask_preserves_chunks(self):
        groups = self.groups.chunk({TIME_DIM: 2})
        result = mask_from_map(
            lsq=self.lsq, groups=groups, groups_cid_map=self.groups_cid_map
        )
        self.assertIsInstance(result, xr.DataArray)
        assert TIME_DIM in result.dims
        assert "fitter_var" in result.dims
        assert result.sizes[TIME_DIM] == self.groups.sizes[TIME_DIM]
        assert result.sizes["fitter_var"] == len(self.lsq.get_results_keys())  - 1  # no rmse
        assert result.chunksizes
        assert result.chunksizes[TIME_DIM] == groups.chunksizes[TIME_DIM]

    def test_missing_cids(self):
        groups_cid_map = {1: [100, 101], 2: [102, 103], 3: [108]}

        with self.assertRaises(ValueError) as context:
            mask_from_map(
                lsq=self.lsq, groups=self.groups, groups_cid_map=groups_cid_map
            )

        self.assertIn("1 CIDs are missing", str(context.exception))

    def test_with_always_cids(self):
        result = mask_from_map(
            lsq=self.lsq,
            groups=self.groups,
            groups_cid_map=self.groups_cid_map,
            always_cids=[104],
        )
        self.assertIsInstance(result, xr.DataArray)
        assert "lsq_gasConcs_104" in result.fitter_var.values
        self.assertTrue(result.sel(fitter_var="lsq_gasConcs_104").all())

    def test_with_default_cids(self):
        # group 3 will get the default cids
        result = mask_from_map(
            lsq=self.lsq,
            groups=self.groups,
            groups_cid_map=self.groups_cid_map,
            default_cids=[104],
        )
        self.assertIsInstance(result, xr.DataArray)
        assert "lsq_gasConcs_104" in result.fitter_var.values
        dt = self.groups.where(self.groups == 3, drop=True)[TIME_DIM].values
        self.assertTrue(
            result.sel({TIME_DIM: dt, "fitter_var": "lsq_gasConcs_104"}).all()
        )
