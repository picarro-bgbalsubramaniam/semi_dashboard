import math
import unittest

import numpy as np
import pandas as pd
import pytest
import xarray as xr
from pydantic import ValidationError

from picarro_xarray.compute.compactify import (
    _format_compact_dataset,
    _get_compact_stats,
    _get_grouped_weighted_mean,
    _get_grouped_weighted_std,
    _get_populated_modes_mask,
    _get_spectra_validity_mask,
    _get_updated_spectral_values,
    _move_stat_to_last_dim,
    _parse_prepare_compactify_grouper,
    _prepare_compactify_data,
    _valid_modes_from_mask,
    compactify,
)
from picarro_xarray.compute.spectral_operations.spectral_operations import (
    FITTER,
    SPECTRAL,
)
from picarro_xarray.compute.utils import _filter_groups_population
from picarro_xarray.data_models.constants import MODE_DIM, STATS_DIM, TIME_DIM


class TestCompactify(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds = request.getfixturevalue("combolog_ds")
        self.time_chunk = 3
        self.mode_chunk = 2
        self.spectral_var_chunk = 1
        self.fitter_var_chunk = 2
        self.ds_chunked = self.ds.chunk(
            {
                TIME_DIM: self.time_chunk,
                MODE_DIM: self.mode_chunk,
                "spectral_var": self.spectral_var_chunk,
                "fitter_var": self.fitter_var_chunk,
            }
        )

    def test_compactify_no_group(self):
        res = compactify(
            data=self.ds,
        )
        assert isinstance(res, xr.Dataset)
        assert res.sizes[TIME_DIM] == 1
        assert res.sizes[MODE_DIM] == self.ds.sizes[MODE_DIM]
        assert STATS_DIM in res.coords
        assert FITTER.COORDINATE_INDEXER_NAME in res.coords
        assert FITTER.MEAN_VARIABLE_NAME in res
        assert FITTER.ERROR_VARIABLE_NAME in res
        assert SPECTRAL.COORDINATE_INDEXER_NAME in res.coords
        assert SPECTRAL.MEAN_VARIABLE_NAME in res
        assert SPECTRAL.ERROR_VARIABLE_NAME in res
        assert not res.chunks

        res_chunked = compactify(
            data=self.ds_chunked,
        )
        assert res_chunked.sizes[TIME_DIM] == 1
        assert res_chunked.sizes[MODE_DIM] == self.ds.sizes[MODE_DIM]
        assert STATS_DIM in res_chunked.coords
        assert FITTER.COORDINATE_INDEXER_NAME in res_chunked.coords
        assert FITTER.MEAN_VARIABLE_NAME in res_chunked
        assert FITTER.ERROR_VARIABLE_NAME in res_chunked
        assert SPECTRAL.COORDINATE_INDEXER_NAME in res_chunked.coords
        assert SPECTRAL.MEAN_VARIABLE_NAME in res_chunked
        assert SPECTRAL.ERROR_VARIABLE_NAME in res_chunked
        xr.testing.assert_allclose(res_chunked, res)
        assert res_chunked.chunks

    def test_compactify_str_group(self):
        res = compactify(
            data=self.ds,
            groupby="group_this",
        )
        assert isinstance(res, xr.Dataset)
        assert res.sizes[TIME_DIM] == 2
        assert res.sizes[MODE_DIM] == self.ds.sizes[MODE_DIM]
        assert STATS_DIM in res.coords
        assert FITTER.COORDINATE_INDEXER_NAME in res.coords
        assert FITTER.MEAN_VARIABLE_NAME in res
        assert FITTER.ERROR_VARIABLE_NAME in res
        assert SPECTRAL.COORDINATE_INDEXER_NAME in res.coords
        assert SPECTRAL.MEAN_VARIABLE_NAME in res
        assert SPECTRAL.ERROR_VARIABLE_NAME in res
        assert not res.chunks

        res_chunked = compactify(
            data=self.ds_chunked,
            groupby="group_this",
        )
        xr.testing.assert_allclose(res_chunked, res)
        assert res_chunked.chunks

    def test_compactify_da_group(self):
        gb = xr.DataArray(
            [1, 1, 1, 0, 0, 0, 2, 2, 2, 2],
            dims=TIME_DIM,
            coords={TIME_DIM: self.ds[TIME_DIM].values},
            name="group",
        )
        res = compactify(
            data=self.ds,
            groupby=gb,
        )
        assert isinstance(res, xr.Dataset)
        assert res.sizes[TIME_DIM] == 3
        assert res.sizes[MODE_DIM] == self.ds.sizes[MODE_DIM]
        assert STATS_DIM in res.coords
        assert FITTER.COORDINATE_INDEXER_NAME in res.coords
        assert FITTER.MEAN_VARIABLE_NAME in res
        assert FITTER.ERROR_VARIABLE_NAME in res
        assert SPECTRAL.COORDINATE_INDEXER_NAME in res.coords
        assert SPECTRAL.MEAN_VARIABLE_NAME in res
        assert SPECTRAL.ERROR_VARIABLE_NAME in res
        assert not res.chunks

        res_chunked = compactify(
            data=self.ds_chunked,
            groupby=gb,
        )
        xr.testing.assert_allclose(res_chunked, res)
        assert res_chunked.chunks

    def test_compactify_argument(self):
        with self.assertRaises(ValidationError):
            compactify(
                data=self.ds.spectral_values,
            )

        with self.assertRaises(ValidationError):
            compactify(
                data=self.ds.fitter_values,
            )

        with self.assertRaises(ValidationError):
            compactify(data=self.ds, groupby=123)

        with self.assertRaises(ValidationError):
            compactify(data=self.ds, consecutive=14)

        with self.assertRaises(ValidationError):
            compactify(data=self.ds, min_points_per_group=1)

        with self.assertRaises(ValidationError):
            compactify(data=self.ds, minimum_mode_occupancy=2)

    def test_compactify_groupby_success_str_consecutive(self):
        res = compactify(
            data=self.ds,
            groupby="group_this",
            consecutive=True,
            group_name="group_this",
        )
        assert isinstance(res, xr.Dataset)
        assert res.sizes[TIME_DIM] == 2  # drop two groups with not enough population
        assert "group_this" in res.coords
        assert not res.chunks

        res_chunked = compactify(
            data=self.ds_chunked,
            groupby="group_this",
            consecutive=True,
            group_name="group_this",
        )
        xr.testing.assert_allclose(res_chunked, res)
        assert res_chunked.chunks

    def test_compactify_groupby_success_str(self):
        res = compactify(
            data=self.ds,
            groupby="group_this",
            consecutive=False,
            group_name="group_this",
        )
        assert isinstance(res, xr.Dataset)
        assert res.sizes[TIME_DIM] == 1
        assert "group_this" in res.coords
        assert not res.chunks

        res_chunked = compactify(
            data=self.ds_chunked,
            groupby="group_this",
            consecutive=False,
            group_name="group_this",
        )
        xr.testing.assert_allclose(res_chunked, res)
        assert res_chunked.chunks

    def test_compactify_groupby_fail_str(self):
        with self.assertRaises(ValueError):
            compactify(
                data=self.ds,
                groupby="group_that",
                consecutive=False,
                group_name="group_that",
            )

    def test_compactify_groupby_success_da(self):
        res = compactify(
            data=self.ds,
            groupby=self.ds.sel(fitter_var="group_this", drop=True).fitter_values,
            consecutive=False,
            group_name="group_this",
        )
        assert isinstance(res, xr.Dataset)
        assert res.sizes[TIME_DIM] == 1
        assert "group_this" in res.coords
        assert not res.chunks

        res_chunked = compactify(
            data=self.ds_chunked,
            groupby=self.ds.sel(fitter_var="group_this", drop=True).fitter_values,
            consecutive=False,
            group_name="group_this",
        )
        xr.testing.assert_allclose(res_chunked, res)
        assert res_chunked.chunks

    def test_compactify_groupby_fail_da(self):
        with self.assertRaises(ValueError):
            compactify(
                data=self.ds,
                groupby=self.ds.sel(fitter_var="group_this")
                .isel(_datetime=slice(0, 5))
                .fitter_values,
                consecutive=False,
                group_name="group_that",
            )

    def test_accessor_fails_dims(self):
        import picarro_xarray.accessors.compactify_accessor  # noqa

        ds = self.ds.copy(deep=True).rename({"mode": "mode2"})

        with pytest.raises(TypeError):
            ds.compactify.compact()

        ds = self.ds.copy(deep=True).rename({"_datetime": "time2"})
        with pytest.raises(TypeError):
            ds.compactify.compact()

    def test_accessor_success(self):
        import picarro_xarray.accessors.compactify_accessor  # noqa

        ds = self.ds.copy(deep=True)
        res = ds.compactify.compact()
        assert isinstance(res, xr.Dataset)
        assert TIME_DIM in res.dims

        res = ds.compactify.compact(groupby="group_this")
        assert isinstance(res, xr.Dataset)
        assert TIME_DIM in res.dims

        res = ds.compactify.compact(
            groupby=ds.sel(fitter_var="group_this", drop=True).fitter_values
        )
        assert isinstance(res, xr.Dataset)
        assert TIME_DIM in res.dims


class TestFormatCompactDataset(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.compat_ds = request.getfixturevalue("compat_dataset")
        self.compat_ds = self.compat_ds.assign_coords(
            group=(TIME_DIM, np.arange(self.compat_ds.sizes[TIME_DIM]))
        ).swap_dims({TIME_DIM: "group"})
        self.adev = xr.merge(
            [
                self.compat_ds.sel(stat="allan_dev").spectral_values_stats,
                self.compat_ds.sel(stat="allan_dev").fitter_values_stats,
            ]
        )
        self.adev = self.adev.rename(
            {
                "spectral_values_stats": "spectral_values",
                "fitter_values_stats": "fitter_values",
            }
        )

    def test_format_compact_dataset(self):
        res = _format_compact_dataset(
            fitter_mean=self.compat_ds.fitter_values,
            spectral_mean=self.compat_ds.spectral_values,
            fitter_std=self.compat_ds.sel(stat="std_dev").fitter_values_stats,
            spectral_std=self.compat_ds.sel(stat="std_dev").spectral_values_stats,
            fitter_std_err=self.compat_ds.sel(stat="std_err").fitter_values_stats,
            spectral_std_err=self.compat_ds.sel(stat="std_err").spectral_values_stats,
            allan_dev=self.adev,
            allan_std_err=self.adev,
            group_name="group",
            stats_dim=STATS_DIM,
            time_dim=TIME_DIM,
        )
        assert isinstance(res, xr.Dataset)
        assert TIME_DIM in res.dims


class TestGroupedWeightedMean(unittest.TestCase):
    def setUp(self):
        dt = pd.to_datetime(
            [
                "2021-09-01T12:00:00",
                "2021-09-01T12:05:00",
                "2021-09-01T12:10:00",
                "2021-09-01T12:15:00",
            ]
        )
        self.data = xr.DataArray(
            [[1, 2], [3, 4], [5, 6], [7, 8]],
            dims=[TIME_DIM, "variables"],
            coords={TIME_DIM: dt},
        )
        self.grouper = xr.DataArray(
            [0, 0, 1, 1], dims=[TIME_DIM], coords={TIME_DIM: dt}
        )
        self.uniform_weights = xr.DataArray(
            [[1, 1], [1, 1], [1, 1], [1, 1]],
            dims=[TIME_DIM, "variables"],
            coords={TIME_DIM: dt},
        )

        self.non_uniform_weights = xr.DataArray(
            [[1, 2], [2, 1], [1, 2], [2, 1]],
            dims=[TIME_DIM, "variables"],
            coords={TIME_DIM: dt},
        )

    def test_success_uniform(self):
        """
        For group 0 (time = 0 and 1):

        Mean of w_i * x_i for variable 0: (1*1 + 1*3) / 2 = 2
        Mean of w_i * x_i for variable 1: (1*2 + 1*4) / 2 = 3

        For group 1 (time = 2 and 3):

        Mean of w_i * x_i for variable 0: (1*5 + 1*7) / 2 = 6
        Mean of w_i * x_i for variable 1: (1*6 + 1*8) / 2 = 7
        """
        res = _get_grouped_weighted_mean(
            data=self.data, groupby=self.grouper, weights=self.uniform_weights
        )
        assert isinstance(res, xr.DataArray)
        assert np.allclose(res.values, [[2, 3], [6, 7]])

    def test_success_non_uniform(self):
        """
        For group 0 (time = 0 and 1):

        Arithmetic Mean of w_i * x_i for variable 0: (1*1 + 2*3) / 2 = 3.5

        Arithmetic Mean of w_i for variable 0: (1 + 2) / 2 = 1.5

        Arithmetic Mean of w_i * x_i for variable 1: (2*2 + 1*4) / 2 = 4

        Arithmetic Mean of w_i for variable 1: (2 + 1) / 2 = 1.5

        Weighted Mean for variable 0 in group 0: 3.5 / 1.5 = 2.33
        Weighted Mean for variable 1 in group 0: 4 / 1.5 = 2.67

        For group 1 (time = 2 and 3):

        Arithmetic Mean of w_i * x_i for variable 0: (1*5 + 2*7) / 2 = 9.5

        Arithmetic Mean of w_i for variable 0: (1 + 2) / 2 = 1.5

        Arithmetic Mean of w_i * x_i for variable 1: (2*6 + 1*8) / 2 = 10

        Arithmetic Mean of w_i for variable 1: (2 + 1) / 2 = 1.5

        Weighted Mean for variable 0 in group 1: 9.5 / 1.5 = 6.33
        Weighted Mean for variable 1 in group 1: 10 / 1.5 = 6.67
        """
        res = _get_grouped_weighted_mean(
            data=self.data, groupby=self.grouper, weights=self.non_uniform_weights
        )
        assert isinstance(res, xr.DataArray)
        assert np.allclose(res.values, [[2.3333333, 2.6666667], [6.3333333, 6.666667]])

    def test_fail_different_sizes(self):
        with self.assertRaises(ValueError):
            _get_grouped_weighted_mean(
                data=self.data,
                groupby=self.grouper,
                weights=self.uniform_weights.isel({TIME_DIM: 0}),
            )


class TestGroupedWeightedStd(unittest.TestCase):
    def setUp(self):
        dt = pd.to_datetime(
            [
                "2021-09-01T12:00:00",
                "2021-09-01T12:05:00",
                "2021-09-01T12:10:00",
                "2021-09-01T12:15:00",
            ]
        )
        self.data = xr.DataArray(
            [[1, 2], [3, 4], [5, 6], [7, 8]],
            dims=[TIME_DIM, "variables"],
            coords={TIME_DIM: dt},
        )
        self.grouper = xr.DataArray(
            [0, 0, 1, 1], dims=[TIME_DIM], coords={TIME_DIM: dt}
        )
        self.uniform_weights = xr.DataArray(
            [[1, 1], [1, 1], [1, 1], [1, 1]],
            dims=[TIME_DIM, "variables"],
            coords={TIME_DIM: dt},
        )

        self.non_uniform_weights = xr.DataArray(
            [[1, 2], [2, 1], [1, 2], [2, 1]],
            dims=[TIME_DIM, "variables"],
            coords={TIME_DIM: dt},
        )

    def test_success_uniform(self):
        """
        Means are: [[2, 3], [6, 7]]

        For group 0 (time = 0 and 1):

        Variance for variable 0: [(1*(1-2)^2 + 1*(3-2)^2) / 2]
        Variance for variable 1: [(1*(2-3)^2 + 1*(4-3)^2) / 2]

        Standard deviation is the square root of the variance.

        For group 1 (time = 2 and 3):

        Variance for variable 0: [(1*(5-6)^2 + 1*(7-6)^2) / 2]
        Variance for variable 1: [(1*(6-7)^2 + 1*(8-7)^2) / 2]
        """
        res = _get_grouped_weighted_std(
            data=self.data, groupby=self.grouper, weights=self.uniform_weights
        )
        assert isinstance(res, xr.DataArray)
        assert np.allclose(res.values, [[1, 1], [1, 1]])

        # test chunked
        data = self.data.chunk({TIME_DIM: 2, "variables": 1})
        res2 = _get_grouped_weighted_std(
            data=data, groupby=self.grouper, weights=self.uniform_weights
        )
        assert res2.equals(res)
        assert res2.chunksizes
        assert "group" in res2.chunksizes
        assert "variables" in res2.chunksizes

    def test_success_non_uniform(self):
        """
        Given:
        - Data values: x = [[1, 2], [3, 4], [5, 6], [7, 8]]
        - Weights: w = [[1, 2], [2, 1], [1, 2], [2, 1]]

        For group 0 (time = 0 and 1):

        Variable 0:
        - Weighted Mean: (1 × 1 + 2 × 3) / (1 + 2) = 7 / 3 = 2.33333
        - Weighted Standard Deviation: sqrt((1(1-2.33333)^2 + 2(3-2.33333)^2) / (1 + 2)) = 0.94281

        Variable 1:
        - Weighted Mean: (2 × 2 + 1 × 4) / (2 + 1) = 8 / 3 = 2.66667
        - Weighted Standard Deviation: sqrt((2(2-2.66667)^2 + 1(4-2.66667)^2) / (2 + 1)) = 0.94281

        For group 1 (time = 2 and 3):

        Variable 0:
        - Weighted Mean: (1 × 5 + 2 × 7) / (1 + 2) = 19 / 3 = 6.33333
        - Weighted Standard Deviation: sqrt((1(5-6.33333)^2 + 2(7-6.33333)^2) / (1 + 2)) = 0.94281

        Variable 1:
        - Weighted Mean: (2 × 6 + 1 × 8) / (2 + 1) = 20 / 3 = 6.66667
        - Weighted Standard Deviation: sqrt((2(6-6.66667)^2 + 1(8-6.66667)^2) / (2 + 1)) = 0.94281

        """
        res = _get_grouped_weighted_std(
            data=self.data, groupby=self.grouper, weights=self.non_uniform_weights
        )
        assert isinstance(res, xr.DataArray)
        assert np.allclose(
            res.values, [[0.94280904, 0.94280904], [0.94280904, 0.94280904]]
        )

        # test chunked
        data = self.data.chunk({TIME_DIM: 2, "variables": 1})
        res2 = _get_grouped_weighted_std(
            data=data, groupby=self.grouper, weights=self.non_uniform_weights
        )
        assert res2.equals(res)
        assert res2.chunksizes
        assert "group" in res2.chunksizes
        assert "variables" in res2.chunksizes

    def test_fail_different_sizes(self):
        with self.assertRaises(ValueError):
            _get_grouped_weighted_std(
                data=self.data,
                groupby=self.grouper,
                weights=self.uniform_weights.isel({TIME_DIM: 0}),
            )


class TestGetCompactStats(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds = request.getfixturevalue("combolog_ds")

    def test_get_compact_stats(self):
        gb = xr.DataArray(
            np.ones(self.ds.sizes[TIME_DIM]),
            dims=TIME_DIM,
            coords={TIME_DIM: self.ds[TIME_DIM].values},
            name="group",
        )
        mean, std, std_err = _get_compact_stats(
            data=self.ds.spectral_values,
            groupby=gb,
        )
        for da in [mean, std, std_err]:
            assert isinstance(da, xr.DataArray)
            assert da.sizes[MODE_DIM] == self.ds.sizes[MODE_DIM]

        mean, std, std_err = _get_compact_stats(
            data=self.ds.fitter_values,
            groupby=gb,
        )
        for da in [mean, std, std_err]:
            assert isinstance(da, xr.DataArray)
            assert MODE_DIM not in da.dims

    def test_get_compact_stats_weights(self):
        gb = xr.DataArray(
            np.ones(self.ds.sizes[TIME_DIM]),
            dims=TIME_DIM,
            coords={TIME_DIM: self.ds[TIME_DIM].values},
            name="group",
        )
        weights = xr.ones_like(self.ds.fitter_values)
        mean, std, std_err = _get_compact_stats(
            data=self.ds.fitter_values,
            groupby=gb,
            weights=weights,
        )
        for da in [mean, std, std_err]:
            assert isinstance(da, xr.DataArray)
            assert MODE_DIM not in da.dims

    def test_get_compact_stats_weights_chunked(self):
        gb = xr.DataArray(
            np.ones(self.ds.sizes[TIME_DIM]),
            dims=TIME_DIM,
            coords={TIME_DIM: self.ds[TIME_DIM].values},
            name="group",
        )
        data = self.ds.fitter_values
        data = data.chunk({TIME_DIM: 2, "fitter_var": 2})

        weights = xr.ones_like(data)

        mean, std, std_err = _get_compact_stats(
            data=data,
            groupby=gb,
            weights=weights,
        )
        for da in [mean, std, std_err]:
            assert isinstance(da, xr.DataArray)
            assert MODE_DIM not in da.dims
            assert da.chunksizes
            assert "group" in da.chunksizes
            assert "fitter_var" in da.chunksizes

    def test_compact_stats_fail_dataset(self):
        with self.assertRaises(ValidationError):
            _get_compact_stats(
                data=self.ds,
            )


class TestMoveStatToLastDim(unittest.TestCase):
    def test_move_stats_dim(self):
        stat_da = xr.DataArray(
            np.random.rand(10, 4),
            dims=[TIME_DIM, STATS_DIM],
        )
        res = _move_stat_to_last_dim(
            data=stat_da,
        )
        assert isinstance(res, xr.DataArray)
        assert list(res.dims)[-1] == STATS_DIM

    def test_move_stats_dim_no_stats(self):
        # case where no stat is in dims
        stat_da = xr.DataArray(
            np.random.rand(10, 4),
            dims=[TIME_DIM, "abcdef"],
        )
        res = _move_stat_to_last_dim(
            data=stat_da,
        )
        assert isinstance(res, xr.DataArray)
        assert STATS_DIM not in res.dims


class TestFilterGroupPopulation(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds = request.getfixturevalue("combolog_ds")

    def test_filter_group_population(self):
        res = _filter_groups_population(
            groupby=self.ds.sel(fitter_var="group_this").fitter_values,
            min_points=1,
        )
        assert isinstance(res, xr.DataArray)
        assert res.sizes[TIME_DIM] == 10

        res = _filter_groups_population(
            groupby=self.ds.sel(fitter_var="group_this").fitter_values,
            min_points=3,
        )
        assert isinstance(res, xr.DataArray)
        assert res.sizes[TIME_DIM] == 6


class TestParsePrepareCompactifyGrouper(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds = request.getfixturevalue("combolog_ds")
        self.grouper = self.ds.sel(fitter_var="group_this", drop=True).fitter_values

    def test_success_str(self):
        res = _parse_prepare_compactify_grouper(
            data=self.ds,
            groupby="group_this",
            group_name="group_this",
        )
        assert isinstance(res, xr.DataArray)
        assert res.sizes[TIME_DIM] <= self.ds.sizes[TIME_DIM]

    def test_success_da(self):
        res = _parse_prepare_compactify_grouper(
            data=self.ds,
            groupby=self.grouper,
            group_name="new_group",
        )
        assert isinstance(res, xr.DataArray)
        assert res.sizes[TIME_DIM] <= self.ds.sizes[TIME_DIM]

    def test_success_none(self):
        res = _parse_prepare_compactify_grouper(
            data=self.ds,
            groupby=None,
            group_name="new_group",
        )
        assert isinstance(res, xr.DataArray)
        assert res.sizes[TIME_DIM] == self.ds.sizes[TIME_DIM]
        assert res.name == "new_group"

    def test_success_non_consecutive(self):
        res = _parse_prepare_compactify_grouper(
            data=self.ds,
            groupby=self.grouper,
            group_name="new_group",
            consecutive=False,
        )
        assert isinstance(res, xr.DataArray)
        assert res.name == "new_group"


class TestPrepareCompactifyData(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds = request.getfixturevalue("combolog_ds")
        self.grouper = self.ds.sel(fitter_var="group_this", drop=True).fitter_values

    def test_success(self):
        res = _prepare_compactify_data(
            data=self.ds,
            groupby=self.grouper,
        )
        assert isinstance(res, xr.Dataset)
        assert res.sizes[TIME_DIM] <= self.ds.sizes[TIME_DIM]
        assert res.sizes[MODE_DIM] <= self.ds.sizes[MODE_DIM]

    def test_existing_dimension_name(self):
        with self.assertRaises(ValueError):
            grouper = self.grouper
            grouper.name = "fitter_var"

            _prepare_compactify_data(
                data=self.ds,
                groupby=grouper,
            )

    def test_existing_coordinate(self):
        data = self.ds
        data = data.assign_coords(group=(TIME_DIM, np.arange(data.sizes[TIME_DIM])))
        grouper = self.grouper
        grouper.name = "group"

        res = _prepare_compactify_data(
            data=data,
            groupby=grouper,
        )
        assert isinstance(res, xr.Dataset)
        assert res.sizes[TIME_DIM] <= self.ds.sizes[TIME_DIM]
        assert res.sizes[MODE_DIM] <= self.ds.sizes[MODE_DIM]


def test_valid_modes_from_mask():
    mask = xr.DataArray(
        [
            [True, True, True, False],
            [True, True, True, False],
            [False, False, False, False],
        ],
        dims=["group", MODE_DIM],
        coords={"group": [1, 2, 3], MODE_DIM: ["a", "b", "c", "d"]},
    )
    res = _valid_modes_from_mask(mode_mask=mask, group_dim="group", mode_dim=MODE_DIM)
    assert isinstance(res, np.ndarray)
    assert len(res) == 3
    assert np.all(res == ["a", "b", "c"])

    mask = xr.DataArray(
        [
            [True, True, True, True],
            [True, True, True, False],
            [False, False, False, False],
        ],
        dims=["group", MODE_DIM],
        coords={"group": [1, 2, 3], MODE_DIM: ["a", "b", "c", "d"]},
    )
    res = _valid_modes_from_mask(mode_mask=mask, group_dim="group", mode_dim=MODE_DIM)
    assert isinstance(res, np.ndarray)
    assert len(res) == 4
    assert np.all(res == ["a", "b", "c", "d"])

    mask = xr.DataArray(
        [
            [False, False, False, False],
            [False, False, False, False],
            [False, False, False, False],
        ],
        dims=["group", MODE_DIM],
        coords={"group": [1, 2, 3], MODE_DIM: ["a", "b", "c", "d"]},
    )
    res = _valid_modes_from_mask(mode_mask=mask, group_dim="group", mode_dim=MODE_DIM)
    assert isinstance(res, np.ndarray)
    assert len(res) == 0


def test_get_populated_modes_mask():
    n_times = 15
    n_modes = 2

    groupby_values = [1] * 5 + [2] * 5 + [3] * 5

    _datetime = pd.date_range("2023-01-01", periods=n_times)
    groupby = xr.DataArray(
        groupby_values, coords=[_datetime], dims=[TIME_DIM], name="group"
    )

    # Creating the array filled with True values
    data = np.full((n_times, n_modes), True)

    data[0:2, 0] = False  # 2 of 5 are set to False
    data[:, 1] = False

    # Creating the DataArray with specified dimensions
    validity_mask_xr = xr.DataArray(
        data,
        coords={
            TIME_DIM: _datetime,
            MODE_DIM: np.arange(n_modes),
        },
        dims=[TIME_DIM, MODE_DIM],
    )
    counts = validity_mask_xr[TIME_DIM].groupby(groupby).count(dim=TIME_DIM)

    # result should be [[True, True, True], [False, False, False]]
    res = _get_populated_modes_mask(
        spectral_validity_mask=validity_mask_xr,
        groupby=groupby,
        datetime_counts_per_group=counts,
        minimum_mode_occupancy=0.5,
    )
    assert isinstance(res, xr.DataArray)
    assert res.sizes[MODE_DIM] == n_modes
    assert res.sizes["group"] == 3
    assert np.all(res.isel(mode=0).values)
    assert np.all(res.isel(mode=1).values == [False, False, False])

    # result should be [[False, True, True], [False, False, False]]
    # as I demand 90% occupancy
    res = _get_populated_modes_mask(
        spectral_validity_mask=validity_mask_xr,
        groupby=groupby,
        datetime_counts_per_group=counts,
        minimum_mode_occupancy=0.9,
    )
    assert isinstance(res, xr.DataArray)
    assert res.sizes[MODE_DIM] == n_modes
    assert res.sizes["group"] == 3
    assert np.all(res.isel(mode=0).values == [False, True, True])
    assert np.all(res.isel(mode=1).values == [False, False, False])

    # same tests, but with chunked data
    # verify that the chunking is preserved
    chunk_time = 3
    chunk_mode = 1
    validity_mask_xr = validity_mask_xr.chunk(
        {TIME_DIM: chunk_time, MODE_DIM: chunk_mode}
    )
    assert len(validity_mask_xr.chunksizes[TIME_DIM]) == math.ceil(n_times / chunk_time)
    assert len(validity_mask_xr.chunksizes[MODE_DIM]) == math.ceil(n_modes / chunk_mode)

    # result should be [[True, True, True], [False, False, False]]
    res = _get_populated_modes_mask(
        spectral_validity_mask=validity_mask_xr,
        groupby=groupby,
        datetime_counts_per_group=counts,
        minimum_mode_occupancy=0.5,
    )
    assert isinstance(res, xr.DataArray)
    assert res.sizes[MODE_DIM] == n_modes
    assert res.sizes["group"] == 3
    assert np.all(res.isel(mode=0).values)
    assert np.all(res.isel(mode=1).values == [False, False, False])
    assert res.chunksizes
    assert len(res.chunksizes[groupby.name]) == math.ceil(
        res.sizes[groupby.name] / chunk_time
    )
    assert len(res.chunksizes[MODE_DIM]) == math.ceil(n_modes / chunk_mode)

    # result should be [[False, True, True], [False, False, False]]
    # as I demand 90% occupancy
    res = _get_populated_modes_mask(
        spectral_validity_mask=validity_mask_xr,
        groupby=groupby,
        datetime_counts_per_group=counts,
        minimum_mode_occupancy=0.9,
    )
    assert isinstance(res, xr.DataArray)
    assert res.sizes[MODE_DIM] == n_modes
    assert res.sizes["group"] == 3
    assert np.all(res.isel(mode=0).values == [False, True, True])
    assert np.all(res.isel(mode=1).values == [False, False, False])
    assert res.chunksizes
    assert len(res.chunksizes[groupby.name]) == math.ceil(
        res.sizes[groupby.name] / chunk_time
    )
    assert len(res.chunksizes[MODE_DIM]) == math.ceil(n_modes / chunk_mode)


def test_get_spectra_validity_mask():
    n_times = 15
    n_vars = 3
    n_modes = 2
    _datetime = pd.date_range("2023-01-01", periods=n_times)
    data = np.full((n_times, n_vars, n_modes), 2.0)

    data[0:2, 0, 0] = np.nan  # 2 of 5 are set to False for spectral var 0

    # mode 1 invalid for all times and spectral vars ["a", "b"]
    data[:, 0:2, 1] = np.nan

    data_xr = xr.DataArray(
        data,
        coords={
            TIME_DIM: _datetime,
            "spectral_var": ["a", "b", "c"],
            MODE_DIM: np.arange(n_modes),
        },
        dims=[TIME_DIM, "spectral_var", MODE_DIM],
    )
    res = _get_spectra_validity_mask(
        spectral_data=data_xr,
        control_spectral_vars=["a", "b"],
    )
    expectation = (~np.isnan(data)).all(axis=1)
    assert isinstance(res, xr.DataArray)
    assert res.sizes[MODE_DIM] == n_modes
    assert res.sizes[TIME_DIM] == n_times
    assert np.allclose(res.data, expectation)

    # reduction is performed on spectral var
    assert "spectral_var" not in res.dims

    res = _get_spectra_validity_mask(
        spectral_data=data_xr,
        control_spectral_vars=["c"],
    )
    assert isinstance(res, xr.DataArray)
    assert res.sizes[MODE_DIM] == n_modes
    assert res.sizes[TIME_DIM] == n_times
    assert np.all(res.values)

    # reduction is performed on spectral var
    assert "spectral_var" not in res.dims

    # same tests, but with chunked data
    # verify that the chunking is preserved
    chunk_time = 3
    chunk_mode = 1
    chunk_spectral_var = 1
    data_xr = data_xr.chunk(
        {TIME_DIM: chunk_time, "spectral_var": chunk_spectral_var, MODE_DIM: chunk_mode}
    )
    assert len(data_xr.chunksizes[TIME_DIM]) == math.ceil(n_times / chunk_time)
    assert len(data_xr.chunksizes["spectral_var"]) == math.ceil(
        n_vars / chunk_spectral_var
    )
    assert len(data_xr.chunksizes[MODE_DIM]) == math.ceil(n_modes / chunk_mode)

    res = _get_spectra_validity_mask(
        spectral_data=data_xr,
        control_spectral_vars=["a", "b"],
    )
    assert isinstance(res, xr.DataArray)
    assert res.sizes[MODE_DIM] == n_modes
    assert res.sizes[TIME_DIM] == n_times
    assert np.allclose(res.data, expectation)
    assert res.chunksizes
    assert res.chunksizes[TIME_DIM] == data_xr.chunksizes[TIME_DIM]
    assert res.chunksizes[MODE_DIM] == data_xr.chunksizes[MODE_DIM]

    # reduction is performed on spectral var
    assert "spectral_var" not in res.chunksizes
    assert "spectral_var" not in res.dims

    res = _get_spectra_validity_mask(
        spectral_data=data_xr,
        control_spectral_vars=["c"],
    )
    assert isinstance(res, xr.DataArray)
    assert res.sizes[MODE_DIM] == n_modes
    assert res.sizes[TIME_DIM] == n_times
    assert np.all(res.values)
    assert res.chunksizes
    assert res.chunksizes[TIME_DIM] == data_xr.chunksizes[TIME_DIM]
    assert res.chunksizes[MODE_DIM] == data_xr.chunksizes[MODE_DIM]

    # reduction is performed on spectral var
    assert "spectral_var" not in res.chunksizes
    assert "spectral_var" not in res.dims


def test_get_updated_spectral_values():
    n_times = 15
    n_vars = 3
    n_modes = 2
    groupby_values = [1] * 5 + [2] * 5 + [3] * 5

    _datetime = pd.date_range("2023-01-01", periods=n_times)
    groupby = xr.DataArray(
        groupby_values, coords=[_datetime], dims=[TIME_DIM], name="group"
    )

    data = np.full((n_times, n_vars, n_modes), 2.0)

    data[0:2, 0, 0] = np.nan  # 2 of 5 are set to False for spectral var 0

    # mode 1 invalid for all times and spectral vars ["a", "b"]
    data[:, 0:2, 1] = np.nan

    data_xr = xr.DataArray(
        data,
        coords={
            TIME_DIM: _datetime,
            "spectral_var": ["a", "b", "c"],
            MODE_DIM: np.arange(n_modes),
        },
        dims=[TIME_DIM, "spectral_var", MODE_DIM],
    )
    spectra_mask = _get_spectra_validity_mask(
        spectral_data=data_xr,
        control_spectral_vars=["a", "b"],
    )

    mode_mask = _get_populated_modes_mask(
        spectral_validity_mask=spectra_mask,
        groupby=groupby,
        datetime_counts_per_group=spectra_mask[TIME_DIM]
        .groupby(groupby)
        .count(dim=TIME_DIM),
        minimum_mode_occupancy=0.9,
    )
    expected_mode_mask = np.array([[False, False], [True, False], [True, False]])
    assert np.all(mode_mask.values == expected_mode_mask)

    updated_spectra = _get_updated_spectral_values(
        spectral_data=data_xr,
        spectral_validity_mask=spectra_mask,
        populated_modes_mask=mode_mask,
        groupby=groupby,
    )

    # check that the invalid values are replaced by NaN
    # invalid values where in the first group with spectral_var "a"
    # and mode 0
    should_be_null = updated_spectra.isel(mode=0, spectral_var=0, _datetime=slice(0, 5))
    assert np.all(np.isnan(should_be_null.values))

    # specifically, the last two values of original data were not null
    not_null = data_xr.isel(mode=0, spectral_var=0, _datetime=slice(3, 5))
    assert np.all(not_null.values == 2.0)

    # but they should be null in the updated data
    assert np.all(np.isnan(should_be_null.isel(_datetime=slice(3, 5)).values))

    expected_spectra = np.array([[np.nan] * 5 + [2.0] * 10, [np.nan] * 15]).T
    assert np.allclose(
        updated_spectra.isel(spectral_var=0).values, expected_spectra, equal_nan=True
    )
    assert np.allclose(
        updated_spectra.isel(spectral_var=1).values, expected_spectra, equal_nan=True
    )
    assert np.allclose(
        updated_spectra.isel(spectral_var=2).values, expected_spectra, equal_nan=True
    )

    # no chunks
    assert not updated_spectra.chunksizes

    # check with chunking
    chunk_time = 3
    data_xr = xr.DataArray(
        data,
        coords={
            TIME_DIM: _datetime,
            "spectral_var": ["a", "b", "c"],
            MODE_DIM: np.arange(n_modes),
        },
        dims=[TIME_DIM, "spectral_var", MODE_DIM],
    )
    data_xr = data_xr.chunk({TIME_DIM: chunk_time, "spectral_var": 1, MODE_DIM: 2})

    spectra_mask = _get_spectra_validity_mask(
        spectral_data=data_xr,
        control_spectral_vars=["a", "b"],
    )

    mode_mask = _get_populated_modes_mask(
        spectral_validity_mask=spectra_mask,
        groupby=groupby,
        datetime_counts_per_group=spectra_mask[TIME_DIM]
        .groupby(groupby)
        .count(dim=TIME_DIM),
        minimum_mode_occupancy=0.9,
    )

    updated_spectra_chunked = _get_updated_spectral_values(
        spectral_data=data_xr,
        spectral_validity_mask=spectra_mask,
        populated_modes_mask=mode_mask,
        groupby=groupby,
    )
    assert updated_spectra_chunked.chunksizes
    assert updated_spectra_chunked.chunksizes[TIME_DIM]
    assert updated_spectra_chunked.chunksizes[MODE_DIM]
    assert updated_spectra_chunked.chunksizes["spectral_var"]
    assert len(updated_spectra_chunked.chunksizes[TIME_DIM]) == math.ceil(
        n_times / chunk_time
    )
    assert updated_spectra_chunked.equals(updated_spectra)
