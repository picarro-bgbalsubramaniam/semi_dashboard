import unittest

import numpy as np
import pytest
import xarray as xr
from pydantic import ValidationError

from picarro_xarray.compute.allan_deviation import (
    _allan_dev,
    _allan_std_err,
    _allan_var,
    _calc_adev_phase,
    _compute_complete_allan_dev,
    _compute_first_term_allan_dev,
    compute_allan_dev,
    frequency_to_phase,
    generate_taus,
)
from picarro_xarray.compute.utils import remove_non_numeric_variables
from picarro_xarray.data_models.constants import TIME_DIM


class TestGenerateTaus(unittest.TestCase):
    def test_generate_taus_valid_input(self):
        self.assertEqual(generate_taus(16), [1, 2, 4, 8])
        self.assertEqual(generate_taus(1), [])
        self.assertEqual(generate_taus(2), [1])
        self.assertEqual(generate_taus(32), [1, 2, 4, 8, 16])

    def test_generate_taus_invalid_input(self):
        with self.assertRaises(ValidationError):
            generate_taus(0)
        with self.assertRaises(ValidationError):
            generate_taus("abc")


class TestFrequencyToPhase(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        self.ds = ds

    def test_arguments(self):
        with pytest.raises(ValidationError):
            frequency_to_phase(self.ds.fitter_values.values)
        with pytest.raises(ValidationError):
            frequency_to_phase("abc")

    def test_da(self):
        res = frequency_to_phase(self.ds.fitter_values)
        assert isinstance(res, xr.DataArray)
        assert TIME_DIM in res.dims
        assert res.sizes[TIME_DIM] == self.ds.fitter_values.sizes[TIME_DIM] + 1

    def test_ds(self):
        res = frequency_to_phase(self.ds)
        assert isinstance(res, xr.Dataset)
        assert TIME_DIM in res.dims
        assert res.sizes[TIME_DIM] == self.ds.fitter_values.sizes[TIME_DIM] + 1


class TestCalcAdevPhase(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        ds = remove_non_numeric_variables(ds)
        self.ds = ds

    def test_arguments(self):
        with pytest.raises(ValidationError):
            _calc_adev_phase(
                phase=self.ds.fitter_values,
                mj=1,
                stride=-1,
            )
        with pytest.raises(ValidationError):
            _calc_adev_phase(
                phase=self.ds.fitter_values,
                mj=0,
                stride=1,
            )

        with pytest.raises(ValidationError):
            _calc_adev_phase(
                phase=self.ds.fitter_values,
                mj=1,
                stride="a",
            )

        with pytest.raises(ValidationError):
            _calc_adev_phase(
                phase=self.ds.fitter_values,
                mj="b",
                stride=1,
            )

        with pytest.raises(ValidationError):
            _calc_adev_phase(
                phase=self.ds.fitter_values.values,
                mj=1,
                stride=1,
            )

    def test_da(self):
        res = _calc_adev_phase(
            phase=self.ds.fitter_values,
            mj=1,
            stride=1,
        )
        assert isinstance(res, xr.DataArray)

    def test_ds(self):
        res = _calc_adev_phase(
            phase=self.ds,
            mj=1,
            stride=1,
        )
        assert isinstance(res, xr.Dataset)


class TestAllanDev(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        ds = remove_non_numeric_variables(ds)
        self.ds = ds

    def test_arguments(self):
        with pytest.raises(ValidationError):
            _allan_dev(
                phase="abc",
                taus=[1, 2, 4],
                overlapping=True,
            )

        with pytest.raises(ValidationError):
            _allan_dev(
                phase=self.ds.fitter_values,
                taus="abc",
                overlapping=True,
            )

        with pytest.raises(ValidationError):
            _allan_dev(
                phase=self.ds,
                taus=[1, 2, 4],
                overlapping="cde",
            )

    def test_success_da_overlapping(self):
        res = _allan_dev(
            phase=self.ds.fitter_values,
            taus=[1, 2],
            overlapping=True,
        )
        assert isinstance(res, xr.DataArray)

    def test_success_da_non_overlapping(self):
        res = _allan_dev(
            phase=self.ds.fitter_values,
            taus=[1, 2],
            overlapping=False,
        )
        assert isinstance(res, xr.DataArray)

    def test_success_ds_overlapping(self):
        res = _allan_dev(
            phase=self.ds,
            taus=[1, 2],
            overlapping=True,
        )
        assert isinstance(res, xr.Dataset)

    def test_success_ds_non_overlapping(self):
        res = _allan_dev(
            phase=self.ds,
            taus=[1, 2],
            overlapping=False,
        )
        assert isinstance(res, xr.Dataset)


class TestAllanVariations(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        ds = remove_non_numeric_variables(ds)
        allan_ds = _allan_dev(
            phase=ds,
            taus=[1, 2],
            overlapping=False,
        )
        self.allan_ds = allan_ds
        self.allan_da = allan_ds.fitter_values

    def test_arguments_std_err(self):
        with pytest.raises(ValidationError):
            _allan_std_err(
                allan_dev_data="abc",
            )

        with pytest.raises(ValidationError):
            _allan_std_err(
                allan_dev_data=self.allan_ds.rename({"tau": "abc"}),
            )

        with pytest.raises(ValidationError):
            _allan_std_err(
                allan_dev_data=self.allan_da.rename({"tau": "abc"}),
            )

    def test_arguments_var(self):
        with pytest.raises(ValidationError):
            _allan_var(
                allan_dev_data="abc",
            )

        with pytest.raises(ValidationError):
            _allan_var(
                allan_dev_data=self.allan_ds.rename({"tau": "abc"}),
            )

        with pytest.raises(ValidationError):
            _allan_var(
                allan_dev_data=self.allan_da.rename({"tau": "abc"}),
            )

    def test_success_std_err_ds(self):
        res = _allan_std_err(
            allan_dev_data=self.allan_ds,
        )
        assert isinstance(res, xr.Dataset)

    def test_success_std_err_da(self):
        res = _allan_std_err(
            allan_dev_data=self.allan_da,
        )
        assert isinstance(res, xr.DataArray)

    def test_success_var_ds(self):
        res = _allan_var(
            allan_dev_data=self.allan_ds,
        )
        assert isinstance(res, xr.Dataset)

    def test_success_var_da(self):
        res = _allan_var(
            allan_dev_data=self.allan_da,
        )
        assert isinstance(res, xr.DataArray)


class TestComputeCompleteAllanDev(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        self.ds = ds

    def test_arguments(self):
        with pytest.raises(ValidationError):
            _compute_complete_allan_dev(data="abc", overlapping=True)

        with pytest.raises(ValidationError):
            _compute_complete_allan_dev(data=self.ds, overlapping="abc")

        with pytest.raises(ValidationError):
            _compute_complete_allan_dev(
                data=self.ds.rename({TIME_DIM: "abc"}),
                overlapping=False,
            )

    def test_success_ds(self):
        res = _compute_complete_allan_dev(data=self.ds, overlapping=False)
        assert isinstance(res, xr.Dataset)
        assert "tau" in res.dims

        res = _compute_complete_allan_dev(data=self.ds, overlapping=True)
        assert isinstance(res, xr.Dataset)
        assert "tau" in res.dims

    def test_success_da(self):
        res = _compute_complete_allan_dev(data=self.ds.fitter_values, overlapping=False)
        assert isinstance(res, xr.DataArray)
        assert "tau" in res.dims

        res = _compute_complete_allan_dev(data=self.ds.fitter_values, overlapping=True)
        assert isinstance(res, xr.DataArray)
        assert "tau" in res.dims

        res = _compute_complete_allan_dev(data=self.ds.fitter_values, overlapping=False)
        assert isinstance(res, xr.DataArray)
        assert "tau" in res.dims


class TestComputeFirstTermAllanDev(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        self.ds = ds.drop_vars("fitter_origin_file")
        self.grouper = xr.DataArray(
            data=[0, 0, 0, 0, 1, 1, 1, 2, 2, 2],
            dims=TIME_DIM,
            coords={TIME_DIM: ds[TIME_DIM].values},
        )

    def test_arguments(self):
        with pytest.raises(ValidationError):
            _compute_first_term_allan_dev(data="abc", groupby=self.grouper)

        with pytest.raises(ValidationError):
            _compute_first_term_allan_dev(data=self.ds, groupby="abc")

        with pytest.raises(ValidationError):
            _compute_first_term_allan_dev(
                data=self.ds.rename({TIME_DIM: "abc"}),
                groupby=self.grouper,
            )

    def test_success_ds(self):
        res = _compute_first_term_allan_dev(data=self.ds, groupby=self.grouper)
        assert isinstance(res, xr.Dataset)
        assert "tau" in res.coords
        assert TIME_DIM in res.dims
        assert "tau_scaled" in res.coords

    def test_success_da(self):
        res = _compute_first_term_allan_dev(
            data=self.ds.fitter_values, groupby=self.grouper
        )
        assert isinstance(res, xr.DataArray)
        assert "tau" in res.coords
        assert TIME_DIM in res.dims
        assert "tau_scaled" in res.coords

        res = _compute_first_term_allan_dev(
            data=self.ds.spectral_values, groupby=self.grouper
        )
        assert isinstance(res, xr.DataArray)
        assert "tau" in res.coords
        assert TIME_DIM in res.dims
        assert "tau_scaled" in res.coords


class TestComputeAllanDev(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        self.ds = ds
        self.grouper = self.ds.sel(fitter_var="group_this").fitter_values

    def test_arguments(self):
        with pytest.raises(ValidationError):
            compute_allan_dev(data="abc", groupby=None, complete=True)

        with pytest.raises(ValidationError):
            compute_allan_dev(data=self.ds, groupby="abc", complete=True)

        with pytest.raises(ValidationError):
            compute_allan_dev(data=self.ds, groupby=self.grouper, complete="abc")

        with pytest.raises(ValidationError):
            compute_allan_dev(
                data=self.ds.rename({TIME_DIM: "abc"}),
                complete=False,
            )

    def test_success_ds(self):
        res = compute_allan_dev(data=self.ds, complete=True)
        assert isinstance(res, xr.Dataset)
        assert "tau" in res.coords

        res = compute_allan_dev(data=self.ds, complete=False)
        assert isinstance(res, xr.Dataset)
        assert "tau" in res.coords
        assert res.sizes[TIME_DIM] == 1

        res = compute_allan_dev(data=self.ds, groupby=self.grouper, complete=False)
        assert isinstance(res, xr.Dataset)
        assert "tau" in res.coords
        assert res.sizes[TIME_DIM] == len(np.unique(self.grouper.values))

    def test_success_da(self):
        res = compute_allan_dev(data=self.ds.fitter_values, complete=True)
        assert isinstance(res, xr.DataArray)
        assert "tau" in res.coords

        res = compute_allan_dev(data=self.ds.fitter_values, complete=False)
        assert isinstance(res, xr.DataArray)
        assert "tau" in res.coords
        assert res.sizes[TIME_DIM] == 1

        res = compute_allan_dev(
            data=self.ds.fitter_values, groupby=self.grouper, complete=False
        )
        assert isinstance(res, xr.DataArray)
        assert "tau" in res.coords
        assert res.sizes[TIME_DIM] == len(np.unique(self.grouper.values))

        res = compute_allan_dev(data=self.ds.spectral_values, complete=True)
        assert isinstance(res, xr.DataArray)
        assert "tau" in res.coords

        res = compute_allan_dev(data=self.ds.spectral_values, complete=False)
        assert isinstance(res, xr.DataArray)
        assert "tau" in res.coords
        assert res.sizes[TIME_DIM] == 1

        res = compute_allan_dev(
            data=self.ds.spectral_values, groupby=self.grouper, complete=False
        )
        assert isinstance(res, xr.DataArray)
        assert "tau" in res.coords
        assert res.sizes[TIME_DIM] == len(np.unique(self.grouper.values))

    def test_raise_if_group_and_complete(self):
        with pytest.raises(NotImplementedError):
            compute_allan_dev(data=self.ds, groupby=self.grouper, complete=True)


class TestAllanAccessor(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        import picarro_xarray.accessors.allan_accessor  # noqa

        ds = request.getfixturevalue("combolog_ds")
        ds = remove_non_numeric_variables(ds)
        self.ds = ds

    def _check_allan_method(self, method_name):
        method = getattr(self.ds.allan, method_name)
        # Test default (not complete)
        res = method()
        assert isinstance(res, xr.Dataset)
        assert "tau" in res.coords
        assert res.tau.size == 1
        assert TIME_DIM in res.dims
        assert "tau_scaled" in res.coords

        # Test complete=True
        res = method(complete=True)
        assert isinstance(res, xr.Dataset)
        assert "tau" in res.coords
        assert res.tau.size > 1

    def test_allan_dev(self):
        self._check_allan_method("allan_dev")

    def test_allan_std_err(self):
        self._check_allan_method("allan_std_err")

    def test_allan_var(self):
        self._check_allan_method("allan_var")

    def test_time_failure(self):
        da = xr.DataArray(
            data=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
            dims="a",
            coords={"a": np.arange(10)},
        )
        with pytest.raises(TypeError):
            da.allan.allan_dev()
