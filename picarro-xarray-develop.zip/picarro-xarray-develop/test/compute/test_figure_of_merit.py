import unittest

import pytest
import xarray as xr
from pydantic import ValidationError

import picarro_xarray.accessors.allan_accessor  # noqa
from picarro_xarray.compute.figure_of_merit import figure_of_merit, get_figure_of_merit
from picarro_xarray.compute.utils import remove_non_numeric_variables
from picarro_xarray.data_models.constants import TIME_DIM


class TestFOM(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        ds = remove_non_numeric_variables(ds)
        self.da = ds.fitter_values

    def test_success_numpy(self):
        with self.assertRaises(NotImplementedError):
            get_figure_of_merit(
                zero_referenced_data=self.da,
                transition_variable_data=self.da.sel(fitter_var="group_this"),
                reference_sigma_tau=self.da.allan.allan_dev(complete=False),
                group_name="abcde",
            )

    def test_success_dask(self):
        da = self.da.chunk({TIME_DIM: 2})
        with self.assertRaises(NotImplementedError):
            get_figure_of_merit(
                zero_referenced_data=da,
                transition_variable_data=da.sel(fitter_var="group_this"),
                reference_sigma_tau=da.allan.allan_dev(complete=False),
            )

    def test_success_full_adev(self):
        da = self.da.chunk({TIME_DIM: 2})
        with self.assertRaises(NotImplementedError):
            get_figure_of_merit(
                zero_referenced_data=da,
                transition_variable_data=da.sel(fitter_var="group_this"),
                reference_sigma_tau=da.allan.allan_dev(complete=True),
            )

    def test_different_length(self):
        with self.assertRaises(NotImplementedError):
            get_figure_of_merit(
                zero_referenced_data=self.da,
                transition_variable_data=self.da.sel(fitter_var="group_this").isel(
                    {TIME_DIM: slice(1, None)}
                ),
                reference_sigma_tau=self.da.allan.allan_dev(complete=False),
            )

    def test_arguments(self):
        with self.assertRaises(ValidationError):
            get_figure_of_merit(
                zero_referenced_data=self.da,
                transition_variable_data=self.da.sel(fitter_var="group_this"),
                reference_sigma_tau=self.da.allan.allan_dev(complete=False),
                group_name=1,
            )

        with self.assertRaises(ValidationError):
            get_figure_of_merit(
                zero_referenced_data=self.da,
                transition_variable_data=self.da.sel(fitter_var="group_this"),
                reference_sigma_tau=self.da,
            )

        with self.assertRaises(ValidationError):
            get_figure_of_merit(
                zero_referenced_data=self.da,
                transition_variable_data=self.da.sel(fitter_var="group_this").rename(
                    {TIME_DIM: "time"}
                ),
                reference_sigma_tau=self.da.allan.allan_dev(complete=False),
            )

        with self.assertRaises(ValidationError):
            get_figure_of_merit(
                zero_referenced_data=self.da,
                transition_variable_data=self.da.sel(fitter_var="group_this"),
                reference_sigma_tau=self.da.allan.allan_dev(complete=False),
                sigma_confidence_level=-1,
            )


class TestFigureOfMerit(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        ds = remove_non_numeric_variables(ds)
        lod = ds.mean(dim="_datetime")
        lod = lod.assign_coords(tau_scaled=5)
        self.fake_lod = lod
        self.da = ds.fitter_values
        self.ds = ds

    def test_da_group(self):
        res = figure_of_merit(
            zero_referenced_data=self.da,
            lod_data=self.fake_lod.fitter_values,
            groupby="group_this",
        )
        assert isinstance(res, xr.DataArray)
        assert res.sizes[TIME_DIM] < self.da.sizes[TIME_DIM]

    def test_da_no_group(self):
        res = figure_of_merit(
            zero_referenced_data=self.da,
            lod_data=self.fake_lod.fitter_values,
        )
        assert isinstance(res, xr.DataArray)
        assert res.sizes[TIME_DIM] == self.da.sizes[TIME_DIM]

    def test_ds_group(self):
        res = figure_of_merit(
            zero_referenced_data=self.ds,
            lod_data=self.fake_lod,
            groupby="group_this",
        )
        assert isinstance(res, xr.Dataset)
        assert res.sizes[TIME_DIM] < self.da.sizes[TIME_DIM]

    def test_ds_no_group(self):
        res = figure_of_merit(
            zero_referenced_data=self.ds,
            lod_data=self.fake_lod,
        )
        assert isinstance(res, xr.Dataset)
        assert res.sizes[TIME_DIM] == self.da.sizes[TIME_DIM]
