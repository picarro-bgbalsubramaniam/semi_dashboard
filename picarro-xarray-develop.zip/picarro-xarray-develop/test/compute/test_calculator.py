import unittest
from unittest.mock import Mock, patch

import numpy as np
import xarray as xr
from pydantic import ValidationError

from picarro_xarray.compute.spectral_operations.calculator import (
    _check_and_cast_dimensions,
    _prepare_operators,
    operation_dispatcher,
)
from picarro_xarray.compute.spectral_operations.operations import Operation
from picarro_xarray.data_models.constants import COUNT_DIM, TIME_DIM


class TestCheckAndCastDimensions(unittest.TestCase):
    def test_success(self):
        """Test the successful case where mean_2 and errors_2 have the correct dimension size."""
        time = np.array(
            ["2023-01-01T00:00", "2023-01-01T00:01"], dtype="datetime64[ns]"
        )
        mean_1 = xr.DataArray([1, 2], dims=[TIME_DIM], coords={TIME_DIM: time})
        mean_2 = xr.DataArray([3], dims=[TIME_DIM], coords={TIME_DIM: time[:1]})
        errors_1 = xr.DataArray([0.1, 0.2], dims=[TIME_DIM], coords={TIME_DIM: time})
        errors_2 = xr.DataArray([0.3], dims=[TIME_DIM], coords={TIME_DIM: time[:1]})

        result = _check_and_cast_dimensions(mean_1, mean_2, errors_1, errors_2)

        self.assertIsInstance(result, tuple)
        self.assertEqual(len(result), 4)

        for item in result:
            self.assertIsInstance(item, xr.DataArray)

        self.assertIn(TIME_DIM, result[0].dims)
        self.assertNotIn(TIME_DIM, result[1].dims)  # check the squeeze
        self.assertIn(TIME_DIM, result[2].dims)
        self.assertNotIn(TIME_DIM, result[3].dims)

    def test_failure_due_to_incorrect_dimension_size(self):
        """Test failure when mean_2 and errors_2 have more than one time point."""
        time = np.array(
            ["2023-01-01T00:00", "2023-01-02T00:00"], dtype="datetime64[ns]"
        )
        mean_1 = xr.DataArray([1, 2], dims=[TIME_DIM], coords={TIME_DIM: time})
        mean_2 = xr.DataArray(
            [3, 4], dims=[TIME_DIM], coords={TIME_DIM: time}
        )  # more than one time point
        errors_1 = xr.DataArray([0.1, 0.2], dims=[TIME_DIM], coords={TIME_DIM: time})
        errors_2 = xr.DataArray(
            [0.3, 0.4], dims=[TIME_DIM], coords={TIME_DIM: time}
        )  # more than one time point

        with self.assertRaises(ValueError) as context:
            _check_and_cast_dimensions(mean_1, mean_2, errors_1, errors_2)

        self.assertIn(
            "Second operand of a spectral operation shall", str(context.exception)
        )


class TestPrepareOperators(unittest.TestCase):
    def setUp(self):
        """Set up reusable assets."""
        self.time = np.array(["2023-01-01T00:00"], dtype="datetime64[ns]")
        self.count = np.ones(len(self.time))
        self.mean_1 = xr.DataArray(
            [1],
            dims=[TIME_DIM],
            coords={TIME_DIM: self.time, COUNT_DIM: (TIME_DIM, self.count)},
        )
        self.errors_1 = xr.DataArray(
            [0.1],
            dims=[TIME_DIM],
            coords={TIME_DIM: self.time, COUNT_DIM: (TIME_DIM, self.count)},
        )

    def test_mean_2_as_scalar(self):
        """Test if function handles scalar mean_2 correctly."""
        mean_2 = 3  # scalar

        result = _prepare_operators(self.mean_1, mean_2, self.errors_1)

        # Check types and equality
        self.assertIsInstance(result, tuple)
        self.assertEqual(len(result), 4)

        for item in result:
            self.assertIsInstance(item, xr.DataArray)

        self.assertEqual(
            result[1].values, np.array([mean_2])
        )  # check mean_2 values are the scalar
        self.assertEqual(result[3].values, np.array([0]))  # check errors_2 is zero

    def test_errors_2_none(self):
        """Test if function handles None errors_2 correctly, assigning zero errors."""
        mean_2 = xr.DataArray([3], dims=[TIME_DIM], coords={TIME_DIM: self.time})

        result = _prepare_operators(self.mean_1, mean_2, self.errors_1, None)

        # Check types and equality
        self.assertIsInstance(result, tuple)
        self.assertEqual(len(result), 4)

        for item in result:
            self.assertIsInstance(item, xr.DataArray)

        # Check values for errors_2
        np.testing.assert_array_equal(result[3].values, np.array([0]))

    def test_mean_2_as_dataarray(self):
        """Test if function handles DataArray mean_2 correctly."""
        mean_2 = xr.DataArray([3], dims=[TIME_DIM], coords={TIME_DIM: self.time})
        errors_2 = xr.DataArray([0.3], dims=[TIME_DIM], coords={TIME_DIM: self.time})

        result = _prepare_operators(self.mean_1, mean_2, self.errors_1, errors_2)

        # Check types and equality
        self.assertIsInstance(result, tuple)
        self.assertEqual(len(result), 4)
        for item in result:
            self.assertIsInstance(item, xr.DataArray)

        self.assertEqual(
            result[1].values, mean_2.values
        )  # check mean_2 values are the same
        self.assertEqual(
            result[3].values, errors_2.values
        )  # check errors_2 values are the same


class TestOperationDispatcher(unittest.TestCase):
    def setUp(self):
        """Set up reusable assets."""
        self.time = np.array(["2023-01-01T00:00"], dtype="datetime64[ns]")
        self.mean_1 = xr.DataArray([1], dims=[TIME_DIM], coords={TIME_DIM: self.time})
        self.mean_2 = xr.DataArray([2], dims=[TIME_DIM], coords={TIME_DIM: self.time})
        self.errors_1 = xr.DataArray(
            [0.1], dims=[TIME_DIM], coords={TIME_DIM: self.time}
        )
        self.errors_2 = xr.DataArray(
            [0.2], dims=[TIME_DIM], coords={TIME_DIM: self.time}
        )
        self.operation = Operation.DIFFERENCE

    from picarro_xarray.compute.spectral_operations.calculator import OperationFactory

    @patch.object(OperationFactory, "create_operation")
    def test_valid_operation(self, mock_operation_factory):
        """Test the operation_dispatcher with valid inputs and operation."""

        # Mocking the operation function that would be created by the OperationFactory
        mock_operation_func = Mock()
        mock_operation_func.return_value = (self.mean_1, self.errors_1)
        mock_operation_factory.return_value = mock_operation_func

        result_mean, result_errors = operation_dispatcher(
            self.operation, self.mean_1, self.mean_2, self.errors_1, self.errors_2
        )

        # Validate that the OperationFactory was called with the correct operation
        mock_operation_factory.assert_called_once_with(self.operation)

        # Validate the operation function is called with the correct arguments
        mock_operation_func.assert_called_once_with(
            self.mean_1, self.mean_2, self.errors_1, self.errors_2
        )

        self.assertEqual(result_mean.values, self.mean_1.values)
        self.assertEqual(result_errors.values, self.errors_1.values)

    def test_arguments(self):
        with self.assertRaises(ValidationError):
            operation_dispatcher(
                self.operation,
                self.mean_1,
                self.mean_2,
                self.errors_1,
                self.errors_2.rename({TIME_DIM: "time"}),
            )

        with self.assertRaises(ValidationError):
            operation_dispatcher(
                self.operation, 5, self.mean_2, self.errors_1, self.errors_2
            )

        with self.assertRaises(ValidationError):
            operation_dispatcher(
                self.operation, self.mean_1, "abcde", self.errors_1, self.errors_2
            )
