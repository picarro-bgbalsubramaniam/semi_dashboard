import unittest

from sklearn.datasets import make_regression

from picarro_xarray.compute.least_squares.ridge_hyperparameter import (
    _get_optimal_lambda,
    _get_optimal_lambda_se,
    _hkb,
    _k4,
    _kb3,
    _l_curve,
    estimate_ridge_parameter,
)


class TestRidgeHyperparameter(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.X, cls.y = make_regression(
            n_samples=100, n_features=20, noise=0.1, random_state=42
        )

    def test_estimate_ridge_parameter(self):
        # Test the main function with different methods
        methods = [
            "cross_validate_opt",
            "cross_validate_se",
            "k4",
            "hkb",
            "kb3",
        ]
        for method in methods:
            lambda_value = estimate_ridge_parameter(self.X, self.y, method=method)
            self.assertIsInstance(lambda_value, float)
            self.assertGreater(lambda_value, 0)

    def test_invalid_method(self):
        with self.assertRaises(ValueError):
            estimate_ridge_parameter(self.X, self.y, method="give me stuff!")


    def test_get_optimal_lambda(self):
        lambda_value = _get_optimal_lambda(self.X, self.y)
        self.assertIsInstance(lambda_value, float)
        self.assertGreater(lambda_value, 0)

    def test_get_optimal_lambda_se(self):
        lambda_value = _get_optimal_lambda_se(self.X, self.y)
        self.assertIsInstance(lambda_value, float)
        self.assertGreater(lambda_value, 0)

    def test_k4(self):
        lambda_value = _k4(self.X, self.y)
        self.assertIsInstance(lambda_value, float)
        self.assertGreater(lambda_value, 0)

    def test_hkb(self):
        lambda_value = _hkb(self.X, self.y)
        self.assertIsInstance(lambda_value, float)
        self.assertGreater(lambda_value, 0)

    def test_kb3(self):
        lambda_value = _kb3(self.X, self.y)
        self.assertIsInstance(lambda_value, float)
        self.assertGreater(lambda_value, 0)

    def test_l_curve(self):
        lambda_value = _l_curve(self.X, self.y)
        self.assertIsInstance(lambda_value, float)
        self.assertGreater(lambda_value, 0)

    def test_custom_estimator(self):
        def custom_estimator(X, y, **kwargs):
            return 0.1

        lambda_value = estimate_ridge_parameter(self.X, self.y, method=custom_estimator)
        self.assertEqual(lambda_value, 0.1)

    def test_invalid_method(self):
        with self.assertRaises(ValueError):
            estimate_ridge_parameter(self.X, self.y, method="invalid_method")
