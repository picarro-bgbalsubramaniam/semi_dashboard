import unittest

import numpy as np
import pandas as pd
import pytest
import xarray as xr
from pydantic import ValidationError

import picarro_xarray.accessors.allan_accessor  # noqa
from picarro_xarray.compute.interference_detection import (
    InterferenceEvent,
    get_outliers_and_transitions,
    hampel_filter,
)
from picarro_xarray.data_models.constants import (
    CID_DIM,
    TIME_DIM,
)


class TestInterferentsDetection(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.fom = request.getfixturevalue("fom_data_array")

    def test_success(self):
        interf_list = get_outliers_and_transitions(
            figure_of_merit_da=self.fom,
            hampel_window_size=10,
            hampel_scale_factor=2,
            gmm_window_size=10,
            gmm_scale_factor=4.5,
            dask="parallelized",
            transition_var="abcde",
        )
        assert isinstance(interf_list, list)
        assert len(interf_list) > 0
        assert isinstance(interf_list[0], InterferenceEvent)

    def test_arguments(self):
        with self.assertRaises(ValidationError):
            get_outliers_and_transitions(
                figure_of_merit_da=self.fom,
                hampel_window_size=10,
                hampel_scale_factor=2,
                gmm_window_size=10,
                gmm_scale_factor=4.5,
                dask="parallelized",
                transition_var=1,
            )

        with self.assertRaises(ValidationError):
            get_outliers_and_transitions(
                figure_of_merit_da=self.fom,
                hampel_window_size=10,
                hampel_scale_factor=2,
                gmm_window_size=0,
                gmm_scale_factor=4.5,
                transition_var="abcde",
                dask="parallelized",
            )

        with self.assertRaises(ValidationError):
            get_outliers_and_transitions(
                figure_of_merit_da=self.fom,
                hampel_window_size=0,
                hampel_scale_factor=2,
                gmm_window_size=10,
                gmm_scale_factor=4.5,
                transition_var="abcde",
                dask="parallelized",
            )

        with self.assertRaises(ValidationError):
            get_outliers_and_transitions(
                figure_of_merit_da=self.fom.to_pandas(),
                hampel_window_size=10,
                hampel_scale_factor=2,
                gmm_window_size=10,
                gmm_scale_factor=4.5,
                transition_var="abcde",
                dask="parallelized",
            )


class TestHampelFilter(unittest.TestCase):
    def setUp(self):
        """Set up basic data for tests."""
        self.times = pd.date_range("2023-01-01T00:00:00", periods=10, freq="min")
        self.fitter_vars = ["A", "B"]
        self.time_dim = TIME_DIM
        self.fitter_dim = CID_DIM

        # Basic data: mostly 1s, one obvious outlier for var 'A'
        data_values = np.ones((len(self.times), len(self.fitter_vars)))
        data_values[5, 0] = 100  # Outlier for var A at time index 5
        self.da = xr.DataArray(
            data_values,
            coords={
                self.time_dim: self.times,
                self.fitter_dim: self.fitter_vars,
            },
            dims=[self.time_dim, self.fitter_dim],
            name="test_data",
        )

        # Grouping array
        group_data = ["group1"] * 3 + ["group2"] * 7
        self.group_by_da = xr.DataArray(
            group_data, coords={self.time_dim: self.times}, dims=[self.time_dim]
        )

    def test_basic_outlier_detection(self):
        """Test basic non-grouped outlier detection."""
        result = hampel_filter(self.da, window_size=3, factor=2, time_dim=self.time_dim)
        # Expecting the outlier at index 5 for var 'A' to be positive
        assert result.sel({self.time_dim: self.times[5], self.fitter_dim: "A"}) > 0
        # Expecting other points to be NaN (or non-positive if we revert the NaN change)
        assert np.isnan(
            result.sel({self.time_dim: self.times[0], self.fitter_dim: "A"}).item()
        )
        assert np.isnan(
            result.sel({self.time_dim: self.times[5], self.fitter_dim: "B"}).item()
        )
        assert result.notnull().sum().item() == 1  # Only one outlier score

        # Test with chunked data
        da = self.da.chunk({TIME_DIM: 5, CID_DIM: 1})
        result = hampel_filter(da, window_size=3, factor=2, time_dim=self.time_dim)
        assert result.notnull().sum().compute().item() == 1

    def test_grouped_outlier_detection(self):
        """Test grouped outlier detection."""
        # Modify data to have an outlier in group2 for var 'B'
        grouped_test_da = self.da.copy()
        grouped_test_da.loc[{self.time_dim: self.times[8], self.fitter_dim: "B"}] = 200

        result = hampel_filter(
            grouped_test_da,
            group_by=self.group_by_da,
            window_size=3,
            factor=2,
            time_dim=self.time_dim,
        )

        # Outlier in group1 for 'A'
        assert result.sel({self.time_dim: self.times[5], self.fitter_dim: "A"}) > 0
        # Outlier in group2 for 'B'
        assert result.sel({self.time_dim: self.times[8], self.fitter_dim: "B"}) > 0
        # Check a non-outlier point
        assert np.isnan(
            result.sel({self.time_dim: self.times[0], self.fitter_dim: "A"}).item()
        )
        assert result.notnull().sum().item() == 2  # Two outlier scores

        # Test with chunked data
        da = grouped_test_da.chunk({TIME_DIM: 5, CID_DIM: 1})
        result = hampel_filter(
            da,
            group_by=self.group_by_da,
            window_size=3,
            factor=2,
            time_dim=self.time_dim,
        )
        assert result.notnull().sum().compute().item() == 2

    def test_no_outliers(self):
        """Test with data that has no outliers."""
        no_outlier_data = xr.DataArray(
            np.ones((len(self.times), len(self.fitter_vars))),
            coords=self.da.coords,
            dims=self.da.dims,
        )
        result = hampel_filter(
            no_outlier_data, window_size=3, factor=2, time_dim=self.time_dim
        )
        assert result.isnull().all()  # All values should be NaN
