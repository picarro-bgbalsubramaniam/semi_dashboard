import numpy as np
import pandas as pd
import pytest

from picarro_xarray.compute.transitions import split_transitions_by_duration


def _dt_index(n, start="2025-01-01 00:00:00", freq="10min"):
    return pd.date_range(start=start, periods=n, freq=freq)


def _verify_max_span(series: pd.Series, max_duration: pd.Timedelta) -> bool:
    g = series.groupby(series)
    return bool((g.apply(lambda s: s.index[-1] - s.index[0] <= max_duration)).all())


def test_empty_series_returns_empty():
    idx = _dt_index(0)
    s = pd.Series([], index=idx, dtype=np.int64, name="transition_uid")
    out = split_transitions_by_duration(s, pd.Timedelta(minutes=15))
    assert isinstance(out, pd.Series)
    assert out.empty
    assert (out.index == s.index).all()
    assert out.name == s.name

def test_non_datetime_index_raises():
    s = pd.Series([1, 1, 1], index=range(3), name="transition_uid")
    with pytest.raises(IndexError):
        _ = split_transitions_by_duration(s, pd.Timedelta(minutes=15))


def test_duplicate_index_raises():
    idx = _dt_index(3)
    idx = idx.take([0, 1, 1])
    s = pd.Series([1, 1, 1], index=idx, name="transition_uid")
    with pytest.raises(ValueError):
        _ = split_transitions_by_duration(s, pd.Timedelta(minutes=15))


def test_non_integer_castable_float_raises_then_cast_works():
    idx = _dt_index(5)
    # Castable floats (exact integers), but function requires integer-like dtype
    s_float = pd.Series([1.0, 1.0, 1.0, 1.0, 1.0], index=idx, name="transition_uid")
    with pytest.raises(TypeError):
        _ = split_transitions_by_duration(s_float, pd.Timedelta(minutes=15))

    # Explicitly casting to int should succeed
    s_int = s_float.astype(np.int64)
    out = split_transitions_by_duration(s_int, pd.Timedelta(minutes=15))
    assert isinstance(out, pd.Series)
    assert (out.index == s_int.index).all()


def test_non_integer_string_castable_and_uncastable_raise():
    idx = _dt_index(3)
    # Numeric strings are “castable” externally, but the function requires int dtype and should raise
    s_str_castable = pd.Series(["1", "1", "1"], index=idx, name="transition_uid")
    with pytest.raises(TypeError):
        _ = split_transitions_by_duration(s_str_castable, pd.Timedelta(minutes=15))

    # Uncastable strings
    s_str_bad = pd.Series(["a", "b", "c"], index=idx, name="transition_uid")
    with pytest.raises(TypeError):
        _ = split_transitions_by_duration(s_str_bad, pd.Timedelta(minutes=15))


def test_series_with_nan_raises_valueerror():
    idx = _dt_index(3)
    s = pd.Series([1, np.nan, 1], index=idx, name="transition_uid")
    with pytest.raises(ValueError):
        _ = split_transitions_by_duration(s, pd.Timedelta(minutes=15))


def test_non_monotonic_index_raises():
    idx = _dt_index(4)
    idx = idx.take([0, 2, 1, 3])  # make non-monotonic
    s = pd.Series([1, 1, 1, 1], index=idx, name="transition_uid", dtype=np.int64)
    with pytest.raises(ValueError):
        _ = split_transitions_by_duration(s, pd.Timedelta(minutes=15))


def test_effective_splitting_single_run_varied_durations():
    # Single run of identical IDs across 0, 10, 20, 30, 40 minutes
    idx = _dt_index(5, freq="10min")
    base = pd.Series([1, 1, 1, 1, 1], index=idx, name="transition_uid", dtype=np.int64)

    # 15-minute limit (strictly-greater policy): expect segments at 0–<15, 15–<30, 30–...
    out_15 = split_transitions_by_duration(base, pd.Timedelta(minutes=15))
    assert _verify_max_span(out_15, pd.Timedelta(minutes=15))
    # Should produce 3 segments: [0,10] -> seg0, [20] -> seg1, [30,40] -> seg2
    assert out_15.nunique() == 3

    # 30-minute limit: expect 2 segments: [0,10,20] and [30,40]
    out_30 = split_transitions_by_duration(base, pd.Timedelta(minutes=30))
    assert _verify_max_span(out_30, pd.Timedelta(minutes=30))
    assert out_30.nunique() == 2

    # Boundary equality should not split (strictly greater)
    idx2 = _dt_index(2, freq="15min")
    base2 = pd.Series([7, 7], index=idx2, name="transition_uid", dtype=np.int64)
    out_eq = split_transitions_by_duration(base2, pd.Timedelta(minutes=15))
    assert _verify_max_span(out_eq, pd.Timedelta(minutes=15))
    assert out_eq.nunique() == 1


def test_effective_splitting_multiple_runs_global_uniqueness():
    # Two runs, each 3 points at 10-minute spacing:
    # Run1 IDs=1 at t=[0,10,20], Run2 IDs=2 at t=[30,40,50]
    idx = _dt_index(6, freq="10min")
    vals = [1, 1, 1, 2, 2, 2]
    s = pd.Series(vals, index=idx, name="transition_uid", dtype=np.int64)

    out = split_transitions_by_duration(s, pd.Timedelta(minutes=15))
    assert _verify_max_span(out, pd.Timedelta(minutes=15))

    # Each run splits into 2 segments -> total 4 globally unique IDs
    assert out.nunique() == 4

    # IDs should be non-decreasing and run boundaries respected
    assert (np.diff(out.to_numpy()) >= 0).all()
    # Check per-original-run segments count via groupby on original base values
    g = out.groupby(s)
    seg_counts = g.nunique()
    assert seg_counts.loc[1] == 2
    assert seg_counts.loc[2] == 2
    