import unittest
import xarray as xr
import numpy as np
from pydantic import ValidationError

from picarro_xarray.compute.spectral_operations.error_propagation import (
    errors_quadrature,
    errors_product,
)


class TestErrorPropagationFunctions(unittest.TestCase):
    def test_errors_quadrature_simple(self):
        err_1 = xr.DataArray([0.1, 0.8], dims=["mode"])
        err_2 = xr.DataArray([0.2, 0.1], dims=["mode"])
        expected = np.array([0.2236068, 0.80622577])
        result = errors_quadrature(err_1, err_2).values
        self.assertTrue(np.allclose(result, expected))

    def test_errors_product_simple(self):
        err_1 = xr.DataArray([0.3, 2.5], dims=["mode"])
        mean_1 = xr.DataArray([3, 5], dims=["mode"])
        err_2 = xr.DataArray([0.2, 1], dims=["mode"])
        mean_2 = xr.DataArray([2.0, 4], dims=["mode"])
        mean_result = mean_1 * mean_2
        expected = np.array([0.8485, 11.1803])
        result = errors_product(err_1, mean_1, err_2, mean_2, mean_result).values
        self.assertTrue(np.allclose(result, expected, atol=1e-4))

    def test_errors_quadrature_multidim(self):
        # this is the case where multiple copmpact spectra are processed
        # against a single compact spectrum
        # the operations should be performed on each compact spectrum by broadcasting
        err_1 = xr.DataArray([[0.1, 0.8, 1.0], [0.8, 0.1, 1.0]], dims=["mode", "time"])
        err_2 = xr.DataArray([0.2, 0.1], dims=["mode"])
        expected = np.array([[0.2236068, 0.8246, 1.0198], [0.80622577, 0.1414, 1.0049]])
        result = errors_quadrature(err_1, err_2).values
        assert result.shape == expected.shape
        self.assertTrue(np.allclose(result, expected, atol=1e-4))

    def test_errors_product_multidim(self):
        # this is the case where multiple copmpact spectra are processed
        # against a single compact spectrum
        # the operations should be performed on each compact spectrum by broadcasting
        err_1 = xr.DataArray([[0.1, 0.8, 1.0], [0.8, 0.1, 1.0]], dims=["mode", "time"])
        mean_1 = xr.DataArray([[1.0, 4.0, 2.0], [3.0, 1.5, 2.0]], dims=["mode", "time"])
        err_2 = xr.DataArray([0.2, 0.1], dims=["mode"])
        mean_2 = xr.DataArray([2.0, 0.5], dims=["mode"])

        mean_result = mean_1 * mean_2

        expected = np.array([[0.2828, 1.7885, 2.0396], [0.5, 0.1581, 0.5385]])

        # Call the function with the test data
        result = errors_product(err_1, mean_1, err_2, mean_2, mean_result).values

        # Assertions to ensure output is as expected
        self.assertEqual(result.shape, expected.shape)  # same shape
        self.assertTrue(np.allclose(result, expected, atol=1e-3))  # values are close

    def test_arguments_quadrature(self):
        with self.assertRaises(ValidationError):
            errors_quadrature(1, xr.DataArray([0.1, 0.8], dims=["mode"]))

    def test_arguments_product(self):
        with self.assertRaises(ValidationError):
            errors_product(
                "abc",
                xr.DataArray([3, 5], dims=["mode"]),
                xr.DataArray([0.2, 1], dims=["mode"]),
                xr.DataArray([2.0, 4], dims=["mode"]),
                xr.DataArray([6.0, 20], dims=["mode"]),
            )
