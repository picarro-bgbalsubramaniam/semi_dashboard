import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import dask.array as da
import numpy as np
import pandas as pd
import pytest
import xarray as xr
from pydantic import ValidationError

from picarro_xarray.compute.least_squares.utils import (
    _create_valid_modes_mask,
    _retrieve_max_true_values,
)
from picarro_xarray.compute.utils import (
    _rechunk_time,
    maybe_cache,
    remove_non_numeric_variables,
)
from picarro_xarray.data_models.constants import CID_DIM, MODE_DIM, TIME_DIM


class TestMaybeCache(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        self.ds = ds.copy(deep=True)

    def test_cache_zarr(self):
        # Import the modules to get references to the functions
        import xarray.backends.api

        from picarro_xarray.compute import utils

        with (
            patch.object(utils.xr, "open_zarr") as mock_open_zarr,
            patch.object(xarray.backends.api, "to_zarr") as mock_to_zarr,
        ):
            # cache
            mock_open_zarr.return_value = self.ds
            with tempfile.TemporaryDirectory() as tmp_folder:
                fname = "test.zarr"
                res = maybe_cache(self.ds, fname, temp_storage=Path(tmp_folder))
                assert res is self.ds
                mock_to_zarr.assert_called_once()
                mock_open_zarr.assert_called_once_with(Path(tmp_folder) / fname)

    def test_cache_netcdf(self):
        # Import the modules to get references to the functions
        import xarray.backends.api

        from picarro_xarray.compute import utils

        with (
            patch.object(utils.xr, "open_dataset") as mock_open_dataset,
            patch.object(xarray.backends.api, "to_netcdf") as mock_to_netcdf,
        ):
            # cache
            mock_open_dataset.return_value = self.ds
            with tempfile.TemporaryDirectory() as tmp_folder:
                fname = "test.nc"
                res = maybe_cache(self.ds, fname, temp_storage=Path(tmp_folder))
                assert res is self.ds
                mock_to_netcdf.assert_called_once()
                mock_open_dataset.assert_called_once_with(Path(tmp_folder) / fname)

    def test_no_cache(self):
        # Import the modules to get references to the functions
        import xarray.backends.api

        from picarro_xarray.compute import utils

        with (
            patch.object(utils.xr, "open_zarr") as mock_open_zarr,
            patch.object(xarray.backends.api, "to_zarr") as mock_to_zarr,
        ):
            fname = "test.zarr"
            res = maybe_cache(self.ds, fname, temp_storage=None)
            assert res is self.ds
            mock_to_zarr.assert_not_called()
            mock_open_zarr.assert_not_called()


class TestRemoveNonNumericVariables(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        self.ds = ds

    def test_arguments(self):
        with pytest.raises(ValidationError):
            remove_non_numeric_variables("abc")

    def test_success_ds(self):
        ds = remove_non_numeric_variables(self.ds)
        assert isinstance(ds, xr.Dataset)
        assert "fitter_origin_file" not in ds.data_vars

    def test_success_da(self):
        da = remove_non_numeric_variables(self.ds.fitter_values)
        assert isinstance(da, xr.DataArray)

    def test_fail_da(self):
        with pytest.raises(ValueError):
            remove_non_numeric_variables(self.ds.fitter_origin_file)


class TestCreateValidModesMask(unittest.TestCase):
    def test_all_valid(self):
        spectrum = np.array([[1, 2, 3], [4, 5, 6]])
        expected = np.array([True, True, True])
        result = _create_valid_modes_mask(spectrum, threshold=0.5)
        assert np.all(result == expected)

    def test_all_invalid(self):
        spectrum = np.array([[np.nan, np.nan], [np.nan, np.nan]])
        expected = np.array([False, False])
        result = _create_valid_modes_mask(spectrum, threshold=0.5)
        assert np.all(result == expected)

    def test_mixed_validity(self):
        spectrum = np.array([[1, np.nan, 3], [np.nan, 2, np.nan]])
        expected = np.array([True, True, True])
        result = _create_valid_modes_mask(spectrum, threshold=0.5)
        assert np.all(result == expected)

    def test_threshold_effect(self):
        spectrum = np.array([[1, np.nan, 3], [np.nan, 2, np.nan]])
        expected_low = np.array([True, True, True])
        expected_high = np.array([False, False, False])
        result_low = _create_valid_modes_mask(spectrum, threshold=0.3)
        result_high = _create_valid_modes_mask(spectrum, threshold=0.7)
        assert np.all(result_low == expected_low)
        assert np.all(result_high == expected_high)

    def test_empty_spectrum(self):
        spectrum = np.array([])
        expected = np.array([])
        result = _create_valid_modes_mask(spectrum, threshold=0.5)
        assert np.all(result == expected)

    def test_single_row(self):
        spectrum = np.array([[1, np.nan, 3]])
        expected = np.array([True, False, True])
        result = _create_valid_modes_mask(spectrum, threshold=0.5)
        assert np.all(result == expected)


class TestRetrieveMaxTrueValues(unittest.TestCase):
    def test_retrieve_max_true_values(self):
        # Create 3 time points with 6 fitter variables
        test_data = np.array(
            [
                [True, False, True, True, True, True],  # Sum: 5
                [True, True, False, False, False, False],  # Sum: 2
                [True, True, True, False, False, False],  # Sum: 3
            ],
            dtype=bool,
        )  # (_datetime, fitter_var) == (3, 6)

        # Expected maximum sum is 5
        expected_max = 5

        time_coords = pd.date_range(start="2023-01-01", periods=3, freq="h")
        fitter_var_coords = ["var1", "var2", "var3", "var4", "var5", "var6"]

        # create cid fitter mask
        cid_fitter_mask = xr.DataArray(
            data=test_data,
            dims=["_datetime", "fitter_var"],
            coords={"_datetime": time_coords, "fitter_var": fitter_var_coords},
        )

        result = _retrieve_max_true_values(cid_fitter_mask)

        # Check the result
        self.assertEqual(result, expected_max)

        # try with chunked data
        cid_fitter_mask = cid_fitter_mask.chunk({"fitter_var": 2, "_datetime": 2})
        result = _retrieve_max_true_values(cid_fitter_mask)
        self.assertEqual(result, expected_max)

    def test_empty_mask(self):
        # Create an empty mask (all False)
        test_data = np.zeros((2, 3), dtype=bool)

        time_coords = pd.date_range(start="2023-01-01", periods=2, freq="h")
        fitter_var_coords = ["var1", "var2", "var3"]

        cid_fitter_mask = xr.DataArray(
            data=test_data,
            dims=["_datetime", "fitter_var"],
            coords={"_datetime": time_coords, "fitter_var": fitter_var_coords},
        )

        # Expected maximum sum is 0
        expected_max = 0

        # Get the result
        result = _retrieve_max_true_values(cid_fitter_mask)

        # Check the result
        self.assertEqual(result, expected_max)


class TestRechunkTime(unittest.TestCase):
    def setUp(self):
        """Create a test dataset with dask arrays for use in tests."""
        # Create dimensions
        time_size = 500
        mode_size = 30
        cid_size = 15

        # Create coordinate arrays
        time_coords = pd.date_range("2023-01-01", periods=time_size, freq="1s")
        mode_coords = np.arange(mode_size)
        cid_coords = [f"var_{i}" for i in range(cid_size)]

        # Create multiple dask arrays for different variables
        data_vars = {}
        data_vars["spectral_values"] = (
            [TIME_DIM, MODE_DIM, CID_DIM],
            da.random.random((time_size, mode_size, cid_size), chunks=(50, 10, 5)),
        )

        data_vars["fitter_values"] = (
            [TIME_DIM, CID_DIM],
            da.random.random((time_size, cid_size), chunks=(50, 5)),
        )

        # Create xarray Dataset
        self.ds_test = xr.Dataset(
            data_vars,
            coords={TIME_DIM: time_coords, MODE_DIM: mode_coords, CID_DIM: cid_coords},
        )

    def test_rechunk_time_dataarray(self):
        """Test _rechunk_time with a DataArray using dask arrays without materialization."""
        target_chunksize_mb = 50

        # Get spectral_values DataArray from the test dataset
        for test_var in ["spectral_values", "fitter_values"]:
            da_test = self.ds_test[test_var]

            # Verify it's using dask (not materialized)
            self.assertTrue(da_test.chunks is not None)

            # Test rechunking
            rechunked = _rechunk_time(da_test, target_chunksize_mb=target_chunksize_mb)

            # Verify output is still a DataArray
            self.assertIsInstance(rechunked, xr.DataArray)

            # Verify it's still using dask
            self.assertTrue(rechunked.chunks is not None)

            # Verify time dimension is chunked as single block
            time_chunks = rechunked.chunksizes[TIME_DIM]
            self.assertEqual(len(time_chunks), 1)
            self.assertEqual(time_chunks[0], self.ds_test.sizes[TIME_DIM])

    def test_rechunk_time_dataset(self):
        """Test _rechunk_time with a Dataset using dask arrays."""
        target_chunksize_mb = 50

        # Verify it's using dask
        for var in self.ds_test.data_vars:
            self.assertTrue(self.ds_test[var].chunks is not None)

        # Test rechunking
        rechunked = _rechunk_time(self.ds_test, target_chunksize_mb=target_chunksize_mb)

        # Verify output is still a Dataset
        self.assertIsInstance(rechunked, xr.Dataset)

        # Verify all variables are properly rechunked
        for var_name in self.ds_test.data_vars:
            var_rechunked = rechunked[var_name]

            # Still using dask
            self.assertTrue(var_rechunked.chunks is not None)

            # Time dimension chunked as single block
            time_chunks = var_rechunked.chunksizes[TIME_DIM]
            self.assertEqual(len(time_chunks), 1)
            self.assertEqual(time_chunks[0], self.ds_test.sizes[TIME_DIM])

            # Data hasn't been materialized
            self.assertTrue(hasattr(var_rechunked.data, "compute"))

    def test_no_time_dim(self):
        ds_test = self.ds_test.rename({TIME_DIM: "wrong_time"})
        with pytest.raises(ValidationError):
            _rechunk_time(ds_test)
