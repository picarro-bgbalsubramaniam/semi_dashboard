import unittest

from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from picarro_xarray.compute.least_squares.experimental import (
    get_petroglyph_least_squares,
)


class TestGetPetroglyphLeastSquares(unittest.TestCase):
    def setUp(self):
        self.model_functions = {
            cid: lambda pressure: pressure * cid for cid in range(1000)
        }
        self.cids = [100, 200, 300]
        self.pressure = 1.0

    def test_valid_input(self):
        lsq = get_petroglyph_least_squares(
            self.model_functions, self.cids, self.pressure
        )
        self.assertIsInstance(lsq, LinearLeastSquares)

    def test_dont_fit(self):
        cids_with_dont_fit = [947, 100, 200]
        lsq = get_petroglyph_least_squares(
            self.model_functions, cids_with_dont_fit, self.pressure
        )
        # Check that 947 is not in the model functions used
        self.assertNotIn(947, lsq.model_functions.funcs)

    def test_edge_case_nu_min_max(self):
        lsq = get_petroglyph_least_squares(
            self.model_functions, self.cids, self.pressure, nu_min=5700, nu_max=6400
        )
        self.assertEqual(lsq.model_functions.nu_min, 5700)
        self.assertEqual(lsq.model_functions.nu_max, 6400)

    def test_invalid_input(self):
        with self.assertRaises(KeyError):
            # Assuming a KeyError is raised for missing model functions
            get_petroglyph_least_squares({}, self.cids, self.pressure)
