import unittest
from unittest.mock import patch

import numpy as np
import pytest
import xarray as xr
from pydantic import ValidationError

from picarro_xarray.compute.spectra_integral import (
    integrate_da,
    partial_fit_integral,
    partial_fit_integral_equivalent,
    spectrum_integral,
)
from picarro_xarray.data_models.constants import CID_DIM, MODE_DIM, TIME_DIM


class TestSpectraIntegral(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds = request.getfixturevalue("combolog_ds")
        self.time_chunk = 3
        self.mode_chunk = 2
        self.spectral_var_chunk = 1
        self.fitter_var_chunk = 2
        self.ds_chunked = self.ds.chunk(
            {
                TIME_DIM: self.time_chunk,
                MODE_DIM: self.mode_chunk,
                "spectral_var": self.spectral_var_chunk,
                "fitter_var": self.fitter_var_chunk,
            }
        )

    def test_arguments_partial_fit_integral(self):
        with pytest.raises(ValidationError):
            partial_fit_integral(data=self.ds_chunked, integral_func="not a function")

        with pytest.raises(ValidationError):
            partial_fit_integral(data=self.ds_chunked.spectral_values.values)

    def test_spectral_vars_partial_fit_integral(self):
        with pytest.raises(ValueError):
            partial_fit_integral(data=self.ds.drop_sel(spectral_var="partial_fit"))

    def test_success_partial_fit_integral(self):
        res = partial_fit_integral(data=self.ds_chunked)
        assert isinstance(res, xr.DataArray)
        assert res.sizes[TIME_DIM] == self.ds_chunked.sizes[TIME_DIM]
        assert MODE_DIM not in res.dims
        assert res.chunks

        res = partial_fit_integral(data=self.ds)
        assert isinstance(res, xr.DataArray)
        assert res.sizes[TIME_DIM] == self.ds_chunked.sizes[TIME_DIM]
        assert MODE_DIM not in res.dims
        assert not res.chunks

    def test_arguments_spectrum_integral(self):
        with pytest.raises(ValidationError):
            spectrum_integral(
                x=self.ds_chunked.spectral_values, y=self.ds_chunked.fitter_values
            )

        with pytest.raises(ValidationError):
            spectrum_integral(
                x=self.ds_chunked.spectral_values,
                y=self.ds_chunked.spectral_values,
                integral_func="not a function",
            )

    def test_spectrum_integral_deprecated(self):
        with self.assertRaises(NotImplementedError):
            spectrum_integral(
                x=self.ds_chunked.sel(spectral_var="nu_prime").spectral_values,
                y=self.ds_chunked.sel(spectral_var="partial_fit").spectral_values,
            )

    def test_arguments_integrate_da(self):
        with pytest.raises(ValidationError):
            integrate_da(
                x=self.ds_chunked.spectral_values,
                y=self.ds_chunked.fitter_values,
            )

        with pytest.raises(ValidationError):
            integrate_da(
                x=self.ds_chunked.spectral_values,
                y=self.ds_chunked.spectral_values,
                integral_func="not a function",
            )

    def test_match_integrate_da_partial_fit_integral(self):
        res_partial_fit = partial_fit_integral(data=self.ds_chunked)
        res_integrate = integrate_da(
            x=self.ds_chunked.sel(spectral_var="nu_prime").spectral_values,
            y=self.ds_chunked.sel(spectral_var="partial_fit").spectral_values,
            integral_dim=MODE_DIM,
        )
        assert res_partial_fit.equals(res_integrate)


class TestPartialFitIntegralEquivalent(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds = request.getfixturevalue("combolog_ds")
        self.ds_chunked = self.ds.chunk({TIME_DIM: 3, MODE_DIM: 2})

        n_modes = self.ds.sizes[MODE_DIM]

        self.mock_cids_da = xr.DataArray(
            [np.random.rand(n_modes), np.random.rand(n_modes)],
            dims=[CID_DIM, MODE_DIM],
            coords={
                MODE_DIM: self.ds[MODE_DIM],
                CID_DIM: ["gasConcs_1", "gasConcs_2"],
            },
        )

    def test_invalid_arguments(self):
        with pytest.raises(ValidationError):
            partial_fit_integral_equivalent(data=self.ds_chunked, cids="not a list")

    def test_missing_compound_search_accessor(self):
        with pytest.raises(ValueError):
            partial_fit_integral_equivalent(data=self.ds_chunked, cids=[1, 2])

    def test_success_with_chunked_data(self):
        import picarro_xarray.accessors.compound_search_accessor  # noqa

        with patch.object(
            self.ds_chunked.compound_search,
            "get_model_functions",
            return_value=self.mock_cids_da,
        ):
            res = partial_fit_integral_equivalent(
                data=self.ds_chunked, cids=[1, 2], prefix="gasConcs_"
            )
            assert isinstance(res, xr.DataArray)
            assert res.sizes[TIME_DIM] == self.ds_chunked.sizes[TIME_DIM]
            assert MODE_DIM not in res.dims
            assert res.chunks

    def test_success_with_unchunked_data(self):
        import picarro_xarray.accessors.compound_search_accessor  # noqa

        with patch.object(
            self.ds.compound_search,
            "get_model_functions",
            return_value=self.mock_cids_da.compute(),
        ):
            res = partial_fit_integral_equivalent(data=self.ds, cids=[1, 2])
            assert isinstance(res, xr.DataArray)
            assert res.sizes[TIME_DIM] == self.ds.sizes[TIME_DIM]
            assert MODE_DIM not in res.dims
            assert not res.chunks

    def test_missing_required_spectral_variables(self):
        ds_missing_var = self.ds_chunked.drop_sel(spectral_var="partial_fit")
        with pytest.raises(ValueError):
            partial_fit_integral_equivalent(data=ds_missing_var, cids=[1, 2])
