import unittest
from unittest.mock import patch

import xarray as xr

from picarro_xarray.compute.spectral_operations.operations import Operation
from picarro_xarray.compute.spectral_operations.operations_mapping import (
    _fill_operation_map_with_default,
    _get_default_fitter_operation_map,
    _get_default_spectral_operation_map,
    parse_operation,
)


class TestGetDefaultSpectralOperationMap(unittest.TestCase):
    def test_int_float_second_operator_type(self):
        # Test behavior with second_operator_type as int and float
        for type_ in (int, float):
            with self.subTest(second_operator_type=type_):
                result = _get_default_spectral_operation_map(
                    operation=Operation.SUM,
                    second_operator_type=type_,
                    variables=["partial_fit", "absorbance"],
                    nu_vars=["nu"],
                    npoints_vars=["npoints"],
                )

                expected = {
                    Operation.PASSTHROUGH: ["nu", "npoints"],
                    Operation.SUM: ["partial_fit", "absorbance"],
                }

                for k, v in result.items():
                    self.assertEqual(set(expected[k]), set(v))

    def test_xrDataArray_xrDataset_second_operator_type(self):
        # Test behavior with second_operator_type as xr.DataArray and xr.Dataset
        for type_ in (xr.DataArray, xr.Dataset):
            with self.subTest(second_operator_type=type_):
                result = _get_default_spectral_operation_map(
                    operation=Operation.SUM,
                    second_operator_type=type_,
                    variables=["partial_fit", "absorbance"],
                    nu_vars=["nu"],
                    npoints_vars=["npoints"],
                )

                expected = {
                    Operation.UNION: ["nu"],
                    Operation.MINIMUM: ["npoints"],
                    Operation.SUM: ["partial_fit", "absorbance"],
                }

                for k, v in result.items():
                    self.assertEqual(set(expected[k]), set(v))

    def test_unsupported_second_operator_type(self):
        # Test behavior with an unsupported second_operator_type
        with self.assertRaises(NotImplementedError):
            _get_default_spectral_operation_map(
                operation=Operation.SUM,
                second_operator_type=dict,  # using dict as an unsupported type
                variables=["partial_fit", "absorbance"],
                nu_vars=["nu"],
                npoints_vars=["npoints"],
            )


class TestGetDefaultFitterOperationMap(unittest.TestCase):
    def test_supported_second_operator_types(self):
        # Test behavior with int, float, xr.DataArray, and xr.Dataset types
        for type_ in (int, float, xr.DataArray, xr.Dataset):
            with self.subTest(second_operator_type=type_):
                operation = (
                    Operation.ARITHMETIC_MEAN
                    if type_ in (int, float)
                    else Operation.UNION
                )
                result = _get_default_fitter_operation_map(
                    operation=operation,
                    second_operator_type=type_,
                    variables=["var1", "var2"],
                )

                expected = {operation: ["var1", "var2"]}

                for k, v in result.items():
                    self.assertEqual(set(expected[k]), set(v))

    def test_unsupported_second_operator_type(self):
        # Test behavior with an unsupported second_operator_type
        with self.assertRaises(NotImplementedError):
            _get_default_fitter_operation_map(
                operation=Operation.UNION,
                second_operator_type=dict,  # using dict as an unsupported type
                variables=["var1", "var2"],
            )


class TestFillOperationMapWithDefault(unittest.TestCase):
    def test_all_variables_present(self):
        operation_map = {
            Operation.UNION: ["var1", "var2"],
            Operation.INTERSECTION: ["var3"],
        }
        required_variables = ["var1", "var2", "var3"]

        result = _fill_operation_map_with_default(operation_map, required_variables)

        # No change should be made to the operation map\
        for k, v in result.items():
            self.assertEqual(set(operation_map[k]), set(v))

    def test_missing_variables_added(self):
        operation_map = {Operation.UNION: ["var1", "var2"]}
        required_variables = ["var1", "var2", "var3", "var4"]

        result = _fill_operation_map_with_default(operation_map, required_variables)

        expected = {
            Operation.UNION: [
                "var1",
                "var2",
                "var3",
                "var4",
            ]  # var3 and var4 should be added
        }

        for k, v in result.items():
            self.assertEqual(set(expected[k]), set(v))

    def test_empty_operation_map(self):
        # Test with an empty operation map
        operation_map = {}
        required_variables = ["var1", "var2"]

        result = _fill_operation_map_with_default(operation_map, required_variables)

        expected = {
            Operation.UNION: [
                "var1",
                "var2",
            ]  # All variables should be added with the default operation
        }

        for k, v in result.items():
            self.assertEqual(set(expected[k]), set(v))


class TestParseOperation(unittest.TestCase):
    def test_singular_operation_spectral(self):
        # Import the module to get a reference to the function
        from picarro_xarray.compute.spectral_operations import operations_mapping

        # Mocking the default spectral operation map function
        with patch.object(
            operations_mapping, "_get_default_spectral_operation_map"
        ) as mock_map_func:
            mock_map_func.return_value = {Operation.UNION: ["var1", "var2"]}

            result = parse_operation(
                operation=Operation.UNION,
                second_operator_type=int,
                is_spectral_operation=True,
                required_variables=["var1", "var2"],
                nu_vars=["nu"],
                npoints_vars=["npoints"],
            )

            # Check if the appropriate default map function was called
            mock_map_func.assert_called_once_with(
                operation=Operation.UNION,
                second_operator_type=int,
                variables=["var1", "var2"],
                nu_vars=["nu"],
                npoints_vars=["npoints"],
            )

            # Check the result
            expected = {Operation.UNION: ["var1", "var2"]}
            for k, v in result.items():
                self.assertEqual(set(expected[k]), set(v))

    def test_singular_operation_non_spectral(self):
        # Mocking the default fitter operation map function
        from picarro_xarray.compute.spectral_operations import operations_mapping

        with patch.object(
            operations_mapping, "_get_default_fitter_operation_map"
        ) as mock_map_func:
            mock_map_func.return_value = {Operation.INTERSECTION: ["var1", "var2"]}

            result = parse_operation(
                operation=Operation.INTERSECTION,
                second_operator_type=int,
                is_spectral_operation=False,
                required_variables=["var1", "var2"],
                nu_vars=[],  # These aren't used for non-spectral operations
                npoints_vars=[],
            )

            # Check if the appropriate default map function was called
            mock_map_func.assert_called_once_with(
                operation=Operation.INTERSECTION,
                second_operator_type=int,
                variables=["var1", "var2"],
            )

            # Check the result
            expected = {Operation.INTERSECTION: ["var1", "var2"]}
            for k, v in result.items():
                self.assertEqual(set(expected[k]), set(v))

    def test_dict_operation(self):
        # Mocking the function to fill the operation map with defaults
        from picarro_xarray.compute.spectral_operations import operations_mapping

        with patch.object(
            operations_mapping, "_fill_operation_map_with_default"
        ) as mock_fill_func:
            mock_fill_func.return_value = {
                Operation.UNION: ["var3"],
                Operation.INTERSECTION: ["var1", "var2"],
            }

            operation_dict = {Operation.INTERSECTION: ["var1", "var2"]}

            result = parse_operation(
                operation=operation_dict,
                second_operator_type=int,
                is_spectral_operation=True,
                required_variables=["var1", "var2", "var3"],
                nu_vars=["nu"],
                npoints_vars=["npoints"],
            )

            # Check if the fill function was called with the operation dict
            mock_fill_func.assert_called_once_with(
                operation_map=operation_dict,
                required_variables=["var1", "var2", "var3"],
                default_operation=Operation.UNION,
            )

            expected = {
                Operation.UNION: ["var3"],
                Operation.INTERSECTION: ["var1", "var2"],
            }
            for k, v in result.items():
                self.assertEqual(set(expected[k]), set(v))

    def test_unsupported_operation_type(self):
        # Testing with an unsupported operation type (not Operation or dict)
        with self.assertRaises(NotImplementedError):
            parse_operation(
                operation="unsupported_type",
                second_operator_type=int,
                is_spectral_operation=True,
                required_variables=["var1"],
                nu_vars=["nu"],
                npoints_vars=["npoints"],
            )
