import unittest
from typing import Callable
from unittest.mock import patch

import numpy as np
import pandas as pd
import pytest
import xarray as xr
from pydantic import ValidationError
from spectral_arithmetic.linear_least_squares import LinearLeastSquares, design_matrix

from picarro_xarray.compute.least_squares.least_squares_fitter import (
    bounded_fit_dataset,
    fit_dataset,
    ridge_fit_dataset,
)
from picarro_xarray.compute.least_squares.regular_least_squares import (
    _lsq_fit_single_spectrum,
    _nnlsq_fit_single_spectrum,
    lsq_fit_xarray,
)
from picarro_xarray.compute.least_squares.utils import (
    _extract_spectral_error,
    _filter_and_weight_spectral_data,
    _filter_dataset_modes,
    _validate_combo_dataset,
)
from picarro_xarray.data_models.constants import CID_DIM, MODE_DIM, TIME_DIM


class TestLsqFitSpectrum(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        mf = request.getfixturevalue("model_functions_harness")
        self.mf = mf

    def test_normal(self):
        lsq = LinearLeastSquares(self.mf)
        baseline_order = 2

        wavenumber = np.array([6001.0, 6002.0, 6003.0, 6004.0])
        spectrum = np.array([1.0, 2.0, 3.0, 4.0])
        fitter_mask = np.ones(len(lsq.get_results_keys(baseline_order)) - 1).astype(
            bool
        )  # drop rmse
        nu_center = wavenumber.mean()
        error = np.ones_like(spectrum)

        full_model_function_matrix = design_matrix(
            nu_array=wavenumber,
            model_functions=lsq.model_functions.funcs,
            nu_center=nu_center,
            baseline_order=baseline_order,
        )

        soln, _ = lsq.eval(
            nu_array=wavenumber,
            y_data=spectrum,
            y_err=error,
            nu_center=nu_center,
            baseline_order=baseline_order,
        )

        result = _lsq_fit_single_spectrum(
            model_function_matrix=full_model_function_matrix,
            spectrum=spectrum,
            error=error,
            fitter_var_mask=fitter_mask,
        )

        assert isinstance(result, np.ndarray)
        assert np.allclose(result, np.fromiter(soln.values(), dtype=float)[:-1])

        result_nnlsq = _nnlsq_fit_single_spectrum(
            model_function_matrix=full_model_function_matrix,
            spectrum=spectrum,
            error=error,
            fitter_var_mask=fitter_mask,
        )
        assert isinstance(result_nnlsq, np.ndarray)
        assert len(result_nnlsq) == len(result)

    def test_nans(self):
        lsq = LinearLeastSquares(self.mf)
        baseline_order = 2

        wavenumber = np.array([6001.0, 6002.0, 6003.0, 6004.0])
        spectrum = np.array([1.0, 2.0, 3.0, np.nan])
        fitter_mask = np.ones(len(lsq.get_results_keys(baseline_order)) - 1).astype(
            bool
        )  # drop rmse
        nu_center = wavenumber.mean()
        error = np.ones_like(spectrum)

        full_model_function_matrix = design_matrix(
            nu_array=wavenumber,
            model_functions=lsq.model_functions.funcs,
            nu_center=nu_center,
            baseline_order=baseline_order,
        )

        result = _lsq_fit_single_spectrum(
            model_function_matrix=full_model_function_matrix,
            spectrum=spectrum,
            error=error,
            fitter_var_mask=fitter_mask,
        )
        assert isinstance(result, np.ndarray)

        result_nnlsq = _nnlsq_fit_single_spectrum(
            model_function_matrix=full_model_function_matrix,
            spectrum=spectrum,
            error=error,
            fitter_var_mask=fitter_mask,
        )
        assert isinstance(result_nnlsq, np.ndarray)
        assert len(result_nnlsq) == len(result)


class TestLsqFitXarray(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        mf = request.getfixturevalue("model_functions_harness")
        combo_ds = request.getfixturevalue("combolog_ds")
        self.lsq = LinearLeastSquares(mf)
        self.wavenumber = combo_ds.sel(spectral_var="nu").spectral_values
        self.spectrum = combo_ds.sel(spectral_var="partial_fit").spectral_values
        self.error = 1 / combo_ds.sel(spectral_var="npoints").spectral_values
        self.nu_center = combo_ds.sel(fitter_var="a").fitter_values

    def test_success(self):
        mock_res = np.ones(
            (self.nu_center.sizes[TIME_DIM], len(self.lsq.get_results_keys()))
        )

        from picarro_xarray.compute.least_squares import regular_least_squares

        with patch.object(
            regular_least_squares,
            "_lsq_fit_time_block",
            return_value=mock_res,
        ) as mock_lsq_fit:
            res = lsq_fit_xarray(
                spectrum=self.spectrum,
                spectrum_error=self.error,
                wavenumber=self.wavenumber,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
                baseline_order=1,
            )
            assert isinstance(res, xr.DataArray)
            assert isinstance(mock_lsq_fit.call_args.kwargs["solver"], Callable)

            res = lsq_fit_xarray(
                spectrum=self.spectrum,
                spectrum_error=self.error,
                wavenumber=self.wavenumber,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
                baseline_order=1,
                positive=True,
            )
            assert isinstance(res, xr.DataArray)
            assert isinstance(mock_lsq_fit.call_args.kwargs["solver"], Callable)

    def test_arguments(self):
        with self.assertRaises(ValidationError):
            lsq_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=self.wavenumber,
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=123,
            )

        with self.assertRaises(ValidationError):
            lsq_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=self.wavenumber,
                spectrum_error=self.error,
                nu_center=self.nu_center.rename({TIME_DIM: "abc"}),
                lsq_fitter=self.lsq,
            )

        with self.assertRaises(ValidationError):
            lsq_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=self.wavenumber,
                spectrum_error="123",
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
            )

        with self.assertRaises(ValidationError):
            lsq_fit_xarray(
                spectrum=123,
                wavenumber=self.wavenumber,
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
            )

        with self.assertRaises(ValidationError):
            lsq_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=np.array([1, 2, 3]),
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
            )

        with self.assertRaises(ValidationError):
            lsq_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=np.array([1, 2, 3]),
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
                baseline_order="abc",
            )

        with self.assertRaises(ValidationError):
            lsq_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=np.array([1, 2, 3]),
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
                positive=10,
            )


class TestFitDataset(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        mf = request.getfixturevalue("model_functions_harness")
        self.combo_ds = request.getfixturevalue("combolog_ds")
        self.lsq = LinearLeastSquares(mf)
        out_keys = self.lsq.get_results_keys(baseline_order=1)[:-1]
        ncids = len(out_keys)
        self.mf_matrix = pd.DataFrame(
            data=np.random.rand(self.combo_ds.sizes[MODE_DIM], ncids),
            columns=out_keys,
        ).values

    def test_success(self):
        fit_functions = [fit_dataset, bounded_fit_dataset, ridge_fit_dataset]

        from picarro_xarray.compute.least_squares import block_fitter

        with patch.object(block_fitter, "design_matrix", return_value=self.mf_matrix):
            for fit_func in fit_functions:
                res = fit_func(
                    dataset=self.combo_ds,
                    lsq_fitter=self.lsq,
                    nu_key="nu",
                    spectrum_key="partial_fit",
                    nu_center_key="a",
                )
                assert isinstance(res, xr.DataArray)
                assert TIME_DIM in res.dims

                res = fit_func(
                    dataset=self.combo_ds.chunk({TIME_DIM: 1}),
                    lsq_fitter=self.lsq,
                    nu_key="nu",
                    spectrum_key="partial_fit",
                    nu_center_key="a",
                )
                assert isinstance(res, xr.DataArray)
                assert TIME_DIM in res.dims

    def test_failure_fast(self):
        # fast argument is deprecated in 0.0.17
        with self.assertRaises(ValidationError):
            fit_dataset(
                dataset=self.combo_ds,
                lsq_fitter=self.lsq,
                nu_key="nu",
                spectrum_key="partial_fit",
                nu_center_key="a",
                fast=True,
            )

        with self.assertRaises(ValidationError):
            fit_dataset(
                dataset=self.combo_ds.chunk({TIME_DIM: 1}),
                lsq_fitter=self.lsq,
                nu_key="nu",
                spectrum_key="partial_fit",
                nu_center_key="a",
                fast=True,
            )

    def test_empty(self):
        combo_use = self.combo_ds.copy(deep=True)
        combo_use["spectral_values"] = combo_use.spectral_values.where(False, np.nan)

        with self.assertRaises(ValueError):
            fit_dataset(
                dataset=combo_use.chunk({TIME_DIM: 1}),
                lsq_fitter=self.lsq,
                nu_key="nu",
                spectrum_key="partial_fit",
                nu_center_key="a",
            )

    def test_no_combolog(self):
        with self.assertRaises(ValueError):
            fit_dataset(
                dataset=self.combo_ds.rename({"fitter_var": "fitter_var2"}),
                lsq_fitter=self.lsq,
                nu_key="nu",
                spectrum_key="partial_fit",
                nu_center_key="a",
                npoints_key="npoints",
            )

    def test_no_timeseries(self):
        with self.assertRaises(ValueError):
            fit_dataset(
                dataset=self.combo_ds.rename({TIME_DIM: "time2"}),
                lsq_fitter=self.lsq,
                nu_key="nu",
                spectrum_key="partial_fit",
                nu_center_key="a",
                npoints_key="npoints",
            )

    def test_wrong_fitter(self):
        with self.assertRaises(ValueError):
            fit_dataset(
                dataset=self.combo_ds,
                lsq_fitter=123,
                nu_key="nu",
                spectrum_key="partial_fit",
                nu_center_key="a",
                npoints_key="npoints",
            )

    def test_fails_fitter_var_check(self):
        fit_functions = [fit_dataset, bounded_fit_dataset, ridge_fit_dataset]
        correct_keys = self.lsq.get_results_keys(baseline_order=1)[:-1]

        mask = xr.DataArray(
            1,
            dims=[TIME_DIM, CID_DIM],
            coords={
                TIME_DIM: self.combo_ds[TIME_DIM],
                CID_DIM: np.arange(len(correct_keys)).astype(str),
            },
        )
        for fit_func in fit_functions:
            with self.assertRaises(ValueError):
                fit_func(
                    dataset=self.combo_ds,
                    lsq_fitter=self.lsq,
                    cid_fitter_mask=mask,
                    nu_key="nu",
                    spectrum_key="partial_fit",
                    nu_center_key="a",
                    npoints_key="npoints",
                )


class TestValidateComboDataset(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        mf = request.getfixturevalue("model_functions_harness")
        self.combo_ds = request.getfixturevalue("combolog_ds")
        self.lsq = LinearLeastSquares(mf)

    def test_spectral_keys_arguments(self):
        with self.assertRaises(ValueError):
            _validate_combo_dataset(
                dataset=self.combo_ds,
                spectral_keys=["partial_fitsssss", "nu", "npoints"],
                fitter_keys=["a"],
            )

        with self.assertRaises(ValueError):
            _validate_combo_dataset(
                dataset=self.combo_ds,
                spectral_keys=["partial_fit", "nussss", "npoints"],
                fitter_keys=["a"],
            )

    def test_fitter_keys_arguments(self):
        with self.assertRaises(ValueError):
            _validate_combo_dataset(
                dataset=self.combo_ds,
                spectral_keys=["partial_fit", "nu", "npoints"],
                fitter_keys=["abcdef"],
            )


class TestFilterDatasetModes(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        mf = request.getfixturevalue("model_functions_harness")
        self.combo_ds = request.getfixturevalue("combolog_ds")
        self.lsq = LinearLeastSquares(mf)

    def test_empty(self):
        combo_use = self.combo_ds.copy(deep=True)
        combo_use["spectral_values"] = combo_use.spectral_values.where(False, np.nan)

        res = _filter_dataset_modes(
            dataset=combo_use.chunk({TIME_DIM: 1}),
            spectrum_key="partial_fit",
        )

        assert isinstance(res, xr.Dataset)
        assert res.sizes[MODE_DIM] == 0

    def test_full(self):
        res = _filter_dataset_modes(
            dataset=self.combo_ds,
            spectrum_key="partial_fit",
        )

        assert isinstance(res, xr.Dataset)
        assert res.sizes[MODE_DIM] == self.combo_ds.sizes[MODE_DIM]


class TestExtractSpectralError(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.combo_ds = request.getfixturevalue("combolog_ds")
        self.compact_ds = request.getfixturevalue("compat_dataset")

    def test_success_combo(self):
        res = _extract_spectral_error(
            dataset=self.combo_ds,
            spectrum_key="partial_fit",
            npoints_key="npoints",
            error_statistic_key="std_err",
        )
        assert isinstance(res, xr.DataArray)
        assert res.sizes[TIME_DIM] == self.combo_ds.sizes[TIME_DIM]
        assert MODE_DIM in res.dims
        assert res.equals(
            np.sqrt(1 / self.combo_ds.sel(spectral_var="npoints").spectral_values)
        )

    def test_success_compact(self):
        res = _extract_spectral_error(
            dataset=self.compact_ds,
            spectrum_key="partial_fit",
            npoints_key="npoints",
            error_statistic_key="std_err",
        )
        assert isinstance(res, xr.DataArray)
        assert res.sizes[TIME_DIM] == self.compact_ds.sizes[TIME_DIM]
        assert MODE_DIM in res.dims
        assert res.equals(
            self.compact_ds.sel(
                spectral_var="partial_fit", stat="std_err"
            ).spectral_values_stats
        )


class TestFilterAndWeightSpectralData(unittest.TestCase):
    def test_all_valid(self):
        n_modes = 15
        n_cids = 5
        spectra = 1 + np.random.rand(n_modes)
        errors = np.ones(n_modes)
        mf_matrix = np.random.rand(n_modes, n_cids)

        weighted_mf, weighted_s = _filter_and_weight_spectral_data(
            spectrum=spectra,
            error=errors,
            model_function_matrix=mf_matrix,
        )
        assert isinstance(weighted_mf, np.ndarray)
        assert isinstance(weighted_s, np.ndarray)
        assert weighted_mf.shape == mf_matrix.shape
        assert weighted_s.shape == spectra.shape
        assert np.allclose(weighted_s, spectra)
        assert np.allclose(weighted_mf, mf_matrix)

    def test_half_weight(self):
        n_modes = 15
        n_cids = 5
        spectra = 1 + np.random.rand(n_modes)
        errors = 2 * np.ones(n_modes)
        mf_matrix = np.random.rand(n_modes, n_cids)

        weighted_mf, weighted_s = _filter_and_weight_spectral_data(
            spectrum=spectra,
            error=errors,
            model_function_matrix=mf_matrix,
        )
        assert isinstance(weighted_mf, np.ndarray)
        assert isinstance(weighted_s, np.ndarray)
        assert weighted_mf.shape == mf_matrix.shape
        assert weighted_s.shape == spectra.shape
        assert np.allclose(weighted_s, spectra / 2)
        assert np.allclose(weighted_mf, mf_matrix / 2)

    def test_error_zero(self):
        n_modes = 15
        n_cids = 5
        spectra = 1 + np.random.rand(n_modes)
        errors = np.ones(n_modes)
        errors[-1] = 0
        mf_matrix = np.random.rand(n_modes, n_cids)

        weighted_mf, weighted_s = _filter_and_weight_spectral_data(
            spectrum=spectra,
            error=errors,
            model_function_matrix=mf_matrix,
        )
        assert isinstance(weighted_mf, np.ndarray)
        assert isinstance(weighted_s, np.ndarray)
        assert weighted_mf.shape[0] == mf_matrix.shape[0] - 1
        assert weighted_mf.shape[1] == mf_matrix.shape[1]
        assert weighted_s.shape[0] == spectra.shape[0] - 1

    def test_spectrum_nan(self):
        n_modes = 15
        n_cids = 5
        spectra = 1 + np.random.rand(n_modes)
        errors = np.ones(n_modes)
        spectra[-5:] = np.nan
        mf_matrix = np.random.rand(n_modes, n_cids)

        weighted_mf, weighted_s = _filter_and_weight_spectral_data(
            spectrum=spectra,
            error=errors,
            model_function_matrix=mf_matrix,
        )
        assert isinstance(weighted_mf, np.ndarray)
        assert isinstance(weighted_s, np.ndarray)
        assert weighted_mf.shape[0] == mf_matrix.shape[0] - 5
        assert weighted_mf.shape[1] == mf_matrix.shape[1]
        assert weighted_s.shape[0] == spectra.shape[0] - 5


class TestFitDatasetAccessor(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        import picarro_xarray.accessors.refit_accessor  # noqa

        mf = request.getfixturevalue("model_functions_harness")
        self.combo_ds = request.getfixturevalue("combolog_ds")
        self.lsq = LinearLeastSquares(mf)
        out_keys = self.lsq.get_results_keys(baseline_order=1)[:-1]
        ncids = len(out_keys)
        np.random.seed(42)
        self.mf_matrix = pd.DataFrame(
            data=np.random.rand(self.combo_ds.sizes[MODE_DIM], ncids),
            columns=out_keys,
        ).values

        self.cid_fitter_mask = xr.DataArray(
            data=np.random.randint(0, 2, (self.combo_ds.sizes[TIME_DIM], ncids)),
            dims=[TIME_DIM, CID_DIM],
            coords={
                TIME_DIM: self.combo_ds[TIME_DIM],
                CID_DIM: out_keys,
            },
        )

    def test_accessor_fails_dims(self):
        ds = self.combo_ds.copy(deep=True).rename({"mode": "mode2"})
        with pytest.raises(TypeError):
            ds.refit.llsq()

        ds = self.combo_ds.copy(deep=True).rename({"_datetime": "time2"})
        with pytest.raises(TypeError):
            ds.refit.llsq()

        ds = self.combo_ds.copy(deep=True).rename({"fitter_var": "fitter_var2"})
        with pytest.raises(TypeError):
            ds.refit.llsq()

        ds = self.combo_ds.copy(deep=True).rename({"spectral_var": "spectral_var2"})
        with pytest.raises(TypeError):
            ds.refit.llsq()

    def test_fit_dataset(self):
        from picarro_xarray.compute.least_squares import block_fitter

        with patch.object(block_fitter, "design_matrix", return_value=self.mf_matrix):
            res = self.combo_ds.refit.llsq(lsq=self.lsq)
            assert isinstance(res, xr.DataArray)
            assert TIME_DIM in res.dims

            res = self.combo_ds.refit.llsq(lsq=self.lsq, positive=True)
            assert isinstance(res, xr.DataArray)
            assert TIME_DIM in res.dims
            assert np.all(res >= 0)

            res = self.combo_ds.refit.llsq(
                lsq=self.lsq, cid_fitter_mask=self.cid_fitter_mask
            )
            assert isinstance(res, xr.DataArray)
            assert TIME_DIM in res.dims
            assert CID_DIM in res.dims

    def test_bounded_lsq(self):
        from picarro_xarray.compute.least_squares import block_fitter

        with patch.object(block_fitter, "design_matrix", return_value=self.mf_matrix):
            res = self.combo_ds.refit.bounded_llsq(lsq=self.lsq)
            assert isinstance(res, xr.DataArray)
            assert TIME_DIM in res.dims

            key1 = self.lsq.cid_list[0]  # 101
            gc1 = f"{self.lsq.prefix}_gasConcs_{key1}"
            lb, ub = 0, 1
            concs = res.sel(fitter_var=gc1).values

            # check that the bounds are not applied
            assert not np.all((concs >= lb) & (concs <= ub))

            bounds = {int(key1): (lb, ub)}
            res = self.combo_ds.refit.bounded_llsq(lsq=self.lsq, bounds=bounds)
            assert isinstance(res, xr.DataArray)
            assert TIME_DIM in res.dims
            concs = res.sel(fitter_var=gc1).values

            # check that the bounds are applied
            assert np.all((concs >= lb) & (concs <= ub))

    def test_ridge_refit(self):
        from picarro_xarray.compute.least_squares import block_fitter

        with patch.object(block_fitter, "design_matrix", return_value=self.mf_matrix):
            res = self.combo_ds.refit.ridge(lsq=self.lsq)
            assert isinstance(res, xr.DataArray)
            assert TIME_DIM in res.dims

            res = self.combo_ds.refit.ridge(lsq=self.lsq, method="hkb")
            assert isinstance(res, xr.DataArray)
            assert TIME_DIM in res.dims

            res = self.combo_ds.refit.ridge(
                lsq=self.lsq, method="hkb", baseline_order=1
            )
            assert isinstance(res, xr.DataArray)
            assert TIME_DIM in res.dims

            res = self.combo_ds.refit.ridge(
                lsq=self.lsq, method="hkb", baseline_order=1
            )
            assert isinstance(res, xr.DataArray)
            assert TIME_DIM in res.dims
