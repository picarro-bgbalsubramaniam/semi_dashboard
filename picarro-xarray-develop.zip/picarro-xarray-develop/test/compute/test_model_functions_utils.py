import unittest

import numpy as np
import pandas as pd
from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from picarro_xarray.compute.least_squares.model_functions_utils import (
    _create_static_model_function,
    _create_static_model_functions,
    get_static_least_squares_fitter,
)


class TestModelFunctionsUtils(unittest.TestCase):
    def setUp(self):
        nu_values = np.linspace(1000, 1010, 11)
        mfs = {101: np.sin(nu_values), 202: np.cos(nu_values)}
        self.model_function_matrix = pd.DataFrame(data=mfs, index=nu_values)
        self.cids = list(mfs.keys())

    def test_get_static_least_squares_fitter(self):
        # test straightfoward working case
        lsq = get_static_least_squares_fitter(
            model_function_matrix=self.model_function_matrix, cids=self.cids
        )
        self.assertIsInstance(lsq, LinearLeastSquares)
        self.assertEqual(len(lsq.model_functions.funcs), 2)
        self.assertTrue(callable(lsq.model_functions.funcs[self.cids[0]]))

    def test_create_static_model_functions(self):
        static_mf = _create_static_model_functions(
            model_function_matrix=self.model_function_matrix, cids=self.cids
        )
        self.assertEqual(len(static_mf), 2)

        for cid in self.cids:
            self.assertIn(cid, static_mf)
            self.assertTrue(callable(static_mf[cid]))

    def test_create_static_model_function(self):
        cid = self.cids[0]
        cid_absorbance = self.model_function_matrix[cid]
        static_func = _create_static_model_function(
            cid_absorbance=cid_absorbance, nu_tol=1e-2
        )

        # Test with values within the range with a small offset
        test_nu = self.model_function_matrix.index.values
        test_nu = test_nu + 1e-6 * np.random.randn(len(test_nu))

        result = static_func(test_nu)
        expected = np.sin(test_nu)
        np.testing.assert_allclose(result, expected, atol=1e-3)

        # Test with a value outside the range
        test_nu_outside = np.array([999.0])
        result_outside = static_func(test_nu_outside)
        self.assertTrue(np.isnan(result_outside[0]))

    def test_create_static_model_function_tolerance(self):
        cid = self.cids[0]
        cid_absorbance = self.model_function_matrix[cid]
        static_func = _create_static_model_function(cid_absorbance, nu_tol=0.1)

        # Test with a value below tolerance
        test_nu = np.array([1000.05])
        result = static_func(test_nu)
        self.assertFalse(np.isnan(result[0]))

        # Test with a value outside the tolerance
        test_nu_outside_tol = np.array([1000.2])
        result_outside_tol = static_func(test_nu_outside_tol)
        self.assertTrue(np.isnan(result_outside_tol[0]))
