import unittest
from typing import Callable
from unittest.mock import Mock, patch

import numpy as np
import pytest
import xarray as xr
from pydantic import ValidationError
from sklearn.datasets import make_regression
from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from picarro_xarray.compute.least_squares.ridge_regression import (
    _ridge_fit_single_spectrum,
    ridge_fit_xarray,
)
from picarro_xarray.data_models.constants import CID_DIM, TIME_DIM


class TestRidgeFitSingleSpectrum(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        X, y = make_regression(n_samples=100, n_features=5, random_state=0)
        self.X = X
        self.spectrum = y
        self.error = np.ones_like(y)
        self.fitter_mask = np.ones(X.shape[1]).astype(bool)

    def test_small_regularization(self):
        from scipy.linalg import lstsq

        result = lstsq(self.X, self.spectrum)[0]

        result_ridge = _ridge_fit_single_spectrum(
            model_function_matrix=self.X,
            spectrum=self.spectrum,
            error=self.error,
            fitter_var_mask=self.fitter_mask,
            method=lambda X,
            y: 1e-8,  # small regularization, results very similar to ols
        )

        assert isinstance(result_ridge, np.ndarray)

        # coefs should be similar for small regularization
        assert np.allclose(result_ridge, result)

    def test_large_regularization(self):
        from scipy.linalg import lstsq

        result = lstsq(self.X, self.spectrum)[0]

        result_ridge = _ridge_fit_single_spectrum(
            model_function_matrix=self.X,
            spectrum=self.spectrum,
            error=self.error,
            fitter_var_mask=self.fitter_mask,
            method=lambda X,
            y: 1000,  # small regularization, results very similar to ols
        )

        assert isinstance(result_ridge, np.ndarray)

        # coefs should be smaller than ols
        assert np.all(abs(result_ridge) < abs(result))

    def test_regularization_kwargs(self):
        # test kwargs propagated to `method`
        mock_method = Mock(return_value=13)

        result_ridge = _ridge_fit_single_spectrum(
            model_function_matrix=self.X,
            spectrum=self.spectrum,
            error=self.error,
            fitter_var_mask=self.fitter_mask,
            method=mock_method,
            c=1,
        )

        assert isinstance(result_ridge, np.ndarray)
        mock_method.assert_called_once()
        assert mock_method.call_args.kwargs["c"] == 1

    def test_dynamic_fitting(self):
        fitter_mask = self.fitter_mask.copy()
        fitter_mask[-1] = False

        result_ridge = _ridge_fit_single_spectrum(
            model_function_matrix=self.X,
            spectrum=self.spectrum,
            error=self.error,
            fitter_var_mask=fitter_mask,
            method=lambda X,
            y: 1e-8,  # small regularization, results very similar to ols
        )
        assert isinstance(result_ridge, np.ndarray)
        assert len(result_ridge) == self.X.shape[1]
        assert np.isnan(result_ridge[-1])
        assert np.all(result_ridge[:-1] >= 0)


class TestRidgeFitXarray(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        mf = request.getfixturevalue("model_functions_harness")
        combo_ds = request.getfixturevalue("combolog_ds")
        self.lsq = LinearLeastSquares(mf)
        self.wavenumber = combo_ds.sel(spectral_var="nu").spectral_values
        self.spectrum = combo_ds.sel(spectral_var="partial_fit").spectral_values
        self.error = 1 / combo_ds.sel(spectral_var="npoints").spectral_values
        self.nu_center = combo_ds.sel(fitter_var="a").fitter_values

    def test_success(self):
        mock_res = np.ones(
            (self.nu_center.sizes[TIME_DIM], len(self.lsq.get_results_keys()))
        )
        from picarro_xarray.compute.least_squares import ridge_regression

        with patch.object(
            ridge_regression,
            "_lsq_fit_time_block",
            return_value=mock_res,
        ) as mock_lsq_fit:
            res = ridge_fit_xarray(
                spectrum=self.spectrum,
                spectrum_error=self.error,
                wavenumber=self.wavenumber,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
                baseline_order=1,
                method="cross_validate_opt",
            )
            assert isinstance(res, xr.DataArray)
            assert isinstance(mock_lsq_fit.call_args.kwargs["solver"], Callable)
            assert mock_lsq_fit.call_args.kwargs["method"] == "cross_validate_opt"

    def test_wrong_fitter_mask(self):
        output_keys = self.lsq.get_results_keys(baseline_order=1)[:-1]
        time_dim = TIME_DIM

        cid_fitter_mask = xr.DataArray(
            np.full(
                shape=(self.spectrum.sizes[TIME_DIM], len(output_keys)), fill_value=True
            ),
            dims=[time_dim, CID_DIM],
            coords={
                TIME_DIM: self.spectrum[TIME_DIM].values,
                CID_DIM: ["a" for _ in output_keys],
            },
        )

        with pytest.raises(ValueError):
            ridge_fit_xarray(
                spectrum=self.spectrum,
                spectrum_error=self.error,
                wavenumber=self.wavenumber,
                nu_center=self.nu_center,
                cid_fitter_mask=cid_fitter_mask,
                lsq_fitter=self.lsq,
                baseline_order=1,
            )

    def test_arguments(self):
        with self.assertRaises(ValidationError):
            ridge_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=self.wavenumber,
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=123,
            )

        with self.assertRaises(ValidationError):
            ridge_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=self.wavenumber,
                spectrum_error=self.error,
                nu_center=self.nu_center.rename({TIME_DIM: "abc"}),
                lsq_fitter=self.lsq,
            )

        with self.assertRaises(ValidationError):
            ridge_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=self.wavenumber,
                spectrum_error="123",
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
            )

        with self.assertRaises(ValidationError):
            ridge_fit_xarray(
                spectrum=123,
                wavenumber=self.wavenumber,
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
            )

        with self.assertRaises(ValidationError):
            ridge_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=np.array([1, 2, 3]),
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
            )

        with self.assertRaises(ValidationError):
            ridge_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=np.array([1, 2, 3]),
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
                baseline_order="abc",
            )

        with self.assertRaises(ValidationError):
            ridge_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=np.array([1, 2, 3]),
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
                method=10,
            )
