import unittest

import pytest
import xarray as xr
from pydantic import ValidationError

from picarro_xarray.compute.detection_limits import (
    get_limits_of_detection,
    limits_of_detection,
)


class TestGetLimitsOfDetection(unittest.TestCase):
    def test_valid_input(self):
        sigma_tau = xr.DataArray(10).assign_coords(tau_scaled=5, tau=1, n_samples=1)
        with self.assertRaises(NotImplementedError):
            get_limits_of_detection(
                sigma_tau, averaging_time_seconds=100, sigma_confidence_level=1
            )

    def test_with_optional_parameters(self):
        sigma_tau = xr.DataArray(10).assign_coords(tau_scaled=1, tau=1, n_samples=1)
        with self.assertRaises(NotImplementedError):
            get_limits_of_detection(
                sigma_tau, averaging_time_seconds=100, sigma_confidence_level=1
            )

    def test_arguments(self):
        sigma_tau = xr.DataArray(10).assign_coords(tau_scaled=1, tau=1, n_samples=1)
        with self.assertRaises(ValidationError):
            get_limits_of_detection(
                sigma_tau, averaging_time_seconds=0, sigma_confidence_level=1
            )

        with self.assertRaises(ValidationError):
            get_limits_of_detection(
                sigma_tau, averaging_time_seconds=10, sigma_confidence_level=-1
            )

        with self.assertRaises(ValidationError):
            get_limits_of_detection(
                "abc",
                averaging_time_seconds=10,
                sigma_confidence_level=1,
            )

        with self.assertRaises(ValidationError):
            get_limits_of_detection(sigma_tau.drop_vars("tau"))


class TestLimitsOfDetection(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        self.ds = ds

    def test_ds(self):
        res = limits_of_detection(
            data=self.ds,
            transition_variable="group_this",
            reference_value=0,
            averaging_time_seconds=100,
            sigma_confidence_level=3,
        )
        assert isinstance(res, xr.Dataset)
        assert "fitter_var" in res.dims
        assert "mode" in res.dims
        assert "spectral_var" in res.dims
        assert "_datetime" not in res.dims

    def test_da(self):
        res = limits_of_detection(
            data=self.ds.sel(fitter_var=["a", "b"]).fitter_values,
            transition_variable=self.ds.fitter_values.sel(fitter_var="group_this"),
            reference_value=0,
            averaging_time_seconds=100,
            sigma_confidence_level=3,
        )
        assert isinstance(res, xr.DataArray)
        assert "fitter_var" in res.dims
        assert "_datetime" not in res.dims

    def test_ds_no_avg(self):
        res = limits_of_detection(
            data=self.ds,
            transition_variable="group_this",
            reference_value=0,
            averaging_time_seconds=None,
            sigma_confidence_level=3,
        )
        assert isinstance(res, xr.Dataset)
        assert "fitter_var" in res.dims
        assert "mode" in res.dims
        assert "spectral_var" in res.dims
        assert "_datetime" not in res.dims

    def test_da_no_avg(self):
        res = limits_of_detection(
            data=self.ds.sel(fitter_var=["a", "b"]).fitter_values,
            transition_variable=self.ds.fitter_values.sel(fitter_var="group_this"),
            reference_value=0,
            averaging_time_seconds=None,
            sigma_confidence_level=3,
        )
        assert isinstance(res, xr.DataArray)
        assert "fitter_var" in res.dims
        assert "_datetime" not in res.dims
