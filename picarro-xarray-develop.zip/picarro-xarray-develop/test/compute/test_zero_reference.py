import unittest

import numpy as np
import pytest
import xarray as xr
from pydantic import ValidationError

from picarro_xarray.compute.zero_reference import (
    _drop_non_dim_coords,
    _filter_passthrough_variables,
    get_contiguous_group_averages,
    get_interpolated_data,
    get_reference_transitions_uid,
    get_transition_uid,
    get_zero_referenced_data,
    perform_zero_referencing,
    propagate_reference_value,
)
from picarro_xarray.data_models.constants import CID_DIM, MODE_DIM, TIME_DIM


class TestGetTransitionUid(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds = request.getfixturevalue("combolog_ds")
        self.transition_data = self.ds.fitter_values.sel(fitter_var="group_this")

    def test_arguments(self):
        da = self.transition_data
        da = da.rename({"_datetime": "some_time"})

        with pytest.raises(ValidationError):
            get_transition_uid(da)

        with pytest.raises(ValidationError):
            get_transition_uid(1)

    def test_success(self):
        res = get_transition_uid(self.transition_data)
        assert isinstance(res, xr.DataArray)
        assert res.sizes["_datetime"] == self.ds.fitter_values.sizes["_datetime"]

    def test_success_chunked(self):
        da = self.transition_data.chunk({"_datetime": 1})
        res = get_transition_uid(da)
        assert isinstance(res, xr.DataArray)
        assert res.sizes["_datetime"] == self.ds.fitter_values.sizes["_datetime"]


class TestGetReferenceTransitionsUID(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds = request.getfixturevalue("combolog_ds")
        self.transition_data = self.ds.fitter_values.sel(fitter_var="group_this")

    def test_arguments(self):
        da = self.transition_data

        with pytest.raises(ValidationError):
            get_reference_transitions_uid(1, 100)

        with pytest.raises(ValidationError):
            get_reference_transitions_uid(da, np.array([1, 2, 3]))

        da = da.rename({"_datetime": "some_time"})

        with pytest.raises(ValidationError):
            get_reference_transitions_uid(da, 100)

    def test_success(self):
        res = get_reference_transitions_uid(self.transition_data, 1)
        assert isinstance(res, xr.DataArray)
        assert "_datetime" in res.dims
        assert res.sizes["_datetime"] <= self.transition_data.sizes["_datetime"]

    def test_raise_empty(self):
        with self.assertRaises(ValueError):
            get_reference_transitions_uid(self.transition_data, 123456)

    def test_success_chunked(self):
        da = self.transition_data.chunk({"_datetime": 1})
        res = get_reference_transitions_uid(da, reference_value=1)
        assert isinstance(res, xr.DataArray)
        assert res.sizes["_datetime"] < self.ds.fitter_values.sizes["_datetime"]


class TestGetContiguousGroupAverages(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds = request.getfixturevalue("combolog_ds")
        self.grouper = get_reference_transitions_uid(
            self.ds.fitter_values.sel(fitter_var="group_this"),
            reference_value=0,
        )

    def test_arguments(self):
        da = self.ds.fitter_values

        with pytest.raises(ValidationError):
            get_contiguous_group_averages(1, self.grouper)

        with pytest.raises(ValidationError):
            get_contiguous_group_averages(da, 1)

        grouper_change = self.grouper.rename({"_datetime": "some_time"})

        with pytest.raises(ValidationError):
            get_contiguous_group_averages(da, grouper_change)

        da = da.rename({"_datetime": "some_time"})

        with pytest.raises(ValidationError):
            get_contiguous_group_averages(da, self.grouper)

    def test_success_mean(self):
        res = get_contiguous_group_averages(
            data=self.ds.fitter_values,
            grouper_da=self.grouper,
            data_aggregation="mean",
        )
        assert isinstance(res, xr.DataArray)
        assert "_datetime" in res.dims
        assert res.sizes["_datetime"] <= self.ds.fitter_values.sizes["_datetime"]

    def test_success_median(self):
        res = get_contiguous_group_averages(
            data=self.ds.fitter_values,
            grouper_da=self.grouper,
            data_aggregation="median",
        )
        assert isinstance(res, xr.DataArray)
        assert "_datetime" in res.dims
        assert res.sizes["_datetime"] <= self.ds.fitter_values.sizes["_datetime"]

    def test_success_chunked(self):
        da = self.ds.fitter_values.chunk({"_datetime": 1})
        res = get_contiguous_group_averages(
            data=da,
            grouper_da=self.grouper,
        )
        assert isinstance(res, xr.DataArray)
        assert "_datetime" in res.dims
        assert res.sizes["_datetime"] <= self.ds.fitter_values.sizes["_datetime"]

    def test_success_flox(self):
        """
        Test that using flox.xarray_reduce produces results equivalent to
        xarray's built-in groupby aggregation for both nanmedian and nanmean, on both
        unchunked and chunked DataArrays/Datasets.

        This ensures that the new flox-based reduction is a drop-in replacement for
        xarray's groupby().mean(skipna=True) and groupby().median(skipna=True) in all
        relevant cases.
        """
        from flox.xarray import xarray_reduce

        grouper_da = self.grouper
        grouper_da.name = "group"

        reference_data = self.ds.sel({TIME_DIM: grouper_da[TIME_DIM].values})
        reference_data = reference_data[["spectral_values", "fitter_values"]]
        classes = np.unique(grouper_da)

        for func in ["nanmedian", "nanmean"]:
            # Unchunked
            reference_flox = xarray_reduce(
                reference_data,
                grouper_da,
                func=func,
                method="blockwise",
                expected_groups=classes,
            )
            reference_xarray = getattr(
                reference_data.groupby(grouper_da), func.replace("nan", "")
            )(skipna=True)
            xr.testing.assert_allclose(reference_flox, reference_xarray)

            # Chunked
            chunked_data = reference_data.chunk({TIME_DIM: 5, CID_DIM: 2, MODE_DIM: 5})
            reference_flox = xarray_reduce(
                chunked_data,
                grouper_da,
                func=func,
                method="blockwise",
                expected_groups=classes,
            )
            reference_xarray = getattr(
                chunked_data.groupby(grouper_da), func.replace("nan", "")
            )(skipna=True)
            xr.testing.assert_allclose(reference_flox, reference_xarray)


class TestGetInterpolatedData(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        self.da = ds.fitter_values
        ref_uid = get_reference_transitions_uid(
            transition_variable_data=self.da.sel(fitter_var="group_this"),
            reference_value=0,
        )
        ref_data = get_contiguous_group_averages(data=self.da, grouper_da=ref_uid)
        ref_roll = (
            ref_data.rolling({TIME_DIM: 5}, center=True, min_periods=1)
            .construct("win")
            .mean("win")
        )
        self.ref_data = ref_roll

    def test_arguments(self):
        with pytest.raises(ValidationError):
            get_interpolated_data(data=self.ref_data, datetime_eval=np.array([1, 2, 3]))

        with pytest.raises(ValidationError):
            get_interpolated_data(data="abc", datetime_eval=self.da["_datetime"])

        with pytest.raises(ValidationError):
            get_interpolated_data("abc", datetime_eval=1)

        da = self.da["_datetime"].rename({"_datetime": "some_time"})

        with pytest.raises(ValidationError):
            get_interpolated_data(data=self.ref_data, datetime_eval=da)

        with pytest.raises(ValidationError):
            get_interpolated_data(
                data=self.ref_data.rename({"_datetime": "my_dt"}),
                datetime_eval=self.da["_datetime"],
            )

    def test_success(self):
        res = get_interpolated_data(
            data=self.ref_data,
            datetime_eval=self.da["_datetime"],
        )
        assert isinstance(res, xr.DataArray)
        assert "_datetime" in res.dims
        assert res.sizes["_datetime"] == self.da.sizes["_datetime"]

    def test_success_chunked(self):
        data = self.ref_data.chunk({"_datetime": 1})
        res = get_interpolated_data(
            data=data,
            datetime_eval=self.da["_datetime"],
        )
        assert isinstance(res, xr.DataArray)
        assert "_datetime" in res.dims
        assert res.sizes["_datetime"] == self.da.sizes["_datetime"]


class TestPerformZeroReferencing(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        self.da = ds.fitter_values

    def test_arguments(self):
        with pytest.raises(ValidationError):
            perform_zero_referencing(data=self.da, zero_reference_data="abc")

        with pytest.raises(ValidationError):
            perform_zero_referencing(data="abc", zero_reference_data=self.da)

        da = self.da.rename({"_datetime": "some_time"})

        with pytest.raises(ValidationError):
            perform_zero_referencing(data=da, zero_reference_data=self.da)

        with pytest.raises(ValidationError):
            perform_zero_referencing(data=self.da, zero_reference_data=da)

    def test_success(self):
        res = perform_zero_referencing(
            data=self.da,
            zero_reference_data=self.da,
        )
        assert isinstance(res, xr.DataArray)
        assert "_datetime" in res.dims
        assert res.sizes["_datetime"] == self.da.sizes["_datetime"]
        assert np.allclose(res.values, 0)

    def test_success_chunked(self):
        data = self.da.chunk({"_datetime": 1})
        res = perform_zero_referencing(
            data=data,
            zero_reference_data=self.da,
        )
        assert isinstance(res, xr.DataArray)
        assert "_datetime" in res.dims
        assert res.sizes["_datetime"] == self.da.sizes["_datetime"]
        assert np.allclose(res.values, 0)


def test_drop_non_dim_coords(combolog_ds):
    da = combolog_ds.fitter_values

    with pytest.raises(ValidationError):
        _drop_non_dim_coords("abc")

    with pytest.raises(ValidationError):
        da2 = da.rename({"_datetime": "some_time"})
        _drop_non_dim_coords(da2)

    vm = da.sel(fitter_var="a")
    res = _drop_non_dim_coords(data=vm)

    assert isinstance(res, xr.DataArray)
    assert "_datetime" in res.dims
    assert res.sizes["_datetime"] == da.sizes["_datetime"]
    assert "fitter_var" not in res.coords


class TestGetZeroReferencedData(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds = request.getfixturevalue("combolog_ds")

    def test_success_ds(self):
        res = get_zero_referenced_data(
            data=self.ds,
            transition_variable="group_this",
            reference_value=0,
        )
        assert isinstance(res, xr.Dataset)
        assert TIME_DIM in res.dims
        assert res.sizes[TIME_DIM] == self.ds.sizes[TIME_DIM]
        assert "fitter_values" in res
        assert "spectral_values" in res

    def test_success_ds_centered(self):
        res_center = get_zero_referenced_data(
            data=self.ds,
            transition_variable="group_this",
            reference_value=0,
            center=True,
        )
        assert isinstance(res_center, xr.Dataset)
        assert TIME_DIM in res_center.dims
        assert res_center.sizes[TIME_DIM] == self.ds.sizes[TIME_DIM]
        assert "fitter_values" in res_center
        assert "spectral_values" in res_center

    def test_success_ds_chunked(self):
        use_ds = self.ds.chunk(
            {"_datetime": 5, "fitter_var": 1, "spectral_var": 1, "mode": 3}
        )

        res = get_zero_referenced_data(
            data=use_ds,
            transition_variable="group_this",
            reference_value=0,
        )
        assert isinstance(res, xr.Dataset)
        assert TIME_DIM in res.dims
        assert res.sizes[TIME_DIM] == self.ds.sizes[TIME_DIM]
        assert "fitter_values" in res
        assert "spectral_values" in res
        assert res.chunksizes == use_ds.chunksizes

    def test_success_ds_chunked_centered(self):
        use_ds = self.ds.chunk(
            {"_datetime": 5, "fitter_var": 1, "spectral_var": 1, "mode": 3}
        )

        res = get_zero_referenced_data(
            data=use_ds,
            transition_variable="group_this",
            reference_value=0,
            center=True,
        )
        assert isinstance(res, xr.Dataset)
        assert TIME_DIM in res.dims
        assert res.sizes[TIME_DIM] == self.ds.sizes[TIME_DIM]
        assert "fitter_values" in res
        assert "spectral_values" in res
        assert res.chunksizes == use_ds.chunksizes

    def test_success_ds_single_reference(self):
        res = get_zero_referenced_data(
            data=self.ds,
            transition_variable="group_this",
            reference_value=1,
        )
        assert isinstance(res, xr.Dataset)
        assert TIME_DIM in res.dims
        assert res.sizes[TIME_DIM] == self.ds.sizes[TIME_DIM]
        assert "fitter_values" in res
        assert "spectral_values" in res

    def test_success_ds_grouper(self):
        grouper = self.ds.sel(fitter_var="group_this").fitter_values.copy(deep=True)
        res = get_zero_referenced_data(
            data=self.ds,
            transition_variable=grouper,
            reference_value=0,
        )
        assert isinstance(res, xr.Dataset)
        assert TIME_DIM in res.dims
        assert res.sizes[TIME_DIM] == self.ds.sizes[TIME_DIM]
        assert "fitter_values" in res
        assert "spectral_values" in res

    def test_success_ds_passthrough(self):
        res = get_zero_referenced_data(
            data=self.ds,
            transition_variable="group_this",
            reference_value=0,
        )
        assert isinstance(res, xr.Dataset)
        assert TIME_DIM in res.dims
        assert res.sizes[TIME_DIM] == self.ds.sizes[TIME_DIM]
        assert "fitter_values" in res
        assert "spectral_values" in res
        assert not res.sel(fitter_var="a").fitter_values.equals(
            self.ds.fitter_values.sel(fitter_var="a")
        )

        res2 = get_zero_referenced_data(
            data=self.ds,
            transition_variable="group_this",
            reference_value=0,
            passthrough_fitter_vars=["a"],
        )
        assert isinstance(res2, xr.Dataset)
        assert not res2.equals(res)
        assert np.allclose(
            res2.sel(fitter_var="a").fitter_values.values,
            self.ds.fitter_values.sel(fitter_var="a").values,
        )

    def test_success_da(self):
        res = get_zero_referenced_data(
            data=self.ds.fitter_values,
            transition_variable="group_this",
            reference_value=0,
        )
        assert isinstance(res, xr.DataArray)
        assert TIME_DIM in res.dims
        assert res.sizes[TIME_DIM] == self.ds.sizes[TIME_DIM]
        assert res.name == "fitter_values"

    def test_success_da_chunked(self):
        use_da = self.ds.fitter_values.chunk({"_datetime": 5, "fitter_var": 1})
        res = get_zero_referenced_data(
            data=use_da,
            transition_variable="group_this",
            reference_value=0,
        )
        assert isinstance(res, xr.DataArray)
        assert TIME_DIM in res.dims
        assert res.sizes[TIME_DIM] == self.ds.sizes[TIME_DIM]
        assert res.name == "fitter_values"
        assert res.chunksizes == use_da.chunksizes

    def test_fail_no_variable(self):
        with pytest.raises(ValueError, match=r"Grouping variable.*"):
            get_zero_referenced_data(
                data=self.ds,
                transition_variable="group_that",
                reference_value=0,
            )

    def test_arguments(self):
        with self.assertRaises(ValidationError):
            get_zero_referenced_data(
                data=self.ds,
                transition_variable=1,
                reference_value=0,
            )

        with self.assertRaises(ValidationError):
            get_zero_referenced_data(
                data=1,
                transition_variable="group_this",
                reference_value=0,
            )

        with self.assertRaises(ValidationError):
            get_zero_referenced_data(
                data=self.ds,
                transition_variable="group_this",
                reference_value="abc",
                event_window_width="abc",
            )


class TestFilterPassthroughVariables(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        self.ds = ds.copy(deep=True)

    def test_arguments(self):
        with self.assertRaises(ValidationError):
            _filter_passthrough_variables(
                original_data=12345,
                passthrough_vars=["abc"],
                passthrough_dim="fitter_var",
            )

        with self.assertRaises(ValidationError):
            _filter_passthrough_variables(
                original_data=self.ds.fitter_values,
                passthrough_vars="abc",
                passthrough_dim="fitter_var",
            )

        with self.assertRaises(ValidationError):
            _filter_passthrough_variables(
                original_data=self.ds.fitter_values,
                passthrough_vars=["abc"],
                passthrough_dim=[123],
            )

    def test_dim(self):
        # ignore when passthrough_dim is not in original_data
        res = _filter_passthrough_variables(
            original_data=self.ds,
            passthrough_vars=["abc"],
            passthrough_dim="abc",
        )
        assert res.equals(self.ds)

    def test_success(self):
        res = _filter_passthrough_variables(
            original_data=self.ds.fitter_values,
            passthrough_vars=["a"],
            passthrough_dim="fitter_var",
        )
        assert "a" in self.ds.fitter_var
        assert "a" not in res.fitter_var
        assert res.sizes["fitter_var"] == self.ds.sizes["fitter_var"] - 1

        res = _filter_passthrough_variables(
            original_data=self.ds.fitter_values,
            passthrough_vars=["a", "b"],
            passthrough_dim="fitter_var",
        )
        assert "a" in self.ds.fitter_var
        assert "a" not in res.fitter_var
        assert "b" in self.ds.fitter_var
        assert "b" not in res.fitter_var
        assert res.sizes["fitter_var"] == self.ds.sizes["fitter_var"] - 2

    def test_no_replacement(self):
        res = _filter_passthrough_variables(
            original_data=self.ds.spectral_values,
            passthrough_vars=["d"],
            passthrough_dim="fitter_var",
        )
        assert res.equals(self.ds.spectral_values)


class TestInterp1D(unittest.TestCase):
    """
    this is kept in just as we transition from xarray 2024.11.0 to 2025.3.0
    and we move to their built-in interp method.
    """

    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        ds = request.getfixturevalue("combolog_ds")
        self.ds = ds.copy(deep=True)
        self.da = ds.fitter_values
        ref_uid = get_reference_transitions_uid(
            transition_variable_data=self.da.sel(fitter_var="group_this", drop=True),
            reference_value=0,
        )
        ref_data = get_contiguous_group_averages(data=self.ds, grouper_da=ref_uid)

        # using numbagg forces me to use construct and mean rather than mean
        ref_roll = (
            ref_data.rolling({TIME_DIM: 5}, center=True, min_periods=1)
            .construct("win")
            .mean("win")
        )
        self.ref_data = ref_roll.chunk(
            {TIME_DIM: 10, MODE_DIM: 4, "fitter_var": 3, "spectral_var": 1}
        )

        time_eval = xr.DataArray(
            self.da[TIME_DIM].values,
            dims=[TIME_DIM],
            coords={TIME_DIM: self.da[TIME_DIM].values},
            name="time",
        ).chunk({TIME_DIM: 5})
        self.time_eval = time_eval

    def test_success(self):
        res = self.ref_data.interp(
            _datetime=self.time_eval,
            assume_sorted=True,
            method="linear",
            kwargs={"fill_value": "extrapolate", "bounds_error": False},
        )
        assert isinstance(res, xr.Dataset)
        assert TIME_DIM in res.dims

        # earlier, we checked that the chunksizes are the same as time_eval for time axis
        # but now, we use xarray's interp, which merges the chunk along time axis
        assert res.chunksizes[TIME_DIM][0] == self.time_eval.sizes[TIME_DIM]

        # check that the chunksizes are the same as ref_data for other axes
        assert len(res.chunksizes[MODE_DIM]) == len(self.ref_data.chunksizes[MODE_DIM])
        assert len(res.chunksizes["spectral_var"]) == len(
            self.ref_data.chunksizes["spectral_var"]
        )
        assert len(res.chunksizes["fitter_var"]) == len(
            self.ref_data.chunksizes["fitter_var"]
        )

        assert res.sizes[TIME_DIM] == self.time_eval.sizes[TIME_DIM]
        assert "fitter_values" in res
        assert "spectral_values" in res


class TestPropagateLastReferenceValue(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds = request.getfixturevalue("combolog_ds")

        # Create sparse reference data by taking every 5th time point
        time_indices = np.arange(0, self.ds.sizes[TIME_DIM], 5)

        # Create reference data with gaps
        self.ref_data = self.ds.fitter_values.isel({TIME_DIM: time_indices})

        # Full datetime_eval array (original dense time coordinates)
        self.datetime_eval = self.ds[TIME_DIM]

    def test_arguments(self):
        # Test invalid data type
        with pytest.raises(ValidationError):
            propagate_reference_value(data="invalid", datetime_eval=self.datetime_eval)

        # Test invalid datetime_eval type
        with pytest.raises(ValidationError):
            propagate_reference_value(data=self.ref_data, datetime_eval="invalid")

        # Test mismatched time dimension names
        datetime_eval_renamed = self.datetime_eval.rename({"_datetime": "some_time"})
        with pytest.raises(ValidationError):
            propagate_reference_value(
                data=self.ref_data, datetime_eval=datetime_eval_renamed
            )

    def test_success_dataarray(self):
        """Test with DataArray input"""
        result = propagate_reference_value(
            data=self.ref_data, datetime_eval=self.datetime_eval
        )

        # Check return type and dimensions
        assert isinstance(result, xr.DataArray)
        assert TIME_DIM in result.dims

        # Check that output has same time coordinates as datetime_eval
        assert result.sizes[TIME_DIM] == self.datetime_eval.sizes[TIME_DIM]
        np.testing.assert_array_equal(
            result[TIME_DIM].values, self.datetime_eval.values
        )

        # Check that no values are NaN (all should be filled)
        assert not np.isnan(result.values).any()

    def test_success_dataset(self):
        """Test with Dataset input"""
        # Create a small dataset with sparse time points
        ref_dataset = xr.Dataset(
            {
                "fitter_values": self.ref_data,
                "spectral_values": self.ds.spectral_values.isel(
                    {TIME_DIM: np.arange(0, self.ds.sizes[TIME_DIM], 5)}
                ),
            }
        )

        result = propagate_reference_value(
            data=ref_dataset, datetime_eval=self.datetime_eval
        )

        # Check return type and dimensions
        assert isinstance(result, xr.Dataset)
        assert TIME_DIM in result.dims

        # Check that output has same time coordinates as datetime_eval
        assert result.sizes[TIME_DIM] == self.datetime_eval.sizes[TIME_DIM]
        np.testing.assert_array_equal(
            result[TIME_DIM].values, self.datetime_eval.values
        )

        # Check that no values are NaN in any variable
        for var in result.data_vars:
            assert not np.isnan(result[var].values).any()

    def test_forward_fill_behavior(self):
        """Test that values are forward filled correctly"""
        import pandas as pd

        time_coords = pd.date_range("2023-01-01", periods=10, freq="1min")
        sparse_time = time_coords[::3]  # Every 3rd point: [0, 3, 6, 9]
        dense_time = time_coords  # All points

        # Create data with known values at sparse time points
        sparse_data = xr.DataArray(
            data=[10, 20, 30, 40],  # Values at indices 0, 3, 6, 9
            dims=[TIME_DIM],
            coords={TIME_DIM: sparse_time},
        )

        dense_time_da = xr.DataArray(
            data=dense_time, dims=[TIME_DIM], coords={TIME_DIM: dense_time}
        )

        result = propagate_reference_value(
            data=sparse_data, datetime_eval=dense_time_da
        )

        # Check forward fill: indices 1,2 should have value 10; 4,5 should have value 20, etc.
        expected_values = [10, 10, 10, 20, 20, 20, 30, 30, 30, 40]
        np.testing.assert_array_equal(result.values, expected_values)

    def test_backward_fill_behavior(self):
        """Test that initial values are backward filled correctly"""
        # Create test data where first datetime_eval points are before first data point
        import pandas as pd

        time_coords = pd.date_range("2023-01-01", periods=10, freq="1min")

        # Data starts at index 3
        sparse_time = time_coords[3::2]  # [3, 5, 7, 9]
        sparse_data = xr.DataArray(
            data=[100, 200, 300, 400], dims=[TIME_DIM], coords={TIME_DIM: sparse_time}
        )

        # Evaluation time includes earlier points
        dense_time_da = xr.DataArray(
            data=time_coords, dims=[TIME_DIM], coords={TIME_DIM: time_coords}
        )

        result = propagate_reference_value(
            data=sparse_data, datetime_eval=dense_time_da
        )

        # First 3 values (indices 0,1,2) should be backward filled with 100
        # Then forward filled as normal
        expected_values = [100, 100, 100, 100, 100, 200, 200, 300, 300, 400]
        np.testing.assert_array_equal(result.values, expected_values)

    def test_success_chunked(self):
        """Test with chunked data"""
        chunked_ref_data = self.ref_data.chunk({TIME_DIM: 2, "fitter_var": 1})
        chunked_datetime_eval = self.datetime_eval.chunk({TIME_DIM: 3})

        result = propagate_reference_value(
            data=chunked_ref_data, datetime_eval=chunked_datetime_eval
        )

        # Check that result is chunked
        assert result.chunks is not None

        # Check return type and dimensions
        assert isinstance(result, xr.DataArray)
        assert TIME_DIM in result.dims
        assert result.sizes[TIME_DIM] == self.datetime_eval.sizes[TIME_DIM]

        # Check that no values are NaN
        assert not np.isnan(result.values).any()
