import unittest
from typing import Callable
from unittest.mock import patch

import numpy as np
import pandas as pd
import pytest
import xarray as xr
from pydantic import ValidationError
from spectral_arithmetic.linear_least_squares import LinearLeastSquares, design_matrix

from picarro_xarray.compute.least_squares.block_fitter import _scale_bounds_for_solver
from picarro_xarray.compute.least_squares.bounded_least_squares import (
    _bounded_lsq_fit_single_spectrum,
    _get_solution_bounds,
    bounded_lsq_fit_xarray,
)
from picarro_xarray.data_models.constants import CID_DIM, TIME_DIM


class TestGetSolutionBounds(unittest.TestCase):
    def test_no_bounds(self):
        bounds = None
        baseline_order = 2
        baseline_terms = list(range(baseline_order + 1))
        cid_list = [3, 4]
        expected_lower = np.array([-np.inf, -np.inf, -np.inf, -np.inf, -np.inf])
        expected_upper = np.array([np.inf, np.inf, np.inf, np.inf, np.inf])

        lower, upper = _get_solution_bounds(
            baseline_terms=baseline_terms,
            cid_list=cid_list,
            bounds=bounds,
        )
        assert np.all(lower == expected_lower)
        assert np.all(upper == expected_upper)

        bounds = {}
        lower, upper = _get_solution_bounds(
            baseline_terms=baseline_terms,
            cid_list=cid_list,
            bounds=bounds,
            default_bounds=(-np.inf, np.inf),
        )
        assert np.all(lower == expected_lower)
        assert np.all(upper == expected_upper)

    def test_with_bounds_override(self):
        bounds = {1: (0, 1), 3: (-1, 2)}
        baseline_order = 2
        baseline_terms = list(range(baseline_order + 1))
        cid_list = [3, 4]
        expected_lower = np.array([-np.inf, 0, -np.inf, -1, -np.inf])
        expected_upper = np.array([np.inf, 1, np.inf, 2, np.inf])

        lower, upper = _get_solution_bounds(
            baseline_terms=baseline_terms,
            cid_list=cid_list,
            bounds=bounds,
            default_bounds=(-np.inf, np.inf),
        )
        assert np.all(lower == expected_lower)
        assert np.all(upper == expected_upper)

    def test_empty_cid_list(self):
        bounds = {0: (0, 1), 2: (-1, 2)}
        baseline_order = 2
        baseline_terms = list(range(baseline_order + 1))
        cid_list = []
        expected_lower = np.array([0, -np.inf, -1])
        expected_upper = np.array([1, np.inf, 2])

        lower, upper = _get_solution_bounds(
            baseline_terms=baseline_terms,
            cid_list=cid_list,
            bounds=bounds,
            default_bounds=(-np.inf, np.inf),
        )
        assert np.all(lower == expected_lower)
        assert np.all(upper == expected_upper)

    def test_empty_baseline(self):
        bounds = {3: (0, 1), 4: (-1, 2)}
        baseline_order = 0
        baseline_terms = list(range(baseline_order + 1))
        cid_list = [3, 4]
        expected_lower = np.array([-np.inf, 0, -1])
        expected_upper = np.array([np.inf, 1, 2])

        lower, upper = _get_solution_bounds(
            baseline_terms=baseline_terms,
            cid_list=cid_list,
            bounds=bounds,
            default_bounds=(-np.inf, np.inf),
        )
        assert np.all(lower == expected_lower)
        assert np.all(upper == expected_upper)

    def test_extra_cids(self):
        bounds = {3: (0, 1), 4: (-1, 2)}
        baseline_order = 0
        baseline_terms = list(range(baseline_order + 1))
        cid_list = [5]
        expected_lower = np.array([-np.inf, -np.inf])
        expected_upper = np.array([np.inf, np.inf])

        lower, upper = _get_solution_bounds(
            baseline_terms=baseline_terms,
            cid_list=cid_list,
            bounds=bounds,
            default_bounds=(-np.inf, np.inf),
        )
        assert np.all(lower == expected_lower)
        assert np.all(upper == expected_upper)

    def test_no_offset(self):
        bounds = {3: (0, 1), 4: (-1, 2), 0: (-np.inf, np.inf), 1: (0, 1)}
        baseline_terms = [1]
        cid_list = [3, 4]
        expected_lower = np.array([0.0, 0.0, -1])
        expected_upper = np.array([1.0, 1.0, 2])

        lower, upper = _get_solution_bounds(
            baseline_terms=baseline_terms,
            cid_list=cid_list,
            bounds=bounds,
            default_bounds=(-np.inf, np.inf),
        )
        assert np.all(lower == expected_lower)
        assert np.all(upper == expected_upper)


class TestBoundedLsqFitSpectrum(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        mf = request.getfixturevalue("model_functions_harness")
        self.mf = mf

    def test_normal(self):
        lsq = LinearLeastSquares(self.mf)
        baseline_order = 2

        wavenumber = np.array([6001.0, 6002.0, 6003.0, 6004.0])
        spectrum = np.array([1.0, 2.0, 3.0, 4.0])
        nu_center = wavenumber.mean()
        error = np.ones_like(spectrum)

        full_model_function_matrix = design_matrix(
            nu_array=wavenumber,
            model_functions=lsq.model_functions.funcs,
            nu_center=nu_center,
            baseline_order=baseline_order,
        )

        full_model_function_matrix = pd.DataFrame(
            full_model_function_matrix,
            columns=lsq.get_results_keys(baseline_order=baseline_order)[:-1],
        )
        lb = np.full(full_model_function_matrix.shape[1], -np.inf)
        ub = np.full(full_model_function_matrix.shape[1], np.inf)
        fitter_mask = np.ones(full_model_function_matrix.shape[1]).astype(bool)

        from scipy.linalg import lstsq

        result = lstsq(full_model_function_matrix.values, spectrum)[0]

        result_blsq = _bounded_lsq_fit_single_spectrum(
            model_function_matrix=full_model_function_matrix.values,
            spectrum=spectrum,
            error=error,
            lb=lb,
            ub=ub,
            fitter_var_mask=fitter_mask,
        )

        assert isinstance(result_blsq, np.ndarray)
        assert np.allclose(result_blsq, result)

    def test_nans(self):
        lsq = LinearLeastSquares(self.mf)
        baseline_order = 2

        wavenumber = np.array([6001.0, 6002.0, 6003.0, 6004.0])
        spectrum = np.array([1.0, 2.0, 3.0, np.nan])
        nu_center = wavenumber.mean()
        error = np.ones_like(spectrum)

        full_model_function_matrix = design_matrix(
            nu_array=wavenumber,
            model_functions=lsq.model_functions.funcs,
            nu_center=nu_center,
            baseline_order=baseline_order,
        )

        full_model_function_matrix = pd.DataFrame(
            full_model_function_matrix,
            columns=lsq.get_results_keys(baseline_order=baseline_order)[:-1],
        )

        lb = np.full(full_model_function_matrix.shape[1], -np.inf)
        ub = np.full(full_model_function_matrix.shape[1], np.inf)
        fitter_mask = np.ones(full_model_function_matrix.shape[1]).astype(bool)

        result_blsq = _bounded_lsq_fit_single_spectrum(
            model_function_matrix=full_model_function_matrix.values,
            spectrum=spectrum,
            error=error,
            lb=lb,
            ub=ub,
            fitter_var_mask=fitter_mask,
        )

        assert isinstance(result_blsq, np.ndarray)
        assert len(result_blsq) == full_model_function_matrix.shape[1]

    def test_bounds(self):
        lsq = LinearLeastSquares(self.mf)
        baseline_order = 2

        wavenumber = np.array([6001.0, 6002.0, 6003.0, 6004.0])
        spectrum = np.array([1.0, 2.0, 3.0, 4.0])
        nu_center = wavenumber.mean()
        error = np.ones_like(spectrum)

        full_model_function_matrix = design_matrix(
            nu_array=wavenumber,
            model_functions=lsq.model_functions.funcs,
            nu_center=nu_center,
            baseline_order=baseline_order,
        )

        full_model_function_matrix = pd.DataFrame(
            full_model_function_matrix,
            columns=lsq.get_results_keys(baseline_order=baseline_order)[:-1],
        )

        lb = np.full(full_model_function_matrix.shape[1], 0)
        ub = np.full(full_model_function_matrix.shape[1], np.inf)
        fitter_mask = np.ones(full_model_function_matrix.shape[1]).astype(bool)

        result_blsq = _bounded_lsq_fit_single_spectrum(
            model_function_matrix=full_model_function_matrix.values,
            spectrum=spectrum,
            error=error,
            lb=lb,
            ub=ub,
            fitter_var_mask=fitter_mask,
        )

        assert isinstance(result_blsq, np.ndarray)
        assert len(result_blsq) == full_model_function_matrix.shape[1]
        assert np.all(result_blsq >= 0)

    def test_bounds_dynamic(self):
        lsq = LinearLeastSquares(self.mf)
        baseline_order = 2

        wavenumber = np.array([6001.0, 6002.0, 6003.0, 6004.0])
        spectrum = np.array([1.0, 2.0, 3.0, 4.0])
        nu_center = wavenumber.mean()
        error = np.ones_like(spectrum)

        full_model_function_matrix = design_matrix(
            nu_array=wavenumber,
            model_functions=lsq.model_functions.funcs,
            nu_center=nu_center,
            baseline_order=baseline_order,
        )

        full_model_function_matrix = pd.DataFrame(
            full_model_function_matrix,
            columns=lsq.get_results_keys(baseline_order=baseline_order)[:-1],
        )

        lb = np.full(full_model_function_matrix.shape[1], 0)
        ub = np.full(full_model_function_matrix.shape[1], np.inf)
        fitter_mask = np.ones(full_model_function_matrix.shape[1]).astype(bool)
        fitter_mask[-1] = False

        result_blsq = _bounded_lsq_fit_single_spectrum(
            model_function_matrix=full_model_function_matrix.values,
            spectrum=spectrum,
            error=error,
            lb=lb,
            ub=ub,
            fitter_var_mask=fitter_mask,
        )

        assert isinstance(result_blsq, np.ndarray)
        assert len(result_blsq) == full_model_function_matrix.shape[1]
        assert np.isnan(result_blsq[-1])
        assert np.all(result_blsq[:-1] >= 0)


class TestBoundedLsqFitXarray(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        mf = request.getfixturevalue("model_functions_harness")
        combo_ds = request.getfixturevalue("combolog_ds")
        self.lsq = LinearLeastSquares(mf)
        self.wavenumber = combo_ds.sel(spectral_var="nu").spectral_values
        self.spectrum = combo_ds.sel(spectral_var="partial_fit").spectral_values
        self.error = 1 / combo_ds.sel(spectral_var="npoints").spectral_values
        self.nu_center = combo_ds.sel(fitter_var="a").fitter_values

    def test_success(self):
        mock_res = np.ones(
            (self.nu_center.sizes[TIME_DIM], len(self.lsq.get_results_keys()))
        )

        from picarro_xarray.compute.least_squares import bounded_least_squares

        with patch.object(
            bounded_least_squares,
            "_lsq_fit_time_block",
            return_value=mock_res,
        ) as mock_lsq_fit:
            res = bounded_lsq_fit_xarray(
                spectrum=self.spectrum,
                spectrum_error=self.error,
                wavenumber=self.wavenumber,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
                baseline_order=1,
                bounds={0: (0, 1), 104: (0, 100)},
            )
            assert isinstance(res, xr.DataArray)
            assert isinstance(mock_lsq_fit.call_args.kwargs["solver"], Callable)
            assert np.all(
                mock_lsq_fit.call_args.kwargs["lb"]
                == [-np.inf, -np.inf, -np.inf, -np.inf, 0]
            )
            assert np.all(
                mock_lsq_fit.call_args.kwargs["ub"]
                == [np.inf, np.inf, np.inf, np.inf, 100]
            )

    def test_wrong_fitter_mask(self):
        output_keys = self.lsq.get_results_keys(baseline_order=1)[:-1]
        time_dim = TIME_DIM

        cid_fitter_mask = xr.DataArray(
            np.full(
                shape=(self.spectrum.sizes[TIME_DIM], len(output_keys)), fill_value=True
            ),
            dims=[time_dim, CID_DIM],
            coords={
                TIME_DIM: self.spectrum[TIME_DIM].values,
                CID_DIM: ["a" for _ in output_keys],
            },
        )

        with pytest.raises(ValueError):
            bounded_lsq_fit_xarray(
                spectrum=self.spectrum,
                spectrum_error=self.error,
                wavenumber=self.wavenumber,
                nu_center=self.nu_center,
                cid_fitter_mask=cid_fitter_mask,
                lsq_fitter=self.lsq,
                baseline_order=1,
                bounds={0: (0, 1), 4: (0, 100)},
            )

    def test_arguments(self):
        with self.assertRaises(ValidationError):
            bounded_lsq_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=self.wavenumber,
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=123,
            )

        with self.assertRaises(ValidationError):
            bounded_lsq_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=self.wavenumber,
                spectrum_error=self.error,
                nu_center=self.nu_center.rename({TIME_DIM: "abc"}),
                lsq_fitter=self.lsq,
            )

        with self.assertRaises(ValidationError):
            bounded_lsq_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=self.wavenumber,
                spectrum_error="123",
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
            )

        with self.assertRaises(ValidationError):
            bounded_lsq_fit_xarray(
                spectrum=123,
                wavenumber=self.wavenumber,
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
            )

        with self.assertRaises(ValidationError):
            bounded_lsq_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=np.array([1, 2, 3]),
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
            )

        with self.assertRaises(ValidationError):
            bounded_lsq_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=np.array([1, 2, 3]),
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
                baseline_order="abc",
            )

        with self.assertRaises(ValidationError):
            bounded_lsq_fit_xarray(
                spectrum=self.spectrum,
                wavenumber=np.array([1, 2, 3]),
                spectrum_error=self.error,
                nu_center=self.nu_center,
                lsq_fitter=self.lsq,
                bounds=10,
            )


class TestScaleBoundsForSolver(unittest.TestCase):
    """Test cases for the _scale_bounds_for_solver function."""

    def test_normal_scaling(self):
        """Test normal scaling with positive scale factors."""
        lb_original = np.array([-1.0, 0.0, -np.inf])
        ub_original = np.array([1.0, 10.0, np.inf])
        columns_scale = np.array([2.0, 0.5, 3.0])

        lb_scaled, ub_scaled = _scale_bounds_for_solver(
            lb_original=lb_original,
            ub_original=ub_original,
            columns_scale=columns_scale,
        )

        expected_lb = np.array([-2.0, 0.0, -np.inf])
        expected_ub = np.array([2.0, 5.0, np.inf])

        np.testing.assert_array_equal(lb_scaled, expected_lb)
        np.testing.assert_array_equal(ub_scaled, expected_ub)

    def test_zero_scale_factors(self):
        """Test handling of zero scale factors."""
        lb_original = np.array([-1.0, 0.0, -5.0])
        ub_original = np.array([1.0, 10.0, 5.0])
        columns_scale = np.array([2.0, 0.0, 0.0])  # Second and third have zero scale

        lb_scaled, ub_scaled = _scale_bounds_for_solver(
            lb_original=lb_original,
            ub_original=ub_original,
            columns_scale=columns_scale,
        )

        expected_lb = np.array([-2.0, 0.0, 0.0])  # Zero scale -> bounds become [0, 0]
        expected_ub = np.array([2.0, 0.0, 0.0])

        np.testing.assert_array_equal(lb_scaled, expected_lb)
        np.testing.assert_array_equal(ub_scaled, expected_ub)

    def test_infinite_bounds(self):
        """Test handling of infinite bounds."""
        lb_original = np.array([-np.inf, -10.0, 0.0])
        ub_original = np.array([np.inf, np.inf, 100.0])
        columns_scale = np.array([1.5, 2.0, 0.1])

        lb_scaled, ub_scaled = _scale_bounds_for_solver(
            lb_original=lb_original,
            ub_original=ub_original,
            columns_scale=columns_scale,
        )

        expected_lb = np.array([-np.inf, -20.0, 0.0])
        expected_ub = np.array([np.inf, np.inf, 10.0])

        np.testing.assert_array_equal(lb_scaled, expected_lb)
        np.testing.assert_array_equal(ub_scaled, expected_ub)

    def test_single_element_arrays(self):
        """Test with single-element arrays."""
        lb_original = np.array([2.0])
        ub_original = np.array([8.0])
        columns_scale = np.array([0.25])

        lb_scaled, ub_scaled = _scale_bounds_for_solver(
            lb_original=lb_original,
            ub_original=ub_original,
            columns_scale=columns_scale,
        )

        expected_lb = np.array([0.5])
        expected_ub = np.array([2.0])

        np.testing.assert_array_equal(lb_scaled, expected_lb)
        np.testing.assert_array_equal(ub_scaled, expected_ub)

    def test_shape_mismatch_lb(self):
        """Test error handling for shape mismatch in lower bounds."""
        lb_original = np.array([-1.0, 0.0, -np.inf])
        ub_original = np.array([1.0, 10.0, 5.0])
        columns_scale = np.array([2.0, 0.5])  # Wrong shape

        with self.assertRaises(ValueError) as context:
            _scale_bounds_for_solver(
                lb_original=lb_original,
                ub_original=ub_original,
                columns_scale=columns_scale,
            )

        self.assertIn(
            "Shape mismatch between bounds and columns_scale", str(context.exception)
        )

    def test_empty_arrays(self):
        """Test with empty arrays."""
        lb_original = np.array([])
        ub_original = np.array([])
        columns_scale = np.array([])

        lb_scaled, ub_scaled = _scale_bounds_for_solver(
            lb_original=lb_original,
            ub_original=ub_original,
            columns_scale=columns_scale,
        )

        self.assertEqual(lb_scaled.shape, (0,))
        self.assertEqual(ub_scaled.shape, (0,))

    def test_return_types(self):
        """Test that the function returns the correct types."""
        lb_original = np.array([-1.0, 0.0])
        ub_original = np.array([1.0, 10.0])
        columns_scale = np.array([2.0, 0.5])

        lb_scaled, ub_scaled = _scale_bounds_for_solver(
            lb_original=lb_original,
            ub_original=ub_original,
            columns_scale=columns_scale,
        )

        self.assertIsInstance(lb_scaled, np.ndarray)
        self.assertIsInstance(ub_scaled, np.ndarray)
        self.assertTrue(np.issubdtype(lb_scaled.dtype, np.floating))
        self.assertTrue(np.issubdtype(ub_scaled.dtype, np.floating))
        self.assertEqual(lb_scaled.shape, lb_original.shape)
        self.assertEqual(ub_scaled.shape, ub_original.shape)
