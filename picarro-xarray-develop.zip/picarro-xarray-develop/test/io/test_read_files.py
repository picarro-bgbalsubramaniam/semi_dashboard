import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pytest

from picarro_xarray.io.read_files import pool_data_to_zarr


class TestPoolDataToZarr(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds_combo = request.getfixturevalue("combolog_ds")
        self.ds_private = request.getfixturevalue("privatelog_ds")

    def test_timezone(self):
        with self.assertRaises(ValueError):
            pool_data_to_zarr(
                combolog_folder_path="some_path",
                path_to_zarr="a folder",
                local_time_zone="a timezone",
            )

    def test_existing_one_zarr(self):
        with tempfile.TemporaryDirectory(dir="/tmp") as tmpdir:
            zarr_path = Path(tmpdir) / "combo.zarr"
            self.ds_combo.to_zarr(zarr_path)

            # one zarr, exist_ok=False
            with self.assertRaises(FileExistsError):
                pool_data_to_zarr(
                    combolog_folder_path="some_path",
                    path_to_zarr=tmpdir,
                    local_time_zone="US/Pacific",
                    exist_ok=False,
                )

            # one zarr, exist_ok=True
            assert zarr_path == pool_data_to_zarr(
                combolog_folder_path="some_path",
                path_to_zarr=tmpdir,
                local_time_zone="US/Pacific",
                exist_ok=True,
            )

    def test_existing_two_zarr(self):
        with tempfile.TemporaryDirectory(dir="/tmp") as tmpdir:
            zarr_path = Path(tmpdir) / "combo.zarr"
            zarr_path_2 = Path(tmpdir) / "combo_2.zarr"
            self.ds_combo.to_zarr(zarr_path)
            self.ds_private.to_zarr(zarr_path_2)

            # two zarr
            with self.assertRaises(ValueError):
                pool_data_to_zarr(
                    combolog_folder_path="some_path",
                    path_to_zarr=tmpdir,
                    local_time_zone="US/Pacific",
                    exist_ok=False,
                )

    def test_no_private(self):
        # Import the module to get a reference to the function
        from picarro_xarray.io import read_files

        with tempfile.TemporaryDirectory(dir="/tmp") as tmpdir:
            zarr_path = Path(tmpdir) / "hide/combo.zarr"
            self.ds_combo.to_zarr(zarr_path)

            with patch.object(read_files, "read_combo_logs", return_value=zarr_path):
                res = pool_data_to_zarr(
                    combolog_folder_path="some_path",
                    path_to_zarr=tmpdir,
                    local_time_zone="US/Pacific",
                )
                assert res == zarr_path

                # same when private_path does not exist
                res = pool_data_to_zarr(
                    combolog_folder_path="some_path",
                    privatelog_folder_path="some_path",
                    path_to_zarr=tmpdir,
                    local_time_zone="US/Pacific",
                )
                assert res == zarr_path

    def test_with_private(self):
        # Import the module to get a reference to the functions
        from picarro_xarray.io import read_files

        with tempfile.TemporaryDirectory(dir="/tmp") as tmpdir:
            zarr_path = Path(tmpdir) / "hide/combo.zarr"
            zarr_path_private = Path(tmpdir) / "hide/private.zarr"
            self.ds_combo.to_zarr(zarr_path)
            self.ds_private.to_zarr(zarr_path_private)

            with (
                patch.object(read_files, "read_combo_logs", return_value=zarr_path),
                patch.object(
                    read_files, "read_private_logs", return_value=zarr_path_private
                ),
            ):
                res = pool_data_to_zarr(
                    combolog_folder_path="some_path",
                    path_to_zarr=tmpdir,
                    local_time_zone="US/Pacific",
                    privatelog_folder_path=Path(tmpdir) / "hide",
                )
                assert res == zarr_path
                assert not zarr_path_private.exists()
                assert zarr_path.exists()
