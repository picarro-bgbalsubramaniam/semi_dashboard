import pytest
import xarray as xr
import pandas as pd
from pydantic import ValidationError

from picarro_xarray.io.utils.dataset_attributes_setting import set_time_attributes, set_files_attributes


def test_set_time_attributes():

    test_ds = xr.Dataset({"_datetime": pd.date_range(start="2021-01-01", end="2021-01-02", freq="D")})
    test_ds = set_time_attributes(test_ds)
    assert test_ds.attrs["Start"] == "2021-01-01 00:00:00"
    assert test_ds.attrs["Stop"] == "2021-01-02 00:00:00"

    with pytest.raises(ValueError):
        set_time_attributes(xr.Dataset({"abc": [1, 2, 3]}))

    with pytest.raises(ValueError):
        set_time_attributes(xr.Dataset({"_datetime": ["2021-01-01", "2021-01-02"]}))

    with pytest.raises(ValueError):
        test_ds = xr.Dataset({"_datetime": pd.to_datetime(["2021-01-02", "2021-01-01"])})
        set_time_attributes(test_ds)

    with pytest.raises(ValueError):
        test_ds = xr.Dataset({"_datetime": pd.date_range(start="2021-01-02", end="2021-01-01", freq="D")})
        set_time_attributes(test_ds)

    with pytest.raises(ValidationError):
        set_time_attributes(pd.Series([1, 2, 3]))


def test_set_files_attributes():

    test_da = xr.DataArray(["1", "2", "3"], dims=["_datetime"])
    test_da = set_files_attributes(test_da)
    assert set(test_da.attrs["files"]) == {"1", "2", "3"}

    test_da = xr.DataArray(
        ["path/to/file1.h5", "path/to/file1.h5", "path/to/file2.h5"], dims=["_datetime"]
    )
    test_da = set_files_attributes(test_da)
    assert set(test_da.attrs["files"]) == {"file1.h5", "file2.h5"}

    with pytest.raises(ValueError):
        test_da = xr.DataArray([1, 2, 3], dims=["abc"])
        set_files_attributes(test_da)

    with pytest.raises(ValidationError):
        set_files_attributes(pd.Series([1, 2, 3]))
