import os
import shutil
import tempfile
from pathlib import Path
from unittest import mock
from zipfile import ZipFile

import h5py
import numpy as np
import pandas as pd
import pytest
import xarray as xr
import xarray.backends.api as xr_api
from distributed import client as distributed_client
from pydantic import ValidationError

from picarro_xarray.io.data_models.prescan_data_structures import PrivateLogInfo
from picarro_xarray.io.merging.merge_datasets import (
    append_private_logs_to_spectral_zarr,
)

# Import modules for patching
from picarro_xarray.io.privatelog import private_log_prescan, private_log_results
from picarro_xarray.io.privatelog.private_log_results import (
    _h5s_privatelogs_to_zarr,
    _process_h5_privatelog_file,
    _read_individual_privatelog_h5,
    read_private_logs,
)
from picarro_xarray.io.utils.api_utils import (
    DATE_FORMAT,
    _tmp_files_cleanup,
    get_private_logs_files_paths,
    private_xarray_to_pandas,
)
from picarro_xarray.time_utils.timeutils import convert_timezone

date_range = pd.date_range("2022-10-18", periods=100, freq="4s")
my_paths = [f"my_path{i // 2}" for i in range(1, 100 + 1)]
DA = xr.DataArray(
    np.random.rand(100, 4),
    dims=["_datetime", "private_var"],
    attrs={
        "Start": f"{date_range[0]:{DATE_FORMAT}}",
        "Stop": f"{date_range[-1]:{DATE_FORMAT}}",
        "tz": "UTC",
    },
    coords={
        "_datetime": ("_datetime", date_range),
        "private_var": ("private_var", [f"my_var{i}" for i in range(4)]),
    },
)

DS = xr.Dataset(
    data_vars={
        "private_values": (("_datetime", "private_var"), np.random.rand(100, 4)),
        "private_logs_origin": (
            "_datetime",
            my_paths,
            {"files": list(set(my_paths))},
        ),
    },
    attrs={
        "Start": f"{date_range[0]:{DATE_FORMAT}}",
        "Stop": f"{date_range[-1]:{DATE_FORMAT}}",
        "tz": "UTC",
    },
    coords={
        "_datetime": ("_datetime", pd.date_range("2022-10-17", periods=100, freq="4s")),
        "private_var": ("private_var", [f"my_var{i}" for i in range(4)]),
    },
)

DS2 = xr.Dataset(
    coords={
        "_datetime": ("_datetime", pd.date_range("2022-10-17", periods=100, freq="3s"))
    }
)


def test_get_private_logs_files_paths():
    with tempfile.TemporaryDirectory(prefix="tmp_zip_files") as td:
        names = [
            "NUV1050-20230822-000806-DataLog_Private.h5",
            "NUV1050-20230822-001200-DataLog_NewFitter_Private.h5",
            "NUV1050-20230822-001201-DataLog_NewFitter_Private.h5",
            "NUV1050-20230822-001200-DataLog_TD_Private.h5",
            "NUV1050-20230822-001200-DataLog_Standard_Private.h5",
        ]
        names = [f"{td}/{name}" for name in names]

        for name in names:
            with h5py.File(name, "w") as f:
                pass

        with ZipFile(f"{td}/test.zip", "w") as myzip:
            for name in names:
                myzip.write(name)

        res = get_private_logs_files_paths(folder_path=td, privatelog_key="NewFitter")
        assert isinstance(res, list)
        assert len(res) == 2

        res = get_private_logs_files_paths(folder_path=td, privatelog_key="TD")
        assert isinstance(res, list)
        assert len(res) == 1

        with pytest.raises(
            ValueError, match=r".*different private logs designations.*"
        ):
            _ = get_private_logs_files_paths(folder_path=td, privatelog_key=None)

    with pytest.raises(FileNotFoundError):
        _ = get_private_logs_files_paths(folder_path="my_other_dir")

    with pytest.raises(ValidationError):
        _ = get_private_logs_files_paths(folder_path={})


def test_tmp_files_cleanup():
    with tempfile.TemporaryDirectory(prefix="tmp_zip_files") as td:
        names = [
            "NewFitter_Private01.h5",
            "OldFitter_Private02.h5",
            "NewFitter_Private03.h5",
            "OldFitter_Private04.h5",
        ]
        names = [f"{td}/{name}" for name in names]

        for name in names:
            with h5py.File(name, "w") as f:
                pass

        with mock.patch.object(shutil, "rmtree") as mock_rmtree:
            _tmp_files_cleanup(td)
            mock_rmtree.assert_called_once

    with pytest.raises(Exception):
        _tmp_files_cleanup("some_folder")


@mock.patch.object(os, "rename")
@mock.patch.object(
    private_log_results,
    "get_private_logs_files_paths",
    return_value=["NUV1047_0.h5", "NUV1047_1.h5"],
)
@mock.patch.object(private_log_results, "_tmp_files_cleanup")
@mock.patch.object(
    private_log_results,
    "prescan_private_logs",
    return_value={
        "NUV1047_0.h5": PrivateLogInfo(
            timestamp=np.array([1, 2, 3]) + 63798364799150, variables=["a", "b", "c"]
        ),
        "NUV1047_1.h5": PrivateLogInfo(
            timestamp=np.array([4, 5, 6]) + 63798364799150, variables=["a", "b"]
        ),
    },
)
@mock.patch.object(private_log_prescan, "_preallocate_private_zarr_store")
@mock.patch.object(private_log_results, "_h5s_privatelogs_to_zarr")
def test_read_private_logs_xarray(
    mock_zarr,
    mock_preallocate,
    mock_prescan_info,
    mock_cleanup,
    mock_get_private,
    mock_rename,
):
    with tempfile.TemporaryDirectory(dir="/tmp") as tempdir:
        with pytest.raises(ValidationError):
            read_private_logs(
                folder_path=None,
                local_time_zone="US/Pacific",
                path_to_zarr=tempdir,
                analyzer_name="NUV1041",
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_private_logs(
                folder_path="mypath",
                local_time_zone=[],
                path_to_zarr=tempdir,
                analyzer_name="NUV1041",
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_private_logs(
                folder_path="mypath",
                local_time_zone="US/Pacific",
                path_to_zarr=tempdir,
                analyzer_name=np.array([1, 2, 3]),
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_private_logs(
                folder_path="mypath",
                local_time_zone="US/Pacific",
                path_to_zarr=tempdir,
                analyzer_name="NUV1041",
                chunk_time_size={"len": 1000},
            )

        # Chunk size must be >0
        with pytest.raises(ValueError):
            read_private_logs(
                folder_path="mypath",
                local_time_zone="US/Pacific",
                path_to_zarr=tempdir,
                analyzer_name="NUV1041",
                chunk_time_size=-1,
            )

        # Can't find tz
        with pytest.raises(ValueError):
            read_private_logs(
                folder_path="mypath",
                local_time_zone="mytz",
                path_to_zarr=tempdir,
                analyzer_name="NUV1041",
                chunk_time_size=1000,
            )

        # No unique files
        with mock.patch.object(
            private_log_results, "check_for_overlapping_files", return_value=[]
        ) as mock_overlap:
            res = read_private_logs(
                folder_path="mypath",
                local_time_zone="US/Pacific",
                path_to_zarr=Path(tempdir),
                analyzer_name="NUV1041",
                chunk_time_size=1000,
            )
            mock_overlap.assert_called_once
            assert isinstance(res, Path)

        mock_overlap.reset_mock()
        mock_prescan_info.reset_mock()
        mock_cleanup.reset_mock()
        mock_get_private.reset_mock()
        mock_zarr.reset_mock()
        mock_rename.reset_mock()

        with (
            mock.patch.object(private_log_results.Path, "exists") as mock_exist,
            mock.patch.object(xr, "open_zarr") as mock_open,
            mock.patch.object(
                private_log_results, "concat_zarr_stores", return_value=xr.Dataset()
            ) as mock_concat,
            mock.patch.object(shutil, "rmtree") as mock_remove,
        ):
            read_private_logs(
                folder_path="mypath",
                local_time_zone="US/Pacific",
                path_to_zarr=tempdir,
                analyzer_name="NUV1041",
                chunk_time_size=1000,
            )

            mock_get_private.assert_called_once
            mock_overlap.assert_called_once
            mock_prescan_info.assert_called_once
            mock_preallocate.assert_called_once
            mock_zarr.assert_called_once
            mock_cleanup.assert_called_once
            mock_exist.assert_called_once
            mock_open.assert_called_once
            mock_concat.assert_called_once
            mock_remove.assert_called_once
            mock_rename.assert_called_once

        mock_overlap.reset_mock()
        mock_prescan_info.reset_mock()
        mock_cleanup.reset_mock()
        mock_get_private.reset_mock()
        mock_zarr.reset_mock()
        mock_rename.reset_mock()

        with mock.patch.object(
            private_log_results.Path, "exists", return_value=False
        ) as mock_exist:
            read_private_logs(
                folder_path="mypath",
                local_time_zone="US/Pacific",
                path_to_zarr=tempdir,
                analyzer_name="NUV1041",
                chunk_time_size=1000,
            )

            mock_get_private.assert_called_once
            mock_overlap.assert_called_once
            mock_prescan_info.assert_called_once
            mock_preallocate.assert_called_once
            mock_zarr.assert_called_once
            mock_cleanup.assert_called_once
            mock_exist.assert_called_once
            mock_rename.assert_called_once

        mock_overlap.reset_mock()
        mock_prescan_info.reset_mock()
        mock_cleanup.reset_mock()
        mock_get_private.reset_mock()
        mock_zarr.reset_mock()
        mock_rename.reset_mock()

        with mock.patch.object(
            private_log_results.Path, "exists", return_value=False
        ) as mock_exist:
            read_private_logs(
                folder_path="mypath",
                local_time_zone="US/Pacific",
                path_to_zarr=tempdir,
                analyzer_name=None,
                chunk_time_size=1000,
            )

            mock_get_private.assert_called_once
            mock_overlap.assert_called_once
            mock_prescan_info.assert_called_once
            mock_preallocate.assert_called_once
            mock_zarr.assert_called_once
            mock_cleanup.assert_called_once
            mock_exist.assert_called_once
            mock_rename.assert_called_once

        mock_overlap.reset_mock()
        mock_prescan_info.reset_mock()
        mock_cleanup.reset_mock()
        mock_get_private.reset_mock()
        mock_zarr.reset_mock()
        mock_rename.reset_mock()


@mock.patch.object(private_log_results.Path, "exists")
@mock.patch.object(xr_api, "to_zarr")
@mock.patch.object(xr, "open_zarr")
def test_append_private_logs_to_spectral_zarr(mock_openzarr, mock_tozarr, mock_exist):
    assert isinstance(DS, xr.Dataset)
    assert isinstance(DS2, xr.Dataset)

    with pytest.raises(ValidationError):
        append_private_logs_to_spectral_zarr(
            ds_private=None, zarr_store_path="mypath", chunk_time_size=1000
        )

    with pytest.raises(ValidationError):
        append_private_logs_to_spectral_zarr(
            ds_private=DS, zarr_store_path=None, chunk_time_size=1000
        )

    with pytest.raises(ValidationError):
        append_private_logs_to_spectral_zarr(
            ds_private=DS, zarr_store_path="path", chunk_time_size={"len": 1000}
        )

    mock_exist.return_value = False
    with pytest.raises(FileNotFoundError):
        append_private_logs_to_spectral_zarr(
            ds_private=DS, zarr_store_path="mypath", chunk_time_size=1000
        )

    mock_exist.return_value = True
    with pytest.raises(ValueError):
        append_private_logs_to_spectral_zarr(
            ds_private=DS, zarr_store_path="path", chunk_time_size=-1
        )

    mock_openzarr.return_value = DS2

    append_private_logs_to_spectral_zarr(
        ds_private=DS, zarr_store_path="path", chunk_time_size=1000
    )

    mock_tozarr.assert_called_once


def test_convert_timezone():
    """Test that timezone conversion of xarray works as expected"""
    converted_ds = convert_timezone(DA, "America/Los_Angeles")
    assert pd.Timestamp(converted_ds.attrs["Start"]) == pd.Timestamp(
        "2022-10-17 17:00:00"
    )
    assert pd.Timestamp(converted_ds.attrs["Stop"]) == pd.Timestamp(
        "2022-10-17 17:06:36"
    )
    assert converted_ds.attrs["tz"] == "America/Los_Angeles"

    with pytest.raises(ValueError):
        convert_timezone(DA, "mytz")

    with pytest.raises(ValueError):
        convert_timezone(DA.rename({"_datetime": "time"}), "US/Pacific")

    with pytest.raises(ValueError):
        tmp_da = DA.copy(deep=True)
        tmp_da.attrs = {}
        convert_timezone(tmp_da, "US/Pacific")

    with pytest.raises(ValidationError):
        convert_timezone(DA, {1, 2})

    with pytest.raises(ValidationError):
        convert_timezone(None, "US/Pacific")


def test_private_xarray_to_pandas():
    """
    Test that we can convert xarray into time series pandas df
    """
    df = private_xarray_to_pandas(DS, start="2022-10-17 00:00:16")
    assert str(df.index[0]) == "2022-10-17 00:00:16"
    assert str(df.index[-1]) == "2022-10-17 00:06:36"
    df = private_xarray_to_pandas(
        DS, start="2022-10-17 00:00:16", stop="2022-10-17 00:06:00"
    )
    assert str(df.index[0]) == "2022-10-17 00:00:16"
    assert str(df.index[-1]) == "2022-10-17 00:06:00"
    df = private_xarray_to_pandas(DS, stop="2022-10-17 00:06:00")
    assert str(df.index[0]) == "2022-10-17 00:00:00"
    assert str(df.index[-1]) == "2022-10-17 00:06:00"
    df = private_xarray_to_pandas(DS, columns=["my_var1", "my_var2"])
    assert set(df.columns) == {"my_var1", "my_var2"}


def test_process_h5_privatelog_file():
    from pathlib import Path

    from dask.distributed import Client

    len_t = 50
    ts = np.array(1e9 * np.arange(0, len_t) + 63798364799150, dtype=int)

    # create random data
    df1 = pd.DataFrame(
        data={
            "timestamp": ts,
            "a": np.random.rand(len_t).astype(int),
            "b": np.random.rand(len_t).astype(np.float64),
        }
    )

    with tempfile.NamedTemporaryFile() as tf1:
        with h5py.File(tf1.name, "w") as f:
            _ = f.create_dataset(name="results", data=df1.to_records(index=False))

        with Client():
            with mock.patch.object(xr_api, "to_zarr") as my_mock:
                _ = _process_h5_privatelog_file(
                    filename=tf1.name,
                    zarr_path="mypath",
                    file_info=PrivateLogInfo(
                        timestamp=ts,
                        variables=["a", "b"],
                    ),
                    time_region=slice(0, len(ts)),
                    private_vars=["a", "b", "c"],
                )
                assert my_mock.call_count == 1

            with mock.patch.object(xr_api, "to_zarr") as my_mock:
                _ = _process_h5_privatelog_file(
                    filename=Path(tf1.name),
                    zarr_path=Path("mypath"),
                    file_info=PrivateLogInfo(
                        timestamp=ts,
                        variables=["a", "b"],
                    ),
                    time_region=slice(0, len(ts)),
                    private_vars=["a", "b", "c"],
                )
                assert my_mock.call_count == 1

            with pytest.raises(ValidationError):
                _ = _process_h5_privatelog_file(
                    filename=np.array([1, 2, 3]),
                    zarr_path="mypath",
                    file_info=PrivateLogInfo(
                        timestamp=ts,
                        variables=["a", "b"],
                    ),
                    time_region=slice(0, len(ts)),
                    private_vars=["a", "b", "c"],
                )

            with pytest.raises(ValidationError):
                _ = _process_h5_privatelog_file(
                    filename=tf1.name,
                    zarr_path=None,
                    file_info=PrivateLogInfo(
                        timestamp=ts,
                        variables=["a", "b"],
                    ),
                    time_region=slice(0, len(ts)),
                    private_vars=["a", "b", "c"],
                )

            with pytest.raises(ValidationError):
                _ = _process_h5_privatelog_file(
                    filename=tf1.name,
                    zarr_path="mypath",
                    file_info={"a": 1},
                    time_region=slice(0, len(ts)),
                    private_vars=["a", "b", "c"],
                )

            with pytest.raises(ValidationError):
                _ = _process_h5_privatelog_file(
                    filename=tf1.name,
                    zarr_path="mypath",
                    file_info=PrivateLogInfo(
                        timestamp=ts,
                        variables=["a", "b"],
                    ),
                    time_region=3,
                    private_vars=["a", "b", "c"],
                )

            with pytest.raises(ValidationError):
                _ = _process_h5_privatelog_file(
                    filename=tf1.name,
                    zarr_path="None",
                    file_info=PrivateLogInfo(
                        timestamp=ts,
                        variables=["a", "b"],
                    ),
                    time_region=slice(0, len(ts)),
                    private_vars=pd.Series(["a", "b", 1]),
                )


def test_read_individual_privatelog_h5():
    from pathlib import Path

    len_t = 50
    ts = np.array(1e9 * np.arange(0, len_t) + 63798364799150, dtype=int)

    # create random data
    df1 = pd.DataFrame(
        data={
            "timestamp": ts,
            "a": np.random.rand(len_t).astype(int),
            "b": np.random.rand(len_t).astype(np.float64),
        }
    )

    with tempfile.NamedTemporaryFile() as tf1:
        with h5py.File(tf1.name, "w") as f:
            _ = f.create_dataset(name="results", data=df1.to_records(index=False))

        info = PrivateLogInfo(
            timestamp=ts,
            variables=["a", "b", "timestamp"],
        )

        result = _read_individual_privatelog_h5(
            h5file_path=tf1.name,
            file_info=info,
        )

        assert isinstance(result, xr.Dataset)
        assert all(var_ in result.dims for var_ in ["_datetime", "private_var"])
        assert "private_values" in result.data_vars
        assert set(result.private_var.values) == set(["a", "b", "timestamp"])
        assert result.sizes["_datetime"] == len_t
        assert result.sizes["private_var"] == 3

        result = _read_individual_privatelog_h5(
            h5file_path=Path(tf1.name),
            file_info=info,
        )

        assert isinstance(result, xr.Dataset)
        assert all(var_ in result.dims for var_ in ["_datetime", "private_var"])
        assert "private_values" in result.data_vars
        assert set(result.private_var.values) == set(["a", "b", "timestamp"])
        assert result.sizes["_datetime"] == len_t
        assert result.sizes["private_var"] == 3

        with pytest.raises(ValidationError):
            _ = _read_individual_privatelog_h5(
                h5file_path="abc",
                file_info={"a": 1},
            )

        with pytest.raises(ValidationError):
            _ = _read_individual_privatelog_h5(
                h5file_path=pd.Series([1, 2, 3]),
                file_info=info,
            )

        with pytest.raises(ValueError):
            info = PrivateLogInfo(
                timestamp=ts[:-1],
                variables=["a", "b", "timestamp"],
            )

            _ = _read_individual_privatelog_h5(
                h5file_path=tf1.name,
                file_info=info,
            )

        with pytest.raises(ValueError):
            ts2 = ts
            ts2[0] -= 0.5
            info = PrivateLogInfo(
                timestamp=ts2,
                variables=["a", "b", "timestamp"],
            )

            _ = _read_individual_privatelog_h5(
                h5file_path=tf1.name,
                file_info=info,
            )

    with pytest.raises(KeyError):
        with tempfile.NamedTemporaryFile() as tf1:
            with h5py.File(tf1.name, "w") as f:
                _ = f.create_dataset(
                    name="results",
                    data=df1.drop(columns="timestamp").to_records(index=False),
                )

            info = PrivateLogInfo(
                timestamp=ts,
                variables=["a", "b", "timestamp"],
            )

            _ = _read_individual_privatelog_h5(
                h5file_path=tf1.name,
                file_info=info,
            )

    with pytest.raises(KeyError):
        with tempfile.NamedTemporaryFile() as tf1:
            with h5py.File(tf1.name, "w") as f:
                _ = f.create_dataset(name="resul", data=df1.to_records(index=False))

            info = PrivateLogInfo(
                timestamp=ts,
                variables=["a", "b", "timestamp"],
            )

            _ = _read_individual_privatelog_h5(
                h5file_path=tf1.name,
                file_info=info,
            )


@mock.patch.object(distributed_client.Client, "submit", autospec=True)
def test_h5_to_zarr(mock_submit):
    from pathlib import Path

    files_info = {
        "0.h5": PrivateLogInfo(timestamp=np.array([1, 2]), variables=["a"]),
        "1.h5": PrivateLogInfo(timestamp=np.array([3, 4]), variables=["a", "b"]),
        "2.h5": PrivateLogInfo(timestamp=np.array([5, 6]), variables=["a", "c"]),
    }

    _h5s_privatelogs_to_zarr(
        files_info=files_info,
        allocated_store_path="some_path",
        show_progress=True,
        n_workers=None,
    )
    assert mock_submit.call_count == 3
    mock_submit.reset_mock()

    _h5s_privatelogs_to_zarr(
        files_info=files_info,
        allocated_store_path=Path("some_path"),
        show_progress=True,
        n_workers=None,
    )
    assert mock_submit.call_count == 3
    mock_submit.reset_mock()

    _h5s_privatelogs_to_zarr(
        files_info=files_info,
        allocated_store_path="some_path",
        show_progress=False,
        n_workers=None,
    )
    assert mock_submit.call_count == 3
    mock_submit.reset_mock()

    _h5s_privatelogs_to_zarr(
        files_info=files_info,
        allocated_store_path="some_path",
        show_progress=True,
        n_workers=1,
    )
    assert mock_submit.call_count == 3
    mock_submit.reset_mock()

    with pytest.raises(ValidationError):
        _h5s_privatelogs_to_zarr(
            files_info=pd.Series([1, 2, 3]),
            allocated_store_path="some_path",
            show_progress=True,
            n_workers=1,
        )

    with pytest.raises(ValidationError):
        _h5s_privatelogs_to_zarr(
            files_info=files_info,
            allocated_store_path=np.array([1, 2, 3]),
            show_progress=True,
            n_workers=1,
        )

    with pytest.raises(ValidationError):
        _h5s_privatelogs_to_zarr(
            files_info=files_info,
            allocated_store_path="some_path",
            show_progress=True,
            n_workers={"a": 1.5},
        )
