from contextlib import nullcontext as does_not_raise


import numpy as np
import pytest
from pydantic import ValidationError

from picarro_xarray.io.data_models.prescan_data_structures import PrivateLogInfo
from picarro_xarray.io.utils.prescan_utils import _verify_intervals_distinct, _get_file_origin, _get_time_regions


@pytest.mark.parametrize(
    "sorted_files_info, expectation",
    [
        (
            "broadband_gasConcs_180",
            pytest.raises(ValidationError),
        ),
        (
            ["broadband_gasConcs_180"],
            pytest.raises(ValidationError),
        ),
        (
            {"a": "broadband_gasConcs_180"},
            pytest.raises(ValidationError),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([1, 2, 3]), variables=["a", "b"]
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([3, 5, 6]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([7, 8, 9]), variables=["c", "d"]
                ),
            },
            pytest.raises(ValueError),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([1, 2, 3]), variables=["a", "b"]
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([10, 11, 12]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([15, 18, 20]), variables=["c", "d"]
                ),
            },
            does_not_raise(),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([1, 2, 3]), variables=["a", "b"]
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([4, 5, 6]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([7, 8, 9]), variables=["c", "d"]
                ),
            },
            does_not_raise(),
        ),
    ],
)
def test_verify_intervals_distinct(sorted_files_info, expectation):
    with expectation:
        _verify_intervals_distinct(
            sorted_files_info=sorted_files_info,
        )


@pytest.mark.parametrize(
    "files_info, local_time_zone, expectation",
    [
        (
            "broadband_gasConcs_180",
            "US/Pacific",
            pytest.raises(ValidationError),
        ),
        (
            ["broadband_gasConcs_180"],
            "US/Pacific",
            pytest.raises(ValidationError),
        ),
        (
            {"a": "broadband_gasConcs_180"},
            "US/Pacific",
            pytest.raises(ValidationError),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([1, 2, 3]), variables=["a", "b"]
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([4, 5, 6]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([7, 8, 9]), variables=["c", "d"]
                ),
            },
            {151},
            pytest.raises(ValidationError),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([1, 2, 3]), variables=["a", "b"]
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([4, 5, 6]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([7, 8, 9]), variables=["c", "d"]
                ),
            },
            "US/wherever",
            pytest.raises(ValueError),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([63825842106000, 63825842106001]),
                    variables=["a", "b"],
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([63825842106002]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([63825842106003]), variables=["c", "d"]
                ),
            },
            "US/Pacific",
            does_not_raise(),
        ),
    ],
)
def test_get_file_origin(files_info, local_time_zone, expectation):
    import xarray as xr

    with expectation:
        result = _get_file_origin(
            files_info=files_info,
            local_time_zone=local_time_zone,
        )
        assert isinstance(result, xr.DataArray)
        assert "_datetime" in result.dims
        assert "files" in result.attrs
        total_time_len = sum(len(v.timestamp) for v in files_info.values())
        assert result.sizes["_datetime"] == total_time_len
        assert result.name == "fitter_origin_file"


@pytest.mark.parametrize(
    "files_info, expectation",
    [
        (
            "broadband_gasConcs_180",
            pytest.raises(ValidationError),
        ),
        (
            ["broadband_gasConcs_180"],
            pytest.raises(ValidationError),
        ),
        (
            {"a": "broadband_gasConcs_180"},
            pytest.raises(ValidationError),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([1, 2, 3]), variables=["a", "b"]
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([4, 5, 6]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([7, 8, 9]), variables=["c", "d"]
                ),
            },
            does_not_raise(),
        ),
    ],
)
def test_get_time_regions(files_info, expectation):
    with expectation:
        result = _get_time_regions(
            files_info=files_info,
        )
        assert isinstance(result, dict)
        assert len(result) == len(files_info)

        for key, value in result.items():
            assert isinstance(key, str)
            assert isinstance(value, slice)
