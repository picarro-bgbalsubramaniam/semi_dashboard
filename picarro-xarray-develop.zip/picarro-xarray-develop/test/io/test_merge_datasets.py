import tempfile
import unittest
from unittest import mock

import numpy as np
import pandas as pd
import pytest
import xarray as xr
from pydantic import ValidationError

from picarro_xarray.io.merging.merge_datasets import (
    _sort_and_align_datetimes,
    concat_zarr_stores,
    merge_private_zarr_stores,
)
from picarro_xarray.io.utils.dataset_attributes_setting import set_time_attributes

my_paths = [f"my_path{i // 2}" for i in range(1, 100 + 1)]


@pytest.fixture
def ds_combo():
    paths = [f"my_path{i // 2}" for i in range(1, 10 + 1)]
    ds_combo = xr.Dataset(
        data_vars={
            "spectral_values": (
                ("_datetime", "mode", "spectral_var"),
                np.random.rand(10, 5, 2),
            ),
            "fitter_values": (("_datetime", "fitter_var"), np.random.rand(10, 1)),
            "fitter_origin_file": ("_datetime", paths, {"files": list(set(paths))}),
        },
        coords={
            "_datetime": (
                "_datetime",
                pd.date_range("2020-01-01", periods=10, freq="D"),
            ),
            "mode": ("mode", [0, 2, 4, 6, 8]),
            "spectral_var": ("spectral_var", ["nu", "partial_fit"]),
            "fitter_var": ("fitter_var", ["variable_a"]),
        },
        attrs={
            "tz": "US/Pacific",
            "analyzer": "my_analyzer",
        },
    )
    return ds_combo


@pytest.fixture
def ds_base():
    ds = xr.Dataset(
        data_vars={
            "private_values": (("_datetime", "private_var"), np.random.rand(100, 4)),
            "private_logs_origin": (
                "_datetime",
                my_paths,
                {"files": list(set(my_paths))},
            ),
        },
        attrs={
            "tz": "UTC",
            "analyzer": "my_analyzer",
        },
        coords={
            "_datetime": (
                "_datetime",
                pd.date_range("2022-10-18", periods=100, freq="4s"),
            ),
            "private_var": ("private_var", [f"my_var{i}" for i in range(4)]),
        },
    )
    ds = set_time_attributes(ds)
    return ds


@pytest.fixture
def ds_private():
    paths = [f"my_path{i // 2}" for i in range(1, 10 + 1)]
    ds_private = xr.Dataset(
        data_vars={
            "private_values": (("_datetime", "private_var"), np.ones((10, 1))),
            "private_logs_origin": ("_datetime", paths, {"files": list(set(paths))}),
        },
        coords={
            "_datetime": (
                "_datetime",
                pd.date_range("2020-01-12", periods=10, freq="D"),
            ),
            "private_var": ("private_var", ["private_a"]),
        },
        attrs={
            "tz": "US/Pacific",
            "analyzer": "my_analyzer",
        },
    )
    return ds_private


@pytest.fixture
def ds_mix():
    paths_private = [f"my_path_private{i // 2}" for i in range(1, 12 + 1)]
    paths_combo = [f"my_path_combo{i // 2}" for i in range(1, 12 + 1)]
    ds_mix = xr.Dataset(
        data_vars={
            "spectral_values": (
                ("_datetime", "mode", "spectral_var"),
                np.random.rand(12, 6, 3),
            ),
            "fitter_values": (("_datetime", "fitter_var"), np.random.rand(12, 2)),
            "private_values": (("_datetime", "private_var"), np.random.rand(12, 1)),
            "private_logs_origin": (
                "_datetime",
                paths_private,
                {"files": list(set(paths_private))},
            ),
            "fitter_origin_file": (
                "_datetime",
                paths_combo,
                {"files": list(set(paths_combo))},
            ),
        },
        coords={
            "_datetime": (
                "_datetime",
                pd.date_range("2020-01-24", periods=12, freq="D"),
            ),
            "mode": ("mode", [1, 2, 3, 4, 5, 6]),
            "spectral_var": ("spectral_var", ["nu", "partial_fit", "absorbance"]),
            "fitter_var": ("fitter_var", ["variable_a", "variable_b"]),
            "private_var": ("private_var", ["private_a"]),
        },
        attrs={
            "tz": "US/Pacific",
            "analyzer": "my_analyzer",
        },
    )
    return ds_mix


@pytest.fixture
def ds_combo_tz(ds_combo):
    ds_ret = ds_combo.copy(deep=True)
    ds_ret.attrs["tz"] = "Europe/Paris"
    return ds_ret


@pytest.fixture
def ds_combo_no_tz(ds_combo):
    ds_ret = ds_combo.copy(deep=True)
    ds_ret.attrs.pop("tz")
    return ds_ret


def test_sort_and_align_datetimes(
    ds_combo, ds_private, ds_mix, ds_combo_tz, ds_combo_no_tz
):
    # Import the module to get a reference to the function
    from picarro_xarray.io.merging import merge_datasets

    with mock.patch.object(merge_datasets.xr, "open_zarr") as mock_zarr:
        # regular cases
        mock_zarr.side_effect = lambda input_value: {
            "ds_combo": ds_combo,
            "ds_private": ds_private,
            "ds_mix": ds_mix,
        }.get(input_value)

        result = _sort_and_align_datetimes(["ds_combo", "ds_private"])
        assert isinstance(result, dict)
        assert len(result) == 2
        assert "ds_combo" in result
        assert "ds_private" in result

        result = _sort_and_align_datetimes(["ds_combo", "ds_mix"])
        assert isinstance(result, dict)
        assert len(result) == 2
        assert "ds_combo" in result
        assert "ds_mix" in result

        result = _sort_and_align_datetimes(["ds_mix", "ds_private"])
        assert isinstance(result, dict)
        assert len(result) == 2
        assert "ds_mix" in result
        assert "ds_private" in result

        result = _sort_and_align_datetimes(["ds_combo", "ds_mix", "ds_private"])
        assert isinstance(result, dict)
        assert len(result) == 3
        assert "ds_combo" in result
        assert "ds_private" in result
        assert "ds_mix" in result

        # No tz
        mock_zarr.side_effect = lambda input_value: {
            "ds_combo": ds_combo_no_tz,
            "ds_private": ds_private,
            "ds_mix": ds_mix,
        }.get(input_value)

        with pytest.raises(KeyError):
            _sort_and_align_datetimes(["ds_combo", "ds_private"])

        # Different tz
        mock_zarr.side_effect = lambda input_value: {
            "ds_combo": ds_combo_tz,
            "ds_private": ds_private,
            "ds_mix": ds_mix,
        }.get(input_value)

        with pytest.raises(ValueError):
            _sort_and_align_datetimes(["ds_combo", "ds_private"])

        # overlapping intervals
        ds_overlap = ds_combo.copy(deep=True)
        ds_overlap["_datetime"] = ds_private["_datetime"]

        mock_zarr.side_effect = lambda input_value: {
            "ds_combo": ds_overlap,
            "ds_private": ds_private,
            "ds_mix": ds_mix,
        }.get(input_value)

        result = _sort_and_align_datetimes(["ds_combo", "ds_private", "ds_mix"])
        assert isinstance(result, dict)
        assert len(result) == 2  # ds_private is dropped
        assert "ds_combo" in result
        assert "ds_mix" in result


def test_merge_private_zarr_stores(ds_base):
    from pathlib import Path

    import xarray.backends.api

    # Import the modules to get references to the functions
    from picarro_xarray.io.privatelog import private_log_results

    date_range = pd.date_range("2022-10-18", periods=100, freq="4s")

    dt = pd.date_range("2022-10-19", periods=100, freq="4s")
    my_new_paths = [f"my_new_path{i // 4}" for i in range(1, 100 + 1)]

    private_ds = xr.Dataset(
        data_vars={
            "private_values": (("_datetime", "private_var"), np.random.rand(100, 5)),
            "private_logs_origin": (
                "_datetime",
                my_new_paths,
                {"files": list(set(my_new_paths))},
            ),
        },
        attrs={
            "tz": "UTC",
        },
        coords={
            "_datetime": ("_datetime", dt),
            "private_var": ("private_var", [f"my_var{i}" for i in range(5)]),
        },
    )
    private_ds = set_time_attributes(private_ds)

    with tempfile.TemporaryDirectory(prefix="tmp_zarr_", suffix=".zarr") as temp_zarr:
        with mock.patch.object(
            private_log_results.xr, "open_zarr", return_value=ds_base
        ) as mock_open:
            zarr_store_path = merge_private_zarr_stores(
                zarr_store_path=temp_zarr,
                private_ds=private_ds,
                chunk_time_size=50,
            )
            mock_open.assert_called_once

        ds_result = xr.open_zarr(zarr_store_path)

        assert isinstance(ds_result, xr.Dataset)
        assert pd.Timestamp(ds_result.attrs["Start"]) == min(
            pd.Timestamp(date_range[0]), pd.Timestamp(dt[0])
        )
        assert pd.Timestamp(ds_result.attrs["Stop"]) == max(
            pd.Timestamp(date_range[-1]), pd.Timestamp(dt[-1])
        )
        assert (
            ds_result.sizes["_datetime"]
            == private_ds.sizes["_datetime"] + ds_base.sizes["_datetime"]
        )
        assert ds_result.sizes["private_var"] == max(
            private_ds.sizes["private_var"], ds_base.sizes["private_var"]
        )
        assert set(ds_result.private_var.values) == set(
            private_ds.private_var.values
        ).union(ds_base.private_var.values)
        assert set(ds_result["private_logs_origin"].attrs["files"]) == set(
            my_new_paths
        ).union(my_paths)
        assert (
            len(ds_result["private_logs_origin"])
            == private_ds.sizes["_datetime"] + ds_base.sizes["_datetime"]
        )
        # check datetime is ascending
        assert all(
            ds_result["_datetime"].values[i] <= ds_result["_datetime"].values[i + 1]
            for i in range(len(ds_result["_datetime"]) - 1)
        )

    # check that even if I swap the files order, the time axis is still sorted
    with tempfile.TemporaryDirectory(prefix="tmp_zarr_", suffix=".zarr") as temp_zarr:
        with mock.patch.object(
            private_log_results.xr, "open_zarr", return_value=private_ds
        ) as mock_open:
            zarr_store_path = merge_private_zarr_stores(
                zarr_store_path=Path(temp_zarr),
                private_ds=ds_base,
                chunk_time_size=50,
            )
            mock_open.assert_called_once

        ds_result = xr.open_zarr(zarr_store_path)

        assert isinstance(ds_result, xr.Dataset)
        assert pd.Timestamp(ds_result.attrs["Start"]) == min(
            pd.Timestamp(date_range[0]), pd.Timestamp(dt[0])
        )
        assert pd.Timestamp(ds_result.attrs["Stop"]) == max(
            pd.Timestamp(date_range[-1]), pd.Timestamp(dt[-1])
        )
        assert (
            ds_result.sizes["_datetime"]
            == private_ds.sizes["_datetime"] + ds_base.sizes["_datetime"]
        )
        assert ds_result.sizes["private_var"] == max(
            private_ds.sizes["private_var"], ds_base.sizes["private_var"]
        )
        assert set(ds_result.private_var.values) == set(
            private_ds.private_var.values
        ).union(ds_base.private_var.values)
        assert set(ds_result["private_logs_origin"].attrs["files"]) == set(
            my_new_paths
        ).union(my_paths)
        assert (
            len(ds_result["private_logs_origin"])
            == private_ds.sizes["_datetime"] + ds_base.sizes["_datetime"]
        )
        # check datetime is ascending
        assert all(
            ds_result["_datetime"].values[i] <= ds_result["_datetime"].values[i + 1]
            for i in range(len(ds_result["_datetime"]) - 1)
        )

    with (
        mock.patch.object(
            private_log_results.xr, "open_zarr", return_value=ds_base
        ) as mock_open,
        mock.patch.object(
            xarray.backends.api, "to_zarr", side_effect=ValueError
        ) as mock_write,
    ):
        with pytest.raises(ValueError):
            _ = merge_private_zarr_stores(
                zarr_store_path=temp_zarr,
                private_ds=private_ds,
                chunk_time_size=50,
            )
        mock_open.assert_called_once
        mock_write.assert_called_once

    with pytest.raises(ValidationError):
        _ = merge_private_zarr_stores(
            zarr_store_path=None,
            private_ds=private_ds,
            chunk_time_size=50,
        )

    with pytest.raises(ValidationError):
        _ = merge_private_zarr_stores(
            zarr_store_path="some_path",
            private_ds=None,
            chunk_time_size=50,
        )

    with pytest.raises(ValidationError):
        _ = merge_private_zarr_stores(
            zarr_store_path="some_path",
            private_ds=private_ds,
            chunk_time_size={"abc"},
        )

    with pytest.raises(ValueError):
        _ = merge_private_zarr_stores(
            zarr_store_path="some_path",
            private_ds=private_ds,
            chunk_time_size=-1,
        )

    with pytest.raises(ValueError):
        _ = merge_private_zarr_stores(
            zarr_store_path="some_path",
            private_ds=private_ds.rename({"private_var": "my_var"}),
            chunk_time_size=1,
        )

    with pytest.raises(ValueError):
        _ = merge_private_zarr_stores(
            zarr_store_path="some_path",
            private_ds=private_ds.rename({"private_values": "my_values"}),
            chunk_time_size=1,
        )


class TestMergeZarrStores(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        self.ds_private = request.getfixturevalue("ds_private")
        self.ds_mix = request.getfixturevalue("ds_mix")
        self.ds_combo = request.getfixturevalue("ds_combo")

    def test_concat_zarr_stores(self):
        # Import the module to get a reference to the function
        from picarro_xarray.io.merging import merge_datasets

        with tempfile.TemporaryDirectory(
            suffix="NUVxyzq.zarr", dir="/tmp"
        ) as path_zarr:
            with mock.patch.object(merge_datasets.xr, "open_zarr") as mock_open:
                # regular cases
                mock_open.side_effect = lambda input_value: {
                    "ds_combo": self.ds_combo,
                    "ds_private": self.ds_private,
                    "ds_mix": self.ds_mix,
                }.get(input_value)

                concat_zarr_stores(
                    sources=["ds_private", "ds_mix", "ds_combo"], destination=path_zarr
                )

                mock_open.call_count == 3

            ds_result = xr.open_zarr(path_zarr)
            assert isinstance(ds_result, xr.Dataset)

            # files do not share times
            assert (
                ds_result.sizes["_datetime"]
                == self.ds_combo.sizes["_datetime"]
                + self.ds_mix.sizes["_datetime"]
                + self.ds_private.sizes["_datetime"]
            )

            # private vars are always a superset
            private_var = set()
            for _ds in [self.ds_mix, self.ds_combo, self.ds_private]:
                try:
                    private_var = private_var.union(set(_ds.private_var.values))
                except AttributeError:
                    pass

            assert set(ds_result["private_var"].values) == private_var

            # fitter vars are always a superset
            fitter_var = set()
            for _ds in [self.ds_mix, self.ds_combo, self.ds_private]:
                try:
                    fitter_var = fitter_var.union(set(_ds.fitter_var.values))
                except AttributeError:
                    pass

            assert set(ds_result["fitter_var"].values) == fitter_var

            # mode are always a superset
            mode = set()
            for _ds in [self.ds_mix, self.ds_combo, self.ds_private]:
                try:
                    mode = mode.union(set(_ds.mode.values))
                except AttributeError:
                    pass

            assert set(ds_result["mode"].values) == mode

            # spectral_var are always a superset
            spectral_var = set()
            for _ds in [self.ds_mix, self.ds_combo, self.ds_private]:
                try:
                    spectral_var = spectral_var.union(set(_ds.spectral_var.values))
                except AttributeError:
                    pass

            assert set(ds_result["spectral_var"].values) == spectral_var

            # all private_values in combo_ds datetimes should be null
            assert np.all(
                ds_result.sel(_datetime=self.ds_combo._datetime.values)
                .private_values.isnull()
                .values
            )

            # all fitter_values in private_ds datetimes should be null
            assert np.all(
                ds_result.sel(_datetime=self.ds_private._datetime.values)
                .fitter_values.isnull()
                .values
            )

            ds_result.close()

    def test_concat_overlaps(self):
        # Import the module to get a reference to the function
        from picarro_xarray.io.merging import merge_datasets

        with tempfile.TemporaryDirectory(
            suffix="NUVxyzq.zarr", dir="/tmp"
        ) as path_zarr:
            with mock.patch.object(merge_datasets.xr, "open_zarr") as mock_open:
                # regular cases

                ds_overlap = self.ds_combo.copy(deep=True)
                ds_overlap["_datetime"] = pd.date_range(
                    "2020-01-04", freq="1D", periods=10
                )

                mock_open.side_effect = lambda input_value: {
                    "ds_combo": ds_overlap,
                    "ds_private": self.ds_private,
                    "ds_mix": self.ds_mix,
                }.get(input_value)

                concat_zarr_stores(
                    sources=["ds_combo", "ds_private", "ds_mix"], destination=path_zarr
                )
                mock_open.call_count == 3

            ds_result = xr.open_zarr(path_zarr)
            assert isinstance(ds_result, xr.Dataset)

            # files have overlap times
            dt_expected = (
                pd.DatetimeIndex(ds_overlap["_datetime"].values)
                .union(self.ds_mix["_datetime"].values)
                .union(self.ds_private["_datetime"].values)
            )

            assert len(dt_expected) == ds_result.sizes["_datetime"]

            assert np.all(ds_result["_datetime"].values == dt_expected)

            overlap_dt = pd.DatetimeIndex(ds_overlap["_datetime"].values).difference(
                self.ds_private["_datetime"].values
            )

            # in overlap_dt I expect private_values
            # to be null, as these datetimes are taken
            # from the first dataset chronologically (ds_combo)
            assert np.all(
                ds_result.sel(_datetime=overlap_dt).private_values.isnull().values
            )

            # private vars are always a superset
            private_var = set()
            for _ds in [self.ds_mix, ds_overlap, self.ds_private]:
                try:
                    private_var = private_var.union(set(_ds.private_var.values))
                except AttributeError:
                    pass

            assert set(ds_result["private_var"].values) == private_var

            # fitter vars are always a superset
            fitter_var = set()
            for _ds in [self.ds_mix, ds_overlap, self.ds_private]:
                try:
                    fitter_var = fitter_var.union(set(_ds.fitter_var.values))
                except AttributeError:
                    pass

            assert set(ds_result["fitter_var"].values) == fitter_var

            # mode are always a superset
            mode = set()
            for _ds in [self.ds_mix, ds_overlap, self.ds_private]:
                try:
                    mode = mode.union(set(_ds.mode.values))
                except AttributeError:
                    pass

            assert set(ds_result["mode"].values) == mode

            # spectral_var are always a superset
            spectral_var = set()
            for _ds in [self.ds_mix, ds_overlap, self.ds_private]:
                try:
                    spectral_var = spectral_var.union(set(_ds.spectral_var.values))
                except AttributeError:
                    pass

            assert set(ds_result["spectral_var"].values) == spectral_var

            ds_result.close()

    def test_complete_overlap(self):
        # Import the module to get a reference to the function
        from picarro_xarray.io.merging import merge_datasets

        with tempfile.TemporaryDirectory(
            suffix="NUVxyzq.zarr", dir="/tmp"
        ) as path_zarr:
            with mock.patch.object(merge_datasets.xr, "open_zarr") as mock_open:
                # complete overlap
                ds_overlap = self.ds_combo.copy(deep=True)
                ds_overlap["_datetime"] = self.ds_private["_datetime"]

                mock_open.side_effect = lambda input_value: {
                    "ds_combo": ds_overlap,
                    "ds_private": self.ds_private,
                    "ds_mix": self.ds_mix,
                }.get(input_value)

                concat_zarr_stores(
                    sources=["ds_combo", "ds_private", "ds_mix"], destination=path_zarr
                )
                mock_open.call_count == 3

            ds_result = xr.open_zarr(path_zarr)
            assert isinstance(ds_result, xr.Dataset)

            # files have overlap times
            dt_expected = pd.DatetimeIndex(ds_overlap["_datetime"].values).union(
                self.ds_mix["_datetime"].values
            )

            assert len(dt_expected) == ds_result.sizes["_datetime"]

            assert np.all(ds_result["_datetime"].values == dt_expected)

            overlap_dt = pd.DatetimeIndex(ds_overlap["_datetime"].values).difference(
                self.ds_private["_datetime"].values
            )

            # in overlap_dt I expect private_values
            # to be null, as these datetimes are taken
            # from the first dataset chronologically (ds_combo)
            assert np.all(
                ds_result.sel(_datetime=overlap_dt).private_values.isnull().values
            )

            ds_result.close()

    def test_arguments(self):
        with pytest.raises(ValidationError):
            concat_zarr_stores(sources={"a": 1}, destination="mypath")

        with pytest.raises(ValidationError):
            concat_zarr_stores(sources=["a"], destination=pd.Series([1, 2, 3]))

        with pytest.raises(ValidationError):
            concat_zarr_stores(
                sources=["a"],
                destination="mypath",
                chunk_time_size=np.array([[1, 2, 3], [4, 5, 6]]),
            )

        with pytest.raises(ValidationError):
            concat_zarr_stores(sources=["a"], destination="mypath", chunk_time_size=0)

        with pytest.raises(ValidationError):
            concat_zarr_stores(
                sources=["a"],
                destination="mypath",
                chunk_time_size=1000,
                n_workers={"a": 1},
            )

    def test_no_datasets(self):
        # Import the module to get a reference to the function
        from picarro_xarray.io.merging import merge_datasets

        # no datsets to concat
        with tempfile.TemporaryDirectory(
            suffix="NUVxyzq.zarr", dir="/tmp"
        ) as path_zarr:
            with mock.patch.object(merge_datasets.xr, "open_zarr") as mock_open:
                # regular cases

                ds_overlap = self.ds_combo.copy(deep=True)
                ds_overlap["_datetime"] = self.ds_private["_datetime"]

                mock_open.side_effect = lambda input_value: {
                    "ds_combo": ds_overlap,
                    "ds_private": self.ds_private,
                }.get(input_value)

                with pytest.raises(ValueError):
                    concat_zarr_stores(
                        sources=["ds_combo", "ds_private"], destination=path_zarr
                    )

    def test_check_nonnull(self):
        # Import the module to get a reference to the function
        from picarro_xarray.io.merging import merge_datasets

        with tempfile.TemporaryDirectory(
            suffix="NUVxyzq.zarr", dir="/tmp"
        ) as path_zarr:
            with mock.patch.object(merge_datasets.xr, "open_zarr") as mock_open:
                # regular cases
                mock_open.side_effect = lambda input_value: {
                    "ds_combo": self.ds_combo,
                    "ds_mix": self.ds_mix,
                }.get(input_value)

                concat_zarr_stores(
                    sources=["ds_mix", "ds_combo"], destination=path_zarr
                )

                mock_open.call_count == 3

            ds_result = xr.open_zarr(path_zarr)
            assert isinstance(ds_result, xr.Dataset)

            # check fitter_var="variable_b" (only in ds_mix)
            check_var = "variable_b"
            assert (
                ds_result.sel(
                    fitter_var=check_var, _datetime=self.ds_mix["_datetime"].values
                )
                .fitter_values.notnull()
                .all()
            )

            # when ds_combo, it should be null
            assert (
                ds_result.sel(
                    fitter_var=check_var, _datetime=self.ds_combo["_datetime"].values
                )
                .fitter_values.isnull()
                .all()
            )

            # check mode 2 (all complete for both datasets)
            assert (
                ds_result.sel(mode=2, spectral_var="partial_fit")
                .spectral_values.notnull()
                .all()
            )

            # check mode 0 (only ds_combo is full)
            assert (
                ds_result.sel(
                    mode=0,
                    spectral_var="partial_fit",
                    _datetime=self.ds_combo["_datetime"].values,
                )
                .spectral_values.notnull()
                .all()
            )

            # check mode 0 (only ds_combo is full), when ds_mix, it should be null
            assert (
                ds_result.sel(
                    mode=0,
                    spectral_var="partial_fit",
                    _datetime=self.ds_mix["_datetime"].values,
                )
                .spectral_values.isnull()
                .all()
            )

            # check mode 1 (only ds_mix)
            assert (
                ds_result.sel(
                    mode=1,
                    spectral_var="partial_fit",
                    _datetime=self.ds_mix["_datetime"].values,
                )
                .spectral_values.notnull()
                .all()
            )

            # check mode 1 (only ds_mix), when ds_combo, it should be null
            assert (
                ds_result.sel(
                    mode=1,
                    spectral_var="partial_fit",
                    _datetime=self.ds_combo["_datetime"].values,
                )
                .spectral_values.isnull()
                .all()
            )

            # check spectral_var="absorbance" (only ds_mix)
            assert (
                ds_result.sel(
                    spectral_var="absorbance",
                    _datetime=self.ds_mix["_datetime"].values,
                    mode=self.ds_mix["mode"].values,
                )
                .spectral_values.notnull()
                .all()
            )

            # check spectral_var="absorbance" (only ds_mix), when ds_combo, it should be null
            assert (
                ds_result.sel(
                    spectral_var="absorbance",
                    _datetime=self.ds_combo["_datetime"].values,
                )
                .spectral_values.isnull()
                .all()
            )
