import tempfile
from os import PathLike
from unittest import mock

import h5py
import numpy as np
import pandas as pd
import pytest
from pydantic import ValidationError

from picarro_xarray.io.combolog.combo_log_prescan import (
    ScanKey,
    ScanResult,
    _allocate_combo_zarr_store,
    _get_nu_data,
    _get_nu_key,
    _get_unique_values,
    _scan_combo_log,
    prescan_combo_logs,
)
from picarro_xarray.io.data_models.h5_structures import NuTransformInfo
from picarro_xarray.io.data_models.prescan_data_structures import ComboLogInfo


def test_allocate_combo_zarr_store():
    from pathlib import Path

    import xarray as xr
    import xarray.backends.api

    # Import the module to get a reference to the function
    with mock.patch.object(
        xarray.backends.api, "to_zarr", return_value="mocked"
    ) as mocker:
        zarr_path = Path("my_path")
        local_time_zone = "US/Pacific"
        datetime = pd.date_range("2021-01-01", "2021-01-02", freq="1h")
        fitter_vars = ["a", "b", "c"]
        spectral_vars = ["d", "e", "f"]
        modes = np.array([1, 2, 3]).astype(np.int32)
        analyzer_name = "my_analyzer"
        logs_origin = xr.DataArray(
            len(datetime) * ["my_file"],
            dims=["_datetime"],
            coords={"_datetime": datetime},
        )
        time_chunk = 50

        _allocate_combo_zarr_store(
            zarr_path=zarr_path,
            local_time_zone=local_time_zone,
            datetime=datetime,
            fitter_vars=fitter_vars,
            spectral_vars=spectral_vars,
            modes=modes,
            analyzer_name=analyzer_name,
            fitter_logs_origin=logs_origin,
            chunks={"_datetime": time_chunk},
        )

        assert mocker.called

        with pytest.raises(ValueError):
            # datetime not in coords of fitter_logs_origin
            _allocate_combo_zarr_store(
                zarr_path=zarr_path,
                local_time_zone=local_time_zone,
                datetime=datetime,
                fitter_vars=fitter_vars,
                spectral_vars=spectral_vars,
                modes=modes,
                analyzer_name=analyzer_name,
                fitter_logs_origin=xr.DataArray(
                    len(datetime) * ["my_file"],
                    dims=["abc"],
                    coords={"abc": datetime},
                ),
                time_chunk_size=time_chunk,
            )

        with pytest.raises(ValueError):
            # dimension mismatch
            _allocate_combo_zarr_store(
                zarr_path=zarr_path,
                local_time_zone=local_time_zone,
                datetime=datetime,
                fitter_vars=fitter_vars,
                spectral_vars=spectral_vars,
                modes=modes,
                analyzer_name=analyzer_name,
                fitter_logs_origin=xr.DataArray(
                    (len(datetime) - 1) * ["my_file"],
                    dims=["_datetime"],
                    coords={"_datetime": datetime[:-1]},
                ),
                time_chunk_size=time_chunk,
            )

        with pytest.raises(ValueError):
            # invalid tz
            _allocate_combo_zarr_store(
                zarr_path=zarr_path,
                local_time_zone="My_tz",
                datetime=datetime,
                fitter_vars=fitter_vars,
                spectral_vars=spectral_vars,
                modes=modes,
                analyzer_name=analyzer_name,
                fitter_logs_origin=logs_origin,
                time_chunk_size=time_chunk,
            )

        with pytest.raises(ValidationError):
            # chunk <= 0
            _allocate_combo_zarr_store(
                zarr_path=zarr_path,
                local_time_zone=local_time_zone,
                datetime=datetime,
                fitter_vars=fitter_vars,
                spectral_vars=spectral_vars,
                modes=modes,
                analyzer_name=analyzer_name,
                fitter_logs_origin=logs_origin,
                time_chunk_size=0,
            )

        with pytest.raises(ValidationError):
            _allocate_combo_zarr_store(
                zarr_path=["a", "b"],
                local_time_zone=local_time_zone,
                datetime=datetime,
                fitter_vars=fitter_vars,
                spectral_vars=spectral_vars,
                modes=modes,
                analyzer_name=analyzer_name,
                fitter_logs_origin=logs_origin,
                time_chunk_size=time_chunk,
            )

        with pytest.raises(ValidationError):
            _allocate_combo_zarr_store(
                zarr_path=zarr_path,
                local_time_zone=pd.Series([], dtype=int),
                datetime=datetime,
                fitter_vars=fitter_vars,
                spectral_vars=spectral_vars,
                modes=modes,
                analyzer_name=analyzer_name,
                fitter_logs_origin=logs_origin,
                time_chunk_size=time_chunk,
            )

        with pytest.raises(ValidationError):
            _allocate_combo_zarr_store(
                zarr_path=zarr_path,
                local_time_zone=local_time_zone,
                datetime=[1, 2, 3],
                fitter_vars=fitter_vars,
                spectral_vars=spectral_vars,
                modes=modes,
                analyzer_name=analyzer_name,
                fitter_logs_origin=logs_origin,
                time_chunk_size=time_chunk,
            )

        with pytest.raises(ValidationError):
            _allocate_combo_zarr_store(
                zarr_path=zarr_path,
                local_time_zone=local_time_zone,
                datetime=datetime,
                fitter_vars=np.array([1, 2, 3]),
                spectral_vars=spectral_vars,
                modes=modes,
                analyzer_name=analyzer_name,
                fitter_logs_origin=logs_origin,
                time_chunk_size=time_chunk,
            )

        with pytest.raises(ValidationError):
            _allocate_combo_zarr_store(
                zarr_path=zarr_path,
                local_time_zone=local_time_zone,
                datetime=datetime,
                fitter_vars=fitter_vars,
                spectral_vars={"1": "a", "2": "b", "3": "c"},
                modes=modes,
                analyzer_name=analyzer_name,
                fitter_logs_origin=logs_origin,
                time_chunk_size=time_chunk,
            )

        with pytest.raises(ValidationError):
            _allocate_combo_zarr_store(
                zarr_path=zarr_path,
                local_time_zone=local_time_zone,
                datetime=datetime,
                fitter_vars=fitter_vars,
                spectral_vars=spectral_vars,
                modes=pd.Series([1, 2, 3]),
                analyzer_name=analyzer_name,
                fitter_logs_origin=logs_origin,
                time_chunk_size=time_chunk,
            )

        with pytest.raises(ValidationError):
            _allocate_combo_zarr_store(
                zarr_path=zarr_path,
                local_time_zone=local_time_zone,
                datetime=datetime,
                fitter_vars=fitter_vars,
                spectral_vars=spectral_vars,
                modes=modes,
                analyzer_name=None,
                fitter_logs_origin=logs_origin,
                time_chunk_size=time_chunk,
            )

        with pytest.raises(ValidationError):
            _allocate_combo_zarr_store(
                zarr_path=zarr_path,
                local_time_zone=local_time_zone,
                datetime=datetime,
                fitter_vars=fitter_vars,
                spectral_vars=spectral_vars,
                modes=modes,
                analyzer_name=analyzer_name,
                fitter_logs_origin=pd.Series([1, 2, 3]),
                time_chunk_size=time_chunk,
            )

        with pytest.raises(ValidationError):
            _allocate_combo_zarr_store(
                zarr_path=zarr_path,
                local_time_zone=local_time_zone,
                datetime=datetime,
                fitter_vars=fitter_vars,
                spectral_vars=spectral_vars,
                modes=modes,
                analyzer_name=analyzer_name,
                fitter_logs_origin=logs_origin,
                time_chunk_size="avbc",
            )


def test_get_nu_keys():
    with tempfile.NamedTemporaryFile() as tf:
        with h5py.File(tf, "w") as f:
            # results timestamp not present
            with pytest.raises(KeyError):
                _get_nu_key(h5file=f, query_keys=["my_key"])

            f["results/timestamp"] = np.zeros(20)
            f["results/mykey"] = np.ones(20)

            # No key found
            with pytest.raises(KeyError):
                _get_nu_key(h5file=f, query_keys=["my_key"])

            # Default value used
            res = _get_nu_key(h5file=f, query_keys=["my_key"], default_value=5.0)
            assert isinstance(res, np.ndarray)
            assert np.allclose(res, np.ones(20) * 5.0)

            # Regular return value
            res = _get_nu_key(
                h5file=f, query_keys=["my_key", "mykey"], default_value=5.0
            )
            assert isinstance(res, np.ndarray)
            assert np.allclose(res, f["results/mykey"])

            with pytest.raises(ValidationError):
                _get_nu_key(
                    h5file="123", query_keys=["my_key", "mykey"], default_value=5.0
                )

            with pytest.raises(ValidationError):
                _get_nu_key(
                    h5file=f, query_keys=pd.Series([1, 2, 3]), default_value=5.0
                )

            with pytest.raises(ValidationError):
                _get_nu_key(
                    h5file=f, query_keys=["my_key", "mykey"], default_value=None
                )


def test_get_nu_data():
    with tempfile.NamedTemporaryFile() as tf:
        with h5py.File(tf, "w") as f:
            f["results/timestamp"] = np.zeros(20)
            f["results/f0"] = np.ones(20)
            f["results/fitData_fitdata_params_nucenter"] = np.ones(20)
            f["results/fitData_nu_transform_n0"] = np.ones(20)
            f["results/fitData_nu_transform_n1"] = np.ones(20)

            res = _get_nu_data(f)
            assert isinstance(res, NuTransformInfo)

            with pytest.raises(ValidationError):
                _get_nu_data(h5file="abc")


def test_get_unique_values():
    with tempfile.NamedTemporaryFile() as tf1, tempfile.NamedTemporaryFile() as tf2:
        with h5py.File(tf1, "w") as f1, h5py.File(tf2, "w") as f2:
            mode = ScanKey.FITTER_VARIABLES
            f1[mode.value] = ["d", "a", "b"]
            f2[mode.value] = ["b", "d", "a", "c"]

        res = _get_unique_values(files_list=[tf1.name, tf2.name], key_=mode)
        assert isinstance(res, list)
        assert res == ["a", "b", "c", "d"]

        with pytest.raises(KeyError):
            _get_unique_values(
                files_list=[tf1.name, tf2.name], key_=ScanKey.SPECTRAL_VARIABLES
            )

        with h5py.File(tf1, "w") as f1, h5py.File(tf2, "w") as f2:
            mode = ScanKey.MODES
            f1[mode.value] = [2, 3]
            f2[mode.value] = [5, 4, 1]

        res = _get_unique_values(files_list=[tf1.name, tf2.name], key_=mode)
        assert isinstance(res, list)
        assert res == [1, 2, 3, 4, 5]

        with pytest.raises(ValidationError):
            _get_unique_values(files_list=[tf1.name, tf2.name], key_="abc")

        with pytest.raises(ValidationError):
            _get_unique_values(files_list={"a": 1, "b": 2}, key_=mode)


def test_scan_combo_log():
    with tempfile.NamedTemporaryFile() as tf1:
        f0 = 0.0205
        with h5py.File(tf1, "w") as f:
            len_t = 100
            f["results/timestamp"] = 1e9 * np.arange(0, len_t) + 63819453033178
            f["results/f0"] = np.ones(len_t) * f0
            f["results/mybad"] = ["ohno!"] * len_t
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            f["results/some_private"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])

        with tempfile.TemporaryDirectory() as td:
            ret = _scan_combo_log(
                filename=tf1.name,
                export_folder=td,
            )
            assert isinstance(ret, (str, PathLike))

            # test roundtrip behavior
            test_roundtrip = ComboLogInfo.import_from_h5(ret)
            assert isinstance(test_roundtrip, ComboLogInfo)
            assert len(test_roundtrip.modes) == len_t
            assert test_roundtrip.fsr.shape[0] == len_t
            assert len(test_roundtrip.nu_prime) == len_t
            assert "mybad" not in test_roundtrip.variables

    with tempfile.NamedTemporaryFile() as tf1:
        f0 = 0.0205
        with h5py.File(tf1, "w") as f:
            len_t = 100
            f["results/timestamp"] = 1e9 * np.arange(0, len_t) + 63819453033178
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            f["results/some_private"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])
                del f[f"spectra/{i}/nu"]

        with tempfile.TemporaryDirectory() as td:
            with pytest.raises(KeyError):
                # nu not found
                _ = _scan_combo_log(
                    filename=tf1.name,
                    export_folder=td,
                )

    with tempfile.NamedTemporaryFile() as tf1:
        f0 = 0.0205
        with h5py.File(tf1, "w") as f:
            len_t = 100
            f["results/timestamp"] = 1e9 * np.arange(0, len_t) + 63819453033178
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            f["results/some_private"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])

            del f["results/timestamp"]

        with tempfile.TemporaryDirectory() as td:
            with pytest.raises(KeyError):
                # timestamp not found
                _ = _scan_combo_log(
                    filename=tf1.name,
                    export_folder=td,
                )

    with tempfile.NamedTemporaryFile() as tf1:
        f0 = 0.0205
        with h5py.File(tf1, "w") as f:
            len_t = 100
            f["results/timestamp"] = 1e9 * np.arange(0, len_t) + 63819453033178
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            f["results/some_private"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])

            # force a mode bin error
            weird_nu = f["spectra/1/nu"]
            weird_nu[1] = weird_nu[1] + f0 / 2
            del f["spectra/1/nu"]
            f["spectra/1/nu"] = weird_nu

        with tempfile.TemporaryDirectory() as td:
            ret = _scan_combo_log(
                filename=tf1.name,
                export_folder=td,
            )
            assert isinstance(ret, (str, PathLike))

            # test roundtrip behavior
            test_roundtrip = ComboLogInfo.import_from_h5(ret)
            assert isinstance(test_roundtrip, ComboLogInfo)
            assert len(test_roundtrip.modes) == len_t
            assert test_roundtrip.fsr.shape[0] == len_t
            assert len(test_roundtrip.nu_prime) == len_t
            assert test_roundtrip.modes[1].size == 0
            assert test_roundtrip.mode_bin_errors == 1


def test_prescan_combo_logs():
    # Import the module to get a reference to the function
    import dask.bag

    with mock.patch.object(dask.bag.Bag, "compute") as mock_compute:
        # Setup mock to return successful results
        mock_compute.return_value = [
            ScanResult(original_file="a", output_file="a_prescan", success=True),
            ScanResult(original_file="b", output_file="b_prescan", success=True),
        ]

        result = prescan_combo_logs(["a", "b"], tmp_dir="/tmp")
        assert isinstance(result, dict)
        assert len(result) == 2
        assert result == {"a": "a_prescan", "b": "b_prescan"}

        # Test with some failures and on_error="ignore"
        mock_compute.return_value = [
            ScanResult(original_file="a", output_file="a_prescan", success=True),
            ScanResult(
                original_file="b",
                success=False,
                error_message="Failed to process H5 file. Corrupted?. Error: test error",
            ),
        ]

        result = prescan_combo_logs(["a", "b"], tmp_dir="/tmp", on_error="ignore")
        assert isinstance(result, dict)
        assert len(result) == 1
        assert result == {"a": "a_prescan"}

        # Test with failures and on_error="raise"
        mock_compute.return_value = [
            ScanResult(original_file="a", output_file="a_prescan", success=True),
            ScanResult(
                original_file="b",
                success=False,
                error_message="Failed to process H5 file. Corrupted?. Error: test error",
            ),
        ]

        with pytest.raises(ValueError, match="Failed to process H5 file"):
            prescan_combo_logs(["a", "b"], tmp_dir="/tmp", on_error="raise")

        # Test validation errors
        with pytest.raises(ValidationError):
            prescan_combo_logs({"a": 1, "b": 2}, tmp_dir="/tmp")

        with pytest.raises(ValidationError):
            prescan_combo_logs(tmp_dir={"a": 1, "b": 2}, files_list=["a", "b"])


def test_safe_scan_combo_log():
    """Test the _safe_scan_combo_log function that wraps _scan_combo_log with error handling."""
    from picarro_xarray.io.combolog.combo_log_prescan import (
        FAIL_MESSAGE,
        _safe_scan_combo_log,
    )

    # Test with a valid file
    with tempfile.NamedTemporaryFile() as tf1:
        f0 = 0.0205
        with h5py.File(tf1, "w") as f:
            len_t = 10
            f["results/timestamp"] = 1e9 * np.arange(0, len_t) + 63819453033178
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])

        with tempfile.TemporaryDirectory() as td:
            result = _safe_scan_combo_log(filename=tf1.name, export_folder=td)
            assert result.success is True
            assert result.original_file == tf1.name
            assert result.output_file is not None
            assert result.error_message is None

    # Test with an invalid file (missing required data)
    with tempfile.NamedTemporaryFile() as tf2:
        with h5py.File(tf2, "w") as f:
            # Create an invalid H5 file (missing timestamp)
            f["results/some_data"] = np.zeros(10)

        with tempfile.TemporaryDirectory() as td:
            result = _safe_scan_combo_log(filename=tf2.name, export_folder=td)
            assert result.success is False
            assert result.original_file == tf2.name
            assert result.output_file is None
            assert FAIL_MESSAGE in result.error_message

    # Test with a non-existent file
    with tempfile.TemporaryDirectory() as td:
        result = _safe_scan_combo_log(filename="nonexistent_file.h5", export_folder=td)
        assert result.success is False
        assert result.original_file == "nonexistent_file.h5"
        assert result.output_file is None
        assert FAIL_MESSAGE in result.error_message
