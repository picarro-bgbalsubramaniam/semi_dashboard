import tempfile
from pathlib import Path
from unittest import mock
from unittest.mock import patch

import h5py
import numpy as np
import pandas as pd
import pytest
import xarray as xr
from pydantic import ValidationError

from picarro_xarray.io.utils.api_utils import (
    FileTypeEnum,
    check_for_overlapping_files,
    get_analyzer_name,
    get_dataset_summary,
    get_existing_zarr_store_path,
    get_h5_combolog_paths,
)
from picarro_xarray.time_utils.timeutils import get_start_end_time

date_range = pd.date_range("2022-10-18", periods=100, freq="4s")
DS = xr.Dataset(
    data_vars={
        "private_values": (("_datetime", "private_var"), np.random.rand(100, 4)),
        "private_logs_origin": (
            "_datetime",
            [f"my_path{i // 2}" for i in range(1, 100 + 1)],
        ),
    },
    attrs={"Start": str(date_range[0]), "Stop": str(date_range[-1]), "tz": "UTC"},
    coords={
        "_datetime": ("_datetime", pd.date_range("2022-10-17", periods=100, freq="4s")),
        "private_var": ("private_var", [f"my_var{i}" for i in range(4)]),
    },
)


def mocked_ds(path):
    return DS


def test_get_analyzer_name():
    FILE = "/foo/junk_NUV1047_stuff"
    assert get_analyzer_name(FILE) == "NUV1047"

    with pytest.raises(ValueError):
        FILE = "/foo/bar/jun3k/2stuff1"
        get_analyzer_name(FILE)


def test_check_for_overlapping_files():
    file_list = ["/tmp/NUV1047_1", "/tmp/NUV1047_2"]
    assert (
        check_for_overlapping_files(file_list, "foo", FileTypeEnum.combologs)
        == file_list
    )

    with tempfile.TemporaryDirectory(suffix="NUV1047.zarr", dir="/tmp"):
        assert (
            check_for_overlapping_files(
                file_list, "/tmp/NUV1047.zarr", FileTypeEnum.combologs
            )
            == file_list
        )

    time_len = 10
    datetime_ = list(range(time_len))
    private_logs_origin = xr.DataArray(
        ["file1"] * 5 + ["file2"] * 5,
        dims="_datetime",
        coords={"_datetime": datetime_},
        name="private_logs_origin",
        attrs={"files": ["file1", "file2"]},
    )
    fitter_origin_file = xr.DataArray(
        ["file3"] * 5 + ["file4"] * 5,
        dims="_datetime",
        coords={"_datetime": datetime_},
        name="fitter_origin_file",
        attrs={"files": ["file3", "file4"]},
    )
    ds_origin = xr.Dataset(
        data_vars={
            "private_logs_origin": private_logs_origin,
            "fitter_origin_file": fitter_origin_file,
            "_datetime": datetime_,
        }
    )

    # Import the module to get a reference to the function
    from picarro_xarray.io.utils import api_utils

    with (
        mock.patch.object(api_utils.xr, "open_zarr", return_value=ds_origin),
        mock.patch.object(api_utils.Path, "exists"),
    ):
        result = check_for_overlapping_files(
            ["file1", "file2", "file4"], "some_path", FileTypeEnum.combologs
        )
        assert set(result) == {"file1", "file2"}  # file4 is present

        result = check_for_overlapping_files(
            ["file2", "file3", "file4"], "some_path", FileTypeEnum.privatelogs
        )
        assert set(result) == {"file3", "file4"}  # file2 is present


def test_get_start_end_time():
    """Test that we get correct start and end times"""
    # Import the module to get references to the functions
    from picarro_xarray.time_utils import timeutils

    with (
        patch.object(timeutils.Path, "exists", return_value=True),
        patch.object(timeutils.xr, "open_zarr", return_value=mocked_ds("my_path")),
    ):
        start, stop = get_start_end_time("my_path")
        assert str(start) == "2022-10-18 00:00:00"
        assert str(stop) == "2022-10-18 00:06:36"

    with patch.object(timeutils.Path, "exists", return_value=False):
        with pytest.raises(ValueError):
            get_start_end_time("foo")

    with patch.object(timeutils.Path, "exists", return_value=True):
        with pytest.raises(ValueError):
            get_start_end_time("my_path", time_zone="foo")

        # Test different time zone
        with patch.object(timeutils.xr, "open_zarr", return_value=mocked_ds("my_path")):
            start, stop = get_start_end_time("my_path", "America/Los_Angeles")
            assert str(start) == "2022-10-17 17:00:00"
            assert str(stop) == "2022-10-17 17:06:36"

            # Test repr
            start, stop = get_start_end_time("my_path", return_format="%Y%m%d")
            assert str(start) == "20221018"
            assert str(stop) == "20221018"


def test_get_h5_files_path():
    with tempfile.NamedTemporaryFile(prefix="/tmp/", suffix="_broadband_123.h5") as tf1:
        f0 = 0.0205

        with h5py.File(tf1, "w") as f:
            len_t = 100
            f["results/timestamp"] = 1e9 * np.arange(0, len_t) + 63798364799150.86
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])

        my_dir = str(Path(tf1.name).parent)
        res = get_h5_combolog_paths(folder_path=my_dir, fitter_name="broadband")
        assert isinstance(res, list)
        assert len(res) == 1

        with pytest.raises(FileNotFoundError):
            _ = get_h5_combolog_paths(folder_path=my_dir, fitter_name="narrowband")

        with pytest.raises(FileNotFoundError):
            _ = get_h5_combolog_paths(
                folder_path="my_other_dir", fitter_name="broadband"
            )

    with pytest.raises(ValidationError):
        _ = get_h5_combolog_paths(folder_path={}, fitter_name="abc")

    with pytest.raises(ValidationError):
        _ = get_h5_combolog_paths(folder_path=my_dir, fitter_name=[])


def test_get_dataset_summary():
    res = get_dataset_summary(DS)
    assert isinstance(res, str)
    assert "_datetime" in res

    with pytest.raises(ValidationError):
        get_dataset_summary("abc")

    with pytest.raises(ValueError, match=r".*_datetime.*"):
        test_ds = DS.copy(deep=True)
        test_ds = test_ds.rename({"_datetime": "abc"})
        get_dataset_summary(test_ds)


def test_get_existing_zarr_store_path():
    with tempfile.TemporaryDirectory(dir="/tmp") as tmp_dir:
        dir_path = Path(tmp_dir)

        assert get_existing_zarr_store_path(dir_path) is None

        fname = dir_path / "test.zarr"
        fname.touch()

        # one file
        assert get_existing_zarr_store_path(tmp_dir) == fname

        fname = dir_path / "test2.zarr"
        fname.touch()

        with pytest.raises(ValueError):
            # too many files
            get_existing_zarr_store_path(tmp_dir)
