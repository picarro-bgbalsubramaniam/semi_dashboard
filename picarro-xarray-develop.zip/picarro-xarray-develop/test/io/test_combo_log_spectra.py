import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock
from unittest.mock import patch

import h5py
import numpy as np
import pandas as pd
import pytest
import xarray as xr
from pydantic import ValidationError

from picarro_xarray.data_models.constants import TIME_DIM
from picarro_xarray.io.combolog.combo_log_prescan import _scan_combo_log
from picarro_xarray.io.combolog.combo_log_spectra import (
    _read_combolog_to_dataset,
    _write_combologs_to_zarr,
    _write_individual_combolog,
    read_combo_logs,
)
from picarro_xarray.io.data_models.prescan_data_structures import ComboLogInfo


def test_read_combolog_to_dataset():
    f0 = 0.0205
    nu = np.arange(start=0, stop=1, step=f0)
    time_len = 2

    with (
        tempfile.NamedTemporaryFile() as h5file,
        tempfile.TemporaryDirectory(dir="/tmp") as tmp_folder,
    ):
        with h5py.File(h5file, "w") as f:
            f["results/timestamp"] = np.arange(0, time_len) + 63819453033178
            f["results/f0"] = np.ones(time_len) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(time_len)
            f["results/fitData_nu_transform_n0"] = np.zeros(time_len)
            f["results/fitData_nu_transform_n1"] = np.zeros(time_len)
            f["spectra/0/nu"] = nu
            f["spectra/0/absorbance"] = np.ones_like(f["spectra/0/nu"])
            f["spectra/1/nu"] = nu
            f["spectra/1/absorbance"] = np.ones_like(f["spectra/1/nu"])
            f["results/variable_a"] = np.ones(time_len)

        prescan_path = _scan_combo_log(filename=h5file.name, export_folder=tmp_folder)

        result = _read_combolog_to_dataset(
            h5file_path=h5file.name, prescan_path=prescan_path
        )
        assert isinstance(result, xr.Dataset)
        assert result.sizes["_datetime"] == time_len
        assert result.sizes["spectral_var"] == (2 + 1)  # +1 for nu_prime
        assert result.sizes["fitter_var"] == 6 + 1  # +1 for fsr
        assert result.sizes["mode"] == nu.shape[0]
        assert all(
            var_ in result.data_vars for var_ in ["spectral_values", "fitter_values"]
        )
        assert all(
            var_ in result.dims
            for var_ in ["_datetime", "spectral_var", "fitter_var", "mode"]
        )
        assert "nu_prime" in result.spectral_var.values

    with (
        tempfile.NamedTemporaryFile() as h5file,
        tempfile.TemporaryDirectory(dir="/tmp") as tmp_folder,
    ):
        with h5py.File(h5file, "w") as f:
            f["results/timestamp"] = np.arange(0, 2) + 63819453033178
            f["results/f0"] = np.ones(2) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(2)
            f["results/fitData_nu_transform_n0"] = np.zeros(2)
            f["results/fitData_nu_transform_n1"] = np.zeros(2)
            f["spectra/0/nu"] = np.append(nu, 1.05)
            f["spectra/0/absorbance"] = np.ones_like(f["spectra/0/nu"])
            f["spectra/1/nu"] = nu
            f["spectra/1/absorbance"] = np.ones_like(f["spectra/1/nu"])

        prescan_path = _scan_combo_log(filename=h5file.name, export_folder=tmp_folder)

        result = _read_combolog_to_dataset(
            h5file_path=h5file.name, prescan_path=prescan_path
        )
        assert isinstance(result, xr.Dataset)
        assert result.sizes["_datetime"] == time_len
        assert result.sizes["spectral_var"] == (2 + 1)  # +1 for nu_prime
        assert result.sizes["fitter_var"] == 5 + 1  # +1 for fsr
        assert all(
            var_ in result.data_vars for var_ in ["spectral_values", "fitter_values"]
        )
        assert all(
            var_ in result.dims
            for var_ in ["_datetime", "spectral_var", "fitter_var", "mode"]
        )
        assert "nu_prime" in result.spectral_var.values

        # spectra/0/nu has length 50, but it is not mode binned succesfully:
        # only 49 bins are detected (from the nu_prime that are binned ok)
        assert result.sizes["mode"] == nu.shape[0]

        # spectral values on failed datetime are left empty
        assert np.all(result.isel(_datetime=0).spectral_values.isnull().values)

    with (
        tempfile.NamedTemporaryFile() as h5file,
        tempfile.TemporaryDirectory(dir="/tmp") as tmp_folder,
    ):
        with h5py.File(h5file, "w") as f:
            f["results/timestamp"] = np.arange(0, time_len) + 63819453033178
            f["results/f0"] = np.ones(time_len) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(time_len)
            f["results/fitData_nu_transform_n0"] = np.zeros(time_len)
            f["results/fitData_nu_transform_n1"] = np.zeros(time_len)
            f["spectra/0/nu"] = nu
            f["spectra/0/absorbance"] = np.ones_like(f["spectra/0/nu"])
            f["spectra/1/nu"] = nu
            f["spectra/1/absorbance"] = np.ones_like(f["spectra/1/nu"])
            f["spectra/1/my_custom_var"] = np.ones_like(f["spectra/1/nu"])
            f["results/variable_a"] = np.ones(time_len)

        prescan_path = _scan_combo_log(filename=h5file.name, export_folder=tmp_folder)

        result = _read_combolog_to_dataset(
            h5file_path=h5file.name, prescan_path=prescan_path
        )
        assert isinstance(result, xr.Dataset)
        assert result.sizes["_datetime"] == time_len
        assert result.sizes["spectral_var"] == (3 + 1)  # +1 for nu_prime
        assert result.sizes["fitter_var"] == 6 + 1  # +1 for fsr
        assert result.sizes["mode"] == nu.shape[0]
        assert all(
            var_ in result.data_vars for var_ in ["spectral_values", "fitter_values"]
        )
        assert all(
            var_ in result.dims
            for var_ in ["_datetime", "spectral_var", "fitter_var", "mode"]
        )
        assert "nu_prime" in result.spectral_var.values
        assert "my_custom_var" in result.spectral_var.values
        assert np.all(
            result.isel(_datetime=0)
            .sel(spectral_var="my_custom_var")
            .spectral_values.isnull()
            .values
        )

        with pytest.raises(ValidationError):
            _read_combolog_to_dataset(
                h5file_path=pd.Series([1, 2, 3]), prescan_path=prescan_path
            )

        with pytest.raises(ValidationError):
            _read_combolog_to_dataset(h5file_path=h5file.name, prescan_path={"a": 1})

        # trigger timestamp mismatch
        my_info = ComboLogInfo.import_from_h5(import_path=prescan_path)
        my_info.timestamp = np.array([1, 2]).astype(np.int64)

        prescan_path_new = my_info.to_h5(export_path=Path(tmp_folder) / "new.h5")

        with pytest.raises(ValueError):
            _read_combolog_to_dataset(
                h5file_path=h5file.name, prescan_path=prescan_path_new
            )

    # trigger key error when accessing timestamp
    with (
        tempfile.NamedTemporaryFile() as h5file,
        tempfile.TemporaryDirectory(dir="/tmp") as tmp_folder,
    ):
        with h5py.File(h5file, "w") as f:
            f["results/timestamp"] = np.arange(0, time_len) + 63819453033178
            f["results/f0"] = np.ones(time_len) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(time_len)
            f["results/fitData_nu_transform_n0"] = np.zeros(time_len)
            f["results/fitData_nu_transform_n1"] = np.zeros(time_len)
            f["spectra/0/nu"] = nu
            f["spectra/0/absorbance"] = np.ones_like(f["spectra/0/nu"])
            f["spectra/1/nu"] = nu
            f["spectra/1/absorbance"] = np.ones_like(f["spectra/1/nu"])
            f["spectra/1/my_custom_var"] = np.ones_like(f["spectra/1/nu"])
            f["results/variable_a"] = np.ones(time_len)

        prescan_path = _scan_combo_log(filename=h5file.name, export_folder=tmp_folder)

        result = _read_combolog_to_dataset(
            h5file_path=h5file.name, prescan_path=prescan_path
        )
        assert isinstance(result, xr.Dataset)

        with h5py.File(h5file, "a") as f:
            del f["results/timestamp"]

        with pytest.raises(KeyError):
            _read_combolog_to_dataset(
                h5file_path=h5file.name, prescan_path=prescan_path
            )


def test_write_individual_combolog():
    import xarray.backends.api
    from dask.distributed import Client

    # Import the modules to get references to the functions
    from picarro_xarray.io.combolog import combo_log_spectra

    with Client():
        ds = xr.Dataset(
            data_vars={
                "spectral_values": (
                    ("mode", "_datetime", "spectral_var"),
                    np.ones((2, 10, 2)),
                ),
            },
            coords={
                "_datetime": pd.date_range("2020-01-01", periods=10, freq="1s"),
                "mode": [0, 1],
                "spectral_var": ["nu", "my_custom_var"],
                "fitter_var": [
                    "f0",
                    "n0",
                    "n1",
                    "variable_a",
                    "variable_b",
                    "variable_c",
                    "fsr",
                ],
            },
        )

        # nu prime not in spectral_var
        with mock.patch.object(combo_log_spectra.xr, "open_zarr", return_value=ds):
            with pytest.raises(ValueError):
                _write_individual_combolog(
                    h5file_path="some_path",
                    prescan_path="some_path",
                    zarr_path="some_path",
                    time_region=slice(0, 10),
                )

        ds = xr.Dataset(
            data_vars={
                "spectral_values": (
                    ("mode", "_datetime", "spectral_var"),
                    np.ones((2, 10, 3)),
                ),
            },
            coords={
                "_datetime": pd.date_range("2020-01-01", periods=10, freq="1s"),
                "mode": [0, 1],
                "spectral_var": ["nu", "nu_prime", "my_custom_var"],
                "fitter_var": [
                    "f0",
                    "n0",
                    "n1",
                    "variable_a",
                    "variable_b",
                    "variable_c",
                    "fsr",
                ],
            },
        )

        # something goes wrong with reading the combolog prescan files
        with (
            mock.patch.object(combo_log_spectra.xr, "open_zarr", return_value=ds),
            mock.patch.object(
                combo_log_spectra, "_read_combolog_to_dataset", side_effect=KeyError
            ),
        ):
            with pytest.raises(ValueError):
                _write_individual_combolog(
                    h5file_path="some_path",
                    prescan_path="some_path",
                    zarr_path="some_path",
                    time_region=slice(0, 10),
                )

        with (
            mock.patch.object(combo_log_spectra.xr, "open_zarr", return_value=ds),
            mock.patch.object(
                combo_log_spectra, "_read_combolog_to_dataset", side_effect=ValueError
            ),
        ):
            with pytest.raises(ValueError):
                _write_individual_combolog(
                    h5file_path="some_path",
                    prescan_path="some_path",
                    zarr_path="some_path",
                    time_region=slice(0, 10),
                )

        ds2 = xr.Dataset(
            data_vars={
                "spectral_values": (
                    ("mode", "_datetime", "spectral_var"),
                    np.ones((2, 10, 2)),
                ),
            },
            coords={
                "_datetime": pd.date_range("2022-01-01", periods=10, freq="1s"),
                "mode": [0, 0],
                "spectral_var": ["nu", "my_custom_var"],
                "fitter_var": [
                    "f0",
                    "n0",
                    "n1",
                    "variable_a",
                    "variable_b",
                    "variable_c",
                    "fsr",
                ],
            },
        )

        # duplicate coordinate, reindex fails
        with (
            mock.patch.object(combo_log_spectra.xr, "open_zarr", return_value=ds),
            mock.patch.object(
                combo_log_spectra, "_read_combolog_to_dataset", return_value=ds2
            ),
        ):
            with pytest.raises(ValueError):
                _write_individual_combolog(
                    h5file_path="some_path",
                    prescan_path="some_path",
                    zarr_path="some_path",
                    time_region=slice(0, 10),
                )

        ds2 = xr.Dataset(
            coords={
                "_datetime": pd.date_range("2020-01-01", periods=10, freq="1s"),
                "mode": [0, 1, 2, 3],
                "spectral_var": ["nu", "nu_prime", "my_custom_var"],
                "fitter_var": [
                    "f0",
                    "n0",
                    "n1",
                    "variable_a",
                    "variable_b",
                    "variable_c",
                    "variable_d",
                    "fsr",
                ],
            }
        )

        with (
            mock.patch.object(combo_log_spectra.xr, "open_zarr", return_value=ds),
            mock.patch.object(
                combo_log_spectra, "_read_combolog_to_dataset", return_value=ds2
            ),
            mock.patch.object(xarray.backends.api, "to_zarr") as mock_write,
        ):
            _write_individual_combolog(
                h5file_path="mock_to_zarr",
                prescan_path="some_path",
                zarr_path="some_path",
                time_region=slice(0, 10),
            )
            mock_write.assert_called_once()

            with pytest.raises(ValidationError):
                _write_individual_combolog(
                    h5file_path={"a": 1},
                    prescan_path="some_path",
                    zarr_path="some_path",
                    time_region=slice(0, 10),
                )

            with pytest.raises(ValidationError):
                _write_individual_combolog(
                    h5file_path="some_path",
                    prescan_path={"a": 1},
                    zarr_path="some_path",
                    time_region=slice(0, 10),
                )

            with pytest.raises(ValidationError):
                _write_individual_combolog(
                    h5file_path="some_path",
                    prescan_path="some_path",
                    zarr_path={"a": 1},
                    time_region=slice(0, 10),
                )

            with pytest.raises(ValidationError):
                _write_individual_combolog(
                    h5file_path="some_path",
                    prescan_path="some_path",
                    zarr_path="some_path",
                    time_region=np.array([1, 2, 3, 4, 5, 6]),
                )


def test_write_combologs_to_zarr():
    from pathlib import Path

    import distributed.client

    # Import the module to get a reference to the function
    with mock.patch.object(
        distributed.client.Client, "submit", autospec=True
    ) as mock_submit:
        files_info = {"a": "a_prescan", "b": "b_prescan", "c": "c_prescan"}
        regions = {"a": slice(0, 10), "b": slice(10, 20), "c": slice(20, 30)}

        _write_combologs_to_zarr(
            files_info=files_info,
            regions=regions,
            allocated_store_path="some_path",
            show_progress=True,
            n_workers=None,
        )
        assert mock_submit.call_count == 3
        mock_submit.reset_mock()

        _write_combologs_to_zarr(
            files_info=files_info,
            regions=regions,
            allocated_store_path=Path("some_path"),
            show_progress=True,
            n_workers=None,
        )
        assert mock_submit.call_count == 3
        mock_submit.reset_mock()

        _write_combologs_to_zarr(
            files_info=files_info,
            regions=regions,
            allocated_store_path="some_path",
            show_progress=False,
            n_workers=None,
        )
        assert mock_submit.call_count == 3
        mock_submit.reset_mock()

        _write_combologs_to_zarr(
            files_info=files_info,
            regions=regions,
            allocated_store_path="some_path",
            show_progress=True,
            n_workers=1,
        )
        assert mock_submit.call_count == 3
        mock_submit.reset_mock()

        # region and files_info keys mismatch
        with pytest.raises(ValueError):
            _write_combologs_to_zarr(
                files_info=files_info,
                regions={"a": slice(0, 10)},
                allocated_store_path="some_path",
                show_progress=True,
                n_workers=1,
            )

        with pytest.raises(ValidationError):
            _write_combologs_to_zarr(
                files_info=pd.Series([1, 2, 3]),
                regions=regions,
                allocated_store_path="some_path",
                show_progress=True,
                n_workers=1,
            )

        with pytest.raises(ValidationError):
            _write_combologs_to_zarr(
                files_info=files_info,
                regions=pd.Series([1, 2, 3]),
                allocated_store_path="some_path",
                show_progress=True,
                n_workers=1,
            )

        with pytest.raises(ValidationError):
            _write_combologs_to_zarr(
                files_info=files_info,
                regions=regions,
                allocated_store_path=np.array([1, 2, 3]),
                show_progress=True,
                n_workers=1,
            )

        with pytest.raises(ValidationError):
            _write_combologs_to_zarr(
                files_info=files_info,
                regions=regions,
                allocated_store_path="some_path",
                show_progress=True,
                n_workers={"a": 1.5},
            )


class TestReadComboLogs(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory(dir="/tmp")
        f1, f2 = self.create_temp_files()
        self.file1 = f1
        self.file2 = f2

        # Import modules to get references to the functions
        import os
        import shutil

        from picarro_xarray.io.combolog import combo_log_prescan, combo_log_spectra

        self.patch_rename = patch.object(os, "rename")
        self.patch_get_combo_paths = patch.object(
            combo_log_spectra, "get_h5_combolog_paths"
        )
        self.patch_rmtree = patch.object(shutil, "rmtree")
        self.patch_preallocate = patch.object(
            combo_log_prescan, "_allocate_combo_zarr_store"
        )
        self.patch_write_zarr = patch.object(
            combo_log_spectra, "_write_combologs_to_zarr"
        )

        self.mock_rename = self.patch_rename.start()
        self.mock_get_combo_paths = self.patch_get_combo_paths.start()
        self.mock_rmtree = self.patch_rmtree.start()
        self.mock_preallocate = self.patch_preallocate.start()
        self.mock_write_zarr = self.patch_write_zarr.start()

    def create_temp_files(self):
        f0 = 0.0205
        nu1 = np.arange(start=0, stop=1, step=f0)
        nu2 = np.arange(start=f0, stop=1 + f0, step=f0)
        time_len = 2

        file1 = Path(self.temp_dir.name) / "NUV1047_broadband_0_prescan.h5"
        with h5py.File(file1, "w") as f:
            f["results/timestamp"] = np.arange(0, time_len) + 63819453033178
            f["results/f0"] = np.ones(time_len) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(time_len)
            f["results/fitData_nu_transform_n0"] = np.zeros(time_len)
            f["results/fitData_nu_transform_n1"] = np.zeros(time_len)
            f["spectra/0/nu"] = nu1
            f["spectra/0/absorbance"] = np.ones_like(f["spectra/0/nu"])
            f["spectra/1/nu"] = nu1
            f["spectra/1/absorbance"] = np.ones_like(f["spectra/1/nu"])
            f["results/variable_a"] = np.ones(time_len)
            end_time = f["results/timestamp"][-1]

        file2 = Path(self.temp_dir.name) / "NUV1047_broadband_1_prescan.h5"
        with h5py.File(file2, "w") as f2:
            f2["results/timestamp"] = np.arange(end_time + 1, end_time + 1 + time_len)
            f2["results/f0"] = np.ones(time_len) * f0
            f2["results/fitData_fitdata_params_nucenter"] = np.zeros(time_len)
            f2["results/fitData_nu_transform_n0"] = np.zeros(time_len)
            f2["results/fitData_nu_transform_n1"] = np.zeros(time_len)
            f2["spectra/2/nu"] = nu2
            f2["spectra/2/absorbance"] = np.ones_like(f2["spectra/2/nu"])
            f2["spectra/3/nu"] = nu2
            f2["spectra/3/absorbance"] = np.ones_like(f2["spectra/3/nu"])
            f2["results/variable_b"] = np.ones(time_len)

        return file1, file2

    def tearDown(self):
        # Clean up patches
        self.patch_rename.stop()
        self.patch_rmtree.stop()
        self.patch_get_combo_paths.stop()
        self.patch_preallocate.stop()
        self.patch_write_zarr.stop()

        # Clean up the temporary directory
        self.temp_dir.cleanup()

    def test_arguments(self):
        with pytest.raises(ValidationError):
            read_combo_logs(
                folder_path=None,
                local_time_zone="US/Pacific",
                path_to_zarr=self.temp_dir,
                analyzer_name="NUV1041",
                chunks={TIME_DIM: 1000},
                fitter_name="broadband",
            )

        with pytest.raises(ValidationError):
            read_combo_logs(
                folder_path=self.temp_dir,
                local_time_zone=[],
                path_to_zarr=self.temp_dir,
                analyzer_name="NUV1041",
                chunks={TIME_DIM: 1000},
                fitter_name="broadband",
            )

        with pytest.raises(ValidationError):
            read_combo_logs(
                folder_path=self.temp_dir,
                local_time_zone="US/Pacific",
                path_to_zarr=self.temp_dir,
                analyzer_name=np.array([1, 2, 3]),
                chunks={TIME_DIM: 1000},
                fitter_name="broadband",
            )

        with pytest.raises(ValidationError):
            read_combo_logs(
                folder_path=self.temp_dir,
                local_time_zone="US/Pacific",
                path_to_zarr=self.temp_dir,
                analyzer_name="NUV1041",
                chunks={TIME_DIM: 1000},
                fitter_name={"a": 1},
            )

        # Can't find tz
        with pytest.raises(ValueError):
            read_combo_logs(
                folder_path=self.temp_dir,
                local_time_zone="mytz",
                path_to_zarr=self.temp_dir,
                analyzer_name="NUV1041",
                chunks={TIME_DIM: 1000},
                fitter_name="broadband",
            )

    def test_no_unique_files(self):
        from picarro_xarray.io.combolog import combo_log_spectra

        self.mock_get_combo_paths.return_value = ["NUV1047_0.h5", "NUV1047_1.h5"]

        # No unique files
        with mock.patch.object(
            combo_log_spectra, "check_for_overlapping_files", return_value=[]
        ) as mock_overlap:
            res = read_combo_logs(
                folder_path=self.temp_dir.name,
                local_time_zone="US/Pacific",
                path_to_zarr=Path(self.temp_dir.name),
                analyzer_name="NUV1041",
                chunks={TIME_DIM: 1000},
                fitter_name="broadband",
            )
            mock_overlap.assert_called_once
            assert isinstance(res, (str | os.PathLike))

    def test_working_case(self):
        from pathlib import Path

        from picarro_xarray.io.combolog import combo_log_spectra

        # working case
        self.mock_get_combo_paths.return_value = [self.file1, self.file2]

        with (
            mock.patch.object(Path, "exists", return_value=True) as mock_exist,
            mock.patch.object(
                combo_log_spectra, "concat_zarr_stores", return_value="path"
            ) as mock_concat,
            mock.patch.object(
                combo_log_spectra,
                "check_for_overlapping_files",
                return_value=self.mock_get_combo_paths.return_value,
            ) as mock_overlap,
        ):
            read_combo_logs(
                folder_path=self.temp_dir.name,
                local_time_zone="US/Pacific",
                path_to_zarr=self.temp_dir.name,
                analyzer_name="NUV1041",
                chunks={TIME_DIM: 1000},
                fitter_name="broadband",
                allowed_spectral_vars=["absorbance"],
            )

            self.mock_get_combo_paths.assert_called_once
            mock_overlap.assert_called_once
            self.mock_preallocate.assert_called_once
            self.mock_write_zarr.assert_called_once

            self.mock_rmtree.call_count == 4

            mock_exist.assert_called_once
            mock_concat.assert_called_once
            self.mock_rename.assert_called_once

    def test_no_preexisting_zarr(self):
        import os
        from pathlib import Path

        from picarro_xarray.io.combolog import combo_log_spectra

        with (
            mock.patch.object(Path, "exists", return_value=False) as mock_exist,
            mock.patch.object(os, "rename") as mock_os_rename,
            mock.patch.object(
                combo_log_spectra, "check_for_overlapping_files", return_value=[]
            ) as mock_overlap,
        ):
            self.mock_get_combo_paths.return_value = [self.file1, self.file2]

            read_combo_logs(
                folder_path=self.temp_dir.name,
                local_time_zone="US/Pacific",
                path_to_zarr=self.temp_dir.name,
                analyzer_name="NUV1041",
                chunks={TIME_DIM: 1000},
                fitter_name="broadband",
            )

            self.mock_get_combo_paths.assert_called_once
            mock_overlap.assert_called_once
            self.mock_preallocate.assert_called_once
            self.mock_write_zarr.assert_called_once
            self.mock_rmtree.call_count == 3
            mock_exist.assert_called_once
            mock_os_rename.assert_called_once
            self.mock_rename.assert_called_once

    def test_working_default_analyzer_name(self):
        import os
        from pathlib import Path

        from picarro_xarray.io.combolog import combo_log_spectra

        # working case with default analyzer name
        with (
            mock.patch.object(Path, "exists", return_value=False) as mock_exist,
            mock.patch.object(os, "rename") as mock_os_rename,
            mock.patch.object(
                combo_log_spectra, "check_for_overlapping_files", return_value=[]
            ) as mock_overlap,
        ):
            self.mock_get_combo_paths.return_value = [str(self.file1), str(self.file2)]

            read_combo_logs(
                folder_path=self.temp_dir.name,
                local_time_zone="US/Pacific",
                path_to_zarr=self.temp_dir.name,
                fitter_name="broadband",
            )

            self.mock_get_combo_paths.assert_called_once
            mock_overlap.assert_called_once
            self.mock_preallocate.assert_called_once
            self.mock_write_zarr.assert_called_once
            self.mock_rmtree.call_count == 3
            mock_exist.assert_called_once
            mock_os_rename.assert_called_once
            self.mock_rename.assert_called_once

    def test_working_default_chunks(self):
        import os
        from pathlib import Path

        from picarro_xarray.io.combolog import combo_log_spectra

        # working case with default chunking
        with (
            mock.patch.object(Path, "exists", return_value=False) as mock_exist,
            mock.patch.object(os, "rename") as mock_os_rename,
            mock.patch.object(
                combo_log_spectra, "check_for_overlapping_files", return_value=[]
            ) as mock_overlap,
        ):
            self.mock_get_combo_paths.return_value = [str(self.file1), str(self.file2)]

            read_combo_logs(
                folder_path=self.temp_dir.name,
                local_time_zone="US/Pacific",
                path_to_zarr=self.temp_dir.name,
                analyzer_name="NUV1041",
                fitter_name="broadband",
            )

            self.mock_get_combo_paths.assert_called_once
            mock_overlap.assert_called_once
            self.mock_preallocate.assert_called_once
            self.mock_write_zarr.assert_called_once
            self.mock_rmtree.call_count == 3
            mock_exist.assert_called_once
            mock_os_rename.assert_called_once
            self.mock_rename.assert_called_once
