# compound-hunting

compound-hunting

## About

`compound-hunting` is the newest python library developed and maintained by Picarro.

## Installation

The prefered method is to install via `pip`. If you are a developer, you can use `make` to develop locally.

```bash
make develop
```

This will create a `virtualenv` environment with the name `venv`. The environment should be activated and deactivated with the commands `source venv/bin/activate` and `deactivate`, respectively, from the root of this code repository.

## Tests

Use the following command to run unit tests, integration tests, doctests, and coverage analysis.

```bash
make test
```

## Auto-documentation

Use the following command to generate documentation.

```bash
make docs
```

See [here](https://www.sphinx-doc.org/en/master/usage/quickstart.html) for more information on [sphinx](https://www.sphinx-doc.org/en/master/index.html)

***

## Docker

Tests and Auto-documentation can also be run/generated using Docker

### Docker Tests

```bash
docker-compose run tests
```

### Docker Auto-Documentation

```bash
docker-compose run docs
```

***

## Usage

TODO: Add example usage here

## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## License

Copyright 2024 Picarro Inc.
