import unittest

import pandas as pd
from numpy.testing import assert_array_almost_equal

from compound_hunting.preprocessing.global_scaler import GlobalScaler


class TestGlobalScaler(unittest.TestCase):
    def setUp(self):
        """Create a sample DataFrame with known statistics"""
        # overall mean = 3.75, overall std = 2.16506
        self.Y = pd.DataFrame(
            {
                "A": [1.0, 2.0, 3.0, 4.0],  # mean=2.5, std=1.11803
                "B": [2.0, 4.0, 6.0, 8.0],
            }
        )

    def test_fit_transform_dataframe(self):
        gs = GlobalScaler(with_mean=True, with_std=True)
        transformed = gs.fit_transform(self.Y)

        self.assertIsInstance(transformed, pd.DataFrame)
        self.assertAlmostEqual(transformed.values.mean(), 0, places=10)
        self.assertAlmostEqual(transformed.values.std(), 1, places=10)

        reconstructed = gs.inverse_transform(transformed)
        assert_array_almost_equal(reconstructed, self.Y)

        self.assertAlmostEqual(gs.global_mean_, 3.75, places=3)
        self.assertAlmostEqual(gs.global_std_, 2.16506, places=3)

    def test_fit_transform_series(self):
        s = pd.Series([1, 2, 3, 4, 5, 6, 3, 2, 1, 0])
        gs = GlobalScaler(with_mean=True, with_std=True)
        transformed = gs.fit_transform(s)

        # Check output type
        self.assertIsInstance(transformed, pd.Series)

        # Check if mean is close to 0 and std is close to 1
        self.assertAlmostEqual(transformed.mean(), 0, places=3)

        # Check inverse transform
        reconstructed = gs.inverse_transform(transformed)
        assert_array_almost_equal(reconstructed, s)

        self.assertAlmostEqual(gs.global_mean_, 2.7, places=3)
        self.assertAlmostEqual(gs.global_std_, 1.791647, places=3)

    def test_without_centering(self):
        gs = GlobalScaler(with_mean=False)
        transformed = gs.fit_transform(self.Y)

        # Check that the mean wasn't subtracted
        self.assertEqual(gs.global_mean_, 0)
        reconstructed = gs.inverse_transform(transformed)
        assert_array_almost_equal(reconstructed, self.Y)

    def test_without_scaling(self):
        gs = GlobalScaler(with_std=False)
        transformed = gs.fit_transform(self.Y)

        # Check that the std wasn't applied
        self.assertIsNotNone(gs.global_mean_)
        self.assertEqual(gs.global_std_, 1)

        # Check inverse transform
        reconstructed = gs.inverse_transform(transformed)
        assert_array_almost_equal(reconstructed, self.Y)

    def test_transform_without_fit(self):
        gs = GlobalScaler()

        with self.assertRaises(ValueError):
            gs.transform(self.Y)

    def test_no_op(self):
        gs = GlobalScaler(with_mean=False, with_std=False)
        transformed = gs.fit_transform(self.Y)
        assert_array_almost_equal(transformed, self.Y)
