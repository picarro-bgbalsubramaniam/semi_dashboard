import unittest

import jax.numpy as jnp
import numpy as np
from sklearn.datasets import make_regression
from sklearn.model_selection import KFold, ShuffleSplit

from compound_hunting.preprocessing.cross_validation import (
    _check_splits_length,
    get_jax_train_test_split,
)


class TestCheckSplitsLength(unittest.TestCase):
    def test_valid_splits(self):
        valid_splits = [
            (np.array([0, 1, 2]), np.array([3, 4])),
            (np.array([1, 2, 3]), np.array([0, 4])),
            (np.array([2, 3, 4]), np.array([0, 1])),
        ]
        _check_splits_length(valid_splits)

    def test_invalid_train_splits(self):
        invalid_train_splits = [
            (np.array([0, 1]), np.array([2, 3])),
            (np.array([0, 1, 2]), np.array([3, 4])),
            (np.array([0, 1, 2, 3]), np.array([4, 5])),
        ]
        with self.assertRaises(ValueError) as context:
            _check_splits_length(invalid_train_splits)
        self.assertTrue("train" in str(context.exception))

    def test_invalid_test_splits(self):
        invalid_test_splits = [
            (np.array([0, 1, 2]), np.array([3])),
            (np.array([0, 1, 2]), np.array([3, 4])),
            (np.array([0, 1, 2]), np.array([3, 4, 5])),
        ]
        with self.assertRaises(ValueError) as context:
            _check_splits_length(invalid_test_splits)
        self.assertTrue("test" in str(context.exception))


class TestGetJaxTrainTestSplit(unittest.TestCase):
    def test_kfold_failure_non_multiple(self):
        # Create dataset with length not divisible by n_splits
        X, y = make_regression(n_samples=22, n_features=5, noise=0.1, random_state=42)
        cv = KFold(n_splits=5)

        with self.assertRaises(ValueError):
            get_jax_train_test_split(X, y, cv)

    def test_kfold_success_multiple(self):
        # Create dataset with length divisible by n_splits
        X, y = make_regression(n_samples=25, n_features=5, noise=0.1, random_state=42)
        cv = KFold(n_splits=5)

        train_indices, test_indices = get_jax_train_test_split(X, y, cv)

        self.assertIsInstance(train_indices, jnp.ndarray)
        self.assertIsInstance(test_indices, jnp.ndarray)
        self.assertEqual(train_indices.shape, (5, 20))
        self.assertEqual(test_indices.shape, (5, 5))

    def test_shuffle_split_always_works(self):
        # Test with different dataset sizes
        for n_samples in [22, 25, 30]:
            X, y = make_regression(
                n_samples=n_samples, n_features=5, noise=0.1, random_state=42
            )
            cv = ShuffleSplit(n_splits=5, test_size=0.2, random_state=42)

            train_indices, test_indices = get_jax_train_test_split(X, y, cv)

            self.assertIsInstance(train_indices, jnp.ndarray)
            self.assertIsInstance(test_indices, jnp.ndarray)
            self.assertEqual(train_indices.shape[0], 5)
            self.assertEqual(test_indices.shape[0], 5)
            self.assertEqual(train_indices.shape[1] + test_indices.shape[1], n_samples)

    def test_no_cv(self):
        n_samples = 25
        X, y = make_regression(
            n_samples=n_samples, n_features=5, noise=0.1, random_state=42
        )
        cv = None

        train_indices, test_indices = get_jax_train_test_split(X, y, cv)

        self.assertIsInstance(train_indices, jnp.ndarray)
        self.assertIsInstance(test_indices, jnp.ndarray)
        self.assertEqual(train_indices.shape, (1, n_samples))
        self.assertEqual(test_indices.shape, (1, n_samples))
        self.assertTrue(jnp.array_equal(train_indices, test_indices))
        assert np.unique(train_indices).size == n_samples
