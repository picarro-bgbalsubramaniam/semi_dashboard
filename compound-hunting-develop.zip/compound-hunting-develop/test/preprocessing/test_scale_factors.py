import unittest

import jax.numpy as jnp
import numpy as np
from sklearn.preprocessing import StandardScaler

from compound_hunting.transformers.millipede_transformer import get_scale_factors


class TestGetScaleFactors(unittest.TestCase):
    def test_with_fitted_scaler(self):
        """Test get_scale_factors with a fitted scaler that has the expected attribute."""
        # Create and fit a scaler
        scaler = StandardScaler()
        X = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
        scaler.fit(X)

        # Get scale factors with expected size equal to number of features
        expected_size = X.shape[1]
        result = get_scale_factors(scaler, expected_size)

        # Check that the result matches the scaler's scale_ attribute
        np.testing.assert_array_equal(result, scaler.scale_)

    def test_with_default_scale(self):
        """Test get_scale_factors with a scaler that doesn't have the expected attribute."""
        # Create an unfitted scaler (no scale_ attribute)
        scaler = StandardScaler()
        expected_size = 5

        # Get scale factors with an expected size
        result = get_scale_factors(scaler, expected_size)

        # Should return an array of ones with length equal to expected_size
        expected_result = jnp.ones(expected_size)
        np.testing.assert_array_equal(result, expected_result)

    def test_with_smaller_scale(self):
        """Test get_scale_factors when the scale attribute is smaller than expected_size."""
        # Create a scaler with a scale_ attribute smaller than expected_size
        scaler = StandardScaler()
        scaler.scale_ = np.array([2.0, 3.0])  # Only 2 elements
        expected_size = 5  # But we expect 5

        # Get scale factors
        result = get_scale_factors(scaler, expected_size)

        # Should prepend ones to the original scale to match expected_size
        expected_result = jnp.array([1.0, 1.0, 1.0, 2.0, 3.0])
        np.testing.assert_array_equal(result, expected_result)

    def test_custom_attribute_name(self):
        """Test get_scale_factors with a custom attribute name."""
        # Create a scaler with a custom attribute
        scaler = StandardScaler()
        scaler.custom_scale = np.array([2.0, 3.0, 4.0])
        expected_size = 3

        # Get scale factors with custom attribute name
        result = get_scale_factors(scaler, expected_size, attr_name="custom_scale")

        # Should use the custom attribute
        expected_result = scaler.custom_scale
        np.testing.assert_array_equal(result, expected_result)

    def test_no_scaler(self):
        """Test get_scale_factors with no scaler."""
        expected_size = 3
        result = get_scale_factors(None, expected_size)
        expected_result = jnp.ones(expected_size)
        np.testing.assert_array_equal(result, expected_result)
