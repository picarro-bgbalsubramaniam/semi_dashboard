import numpy as np
import pandas as pd
import pytest

from compound_hunting.preprocessing.nan_filter import (
    get_nan_rows_mask,
    impute_nans_by_row,
    apply_row_filter,
)


@pytest.fixture
def data_2d():
    return np.array(
        [
            [1, 2, np.nan, 4],
            [np.nan, np.nan, np.nan, 4],
            [np.nan, 2, 3, 4],
            [np.nan, np.nan, np.nan, np.nan],
            [np.nan, np.nan, np.nan, np.nan],
        ]
    )

@pytest.fixture
def data_2d_has_good():
    return np.array(
        [
            [1, 2, 3, 4],
            [np.nan, np.nan, np.nan, 4],
            [np.nan, 2, 3, 4],
            [np.nan, np.nan, np.nan, np.nan],
            [np.nan, np.nan, np.nan, np.nan],
        ]
    )


@pytest.fixture
def data_1d():
    return np.array([1, np.nan, 3, np.nan, 5])


class TestGetNanRowsMask:
    def test_filter_nan_rows_2d(self, data_2d):
        result = get_nan_rows_mask(data_2d, nan_threshold=0.5)
        assert result.ndim == 1
        assert result.shape[0] == data_2d.shape[0]
        assert len(result[result]) == 2

    def test_filter_nan_rows_2d_remove_all(self, data_2d):
        with pytest.raises(ValueError):
            get_nan_rows_mask(data_2d, nan_threshold=0.1)

    def test_filter_nan_rows_1d(self, data_1d):
        result = get_nan_rows_mask(data_1d, nan_threshold=0.5)
        assert result.ndim == 1
        assert result.shape[0] == data_1d.shape[0]
        assert len(result[result]) == 3
    
    def test_filter_remove_any_2d(self, data_2d_has_good):
        result = get_nan_rows_mask(data_2d_has_good, 0)

        assert result[0]
        assert not any(result[1:])
    
    def test_filter_remove_any_1d(self, data_1d):
        result = get_nan_rows_mask(data_1d, 0)

        assert result.ndim == 1
        assert result.shape[0] == data_1d.shape[0]
        assert len(result[result])==3


class TestImputeNansByRow:
    def test_impute_nans_by_row_2d(self, data_2d):
        result = impute_nans_by_row(data_2d)
        expected = np.array(
            [
                [1, 2, 2.33333333, 4],
                [4, 4, 4, 4],
                [3, 2, 3, 4],
                [np.nan, np.nan, np.nan, np.nan],
                [np.nan, np.nan, np.nan, np.nan],
            ]
        )
        np.testing.assert_array_almost_equal(result, expected)

    def test_impute_pandas_2d(self, data_2d):
        df_data_2d = pd.DataFrame(data_2d)
        result = impute_nans_by_row(df_data_2d)
        expected = np.array(
            [
                [1, 2, 2.33333333, 4],
                [4, 4, 4, 4],
                [3, 2, 3, 4],
                [np.nan, np.nan, np.nan, np.nan],
                [np.nan, np.nan, np.nan, np.nan],
            ]
        )
        assert isinstance(result, pd.DataFrame)
        np.testing.assert_array_almost_equal(result, expected)

    def test_impute_nans_by_row_1d(self, data_1d):
        result = impute_nans_by_row(data_1d)
        expected = np.array([1, np.nan, 3, np.nan, 5])
        np.testing.assert_array_equal(result, expected)

    def test_impute_pandas_1d(self, data_1d):
        s_data_1d = pd.Series(data_1d)
        result = impute_nans_by_row(s_data_1d)
        expected = np.array([1, np.nan, 3, np.nan, 5])
        assert isinstance(result, pd.Series)
        np.testing.assert_array_equal(result, expected)

    def test_impute_nans_by_row_empty(self):
        data_empty = np.array([])
        result = impute_nans_by_row(data_empty)
        np.testing.assert_array_equal(result, data_empty)


class TestApplyRowFilter:
    def test_return(self, data_2d, data_1d):
        mask = np.ones(data_2d.shape[0], dtype=bool)
        mask[0] = False

        (result,) = apply_row_filter(data_2d, keep_rows_mask=mask)
        assert result.ndim == 2
        assert result.shape[0] == data_2d.shape[0] - 1
        assert result.shape[1] == data_2d.shape[1]

        data_2, data_1 = apply_row_filter(data_2d, data_1d, keep_rows_mask=mask)
        assert data_2.ndim == 2
        assert data_2.shape[0] == data_2d.shape[0] - 1
        assert data_2.shape[1] == data_2d.shape[1]

        assert data_1.ndim == 1
        assert data_1.shape[0] == data_1d.shape[0] - 1

    def test_pandas(self, data_2d, data_1d):
        mask = np.ones(data_2d.shape[0], dtype=bool)
        mask[0] = False

        df_data_2d = pd.DataFrame(data_2d)
        s_data_1d = pd.Series(data_1d)

        (result,) = apply_row_filter(df_data_2d, keep_rows_mask=mask)
        assert result.ndim == 2
        assert result.shape[0] == data_2d.shape[0] - 1
        assert result.shape[1] == data_2d.shape[1]

        data_2, data_1 = apply_row_filter(df_data_2d, s_data_1d, keep_rows_mask=mask)
        assert data_2.ndim == 2
        assert data_2.shape[0] == data_2d.shape[0] - 1
        assert data_2.shape[1] == data_2d.shape[1]

        assert data_1.ndim == 1
        assert data_1.shape[0] == data_1d.shape[0] - 1

    def test_different_len(self, data_2d):
        mask = np.ones(data_2d.shape[0], dtype=bool)

        with pytest.raises(ValueError):
            apply_row_filter(np.array([1, 2, 3]), data_2d, keep_rows_mask=mask)
