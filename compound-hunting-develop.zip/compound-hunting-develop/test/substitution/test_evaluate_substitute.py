import numpy as np
import jax.numpy as jnp
import pandas as pd

from compound_hunting.substitution.evaluate_substitute import (
    substitute_pca_metric,
    substitute_cond_ratio_metric,
)


def test_substitute_pca_metric():
    original = np.array([1, 2, 3, 4, 5])
    substitute = np.array([1, 2, 3, 4, 5])
    result = substitute_pca_metric(original, substitute)
    assert result.size == 1
    assert np.issubdtype(result.dtype, np.floating)

    original = np.array([1, 2, 3, 4, 5])
    substitute = np.array([5, 4, 3, 2, 1])
    result = substitute_pca_metric(original, substitute)
    assert result.size == 1
    assert np.issubdtype(result.dtype, np.floating)

    original = np.array([1, 2, 3, 4, 5])
    substitute = np.array([[1, 2, 3, 0, 0], [0, 0, 0, 4, 5]]).T
    result = substitute_pca_metric(original, substitute)
    assert result.size == 1
    assert np.issubdtype(result.dtype, np.floating)

    original = jnp.array([1, 2, 3, 4, 5])
    substitute = jnp.array([[1, 2, 3, 0, 0], [0, 0, 0, 4, 5]]).T
    result = substitute_pca_metric(original, substitute)
    assert result.size == 1
    assert np.issubdtype(result.dtype, np.floating)

    original = pd.Series([1, 2, 3, 4, 5])
    substitute = pd.DataFrame([[1, 2, 3, 0, 0], [0, 0, 0, 4, 5]]).T
    result = substitute_pca_metric(original, substitute)
    assert result.size == 1
    assert np.issubdtype(result.dtype, np.floating)

def test_substitute_cond_metric():
    original = np.array([1, 2, 3, 4, 5])
    substitute = np.array([1, 2, 3, 4, 5])
    result = substitute_cond_ratio_metric(original, substitute)
    assert result.size == 1
    assert np.issubdtype(result.dtype, np.floating)

    original = np.array([1, 2, 3, 4, 5])
    substitute = np.array([5, 4, 3, 2, 1])
    result = substitute_cond_ratio_metric(original, substitute)
    assert result.size == 1
    assert np.issubdtype(result.dtype, np.floating)

    original = np.array([1, 2, 3, 4, 5])
    substitute = np.array([[1, 2, 3, 0, 0], [0, 0, 0, 4, 5]]).T
    result = substitute_cond_ratio_metric(original, substitute)
    assert result.size == 1
    assert np.issubdtype(result.dtype, np.floating)

    original = jnp.array([1, 2, 3, 4, 5])
    substitute = jnp.array([[1, 2, 3, 0, 0], [0, 0, 0, 4, 5]]).T
    result = substitute_cond_ratio_metric(original, substitute)
    assert result.size == 1
    assert np.issubdtype(result.dtype, np.floating)

    original = pd.Series([1, 2, 3, 4, 5])
    substitute = pd.DataFrame([[1, 2, 3, 0, 0], [0, 0, 0, 4, 5]]).T
    result = substitute_cond_ratio_metric(original, substitute)
    assert result.size == 1
    assert np.issubdtype(result.dtype, np.floating)
