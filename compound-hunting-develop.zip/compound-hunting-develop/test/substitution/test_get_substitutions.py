import pandas as pd

from compound_hunting.substitution.substitution_data.get_substitutions import get_one_to_two, get_one_to_one


def test_get_one_to_two():
    data = get_one_to_two()
    assert isinstance(data, dict)
    assert len(data) > 450  # just verify there's data there
    first_key = list(data.keys())[0]
    assert isinstance(first_key, int)
    assert isinstance(data[first_key], pd.Series)
    first_pd_index = data[first_key].index[0]
    assert isinstance(first_pd_index, tuple)
    assert len(first_pd_index) == 2


def test_get_one_to_one():
    data = get_one_to_one()
    assert isinstance(data, dict)
    assert len(data) > 450  # just verify there's data there
    first_key = list(data.keys())[0]
    assert isinstance(first_key, int)
    assert isinstance(data[first_key], pd.Series)
    first_pd_index = data[first_key].index[0]
    assert isinstance(first_pd_index, tuple)
    assert len(first_pd_index) == 1
