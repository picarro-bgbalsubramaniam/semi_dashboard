import unittest

import pandas as pd
from sklearn.datasets import make_regression

from compound_hunting.assessment.scorers import bic_score, r2_score
from compound_hunting.substitution.evaluate_alternative_solutions import (
    evaluate_equilength_solutions,
    evaluate_simpler_solutions,
    _filter_available_substitutions,
)


class EvaluateAlternativesEquilength(unittest.TestCase):
    def setUp(self):
        n_features = 10
        X, Y = make_regression(
            n_samples=50, n_features=n_features, n_targets=2, n_informative=6
        )
        feature_names = [int(i) for i in range(n_features)]

        self.X = pd.DataFrame(X, columns=feature_names)
        self.Y = pd.DataFrame(Y, columns=["t1", "t2"])

        one_to_one_substitutes = {
            1: pd.Series({(5,): 0.9, (6,): 0.95}),
            2: pd.Series({(4,): 0.9, (9,): 0.95}),
            3: pd.Series({(1,): 0.9, (5,): 0.95}),
            4: pd.Series(dtype=float),
            5: pd.Series({(1,): 0.9}),
            6: pd.Series({(1,): 0.9}),
            7: pd.Series({(9,): 0.9}),
            8: pd.Series(dtype=float),
        }

        self.one_to_one = one_to_one_substitutes
        self.selected_cids = [1, 4, 2]

    def test_success_series(self):
        records = evaluate_equilength_solutions(
            X=self.X,
            Y=self.Y.mean(axis=1),
            selected_cids=self.selected_cids,
            one_to_one_substitutions=self.one_to_one,
            scorers={"BIC": bic_score, "R2": r2_score},
            positive=True,
            limit=100,
            show_progress=False,
        )
        assert len(records) > 1
        assert isinstance(records, list)
        record = records[1]
        assert isinstance(record, dict)
        assert "cids" in record
        assert len(record["cids"]) <= len(self.selected_cids)
        assert "BIC" in record
        assert "R2" in record

    def test_success_dataframe(self):
        records = evaluate_equilength_solutions(
            X=self.X,
            Y=self.Y,
            selected_cids=self.selected_cids,
            one_to_one_substitutions=self.one_to_one,
            scorers={"BIC": bic_score, "R2": r2_score},
            positive=False,
            limit=100,
            show_progress=False,
        )
        assert len(records) > 1
        assert isinstance(records, list)
        record = records[1]
        assert isinstance(record, dict)
        assert "cids" in record
        assert len(record["cids"]) <= len(self.selected_cids)
        assert "BIC" in record
        assert "R2" in record


class EvaluateAlternativesSimpler(unittest.TestCase):
    def setUp(self):
        n_features = 10
        X, Y = make_regression(
            n_samples=50, n_features=n_features, n_targets=2, n_informative=6
        )
        feature_names = [int(i) for i in range(n_features)]

        self.X = pd.DataFrame(X, columns=feature_names)
        self.Y = pd.DataFrame(Y, columns=["t1", "t2"])

        one_to_two_substitutes = {
            1: pd.Series({(5, 3): 0.9, (6, 2): 0.95}),
            2: pd.Series({(4, 1): 0.9, (9, 1): 0.95}),
            3: pd.Series({(2, 4): 0.9, (5, 6): 0.95}),
            4: pd.Series(dtype=float),
            5: pd.Series({(1, 2): 0.9}),
            6: pd.Series({(1, 4): 0.9}),
            7: pd.Series({(9, 2): 0.9}),
            8: pd.Series(dtype=float),
        }

        self.one_to_two = one_to_two_substitutes
        self.selected_cids = [1, 4, 2]

    def test_success_series(self):
        records = evaluate_simpler_solutions(
            X=self.X,
            Y=self.Y.mean(axis=1),
            selected_cids=self.selected_cids,
            one_to_two_substitutions=self.one_to_two,
            scorers={"BIC": bic_score, "R2": r2_score},
            positive=False,
            limit=100,
            show_progress=False,
            max_concurrent_substitutions=2,
        )
        assert len(records) > 1
        assert isinstance(records, list)
        record = records[1]
        assert isinstance(record, dict)
        assert "cids" in record
        assert len(record["cids"]) < len(self.selected_cids)
        assert "BIC" in record
        assert "R2" in record

    def test_success_dataframe(self):
        records = evaluate_simpler_solutions(
            X=self.X,
            Y=self.Y,
            selected_cids=self.selected_cids,
            one_to_two_substitutions=self.one_to_two,
            scorers={"BIC": bic_score, "R2": r2_score},
            positive=True,
            limit=100,
            show_progress=False,
            max_concurrent_substitutions=2,
        )
        assert len(records) > 1
        assert isinstance(records, list)
        record = records[1]
        assert isinstance(record, dict)
        assert "cids" in record
        assert len(record["cids"]) < len(self.selected_cids)
        assert "BIC" in record
        assert "R2" in record


class TestFilterAvailableSubstitutions(unittest.TestCase):
    def setUp(self):
        # series where substitute cids are a tuple in the index
        # and performance of the substitution is in the values
        self.available_subs = pd.Series(
            {(1, 2): 0.9, (3, 4): 0.8, (5, 6): 0.7, (7, 8): 0.6}
        )

    def test_filter_available_substitutions(self):
        all_cids = [1, 2, 3, 4, 5]
        filtered_subs = _filter_available_substitutions(self.available_subs, all_cids)
        expected_result = pd.Series({(1, 2): 0.9, (3, 4): 0.8})
        pd.testing.assert_series_equal(filtered_subs, expected_result)

    def test_filter_available_substitutions_no_exclusions(self):
        all_cids = [1, 2, 3, 4, 5, 6, 7, 8]
        filtered_subs = _filter_available_substitutions(self.available_subs, all_cids)
        pd.testing.assert_series_equal(filtered_subs, self.available_subs)

    def test_filter_available_substitutions_all_excluded(self):
        all_cids = [9, 10, 11, 12]
        filtered_subs = _filter_available_substitutions(self.available_subs, all_cids)
        self.assertTrue(filtered_subs.empty)

    def test_empty_available_substitutions(self):
        available_subs = pd.Series([])
        all_cids = [1, 2, 3, 4, 5]
        filtered_subs = _filter_available_substitutions(available_subs, all_cids)
        self.assertTrue(filtered_subs.empty)
