import numpy as np
import pandas as pd
import pytest


def test_find_substitutes():
    from compound_hunting.substitution.find_substitutes import find_substitutes

    data = pd.DataFrame(
        {
            "A": [1, 2, 3, 4, 5],
            "B": [5, 4, 3, 2, 1],
            "C": [1, 2, 3, 0, 0],
            "D": [0, 0, 0, 4, 5],
        }
    )

    def metric_function(target, subset):
        return abs(np.random.rand() * 3)

    result = find_substitutes(data, metric_function, threshold=2, depth=2)
    assert isinstance(result, dict)
    assert all(isinstance(v, pd.Series) for v in result.values())
    assert all(isinstance(k, str) for k in result.keys())

    # check requested cids not found
    with pytest.raises(ValueError):
        find_substitutes(data, metric_function, threshold=2, depth=2, cids=["E"])

    # check requested cids found
    result = find_substitutes(data, metric_function, threshold=2, depth=2, cids=["A"])
    assert isinstance(result, dict)
    assert all(isinstance(v, pd.Series) for v in result.values())
    assert all(isinstance(k, str) for k in result.keys())
    assert "A" in result
    assert len(result) == 1

    data.columns = [1, 2, 3, 4]
    result = find_substitutes(data, metric_function, threshold=2, depth=2)
    assert isinstance(result, dict)
    assert all(isinstance(v, pd.Series) for v in result.values())
    assert all(isinstance(k, int) for k in result.keys())
