import unittest

import pandas as pd

from compound_hunting.substitution.utils import distance_based_alternatives


class TestDistanceBasedAlternatives(unittest.TestCase):
    def test_distance_based_alternatives(self):
        data = {
            "A": [0.1, 0.2, 0.3, 0.4, 0.5],
            "B": [0.5, 0.4, 0.3, 0.2, 0.1],
            "C": [0.2, 0.2, 0.2, 0.2, 0.2],
            "D": [0.1, 0.3, 0.5, 0.7, 0.9],
            "E": [0.9, 0.7, 0.5, 0.3, 0.1],
        }
        X = pd.DataFrame(data)

        result = distance_based_alternatives(X, "A", limit=2)
        expected_result = ["C", "D"]
        self.assertEqual(result, expected_result)

        X.columns = [1, 2, 3, 4, 5]
        result = distance_based_alternatives(X, 1, limit=2)
        expected_result = [3, 4]
        self.assertEqual(result, expected_result)

    def test_with_limit_greater_than_columns(self):
        # Create a sample DataFrame
        data = {
            "A": [0.1, 0.2, 0.3, 0.4, 0.5],
            "B": [0.5, 0.4, 0.3, 0.2, 0.1],
            "C": [0.2, 0.2, 0.2, 0.2, 0.2],
        }
        X = pd.DataFrame(data)

        # Test the function with a limit greater than the number of columns
        result = distance_based_alternatives(X, "A", limit=10)
        expected_result = ["C", "B"]
        self.assertEqual(result, expected_result)
