import unittest

import numpy as np
import pandas as pd
import pytest
from sklearn.datasets import make_regression

from compound_hunting.assessment.q_factor import q_metric


class TestQFactor(unittest.TestCase):
    @pytest.fixture(autouse=True)
    def init_fixtures(self, request):
        X, Y = make_regression(
            n_samples=100, n_features=10, n_targets=2, random_state=42
        )
        self.X = pd.DataFrame(X)
        self.Y = pd.DataFrame(Y)
        self.y = self.Y.iloc[:, 0]

    def test_q_metric_series(self):
        selected_cids = list(self.X.columns[0:7])
        one_to_two_substitutions = {
            self.X.columns[6]: pd.Series(
                [0.99], index=[(self.X.columns[7], self.X.columns[8])]
            )
        }

        qs, subs = q_metric(
            X=self.X,
            Y=self.y,
            selected_cids=selected_cids,
            one_to_two_substitutions=one_to_two_substitutions,
            euclidean_distance_alternatives_limit=0
        )
        assert isinstance(qs, pd.Series)
        assert isinstance(subs, pd.Series)
        assert len(qs) == len(selected_cids)
        assert len(subs) == len(selected_cids)

        # check substitution is found for self.X.columns[6]
        assert np.isfinite(qs.loc[self.X.columns[6]])
        assert subs.loc[self.X.columns[6]] == (self.X.columns[7], self.X.columns[8])

        # check no substitution is found for the first 6 cids
        assert np.all(~np.isfinite(qs.loc[selected_cids[:6]]))
        assert np.all(subs.loc[selected_cids[:6]].isna())

    def test_q_metric_already_present(self):
        # check no match is found if I am passing in an existing
        # CID as a substitution
        selected_cids = list(self.X.columns[0:7])
        one_to_two_substitutions = {
            self.X.columns[6]: pd.Series(
                [0.99], index=[(self.X.columns[4], self.X.columns[8])]
            )
        }

        qs, subs = q_metric(
            X=self.X,
            Y=self.y,
            selected_cids=selected_cids,
            one_to_two_substitutions=one_to_two_substitutions,
            euclidean_distance_alternatives_limit=0
        )
        assert np.all(~np.isfinite(qs))
        assert np.all(subs.isna())

    def test_q_metric_dataframe(self):
        selected_cids = list(self.X.columns[0:7])
        one_to_two_substitutions = {
            self.X.columns[6]: pd.Series(
                [0.99], index=[(self.X.columns[7], self.X.columns[8])]
            )
        }

        qs, subs = q_metric(
            X=self.X,
            Y=self.Y,
            selected_cids=selected_cids,
            one_to_two_substitutions=one_to_two_substitutions,
            euclidean_distance_alternatives_limit=0
        )
        assert isinstance(qs, pd.Series)
        assert isinstance(subs, pd.Series)
        assert len(qs) == len(selected_cids)
        assert len(subs) == len(selected_cids)

        # check substitution is found for self.X.columns[6]
        assert np.isfinite(qs.loc[self.X.columns[6]])
        assert subs.loc[self.X.columns[6]] == (self.X.columns[7], self.X.columns[8])

        # check no substitution is found for the first 6 cids
        assert np.all(~np.isfinite(qs.loc[selected_cids[:6]]))
        assert np.all(subs.loc[selected_cids[:6]].isna())
