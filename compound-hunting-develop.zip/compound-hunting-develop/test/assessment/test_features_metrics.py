import unittest

import numpy as np
import pandas as pd

from compound_hunting.assessment.features_metrics import get_variance_inflation_factor


class TestVarianceInflationFactor(unittest.TestCase):
    def setUp(self):
        np.random.seed(42)
        self.sample_data = pd.DataFrame(
            {
                1: np.random.rand(100),
                2: np.random.rand(100),
                3: np.random.rand(100),
                4: np.random.rand(100),
            }
        )

    def test_get_variance_inflation_factor_basic(self):
        cids = [1, 2, 3]
        result = get_variance_inflation_factor(self.sample_data, cids)

        self.assertIsInstance(result, pd.Series)
        self.assertSetEqual(set(result.index.tolist()), set(cids))
        self.assertEqual(result.name, "VIF")
        self.assertTrue(all(result > 0))  # VIF values should be positive

    def test_get_variance_inflation_factor_sorting(self):
        cids = [1, 2, 3, 4]
        result = get_variance_inflation_factor(self.sample_data, cids)

        self.assertEqual(
            result.index.tolist(), sorted(cids, key=lambda x: result[x], reverse=True)
        )

    def test_get_variance_inflation_factor_invalid_cid(self):
        data = pd.DataFrame({1: [1, 2, 3], 2: [4, 5, 6]})
        cids = [1, 2, 3]

        # cid 3 is not present
        with self.assertRaises(ValueError):
            get_variance_inflation_factor(data, cids)

    def test_get_variance_inflation_factor_singular_matrix(self):
        data = pd.DataFrame(
            {
                1: [1, 2, 3],
                2: [2, 4, 6],  # c2 = 2 * c1
                3: [7, 8, 9],
            }
        )
        cids = [1, 2, 3]

        with self.assertRaises(ValueError):
            get_variance_inflation_factor(data, cids)

    def test_get_variance_inflation_factor_empty_dataframe(self):
        data = pd.DataFrame()
        cids = []

        with self.assertRaises(ValueError):
            get_variance_inflation_factor(data, cids)

    def test_compare_statsmodels(self):
        from sklearn.datasets import make_regression

        X, _ = make_regression(n_samples=100, n_features=5, noise=0.1, random_state=42)
        data = pd.DataFrame(X, columns=[f"feature_{i}" for i in range(5)])
        cids = list(data.columns)

        # Hardcoded expected VIF values from statsmodels
        expected_vif = pd.Series(
            {
                "feature_2": 1.057196,
                "feature_3": 1.047112,
                "feature_4": 1.021908,
                "feature_0": 1.019628,
                "feature_1": 1.011094,
            },
            name="VIF",
        )

        # Calculate VIF using our implementation
        calculated_vif = get_variance_inflation_factor(data, cids)

        np.testing.assert_allclose(
            calculated_vif.values,
            expected_vif.values,
            rtol=1e-5,  # Relative tolerance
            atol=1e-5,  # Absolute tolerance
        )

        pd.testing.assert_index_equal(
            calculated_vif.index,
            expected_vif.index,
            check_names=False,
            check_exact=True,
        )
