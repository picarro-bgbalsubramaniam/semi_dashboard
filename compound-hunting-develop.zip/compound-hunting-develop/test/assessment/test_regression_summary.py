from compound_hunting.assessment.regression_summary import (
    regression_summary,
)
import unittest
import pandas as pd
from sklearn.datasets import make_regression


class TestRegressionSummary(unittest.TestCase):
    def setUp(self):
        X, Y = make_regression(
            n_samples=100, n_features=5, n_informative=5, n_targets=5, random_state=0
        )
        self.X = pd.DataFrame(X)
        self.Y = pd.DataFrame(Y)
        self.y = pd.Series(self.Y.iloc[:, 1])

    def test_empty_dataframe_single_target(self):
        empty_df = self.X.loc[:, [0]].drop(columns=0)
        coefs, scores = regression_summary(empty_df, self.y, positive=True)

        self.assertIsInstance(coefs, pd.Series)
        self.assertIsInstance(scores, pd.Series)

    def test_single_target_regression(self):
        coefs, scores = regression_summary(self.X, self.y)

        self.assertIsInstance(coefs, pd.Series)
        self.assertIsInstance(scores, pd.Series)

    def test_multi_target_raw_values(self):
        coefs, scores = regression_summary(
            self.X,
            self.Y,
            multioutput_coefs="raw_values",
            multioutput_scores="raw_values",
        )

        self.assertIsInstance(coefs, pd.DataFrame)
        self.assertIsInstance(scores, pd.DataFrame)

    def test_multi_target_uniform_average(self):
        coefs, scores = regression_summary(
            self.X,
            self.Y,
            multioutput_coefs="uniform_average",
            multioutput_scores="uniform_average",
        )

        self.assertIsInstance(coefs, pd.Series)
        self.assertIsInstance(scores, pd.Series)

    def test_multi_target_median(self):
        coefs, scores = regression_summary(
            self.X, self.Y, multioutput_coefs="median", multioutput_scores="median"
        )

        self.assertIsInstance(coefs, pd.Series)
        self.assertIsInstance(scores, pd.Series)

    def test_multi_target_median_positive(self):
        coefs, scores = regression_summary(
            self.X,
            self.Y,
            multioutput_coefs="median",
            multioutput_scores="median",
            positive=True,
        )

        self.assertIsInstance(coefs, pd.Series)
        self.assertIsInstance(scores, pd.Series)

    def test_single_compound_multi_target(self):
        coefs, scores = regression_summary(
            self.X.iloc[:, 0],
            self.Y,
            multioutput_coefs="median",
            multioutput_scores="median",
            positive=True,
        )

        self.assertIsInstance(coefs, pd.Series)
        self.assertIsInstance(scores, pd.Series)

    def test_empty_dataframe_multi_target(self):
        empty_df = self.X.loc[:, [0]].drop(columns=0)
        coefs, scores = regression_summary(
            empty_df,
            self.Y,
            multioutput_coefs="median",
            multioutput_scores="median",
            positive=True,
        )

        self.assertIsInstance(coefs, pd.Series)
        self.assertIsInstance(scores, pd.Series)

    def test_mismatched_samples(self):
        with self.assertRaises(ValueError):
            regression_summary(self.X, self.Y.iloc[1:])

    def test_invalid_multioutput_coefs(self):
        with self.assertRaises(NotImplementedError):
            regression_summary(self.X, self.Y, multioutput_coefs="foo")

    def test_invalid_multioutput_scores(self):
        with self.assertRaises(NotImplementedError):
            regression_summary(self.X, self.Y, multioutput_scores="BAR")

    def test_nus_input(self):
        coefs, scores = regression_summary(self.X, self.y, nus=self.y.values)

        self.assertIsInstance(coefs, pd.Series)
        self.assertIsInstance(scores, pd.Series)
