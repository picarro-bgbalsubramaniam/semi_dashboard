import jax
import pytest


@pytest.fixture
def sample_ess():
    """Create sample ess values for testing."""
    # Create ess values for 4 compound hunts with a model function matrix of size 100
    key = jax.random.PRNGKey(42)
    ess = jax.random.uniform(key, (100, 4))
    return ess


def test_ess_check(sample_ess):
    """Test that ess_check returns the expected shape and type."""

    from compound_hunting.assessment.flags import ess_check

    ess = sample_ess
    result = ess_check(ess)
    assert result.shape == (ess.shape[1],)
    assert result.dtype == "bool"

    result = ess_check(ess, ess_limit=0.1, quantile=0.5)
    assert result.shape == (ess.shape[1],)
    assert result.dtype == "bool"

    ess = sample_ess[:, 0]
    result = ess_check(ess)
    assert result.shape == ()
    assert result.dtype == "bool"
