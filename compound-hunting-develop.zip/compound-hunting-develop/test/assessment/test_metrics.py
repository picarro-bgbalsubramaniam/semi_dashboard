from unittest.mock import patch

import numpy as np
from jax.typing import ArrayLike

np.random.seed(42)


def test_log_likelihood():
    from compound_hunting.assessment.metrics import log_likelihood_metric

    X = np.random.rand(100, 5)
    y = np.random.rand(100)
    y_pred = np.random.rand(100)
    llf = log_likelihood_metric(X, y, y_pred)
    assert llf.size == 1
    assert np.issubdtype(llf.dtype, np.floating)
    assert isinstance(llf.item(), float)

    y = np.random.rand(100, 5)
    y_pred = np.random.rand(100, 5)
    llf = log_likelihood_metric(X, y, y_pred)
    assert isinstance(llf, ArrayLike)
    assert llf.shape == (5,)


def test_aic_metric():
    from compound_hunting.assessment.metrics import aic_metric

    X = np.random.rand(100, 5)
    y = np.random.rand(100)
    y_pred = np.random.rand(100)
    aic = aic_metric(X, y, y_pred)
    assert aic.size == 1
    assert np.issubdtype(aic.dtype, np.floating)
    assert isinstance(aic.item(), float)

    y = np.random.rand(100, 5)
    y_pred = np.random.rand(100, 5)
    aic = aic_metric(X, y, y_pred)
    assert isinstance(aic, ArrayLike)
    assert aic.shape == (5,)


def test_bic_metric():
    from compound_hunting.assessment.metrics import bic_metric

    X = np.random.rand(100, 5)
    y = np.random.rand(100)
    y_pred = np.random.rand(100)
    bic = bic_metric(X, y, y_pred)
    assert bic.size == 1
    assert np.issubdtype(bic.dtype, np.floating)
    assert isinstance(bic.item(), float)

    y = np.random.rand(100, 5)
    y_pred = np.random.rand(100, 5)
    bic = bic_metric(X, y, y_pred)
    assert isinstance(bic, ArrayLike)
    assert bic.shape == (5,)


def test_spectrum_score():
    from compound_hunting.assessment.metrics import spectrum_metric

    X = np.random.rand(100, 5)
    y_true = np.random.rand(100)
    y_pred = np.random.rand(100)
    ss = spectrum_metric(X, y_true, y_pred)
    assert ss.size == 1
    assert np.issubdtype(ss.dtype, np.floating)
    assert isinstance(ss.item(), float)
    assert ss < 0

    y_true = np.random.rand(100, 5)
    y_pred = np.random.rand(100, 5)
    ss = spectrum_metric(X, y_true, y_pred)
    assert isinstance(ss, ArrayLike)
    assert ss.shape == (5,)


def test_r2_metric():
    from compound_hunting.assessment.metrics import r2_metric

    X = np.random.rand(100, 5)

    y_real = np.array([3, 4, 5, 6, 7])
    y_pred = np.array([2.8, 4.1, 4.9, 6.2, 6.8])
    r2 = r2_metric(X, y_real, y_pred)
    assert r2.size == 1
    assert np.issubdtype(r2.dtype, np.floating)
    assert isinstance(r2.item(), float)
    assert np.isclose(r2, 0.986, atol=1e-3)

    y_true = np.random.rand(100, 5)
    y_pred = np.random.rand(100, 5)
    r2 = r2_metric(X, y_true, y_pred)
    assert isinstance(r2, ArrayLike)
    assert r2.shape == (5,)


def test_adjusted_r2_metric():
    from compound_hunting.assessment.metrics import adjusted_r2_metric

    X = np.random.rand(100, 5)

    y = np.random.rand(100)
    y_pred = np.random.rand(100)

    with patch(
        "compound_hunting.assessment.metrics.r2_metric", return_value=np.array([0.8])
    ):
        r2 = adjusted_r2_metric(X, y, y_pred)
        assert r2.size == 1
        assert np.issubdtype(r2.dtype, np.floating)
        assert isinstance(r2.item(), float)
        assert np.isclose(r2, 0.789, atol=0.001)

    y = np.random.rand(100, 2)
    y_pred = np.random.rand(100, 2)

    with patch(
        "compound_hunting.assessment.metrics.r2_metric",
        return_value=np.array([0.8, 0.9]),
    ):
        r2 = adjusted_r2_metric(X, y, y_pred)
        assert isinstance(r2, ArrayLike)
        assert r2.shape == (2,)
        assert np.allclose(r2, [0.789, 0.894], atol=0.001)


def test_f_statistics_metric():
    from compound_hunting.assessment.metrics import f_statistics_metric

    X = np.random.rand(100, 2)

    y_real = np.array([3, 4, 5, 6, 7])
    y_pred = np.array([2.8, 4.1, 4.9, 6.2, 6.8])
    f = f_statistics_metric(X, y_real, y_pred)
    assert f.size == 1
    assert np.issubdtype(f.dtype, np.floating)
    assert isinstance(f.item(), float)
    assert np.isclose(f, 73.857, atol=1e-3)

    y_true = np.random.rand(100, 5)
    y_pred = np.random.rand(100, 5)
    f = f_statistics_metric(X, y_true, y_pred)
    assert isinstance(f, ArrayLike)
    assert f.shape == (5,)


def test_f_pvalue_metric():
    from compound_hunting.assessment.metrics import f_pvalue_metric

    X = np.random.rand(5, 2)

    y = np.random.rand(5)
    y_pred = np.random.rand(5)

    with patch(
        "compound_hunting.assessment.metrics.f_statistics_metric",
        return_value=np.array([73.857]),
    ):
        pvalue = f_pvalue_metric(X, y, y_pred)
        assert pvalue.size == 1
        assert np.issubdtype(pvalue.dtype, np.floating)
        assert isinstance(pvalue.item(), float)
        assert np.isclose(pvalue, 0.013359, atol=1e-3)

    y = np.random.rand(5, 2)
    y_pred = np.random.rand(5, 2)

    with patch(
        "compound_hunting.assessment.metrics.f_statistics_metric",
        return_value=np.array([73.857, 21]),
    ):
        expected = np.array([0.013359, 0.045455])
        pvalue = f_pvalue_metric(X, y, y_pred)
        assert isinstance(pvalue, ArrayLike)
        assert pvalue.shape == (2,)
        assert np.allclose(pvalue, expected, atol=1e-3)


def test_rmse_metric():
    from compound_hunting.assessment.metrics import rmse_metric

    X = np.random.rand(5000, 2)
    y = np.random.normal(size=5000, loc=0, scale=1)
    y_pred = np.zeros(5000)
    rmse = rmse_metric(X, y, y_pred)
    assert rmse.size == 1
    assert np.issubdtype(rmse.dtype, np.floating)
    assert isinstance(rmse.item(), float)
    assert np.isclose(rmse, 1, atol=0.1)

    y = np.random.rand(100, 5)
    y_pred = np.random.rand(100, 5)
    rmse = rmse_metric(X, y, y_pred)
    assert isinstance(rmse, ArrayLike)
    assert rmse.shape == (5,)


def test_dcorr_pvalue_metric():
    from compound_hunting.assessment.metrics import dcorr_pvalue_metric

    X = np.random.rand(5000, 2)
    y = np.random.normal(size=5000, loc=0, scale=1)
    y_pred = np.zeros(5000)
    nus = np.arange(0, 5000, 1)

    # single target
    dcorr, dcorr_pvalue = dcorr_pvalue_metric(X, y, y_pred, nus)

    assert isinstance(dcorr, ArrayLike)
    assert isinstance(dcorr_pvalue, ArrayLike)

    assert dcorr.size == 1
    assert dcorr_pvalue.size == 1

    assert np.issubdtype(dcorr.dtype, np.floating)
    assert np.issubdtype(dcorr_pvalue.dtype, np.floating)

    assert isinstance(dcorr.item(), float)
    assert isinstance(dcorr_pvalue.item(), float)

    assert np.isclose(dcorr, 0, atol=0.1)
    assert not np.isclose(dcorr_pvalue, 0, atol=0.1)

    dcorr2, dcorr_pvalue2 = dcorr_pvalue_metric(X, y, y_pred)
    assert np.allclose(dcorr, dcorr2)
    assert np.allclose(dcorr_pvalue, dcorr_pvalue2)

    dcorr3, dcorr_pvalue3 = dcorr_pvalue_metric(X, y, y_pred, nus, bias=True)
    assert not np.allclose(dcorr, dcorr3)
    assert not np.allclose(dcorr_pvalue, dcorr_pvalue3)

    # multiple targets
    leading_dim = 3
    Y = np.broadcast_to(y, (leading_dim, len(y))).T
    Y_pred = np.broadcast_to(y_pred, (leading_dim, len(y))).T

    dcorr4, dcorr_pvalue4 = dcorr_pvalue_metric(X, Y, Y_pred)
    assert isinstance(dcorr4, ArrayLike)
    assert dcorr4.shape == (leading_dim,)
    assert isinstance(dcorr_pvalue4, ArrayLike)
    assert dcorr_pvalue4.shape == (leading_dim,)

    assert np.allclose(dcorr, dcorr4)
    assert np.allclose(dcorr_pvalue, dcorr_pvalue4)
