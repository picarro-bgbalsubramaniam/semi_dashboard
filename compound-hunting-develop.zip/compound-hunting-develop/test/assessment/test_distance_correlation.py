import numpy as np
from jax.typing import ArrayLike

np.random.seed(42)


def test_cdist():
    from compound_hunting.assessment.distance_correlation import _cdist

    x = np.random.normal(size=5000, loc=0, scale=1)
    y = np.random.normal(size=4000, loc=0, scale=1)
    cdist = _cdist(x.reshape(-1, 1), y.reshape(-1, 1))
    assert cdist.shape == (5000, 4000)
    assert np.issubdtype(cdist.dtype, np.floating)
    assert isinstance(cdist, ArrayLike)


def test_center_distmat():
    from compound_hunting.assessment.distance_correlation import _center_distmat

    X = np.random.normal(size=(1000, 1000), loc=0, scale=1)
    cent_X = _center_distmat(X)
    assert cent_X.shape == (1000, 1000)
    assert np.issubdtype(cent_X.dtype, np.floating)
    assert isinstance(cent_X, ArrayLike)


def test_dcorr():
    from compound_hunting.assessment.distance_correlation import _dcorr

    x = np.random.normal(size=5000, loc=0, scale=1)
    y = np.random.normal(size=5000, loc=0, scale=1)
    dcorr = _dcorr(x, y, bias=False)
    assert dcorr.size == 1
    assert np.issubdtype(dcorr.dtype, np.floating)
    assert isinstance(dcorr.item(), float)
    assert np.isclose(dcorr, 0, atol=0.1)
    assert isinstance(dcorr, ArrayLike)

    dcorr2 = _dcorr(x, y, bias=True)
    assert dcorr != dcorr2
