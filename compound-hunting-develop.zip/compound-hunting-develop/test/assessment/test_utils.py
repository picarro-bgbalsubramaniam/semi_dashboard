import unittest

import numpy as np
import pandas as pd
from sklearn.datasets import make_regression

from compound_hunting.assessment.utils import (
    evaluate_substitution,
    one_standard_error_rule,
    vip_scores,
)


def test_evaluate_substitution():
    X, Y = make_regression(n_samples=100, n_features=10, n_targets=2, random_state=42)
    X = pd.DataFrame(X)
    Y = pd.DataFrame(Y)
    y = Y.iloc[:, 0]

    selected_cids = list(X.columns[0:7])
    target_cid = 0
    replacement_cids = []
    initial_rmse = evaluate_substitution(
        X=X,
        Y=y,
        selected_cids=selected_cids,
        target_cid=target_cid,
        replacement_cids=replacement_cids,
    )
    assert isinstance(initial_rmse, float)

    target_cid = X.columns[6]
    replacement_cids = list(X.columns[7:9])

    output_rmse = evaluate_substitution(
        X=X,
        Y=y,
        selected_cids=selected_cids,
        target_cid=target_cid,
        replacement_cids=replacement_cids,
    )
    assert isinstance(output_rmse, float)
    assert not np.isclose(initial_rmse, output_rmse)

    target_cid = 0
    replacement_cids = []
    initial_rmse = evaluate_substitution(
        X=X,
        Y=Y,
        selected_cids=selected_cids,
        target_cid=target_cid,
        replacement_cids=replacement_cids,
    )
    assert isinstance(initial_rmse, float)

    target_cid = X.columns[6]
    replacement_cids = list(X.columns[7:9])

    output_rmse = evaluate_substitution(
        X=X,
        Y=Y,
        selected_cids=selected_cids,
        target_cid=target_cid,
        replacement_cids=replacement_cids,
    )
    assert isinstance(output_rmse, float)
    assert not np.isclose(initial_rmse, output_rmse)


class TestOneStandardErrorRule(unittest.TestCase):
    def test_basic_functionality(self):
        # best score is 0.1, look for other scores
        # less than 0.1 + 0.06 = 0.16, pick first (0.15)
        scores = [0.5, 0.4, 0.3, 0.15, 0.1]
        std_errors = [0.05, 0.05, 0.05, 0.05, 0.06]
        index, score = one_standard_error_rule(scores, std_errors, how="first")
        self.assertEqual(index, 3)
        self.assertEqual(score, 0.15)

    def test_all_within_one_std_error(self):
        # best score is 0.11, look for other scores
        # less than 0.11 + 0.11 = 0.22, all do, pick first
        scores = [0.15, 0.14, 0.13, 0.12, 0.11]
        std_errors = [0.10, 0.10, 0.10, 0.10, 0.11]
        index, score = one_standard_error_rule(scores, std_errors, how="first")
        self.assertEqual(index, 0)
        self.assertEqual(score, 0.15)

    def test_no_simpler_model(self):
        # best score is 0.1, look for other scores
        # less than 0.1 + 0.05 = 0.15, none exists, keep best
        scores = [0.5, 0.4, 0.3, 0.2, 0.1]
        std_errors = [0.05, 0.05, 0.05, 0.05, 0.05]
        index, score = one_standard_error_rule(scores, std_errors, how="first")
        self.assertEqual(index, 4)
        self.assertEqual(score, 0.1)

    def test_numpy_arrays(self):
        scores = np.array([0.5, 0.4, 0.3, 0.2, 0.1])
        std_errors = np.array([0.05, 0.05, 0.05, 0.05, 0.05])
        index, score = one_standard_error_rule(scores, std_errors, how="first")
        self.assertEqual(index, 4)
        self.assertEqual(score, 0.1)

    def test_single_element(self):
        scores = [0.5]
        std_errors = [0.05]
        index, score = one_standard_error_rule(scores, std_errors, how="first")
        self.assertEqual(index, 0)
        self.assertEqual(score, 0.5)

    def test_mismatched_lengths(self):
        scores = [0.5, 0.4, 0.3]
        std_errors = [0.05, 0.05]
        with self.assertRaises(ValueError):
            one_standard_error_rule(scores, std_errors, how="first")

    def test_empty_inputs(self):
        with self.assertRaises(ValueError):
            one_standard_error_rule([], [], how="first")

    def test_negative_scores(self):
        # best score is -0.5, look for other scores
        # less than -0.5 + 0.05 = -0.45, none exists
        scores = [-0.1, -0.2, -0.3, -0.4, -0.5]
        std_errors = [0.05, 0.05, 0.05, 0.05, 0.05]
        index, score = one_standard_error_rule(scores, std_errors, how="first")
        self.assertEqual(index, 4)
        self.assertEqual(score, -0.5)

    def test_how_last(self):
        # best score is 0.1, look for other scores
        # less than 0.1 + 0.06 = 0.16, found 0.15
        scores = [0.1, 0.15, 0.3, 0.4, 0.5]
        std_errors = [0.06, 0.05, 0.05, 0.05, 0.06]
        index, score = one_standard_error_rule(scores, std_errors, how="last")
        self.assertEqual(index, 1)
        self.assertEqual(score, 0.15)

    def test_how_last_all_within_one_std_error(self):
        # best score is 0.10, look for other scores
        # less than 0.10 + 0.05 = 0.15, all do, pick last
        scores = [0.10, 0.11, 0.12, 0.13, 0.14]
        std_errors = [0.05, 0.05, 0.06, 0.06, 0.07]
        index, score = one_standard_error_rule(scores, std_errors, how="last")
        self.assertEqual(index, 4)
        self.assertEqual(score, 0.14)

    def test_how_last_no_simpler_model(self):
        # best score is 0.10, look for other scores
        # less than 0.10 + 0.01 = 0.11, none exists
        scores = [0.10, 0.12, 0.125, 0.13, 0.14]
        std_errors = [0.01, 0.03, 0.04, 0.04, 0.08]
        index, score = one_standard_error_rule(scores, std_errors, how="last")
        self.assertEqual(index, 0)
        self.assertEqual(score, 0.1)

    def test_invalid_how(self):
        scores = [0.5, 0.4, 0.3]
        std_errors = [0.05, 0.05, 0.05]
        with self.assertRaises(ValueError):
            one_standard_error_rule(scores, std_errors, how="invalid")

    def test_min_std_error(self):
        # best score is 0.1, look for other scores
        # less than 0.1 + 0.11 = 0.21, pick first (0.2)
        scores = [0.5, 0.4, 0.3, 0.2, 0.1]
        std_errors = [0.01, 0.01, 0.01, 0.01, 0.01]
        index, score = one_standard_error_rule(
            scores, std_errors, min_std_error=0.11, how="first"
        )
        self.assertEqual(index, 3)
        self.assertEqual(score, 0.2)


class TestVIPScores(unittest.TestCase):
    def setUp(self):
        # Set up some sample data for testing
        self.x_weights = np.array([[1, 2], [3, 4], [5, 6]])
        self.x_scores = np.array([[1, 2], [3, 4], [5, 6], [7, 8]])
        self.y_loadings = np.array([[0.5, 0.5]])
        self.n_features = self.x_weights.shape[0]

    def test_vip_scores_normal(self):
        # Test normal operation
        result = vip_scores(self.x_weights, self.x_scores, self.y_loadings)
        assert result.shape[0] == self.n_features
        assert np.all(result >= 0)

    def test_vip_scores_single_component(self):
        # Test with a single component
        x_weights = np.array([[1], [2], [3]])
        x_scores = np.array([[1], [2], [3], [4]])
        y_loadings = np.array([[0.5]])
        result = vip_scores(x_weights, x_scores, y_loadings)
        assert result.shape[0] == x_weights.shape[0]
        assert np.all(result >= 0)

    def test_vip_scores_zero_weights(self):
        # Test with zero weights (should not raise error due to eps)
        x_weights = np.array([[0, 0], [0, 0], [0, 0]])
        result = vip_scores(x_weights, self.x_scores, self.y_loadings)
        assert result.shape[0] == x_weights.shape[0]
        assert np.all(result >= 0)

    def test_vip_scores_custom_eps(self):
        # Test with custom epsilon
        x_weights = np.array([[1e-13, 1e-13], [1e-13, 1e-13], [1e-13, 1e-13]])
        result = vip_scores(x_weights, self.x_scores, self.y_loadings, eps=1e-14)
        assert result.shape[0] == x_weights.shape[0]
        assert np.all(result >= 0)

    def test_size_mismatch(self):
        x_weights = np.array([[1, 2, 3], [4, 5, 6]])
        with self.assertRaises(ValueError):
            vip_scores(x_weights, self.x_scores, self.y_loadings)

    def test_empty_input(self):
        with self.assertRaises(ValueError):
            vip_scores(np.array([]), np.array([]), np.array([]))
