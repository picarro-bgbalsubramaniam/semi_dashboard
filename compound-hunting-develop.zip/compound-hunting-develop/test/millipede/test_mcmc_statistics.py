import jax
import jax.numpy as jnp
import numpy as np

from compound_hunting.millipede.data_structures import (
    MCMCDiagnostics,
    MCMCResults,
    MCMCSample,
)
from compound_hunting.millipede.mcmc_statistics import (
    aggregate_chain_results,
    align_samples_with_assumed_features,
    compute_mcmc_statistics,
    compute_weighted_feature_stats,
    concatenate_chains,
    normalize_weights,
    scale_mcmc_samples,
)


def test_compute_mcmc_statistics_uniform_weights() -> None:
    """
    Test compute_mcmc_statistics using uniform weights and known inputs.

    The test constructs a sample with:
      - n_samples = 4
      - P (non-intercept features) = 3
      - Pa (assumed features) = 1 (so beta has shape (n_samples, 4))
    It verifies the weighted statistics including pip, beta,
    beta_std, conditional_beta, conditional_beta_std, sigma, and sigma_std.
    """
    n_samples = 4
    P = 3
    Pa = 1

    # Define arrays for the MCMC sample (batch size: n_samples)
    # pip: shape (n_samples, P)
    pip = jnp.array(
        [[0.1, 0.2, 0.3], [0.2, 0.3, 0.4], [0.3, 0.4, 0.5], [0.4, 0.5, 0.6]],
        dtype=jnp.float32,
    )

    # beta: shape (n_samples, P+Pa) = (4, 4)
    beta = jnp.array(
        [
            [1.0, 2.0, 3.0, 4.0],
            [2.0, 3.0, 4.0, 5.0],
            [3.0, 4.0, 5.0, 6.0],
            [4.0, 5.0, 6.0, 7.0],
        ],
        dtype=jnp.float32,
    )

    # sigma: shape (n_samples,)
    sigma = jnp.array([1.0, 2.0, 3.0, 4.0], dtype=jnp.float32)

    # gamma: shape (n_samples, P)
    gamma = jnp.array([[1, 0, 1], [1, 1, 0], [0, 1, 1], [1, 1, 1]], dtype=jnp.float32)

    # weight: uniform weights; shape (n_samples,)
    weight = jnp.array([1.0, 1.0, 1.0, 1.0], dtype=jnp.float32)

    # set some features to be active
    active = jax.random.bernoulli(
        jax.random.PRNGKey(0), p=0.5, shape=(n_samples, P)
    ).astype(bool)
    activeb = jnp.zeros((n_samples, P + Pa), dtype=bool)
    activeb = activeb.at[:, :P].set(active)
    activeb = activeb.at[:, P:].set(True)

    # Dummy fields for the rest of the MCMCSample (not used in computation)
    idx = jnp.zeros((n_samples,), dtype=jnp.int32)
    log_h_ratio = jnp.ones((n_samples,), dtype=jnp.float32)

    sample = MCMCSample(
        gamma=gamma,
        activeb=activeb,
        beta=beta,
        sigma=sigma,
        pip=pip,
        idx=idx,
        log_h_ratio=log_h_ratio,
        weight=weight,
    )

    # Ensure shapes of gamma/pip match beta (prepend assumed features)
    sample_aligned = align_samples_with_assumed_features(sample)
    results = compute_mcmc_statistics(sample_aligned)

    expected_features = P + Pa
    assert results.pip.shape == (expected_features,)
    assert results.beta.shape == (expected_features,)
    assert results.beta_std.shape == (expected_features,)
    assert results.conditional_beta.shape == (expected_features,)
    assert results.conditional_beta_std.shape == (expected_features,)
    assert results.sigma.shape == ()
    assert results.sigma_std.shape == ()
    assert results.active_count_max.shape == ()


def test_scale_mcmc_samples() -> None:
    """
    Test scale_mcmc_samples to ensure beta and sigma are scaled correctly.

    Constructs a simple MCMCSample, applies scaling, and verifies the output.
    """
    n_samples = 2
    P = 2
    Pa = 1

    # Define arrays for a simple MCMC sample
    beta = jnp.array([[1.0, 2.0, 10.0], [3.0, 4.0, 12.0]], dtype=jnp.float32)
    sigma = jnp.array([0.5, 1.5], dtype=jnp.float32)
    gamma = jnp.array([[1, 0], [0, 1]], dtype=jnp.float32)
    pip = jnp.array([[0.8, 0.1], [0.2, 0.9]], dtype=jnp.float32)
    weight = jnp.array([1.0, 1.0], dtype=jnp.float32)

    # Dummy fields for the rest of the MCMCSample
    active = jnp.array([[True, False], [False, True]], dtype=bool)
    activeb = jnp.zeros((n_samples, P + Pa), dtype=bool)
    activeb = activeb.at[:, :P].set(active)
    activeb = activeb.at[:, P:].set(True)
    idx = jnp.zeros((n_samples,), dtype=jnp.int32)
    log_h_ratio = jnp.ones((n_samples,), dtype=jnp.float32)

    sample = MCMCSample(
        gamma=gamma,
        activeb=activeb,
        beta=beta,
        sigma=sigma,
        pip=pip,
        idx=idx,
        log_h_ratio=log_h_ratio,
        weight=weight,
    )

    # Define scaling factors
    scale_x = jnp.array([2.0, 4.0, 1.0], dtype=jnp.float32)  # Shape (P+Pa,)
    scale_y = jnp.array(5.0, dtype=jnp.float32)  # Scalar
    mean_x = jnp.array([0.0, 1.0, 2.0], dtype=jnp.float32)  # Shape (P+Pa,)
    mean_y = jnp.array(5.0, dtype=jnp.float32)  # Scalar

    # Scale the samples
    scaled_sample = scale_mcmc_samples(sample, scale_x, scale_y, mean_x, mean_y)

    # Expected results (including intercept adjustment)
    expected_concentration_scale = scale_y / scale_x
    beta_scaled = sample.beta * expected_concentration_scale
    intercept_offset = mean_y - (jnp.nan_to_num(beta_scaled[:, 1:], 0.0) @ mean_x[1:])
    expected_beta = beta_scaled.at[:, 0].add(intercept_offset)
    expected_sigma = sample.sigma * scale_y

    # Check scaled fields
    np.testing.assert_allclose(scaled_sample.beta, expected_beta, rtol=1e-6)
    np.testing.assert_allclose(scaled_sample.sigma, expected_sigma, rtol=1e-6)

    # Check that other fields are unchanged
    np.testing.assert_array_equal(scaled_sample.gamma, sample.gamma)
    np.testing.assert_array_equal(scaled_sample.pip, sample.pip)
    np.testing.assert_array_equal(scaled_sample.weight, sample.weight)
    np.testing.assert_array_equal(scaled_sample.activeb, sample.activeb)


def test_aggreate_chain_results() -> None:
    """
    Test aggreate_chain_results for output shape and handling of diagnostics,
    assuming inputs (pip, conditional_beta, diagnostics) are already uniformly sized.
    """
    n_spectra = 2
    n_active_features = 4  # P
    n_assumed_features = 1  # Pa
    n_features = n_active_features + n_assumed_features

    # Mock MCMCResults
    mock_pip_assumed = jnp.ones((n_spectra, n_assumed_features), dtype=jnp.float32)
    mock_pip_active = jnp.full((n_spectra, n_active_features), 0.8, dtype=jnp.float32)
    mock_pip = jnp.concatenate([mock_pip_assumed, mock_pip_active], axis=-1)

    mock_conditional_beta = jnp.ones((n_spectra, n_features), dtype=jnp.float32)

    results = MCMCResults(
        pip=mock_pip,
        beta=jnp.zeros((n_spectra, n_features)),
        beta_std=jnp.zeros((n_spectra, n_features)),
        conditional_beta=mock_conditional_beta,
        conditional_beta_std=jnp.zeros((n_spectra, n_features)),
        sigma=jnp.zeros((n_spectra,)),
        sigma_std=jnp.zeros((n_spectra,)),
        active_count_max=jnp.zeros((n_spectra,), dtype=jnp.int32),
    )

    # Mock MCMCDiagnostics
    mock_rhat_assumed = jnp.full(
        (n_spectra, n_assumed_features), jnp.nan, dtype=jnp.float32
    )
    mock_rhat_active_values = jnp.full(
        (n_spectra, n_active_features), 1.1, dtype=jnp.float32
    )
    mock_rhat = jnp.concatenate([mock_rhat_assumed, mock_rhat_active_values], axis=-1)

    mock_ess_assumed = jnp.full(
        (n_spectra, n_assumed_features), jnp.nan, dtype=jnp.float32
    )
    mock_ess_active_values = jnp.full(
        (n_spectra, n_active_features), 100.0, dtype=jnp.float32
    )
    mock_ess = jnp.concatenate([mock_ess_assumed, mock_ess_active_values], axis=-1)

    mock_within_active_limit = jnp.full((n_spectra), True, dtype=bool)
    diagnostics = MCMCDiagnostics(
        rhat=mock_rhat, ess=mock_ess, within_active_limit=mock_within_active_limit
    )

    # Areas under curve for each feature
    area_x = jnp.ones((n_features,), dtype=jnp.float32)

    # Test with diagnostics
    aggregated_data_with_diagnostics = aggregate_chain_results(
        results, area_x, diagnostics
    )

    # Expected shape: (n_spectra, n_stats, n_features) where n_stats = 6
    expected_shape = (n_spectra, 6, n_features)
    assert aggregated_data_with_diagnostics.shape == expected_shape

    # Check Mean PIP values (index 0)
    np.testing.assert_allclose(
        aggregated_data_with_diagnostics[:, 0, :n_assumed_features],
        1.0,
        rtol=1e-6,
    )
    np.testing.assert_allclose(
        aggregated_data_with_diagnostics[:, 0, n_assumed_features:],
        0.8,  # or the value set for mock_pip_active
        rtol=1e-6,
    )

    # Check that rhat (index 2) and ess (index 3) are NaN for assumed features
    # and not NaN for active features.
    pip_idx, rhat_idx, ess_idx, beta_idx = 0, 1, 2, 3
    assert jnp.isnan(
        aggregated_data_with_diagnostics[:, rhat_idx, :n_assumed_features]
    ).all()
    assert jnp.isnan(
        aggregated_data_with_diagnostics[:, ess_idx, :n_assumed_features]
    ).all()

    assert not jnp.isnan(
        aggregated_data_with_diagnostics[:, rhat_idx, n_assumed_features:]
    ).any()
    assert not jnp.isnan(
        aggregated_data_with_diagnostics[:, ess_idx, n_assumed_features:]
    ).any()

    # Check values for active features part of rhat and ess
    np.testing.assert_allclose(
        aggregated_data_with_diagnostics[:, rhat_idx, n_assumed_features:],
        mock_rhat_active_values,  # Compare directly with the active part of the mock
        rtol=1e-6,
    )
    np.testing.assert_allclose(
        aggregated_data_with_diagnostics[:, ess_idx, n_assumed_features:],
        mock_ess_active_values,  # Compare directly with the active part of the mock
        rtol=1e-6,
    )

    # Test without diagnostics
    aggregated_data_no_diagnostics = aggregate_chain_results(results, area_x, None)
    assert aggregated_data_no_diagnostics.shape == expected_shape

    # Check that rhat and ess are all NaN
    assert jnp.isnan(aggregated_data_no_diagnostics[:, rhat_idx, :]).all()
    assert jnp.isnan(aggregated_data_no_diagnostics[:, ess_idx, :]).all()

    # Check that other statistics are not all NaN (e.g., means of PIPs)
    # Mean PIP for assumed features should be 1.0
    np.testing.assert_allclose(
        aggregated_data_no_diagnostics[:, pip_idx, :n_assumed_features],
        1.0,
        rtol=1e-6,
    )
    # Mean PIP for active features should be 0.8
    np.testing.assert_allclose(
        aggregated_data_no_diagnostics[:, pip_idx, n_assumed_features:],
        0.8,
        rtol=1e-6,
    )
    assert not jnp.isnan(
        aggregated_data_no_diagnostics[:, beta_idx, :]
    ).any()  # Mean conditional beta


def test_uniformize_samples_shapes() -> None:
    """
    Test uniformize_samples_shapes for correct dimension alignment and value prepending.
    """
    n_samples = 2
    n_active_features = 3  # P
    n_assumed_features = 2  # Pa
    n_total_features = n_active_features + n_assumed_features

    # --- Case 1: Assumed features need to be prepended ---
    # Mock input MCMCSample
    mock_gamma_active = jnp.array(
        [[True, False, True], [False, True, True]], dtype=bool
    )  # Shape (n_samples, n_active_features)
    mock_pip_active = jnp.array(
        [[0.8, 0.1, 0.9], [0.2, 0.7, 0.8]], dtype=jnp.float32
    )  # Shape (n_samples, n_active_features)

    mock_beta_full = jnp.ones(
        (n_samples, n_total_features), dtype=jnp.float32
    )  # Shape (n_samples, n_total_features)
    # Other fields
    mock_activeb = jnp.ones((n_samples, n_total_features), dtype=bool)
    mock_sigma = jnp.array([1.0, 1.5], dtype=jnp.float32)
    mock_idx = jnp.array([0, 1], dtype=jnp.int32)
    mock_log_h_ratio = jnp.array([-0.5, 0.5], dtype=jnp.float32)
    mock_weight = jnp.array([1.0, 1.0], dtype=jnp.float32)

    input_sample = MCMCSample(
        gamma=mock_gamma_active,
        activeb=mock_activeb,
        beta=mock_beta_full,
        sigma=mock_sigma,
        pip=mock_pip_active,
        idx=mock_idx,
        log_h_ratio=mock_log_h_ratio,
        weight=mock_weight,
    )

    uniform_sample = align_samples_with_assumed_features(input_sample)

    # Assert shapes
    assert uniform_sample.gamma.shape == (n_samples, n_total_features)
    assert uniform_sample.pip.shape == (n_samples, n_total_features)
    assert uniform_sample.beta.shape == (n_samples, n_total_features)  # Unchanged

    # Assert prepended values for gamma (should be True for assumed features)
    np.testing.assert_array_equal(
        uniform_sample.gamma[:, :n_assumed_features],
        jnp.ones((n_samples, n_assumed_features), dtype=bool),
    )
    # Assert original active part of gamma is preserved
    np.testing.assert_array_equal(
        uniform_sample.gamma[:, n_assumed_features:], mock_gamma_active
    )

    # Assert prepended values for pip (should be 1.0 for assumed features)
    np.testing.assert_allclose(
        uniform_sample.pip[:, :n_assumed_features],
        jnp.ones((n_samples, n_assumed_features), dtype=jnp.float32),
        rtol=1e-6,
    )
    # Assert original active part of pip is preserved
    np.testing.assert_allclose(
        uniform_sample.pip[:, n_assumed_features:], mock_pip_active, rtol=1e-6
    )

    # Assert other fields are passed through
    np.testing.assert_array_equal(uniform_sample.activeb, mock_activeb)
    np.testing.assert_allclose(uniform_sample.beta, mock_beta_full, rtol=1e-6)
    np.testing.assert_allclose(uniform_sample.sigma, mock_sigma, rtol=1e-6)
    np.testing.assert_array_equal(uniform_sample.idx, mock_idx)
    np.testing.assert_allclose(uniform_sample.log_h_ratio, mock_log_h_ratio, rtol=1e-6)
    np.testing.assert_allclose(uniform_sample.weight, mock_weight, rtol=1e-6)


def test_concatenate_chains() -> None:
    """
    Test concatenate_chains for correct shape transformations.

    Ensures that chains are concatenated along the first dimension,
    resulting in the correct output shapes.
    """
    n_chains = 4
    n_draws = 100
    n_features = 20  # Represents the feature dimension for relevant arrays

    # For 3D arrays: (n_chains, n_draws, n_features)
    gamma_data = jnp.zeros((n_chains, n_draws, n_features), dtype=bool)
    activeb_data = jnp.zeros((n_chains, n_draws, n_features), dtype=bool)
    beta_data = jnp.zeros((n_chains, n_draws, n_features), dtype=jnp.float32)
    pip_data = jnp.zeros((n_chains, n_draws, n_features), dtype=jnp.float32)

    # For 2D arrays: (n_chains, n_draws)
    sigma_data = jnp.zeros((n_chains, n_draws), dtype=jnp.float32)
    idx_data = jnp.zeros((n_chains, n_draws), dtype=jnp.int32)
    log_h_ratio_data = jnp.zeros((n_chains, n_draws), dtype=jnp.float32)
    weight_data = jnp.zeros((n_chains, n_draws), dtype=jnp.float32)

    input_sample = MCMCSample(
        gamma=gamma_data,
        activeb=activeb_data,
        beta=beta_data,
        sigma=sigma_data,
        pip=pip_data,
        idx=idx_data,
        log_h_ratio=log_h_ratio_data,
        weight=weight_data,
    )

    # Concatenate chains
    concatenated_sample = concatenate_chains(input_sample)

    # Expected shape after concatenation
    expected_n_total_draws = n_chains * n_draws

    # --- Check shapes ---
    # These 3D arrays become 2D after concatenation
    assert concatenated_sample.gamma.shape == (expected_n_total_draws, n_features)
    assert concatenated_sample.activeb.shape == (expected_n_total_draws, n_features)
    assert concatenated_sample.beta.shape == (expected_n_total_draws, n_features)
    assert concatenated_sample.pip.shape == (expected_n_total_draws, n_features)

    # These 2D arrays become 1D after concatenation
    assert concatenated_sample.sigma.shape == (expected_n_total_draws,)
    assert concatenated_sample.idx.shape == (expected_n_total_draws,)
    assert concatenated_sample.log_h_ratio.shape == (expected_n_total_draws,)
    assert concatenated_sample.weight.shape == (expected_n_total_draws,)


def test_normalize_weights_basic_properties() -> None:
    w = jnp.array([0.0, 1.0, 3.0, 6.0], dtype=jnp.float32)
    wn = normalize_weights(w)

    # Sum to 1 and non-negative
    np.testing.assert_allclose(jnp.sum(wn), 1.0, rtol=1e-7, atol=1e-9)
    assert jnp.all(wn >= 0.0)


def test_normalize_weights_scale_invariance_and_stability() -> None:
    # Scale invariance
    w = jnp.array([1.0, 2.0, 7.0], dtype=jnp.float32)
    w_scaled = 1e6 * w
    wn = normalize_weights(w)
    wn_scaled = normalize_weights(w_scaled)
    np.testing.assert_allclose(wn, wn_scaled, rtol=1e-6, atol=1e-8)

    # Numerical stability with very small/large magnitudes
    w_hard = jnp.array([1e-30, 1.0, 1e-30], dtype=jnp.float32)
    wn_hard = normalize_weights(w_hard)
    np.testing.assert_allclose(jnp.sum(wn_hard), 1.0, rtol=1e-7, atol=1e-8)
    assert jnp.all(wn_hard >= 0.0)


def test_compute_weighted_feature_stats_uniform_weights_matches_baselines() -> None:
    # Setup small deterministic data (no extra dims): N=4 samples, F=3 features
    weights = normalize_weights(jnp.ones((4,), dtype=jnp.float32))

    beta = jnp.array(
        [
            [1.0, 2.0, 3.0],
            [2.0, 3.0, 4.0],
            [3.0, 4.0, 5.0],
            [4.0, 5.0, 6.0],
        ],
        dtype=jnp.float32,
    )

    # gamma indicates inclusion per sample/feature
    gamma = jnp.array(
        [
            [1, 0, 1],
            [1, 1, 0],
            [0, 1, 1],
            [1, 1, 1],
        ],
        dtype=jnp.float32,
    )

    # pip per sample/feature
    pip = jnp.array(
        [
            [0.1, 0.2, 0.3],
            [0.2, 0.3, 0.4],
            [0.3, 0.4, 0.5],
            [0.4, 0.5, 0.6],
        ],
        dtype=jnp.float32,
    )

    stats = compute_weighted_feature_stats(weights, beta, gamma, pip)

    # Expected baselines with uniform weights
    expected_pip = pip.mean(axis=0)
    expected_beta_mean = beta.mean(axis=0)
    expected_beta_std = beta.std(axis=0)

    # Conditional baselines
    gamma_mean = gamma.mean(axis=0)
    # Avoid divide-by-zero in expectations (mirrors function's denom guard)
    denom = jnp.maximum(gamma_mean, 1e-10)
    expected_cond_beta = (beta * gamma).mean(axis=0) / denom
    expected_cond_beta_sq_mean = (jnp.square(beta) * gamma).mean(axis=0) / denom
    expected_cond_beta_std = jnp.sqrt(
        jnp.maximum(expected_cond_beta_sq_mean - jnp.square(expected_cond_beta), 0.0)
    )

    np.testing.assert_allclose(stats.pip, expected_pip, rtol=1e-6, atol=1e-8)
    np.testing.assert_allclose(
        stats.beta_mean, expected_beta_mean, rtol=1e-6, atol=1e-8
    )
    np.testing.assert_allclose(stats.beta_std, expected_beta_std, rtol=1e-6, atol=1e-8)
    np.testing.assert_allclose(
        stats.conditional_beta, expected_cond_beta, rtol=1e-6, atol=1e-8
    )
    np.testing.assert_allclose(
        stats.conditional_beta_std, expected_cond_beta_std, rtol=1e-6, atol=1e-8
    )


def test_compute_weighted_feature_stats_nonuniform_weights() -> None:
    # Non-uniform weights to test weighting logic (sum to 1 already), N=4, F=2
    weights = jnp.array([0.05, 0.15, 0.3, 0.5], dtype=jnp.float32)
    beta = jnp.array(
        [[1.0, 2.0], [2.0, 1.0], [3.0, 4.0], [5.0, 6.0]], dtype=jnp.float32
    )
    gamma = jnp.array([[1, 1], [1, 0], [0, 1], [1, 1]], dtype=jnp.float32)
    pip = jnp.array([[0.2, 0.8], [0.3, 0.7], [0.5, 0.5], [0.9, 0.1]], dtype=jnp.float32)

    stats = compute_weighted_feature_stats(weights, beta, gamma, pip)

    w = weights[:, None]
    beta_mean = jnp.nansum(beta * w, axis=0)
    beta_sq_mean = jnp.nansum(jnp.square(beta) * w, axis=0)
    beta_std = jnp.sqrt(jnp.maximum(beta_sq_mean - jnp.square(beta_mean), 0.0))
    pip_mean = jnp.sum(pip * w, axis=0)

    gamma_sum = jnp.sum(gamma * w, axis=0)
    denom = jnp.maximum(gamma_sum, 1e-10)
    beta_num = jnp.nansum(beta * w * gamma, axis=0)
    beta_sq_num = jnp.nansum(jnp.square(beta) * w * gamma, axis=0)
    cond_beta = beta_num / denom
    cond_beta_std = jnp.sqrt(
        jnp.maximum(beta_sq_num / denom - jnp.square(cond_beta), 0.0)
    )

    np.testing.assert_allclose(stats.pip, pip_mean, rtol=1e-6, atol=1e-8)
    np.testing.assert_allclose(stats.beta_mean, beta_mean, rtol=1e-6, atol=1e-8)
    np.testing.assert_allclose(stats.beta_std, beta_std, rtol=1e-6, atol=1e-8)
    np.testing.assert_allclose(stats.conditional_beta, cond_beta, rtol=1e-6, atol=1e-8)
    np.testing.assert_allclose(
        stats.conditional_beta_std, cond_beta_std, rtol=1e-6, atol=1e-8
    )
