import jax.numpy as jnp
import numpy as np

from compound_hunting.millipede.data_structures import MCMCSample
from compound_hunting.millipede.feature_permutation_utils import (
    get_feature_reordering_permutations,
    restore_sample_feature_order,
)


def test_get_feature_reordering_permutations_no_assumed():
    """Test with no assumed covariates."""
    original_num_cols = 5
    assumed_covariates_idx = jnp.array([], dtype=jnp.int32)
    perm_to_end, perm_to_original = get_feature_reordering_permutations(
        original_num_cols, assumed_covariates_idx
    )
    expected_perm = jnp.arange(original_num_cols)
    np.testing.assert_array_equal(perm_to_end, expected_perm)
    np.testing.assert_array_equal(perm_to_original, expected_perm)


def test_get_feature_reordering_permutations_with_assumed():
    """Test with some assumed covariates."""
    original_num_cols = 5
    # Assumed are original indices 0 and 3
    assumed_covariates_idx = jnp.array([0, 3], dtype=jnp.int32)
    perm_to_end, perm_to_original = get_feature_reordering_permutations(
        original_num_cols, assumed_covariates_idx
    )

    # Expected: assumed [0, 3] first, then others [1, 2, 4]
    expected_perm_to_end = jnp.array([0, 3, 1, 2, 4])
    np.testing.assert_array_equal(perm_to_end, expected_perm_to_end)

    # Check if applying perm_to_original to perm_to_end restores original order
    original_indices = jnp.arange(original_num_cols)
    permuted_indices = original_indices[perm_to_end]
    restored_indices = permuted_indices[perm_to_original]
    np.testing.assert_array_equal(restored_indices, original_indices)

    # Explicit check for perm_to_original
    expected_perm_to_original = jnp.argsort(expected_perm_to_end)
    np.testing.assert_array_equal(perm_to_original, expected_perm_to_original)


def test_get_feature_reordering_permutations_all_assumed():
    """Test when all covariates are assumed (order might change)."""
    original_num_cols = 3
    # Assumed in a specific order
    assumed_covariates_idx = jnp.array([2, 0, 1], dtype=jnp.int32)
    perm_to_end, perm_to_original = get_feature_reordering_permutations(
        original_num_cols, assumed_covariates_idx
    )

    # perm_to_end should be the same as assumed_covariates_idx as there are no other selectable_indices
    expected_perm_to_end = jnp.array([2, 0, 1])
    np.testing.assert_array_equal(perm_to_end, expected_perm_to_end)

    # perm_to_original should sort perm_to_end to get back to original [0, 1, 2]
    # perm_to_end: [2, 0, 1] -> value 0 is at idx 1, value 1 at idx 2, value 2 at idx 0
    expected_perm_to_original = jnp.array([1, 2, 0])
    np.testing.assert_array_equal(perm_to_original, expected_perm_to_original)

    original_indices = jnp.arange(original_num_cols)
    permuted_indices = original_indices[perm_to_end]
    restored_indices = permuted_indices[perm_to_original]
    np.testing.assert_array_equal(restored_indices, original_indices)


def test_restore_sample_feature_order():
    """Test reordering of MCMCSample fields."""
    # Example: original order is [0, 1, 2, 3, 4]
    # Permuted order for computation (perm_to_end): [0, 3, 1, 2, 4] (from test_get_feature_reordering_permutations_with_assumed)
    # Permutation to get back to original (perm_to_original): [0, 2, 3, 1, 4]
    permutation_to_original = jnp.array([0, 2, 3, 1, 4])

    # Create dummy data in the permuted order
    # Original data would be e.g. beta_original = [b0, b1, b2, b3, b4]
    # Permuted data (as it would be before calling restore_sample_feature_order)
    # corresponds to indices [0, 3, 1, 2, 4] of original
    # So, beta_permuted = [b0, b3, b1, b2, b4]
    beta_permuted = jnp.array(
        [[0.0, 3.0, 1.0, 2.0, 4.0], [10.0, 13.0, 11.0, 12.0, 14.0]], dtype=jnp.float32
    )  # (2 samples, 5 features)
    gamma_permuted = jnp.array(
        [[True, True, False, True, False], [False, True, True, False, True]], dtype=bool
    )
    pip_permuted = jnp.array(
        [[0.1, 0.4, 0.2, 0.3, 0.5], [0.6, 0.9, 0.7, 0.8, 1.0]], dtype=jnp.float32
    )
    activeb_permuted = jnp.array(
        [[True, True, False, True, False], [False, True, True, False, True]], dtype=bool
    )

    # Other fields that should not be changed by their last dim
    sigma_scalar = jnp.array([1.0, 1.5], dtype=jnp.float32)  # (2 samples)
    idx_scalar = jnp.array([0, 1], dtype=jnp.int32)
    weight_scalar = jnp.array([1.0, 1.0], dtype=jnp.float32)
    log_h_ratio_scalar = jnp.array([-1.0, -2.0], dtype=jnp.float32)

    # Create a mock MCMCSample in permuted order
    permuted_samples = MCMCSample(
        beta=beta_permuted,
        gamma=gamma_permuted,
        pip=pip_permuted,
        activeb=activeb_permuted,
        sigma=sigma_scalar,  # Scalar, should not be reordered
        idx=idx_scalar,  # Scalar, should not be reordered
        weight=weight_scalar,  # Scalar
        log_h_ratio=log_h_ratio_scalar,  # Scalar
    )

    restored_samples = restore_sample_feature_order(
        permuted_samples, permutation_to_original
    )

    # Expected data in original order: [b0, b1, b2, b3, b4]
    expected_beta = jnp.array(
        [[0.0, 1.0, 2.0, 3.0, 4.0], [10.0, 11.0, 12.0, 13.0, 14.0]], dtype=jnp.float32
    )
    expected_gamma = jnp.array(
        [[True, False, True, True, False], [False, True, False, True, True]], dtype=bool
    )
    expected_pip = jnp.array(
        [[0.1, 0.2, 0.3, 0.4, 0.5], [0.6, 0.7, 0.8, 0.9, 1.0]], dtype=jnp.float32
    )
    expected_activeb = jnp.array(
        [[True, False, True, True, False], [False, True, False, True, True]], dtype=bool
    )

    np.testing.assert_array_equal(restored_samples.beta, expected_beta)
    np.testing.assert_array_equal(restored_samples.gamma, expected_gamma)
    np.testing.assert_array_equal(restored_samples.pip, expected_pip)
    np.testing.assert_array_equal(restored_samples.activeb, expected_activeb)

    # Check that other fields are untouched
    np.testing.assert_array_equal(restored_samples.sigma, sigma_scalar)
    np.testing.assert_array_equal(restored_samples.idx, idx_scalar)
    np.testing.assert_array_equal(restored_samples.weight, weight_scalar)
    np.testing.assert_array_equal(restored_samples.log_h_ratio, log_h_ratio_scalar)


def test_restore_sample_feature_order_empty_permutation():
    """Test reordering with an empty permutation_to_original (should be identity)."""
    num_features = 3
    permutation_to_original = jnp.arange(num_features)  # Identity

    data = jnp.arange(2 * num_features, dtype=jnp.float32).reshape(2, num_features)

    permuted_samples = MCMCSample(
        beta=data,
        gamma=data.astype(bool),
        pip=data,
        activeb=data.astype(bool),
        sigma=jnp.array([1.0, 2.0]),
        idx=jnp.array([0, 1]),
        weight=jnp.array([1.0, 1.0]),
        log_h_ratio=jnp.array([0.0, 0.0]),
    )
    restored_samples = restore_sample_feature_order(
        permuted_samples, permutation_to_original
    )

    np.testing.assert_array_equal(restored_samples.beta, data)
    np.testing.assert_array_equal(restored_samples.gamma, data.astype(bool))
    np.testing.assert_array_equal(restored_samples.pip, data)
    np.testing.assert_array_equal(restored_samples.activeb, data.astype(bool))
