import jax
import jax.numpy as jnp
import pytest

from compound_hunting.millipede.isotropic_sampling import (
    _compute_beta,
    _compute_i_prob,
    _compute_probs,
    _compute_sigma,
    _expand_subset,
)


@pytest.fixture
def key() -> jax.random.PRNGKey:
    """Fixture for providing a JAX random key."""
    return jax.random.PRNGKey(42)


@pytest.fixture
def small_vectors() -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]:
    """
    Fixture for small test vectors for _compute_i_prob.

    Returns:
        tuple: (gamma, add_prob, xi) where:
            - gamma is a 1-D array of shape (P,) (using P=3).
            - add_prob is a 1-D array of shape (P,).
            - xi is a 1-D array of shape (1,).
    """
    gamma = jnp.array([1, 0, 1], dtype=jnp.float32)  # (3,)
    add_prob = jnp.array([0.8, 0.2, 0.5], dtype=jnp.float32)  # (3,)
    xi = jnp.array([0.5], dtype=jnp.float32)  # (1,)
    return gamma, add_prob, xi


@pytest.fixture
def subset_data() -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]:
    """
    Fixture for test inputs for _expand_subset.

    Returns:
        tuple: (activeb, subset_perm, subset_values) where:
            - activeb is a 1-D boolean array of shape (4,).
            - subset_perm is a 1-D int array of shape (3,).
            - subset_values is a 1-D array of shape (3,).
    """
    activeb = jnp.array([True, False, True, True])
    subset_perm = jnp.array([0, 2, 3])
    subset_values = jnp.array([10, 20, 30])
    return activeb, subset_perm, subset_values


def test_compute_i_prob(small_vectors: tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]):
    """Test _compute_i_prob returns an array with shape (P+1,)."""
    gamma, add_prob, xi = small_vectors
    comb_factor = 0.1
    epsilon = 1e-6
    explore = 0.05

    result = _compute_i_prob(gamma, add_prob, xi, comb_factor, epsilon, explore)
    # Expect shape (P + 1,)
    assert result.shape == (
        gamma.shape[0] + 1,
    ), "Incorrect output shape for _compute_i_prob"


def test_expand_subset(subset_data: tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]):
    """Test _expand_subset correctly maps the subset values to the full vector."""
    activeb, subset_perm, subset_values = subset_data
    result = _expand_subset(subset_values, subset_perm, activeb)
    expected = jnp.array([10, 0, 20, 30])
    assert jnp.allclose(
        result, expected
    ), "_expand_subset did not produce the expected output."


def test_compute_sigma(key: jax.random.PRNGKey):
    """
    Test _compute_sigma returns a positive sigma and updates the random key.

    For this test, set:
      - YY = 10.0
      - Zt_active_sq = 4.0
      - N_nu0 = 15.0
    """
    YY = 10.0
    Zt_active_sq = 4.0
    N_nu0 = 15.0

    sigma = _compute_sigma(YY, Zt_active_sq, N_nu0, key)
    # Check that sigma is positive
    assert sigma > 0, "Computed sigma should be positive."


def test_compute_beta(key: jax.random.PRNGKey):
    """
    Test _compute_beta returns beta coefficients with the correct shape,
    and that coefficients corresponding to inactive features are zero.

    For this test, we use a small example:
        - Let max_active = 3.
        - Assume P = 3 primary features and Pa = 2 assumed features (so full_dim = 5).
        - Use an identity matrix for L_subset.
        - Set Z_active_subset = [1, 2, 3].
        - Define activeb such that the first three are active and the last two are inactive.
        - Let subset_perm = [0, 1, 2].
    """
    max_active = 3
    full_dim = 5  # P + Pa = 3 + 2
    L_subset = jnp.eye(max_active, dtype=jnp.float32)  # (3,3)
    Zt_active_subset = jnp.array([1.0, 2.0, 3.0], dtype=jnp.float32)  # (3,)
    activeb = jnp.array([True, True, True, False, False])
    subset_perm = jnp.array([0, 1, 2])
    sigma = 1.0

    beta = _compute_beta(L_subset, Zt_active_subset, activeb, subset_perm, sigma, key)
    # Check that beta has full dimension
    assert beta.shape == (
        full_dim,
    ), "Beta coefficients do not have the expected shape."
    # Check that coefficients corresponding to inactive features (indices 3 and 4) are zero.
    assert jnp.allclose(
        beta[3:], jnp.nan * jnp.ones(2, dtype=beta.dtype), equal_nan=True
    ), "_compute_beta did not set to nan coefficients for inactive features."


def test_compute_probs_larger_dimension(key: jax.random.PRNGKey):
    """
    Test _compute_probs with larger dimensions and varying active features.

        - P = 10 (primary features)
        - Pa = 1 (assumed feature/intercept)
        - N = 50 samples
        - max_active = 5 (maximum number of active features)

    We verify:
        - Shapes of outputs
        - Numerical properties
        - Behavior with different active feature patterns
        - Consistency of results
    """
    # Set dimensions
    P = 10
    Pa = 1
    N = 50
    max_active = 5
    full_dim = P + Pa

    # Create random but valid input data
    key1, key2, key3, key = jax.random.split(key, 4)

    # Generate gamma with exactly max_active-1 active features (leaving room for assumed)
    gamma = jnp.zeros(P, dtype=jnp.float32)
    active_indices = jax.random.choice(key1, P, shape=(max_active - 1,), replace=False)
    gamma = gamma.at[active_indices].set(1.0)

    # Assumed mask (last feature is assumed)
    assumed_mask = jnp.zeros(full_dim, dtype=bool).at[0].set(True)

    # Generate correlated design matrix
    X = jax.random.normal(key2, (N, full_dim), dtype=jnp.float32)
    # Add correlation between features
    X = X + 0.3 * jnp.roll(X, 1, axis=1)

    # Generate response and its projection
    y = jnp.sum(X * jnp.arange(full_dim), axis=1) + jax.random.normal(key3, (N,))
    Z = X.T @ y

    # Compute gram matrix and its diagonal
    XX = X.T @ X
    XX_diag = jnp.diag(XX)

    # Set other parameters
    YY = float(jnp.sum(y**2))
    N_nu0 = float(N)
    tau = 0.01
    tau_intercept = 1.0e-4
    log_h_ratio = -3.9
    epsilon = 1e-9

    # Run computation
    beta, sigma, add_prob = _compute_probs(
        gamma,
        assumed_mask,
        X,
        Z,
        XX,
        XX_diag,
        YY,
        N_nu0,
        P,
        Pa,
        tau,
        tau_intercept,
        log_h_ratio,
        epsilon,
        key,
        max_active,
    )

    # Test output shapes
    assert beta.shape == (
        full_dim,
    ), f"Expected beta shape {(full_dim,)}, got {beta.shape}"
    assert add_prob.shape == (
        P,
    ), f"Expected add_prob shape {(P,)}, got {add_prob.shape}"
    assert jnp.isscalar(sigma) or sigma.ndim == 0, "sigma should be a scalar"

    # Test numerical properties
    assert jnp.isfinite(sigma), "sigma should be finite"
    assert jnp.all(jnp.isfinite(add_prob)), "add_prob should be finite"
    assert sigma > 0, "sigma should be positive"
    assert jnp.all((add_prob >= 0) & (add_prob <= 1)), "add_prob should be in [0,1]"

    # Test consistency with gamma
    assert jnp.all(
        beta[0] != 0
    ), "Assumed feature (intercept) should have non-zero beta"
    active_features = jnp.where(gamma > 0)[0] + 1
    assert jnp.all(
        jnp.isfinite(beta[active_features])
    ), "beta should be finite for active features"
    assert (
        len(active_features) == max_active - 1
    ), "Should have max_active-1 primary features"

    # Test that inactive features have zero coefficients
    inactive_features = jnp.where(gamma == 0)[0] + 1
    assert jnp.all(
        jnp.isnan(beta[inactive_features])
    ), "Inactive features should have zero coefficients"
