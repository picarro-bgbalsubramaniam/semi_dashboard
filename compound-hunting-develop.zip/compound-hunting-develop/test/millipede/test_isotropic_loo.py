import jax.numpy as jnp
import pytest

from compound_hunting.millipede.isotropic_loo import (
    _compute_log_det_complete,
    _compute_loo_rss_complete,
    compute_log_det_complete,
    compute_loo_rss_complete,
)


@pytest.fixture
def basic_gram_matrix():
    """Create a simple 3x3 gram matrix for testing.

    Returns:
        tuple: Contains:
            - ATA: 3x3 gram matrix, symmetric and positive definite
            - activeb: boolean mask with all features active
            - tau: precision parameter set to 1.0
    """
    # Create a simple 3x3 gram matrix that is symmetric and positive definite
    ATA = jnp.array(
        [
            [2.0, 0.5, 0.3],
            [0.5, 3.0, 0.7],
            [0.3, 0.7, 1.5],
        ]
    )

    # All features active
    activeb = jnp.array([True, True, True])

    # Precision parameter
    tau = 1.0

    return ATA, activeb, tau


@pytest.fixture
def sparse_gram_matrix():
    """Create a 4x4 gram matrix with inactive features.

    Returns:
        tuple: Contains:
            - ATA: 4x4 gram matrix, constructed as X.T @ X
            - activeb: boolean mask with only first two features active
            - tau: precision parameter set to 2.0
            - ATb: projection vector X.T @ y
    """
    # Create a 4x4 gram matrix
    X = jnp.array(
        [
            [1.0, 2.0, 0.5, 0.1],
            [2.0, 1.0, 0.3, 0.2],
            [0.5, 0.3, 2.0, 0.4],
            [0.1, 0.2, 0.4, 1.5],
        ]
    )
    ATA = X.T @ X

    # First two features active, others inactive
    activeb = jnp.array([True, True, False, False])

    # Precision parameter
    tau = 2.0

    # Create ATb vector
    y = jnp.array([1.0, 0.5, 2.0, 1.5])
    ATb = X.T @ y

    return ATA, activeb, tau, ATb


def test_compute_log_det_complete_simple(basic_gram_matrix):
    """Test _compute_log_det_complete with simple matrices."""
    ATA, activeb, tau = basic_gram_matrix

    # Test for each feature
    for i in range(3):
        result = _compute_log_det_complete(ATA, activeb, tau, i)

        # Result should be a scalar float
        assert isinstance(result, float) or isinstance(result, jnp.ndarray)
        assert result.ndim == 0  # Scalar

        # Result should be finite
        assert jnp.isfinite(result)


def test_compute_log_det_complete_complex(sparse_gram_matrix):
    """Test _compute_log_det_complete with more complex matrices."""
    ATA, activeb, tau, _ = sparse_gram_matrix

    # Test for each feature
    for i in range(4):
        result = _compute_log_det_complete(ATA, activeb, tau, i)
        assert jnp.isfinite(result)


def test_compute_log_det_complete_inactive_feature(sparse_gram_matrix):
    """Test that compute_log_det_complete returns 0 for inactive features."""
    ATA, activeb, tau, _ = sparse_gram_matrix

    # Test inactive features (indices 2 and 3 in our fixture)
    result2 = compute_log_det_complete(ATA, activeb, tau, 2)
    result3 = compute_log_det_complete(ATA, activeb, tau, 3)
    assert result2 == 0.0
    assert result3 == 0.0


def test_compute_log_det_complete_positive(basic_gram_matrix):
    """Test that G_k_inv is always positive (leading to real log values)."""
    ATA, activeb, tau = basic_gram_matrix

    for i in range(3):
        result = _compute_log_det_complete(ATA, activeb, tau, i)
        # No complex numbers should appear
        assert not jnp.iscomplex(result)


def test_compute_log_det_complete_tau_scaling(basic_gram_matrix):
    """Test the scaling behavior with respect to tau."""
    ATA, activeb, _ = basic_gram_matrix

    tau1 = 1.0
    tau2 = 2.0

    result1 = _compute_log_det_complete(ATA, activeb, tau1, 0)
    result2 = _compute_log_det_complete(ATA, activeb, tau2, 0)

    # Difference should be exactly 0.5 * log(tau2/tau1)
    expected_diff = 0.5 * jnp.log(tau2 / tau1)
    assert jnp.abs(result2 - result1 - expected_diff) < 1e-5


def test_compute_loo_rss_complete_simple(basic_gram_matrix):
    """Test _compute_loo_rss_complete with simple matrices."""
    ATA, activeb, _ = basic_gram_matrix

    # Create a simple ATb vector
    ATb = jnp.array([1.0, 2.0, 1.5])

    # Test for each feature
    for i in range(3):
        result = _compute_loo_rss_complete(ATA, ATb, activeb, i)

        # Result should be a scalar float
        assert isinstance(result, float) or isinstance(result, jnp.ndarray)
        assert result.ndim == 0  # Scalar

        # Result should be finite and non-negative
        assert jnp.isfinite(result)
        assert result >= 0


def test_compute_loo_rss_complete_complex(sparse_gram_matrix):
    """Test _compute_loo_rss_complete with sparse matrices."""
    ATA, activeb, _, ATb = sparse_gram_matrix

    # Test for each feature
    for i in range(4):
        result = _compute_loo_rss_complete(ATA, ATb, activeb, i)
        assert jnp.isfinite(result)
        assert result >= 0


def test_compute_loo_rss_complete_inactive_feature(sparse_gram_matrix):
    """Test that compute_loo_rss_complete returns 0 for inactive features."""
    ATA, activeb, _, ATb = sparse_gram_matrix

    # Test inactive features (indices 2 and 3 in our fixture)
    result2 = compute_loo_rss_complete(ATA, ATb, activeb, 2)
    result3 = compute_loo_rss_complete(ATA, ATb, activeb, 3)
    assert result2 == 0.0
    assert result3 == 0.0


def test_compute_loo_rss_complete_consistency(basic_gram_matrix):
    """Test that RSS is consistent when removing different active features."""
    ATA, activeb, _ = basic_gram_matrix
    ATb = jnp.array([1.0, 2.0, 1.5])

    # Get RSS when removing each feature
    rss_0 = _compute_loo_rss_complete(ATA, ATb, activeb, 0)
    rss_1 = _compute_loo_rss_complete(ATA, ATb, activeb, 1)
    rss_2 = _compute_loo_rss_complete(ATA, ATb, activeb, 2)

    # RSS values should be similar for similar features
    assert jnp.abs(rss_0 - rss_1) < rss_0  # Difference should be smaller than value
    assert jnp.abs(rss_1 - rss_2) < rss_1
    assert jnp.abs(rss_0 - rss_2) < rss_0


def test_compute_loo_rss_complete_zero_response(basic_gram_matrix):
    """Test RSS computation with zero response vector."""
    ATA, activeb, _ = basic_gram_matrix
    ATb = jnp.zeros(3)

    for i in range(3):
        result = _compute_loo_rss_complete(ATA, ATb, activeb, i)
        assert jnp.abs(result) < 1e-10  # Should be very close to zero


def test_first_feature_active_constraint(sparse_gram_matrix):
    """Test that first feature is always active in the design."""
    _, activeb, _, _ = sparse_gram_matrix
    assert activeb[0], "First feature must always be active by design"
