import jax
import jax.numpy as jnp
import pytest

from compound_hunting.millipede.diagnostics import (
    _autocov,
    _ess_bulk,
    _rhat,
    _rhat_rank,
    _split_chains,
    _z_scale,
    ess,
    rhat,
)


@pytest.fixture
def sample_chains():
    """Create sample MCMC chains for testing."""
    # Create 4 chains with 100 samples each
    key = jax.random.PRNGKey(42)
    key1, key2 = jax.random.split(key)

    # Well-mixed chains (should have good diagnostics) between 0 and 1
    good_chains = jax.random.uniform(key1, (4, 100))  # 4 chains, 100 samples

    # Poorly mixed chains (different means) between 0 and 1
    poor_chains = jax.random.uniform(key2, (4, 100))  # 4 chains, 100 samples

    # Add small offsets that keep values between 0 and 1
    offsets = jnp.linspace(0, 0.3, 4).reshape(-1, 1)
    poor_chains = poor_chains * 0.7 + offsets

    return good_chains, poor_chains


def test_rhat_shape(sample_chains):
    """Test that rhat returns the expected shape."""
    good_chains, poor_chains = sample_chains

    n_items = 1
    result = rhat(good_chains)
    assert result.shape == (n_items,)  # Scalar for 2D input

    # Test with 3D input
    n_items = 2  # 2 parameters stacked in the last dimension
    chains_3d = jnp.stack([good_chains, poor_chains], axis=2)  # (4, 100, 2)
    result = rhat(chains_3d)
    assert result.shape == (n_items,)  # One value per parameter


def test_rhat_values(sample_chains):
    """Test that rhat returns reasonable values."""
    good_chains, poor_chains = sample_chains

    # Well-mixed chains should have R-hat close to 1
    good_rhat = rhat(good_chains).item()
    assert jnp.isfinite(good_rhat)
    assert jnp.abs(good_rhat - 1.0) < 0.1

    # Poorly mixed chains should have R-hat > 1
    poor_rhat = rhat(poor_chains).item()
    assert jnp.isfinite(poor_rhat)
    assert poor_rhat > 1.1


def test_ess_shape(sample_chains):
    """Test that ess returns the expected shape."""
    good_chains, poor_chains = sample_chains

    # Test with 2D input
    n_items = 1
    result = ess(good_chains)
    assert result.shape == (n_items,)  # Scalar for 2D input

    # Test relative ESS
    result_rel = ess(good_chains, relative=True)
    assert result_rel.shape == (n_items,)
    # Relative ESS should be between 0 and 1, but can be higher for some chains
    assert 0 <= result_rel <= 1.5

    # Test with 3D input
    n_items = 2  # 2 parameters stacked in the last dimension
    chains_3d = jnp.stack([good_chains, poor_chains], axis=2)  # (4, 100, 2)
    result = ess(chains_3d)
    assert result.shape == (n_items,)  # One value per parameter


def test_ess_values(sample_chains):
    """Test that ess returns reasonable values."""
    good_chains, poor_chains = sample_chains
    n_chains, n_samples = good_chains.shape
    total_samples = n_chains * n_samples

    # Well-mixed chains should have high ESS
    good_ess = ess(good_chains)
    assert jnp.isfinite(good_ess)
    assert good_ess > 0.5 * total_samples  # At least 50% efficiency

    # Poorly mixed chains should have lower ESS
    poor_ess = ess(poor_chains)
    assert jnp.isfinite(poor_ess)
    assert poor_ess < good_ess  # Should be less efficient


def test_split_chains():
    """Test that _split_chains correctly splits and stacks chains."""
    chains = jnp.array([[1, 2, 3, 4], [5, 6, 7, 8]])
    result = _split_chains(chains)

    # Should double the number of chains and halve the samples
    assert result.shape == (4, 2)

    # Check specific values
    expected = jnp.array([[1, 2], [5, 6], [3, 4], [7, 8]])
    assert jnp.allclose(result, expected)


def test_z_scale():
    """Test that _z_scale correctly transforms values."""
    # Create a simple array with known ranks
    x = jnp.array([[1.0, 5.0, 3.0], [2.0, 4.0, 6.0]])
    result = _z_scale(x)

    # Output should have same shape as input
    assert result.shape == x.shape

    # Values should be finite
    assert jnp.all(jnp.isfinite(result))


def test_autocov():
    """Test that _autocov returns the expected shape."""
    chains = jnp.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]])
    result = _autocov(chains)

    # Should have same shape as input
    assert result.shape == chains.shape

    # First lag should be the variance
    variances = jnp.var(chains, axis=1, keepdims=True)
    assert jnp.allclose(result[:, 0], variances[:, 0], rtol=1e-5)


def test_constant_input():
    """Test behavior with constant input."""
    # Create constant chains
    constant_chains = jnp.ones((4, 100))

    # ESS for constant input should equal total samples
    ess_result = ess(constant_chains)
    assert jnp.isclose(ess_result, 4 * 100)

    # R-hat for constant input should be 1
    rhat_result = rhat(constant_chains)
    assert jnp.isclose(rhat_result, 1.0)


def test_helper_functions():
    """Test that helper functions have expected behavior."""
    chains = jnp.array(
        [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10], [5, 6, 7, 8, 9, 10, 11, 12, 13, 14]],
        dtype=jnp.float32,
    )  # (2, 10)

    # Test _rhat
    rhat_result = _rhat(chains)
    assert rhat_result.shape == ()
    assert jnp.isfinite(rhat_result)

    # Test _rhat_rank
    rhat_rank_result = _rhat_rank(chains)
    assert rhat_rank_result.shape == ()
    assert jnp.isfinite(rhat_rank_result)

    # Test _ess_bulk
    ess_bulk_result = _ess_bulk(chains)
    assert ess_bulk_result.shape == ()
    assert jnp.isfinite(ess_bulk_result)
    assert ess_bulk_result > 0
