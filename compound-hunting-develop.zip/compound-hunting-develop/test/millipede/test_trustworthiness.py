import numpy as np
import pytest

from compound_hunting.millipede.trustworthiness import (
    default_trustworthiness_check,
    power_law_threshold,
)


def test_power_law_threshold_scalar_default():
    x = 1.0
    expected = 1.0 / np.power(0.010 * x, 1.25) + 0.0
    result = power_law_threshold(x)
    assert np.isclose(float(result), expected)


def test_power_law_threshold_list_default():
    x = [1.0, 10.0, 100.0]
    expected = 1.0 / np.power(0.010 * np.asarray(x, dtype=float), 1.25) + 0.0
    result = power_law_threshold(x)
    assert isinstance(result, np.ndarray)
    assert np.allclose(result, expected)


def test_power_law_threshold_array_custom_params():
    x = np.asarray([0.5, 2.0, 5.0], dtype=float)
    a, b, n, c = 2.0, 0.1, 2.0, 0.5
    expected = a / np.power(b * x, n) + c
    result = power_law_threshold(x, a=a, b=b, n=n, c=c)
    assert np.allclose(result, expected)


def test_power_law_threshold_negative_input():
    """Test that negative input is handled by taking the absolute value."""
    a, b, n, c = 1.0, 0.010, 1.25, 0.0
    x_neg = -10.0
    x_pos = 10.0
    result_neg = power_law_threshold(x_neg, a=a, b=b, n=n, c=c)
    result_pos = power_law_threshold(x_pos, a=a, b=b, n=n, c=c)
    assert not np.isnan(float(result_neg))
    assert np.isclose(float(result_neg), float(result_pos))


def test_default_trustworthiness_check_scalar():
    ratio = 0.1
    adjusted = 1.0
    expected = ratio < power_law_threshold(adjusted)
    result = default_trustworthiness_check(ratio, adjusted)
    # result may be a numpy scalar; coerce to bool
    assert bool(np.asarray(result)) is bool(expected)


@pytest.mark.parametrize(
    ("ratio", "adjusted"),
    [
        ([0.05, 0.2, 0.01, 0.5], [0.5, 1.0, 2.0, 10.0]),  # list inputs
        (
            np.asarray([0.05, 0.2, 0.01, 0.5], dtype=float),
            np.asarray([0.5, 1.0, 2.0, 10.0], dtype=float),
        ),  # numpy array inputs
    ],
)
def test_default_trustworthiness_check_vector_types(ratio, adjusted):
    expected = np.asarray(ratio, dtype=float) < power_law_threshold(adjusted)
    result = default_trustworthiness_check(ratio, adjusted)
    assert isinstance(result, np.ndarray)
    assert result.dtype == bool
    assert np.array_equal(result, expected)


def test_default_trustworthiness_check_from_table_data():
    """This data was manually calculated from an unknown unknown plot comparing PFI ratio to PFI free
    for several datasets and analyzers for a power law with a=1.0, b=0.010, n=1.25, c=0.0."""
    a, b, n, c = 1.0, 0.010, 1.25, 0.0
    pfi_ratio = np.array(
        [
            0.272,
            0.696,
            0.615,
            0.0835,
            0.282,
            0.02507,
            0.01326,
            1.267e-4,
            0.186,
            1.326e-2,
            0.526,
            0.195,
            0.116,
            0.584,
        ],
        dtype=float,
    )
    pfi_free = np.array(
        [
            1168,
            180.479,
            35.3,
            645.917,
            299.571,
            2566,
            7835,
            5176,
            464.754,
            7835,
            160,
            318,
            493,
            163,
        ],
        dtype=float,
    )
    flag = np.array(
        [
            True,
            True,
            False,
            False,
            True,
            True,
            True,
            False,
            True,
            True,
            False,
            False,
            False,
            True,
        ]
    )

    # 'T' corresponds to points above the power-law curve (non-modelable)
    above_curve = pfi_ratio > power_law_threshold(pfi_free, a=a, b=b, n=n, c=c)
    assert np.array_equal(above_curve, flag)

    # Default trustworthiness: modelable if below the curve
    is_modelable = default_trustworthiness_check(pfi_ratio, pfi_free)
    expected_is_modelable = ~above_curve
    assert np.array_equal(is_modelable, expected_is_modelable)
