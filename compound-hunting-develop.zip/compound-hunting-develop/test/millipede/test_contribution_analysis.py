"""Tests for contribution analysis functions."""

import unittest

import numpy as np
import pandas as pd

from compound_hunting.millipede.contribution_analysis import (
    calculate_pfi_ratio,
    compute_areas,
    compute_contributions,
    spectral_contributions_breakdown,
)


class TestComputeAreas(unittest.TestCase):
    """Tests for compute_areas function."""

    def setUp(self):
        """Set up test fixtures."""
        self.n_samples = 100
        self.n_features = 5
        self.n_targets = 2
        self.frequencies = np.linspace(0, 10, self.n_samples)

    def test_compute_areas_numpy_single_target(self):
        """Test compute_areas with numpy arrays and single target."""
        X = np.random.randn(self.n_samples, self.n_features)
        y = np.random.randn(self.n_samples)

        area_x, area_y = compute_areas(X, y, self.frequencies)

        self.assertEqual(area_x.shape, (self.n_features, 1))
        self.assertEqual(area_y.shape, (1,))
        self.assertIsInstance(area_x, np.ndarray)
        self.assertIsInstance(area_y, np.ndarray)

    def test_compute_areas_numpy_multi_target(self):
        """Test compute_areas with numpy arrays and multiple targets."""
        X = np.random.randn(self.n_samples, self.n_features)
        Y = np.random.randn(self.n_samples, self.n_targets)

        area_x, area_y = compute_areas(X, Y, self.frequencies)

        self.assertEqual(area_x.shape, (self.n_features, self.n_targets))
        self.assertEqual(area_y.shape, (self.n_targets,))

    def test_compute_areas_pandas_single_target(self):
        """Test compute_areas with pandas structures and single target."""
        X = pd.DataFrame(
            np.random.randn(self.n_samples, self.n_features),
            columns=[f"feat_{i}" for i in range(self.n_features)],
        )
        y = pd.Series(np.random.randn(self.n_samples), name="target")

        area_x, area_y = compute_areas(X, y, self.frequencies)

        self.assertEqual(area_x.shape, (self.n_features, 1))
        self.assertEqual(area_y.shape, (1,))

    def test_compute_areas_pandas_multi_target(self):
        """Test compute_areas with pandas structures and multiple targets."""
        X = pd.DataFrame(
            np.random.randn(self.n_samples, self.n_features),
            columns=[f"feat_{i}" for i in range(self.n_features)],
        )
        Y = pd.DataFrame(
            np.random.randn(self.n_samples, self.n_targets),
            columns=[f"target_{i}" for i in range(self.n_targets)],
        )

        area_x, area_y = compute_areas(X, Y, self.frequencies)

        self.assertEqual(area_x.shape, (self.n_features, self.n_targets))
        self.assertEqual(area_y.shape, (self.n_targets,))

    def test_compute_areas_with_intercept(self):
        """Test compute_areas with intercept added."""
        X = np.random.randn(self.n_samples, self.n_features)
        y = np.random.randn(self.n_samples)

        area_x, area_y = compute_areas(X, y, self.frequencies, add_intercept=True)

        # Should have one extra feature for intercept
        self.assertEqual(area_x.shape, (self.n_features + 1, 1))
        self.assertEqual(area_y.shape, (1,))

    def test_compute_areas_constant_signal(self):
        """Test compute_areas with constant signals."""
        # Constant X should give area proportional to the constant value
        X = np.ones((self.n_samples, self.n_features)) * 2.0
        y = np.ones(self.n_samples) * 3.0

        area_x, area_y = compute_areas(X, y, self.frequencies)

        # For constant signal, area should be approximately constant * range
        expected_area_x = 2.0 * (self.frequencies[-1] - self.frequencies[0])
        expected_area_y = 3.0 * (self.frequencies[-1] - self.frequencies[0])

        np.testing.assert_allclose(area_x[:, 0], expected_area_x, rtol=1e-10)
        np.testing.assert_allclose(area_y[0], expected_area_y, rtol=1e-10)

    def test_compute_areas_mismatched_lengths_X(self):
        """Test compute_areas raises error when X and frequencies have different lengths."""
        X = np.random.randn(self.n_samples - 1, self.n_features)
        y = np.random.randn(self.n_samples)

        with self.assertRaises(ValueError) as context:
            compute_areas(X, y, self.frequencies)

        self.assertIn("same number of samples", str(context.exception))

    def test_compute_areas_mismatched_lengths_Y(self):
        """Test compute_areas raises error when Y and frequencies have different lengths."""
        X = np.random.randn(self.n_samples, self.n_features)
        y = np.random.randn(self.n_samples - 1)

        with self.assertRaises(ValueError) as context:
            compute_areas(X, y, self.frequencies)

        self.assertIn("same number of samples", str(context.exception))


class TestComputeContributions(unittest.TestCase):
    """Tests for compute_contributions function."""

    def setUp(self):
        """Set up test fixtures."""
        self.n_features = 5
        self.n_datasets = 2
        self.feature_names = np.array([f"feat_{i}" for i in range(self.n_features)])
        self.dataset_names = [f"dataset_{i}" for i in range(self.n_datasets)]

    def test_compute_contributions_basic(self):
        """Test basic contribution computation."""
        beta = np.random.randn(self.n_datasets, self.n_features)
        area_x = pd.Series(
            np.random.randn(self.n_features) + 2,  # Ensure positive areas
            index=self.feature_names,
        )

        contributions = compute_contributions(
            beta, area_x, self.feature_names, self.dataset_names
        )

        self.assertIsInstance(contributions, pd.DataFrame)
        self.assertEqual(contributions.shape, (self.n_features, self.n_datasets))
        np.testing.assert_array_equal(contributions.index, self.feature_names)
        np.testing.assert_array_equal(contributions.columns, self.dataset_names)

    def test_compute_contributions_single_dataset(self):
        """Test contribution computation with single dataset."""
        beta = np.random.randn(1, self.n_features)
        area_x = pd.Series(
            np.random.randn(self.n_features) + 2,
            index=self.feature_names,
        )

        contributions = compute_contributions(
            beta, area_x, self.feature_names, ["dataset_0"]
        )

        self.assertEqual(contributions.shape, (self.n_features, 1))

    def test_compute_contributions_values(self):
        """Test that contributions are computed correctly."""
        # Simple test case with known values
        beta = np.array([[1.0, 2.0, 3.0]])
        area_x = pd.Series([2.0, 3.0, 4.0], index=["a", "b", "c"])
        feature_names = np.array(["a", "b", "c"])
        dataset_names = ["dataset"]

        contributions = compute_contributions(
            beta, area_x, feature_names, dataset_names
        )

        expected = np.array([[2.0], [6.0], [12.0]])  # beta * area_x
        np.testing.assert_allclose(contributions.values, expected)

    def test_compute_contributions_zero_area(self):
        """Test contribution computation with zero area."""
        beta = np.array([[1.0, 2.0, 3.0]])
        area_x = pd.Series([0.0, 1.0, 2.0], index=["a", "b", "c"])
        feature_names = np.array(["a", "b", "c"])
        dataset_names = ["dataset"]

        contributions = compute_contributions(
            beta, area_x, feature_names, dataset_names
        )

        # First feature should have zero contribution
        self.assertEqual(contributions.loc["a", "dataset"], 0.0)


class TestSpectralContributionsBreakdown(unittest.TestCase):
    """Tests for spectral_contributions_breakdown function."""

    def test_breakdown_mixed_signs_with_offset(self):
        """Aggregate totals and signed parts; include offset at row index 0."""
        contributions = pd.DataFrame(
            [
                [1.0, 2.0],  # offset row (index 0)
                [-3.0, -1.0],
                [5.0, -0.5],
            ],
            index=[0, 1, 2],
            columns=["dataset_0", "dataset_1"],
        )

        # Provide raw PFI values per dataset; with no excluded CIDs, adjusted_pfi == raw_pfi
        pfi = pd.Series([10.0, 5.0], index=["dataset_0", "dataset_1"])
        summary = spectral_contributions_breakdown(
            contributions, pfi, offset_name=contributions.index[0]
        )

        # dataset_0 expectations
        self.assertAlmostEqual(summary.loc["dataset_0", "model_pfi"], 1.0 - 3.0 + 5.0)
        self.assertAlmostEqual(summary.loc["dataset_0", "negative_pfi"], -3.0)
        self.assertAlmostEqual(summary.loc["dataset_0", "positive_pfi"], 1.0 + 5.0)
        self.assertAlmostEqual(summary.loc["dataset_0", "offset_pfi"], 1.0)
        self.assertAlmostEqual(summary.loc["dataset_0", "raw_pfi"], 10.0)
        self.assertAlmostEqual(summary.loc["dataset_0", "adjusted_pfi"], 10.0)

        # dataset_1 expectations
        self.assertAlmostEqual(summary.loc["dataset_1", "model_pfi"], 2.0 - 1.0 - 0.5)
        self.assertAlmostEqual(summary.loc["dataset_1", "negative_pfi"], -1.5)
        self.assertAlmostEqual(summary.loc["dataset_1", "positive_pfi"], 2.0)
        self.assertAlmostEqual(summary.loc["dataset_1", "offset_pfi"], 2.0)
        self.assertAlmostEqual(summary.loc["dataset_1", "raw_pfi"], 5.0)
        self.assertAlmostEqual(summary.loc["dataset_1", "adjusted_pfi"], 5.0)


class TestCalculatePfiRatio(unittest.TestCase):
    """Tests for calculate_pfi_ratio function."""

    def test_ratio_when_total_positive(self):
        total = pd.Series([10.0, 5.0], index=["d0", "d1"])
        negative = pd.Series([-3.0, -1.0], index=["d0", "d1"])
        positive = pd.Series([13.0, 6.0], index=["d0", "d1"])

        ratio = calculate_pfi_ratio(total, negative, positive)

        expected = np.array([0.3, 0.2])
        np.testing.assert_allclose(ratio, expected)

    def test_ratio_when_total_negative(self):
        total = pd.Series([-10.0], index=["d0"])
        negative = pd.Series([-3.0], index=["d0"])
        positive = pd.Series([13.0], index=["d0"])

        ratio = calculate_pfi_ratio(total, negative, positive)

        expected = np.array([13.0 / 10.0])
        np.testing.assert_allclose(ratio, expected)


if __name__ == "__main__":
    unittest.main()
