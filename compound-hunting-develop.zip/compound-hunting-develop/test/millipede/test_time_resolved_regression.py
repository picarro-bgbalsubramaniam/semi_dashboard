import unittest

import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd

from compound_hunting.millipede.data_structures import (
    MCMCSample,
    MCMCSampleReduced,
    WeightedFeatureStats,
)
from compound_hunting.millipede.time_resolved_regression import (
    _build_active_design_matrix,
    _solve_active_least_squares,
    _standardize_columns,
    _stats_to_beta_df,
    _stats_to_compound_by_time_matrix,
    compute_time_series_betas,
    propagate_model_to_time_series,
    sample_model_by_weight,
    summarize_time_feature_stats,
)


class TestStandardize(unittest.TestCase):
    """Test cases for the reduced_fitter module."""

    def setUp(self) -> None:
        """Set up test data."""
        self.key = jax.random.PRNGKey(42)

        # Create test data with known statistical properties
        self.data_2x3 = jnp.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])

        # Create larger test data with different scales
        self.data_random = jax.random.normal(self.key, (5, 10)) * 10 + 5

    def test_standardize_basic_functionality(self) -> None:
        """Test basic standardization functionality."""
        data_std, data_mean, data_std_vals = _standardize_columns(self.data_2x3)

        # Check return shapes
        self.assertEqual(data_std.shape, (2, 3))
        self.assertEqual(data_mean.shape, (3,))
        self.assertEqual(data_std_vals.shape, (3,))

        # Check that mean and std are computed correctly
        expected_mean = jnp.array([2.5, 3.5, 4.5])  # mean of columns
        expected_std = jnp.array([1.5, 1.5, 1.5])  # std of columns

        np.testing.assert_allclose(data_mean, expected_mean, rtol=1e-6)
        np.testing.assert_allclose(data_std_vals, expected_std, rtol=1e-6)

    def test_standardize_properties(self) -> None:
        """Test that standardized data has correct statistical properties."""
        data_std, data_mean, data_std_vals = _standardize_columns(self.data_random)

        # Standardized data should have mean close to 0
        computed_mean = data_std.mean(axis=0)
        np.testing.assert_allclose(computed_mean, 0.0, atol=1e-6)

        # Standardized data should have std close to 1
        computed_std = data_std.std(axis=0)
        np.testing.assert_allclose(computed_std, 1.0, rtol=1e-6)

    def test_standardize_single_mode(self) -> None:
        """Test standardization with single mode (row)."""
        single_mode_data = jnp.array([[1.0, 2.0, 3.0, 4.0]])
        data_std, data_mean, data_std_vals = _standardize_columns(single_mode_data)

        # With single mode, std should be 0, but the function should still work
        self.assertEqual(data_std.shape, (1, 4))
        np.testing.assert_array_equal(data_mean, single_mode_data[0])
        np.testing.assert_array_equal(data_std_vals, jnp.zeros(4))

    def test_standardize_identical_columns(self) -> None:
        """Test standardization when some columns are identical."""
        identical_data = jnp.array([[1.0, 2.0, 2.0], [1.0, 2.0, 2.0], [1.0, 2.0, 2.0]])
        data_std, data_mean, data_std_vals = _standardize_columns(identical_data)

        # Columns with no variation should have std = 0
        expected_mean = jnp.array([1.0, 2.0, 2.0])
        expected_std = jnp.array([0.0, 0.0, 0.0])

        np.testing.assert_allclose(data_mean, expected_mean, rtol=1e-6)
        np.testing.assert_allclose(data_std_vals, expected_std, rtol=1e-6)


class TestSampleGamma(unittest.TestCase):
    """Test cases for the sample_gamma functions."""

    def setUp(self) -> None:
        """Set up test data."""
        self.key = jax.random.PRNGKey(42)

        # Test dimensions
        self.n_spectra = 3
        self.n_chains = 2
        self.n_draws = 4
        self.n_compounds = 5

        # Create mock MCMCSample
        self.mock_sample = MCMCSample(
            gamma=jax.random.bernoulli(
                self.key,
                0.3,
                (self.n_spectra, self.n_chains, self.n_draws, self.n_compounds),
            ),
            activeb=jnp.ones(
                (self.n_spectra, self.n_chains, self.n_draws, self.n_compounds + 2)
            ),  # +2 for assumed features
            beta=jax.random.normal(
                jax.random.split(self.key, 1)[0],
                (self.n_spectra, self.n_chains, self.n_draws, self.n_compounds + 2),
            ),
            sigma=jax.random.uniform(
                jax.random.split(self.key, 2)[1],
                (self.n_spectra, self.n_chains, self.n_draws),
            ),
            pip=jax.random.uniform(
                jax.random.split(self.key, 3)[2],
                (self.n_spectra, self.n_chains, self.n_draws, self.n_compounds),
            ),
            idx=jnp.zeros((self.n_spectra, self.n_chains, self.n_draws)),
            log_h_ratio=jnp.ones(
                (self.n_spectra, self.n_chains, self.n_draws, self.n_compounds)
            ),
            weight=jax.random.uniform(
                jax.random.split(self.key, 4)[3],
                (self.n_spectra, self.n_chains, self.n_draws),
            ),
        )

    def test_sample_model_by_weight_output_shapes(self) -> None:
        """Test that sample_model_by_weight returns correct output shapes for a single spectrum."""
        n_samples = 10
        # Single spectrum
        single_spectrum_sample = MCMCSample(
            gamma=self.mock_sample.gamma[0],
            activeb=self.mock_sample.activeb[0],
            beta=self.mock_sample.beta[0],
            sigma=self.mock_sample.sigma[0],
            pip=self.mock_sample.pip[0],
            idx=self.mock_sample.idx[0],
            log_h_ratio=self.mock_sample.log_h_ratio[0],
            weight=self.mock_sample.weight[0],
        )
        result = sample_model_by_weight(single_spectrum_sample, n_samples, self.key)

        # Check output is MCMCSampleReduced
        self.assertIsInstance(result, MCMCSampleReduced)

        # Check shapes
        expected_gamma_shape = (n_samples, self.n_compounds)
        expected_pip_shape = (n_samples, self.n_compounds)
        expected_weight_shape = (n_samples,)

        self.assertEqual(result.gamma.shape, expected_gamma_shape)
        self.assertEqual(result.pip.shape, expected_pip_shape)
        self.assertEqual(result.weight.shape, expected_weight_shape)

    def test_sample_model_by_weight_different_n_values(self) -> None:
        """Test sample_model_by_weight with different n values (single spectrum)."""
        single_spectrum_sample = MCMCSample(
            gamma=self.mock_sample.gamma[0],
            activeb=self.mock_sample.activeb[0],
            beta=self.mock_sample.beta[0],
            sigma=self.mock_sample.sigma[0],
            pip=self.mock_sample.pip[0],
            idx=self.mock_sample.idx[0],
            log_h_ratio=self.mock_sample.log_h_ratio[0],
            weight=self.mock_sample.weight[0],
        )
        for n in [1, 5, 20]:
            result = sample_model_by_weight(single_spectrum_sample, n, self.key)
            self.assertEqual(result.gamma.shape[0], n)
            self.assertEqual(result.pip.shape[0], n)
            self.assertEqual(result.weight.shape[0], n)

    def test_sample_model_by_weight_single_spectrum_shapes(self) -> None:
        """Test single-spectrum sampling returns expected shapes."""
        single_spectrum_sample = MCMCSample(
            gamma=self.mock_sample.gamma[0],
            activeb=self.mock_sample.activeb[0],
            beta=self.mock_sample.beta[0],
            sigma=self.mock_sample.sigma[0],
            pip=self.mock_sample.pip[0],
            idx=self.mock_sample.idx[0],
            log_h_ratio=self.mock_sample.log_h_ratio[0],
            weight=self.mock_sample.weight[0],
        )
        n_samples = 7
        result = sample_model_by_weight(single_spectrum_sample, n_samples, self.key)
        self.assertIsInstance(result, MCMCSampleReduced)
        self.assertEqual(result.gamma.shape, (n_samples, self.n_compounds))
        self.assertEqual(result.pip.shape, (n_samples, self.n_compounds))
        self.assertEqual(result.weight.shape, (n_samples,))

    def test_sample_model_by_weight_reproducibility(self) -> None:
        """Test that sample_model_by_weight produces reproducible results for a single spectrum."""
        single_spectrum_sample = MCMCSample(
            gamma=self.mock_sample.gamma[0],
            activeb=self.mock_sample.activeb[0],
            beta=self.mock_sample.beta[0],
            sigma=self.mock_sample.sigma[0],
            pip=self.mock_sample.pip[0],
            idx=self.mock_sample.idx[0],
            log_h_ratio=self.mock_sample.log_h_ratio[0],
            weight=self.mock_sample.weight[0],
        )
        n_samples = 5
        result1 = sample_model_by_weight(single_spectrum_sample, n_samples, self.key)
        result2 = sample_model_by_weight(single_spectrum_sample, n_samples, self.key)

        # Results should be identical
        np.testing.assert_array_equal(result1.gamma, result2.gamma)
        np.testing.assert_array_equal(result1.pip, result2.pip)
        np.testing.assert_array_equal(result1.weight, result2.weight)

    def test_sample_model_by_weight_weight_shape_and_nonnegativity(self) -> None:
        """Weights in reduced output should be non-negative and sized to n samples."""
        single_spectrum_sample = MCMCSample(
            gamma=self.mock_sample.gamma[0],
            activeb=self.mock_sample.activeb[0],
            beta=self.mock_sample.beta[0],
            sigma=self.mock_sample.sigma[0],
            pip=self.mock_sample.pip[0],
            idx=self.mock_sample.idx[0],
            log_h_ratio=self.mock_sample.log_h_ratio[0],
            weight=jnp.ones((self.n_chains, self.n_draws)),
        )
        n_samples = 100
        result = sample_model_by_weight(single_spectrum_sample, n_samples, self.key)
        self.assertEqual(result.weight.shape, (n_samples,))
        self.assertTrue(jnp.all(result.weight >= 0))

    def test_sample_model_by_weight_input_validation(self) -> None:
        """Invalid shapes should raise an error for single-spectrum sampling."""
        # Wrong gamma dims for single spectrum (expect 2D: chains, draws)
        invalid_sample = MCMCSample(
            gamma=jax.random.bernoulli(self.key, 0.3, (self.n_compounds,)),
            activeb=self.mock_sample.activeb[0],
            beta=self.mock_sample.beta[0],
            sigma=self.mock_sample.sigma[0],
            pip=self.mock_sample.pip[0],
            idx=self.mock_sample.idx[0],
            log_h_ratio=self.mock_sample.log_h_ratio[0],
            weight=self.mock_sample.weight[0],
        )
        with self.assertRaises(Exception):
            _ = sample_model_by_weight(invalid_sample, n_models=5, key=self.key)


class TestGetBetas(unittest.TestCase):
    def setUp(self) -> None:
        self.key = jax.random.PRNGKey(0)

    def test_get_betas_recovers_values_and_locations(self) -> None:
        N = 200
        C = 10

        X = jax.random.normal(self.key, (N, C))

        intercept_true = 0.5
        relevant = jnp.array([2, 5, 7])
        true_coefs = jnp.zeros((C,))
        true_coefs = true_coefs.at[relevant].set(jnp.array([1.5, -2.0, 0.7]))

        Y = intercept_true + X @ true_coefs
        Y = Y.reshape(N, 1)

        gamma = jnp.zeros((1, C + 1), dtype=bool)
        gamma = gamma.at[0, 0].set(True)  # intercept
        gamma = gamma.at[0, 1 + relevant].set(True)

        weights = jnp.ones(N)
        betas = compute_time_series_betas(X, Y, gamma, weights)  # (1, C+1, 1)
        betas = betas[0, :, 0]  # (C+1,)

        intercept_est = betas[0]
        coef_est = betas[1:]  # (C,)

        # Check values on active features and intercept
        np.testing.assert_allclose(intercept_est, intercept_true, rtol=1e-5, atol=1e-6)
        np.testing.assert_allclose(
            coef_est[relevant], true_coefs[relevant], rtol=1e-5, atol=1e-6
        )

        # Inactive features should be NaN
        inactive_mask = jnp.ones((C,), dtype=bool).at[relevant].set(False)
        self.assertTrue(bool(jnp.all(jnp.isnan(coef_est[inactive_mask]))))

        # Locations of non-NaN coefficients match the intended relevant indices
        non_nan_indices = jnp.where(~jnp.isnan(coef_est))[0]
        np.testing.assert_array_equal(
            np.sort(np.array(non_nan_indices)),
            np.sort(np.array(relevant)),
        )

    def test_get_betas_shapes_multiple_times_and_samples(self) -> None:
        N = 60  # modes
        C = 10  # features (without intercept)
        T = 30  # times
        S = 20  # number of gamma samples

        key1, key2, key3 = jax.random.split(self.key, 3)

        X = jax.random.normal(key1, (N, C))
        Y = jax.random.normal(key2, (N, T))

        # gamma: (S, C+1) with intercept always active
        gamma = jax.random.bernoulli(key3, p=0.5, shape=(S, C + 1))
        gamma = gamma.at[:, 0].set(True)

        weights = jnp.ones(N)
        betas = compute_time_series_betas(X, Y, gamma, weights)  # (S, C+1, T)
        self.assertEqual(betas.shape, (S, C + 1, T))

        # Inactive features should be NaN across all times; active (incl. intercept) should be non-NaN across all times
        all_nan_per_feat = jnp.all(jnp.isnan(betas), axis=2)  # (S, C+1)
        np.testing.assert_array_equal(
            np.array(all_nan_per_feat), np.logical_not(np.array(gamma))
        )

        all_non_nan_per_feat = jnp.all(~jnp.isnan(betas), axis=2)  # (S, C+1)
        np.testing.assert_array_equal(np.array(all_non_nan_per_feat), np.array(gamma))


class TestGetSummaryStatistics(unittest.TestCase):
    def test_shapes_and_basics(self) -> None:
        # N samples, C features, T times
        N, C, T = 5, 4, 3
        key = jax.random.PRNGKey(0)
        k1, k2, k3 = jax.random.split(key, 3)

        # Betas: (N, C, T)
        betas = jax.random.normal(k1, (N, C, T))
        # Gamma/PIP: (N, C) — ensure at least one active per feature on average
        gamma = jax.random.bernoulli(k2, p=0.6, shape=(N, C)).astype(jnp.float32)
        pip = jax.random.uniform(k3, (N, C))
        # Weights: (N,)
        weights = jnp.arange(1, N + 1, dtype=jnp.float32)

        stats = summarize_time_feature_stats(betas, gamma, pip, weights)

        # stats fields are vmapped over time; each should have shape (T, C)
        assert stats.beta_mean.shape == (T, C)
        assert stats.beta_std.shape == (T, C)
        assert stats.conditional_beta.shape == (T, C)
        assert stats.conditional_beta_std.shape == (T, C)
        assert stats.pip.shape == (C,)  # time-invariant

        # Basic sanity: std is non-negative
        assert jnp.all(stats.beta_std >= 0)
        assert jnp.all(stats.conditional_beta_std >= 0)


def test_prepare_design_matrix_reorders_and_pads() -> None:
    # X: (modes, compounds)
    X = jnp.arange(4 * 5, dtype=jnp.float32).reshape(4, 5)
    # Active features: columns 1, 3, 4 (3 active)
    gamma_i = jnp.array([False, True, False, True, True])
    n_active = int(gamma_i.sum())

    # Case 1: max_active == n_active (no padding)
    max_active = n_active
    X_padded, feature_indices = _build_active_design_matrix(X, gamma_i, max_active)

    assert X_padded.shape == (4, max_active)
    assert feature_indices.shape == (max_active,)

    # Expected ordering follows argsort(~gamma_i): actives first
    expected_order = jnp.argsort(~gamma_i)[:max_active]
    np.testing.assert_array_equal(np.array(feature_indices), np.array(expected_order))
    np.testing.assert_allclose(
        np.array(X_padded), np.array(X[:, expected_order]), rtol=0, atol=0
    )

    # Case 2: max_active > n_active (padding should zero last columns and set -1 index)
    max_active = n_active + 1
    X_padded2, feature_indices2 = _build_active_design_matrix(X, gamma_i, max_active)

    assert X_padded2.shape == (4, max_active)
    assert feature_indices2.shape == (max_active,)

    expected_order2 = jnp.argsort(~gamma_i)[:n_active]
    # First n_active entries equal expected_order2, last is -1 (padding)
    np.testing.assert_array_equal(
        np.array(feature_indices2[:n_active]), np.array(expected_order2)
    )
    assert int(feature_indices2[n_active]) == -1

    # First n_active columns equal the selected columns of X; last column is all zeros
    np.testing.assert_allclose(
        np.array(X_padded2[:, :n_active]),
        np.array(X[:, expected_order2]),
        rtol=0,
        atol=0,
    )
    np.testing.assert_allclose(
        np.array(X_padded2[:, n_active]), np.zeros((4,)), rtol=0, atol=0
    )


def test_single_fit_jax_recovers_active_betas_and_nans_inactive() -> None:
    # Build deterministic design X with intercept column included
    N = 10
    T = 2
    X_no = jnp.stack(
        [
            jnp.linspace(-1.0, 1.0, N),
            jnp.linspace(0.0, 2.0, N),
            jnp.linspace(1.0, -1.0, N),
        ],
        axis=1,
    )  # (N, 3)
    X = jnp.concatenate([jnp.ones((N, 1)), X_no], axis=1)  # (N, 4)

    # Activate intercept (0) and column 2 (second feature of X_no)
    gamma = jnp.array([True, False, True, False])  # (4,)
    active_cols = jnp.array([0, 2])

    # True betas for T=2 times
    beta_active_true = jnp.array([[2.0, -1.0], [0.5, 1.5]])  # (2, T)

    # Generate Y with no noise: Y = X_active @ beta_active_true
    Y = X[:, active_cols] @ beta_active_true  # (N, T)

    # Use max_active > n_active to exercise padding path
    result = _solve_active_least_squares(
        X, Y, gamma, max_active=int(gamma.sum()) + 1
    )  # (4, T)

    # Shape check
    assert result.shape == (4, T)

    # Active coefficients recovered
    np.testing.assert_allclose(
        np.array(result[0]), np.array(beta_active_true[0]), rtol=1e-6, atol=1e-8
    )
    np.testing.assert_allclose(
        np.array(result[2]), np.array(beta_active_true[1]), rtol=1e-6, atol=1e-8
    )

    # Inactive coefficients are NaN across all times
    assert bool(jnp.all(jnp.isnan(result[1])))
    assert bool(jnp.all(jnp.isnan(result[3])))


class TestStatsToCompoundByTimeMatrix(unittest.TestCase):
    """Test cases for _stats_to_compound_by_time_matrix."""

    def test_output_shape(self) -> None:
        """Test that output has correct shape (compounds, 3*time)."""
        T, C = 5, 3

        stats = WeightedFeatureStats(
            pip=jnp.ones(C),
            beta_mean=jnp.zeros((T, C)),
            beta_std=jnp.ones((T, C)),
            conditional_beta=jnp.ones((T, C)),
            conditional_beta_std=jnp.zeros((T, C)),
        )

        result = _stats_to_compound_by_time_matrix(stats)

        # Should be (compounds, 3*time)
        expected_shape = (C, 3 * T)
        self.assertEqual(result.shape, expected_shape)

    def test_different_time_and_compound_dimensions(self) -> None:
        """Test with various time and compound dimensions."""
        key = jax.random.PRNGKey(42)

        for T, C in [(1, 1), (3, 2), (10, 5), (4, 8)]:
            k1, k2, k3 = jax.random.split(key, 3)
            stats = WeightedFeatureStats(
                pip=jax.random.uniform(k1, (C,)),
                beta_mean=jax.random.normal(k2, (T, C)),
                beta_std=jax.random.uniform(k3, (T, C)),
                conditional_beta=jax.random.normal(key, (T, C)),
                conditional_beta_std=jax.random.uniform(key, (T, C)),
            )

            result = _stats_to_compound_by_time_matrix(stats)
            self.assertEqual(result.shape, (C, 3 * T))

    def test_values_arranged_correctly(self) -> None:
        """Test that columns are grouped by time point."""
        T, C = 2, 3

        # Create distinct values for each field
        cbeta = jnp.arange(T * C, dtype=jnp.float32).reshape(T, C) * 10  # (T, C)
        cbeta_std = jnp.arange(T * C, dtype=jnp.float32).reshape(T, C) * 100  # (T, C)
        pip = jnp.arange(C, dtype=jnp.float32) * 1000  # (C,)

        stats = WeightedFeatureStats(
            pip=pip,
            beta_mean=jnp.zeros((T, C)),
            beta_std=jnp.zeros((T, C)),
            conditional_beta=cbeta,
            conditional_beta_std=cbeta_std,
        )

        result = _stats_to_compound_by_time_matrix(stats)

        # For each compound c, check columns are [cbeta[0,c], cbeta_std[0,c], pip[c], cbeta[1,c], cbeta_std[1,c], pip[c]]
        for c in range(C):
            for t in range(T):
                col_idx = t * 3
                np.testing.assert_allclose(result[c, col_idx], cbeta[t, c])
                np.testing.assert_allclose(result[c, col_idx + 1], cbeta_std[t, c])
                np.testing.assert_allclose(result[c, col_idx + 2], pip[c])


class TestStatsToBetaDf(unittest.TestCase):
    """Test cases for _stats_to_beta_df."""

    def test_output_is_dataframe(self) -> None:
        """Test that output is a pandas DataFrame."""
        T, C = 3, 2

        stats = WeightedFeatureStats(
            pip=jnp.ones(C),
            beta_mean=jnp.zeros((T, C)),
            beta_std=jnp.ones((T, C)),
            conditional_beta=jnp.ones((T, C)),
            conditional_beta_std=jnp.zeros((T, C)),
        )

        feature_names = [f"feature_{i}" for i in range(C)]
        time_names = [f"t_{i}" for i in range(T)]

        result = _stats_to_beta_df(stats, feature_names, time_names)

        self.assertIsInstance(result, pd.DataFrame)

    def test_output_shape_and_index(self) -> None:
        """Test DataFrame has correct shape and index."""
        T, C = 4, 5

        stats = WeightedFeatureStats(
            pip=jnp.ones(C),
            beta_mean=jnp.zeros((T, C)),
            beta_std=jnp.ones((T, C)),
            conditional_beta=jnp.ones((T, C)),
            conditional_beta_std=jnp.zeros((T, C)),
        )

        feature_names = [f"feature_{i}" for i in range(C)]
        time_names = [f"t_{i}" for i in range(T)]

        result = _stats_to_beta_df(stats, feature_names, time_names)

        # Shape should be (compounds, 3*time)
        self.assertEqual(result.shape, (C, 3 * T))

        # Index should be feature names
        self.assertEqual(list(result.index), feature_names)

    def test_multiindex_columns(self) -> None:
        """Test that columns are MultiIndex with (time, statistic)."""
        T, C = 2, 3

        stats = WeightedFeatureStats(
            pip=jnp.ones(C),
            beta_mean=jnp.zeros((T, C)),
            beta_std=jnp.ones((T, C)),
            conditional_beta=jnp.ones((T, C)),
            conditional_beta_std=jnp.zeros((T, C)),
        )

        feature_names = ["intercept", "compound_A", "compound_B"]
        time_names = ["0s", "5s"]

        result = _stats_to_beta_df(stats, feature_names, time_names)

        # Check MultiIndex structure
        self.assertIsInstance(result.columns, pd.MultiIndex)
        self.assertEqual(result.columns.nlevels, 2)

        # Check level names exist
        self.assertEqual(list(result.columns.levels[0]), time_names)
        self.assertEqual(
            list(result.columns.levels[1]), ["beta_mean", "beta_std", "pip_mean"]
        )

    def test_different_dimensions(self) -> None:
        """Test with various dimensions."""
        key = jax.random.PRNGKey(0)

        for T, C in [(1, 1), (3, 4), (5, 2)]:
            stats = WeightedFeatureStats(
                pip=jax.random.uniform(key, (C,)),
                beta_mean=jax.random.normal(key, (T, C)),
                beta_std=jax.random.uniform(key, (T, C)),
                conditional_beta=jax.random.normal(key, (T, C)),
                conditional_beta_std=jax.random.uniform(key, (T, C)),
            )

            feature_names = [f"f{i}" for i in range(C)]
            time_names = [f"t{i}" for i in range(T)]

            result = _stats_to_beta_df(stats, feature_names, time_names)

            self.assertEqual(result.shape, (C, 3 * T))
            self.assertEqual(len(result.index), C)


class TestPropagateModelToTimeSeries(unittest.TestCase):
    """Test cases for propagate_model_to_time_series.

    Note: gamma includes intercept (compounds+1) but X must NOT include intercept.
    """

    def setUp(self) -> None:
        """Set up test data.

        Key point: gamma has shape (chains, draws, compounds+1) with intercept,
        but X has shape (n_modes, compounds) WITHOUT intercept.
        """
        self.key = jax.random.PRNGKey(123)

        # Dimensions
        self.n_chains = 2
        self.n_draws = 3
        self.n_compounds = 4  # number of features WITHOUT intercept
        self.n_modes = 10
        self.n_times = 5

        # Create mock MCMCSample (single target)
        k1, k2, k3, k4 = jax.random.split(self.key, 4)

        # IMPORTANT: gamma has shape (chains, draws, compounds+1) - includes intercept!
        self.samples = MCMCSample(
            gamma=jax.random.bernoulli(
                k1, 0.5, (self.n_chains, self.n_draws, self.n_compounds + 1)
            ),
            activeb=jnp.ones((self.n_chains, self.n_draws, self.n_compounds + 1)),
            beta=jax.random.normal(
                k2, (self.n_chains, self.n_draws, self.n_compounds + 1)
            ),
            sigma=jax.random.uniform(k3, (self.n_chains, self.n_draws)),
            pip=jax.random.uniform(
                k4, (self.n_chains, self.n_draws, self.n_compounds + 1)
            ),
            idx=jnp.zeros((self.n_chains, self.n_draws)),
            log_h_ratio=jnp.ones((self.n_chains, self.n_draws, self.n_compounds + 1)),
            weight=jnp.ones((self.n_chains, self.n_draws))
            / (self.n_chains * self.n_draws),
        )

        # X does NOT include intercept - shape (n_modes, n_compounds)
        self.X = pd.DataFrame(
            jax.random.normal(self.key, (self.n_modes, self.n_compounds)),
            columns=[f"compound_{i}" for i in range(self.n_compounds)],
        )

        # Y is time series data
        self.Y = pd.DataFrame(
            jax.random.normal(k1, (self.n_modes, self.n_times)),
            columns=[f"t_{i}s" for i in range(self.n_times)],
        )

        # feature_names INCLUDES intercept at position 0
        self.feature_names = ["intercept"] + [
            f"compound_{i}" for i in range(self.n_compounds)
        ]

    def test_output_is_dataframe(self) -> None:
        """Test that output is a pandas DataFrame."""
        result = propagate_model_to_time_series(
            self.samples, self.X, self.Y, self.feature_names, n=10, seed=42
        )

        self.assertIsInstance(result, pd.DataFrame)

    def test_output_shape(self) -> None:
        """Test DataFrame has correct shape (n_compounds+1, 3*n_times)."""
        result = propagate_model_to_time_series(
            self.samples, self.X, self.Y, self.feature_names, n=10, seed=42
        )

        # Shape: (n_compounds+1 [with intercept], 3*n_times)
        expected_shape = (self.n_compounds + 1, 3 * self.n_times)
        self.assertEqual(result.shape, expected_shape)

    def test_output_index_matches_feature_names(self) -> None:
        """Test that DataFrame index matches feature names (including intercept)."""
        result = propagate_model_to_time_series(
            self.samples, self.X, self.Y, self.feature_names, n=10, seed=42
        )

        self.assertEqual(list(result.index), self.feature_names)
        self.assertEqual(len(result.index), self.n_compounds + 1)

    def test_multiindex_columns_structure(self) -> None:
        """Test that columns are MultiIndex with (time, statistic)."""
        result = propagate_model_to_time_series(
            self.samples, self.X, self.Y, self.feature_names, n=10, seed=42
        )

        self.assertIsInstance(result.columns, pd.MultiIndex)
        self.assertEqual(result.columns.nlevels, 2)

        # First level should be time names from Y.columns
        self.assertEqual(list(result.columns.levels[0]), list(self.Y.columns))

    def test_reproducibility_with_same_seed(self) -> None:
        """Test that same seed produces identical results."""
        result1 = propagate_model_to_time_series(
            self.samples, self.X, self.Y, self.feature_names, n=20, seed=999
        )
        result2 = propagate_model_to_time_series(
            self.samples, self.X, self.Y, self.feature_names, n=20, seed=999
        )

        pd.testing.assert_frame_equal(result1, result2)

    def test_handles_multi_target_samples(self) -> None:
        """Test that multi-target samples (4D gamma) use only first target."""
        k1, k2, k3, k4 = jax.random.split(self.key, 4)
        n_targets = 3

        # Create multi-target samples with gamma shape (targets, chains, draws, compounds+1)
        multi_samples = MCMCSample(
            gamma=jax.random.bernoulli(
                k1, 0.5, (n_targets, self.n_chains, self.n_draws, self.n_compounds + 1)
            ),
            activeb=jnp.ones(
                (n_targets, self.n_chains, self.n_draws, self.n_compounds + 1)
            ),
            beta=jax.random.normal(
                k2, (n_targets, self.n_chains, self.n_draws, self.n_compounds + 1)
            ),
            sigma=jax.random.uniform(k3, (n_targets, self.n_chains, self.n_draws)),
            pip=jax.random.uniform(
                k4, (n_targets, self.n_chains, self.n_draws, self.n_compounds + 1)
            ),
            idx=jnp.zeros((n_targets, self.n_chains, self.n_draws)),
            log_h_ratio=jnp.ones(
                (n_targets, self.n_chains, self.n_draws, self.n_compounds + 1)
            ),
            weight=jnp.ones((n_targets, self.n_chains, self.n_draws))
            / (self.n_chains * self.n_draws),
        )

        # Should use only first target
        result = propagate_model_to_time_series(
            multi_samples, self.X, self.Y, self.feature_names, n=10, seed=42
        )

        # Should still produce correct shape
        expected_shape = (self.n_compounds + 1, 3 * self.n_times)
        self.assertEqual(result.shape, expected_shape)

    def test_varying_n_samples(self) -> None:
        """Test with different numbers of posterior samples."""
        for n in [5, 20, 50]:
            result = propagate_model_to_time_series(
                self.samples, self.X, self.Y, self.feature_names, n=n, seed=42
            )

            # Shape should be independent of n
            expected_shape = (self.n_compounds + 1, 3 * self.n_times)
            self.assertEqual(result.shape, expected_shape)

    def test_accepts_numpy_array_for_X(self) -> None:
        """Test that X can be a numpy array (without intercept)."""
        X_array = np.array(self.X)

        result = propagate_model_to_time_series(
            self.samples, X_array, self.Y, self.feature_names, n=10, seed=42
        )

        self.assertIsInstance(result, pd.DataFrame)
        expected_shape = (self.n_compounds + 1, 3 * self.n_times)
        self.assertEqual(result.shape, expected_shape)

    def test_different_time_dimensions(self) -> None:
        """Test with different numbers of time points."""
        for n_times in [3, 10, 20]:
            Y_test = pd.DataFrame(
                jax.random.normal(self.key, (self.n_modes, n_times)),
                columns=[f"t_{i}" for i in range(n_times)],
            )

            result = propagate_model_to_time_series(
                self.samples, self.X, Y_test, self.feature_names, n=10, seed=42
            )

            expected_shape = (self.n_compounds + 1, 3 * n_times)
            self.assertEqual(result.shape, expected_shape)

    def test_dtype_float32(self) -> None:
        """Test with float32 dtype to cover the else branch."""
        result = propagate_model_to_time_series(
            self.samples,
            self.X,
            self.Y,
            self.feature_names,
            n=10,
            seed=42,
            dtype="float32",
        )

        self.assertIsInstance(result, pd.DataFrame)
        expected_shape = (self.n_compounds + 1, 3 * self.n_times)
        self.assertEqual(result.shape, expected_shape)
