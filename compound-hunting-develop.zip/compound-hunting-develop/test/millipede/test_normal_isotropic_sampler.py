import jax
import jax.numpy as jnp

from compound_hunting.millipede.data_structures import MCMCInputs, MCMCSample
from compound_hunting.millipede.isotropic_sampling import _compute_i_prob
from compound_hunting.millipede.normal_isotropic_sampler import (
    _create_mcmc_step_fn,
    _mcmc_move_isotropic,
    initialize_mcmc_sample,
    run_mcmc_chain_scan,
)


def dummy_inputs() -> MCMCInputs:
    """Generate dummy MCMCInputs with fixed shapes for testing."""
    P = 30  # Number of features
    Pa = 1  # Number of assumed features
    N = 10  # Number of observations
    X = jnp.ones((N, P + Pa))
    Z = jnp.ones((P + Pa,))
    XX = jnp.eye(P + Pa)
    XX_diag = jnp.ones((P + Pa,))
    YY = 100.0
    N_nu0 = 10.0
    tau = 1.0
    tau_intercept = 1.0
    log_h_ratio = jnp.array(-4.2)
    epsilon = 1e-5
    explore = 0.1
    xi = jnp.array([0.0])
    comb_factor = 1.0
    key = jax.random.PRNGKey(0)
    return MCMCInputs(
        P=P,
        Pa=Pa,
        X=X,
        Z=Z,
        XX=XX,
        XX_diag=XX_diag,
        YY=YY,
        N_nu0=N_nu0,
        tau=tau,
        tau_intercept=tau_intercept,
        log_h_ratio=log_h_ratio,
        epsilon=epsilon,
        explore=explore,
        xi=xi,
        comb_factor=comb_factor,
        key=key,
        max_active=6,
    )


def test_initialize_mcmc_sample():
    """Test that initialize_mcmc_sample returns an MCMCSample with correct shapes."""
    inputs = dummy_inputs()
    sample = initialize_mcmc_sample(inputs)
    P, Pa = inputs.P, inputs.Pa

    # gamma and active should be of shape (P,)
    assert sample.gamma.shape == (P,)

    # activeb, activeb_mask should be of shape (P+Pa,)
    assert sample.activeb.shape == (P + Pa,)
    # beta should be of shape (P+Pa,)
    assert sample.beta.shape == (P + Pa,)

    # sigma should be a scalar (ndim = 0)
    assert jnp.ndim(sample.sigma) == 0

    # pip should be of shape (P,)
    assert sample.pip.shape == (P,)

    # idx should be a scalar (ndim = 0)
    assert jnp.ndim(sample.idx) == 0

    assert sample.log_h_ratio.shape == inputs.log_h_ratio.shape

    # weight should be scalar
    assert jnp.ndim(sample.weight) == 0


def test_run_mcmc_chain_scan():
    """Test that run_mcmc_chain_scan returns outputs with correct shapes."""
    inputs = dummy_inputs()
    n_burnin = 5
    n_samples = 10
    final_state, samples = run_mcmc_chain_scan(inputs, n_burnin, n_samples)
    P, Pa = inputs.P, inputs.Pa

    # final_state should be a single MCMCSample (not batched)
    assert isinstance(final_state, MCMCSample)

    # The returned samples are batched from the scan; check one field.
    # activeb should be batched with shape (n_samples, P+Pa)
    assert samples.activeb.shape == (n_samples, P + Pa)
    # beta should be batched with shape (n_samples, P+Pa)
    assert samples.beta.shape == (n_samples, P + Pa)
    # sigma should be batched with shape (n_samples,)
    assert samples.sigma.shape == (n_samples,)


def test_create_mcmc_step_fn():
    """Test that _create_mcmc_step_fn returns a callable producing a sample with expected shapes."""
    inputs = dummy_inputs()
    step_fn = _create_mcmc_step_fn(inputs)
    sample = initialize_mcmc_sample(inputs)
    P, Pa = inputs.P, inputs.Pa

    # Create a new key for stepping.
    key = jax.random.PRNGKey(1)
    next_sample = step_fn(
        sample.gamma, sample.activeb, sample.log_h_ratio, sample.pip, key
    )

    # Check that the resulting sample has expected shapes.
    assert next_sample.gamma.shape == (P,)
    assert next_sample.activeb.shape == (P + Pa,)
    assert next_sample.beta.shape == (P + Pa,)


def test_mcmc_move_isotropic():
    """Test that _mcmc_move_isotropic returns an updated sample with correct shapes."""
    inputs = dummy_inputs()
    sample = initialize_mcmc_sample(inputs)
    key = jax.random.PRNGKey(2)
    P, Pa = inputs.P, inputs.Pa

    new_sample = _mcmc_move_isotropic(
        gamma=sample.gamma,
        assumed_mask=sample.activeb,
        log_h_ratio=sample.log_h_ratio,
        prev_add_prob=sample.pip,
        key=key,
        inputs=inputs,
    )
    # Verify that new_sample's key fields have correct shapes.
    assert new_sample.gamma.shape == (P,)
    assert new_sample.beta.shape == (P + Pa,)


def test_beta_nan_matches_active_mask_and_weight():
    """We check two things per recorded sample:
    - beta NaNs match the inactive mask exactly (i.e., non-NaN beta only where
      `activeb` is True). This guards against the old bug where beta was computed
      pre-flip but gamma was recorded post-flip.
    - weight equals 1 / mean(i_prob) computed on the recorded (post-flip) state
    - check the first Pa elements of activeb are always True (assumed covariates)
    - check the rest of activeb matches gamma
    """
    inputs = dummy_inputs()

    # Ensure we can initialize and then step
    _ = initialize_mcmc_sample(inputs)

    n_burnin = 3
    n_samples = 7
    _, samples = run_mcmc_chain_scan(inputs, n_burnin, n_samples)

    # For each recorded sample: non-NaN betas correspond exactly to activeb mask
    for i in range(n_samples):
        beta_i = samples.beta[i]
        activeb_i = samples.activeb[i]
        # gamma alignment with activeb: assumed covariates ([:Pa]) always True; the rest equals gamma
        Pa = inputs.Pa
        gamma_i = samples.gamma[i]
        assert jnp.all(activeb_i[:Pa])
        assert jnp.all(activeb_i[Pa:] == gamma_i)

        isnan_beta = jnp.isnan(beta_i)
        # inactive positions (where activeb is False) must be NaN in beta
        assert jnp.all(isnan_beta == jnp.logical_not(activeb_i))

        # weight equals 1 / mean(i_prob) for the RECORDED state
        pip_i = samples.pip[i]
        i_prob_i = _compute_i_prob(
            gamma_i,
            pip_i,
            inputs.xi,
            inputs.comb_factor,
            inputs.epsilon,
            inputs.explore,
        )
        expected_weight = 1.0 / jnp.maximum(jnp.mean(i_prob_i), 1e-12)
        assert jnp.allclose(samples.weight[i], expected_weight, rtol=1e-5, atol=1e-7)
