from unittest.mock import MagicMock, patch

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from compound_hunting.millipede.data_structures import MCMCSample
from compound_hunting.millipede.export_samples import get_arviz_inference_data


@pytest.fixture
def mock_mcmc_sample():
    """Create a mock MCMCSample for testing."""
    # Create a sample with 1 dataset, 2 chains, 10 draws, and 5 compounds
    n_chains = 2
    n_draws = 10
    n_compounds = 5

    pip = np.random.uniform(0, 1, (n_chains, n_draws, n_compounds))

    beta = np.random.normal(0, 1, (n_chains, n_draws, n_compounds))
    sigma = np.random.uniform(0.1, 1.0, (n_chains, n_draws))

    # These aren't used by get_arviz_inference_data but are needed for the MCMCSample
    gamma = np.zeros((n_chains, n_draws, n_compounds), dtype=bool)
    activeb = np.zeros((n_chains, n_draws, n_compounds), dtype=bool)
    idx = np.zeros((n_chains, n_draws), dtype=int)
    log_h_ratio = np.zeros((n_chains, n_draws, n_compounds))
    weight = np.ones((n_chains, n_draws))

    sample = MCMCSample(
        gamma=gamma,
        activeb=activeb,
        beta=beta,
        sigma=sigma,
        pip=pip,
        idx=idx,
        log_h_ratio=log_h_ratio,
        weight=weight,
    )
    batched_sample = jax.tree.map(lambda x: jnp.expand_dims(x, axis=0), sample)
    return batched_sample


@pytest.mark.parametrize(
    "cid_names",
    [
        None,  # Test with default integer indices
        ["A", "B", "C", "D", "E"],  # Test with string identifiers
        [101, 102, 103, 104, 105],  # Test with integer identifiers
    ],
)
def test_get_arviz_inference_data(mock_mcmc_sample, cid_names):
    """Test conversion of MCMCSample to ArviZ InferenceData."""
    # Skip test if arviz is not installed
    az = pytest.importorskip("arviz")

    datasets_names = ["dataset1"]
    inference_data = get_arviz_inference_data(
        mock_mcmc_sample, cid_names, datasets_names
    )

    assert isinstance(inference_data, az.InferenceData)

    # Check that the posterior group exists
    assert hasattr(inference_data, "posterior")

    # Check that all expected variables are in the posterior
    expected_vars = ["pip", "gamma", "beta", "sigma"]
    for var in expected_vars:
        assert var in inference_data.posterior.data_vars

    # Check dimensions
    n_datasets, n_chains, n_draws, n_compounds = mock_mcmc_sample.pip.shape

    assert inference_data.posterior.pip.shape == (
        n_chains,
        n_draws,
        n_compounds,
        n_datasets,
    )
    assert inference_data.posterior.gamma.shape == (
        n_chains,
        n_draws,
        n_compounds,
        n_datasets,
    )
    assert inference_data.posterior.beta.shape == (
        n_chains,
        n_draws,
        n_compounds,
        n_datasets,
    )
    assert inference_data.posterior.sigma.shape == (
        n_chains,
        n_draws,
        n_datasets,
    )

    # Check coordinates
    expected_compounds = (
        cid_names if cid_names is not None else list(range(n_compounds))
    )
    expected_datasets = ["dataset1"]
    np.testing.assert_array_equal(
        inference_data.posterior.coords["compound"].values, expected_compounds
    )
    np.testing.assert_array_equal(
        inference_data.posterior.coords["dataset"].values, expected_datasets
    )


def test_get_arviz_inference_data_wrong_shape():
    """Test that the function raises ValueError for wrong shape."""
    # Create a sample with wrong shape. 3D, should be 4D
    wrong_shape_pip = np.random.uniform(0, 1, (2, 10, 5))

    # Create a minimal MCMCSample with wrong shape
    sample = MagicMock(spec=MCMCSample)
    sample.pip = wrong_shape_pip

    with pytest.raises(ValueError):
        get_arviz_inference_data(sample)


def test_get_arviz_inference_data_no_arviz(mock_mcmc_sample):
    """Test that the function raises ImportError when arviz is not installed."""
    # Mock importlib.util.find_spec to return None for arviz
    with patch("importlib.util.find_spec", return_value=None):
        with pytest.raises(ImportError):
            get_arviz_inference_data(mock_mcmc_sample)


def test_get_arviz_inference_data_no_datasets_names(mock_mcmc_sample):
    """Test conversion without providing datasets_names (uses default)."""
    # Skip test if arviz is not installed
    az = pytest.importorskip("arviz")

    # Call without datasets_names parameter to cover the else branch (line 69)
    inference_data = get_arviz_inference_data(
        mock_mcmc_sample, cid_names=None, datasets_names=None
    )

    assert isinstance(inference_data, az.InferenceData)

    # Check that the posterior group exists
    assert hasattr(inference_data, "posterior")

    # Check that dataset coordinates use default string indices
    n_datasets = mock_mcmc_sample.pip.shape[0]
    expected_datasets = [f"{i}" for i in range(n_datasets)]
    np.testing.assert_array_equal(
        inference_data.posterior.coords["dataset"].values, expected_datasets
    )
