"""
Tests for functions in src/picarro_millipede/prepare_chain_inputs.py.

These tests check that _add_intercept and _prepare_chain_inputs produce outputs
having the expected shapes and computed values.
"""

import jax.numpy as jnp
import pytest

from compound_hunting.millipede.prepare_chain_inputs import (
    _add_intercept,
    _expand_y,
    _prepare_chain_inputs,
)


def test_add_intercept():
    """Test that _add_intercept correctly appends a column of ones.

    Given an input 2D array of shape (N, D), the returned array should have shape (N, D+1)
    with the last column equal to ones. Also tests 3D input with leading batch dimension.
    """
    # Create a dummy array with shape (5, 3)
    X = jnp.array([[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15]])
    X_int = _add_intercept(X)

    # Check that the output shape is (5, 4)
    assert X_int.shape == (5, 4)
    # Check that the first column is all ones
    assert jnp.all(X_int[..., 0] == 1)

    # Test with 3D input by broadcasting X to shape (1, 5, 3)
    X_3d = jnp.expand_dims(X, axis=0)
    X_3d_int = _add_intercept(X_3d)

    # Check that the output shape is (1, 5, 4)
    assert X_3d_int.shape == (1, 5, 4)
    # Check that the first column is all ones
    assert jnp.all(X_3d_int[..., 0] == 1)


@pytest.mark.parametrize(
    "input_array, expected_shape",
    [
        (jnp.ones(5), (1, 5)),  # 1D array -> 2D array
        (jnp.ones((3, 5)), (3, 5)),  # 2D array -> unchanged
        (jnp.zeros(1), (1, 1)),
    ],
)
def test_expand_y(input_array, expected_shape):
    """Test _expand_y function with various input shapes."""
    result = _expand_y(input_array)

    # Check shape
    assert result.shape == expected_shape

    # Check values are preserved
    if input_array.ndim == 1:
        assert jnp.array_equal(result[0], input_array)
    else:
        assert jnp.array_equal(result, input_array)


def test_prepare_chain_inputs():
    """Test that _prepare_chain_inputs returns a correctly populated MCMCInputs instance.

    This test creates dummy input data, calls _prepare_chain_inputs, and then checks that:
      - The computed fields such as Z, XX, XX_diag, YY, N_nu0, and log_h_ratio have the expected shapes and values.
    """
    # Set up dummy input parameters
    N = 5  # Number of observations
    D = 3  # Number of original features (without intercept)
    X = jnp.arange(N * D, dtype=jnp.float32).reshape(N, D) + 1  # Create a (5,3) matrix
    y = jnp.array([1, 2, 3, 4, 5], dtype=jnp.float32)  # Response vector of shape (5,)
    S = 2.0  # Expected number of active features
    tau = 1.0
    tau_intercept = 1.0
    nu0 = 0.5
    lambda0 = 2.0
    explore = 0.5
    seed = 0
    max_active = 2
    Pa = 1  # this is included in the columns of X

    inputs = _prepare_chain_inputs(
        X, y, S, tau, tau_intercept, nu0, lambda0, explore, seed, max_active, Pa
    )

    # Original P should equal D - 1; Pa is set to 1.
    assert inputs.P == D - 1
    assert inputs.Pa == Pa

    # Z should have shape (D,)
    assert inputs.Z.shape == (D,)

    # XX (covariance) should be of shape (D, D)
    assert inputs.XX.shape == (D, D)
    # XX_diag should be a 1D array of length D
    assert inputs.XX_diag.shape == (D,)

    # Check precision parameters.
    assert inputs.tau == tau
    assert inputs.tau_intercept == tau_intercept

    # epsilon should be a small positive number.
    assert inputs.epsilon > 0
