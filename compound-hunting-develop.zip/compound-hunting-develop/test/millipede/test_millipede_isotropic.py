import unittest

import jax
import jax.numpy as jnp
import numpy as np

from compound_hunting.millipede.data_structures import (
    MCMCDiagnostics,
    MCMCResults,
    MCMCSample,
)
from compound_hunting.millipede.millipede_isotropic import isotropic_millipede


class TestIsotropicMillipede(unittest.TestCase):
    """Test cases for the isotropic_millipede function."""

    def setUp(self) -> None:
        key = jax.random.PRNGKey(42)

        self.n_species = 5
        self.X = jax.random.normal(key, (50, self.n_species))
        true_coeff = jnp.linspace(0.1, 2.0, self.n_species)
        noise = jax.random.normal(key, (50,))
        y = jnp.dot(self.X, true_coeff) + noise
        self.Y_single = y
        n_spectra = 3
        self.Y_batch = jnp.broadcast_to(y, (n_spectra, len(y)))
        self.X_batch = jnp.broadcast_to(self.X, (n_spectra, *self.X.shape))

        self.sample = 30
        self.tune = 10
        self.chains = 2
        self.n_compounds = self.X.shape[1] + 1  # add intercept

    def _check_shapes(
        self, summary: MCMCResults, samples: MCMCSample, n_spectra: int
    ) -> None:
        """Helper method to check shapes of outputs.

        Args:
            summary: MCMCResults object to check
            samples: MCMCSample object to check
            n_spectra: Number of spectra in the input
        """
        # Check instance types
        self.assertIsInstance(summary, MCMCResults)
        self.assertIsInstance(samples, MCMCSample)

        # Check SAMPLES shapes
        pip = np.array(samples.pip)
        beta = np.array(samples.beta)
        sigma = np.array(samples.sigma)

        expected_pip_shape = (n_spectra, self.chains, self.sample, self.n_compounds)
        self.assertEqual(pip.shape, expected_pip_shape)
        self.assertEqual(sigma.shape, (n_spectra, self.chains, self.sample))
        self.assertEqual(
            beta.shape, (n_spectra, self.chains, self.sample, self.n_compounds)
        )

        # Check SUMMARY shapes
        pip = np.array(summary.pip)
        beta = np.array(summary.beta)
        beta_std = np.array(summary.beta_std)
        conditional_beta = np.array(summary.conditional_beta)
        conditional_beta_std = np.array(summary.conditional_beta_std)
        sigma = np.array(summary.sigma)
        sigma_std = np.array(summary.sigma_std)

        expected_pip_shape = (n_spectra, self.n_compounds)
        self.assertEqual(pip.shape, expected_pip_shape)
        self.assertEqual(beta_std.shape, beta.shape)
        self.assertEqual(conditional_beta_std.shape, conditional_beta.shape)
        self.assertEqual(sigma.shape, (n_spectra,))
        self.assertEqual(sigma_std.shape, (n_spectra,))

    def _check_diagnostics(self, diagnostics: MCMCDiagnostics, n_spectra: int) -> None:
        """Helper method to check shapes of diagnostics.

        Args:
            diagnostics: MCMCDiagnostics object to check
            n_spectra: Number of spectra in the input
        """
        rhat = np.array(diagnostics.rhat)
        ess = np.array(diagnostics.ess)
        within_active_limit = np.array(diagnostics.within_active_limit)
        self.assertEqual(rhat.shape, (n_spectra, self.n_compounds))
        self.assertEqual(ess.shape, (n_spectra, self.n_compounds))
        self.assertEqual(within_active_limit.shape, (n_spectra,))
        assert within_active_limit.dtype == bool

    def test_single_spectrum(self) -> None:
        """Test isotropic_millipede with a single spectrum."""
        summary, diagnostics, samples = isotropic_millipede(
            self.X,
            self.Y_single,
            sample=self.sample,
            tune=self.tune,
            chains=self.chains,
            max_active=self.n_species,
            return_samples=True,
            return_diagnostics=True,
        )
        self._check_shapes(summary, samples, n_spectra=1)
        self._check_diagnostics(diagnostics, n_spectra=1)

    def test_batch_spectra(self) -> None:
        """Test isotropic_millipede with multiple spectra."""
        n_spectra = self.Y_batch.shape[0]
        summary, diagnostics, samples = isotropic_millipede(
            self.X,
            self.Y_batch,
            sample=self.sample,
            tune=self.tune,
            chains=self.chains,
            max_active=self.n_species,
            return_samples=True,
            return_diagnostics=True,
        )
        self._check_shapes(summary, samples, n_spectra=n_spectra)
        self._check_diagnostics(diagnostics, n_spectra=n_spectra)

    def test_batch_spectra_and_design(self) -> None:
        """Test isotropic_millipede with multiple spectra and design matrices."""
        n_spectra = self.Y_batch.shape[0]
        summary, diagnostics, samples = isotropic_millipede(
            self.X_batch,
            self.Y_batch,
            sample=self.sample,
            tune=self.tune,
            chains=self.chains,
            max_active=self.n_species,
            return_samples=True,
            return_diagnostics=True,
        )
        self._check_shapes(summary, samples, n_spectra=n_spectra)
        self._check_diagnostics(diagnostics, n_spectra=n_spectra)

    def test_wrong_batch_spectra_and_design(self) -> None:
        """Test isotropic_millipede with multiple spectra and design matrices."""
        with self.assertRaises(ValueError):
            isotropic_millipede(
                self.X_batch[slice(0, 2), ...],
                self.Y_batch,
                sample=self.sample,
                tune=self.tune,
                chains=self.chains,
                max_active=self.n_species,
                return_samples=True,
            )

    def test_max_active_variations(self) -> None:
        """Test different max_active parameter values."""
        # Test with max_active=None
        summary1, diagnostics1, samples1 = isotropic_millipede(
            self.X,
            self.Y_single,
            sample=self.sample,
            tune=self.tune,
            chains=self.chains,
            max_active=None,
            return_samples=True,
            return_diagnostics=True,
        )

        # Test with max_active > n_compounds
        summary2, diagnostics2, samples2 = isotropic_millipede(
            self.X,
            self.Y_single,
            sample=self.sample,
            tune=self.tune,
            chains=self.chains,
            max_active=50,
            return_samples=True,
            return_diagnostics=True,
        )

        # Verify shapes are consistent
        self.assertEqual(summary1.pip.shape, summary2.pip.shape)
        self.assertEqual(samples1.pip.shape, samples2.pip.shape)
        self.assertEqual(diagnostics1.rhat.shape, diagnostics2.rhat.shape)

    def test_no_samples_return(self) -> None:
        """Test when return_samples is False."""
        summary, diagnostics, samples = isotropic_millipede(
            self.X,
            self.Y_single,
            sample=self.sample,
            tune=self.tune,
            chains=self.chains,
            max_active=self.n_species,
            return_samples=False,
            return_diagnostics=True,
        )

        self.assertIsInstance(summary, MCMCResults)
        self.assertIsInstance(diagnostics, MCMCDiagnostics)
        self.assertIsNone(samples)

    def test_no_diagnostics_return(self) -> None:
        """Test when return_diagnostics is False."""
        summary, diagnostics, samples = isotropic_millipede(
            self.X,
            self.Y_single,
            sample=self.sample,
            tune=self.tune,
            chains=self.chains,
            max_active=self.n_species,
            return_samples=True,
            return_diagnostics=False,
        )

        self.assertIsInstance(summary, MCMCResults)
        self.assertIsNone(diagnostics)
        self.assertIsInstance(samples, MCMCSample)

    def test_y_batch_first(self) -> None:
        """Test when Y is (mode, batch) should fail"""
        with self.assertRaises(ValueError):
            isotropic_millipede(
                self.X,
                self.Y_batch.T,
                sample=self.sample,
                tune=self.tune,
                chains=self.chains,
                max_active=self.n_species,
                return_samples=False,
            )

    def test_scaling_factors_wrong_shapes(self) -> None:
        """Test isotropic_millipede with incorrect scaling factor shapes."""
        n_spectra = self.Y_batch.shape[0]
        P = self.X.shape[1]

        # Test wrong shape for scale_X (should be P+1)
        with self.assertRaises(ValueError):
            isotropic_millipede(
                self.X,
                self.Y_single,
                sample=10,
                tune=5,
                scale_X=jnp.ones(P),  # Wrong shape
                scale_Y=jnp.ones(1),
            )

        # Test wrong shape for scale_Y with batch Y (should be n_spectra)
        with self.assertRaises(ValueError):
            isotropic_millipede(
                self.X,
                self.Y_batch,
                sample=10,
                tune=5,
                scale_X=jnp.ones(P + 1),
                scale_Y=jnp.ones(n_spectra - 1),  # Wrong shape
            )

        # Test wrong shape for scale_X with batch X and Y (should be P+1)
        with self.assertRaises(ValueError):
            isotropic_millipede(
                self.X_batch,
                self.Y_batch,
                sample=10,
                tune=5,
                scale_X=jnp.ones(P),  # Wrong shape
                scale_Y=jnp.ones(n_spectra),
            )

    def test_default_scaling_factors(self) -> None:
        """Test isotropic_millipede with default scaling factors (None)."""
        # Test with single spectrum, both scale_X and scale_Y are None
        summary1, diagnostics1, samples1 = isotropic_millipede(
            self.X,
            self.Y_single,
            sample=self.sample,
            tune=self.tune,
            chains=self.chains,
            max_active=self.n_species,
            return_samples=True,
            return_diagnostics=True,
            scale_X=None,  # Default: ones array
            scale_Y=None,  # Default: ones array
        )
        self._check_shapes(summary1, samples1, n_spectra=1)
        self._check_diagnostics(diagnostics1, n_spectra=1)

        # Test with multiple spectra, both scale_X and scale_Y are None
        n_spectra = self.Y_batch.shape[0]
        summary2, diagnostics2, samples2 = isotropic_millipede(
            self.X,
            self.Y_batch,
            sample=self.sample,
            tune=self.tune,
            chains=self.chains,
            max_active=self.n_species,
            return_samples=True,
            return_diagnostics=True,
            scale_X=None,  # Default: ones array
            scale_Y=None,  # Default: ones array
        )
        self._check_shapes(summary2, samples2, n_spectra=n_spectra)
        self._check_diagnostics(diagnostics2, n_spectra=n_spectra)
