"""Tests for xarray MCMC statistics processing functions."""

import numpy as np
import pandas as pd
import pytest
import xarray as xr

from compound_hunting.millipede.xarray_mcmc_statistics import (
    _explode_chains,
    _get_conditional_beta,
    _get_conditional_beta_std,
    _get_pip,
    _get_sigma,
    _get_sigma_std,
    _get_weights,
    resample_beta_posteriors,
    summarize_inference_data,
)


@pytest.fixture
def mcmc_dataset():
    """Test dataset with structure of MCMC samples."""
    n_chains = 2
    n_draws = 10
    n_compounds = 4
    n_datasets = 3

    np.random.seed(42)

    chains = np.arange(n_chains)
    draws = np.arange(n_draws)
    compounds = [100, 200, 300, 400]
    datasets = pd.date_range("2025-01-01", periods=n_datasets, freq="D")

    # Beta: regression coefficients
    beta = np.random.normal(0, 1, (n_chains, n_draws, n_compounds, n_datasets))

    # Gamma: feature inclusion indicators
    gamma = np.random.binomial(
        1, 0.6, (n_chains, n_draws, n_compounds, n_datasets)
    ).astype(bool)

    # PIP: posterior inclusion probabilities
    pip = gamma.astype(float)  # just for simplicity

    # Sigma: noise standard deviation
    sigma = np.random.gamma(2, 0.5, (n_chains, n_draws, n_datasets))

    # Weight: sample weights
    weight = np.random.gamma(2, 1, (n_chains, n_draws, n_datasets))

    ds = xr.Dataset(
        data_vars={
            "beta": (["chain", "draw", "compound", "dataset"], beta),
            "gamma": (["chain", "draw", "compound", "dataset"], gamma),
            "pip": (["chain", "draw", "compound", "dataset"], pip),
            "sigma": (["chain", "draw", "dataset"], sigma),
            "weight": (["chain", "draw", "dataset"], weight),
        },
        coords={
            "chain": chains,
            "draw": draws,
            "compound": compounds,
            "dataset": datasets,
        },
    )

    return ds


class TestExplodeChains:
    """Test the _explode_chains function."""

    def test_explode_chains_shape(self, mcmc_dataset):
        """Test that explode_chains produces correct output shape."""
        result = _explode_chains(mcmc_dataset)

        # Should combine chains and draws into single draw dimension
        expected_draws = mcmc_dataset.sizes["chain"] * mcmc_dataset.sizes["draw"]

        assert "chain" not in result.dims
        assert result.sizes["draw"] == expected_draws
        assert result.sizes["compound"] == mcmc_dataset.sizes["compound"]
        assert result.sizes["dataset"] == mcmc_dataset.sizes["dataset"]


class TestGetWeights:
    """Test the _get_weights function."""

    def test_get_weights_normalization(self, mcmc_dataset):
        """Test that weights are properly normalized."""
        exploded = _explode_chains(mcmc_dataset)
        weights = _get_weights(exploded.weight)

        # Weights should sum to 1 along draw dimension for each dataset
        weight_sums = weights.sum(dim="draw")
        np.testing.assert_allclose(weight_sums, 1.0, rtol=1e-6)

    def test_get_weights_shape(self, mcmc_dataset):
        """Test that weights maintain correct shape."""
        exploded = _explode_chains(mcmc_dataset)
        weights = _get_weights(exploded.weight)

        assert weights.shape == exploded.weight.shape
        assert weights.dims == exploded.weight.dims

    def test_get_weights_positive(self, mcmc_dataset):
        """Test that all weights are positive."""
        exploded = _explode_chains(mcmc_dataset)
        weights = _get_weights(exploded.weight)

        assert (weights >= 0).all()


class TestGetPip:
    """Test the _get_pip function."""

    def test_get_pip_shape(self, mcmc_dataset):
        """Test that PIP output has correct shape."""
        exploded = _explode_chains(mcmc_dataset)
        weights = _get_weights(exploded.weight)
        pip = _get_pip(exploded.pip, weights)

        expected_shape = (exploded.sizes["compound"], exploded.sizes["dataset"])
        assert pip.shape == expected_shape
        assert pip.dims == ("compound", "dataset")

    def test_get_pip_range(self, mcmc_dataset):
        """Test that PIP values are in [0, 1] range."""
        exploded = _explode_chains(mcmc_dataset)
        weights = _get_weights(exploded.weight)
        pip = _get_pip(exploded.pip, weights)

        assert (pip >= 0).all()
        assert (pip <= 1).all()


class TestGetConditionalBeta:
    """Test the _get_conditional_beta function."""

    def test_get_conditional_beta_shape(self, mcmc_dataset):
        """Test that conditional beta output has correct shape."""
        exploded = _explode_chains(mcmc_dataset)
        weights = _get_weights(exploded.weight)
        conditional_beta = _get_conditional_beta(exploded.beta, exploded.gamma, weights)

        expected_shape = (exploded.sizes["compound"], exploded.sizes["dataset"])
        assert conditional_beta.shape == expected_shape
        assert conditional_beta.dims == ("compound", "dataset")

    def test_get_conditional_beta_finite(self, mcmc_dataset):
        """Test that conditional beta values are finite where gamma > 0."""
        exploded = _explode_chains(mcmc_dataset)
        weights = _get_weights(exploded.weight)
        conditional_beta = _get_conditional_beta(exploded.beta, exploded.gamma, weights)

        # Where there are any gamma=1 samples, result should be finite
        gamma_any = exploded.gamma.any(dim="draw")
        finite_where_gamma = conditional_beta.where(gamma_any).notnull()

        assert finite_where_gamma.sum() > 0


class TestGetConditionalBetaStd:
    """Test the _get_conditional_beta_std function."""

    def test_get_conditional_beta_std_shape(self, mcmc_dataset):
        """Test that conditional beta std output has correct shape."""
        exploded = _explode_chains(mcmc_dataset)
        weights = _get_weights(exploded.weight)
        conditional_beta = _get_conditional_beta(exploded.beta, exploded.gamma, weights)
        conditional_beta_std = _get_conditional_beta_std(
            exploded.beta, exploded.gamma, weights, conditional_beta
        )

        # Should have same shape as conditional_beta
        assert conditional_beta_std.shape == conditional_beta.shape
        assert conditional_beta_std.dims == conditional_beta.dims

    def test_get_conditional_beta_std_positive(self, mcmc_dataset):
        """Test that conditional beta std values are non-negative."""
        exploded = _explode_chains(mcmc_dataset)
        weights = _get_weights(exploded.weight)
        conditional_beta = _get_conditional_beta(exploded.beta, exploded.gamma, weights)
        conditional_beta_std = _get_conditional_beta_std(
            exploded.beta, exploded.gamma, weights, conditional_beta
        )

        # Standard deviations should be non-negative where defined
        finite_mask = conditional_beta_std.notnull()
        finite_values = conditional_beta_std.where(finite_mask)
        assert (finite_values >= 0).all()


class TestGetSigma:
    """Test the _get_sigma function."""

    def test_get_sigma_shape(self, mcmc_dataset):
        """Test that sigma output has correct shape."""
        exploded = _explode_chains(mcmc_dataset)
        weights = _get_weights(exploded.weight)
        sigma = _get_sigma(exploded.sigma, weights)

        # Should remove draw dimension
        expected_shape = (exploded.sizes["dataset"],)
        assert sigma.shape == expected_shape
        assert sigma.dims == ("dataset",)

    def test_get_sigma_positive(self, mcmc_dataset):
        """Test that sigma values are positive."""
        exploded = _explode_chains(mcmc_dataset)
        weights = _get_weights(exploded.weight)
        sigma = _get_sigma(exploded.sigma, weights)

        assert (sigma > 0).all()


class TestGetSigmaStd:
    """Test the _get_sigma_std function."""

    def test_get_sigma_std_shape(self, mcmc_dataset):
        """Test that sigma std output has correct shape."""
        exploded = _explode_chains(mcmc_dataset)
        weights = _get_weights(exploded.weight)
        sigma = _get_sigma(exploded.sigma, weights)
        sigma_std = _get_sigma_std(exploded.sigma, weights, sigma)

        # Should have same shape as sigma
        assert sigma_std.shape == sigma.shape
        assert sigma_std.dims == sigma.dims

    def test_get_sigma_std_positive(self, mcmc_dataset):
        """Test that sigma std values are non-negative."""
        exploded = _explode_chains(mcmc_dataset)
        weights = _get_weights(exploded.weight)
        sigma = _get_sigma(exploded.sigma, weights)
        sigma_std = _get_sigma_std(exploded.sigma, weights, sigma)

        assert (sigma_std >= 0).all()


class TestSummarizeInferenceData:
    """Test the main summarize_inference_data function."""

    def test_summarize_inference_data_output_variables(self, mcmc_dataset):
        """Test that all expected output variables are present."""
        result = summarize_inference_data(mcmc_dataset)

        expected_vars = {
            "pip",
            "beta_mean",
            "beta_std",
            "sigma",
            "sigma_std",
            "beta_marginal",
        }
        assert set(result.data_vars) == expected_vars

    def test_summarize_inference_data_shapes(self, mcmc_dataset):
        """Test that output shapes are correct."""
        result = summarize_inference_data(mcmc_dataset)

        n_compounds = mcmc_dataset.sizes["compound"]
        n_datasets = mcmc_dataset.sizes["dataset"]

        # Variables with compound dimension
        compound_vars = ["pip", "beta_mean", "beta_std", "beta_marginal"]
        for var in compound_vars:
            assert result[var].shape == (n_compounds, n_datasets)
            assert result[var].dims == ("compound", "dataset")

        # Variables with only dataset dimension
        dataset_vars = ["sigma", "sigma_std"]
        for var in dataset_vars:
            assert result[var].shape == (n_datasets,)
            assert result[var].dims == ("dataset",)

    def test_summarize_inference_data_coordinates(self, mcmc_dataset):
        """Test that coordinates are preserved correctly."""
        result = summarize_inference_data(mcmc_dataset)

        # Should preserve compound and dataset coordinates
        np.testing.assert_array_equal(result.compound, mcmc_dataset.compound)
        np.testing.assert_array_equal(result.dataset, mcmc_dataset.dataset)

        # Should not have chain or draw coordinates
        assert "chain" not in result.coords
        assert "draw" not in result.coords

    def test_summarize_inference_data_beta_marginal(self, mcmc_dataset):
        """Test that beta_marginal is correctly computed as pip * beta_mean."""
        result = summarize_inference_data(mcmc_dataset)

        expected_marginal = result.pip * result.beta_mean
        np.testing.assert_allclose(result.beta_marginal, expected_marginal, rtol=1e-6)


class TestEdgeCases:
    """Test edge cases and error conditions."""

    def test_empty_dataset_dimensions(self):
        """Test behavior with minimal dimensions."""
        ds = xr.Dataset(
            data_vars={
                "beta": (
                    ["chain", "draw", "compound", "dataset"],
                    np.random.randn(1, 1, 1, 1).astype(np.float32),
                ),
                "gamma": (
                    ["chain", "draw", "compound", "dataset"],
                    np.ones((1, 1, 1, 1), dtype=bool),
                ),
                "pip": (
                    ["chain", "draw", "compound", "dataset"],
                    np.ones((1, 1, 1, 1), dtype=np.float32),
                ),
                "sigma": (
                    ["chain", "draw", "dataset"],
                    np.ones((1, 1, 1), dtype=np.float32),
                ),
                "weight": (
                    ["chain", "draw", "dataset"],
                    np.ones((1, 1, 1), dtype=np.float32),
                ),
            },
            coords={
                "chain": [0],
                "draw": [0],
                "compound": [1],
                "dataset": [pd.Timestamp("2025-01-01")],
            },
        )

        # Should not raise an error
        result = summarize_inference_data(ds)
        assert result is not None
        assert len(result.data_vars) == 6

    def test_all_gamma_zero(self, mcmc_dataset):
        """Test behavior when gamma is all zeros for some features."""
        # Set first compound to never be included
        mcmc_dataset_modified = mcmc_dataset.copy()
        mcmc_dataset_modified["gamma"][:, :, 0, :] = False
        mcmc_dataset_modified["pip"][:, :, 0, :] = 0.0

        result = summarize_inference_data(mcmc_dataset_modified)

        # Should handle gracefully - pip should be 0, beta_mean might be nan/0
        assert (result.pip[0, :] == 0).all()
        # beta_mean for never-included feature should be 0 or nan
        assert (
            np.isnan(result.beta_mean[0, :]).all()
            or (result.beta_mean[0, :] == 0).all()
        )


class TestResampleBetaPosteriors:
    """Tests for the resample_beta_posteriors function."""

    def test_output_shape_and_dims(self, mcmc_dataset):
        """Test the output shape and dimension names."""
        num_samples = 500
        result = resample_beta_posteriors(mcmc_dataset, num_samples=num_samples)

        n_datasets = mcmc_dataset.sizes["dataset"]
        n_compounds = mcmc_dataset.sizes["compound"]

        assert isinstance(result, xr.DataArray)
        assert result.shape == (n_datasets, num_samples, n_compounds)
        assert result.dims == ("dataset", "sample", "compound")

    def test_different_variable(self, mcmc_dataset):
        """Test that the function works with a different variable."""
        num_samples = 500
        result = resample_beta_posteriors(
            mcmc_dataset, num_samples=num_samples, posterior_variable="pip"
        )
        assert result.shape == (
            mcmc_dataset.sizes["dataset"],
            num_samples,
            mcmc_dataset.sizes["compound"],
        )
        assert result.dims == ("dataset", "sample", "compound")

    def test_output_coordinates(self, mcmc_dataset):
        """Test that coordinates are correctly set in the output."""
        num_samples = 500
        result = resample_beta_posteriors(mcmc_dataset, num_samples=num_samples)

        np.testing.assert_array_equal(
            result.coords["dataset"], mcmc_dataset.coords["dataset"]
        )
        np.testing.assert_array_equal(
            result.coords["compound"], mcmc_dataset.coords["compound"]
        )
        np.testing.assert_array_equal(result.coords["sample"], np.arange(num_samples))

    def test_custom_output_dim(self, mcmc_dataset):
        """Test using a custom name for the output sample dimension."""
        num_samples = 100
        custom_dim = "resampled_draw"
        result = resample_beta_posteriors(
            mcmc_dataset, num_samples=num_samples, output_dim=custom_dim
        )

        assert custom_dim in result.dims
        assert result.dims == ("dataset", custom_dim, "compound")

    def test_raises_error_if_variables_missing(self, mcmc_dataset):
        """Test that a ValueError is raised if 'beta' or 'weight' is missing."""
        ds_missing_beta = mcmc_dataset.drop_vars("beta")
        with pytest.raises(
            ValueError, match="must contain 'beta' and 'weight' variables"
        ):
            resample_beta_posteriors(ds_missing_beta)

        ds_missing_weight = mcmc_dataset.drop_vars("weight")
        with pytest.raises(
            ValueError, match="must contain 'beta' and 'weight' variables"
        ):
            resample_beta_posteriors(ds_missing_weight)
