import jax.numpy as jnp
import pytest
from sklearn.datasets import make_regression

from compound_hunting.compute.solver import solve_lsq
from compound_hunting.compute.solver_nonnegative import nnlsq_active_set


@pytest.fixture
def regression_data():
    X, y = make_regression(n_samples=100, n_features=20, noise=0.1, random_state=42)
    return jnp.array(X), jnp.array(y)


def mock_scorer(X_test, y_test, y_pred):
    return jnp.mean((y_test - y_pred) ** 2)


def test_solve_single(regression_data):
    X, y = regression_data
    X, y = X[:50, :5], y[:50]  # Use a subset of data

    coeffs = solve_lsq(X, y)

    assert coeffs.shape == (5,)
    assert isinstance(coeffs, jnp.ndarray)
    assert not (coeffs >= 0).all()

    coeffs = nnlsq_active_set(X, y)

    assert coeffs.shape == (5,)
    assert isinstance(coeffs, jnp.ndarray)
    assert (coeffs >= 0).all()
