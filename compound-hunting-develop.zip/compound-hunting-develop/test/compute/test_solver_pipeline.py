import unittest

import jax.numpy as jnp
import numpy as np
import pytest
from jax import Array
from jax.typing import ArrayLike

from compound_hunting.compute.solver_pipeline import (
    _generate_incremental_solutions,
    create_feature_evaluator_fn,
    create_feature_searcher_fn,
)


class TestGenerateIncrementalSolutions(unittest.TestCase):
    def test_basic_functionality(self):
        solution = jnp.array([1, 2, 3, 4])
        available_features = jnp.array([5, 6])
        result = _generate_incremental_solutions(solution, available_features)
        assert result.shape[0] == available_features.shape[0]
        assert result.shape[1] == solution.shape[0] + 1
        expected_1 = np.array([1, 2, 3, 4, 5])
        expected_2 = np.array([1, 2, 3, 4, 6])
        assert np.allclose(result[0], expected_1)
        assert np.allclose(result[1], expected_2)


class TestFeatureEvaluator:
    @pytest.fixture
    def mock_solve_fn(self):
        def solve(X_train: ArrayLike, y_train: ArrayLike) -> Array:
            return jnp.ones(X_train.shape[1])

        return solve

    def test_evaluator_basic_functionality(
        self, sample_data, mock_solve_fn, mock_scorer_fn
    ):
        X, y, train_indices, test_indices = sample_data
        evaluator = create_feature_evaluator_fn(
            X, y, train_indices, test_indices, mock_solve_fn, mock_scorer_fn
        )

        # Test with valid feature combination
        score = evaluator(jnp.array([0, 1, 2]))
        assert not jnp.isinf(score)
        assert score == 1.0  # mocked

    def test_duplicates(self, sample_data, mock_solve_fn, mock_scorer_fn):
        X, y, train_indices, test_indices = sample_data
        evaluator = create_feature_evaluator_fn(
            X, y, train_indices, test_indices, mock_solve_fn, mock_scorer_fn
        )

        score = evaluator(jnp.array([0, 1, 1]))
        assert jnp.isinf(score)
        assert score < 0  # Should return -inf for duplicates

    def test_different_feature_sizes(self, sample_data, mock_solve_fn, mock_scorer_fn):
        X, y, train_indices, test_indices = sample_data
        evaluator = create_feature_evaluator_fn(
            X, y, train_indices, test_indices, mock_solve_fn, mock_scorer_fn
        )

        score1 = evaluator(jnp.array([0]))
        score2 = evaluator(jnp.array([0, 1]))
        score3 = evaluator(jnp.array([0, 1, 2]))

        assert not jnp.isinf(score1)
        assert not jnp.isinf(score2)
        assert not jnp.isinf(score3)

    def test_boundaries(self, sample_data, mock_solve_fn, mock_scorer_fn):
        X, y, train_indices, test_indices = sample_data
        evaluator = create_feature_evaluator_fn(
            X, y, train_indices, test_indices, mock_solve_fn, mock_scorer_fn
        )

        n_features = X.shape[1]
        score = evaluator(jnp.array([0, n_features - 1]))
        assert not jnp.isinf(score)
        assert score == 1.0

    def test_evaluator_cross_validation(self, sample_data, mock_solve_fn):
        X, y, train_indices, test_indices = sample_data

        # eturns different values for different splits
        def cv_scorer_fn(X_test, y_test, y_pred):
            return jnp.array(len(y_test))

        evaluator = create_feature_evaluator_fn(
            X, y, train_indices, test_indices, mock_solve_fn, cv_scorer_fn
        )

        score = evaluator(jnp.array([0, 1]))

        # Expected score should be mean of test set sizes
        expected_score = jnp.mean(
            jnp.array([len(test_idx) for test_idx in test_indices])
        )
        assert jnp.allclose(score, expected_score)


class TestFeatureSearcher:
    @pytest.fixture
    def mock_evaluate_single_fn(self):
        def evaluate(feature_indices):
            return jnp.sum(feature_indices)

        return evaluate

    def test_basic_functionality(self, sample_data, mock_evaluate_single_fn):
        X, _, _, _ = sample_data
        batch_size = 4
        top_n = 3
        searcher = create_feature_searcher_fn(X, batch_size, mock_evaluate_single_fn)

        # Test with initial solution
        initial_solution = jnp.array([[0, 1], [2, 3]])
        new_features, scores = searcher(initial_solution, top_n=top_n)

        # new solution has one more feature
        assert new_features.shape[1] == initial_solution.shape[1] + 1
        # number of scores is the same as the number of solutions
        assert len(scores) == new_features.shape[0]
        # number of solutions is the number of initial solutions times the top_n
        assert new_features.shape[0] == top_n * initial_solution.shape[0]

    def test_batch_processing(self, sample_data, mock_evaluate_single_fn):
        X, _, _, _ = sample_data
        top_n = 2

        for batch_size in [1, 2, 4]:
            searcher = create_feature_searcher_fn(
                X, batch_size, mock_evaluate_single_fn
            )
            initial_solution = jnp.array([[0, 1]])
            new_features, scores = searcher(initial_solution, top_n=top_n)

            assert new_features.shape[0] == top_n * initial_solution.shape[0]
            assert new_features.shape[1] == initial_solution.shape[1] + 1

    def test_feature_bounds(self, sample_data, mock_evaluate_single_fn):
        X, _, _, _ = sample_data
        batch_size = 4
        searcher = create_feature_searcher_fn(X, batch_size, mock_evaluate_single_fn)

        n_features = X.shape[1]
        initial_solution = jnp.array([[0, n_features - 1]])
        new_features, scores = searcher(initial_solution, top_n=2)

        # Check that all feature indices are within bounds
        assert jnp.all(new_features >= 0)
        assert jnp.all(new_features < n_features)

    def test_score_ordering(self, sample_data, mock_evaluate_single_fn):
        X, _, _, _ = sample_data
        batch_size = 4
        searcher = create_feature_searcher_fn(X, batch_size, mock_evaluate_single_fn)

        initial_solution = jnp.array([[0, 1]])
        new_features, scores = searcher(initial_solution, top_n=3)

        # Verify scores are in descending order
        assert jnp.all(scores[:-1] >= scores[1:])
