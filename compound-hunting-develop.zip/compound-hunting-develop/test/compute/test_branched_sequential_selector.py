from compound_hunting.compute.branched_sequential_selector import (
    branched_sequential_selector,
)


def test_branched_sequential_selector(sample_data, mock_scorer_fn, mock_decay_fn):
    X, y, train_indices, test_indices = sample_data
    depth = 3
    batch_size = 10

    results = branched_sequential_selector(
        X=X,
        y=y,
        train_indices=train_indices,
        test_indices=test_indices,
        decay_fn=mock_decay_fn,
        scorer_fn=mock_scorer_fn,
        depth=depth,
        batch_size=batch_size,
        show_progress=False,
    )

    results_pos = branched_sequential_selector(
        X=X,
        y=y,
        train_indices=train_indices,
        test_indices=test_indices,
        decay_fn=mock_decay_fn,
        scorer_fn=mock_scorer_fn,
        depth=depth,
        batch_size=batch_size,
        show_progress=False,
        positive=True,
    )

    # Check that the results dictionary has the correct number of entries
    assert len(results) == depth + 1  # include naive solution with no compounds
    assert len(results_pos) == depth + 1

    # naive solution is one solution with no compounds
    assert results[0].features.shape == (1, 0)
    assert results_pos[0].features.shape == (1, 0)

    # Check shapes for each depth
    n_solutions = 1

    for i in range(1, depth + 1):
        result = results[i]
        result_pos = results_pos[i]

        # check ols and nnls have results with the same shapes
        assert result.features.shape == result_pos.features.shape
        assert result.scores.shape == result_pos.scores.shape

        sol, score = result.features, result.scores
        expected_sol_length = n_solutions * mock_decay_fn(i - 1)
        expected_sol_shape = (expected_sol_length, i)
        expected_score_shape = (expected_sol_length,)

        assert sol.shape == expected_sol_shape
        assert score.shape == expected_score_shape
        n_solutions = expected_sol_length
