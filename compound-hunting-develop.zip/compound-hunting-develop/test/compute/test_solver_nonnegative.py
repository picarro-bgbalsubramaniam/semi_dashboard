import unittest

import jax
import jax.numpy as jnp
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.datasets import make_regression

from compound_hunting.compute.solver_nonnegative import nnlsq_active_set


class TestNNLSQActiveSet(unittest.TestCase):
    def test_simple_problem(self):
        """Test a simple problem with known solution"""
        X = jnp.array([[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]])
        y = jnp.array([1.0, 2.0, 3.0])

        expected_sol = jnp.array([1.0, 2.0])
        solution = nnlsq_active_set(X, y)
        np.testing.assert_array_almost_equal(solution, expected_sol)

    def test_sklearn(self):
        """Compare results with sklearn's LinearRegression with positive=True"""
        X, y = make_regression(n_samples=100, n_features=10, random_state=42, noise=0.1)

        with jax.experimental.enable_x64():
            solution = nnlsq_active_set(jnp.array(X), jnp.array(y))

        # Solve with sklearn
        sk_solution = (
            LinearRegression(positive=True, fit_intercept=False).fit(X, y).coef_
        )

        # Compare solutions
        np.testing.assert_array_almost_equal(solution, sk_solution)

    def test_sklearn_large(self):
        """Compare results with sklearn's LinearRegression with positive=True"""
        X, y = make_regression(n_samples=300, n_features=50, random_state=42, noise=0.1)

        with jax.experimental.enable_x64():
            solution = nnlsq_active_set(jnp.array(X), jnp.array(y))

        # Solve with sklearn
        sk_solution = (
            LinearRegression(positive=True, fit_intercept=False).fit(X, y).coef_
        )

        # Compare solutions
        np.testing.assert_array_almost_equal(solution, sk_solution)

    def test_zero_coefficients(self):
        X = np.array(
            [[1.0, 1.0, 0.0], [1.0, 0.0, 1.0], [1.0, 1.0, 1.0], [1.0, 0.0, 0.0]]
        )
        y = np.array([1.0, 1.0, 1.0, 1.0])  # Solution should be [1, 0, 0]

        with jax.experimental.enable_x64():
            solution = nnlsq_active_set(jnp.array(X), jnp.array(y))

        expected = np.array([1.0, 0.0, 0.0])

        np.testing.assert_array_almost_equal(solution, expected)

    def test_ill_conditioned(self):
        """Test with an ill-conditioned matrix"""
        X = jnp.array([[1.0, 1.0], [1.0, 1.000001], [1.0, 1.0], [1.0, 0.999999]])
        y = jnp.array([1.0, 1.0, 1.0, 1.0])

        solution = nnlsq_active_set(X, y)
        # Should still produce a valid solution
        self.assertTrue(jnp.all(solution >= 0))
        self.assertTrue(jnp.all(jnp.isfinite(solution)))

    def test_non_convergent_case(self):
        """Test behavior with a problem that cannot converge to exact solution"""
        X = jnp.array([[1.0, 0.0], [0.0, 1.0]])
        y = jnp.array([-1.0, -1.0])  # Impossible to solve with non-negative constraints

        solution = nnlsq_active_set(X, y)
        # Should return all zeros as the best possible solution
        np.testing.assert_array_almost_equal(solution, jnp.zeros_like(solution))
