import jax.numpy as jnp
import pytest
from jax import Array
from sklearn.datasets import make_regression
from sklearn.model_selection import ShuffleSplit


@pytest.fixture
def sample_data():
    # Generate sample data
    X, y = make_regression(n_samples=100, n_features=20, noise=0.1, random_state=42)
    X = jnp.array(X)
    y = jnp.array(y)

    # Create train/test splits
    ss = ShuffleSplit(n_splits=2, test_size=0.2, random_state=42)
    split_indices = list(ss.split(X))
    train_indices = jnp.array([tr for tr, ts in split_indices])
    test_indices = jnp.array([ts for tr, ts in split_indices])

    return X, y, train_indices, test_indices


@pytest.fixture
def mock_scorer_fn():
    def scorer(X_test: Array, y_test: Array, y_pred: Array) -> Array:
        return jnp.array(1.0)

    return scorer


@pytest.fixture
def mock_decay_fn():
    def decay(depth: int) -> int:
        return max(1, 3 - depth)

    return decay
