import unittest
from unittest.mock import patch

import numpy as np
import pandas as pd
from sklearn.datasets import make_regression

from compound_hunting.transformers.branched_transformer import BranchedTransformer
from compound_hunting.transformers.lasso_transformer import LassoTransformer
from compound_hunting.transformers.millipede_transformer import MillipedeTransformer
from compound_hunting.transformers.pls_transformer import PLSRegressionTransformer
from compound_hunting.transformers.r3_transformer import R3Transformer
from compound_hunting.transformers.sfs_transformer import SequentialTransformer


class FeatureSelectorTestSuite(unittest.TestCase):
    """
    A generic test suite for feature selector classes,
    to be subclassed for specific implementations.

    For a detailed guide on how to use this test suite, refer to the documentation:
    [Documentation Link](../docs/source/feature_selector.rst)
    """

    def setUp(self):
        if type(self) is FeatureSelectorTestSuite:
            self.skipTest("Skip Base Class tests, it's a base class")
        self.setup_data()
        self.selector = self.create_selector()

    def setup_data(self):
        self.X, self.Y = self.create_regression_data()
        self.Y_empty_mode = self.create_empty_mode_data(self.Y)
        self.Y_sparse = self.create_sparse_data(self.Y)
        self.Y_very_sparse = self.create_very_sparse_data(self.Y)
        self.y = self.Y.mean(axis=1)
        self.y_empty_mode = self.Y_empty_mode.mean(axis=1)
        self.y_sparse = self.Y_sparse.mean(axis=1)
        self.y_very_sparse = self.Y_very_sparse.mean(axis=1)

    @staticmethod
    def create_regression_data():
        X, Y = make_regression(
            n_samples=100, n_features=20, noise=0.1, n_targets=2, random_state=42
        )
        return pd.DataFrame(X), Y

    @staticmethod
    def create_empty_mode_data(Y):
        yc = Y.copy()
        yc[0, :] = np.nan
        return yc

    @staticmethod
    def create_sparse_data(Y):
        yc = Y.copy()
        yc[0, 0] = np.nan
        yc[1, 1] = np.nan
        return yc

    @staticmethod
    def create_very_sparse_data(Y):
        np.random.seed(42)

        yc = Y.copy()
        n_rows = yc.shape[0]
        n_cols = yc.shape[1]

        total_elements = n_rows * n_cols
        num_true = int(total_elements * 0.3)
        mask_flat = np.array([True] * num_true + [False] * (total_elements - num_true))
        np.random.shuffle(mask_flat)
        mask = mask_flat.reshape(n_rows, n_cols)
        yc[mask] = np.nan
        return yc

    def create_selector(self):
        """
        Create and return an instance of the feature selector class.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement this method")

    def test_fit_multitask(self):
        """
        Test fitting the selector to multitask data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit_multitask")

    def test_fit_multitask_empty_mode(self):
        """
        Test fitting the selector to multitask data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit_multitask")

    def test_fit_multitask_sparse(self):
        """
        Test fitting the selector to multitask data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit_multitask")

    def test_fit_multitask_very_sparse(self):
        """
        Test fitting the selector to multitask data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit_multitask")

    def test_fit(self):
        """
        Test fitting the selector to single-task data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit")

    def test_fit_empty_mode(self):
        """
        Test fitting the selector to single-task data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit")

    def test_fit_sparse(self):
        """
        Test fitting the selector to single-task data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit")

    def test_fit_very_sparse(self):
        """
        Test fitting the selector to single-task data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit")

    def test_transform(self):
        """
        Test transforming the data using the selector.
        """
        self.selector.fit(self.X, self.y)
        transformed = self.selector.transform(self.X)
        assert transformed.shape[1] < self.X.shape[1]
        self.assertIsInstance(transformed, pd.DataFrame)


class TestLassoTransformer(FeatureSelectorTestSuite):
    def create_selector(self):
        return LassoTransformer()

    def test_fit_multitask(self):
        self.selector.fit(self.X, self.Y)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_empty_mode(self):
        self.selector.fit(self.X, self.Y_empty_mode)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_sparse(self):
        self.selector.fit(self.X, self.Y_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_very_sparse(self):
        self.selector.fit(self.X, self.Y_very_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit(self):
        self.selector.fit(self.X, self.y)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_empty_mode(self):
        self.selector.fit(self.X, self.y_empty_mode)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_sparse(self):
        self.selector.fit(self.X, self.y_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_very_sparse(self):
        self.selector.fit(self.X, self.y_very_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)


class TestR3Transformer(FeatureSelectorTestSuite):
    def create_selector(self):
        return R3Transformer()

    def test_fit_multitask(self):
        self.selector.fit(self.X, self.Y)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_empty_mode(self):
        self.selector.fit(self.X, self.Y_empty_mode)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_sparse(self):
        self.selector.fit(self.X, self.Y_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_very_sparse(self):
        self.selector.fit(self.X, self.Y_very_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit(self):
        self.selector.fit(self.X, self.y)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_empty_mode(self):
        self.selector.fit(self.X, self.y_empty_mode)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_sparse(self):
        self.selector.fit(self.X, self.y_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_very_sparse(self):
        self.selector.fit(self.X, self.y_very_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)


class TestSequentialTransformer(FeatureSelectorTestSuite):
    def create_selector(self):
        return SequentialTransformer()

    def test_fit_multitask(self):
        self.selector.fit(self.X, self.Y)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_empty_mode(self):
        self.selector.fit(self.X, self.Y_empty_mode)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_sparse(self):
        self.selector.fit(self.X, self.Y_sparse)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_very_sparse(self):
        self.selector.fit(self.X, self.Y_very_sparse)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit(self):
        self.selector.fit(self.X, self.y)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_empty_mode(self):
        self.selector.fit(self.X, self.y_empty_mode)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_sparse(self):
        self.selector.fit(self.X, self.y_sparse)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_very_sparse(self):
        self.selector.fit(self.X, self.y_very_sparse)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)


class TestBranchedTransformer(FeatureSelectorTestSuite):
    def create_selector(self):
        return BranchedTransformer(decay_fn=lambda x: 3, n_features=3)

    def test_fit_multitask(self):
        self.selector.fit(self.X, self.Y)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_empty_mode(self):
        self.selector.fit(self.X, self.Y_empty_mode)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_sparse(self):
        self.selector.fit(self.X, self.Y_sparse)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_very_sparse(self):
        self.selector.fit(self.X, self.Y_very_sparse)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit(self):
        self.selector.fit(self.X, self.y)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_empty_mode(self):
        self.selector.fit(self.X, self.y_empty_mode)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_sparse(self):
        self.selector.fit(self.X, self.y_sparse)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_very_sparse(self):
        self.selector.fit(self.X, self.y_very_sparse)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)


class TestPLSRegressionTransformer(FeatureSelectorTestSuite):
    def create_selector(self):
        return PLSRegressionTransformer()

    def test_fit_multitask(self):
        self.selector.fit(self.X, self.Y)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_empty_mode(self):
        self.selector.fit(self.X, self.Y_empty_mode)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_sparse(self):
        self.selector.fit(self.X, self.Y_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_very_sparse(self):
        self.selector.fit(self.X, self.Y_very_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit(self):
        self.selector.fit(self.X, self.y)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_empty_mode(self):
        self.selector.fit(self.X, self.y_empty_mode)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_sparse(self):
        self.selector.fit(self.X, self.y_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_very_sparse(self):
        self.selector.fit(self.X, self.y_very_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)


class TestMillipedeTransformer(FeatureSelectorTestSuite):
    def get_default_millipede_options(self):
        return {
            "max_active": 20,
            "sample": 10,
            "tune": 10,
            "chains": 4,
            "dtype": np.float32,
            "return_samples": True,
            "return_diagnostics": True,
        }

    def create_selector(self):
        options = self.get_default_millipede_options()
        return MillipedeTransformer(**options)

    def check_multitask_output(self, features):
        assert isinstance(features, list)
        assert len(features) == self.Y.shape[1]
        assert isinstance(features[0], np.ndarray)

    def test_fit_multitask(self):
        self.selector.fit(self.X, self.Y)
        features = self.selector.get_feature_names_out()
        self.check_multitask_output(features)

    def test_fit_multitask_empty_mode(self):
        self.selector.fit(self.X, self.Y_empty_mode)
        features = self.selector.get_feature_names_out()
        self.check_multitask_output(features)

    def test_fit_multitask_sparse(self):
        self.selector.fit(self.X, self.Y_sparse)
        features = self.selector.get_feature_names_out()
        self.check_multitask_output(features)

    def test_fit_multitask_very_sparse(self):
        self.selector.fit(self.X, self.Y_very_sparse)
        features = self.selector.get_feature_names_out()
        self.check_multitask_output(features)

    def test_fit(self):
        self.selector.fit(self.X, self.y)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_empty_mode(self):
        self.selector.fit(self.X, self.y_empty_mode)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_sparse(self):
        self.selector.fit(self.X, self.y_sparse)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_very_sparse(self):
        self.selector.fit(self.X, self.y_very_sparse)
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_float64(self):
        options = self.get_default_millipede_options()
        options["dtype"] = np.float64
        selector = MillipedeTransformer(**options)
        selector.fit(self.X, self.y)
        assert isinstance(selector.get_feature_names_out(), np.ndarray)

    def test_fit_no_samples(self):
        options = self.get_default_millipede_options()
        options["return_samples"] = False
        selector = MillipedeTransformer(**options)
        selector.fit(self.X, self.y)
        assert selector.samples_ is None

        with self.assertRaises(ValueError):
            selector.get_inference_data()

    def test_fit_with_samples(self):
        import arviz as az

        options = self.get_default_millipede_options()
        options["return_samples"] = True
        selector = MillipedeTransformer(**options)
        selector.fit(self.X, self.y)
        assert selector.samples_ is not None

        av = selector.get_inference_data()
        assert isinstance(av, az.InferenceData)

    def test_fit_no_diagnostics(self):
        options = self.get_default_millipede_options()
        options["return_diagnostics"] = False
        selector = MillipedeTransformer(**options)
        selector.fit(self.X, self.y)
        assert selector.diagnostics_ is None

    def test_fit_check_max_active_constraint(self):
        # Test when max_active constraint is hit
        with patch(
            "compound_hunting.transformers.millipede_transformer.LOGGER.error"
        ) as mock_error:
            options = self.get_default_millipede_options()
            options["return_diagnostics"] = True
            options["max_active"] = 3
            selector = MillipedeTransformer(**options)
            selector.fit(self.X, self.y)

            # verify that the constraint was hit
            assert not selector.check_max_active_constraint()

            # Verify the error was logged
            mock_error.assert_called()

        # Test when max_active constraint is not hit
        with patch(
            "compound_hunting.transformers.millipede_transformer.LOGGER.error"
        ) as mock_error:
            options = self.get_default_millipede_options()
            options["return_diagnostics"] = True
            options["max_active"] = 40
            selector = MillipedeTransformer(**options)
            selector.fit(self.X, self.y)

            # verify that the constraint was not hit
            assert selector.check_max_active_constraint()

            # Verify no error was logged
            mock_error.assert_not_called()

    def test_fit_with_weights_none(self):
        """Test that weights=None works (default behavior)."""
        selector = self.create_selector()
        selector.fit(self.X, self.y, weights=None)
        assert isinstance(selector.get_feature_names_out(), np.ndarray)

    def test_fit_with_weights_numpy_array_single_task(self):
        """Test fitting with weights as numpy array for single-task."""
        selector = self.create_selector()
        weights = np.ones(self.X.shape[0]) * 2.0
        selector.fit(self.X, self.y, weights=weights)
        assert isinstance(selector.get_feature_names_out(), np.ndarray)

    def test_fit_with_weights_pandas_series_single_task(self):
        """Test fitting with weights as pandas Series for single-task."""
        selector = self.create_selector()
        weights = pd.Series(np.ones(self.X.shape[0]) * 1.5)
        selector.fit(self.X, self.y, weights=weights)
        assert isinstance(selector.get_feature_names_out(), np.ndarray)

    def test_fit_with_weights_multitask(self):
        """Test fitting with weights for multi-task."""
        selector = self.create_selector()
        weights = np.ones(self.X.shape[0]) * 2.0
        selector.fit(self.X, self.Y, weights=weights)
        features = selector.get_feature_names_out()
        self.check_multitask_output(features)

    def test_fit_with_weights_varying_values(self):
        """Test fitting with varying weight values."""
        selector = self.create_selector()
        weights = np.random.uniform(0.5, 2.0, self.X.shape[0])
        selector.fit(self.X, self.y, weights=weights)
        assert isinstance(selector.get_feature_names_out(), np.ndarray)

    def test_fit_with_weights_invalid_shape(self):
        """Test that invalid weights shape raises ValueError."""
        selector = self.create_selector()
        # Wrong shape: should be (n_samples,) but we provide (n_samples, 1)
        weights = np.ones((self.X.shape[0], 1))
        with self.assertRaises(ValueError) as context:
            selector.fit(self.X, self.y, weights=weights)
        self.assertIn("weights must have shape (n_samples,)", str(context.exception))

    def test_fit_with_weights_wrong_length(self):
        """Test that weights with wrong length raises ValueError."""
        selector = self.create_selector()
        # Wrong length: should be n_samples but we provide n_samples + 1
        weights = np.ones(self.X.shape[0] + 1)
        with self.assertRaises(ValueError) as context:
            selector.fit(self.X, self.y, weights=weights)
        self.assertIn("weights must have shape (n_samples,)", str(context.exception))

    def test_fit_with_weights_zero(self):
        """Test that zero weights raise ValueError."""
        selector = self.create_selector()
        weights = np.ones(self.X.shape[0])
        weights[0] = 0.0
        with self.assertRaises(ValueError) as context:
            selector.fit(self.X, self.y, weights=weights)
        self.assertIn("All weights must be positive", str(context.exception))

    def test_fit_with_weights_negative(self):
        """Test that negative weights raise ValueError."""
        selector = self.create_selector()
        weights = np.ones(self.X.shape[0])
        weights[0] = -1.0
        with self.assertRaises(ValueError) as context:
            selector.fit(self.X, self.y, weights=weights)
        self.assertIn("All weights must be positive", str(context.exception))

    def test_fit_with_weights_sparse_data(self):
        """Test that weights work correctly with sparse data (keep_mask filtering)."""
        selector = self.create_selector()
        weights = np.ones(self.X.shape[0]) * 2.0
        # Fit with sparse data - some samples will be filtered out by keep_mask
        selector.fit(self.X, self.y_sparse, weights=weights)
        assert isinstance(selector.get_feature_names_out(), np.ndarray)

    def test_fit_with_weights_empty_mode(self):
        """Test that weights work correctly with empty mode data."""
        selector = self.create_selector()
        weights = np.ones(self.X.shape[0]) * 1.5
        selector.fit(self.X, self.y_empty_mode, weights=weights)
        assert isinstance(selector.get_feature_names_out(), np.ndarray)

    def test_fit_with_weights_multitask_sparse(self):
        """Test that weights work correctly with multi-task sparse data."""
        selector = self.create_selector()
        weights = np.ones(self.X.shape[0]) * 2.0
        selector.fit(self.X, self.Y_sparse, weights=weights)
        features = selector.get_feature_names_out()
        self.check_multitask_output(features)

    def test_fit_with_weights_float64(self):
        """Test that weights work correctly with float64 dtype."""
        options = self.get_default_millipede_options()
        options["dtype"] = np.float64
        selector = MillipedeTransformer(**options)
        weights = np.ones(self.X.shape[0], dtype=np.float64) * 1.5
        selector.fit(self.X, self.y, weights=weights)
        assert isinstance(selector.get_feature_names_out(), np.ndarray)

    def test_fit_with_assumed_covariates(self):
        """Test fitting with assumed_covariates parameter (string column names)."""
        options = self.get_default_millipede_options()
        # Use first few column names as assumed covariates
        assumed_covariates = self.X.columns[:3].tolist()
        options["assumed_covariates"] = assumed_covariates
        selector = MillipedeTransformer(**options)
        selector.fit(self.X, self.y)
        assert isinstance(selector.get_feature_names_out(), np.ndarray)

    def test_fit_with_assumed_covariates_int(self):
        """Test fitting with assumed_covariates parameter (integer indices)."""
        options = self.get_default_millipede_options()
        # Use integer indices as assumed covariates
        assumed_covariates = [0, 1, 2]
        options["assumed_covariates"] = assumed_covariates
        selector = MillipedeTransformer(**options)
        selector.fit(self.X, self.y)
        assert isinstance(selector.get_feature_names_out(), np.ndarray)

    def test_propagate_time_series_success(self):
        """Test successful time series propagation."""
        options = self.get_default_millipede_options()
        options["return_samples"] = True
        selector = MillipedeTransformer(**options)
        selector.fit(self.X, self.y)

        # Create time series data
        Y_time = pd.DataFrame(
            np.random.randn(self.X.shape[0], 10),
            columns=[f"time_{i}" for i in range(10)],
        )

        result = selector.propagate_time_series(self.X, Y_time, n=10, seed=42)
        assert isinstance(result, pd.DataFrame)
        assert len(result) > 0

    def test_propagate_time_series_no_samples(self):
        """Test that propagate_time_series raises error when samples are not stored."""
        options = self.get_default_millipede_options()
        options["return_samples"] = False
        selector = MillipedeTransformer(**options)
        selector.fit(self.X, self.y)

        Y_time = pd.DataFrame(
            np.random.randn(self.X.shape[0], 10),
            columns=[f"time_{i}" for i in range(10)],
        )

        with self.assertRaises(ValueError) as context:
            selector.propagate_time_series(self.X, Y_time)
        self.assertIn("No samples to use for propagation", str(context.exception))
        self.assertIn("return_samples=True", str(context.exception))

    def test_propagate_time_series_multitask_error(self):
        """Test that propagate_time_series raises error for multi-task data."""
        options = self.get_default_millipede_options()
        options["return_samples"] = True
        selector = MillipedeTransformer(**options)
        # Fit with multi-task data
        selector.fit(self.X, self.Y)

        Y_time = pd.DataFrame(
            np.random.randn(self.X.shape[0], 10),
            columns=[f"time_{i}" for i in range(10)],
        )

        with self.assertRaises(ValueError) as context:
            selector.propagate_time_series(self.X, Y_time)
        self.assertIn(
            "Time-series propagation only supports a single target",
            str(context.exception),
        )

    def test_get_results(self):
        """Test get_results method returns a DataFrame."""
        selector = self.create_selector()
        selector.fit(self.X, self.y)
        results = selector.get_results()
        assert isinstance(results, pd.DataFrame)
        assert len(results) > 0
        # Check that it has MultiIndex columns
        assert isinstance(results.columns, pd.MultiIndex)
        # Check that it has the expected structure
        assert "dataset" in results.columns.names
        assert "stat" in results.columns.names

    def test_get_metadata_default(self):
        """Test get_metadata with default parameters."""
        selector = self.create_selector()
        X = self.X.copy()
        X.columns = [f"cid_{i}" for i in range(X.shape[1])]
        selector.fit(X, self.y)
        metadata = selector.get_metadata()
        assert isinstance(metadata, dict)
        assert "version" in metadata
        assert "sigma" in metadata
        assert "pfi_ratio" in metadata
        assert "is_modelable" in metadata
        assert "datasets_names" in metadata

    def test_get_metadata_with_exclude_cids(self):
        """Test get_metadata with exclude_cids parameter."""
        selector = self.create_selector()
        X = self.X.copy()
        X.columns = [i + 1 for i in range(X.shape[1])]
        selector.fit(X, self.y)
        exclude_cids = [1, 2, 3]  # Exclude first few features
        metadata = selector.get_metadata(exclude_cids=exclude_cids)
        assert isinstance(metadata, dict)
        assert "version" in metadata
        assert "pfi_ratio" in metadata

    def test_get_metadata_with_trustworthiness_check(self):
        """Test get_metadata with custom trustworthiness_check."""
        selector = self.create_selector()
        X = self.X.copy()
        X.columns = [f"cid_{i + 1}" for i in range(X.shape[1])]
        selector.fit(X, self.y)

        def custom_check(pfi_ratio, adjusted_pfi):
            """Custom trustworthiness check that always returns True."""
            return np.ones_like(pfi_ratio, dtype=bool)

        metadata = selector.get_metadata(trustworthiness_check=custom_check)
        assert isinstance(metadata, dict)
        assert "is_modelable" in metadata
        # All should be True with our custom check
        assert all(metadata["is_modelable"])

    def test_check_max_active_constraint_no_diagnostics(self):
        """Test that check_max_active_constraint raises error when diagnostics are not computed."""
        options = self.get_default_millipede_options()
        options["return_diagnostics"] = False
        selector = MillipedeTransformer(**options)
        selector.fit(self.X, self.y)

        with self.assertRaises(ValueError) as context:
            selector.check_max_active_constraint()
        self.assertIn("No diagnostics to check", str(context.exception))
        self.assertIn("return_diagnostics=True", str(context.exception))
