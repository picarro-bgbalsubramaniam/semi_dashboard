"""Sphinx configuration."""
project = 'compound-hunting'
copyright = '2024, Picarro'
author = 'Andrea Biasioli'

extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    'sphinx.ext.viewcode',
    'sphinx.ext.githubpages',
    "myst_parser",
]

autodoc_typehints = "description"

html_theme = 'furo'
