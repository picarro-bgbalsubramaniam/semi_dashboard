"""
This module contains functions for solving linear systems using JAX.
"""

import jax.numpy as jnp
from jax import Array
from jax.typing import ArrayLike


def solve_lsq(
    X: ArrayLike,
    y: ArrayLike,
) -> Array:
    """
    Solves a single linear system Xc = y using normal equations.

    Args:
        X (jnp.ndarray): Model functions matrix with shape (n_samples, n_features).
        y (jnp.ndarray): Target vector with shape (n_samples,).
    Returns:
        jnp.ndarray: Concentrations vector with shape (n_features,).
    """
    return jnp.linalg.solve(X.T @ X, X.T @ y)
