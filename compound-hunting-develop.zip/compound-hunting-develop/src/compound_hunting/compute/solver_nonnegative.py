from functools import partial

import jax
from jax import Array, jit
import jax.numpy as jnp
from jax.typing import ArrayLike


@partial(jit, static_argnums=(2, 3))
def nnlsq_active_set(
    A: ArrayLike,
    b: ArrayLike,
    maxiter: int | None = None,
    tol: float | None = None,
) -> Array:
    """
    JAX implementation of Non-negative Least Squares (NNLS) using active set method.
    Based on scipy's implementation.

    Args:
        A: Model matrix of shape (m, n)
        b: Target vector of shape (m,)
        maxiter: Maximum number of iterations (defaults to 3*n)
        tol: Tolerance for convergence (defaults to 10 * max(m,n) * eps)

    Returns:
        Array: Solution vector of shape (n,)
    """
    m, n = A.shape

    # Pre-compute common terms
    AtA = A.T @ A
    Atb = A.T @ b

    # Set defaults
    if not maxiter:
        maxiter = 3 * n

    if tol is None:
        tol = 10 * max(m, n) * jnp.finfo(jnp.float32).eps

    # boolean mask of constraints, True if variable is active
    P = jnp.zeros(n, dtype=bool)
    x = jnp.zeros(n)  # current solution
    s = jnp.zeros(n)  # trial solution
    w = Atb  # projected residual, gradient (x=0 so skip -AtA @ x term)

    def cond_fn(state):
        x, s, P, w, iter_count = state
        # Continue while not all constraints are active and there are violations
        return ~jnp.all(P) & jnp.any(w * (~P) > tol) & (iter_count < maxiter)

    def body_fn(state):
        x, s, P, w, iter_count = state

        # Find most active coefficient and move to inactive set
        k = jnp.argmax(w * (~P))  # B.2
        P = P.at[k].set(True)  # B.3

        # Solve subsystem for active set
        def solve_subsystem(P, AtA, Atb):
            # P is the active variable mask
            active_AtA = jnp.where(P[:, None] & P[None, :], AtA, 0.0)
            return jax.scipy.linalg.solve(
                active_AtA + jnp.eye(n) * 1e-16,
                jnp.where(P, Atb, 0.0),
                assume_a="sym",
            )

        s = solve_subsystem(P, AtA, Atb)

        # Inner loop to handle negative components
        def inner_cond_fn(inner_state):
            x, s, P, iter_count = inner_state
            return jnp.any(P & (s < 0)) & (iter_count < maxiter)

        def inner_body_fn(inner_state):
            x, s, P, iter_count = inner_state

            # Calculate step size
            alpha = jnp.where(P & (s < 0), x / (x - s), jnp.inf).min()

            # Update solution
            x = x * (1 - alpha) + alpha * s
            P = P & (x > tol)

            # Resolve subsystem
            s = solve_subsystem(P, AtA, Atb)
            s = jnp.where(P, s, 0.0)

            return x, s, P, iter_count + 1

        x, s, P, inner_iter = jax.lax.while_loop(
            inner_cond_fn, inner_body_fn, (x, s, P, iter_count)
        )

        # Update solution and residual
        x = s
        w = Atb - AtA @ x

        return x, s, P, w, iter_count + 1

    # Run main loop
    x, _, _, _, _ = jax.lax.while_loop(cond_fn, body_fn, (x, s, P, w, 0))

    return x
