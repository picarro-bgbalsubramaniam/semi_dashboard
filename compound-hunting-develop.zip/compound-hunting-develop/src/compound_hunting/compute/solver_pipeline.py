"""
This module contains functions for solving linear systems in batches using JAX.
"""

from functools import partial
from typing import Callable, NamedTuple

import jax.numpy as jnp
from jax import Array, jit, vmap
from jax.lax import cond, map, top_k
from jax.typing import ArrayLike

BatchResult = NamedTuple("BatchResult", features=Array, scores=Array)


def _generate_incremental_solutions(
    solutions: ArrayLike, available_features: ArrayLike
) -> Array:
    """
    Generate incremental solutions by combining existing solution
    with all available features.

    For a solution of length (n_cids), we generate (n_features) new
    solutions, each having length (n_cids + 1).

    Args:
        solutions (jnp.ndarray): Array of existing solution (n_cids,).
        available_features (jnp.ndarray): Array of all available features (n_features,).

    Returns:
        jnp.ndarray:
            Array of new solutions, where each row is a combination of
            an existing solution with a new feature.
            It has shape (n_features, n_cids + 1).
    """
    return jnp.column_stack(
        (
            jnp.repeat(solutions[jnp.newaxis, :], available_features.shape[0], axis=0),
            available_features,
        )
    )


def create_feature_evaluator_fn(
    X: ArrayLike,
    y: ArrayLike,
    train_indices: ArrayLike,
    test_indices: ArrayLike,
    solve_fn: Callable[[ArrayLike, ArrayLike], Array],
    scorer_fn: Callable[[ArrayLike, ArrayLike, ArrayLike], Array],
) -> Callable[[Array], Array]:
    """Creates an evaluation function with closure over the data.

    The function will be used to evaluate a single feature combination,
    i.e., a single array of feature indices.

    Args:
        X (ArrayLike): Feature matrix of shape (n_samples, n_features).
        y (ArrayLike): Target values of shape (n_samples,).
        train_indices (ArrayLike): Indices for training data (n_splits, n_train).
        test_indices (ArrayLike): Indices for test data (n_splits, n_test).
        solve_fn (Callable):
            Function that solves the regression problem.
            Expected signature: (X_train, y_train) -> coefficients
        scorer_fn (Callable):
            Function that computes the score.
            Expected signature: (X_test, y_test, y_pred) -> score

    Returns:
        Callable:
            A JIT-compiled function that evaluates a single feature combination.
            The returned function takes an array of feature indices
            and returns a score.
            Expected signature: (combo: Array) -> score: Array
    """

    # this will compute score on a single train/test split
    def compute_score_single(train_idx: Array, test_idx: Array, combo: Array) -> Array:
        """Compute score for a single train/test split.

        Args:
            train_idx (Array): 1D array of training indices for this split
            test_idx (Array): 1D array of test indices for this split
            combo (Array): Array of feature indices to evaluate

        Returns:
            Array: Scalar score for this split
        """
        coefs = solve_fn(X[:, combo][train_idx, :], y[train_idx])
        y_pred = X[:, combo][test_idx, :] @ coefs
        scores = scorer_fn(X[:, combo][test_idx, :], y[test_idx], y_pred)
        return scores

    # this will compute score on all train/test splits, keeping the combo fixed
    compute_score_splits = vmap(compute_score_single, in_axes=(0, 0, None))

    @jit
    def evaluate_feature_combo(combo: Array) -> Array:
        """Evaluate a feature combination across all CV splits.

        Args:
            combo (Array): Array of feature indices to evaluate (n_features,).

        Returns:
            Array:
                Scalar mean score across splits,
                or -inf if combo contains duplicates (to be discarded)
        """
        has_duplicates = jnp.any(jnp.bincount(combo, length=X.shape[1]) > 1)

        def compute_score():
            scores = compute_score_splits(train_indices, test_indices, combo)
            return jnp.mean(scores)

        return cond(has_duplicates, lambda: -jnp.inf, compute_score)

    return evaluate_feature_combo


def create_feature_searcher_fn(
    X: ArrayLike,
    batch_size: int,
    evaluate_single_fn: Callable,
) -> Callable:
    """Creates a solution generator function for feature selection.

    Args:
        X (ArrayLike): Feature matrix of shape (n_samples, n_features).
        batch_size (int): Batch size for processing solutions.
        evaluate_single (Callable):
            Function that evaluates a single feature combination.
            Expected signature: (feature_indices: Array) -> score: Array
            From :py:func:`create_feature_evaluator_fn`.

    Returns:
        Callable:
            A function that generates new solutions from previous ones
            by adding one feature (going one level deeper in the search tree).
            The returned function has signature:
                (previous_solutions: Array, top_n: int) -> tuple[Array, Array]
            where the tuple contains:
                - Array of shape (top_n, n_features) containing selected feature indices
                - Array of shape (top_n,) containing corresponding scores
    """

    # these are the available cids (indexes)
    available_cols = jnp.arange(X.shape[1]).reshape(-1, 1)

    # batch evaluation function
    evaluate_batch_fn = vmap(evaluate_single_fn)

    @partial(jit, static_argnums=(1,))
    def expand_feature_set(current_features: Array, top_n: int) -> tuple[Array, Array]:
        """Expand current feature set by adding one feature.

        If m compounds are available, and we have a solution with n_features cids,
        this function will return the best top_n solutions (of length n_features + 1)
        generated by testing all m available cids.

        Args:
            current_features (Array): Array of current feature combinations.
                Shape (n_features,)
            top_n (int): Number of top solutions to keep

        Returns:
            tuple[Array, Array]: Top feature combinations and their scores.
                - Array of shape (top_n, n_features + 1) containing selected feature indices
                - Array of shape (top_n,) containing corresponding scores
        """
        new_features = _generate_incremental_solutions(current_features, available_cols)
        scores = evaluate_batch_fn(new_features)
        top_scores, top_indices = top_k(scores, k=top_n)
        return new_features[top_indices], top_scores

    @partial(jit, static_argnums=(1,))
    def search_next_level(current_solutions: Array, top_n: int) -> tuple[Array, Array]:
        """Search for the best feature combinations at the next level.

        This function will generate new solutions by adding one feature
        to each of the current solutions.

        Args:
            current_solutions (Array):
                Array of shape (n_solutions, n_features) containing
                current feature combinations (i.e., solutions).
            top_n (int): Number of top solutions to keep.

        Returns:
            tuple[Array, Array]:
                Best top_n solutions from each current solution.
                - Array of shape (n_solutions * top_n, n_features + 1) containing
                  selected feature indices
                - Array of shape (n_solutions * top_n,) containing corresponding
                  scores, sorted in descending order
        """
        new_best_features, new_best_scores = map(
            lambda solution: expand_feature_set(solution, top_n),
            current_solutions,
            batch_size=batch_size,
        )
        # scores shape is (n_solutions, top_n, n_features + 1) from branching
        # flatten them to (n_solutions * top_n, n_features + 1) before next branching
        new_best_features = new_best_features.reshape(-1, new_best_features.shape[-1])
        top_scores = new_best_scores.reshape(-1)
        sort_idx = jnp.argsort(-top_scores)
        return new_best_features[sort_idx], top_scores[sort_idx]

    return search_next_level
