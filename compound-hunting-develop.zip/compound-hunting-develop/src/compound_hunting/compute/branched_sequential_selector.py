"""
Branched sequential feature selection.
"""

from typing import Callable

import jax.numpy as jnp
from jax import Array
from jax.typing import ArrayLike
from tqdm.auto import tqdm

from compound_hunting.compute.solver import solve_lsq
from compound_hunting.compute.solver_nonnegative import nnlsq_active_set
from compound_hunting.compute.solver_pipeline import (
    BatchResult,
    create_feature_evaluator_fn,
    create_feature_searcher_fn,
)


def branched_sequential_selector(
    X: ArrayLike,
    y: ArrayLike,
    train_indices: ArrayLike,
    test_indices: ArrayLike,
    decay_fn: Callable[[int], int],
    scorer_fn: Callable[[ArrayLike, ArrayLike, ArrayLike], Array],
    depth: int,
    batch_size: int,
    positive: bool = False,
    tol: float | None = None,
    show_progress: bool = False,
) -> dict[int, BatchResult]:
    """
    Perform branched sequential feature selection.

    The procedure is a branched search over the feature space: the top solutions
    for a given depth are each used to generate new solutions at the next depth.
    If decay_fn always returns 1, the procedure is equivalent to a sequential
    forward feature selection. From the branching process it is clear that
    decay_fn controls the exploration/exploitation trade-off, and it is best to
    choose a function that converges rapidly (explore more initially, then exploit).
    For example, if decay_fn always returns 10, and we have 50 features, then:

    1. Evaluate top 10 solutions with 1 feature each from 50 available features.
    2. For each of these top 10 solutions, generate 49 new candidates with one
       additional feature (49*10 = 490).
    3. Evaluate these 490 candidates, and select the top 10 from each group of 49,
       for a total of 100 solutions.
    4. For these 100 solutions, generate 48 new candidates with one additional
       feature (48*100 = 4800).
    5. Evaluate these 4800 candidates, and select the top 10 from each group of 48,
       for a total of 1000 solutions.
    6. Repeat until depth is reached, each time evaluating 10 times more solutions.

    Args:
        X (jnp.ndarray): Model functions matrix with shape (n_samples, n_features).
        y (jnp.ndarray): Target vector (spectrum) with shape (n_samples,).
        train_indices (jnp.ndarray):
            Indices of the training samples. It has shape (n_splits, n_train_samples,).
            If you have a single split, reshape it with ``reshape(1, -1)``.
        test_indices (jnp.ndarray):
            Indices of the test samples. It has shape (n_splits, n_test_samples,).
            If you have a single split, reshape it with ``reshape(1, -1)``.
        decay_fn (Callable):
            Function to determine the number of top solutions to keep at each iteration.
            Best to pass a convergent series. It must take an integer (depth) and return
            an integer (number of top solutions to keep).
        scorer_fn (Callable):
            Scoring function. Higher is better.
            The function must take three arguments:
                - ``X_test`` (Array):
                    Model functions matrix with shape ``(n_test_samples, n_features)``.
                - ``y_test`` (Array):
                    Target vector (spectrum) with shape ``(n_test_samples,)``.
                - ``y_pred`` (Array):
                    Predicted target vector (spectrum) with shape ``(n_test_samples,)``.
            and return a scalar ``(1)`` Array.
        depth (int):
            Number of iterations to perform
            (equivalent to number of features in the solution).
        batch_size (int):
            Batch size for computations. If you have out-of-memory issues, decrease this.
        positive (bool):
            If True, use non-negative least squares solver.
        tol (float | None):
            Tolerance for convergence. Stop if score improvement
            is less than tol.
        show_progress (bool): Whether to display a progress bar.

    Returns:
        dict:
            Dictionary with the depth as keys and the selected features and their
            scores as values.
    """
    tol = tol or -jnp.inf
    solver_fn = nnlsq_active_set if positive else solve_lsq

    feature_evaluator_fn = create_feature_evaluator_fn(
        X, y, train_indices, test_indices, solver_fn, scorer_fn
    )

    solutions_generator_fn = create_feature_searcher_fn(
        X, batch_size, feature_evaluator_fn
    )

    # start with the empty solution, naive prediction is target mean
    solutions = jnp.array([[]]).astype(int)
    y_naive = jnp.full_like(y, y.mean())
    old_score = scorer_fn(jnp.empty((X.shape[0], 0)), y, y_naive)
    old_score = jnp.array([old_score])
    results = {0: BatchResult(features=solutions, scores=old_score)}

    pbar = tqdm(total=depth, disable=not show_progress)

    i = 1
    converged = False
    while i <= depth and not converged:
        solutions, scores = solutions_generator_fn(solutions, decay_fn(i - 1))
        results[i] = BatchResult(features=solutions, scores=scores)
        new_score = jnp.max(scores)
        delta = new_score - old_score
        converged = bool(delta < tol)
        pbar.set_postfix({"improvement": delta, "converged": "✔️" if converged else "✘"})
        pbar.update(1)
        old_score = new_score
        i += 1

    pbar.close()
    return results
