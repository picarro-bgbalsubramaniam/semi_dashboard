"""Implementation of the isotropic millipede model in JAX."""

from functools import partial

import jax
import jax.numpy as jnp
from jax import Array

from compound_hunting.millipede.data_structures import (
    MCMCDiagnostics,
    MCMCResults,
    MCMCSample,
)
from compound_hunting.millipede.diagnostics import ess, rhat
from compound_hunting.millipede.feature_permutation_utils import (
    get_feature_reordering_permutations,
    restore_sample_feature_order,
)
from compound_hunting.millipede.mcmc_statistics import (
    align_samples_with_assumed_features,
    compute_mcmc_statistics,
    concatenate_chains,
    scale_mcmc_samples,
)
from compound_hunting.millipede.normal_isotropic_sampler import run_mcmc_chain_scan
from compound_hunting.millipede.prepare_chain_inputs import (
    _add_intercept,
    _expand_y,
    _prepare_chain_inputs,
)


def isotropic_millipede(
    X: Array,
    Y: Array,
    sample: int = 2000,
    tune: int = 1000,
    chains: int = 4,
    s: float = 5.0,
    tau: float = 0.01,
    tau_intercept: float = 1.0e-4,
    nu0: float = 0.0,
    lambda0: float = 0.0,
    explore: float = 5,
    seed: int = 0,
    batch_size: int = 10,
    max_active: int | None = None,
    return_samples: bool = False,
    return_diagnostics: bool = False,
    scale_X: Array | None = None,
    scale_Y: Array | None = None,
    mean_X: Array | None = None,
    mean_Y: Array | None = None,
    assumed_covariates_idx: Array | None = None,
) -> tuple[MCMCResults, MCMCDiagnostics | None, MCMCSample | None]:
    """Run the isotropic millipede model for Bayesian variable selection.

    This function implements the isotropic millipede model, which performs Bayesian
    variable selection using MCMC sampling. The algorithm is based on the paper
    "Bayesian Variable Selection in a Million Dimensions". It uses multiple MCMC
    chains to sample from the posterior distribution of model parameters.

    Args:
        X (Array):
            Input matrix of shape (N, P) where N is the number of samples (modes) and P is the
            number of features/covariates (cids). Alternatively, the input matrix
            can have shape (T, N, P) where T is the number of spectra to fit.
            X should be standardized before being provided to the function.
            To retrieve concentrations and sigma in the original scale,
            use the `scale_X` and `scale_Y` arguments.
        Y (Array):
            Target vector of shape (N,) containing the spectrum to fit.
            Alternatively, a matrix of shape (T, N) containing T spectra to fit.
            Y should be standardized before being provided to the function.
            To retrieve concentrations in the original scale, use the `scale_X` and
            `scale_Y` arguments.
        sample (int):
            Number of MCMC samples to draw after tuning.
        tune (int):
            Number of tuning steps before sampling.
        chains (int):
            Number of parallel MCMC chains to run. Defaults to 4.
        s (float):
            Expected number of covariates to include in the model a priori.
            Controls the sparsity level. Defaults to 5.0.
        tau (float):
            Precision parameter for the isotropic prior on coefficients. Controls the
            variance of the coefficient prior distribution. Defaults to 0.01.
        tau_intercept (float):
            Precision parameter for the intercept term. Controls the variance
            of the intercept prior distribution. Defaults to 1.0e-4.
        nu0 (float):
            Shape parameter for the inverse gamma prior on the noise variance.
            Defaults to 0.0.
        lambda0 (float):
            Scale parameter for the inverse gamma prior on the noise variance.
            Defaults to 0.0.
        explore (float):
            Controls how greedy the MCMC algorithm is. Higher values lead to more
            exploration of the parameter space. Defaults to 5.
        seed (int):
            Random seed for reproducibility. Defaults to 0.
        batch_size (int):
            Number of spectra to analyze in parallel (if Y has more than one spectrum).
            Defaults to 10. Reduce if you have memory issues.
        max_active (int | None):
            Maximum number of active features allowed in the model.
            If None (default), it's set to N/10 where N is the number of samples.
        return_samples (bool):
            Whether to return the raw MCMC samples. Defaults to False.
        return_diagnostics (bool):
            Whether to return the convergence diagnostics. Defaults to False.
        scale_X (Array | None):
            Scaling factor used for the provided features in X.
            Shape (P+1,), i.e., features + intercept.
            If None, the scaling factors are set to 1.0 (no scaling).
        scale_Y (Array | None):
            Scaling factor for the provided targets. Shape (T,).
            If None, the scaling factors are set to 1.0 (no scaling).
        mean_X (Array | None):
            Mean of the features in X. Shape (P+1,).
            If None, the mean is set to the mean of the features in X.
        mean_Y (Array | None):
            Mean of the target in Y. Shape (T,).
            If None, the mean is set to the mean of the target in Y.

    Returns:
        A tuple containing:
            - MCMCResults: Summary statistics for the MCMC chains, including mean,
              standard deviation, and convergence diagnostics.
              Each element of MCMCResults has dimensions (T, chains, features) if T is the
              number of spectra in Y and features is the number of features in X.
            - MCMCDiagnostics: Convergence diagnostics including R-hat and effective
              sample size (ESS) for each the posterior inclusion probabilities.
              The shape of MCMCDiagnostics is (T, features) if return_diagnostics is True.
            - MCMCSample: Raw MCMC samples from all chains if return_samples is True,
              otherwise None. The shape of MCMCSample is (T, chains, sample, features).

    Raises:
        ValueError: If X and Y have different numbers of modes or spectra to fit.
    """
    if max_active is None:
        n_modes = X.shape[0] if X.ndim == 2 else X.shape[1]
        max_active = int(n_modes / 10)
    elif max_active > X.shape[1]:
        max_active = X.shape[1]

    Y = _expand_y(Y)  # (n_spectra, modes)

    if assumed_covariates_idx is None:
        assumed_covariates_idx = jnp.array([], dtype=jnp.int32)

    if X.ndim == 2:
        X = jnp.broadcast_to(X, (Y.shape[0], *X.shape))

    # Y is (n_spectra, modes), X is (n_spectra, modes, features)

    # add intercept as first feature
    X = _add_intercept(X)

    # intercept is an assumed covariate. idx of other assumed covariates is shifted by 1
    assumed_covariates_idx = jnp.concatenate(
        [jnp.array([0], dtype=assumed_covariates_idx.dtype), assumed_covariates_idx + 1]
    )

    if X.shape[0] != Y.shape[0]:
        raise ValueError(
            f"X and Y must have the same number of samples in first dimension. "
            f"Got X shape {X.shape} and Y shape {Y.shape}"
        )

    if X.shape[1] != Y.shape[1]:
        raise ValueError(
            f"X and Y must have the same number of modes in second dimension. "
            f"Got X shape {X.shape} and Y shape {Y.shape}"
        )

    if scale_X is None:
        scale_X = jnp.ones(X.shape[2])

    if scale_Y is None:
        scale_Y = jnp.ones(Y.shape[0])

    if scale_Y.shape[0] != Y.shape[0]:
        raise ValueError(
            f"There must be a scale factor for each spectrum in Y. "
            f"Got scale_Y shape {scale_Y.shape} and Y shape {Y.shape}"
        )

    if scale_X.shape[0] != X.shape[2]:
        raise ValueError(
            f"There must be a scale factor for each feature in X including the intercept. "
            f"Got scale_X shape {scale_X.shape} and X shape {X.shape}"
        )

    if mean_X is None:
        mean_X = jnp.nanmean(X, axis=1)  # (n_spectra, features)

        # for now, we assume that the mean is the same for all spectra
        # this will change if we want to stack different instances of
        # model function matrices
        mean_X = mean_X[0, ...]  # (features,)

    if mean_Y is None:
        mean_Y = jnp.nanmean(Y, axis=1)  # (n_spectra,)

    # get the permutations to put assumed covariates first
    permutation_to_end, permutation_to_original = get_feature_reordering_permutations(
        X.shape[2], assumed_covariates_idx
    )

    # reorder the features for X and scale_X
    X = X[:, :, permutation_to_end]
    scale_X = scale_X[permutation_to_end]
    mean_X = mean_X[permutation_to_end]

    with jax.default_matmul_precision("highest"):
        return _run_millipede_batched(
            X=X,
            Y=Y,
            sample=sample,
            tune=tune,
            chains=chains,
            seed=seed,
            batch_size=batch_size,
            max_active=max_active,
            return_samples=return_samples,
            return_diagnostics=return_diagnostics,
            s=s,
            tau=tau,
            tau_intercept=tau_intercept,
            nu0=nu0,
            lambda0=lambda0,
            explore=explore,
            scale_X=scale_X,
            scale_Y=scale_Y,
            mean_X=mean_X,
            mean_Y=mean_Y,
            Pa=len(assumed_covariates_idx),
            permutation_to_original=permutation_to_original,
        )


@partial(
    jax.jit,
    static_argnames=[
        "sample",
        "tune",
        "chains",
        "s",
        "tau",
        "tau_intercept",
        "nu0",
        "lambda0",
        "explore",
        "max_active",
        "return_samples",
        "batch_size",
        "seed",
        "return_diagnostics",
        "Pa",
    ],
)
def _run_millipede_batched(
    X: Array,
    Y: Array,
    sample: int,
    tune: int,
    chains: int,
    s: float,
    tau: float,
    tau_intercept: float,
    nu0: float,
    lambda0: float,
    explore: float,
    seed: int,
    batch_size: int,
    max_active: int,
    return_samples: bool,
    return_diagnostics: bool,
    scale_X: Array,
    scale_Y: Array,
    mean_X: Array,
    mean_Y: Array,
    Pa: int,
    permutation_to_original: Array,
) -> tuple[MCMCResults, MCMCDiagnostics | None, MCMCSample | None]:
    """Run batched MCMC chains for multiple target spectra.

    Args:
        X (Array):
            Input matrix of shape (N, P).
        Y (Array):
            Target matrix of shape (T, N) containing T spectra.
        sample (int):
            Number of MCMC samples to draw after tuning.
        tune (int):
            Number of tuning steps.
        chains (int):
            Number of parallel MCMC chains.
        s (float):
            Expected number of covariates to include.
        tau (float):
            Precision parameter for coefficient prior.
        tau_intercept (float):
            Precision parameter for intercept prior.
        nu0 (float):
            Shape parameter for noise variance prior.
        lambda0 (float):
            Scale parameter for noise variance prior.
        explore (float):
            Exploration parameter for MCMC.
        seed (int):
            Random seed.
        batch_size (int):
            Number of targets to process in each batch.
        max_active (int):
            Maximum number of active features allowed.
        return_samples (bool):
            Whether to return raw MCMC samples.
        return_diagnostics (bool):
            Whether to return convergence diagnostics.
        scale_X (Array):
            Scaling factor for the features. Shape (Pa+P,).
        scale_Y (Array):
            Scaling factor for the target. Shape (T,).
        mean_X (Array):
            Mean for the features. Shape (Pa+P,).
        mean_Y (Array):
            Mean for the target. Shape (T,).
        Pa (int):
            Number of assumed covariates (intercept, or
            other covariates whose presence is forced into the model).
        permutation_to_original (Array):
            Permutation to original features. Shape (Pa+P,).

    Returns:
        A tuple containing:
            - MCMCResults: Summary statistics for the MCMC chains.
            - MCMCDiagnostics: Convergence diagnostics including R-hat and effective
              sample size (ESS) for each parameter. If return_diagnostics is False,
              the MCMCDiagnostics object is None.
            - MCMCSample: Raw MCMC samples if return_samples is True, otherwise None.
    """
    n_spectra = Y.shape[0]
    spectra_idx = jnp.arange(n_spectra)

    key = jax.random.PRNGKey(seed)

    def _run_single_target(i: int) -> tuple[MCMCResults, MCMCSample, MCMCDiagnostics]:
        Xs, ys, scale_y, mean_y = X[i], Y[i], scale_Y[i], mean_Y[i]
        spectrum_key = jax.random.fold_in(key, i)
        spectrum_chain_keys = jax.random.split(spectrum_key, chains)

        def _run_single_chain(chain_key) -> tuple[MCMCResults, MCMCSample]:
            inputs = _prepare_chain_inputs(
                Xs,
                ys,
                s,
                tau,
                tau_intercept,
                nu0,
                lambda0,
                explore,
                chain_key[0],
                max_active,
                Pa,
            )
            _, samples = run_mcmc_chain_scan(inputs, tune, sample)
            samples = align_samples_with_assumed_features(samples)
            samples = scale_mcmc_samples(samples, scale_X, scale_y, mean_X, mean_y)
            samples = restore_sample_feature_order(samples, permutation_to_original)
            return samples

        # Always get samples for diagnostics, even if we don't return them
        samples = jax.vmap(_run_single_chain)(spectrum_chain_keys)
        summary = compute_mcmc_statistics(concatenate_chains(samples))

        # check if the maximum number of simultaneously active features observed across
        # all MCMC samples remained within the specified maximum active limit
        within_active_limit = jnp.all(summary.active_count_max <= max_active)

        # clip to avoid numerical issues with rhat
        tol = 10.0 * jnp.finfo(samples.pip.dtype).eps
        pip = jnp.clip(samples.pip, tol, 1 - tol)

        diagnostics = (
            MCMCDiagnostics(
                rhat=rhat(pip),
                ess=ess(pip),
                within_active_limit=within_active_limit,
            )
            if return_diagnostics
            else None
        )

        samples = samples if return_samples else None
        return summary, diagnostics, samples

    return jax.lax.map(_run_single_target, spectra_idx, batch_size=batch_size)
