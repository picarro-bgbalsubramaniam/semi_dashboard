import jax
import jax.numpy as jnp
import numpy as np
from jax import Array
from numpy.typing import ArrayLike

from compound_hunting.millipede.data_structures import (
    MCMCDiagnostics,
    MCMCResults,
    MCMCSample,
    WeightedFeatureStats,
)


def normalize_weights(weights: Array) -> Array:
    """Normalize weights with numerical stability.

    Applies a log-sum-exp style stabilization to avoid numerical under/overflow
    and ensures the returned weights sum to 1.

    Args:
        weights (Array): Array of weights to normalize.

    Returns:
        Array: Normalized weights that sum to 1.
    """
    weights_safe = jnp.maximum(weights, 1e-12)
    log_weights = jnp.log(weights_safe)
    log_weights_adjusted = log_weights - jnp.max(log_weights)
    weights_exp = jnp.exp(log_weights_adjusted)
    return weights_exp / jnp.sum(weights_exp)


@jax.jit
def compute_mcmc_statistics(samples: MCMCSample) -> MCMCResults:
    """Compute MCMC statistics from samples.

    Calculates weighted posterior statistics including:
    - Posterior inclusion probabilities (PIP)
    - Regression coefficients (beta) and their standard deviations
    - Conditional regression coefficients (given feature inclusion)
    - Noise standard deviation estimates

    Args:
        samples (MCMCSample): Container holding MCMC samples with fields:
            - weight: Array of shape (n_samples,) containing sample weights
            - pip: Array of shape (n_samples, P) posterior inclusion probabilities
            - beta: Array of shape (n_samples, Pa+P) regression coefficients
            - gamma: Array of shape (n_samples, P) active feature indicators
            - sigma: Array of shape (n_samples,) noise standard deviations

    Returns:
        MCMCResults: Named tuple containing:
            - pip: Array of shape (P,) posterior inclusion probabilities
            - beta: Array of shape (Pa+P,) mean regression coefficients
            - beta_std: Array of shape (Pa+P,) std.dev of regression coefficients
            - conditional_beta: Array of shape (Pa+P,) mean coefficients given inclusion
            - conditional_beta_std: Array of shape (Pa+P,) std.dev given inclusion
            - sigma: Scalar mean noise standard deviation
            - sigma_std: Scalar std.dev of noise standard deviation
            - active_count_max: Scalar, max number of simultaneously active
                features encountered in the chain.
    Notes:
        - Weights are normalized to sum to 1 before computation
        - Conditional statistics for non-assumed features are computed using
          only samples where the feature was active (gamma=1)
        - Assumed covariates (first positions) are always included in conditional stats
        - Uses numerical stability terms (1e-10) to prevent division by zero
    """
    # Normalize weights with improved numerical stability
    weights = normalize_weights(samples.weight)

    # Weighted feature statistics (pip, beta, conditional) computed uniformly
    stats = compute_weighted_feature_stats(
        weights, samples.beta, samples.gamma, samples.pip
    )
    pip = stats.pip
    beta = stats.beta_mean
    beta_std = stats.beta_std
    sigma = jnp.sum(samples.sigma * weights)
    sigma_std = jnp.sqrt(
        jnp.sum(jnp.square(samples.sigma) * weights) - jnp.square(sigma)
    )

    conditional_beta = stats.conditional_beta
    conditional_beta_std = stats.conditional_beta_std

    # count of active features in each sample of the chain
    active_count = jnp.sum(samples.activeb, axis=1)  # shape (n_samples,)
    active_count_max = jnp.max(active_count)  # max active in chain

    return MCMCResults(
        pip=pip,
        beta=beta,
        beta_std=beta_std,
        conditional_beta=conditional_beta,
        conditional_beta_std=conditional_beta_std,
        sigma=sigma,
        sigma_std=sigma_std,
        active_count_max=active_count_max,
    )


def compute_weighted_feature_stats(
    weights: Array,
    beta: Array,
    gamma: Array,
    pip: Array,
) -> WeightedFeatureStats:
    """Compute weighted per-feature statistics across samples (2D case).

    Calculates weighted posterior statistics over the sample axis (axis=0):
      - Posterior inclusion probabilities (PIP)
      - Regression coefficients (beta) and their standard deviations
      - Conditional regression coefficients (given feature inclusion)
        and their standard deviations

    Args:
        weights (Array): Shape (N,). Importance weights. Must be normalized
            to sum to 1 prior to calling (see `normalize_weights`).
        beta (Array): Shape (N, F=P+Pa). Regression coefficients per sample.
        gamma (Array): Shape (N, F=P+Pa). Boolean active-feature indicators per sample.
        pip (Array): Shape (N, F=P+Pa). Posterior inclusion probabilities per sample.

    Returns:
        WeightedFeatureStats:
            NamedTuple containing per-feature arrays of shape (F=P+Pa,):
            - pip: Weighted mean PIP across samples
            - beta_mean: Weighted mean of beta across samples
            - beta_std: Weighted std.dev of beta across samples
            - conditional_beta: Weighted mean of beta given gamma==1
            - conditional_beta_std: Weighted std.dev of beta given gamma==1
    """
    # Unconditional means and stds
    w = weights[:, None]  # (N,1)
    weighted_beta = beta * w
    weighted_beta_sq = jnp.square(beta) * w

    beta_mean = jnp.nansum(weighted_beta, axis=0)  # (F,)
    beta_sq_mean = jnp.nansum(weighted_beta_sq, axis=0)  # (F,)
    beta_std = jnp.sqrt(jnp.maximum(beta_sq_mean - jnp.square(beta_mean), 0.0))

    # pip weighted mean (pip is assumed present)
    pip_out = jnp.sum(pip * w, axis=0)  # (F,)

    # Conditional stats given gamma==1
    gamma_sum = jnp.sum(gamma * w, axis=0)  # (F,)
    denom = jnp.maximum(gamma_sum, 1e-10)  # (F,)

    beta_num = jnp.nansum(weighted_beta * gamma, axis=0)  # (F,)
    beta_sq_num = jnp.nansum(weighted_beta_sq * gamma, axis=0)  # (F,)

    conditional_beta = beta_num / denom  # (F,)
    conditional_beta_std = jnp.sqrt(
        jnp.maximum(beta_sq_num / denom - jnp.square(conditional_beta), 0.0)
    )  # (F,)

    return WeightedFeatureStats(
        pip=pip_out,
        beta_mean=beta_mean,
        beta_std=beta_std,
        conditional_beta=conditional_beta,
        conditional_beta_std=conditional_beta_std,
    )


def scale_mcmc_samples(
    samples: MCMCSample, scale_x: Array, scale_y: Array, mean_x: Array, mean_y: Array
) -> MCMCSample:
    """Scales MCMC sample parameters back to the original data scale.

    This function adjusts the regression coefficients (beta) and the noise
    standard deviation (sigma) from the standardized scale used during MCMC
    sampling back to the scale of the original input data (X) and target (y).
    The intercept is adjusted to ensure the mean of the original data is preserved.
    Other fields in the MCMCSample are returned unchanged.

    Args:
        samples (MCMCSample): Container holding MCMC samples with fields like
            beta (n_samples, P+Pa) and sigma (n_samples,).
        scale_x (Array): Scaling factor applied to the features (columns of X).
            Typically the standard deviation of each feature. Shape (P+Pa,).
        scale_y (Array): Scaling factor applied to the target variable (y).
            Typically the standard deviation of y. Shape (1,) or scalar.
        mean_x (Array): Mean of the features (columns of X). Shape (P+Pa,).
        mean_y (Array): Mean of the target variable (y). Shape (1,) or scalar.

    Returns:
        MCMCSample: A new MCMCSample object with beta and sigma fields adjusted
            to the original data scale. Other fields are copied directly.
    """
    concentration_scale = scale_y / scale_x
    betas = samples.beta * concentration_scale
    offset = mean_y - (jnp.nan_to_num(betas[:, 1:], 0.0) @ mean_x[1:])
    betas = betas.at[:, 0].add(offset)

    return MCMCSample(
        gamma=samples.gamma,
        activeb=samples.activeb,
        beta=betas,
        sigma=samples.sigma * scale_y,
        pip=samples.pip,
        idx=samples.idx,
        log_h_ratio=samples.log_h_ratio,
        weight=samples.weight,
    )


def aggregate_chain_results(
    results: MCMCResults,
    area_x: ArrayLike,
    diagnostics: MCMCDiagnostics | None = None,
) -> Array:
    """Aggregates MCMC results and optional diagnostics into a single array.

    Stacks key statistics (PIP, conditional beta, conditional beta std) from
    `results` and (R-hat, ESS) from `diagnostics` (if provided).
    Assumes inputs have leading `n_spectra` and trailing `n_features` dimensions.

    Args:
        results (MCMCResults):
            MCMC output statistics.
            - `pip` (Array):
                Posterior Inclusion Probabilities. Shape `(n_spectra, n_features)`.
            - `conditional_beta` (Array):
                Conditional mean regression coefficients. Shape `(n_spectra, n_features)`.
            - `conditional_beta_std` (Array):
                Std dev of conditional betas. Shape `(n_spectra, n_features)`.
        area_x (ArrayLike):
            Areas under the curve for the features (partial fit integral for 1 ppb).
            Shape `(n_features)`.
        diagnostics (MCMCDiagnostics | None, optional):
            MCMC convergence diagnostics. If None, R-hat/ESS are NaN.
            - `rhat` (Array): R-hat diagnostic. Shape `(n_spectra, n_features)`.
            - `ess` (Array): Effective Sample Size. Shape `(n_spectra, n_features)`.
    Returns:
        Array:
            Stacked statistics. Shape: `(n_spectra, 5, n_features)`.
            The second dimension (size 5) contains:
            0. PIP (`results.pip`)
            1. R-hat (`diagnostics.rhat` or NaN)
            2. ESS (`diagnostics.ess` or NaN)
            3. Conditional beta (`results.conditional_beta`)
            4. Conditional beta std dev (`results.conditional_beta_std`)
            5. Partial fit integral contributions (`np.array(results.beta) * area_x`)
    """
    pip_mean = results.pip  # (n_spectra, n_features)
    beta_means = results.conditional_beta  # (n_spectra, n_features)
    beta_stds = results.conditional_beta_std  # (n_spectra, n_features)

    if diagnostics is not None:
        # Assuming diagnostics.rhat and diagnostics.ess are already (n_spectra, n_features)
        rhat = diagnostics.rhat
        ess = diagnostics.ess
    else:
        # Create NaN arrays with the full feature dimension
        empty_diagnostics_full = jnp.full_like(
            pip_mean, jnp.nan
        )  # means is (n_spectra, n_features)
        rhat = empty_diagnostics_full
        ess = empty_diagnostics_full

    # beta is (n_spectra, n_features), area_x is (n_features)
    contributions = np.array(results.beta) * area_x  # (n_spectra, n_features)

    # apply the operation over the dataset dimension (multiple datasets)
    data = jnp.stack(
        [pip_mean, rhat, ess, beta_means, beta_stds, contributions], axis=1
    )
    return data


def align_samples_with_assumed_features(samples: MCMCSample) -> MCMCSample:
    """Aligns feature dimensions of gamma and PIP with beta by prepending assumed features.

    This function takes an MCMCSample object and modifies the `gamma` and `pip`
    arrays. It assumes that `samples.beta` has a feature dimension that includes
    both active and assumed features, while `samples.gamma` and `samples.pip`
    only represent active features.

    The function calculates the number of assumed features by comparing the
    last dimension of `samples.beta` and `samples.gamma`. It then prepends
    placeholders for these assumed features to `gamma` (as True values) and
    `pip` (as 1.0 values), making their last dimension match that of `beta`.

    Other fields from the input `samples` object (`activeb`, `beta`, `sigma`,
    `idx`, `log_h_ratio`, `weight`) are passed through to the new MCMCSample
    instance.

    Args:
        samples (MCMCSample):
            An MCMC sample object. Expected to have the following
            attributes with compatible shapes:
            - beta: Array with shape `(*batch_dims, n_total_features)`.
            - gamma: Array with shape `(*batch_dims, n_active_features)`, boolean.
            - pip: Array with shape `(*batch_dims, n_active_features)`.
            - activeb, sigma, idx, log_h_ratio, weight: Other relevant fields.
            It's assumed that `batch_dims` allows `samples.gamma.shape[0]` to
            be used for constructing the padding for assumed features. For
            instance, if gamma is `(N, P_active)`, padding will be `(N, n_assumed)`.

    Returns:
        MCMCSample:
            A new MCMCSample instance where:
            - gamma: Array with shape `(*batch_dims, n_total_features)`, boolean.
              The original `gamma` is prepended with `True` for assumed features.
            - pip: Array with shape `(*batch_dims, n_total_features)`.
              The original `pip` is prepended with `1.0` for assumed features.
            - activeb, beta, sigma, idx, log_h_ratio, weight are taken
              directly from the input `samples`.
    """
    n_features = samples.beta.shape[-1]
    n_assumed = n_features - samples.gamma.shape[-1]

    # Pad gamma and pip with placeholders
    assumed_ones_values = jnp.ones(
        (samples.gamma.shape[0], n_assumed), dtype=samples.pip.dtype
    )

    gamma = jnp.concatenate([assumed_ones_values.astype(bool), samples.gamma], axis=-1)
    pip = jnp.concatenate([assumed_ones_values, samples.pip], axis=-1)

    return MCMCSample(
        gamma=gamma,
        activeb=samples.activeb,
        beta=samples.beta,
        sigma=samples.sigma,
        pip=pip,
        idx=samples.idx,
        log_h_ratio=samples.log_h_ratio,
        weight=samples.weight,
    )


def concatenate_chains(samples: MCMCSample) -> MCMCSample:
    """Concatenates chains of an MCMCSample object into a single long chain.

    This function takes an MCMCSample object and concatenates the chains along
    the first dimension. It assumes that all arrays in the MCMCSample have the
    same shape except for the first dimension, which is the number of chains.

    Args:
        samples (MCMCSample):
            An MCMC sample object. It is expected to contain the following
            attributes, where `n_chains` is the number of MCMC chains,
            `n_draws` is the number of draws per chain, and `n_features`
            is the number of features:
            - gamma: `(n_chains, n_draws, n_features)`
            - activeb: `(n_chains, n_draws, n_features)`
            - beta: `(n_chains, n_draws, n_features)`
            - sigma: `(n_chains, n_draws)`
            - pip: `(n_chains, n_draws, n_features)`
            - idx: `(n_chains, n_draws)`
            - log_h_ratio: `(n_chains, n_draws)`
            - weight: `(n_chains, n_draws)`

    Returns:
        MCMCSample: A new MCMCSample instance with concatenated chains.
            Each attribute will have its first dimension changed from
            `n_chains` to `n_chains * n_draws`, effectively merging
            all chains into a single long chain. For example, `gamma`
            will have shape `(n_chains * n_draws, n_features)`.
    """
    idx_chain, idx_draw = 0, 1  # idx_compound would be 2, unused here
    chains = samples.pip.shape[idx_chain]
    draws = samples.pip.shape[idx_draw]
    return jax.tree.map(
        lambda x: jnp.reshape(x, (chains * draws, *x.shape[2:])), samples
    )
