"""Functions for computing leave-one-out (LOO) terms in isotropic regression.

Contains utilities for calculating log determinants and residual sum of squares (RSS)
when excluding individual features.
"""

import jax
import jax.numpy as jnp
from jax import Array


def compute_log_det_complete(
    ATA: Array,
    activeb: Array,
    tau: float,
    i: int,
) -> float:
    """Compute single log determinant term with masking.

    This function computes the log determinant of the covariance matrix of the
    active features, excluding the i-th feature.
    If the i-th feature is not active, the function returns 0.0.

    Args:
        ATA (Array): Array of shape (m, m), the gram matrix X.T @ X
        activeb (Array): Array of shape (m,), boolean mask indicating active features
        tau (float): Precision parameter (scalar)
        i (int): Index of feature to compute for (0 <= i < m)

    Returns:
        float: Log determinant term for feature i
    """
    return jax.lax.cond(
        activeb[i],
        lambda: _compute_log_det_complete(ATA, activeb, tau, i),
        lambda: 0.0,
    )


def _compute_log_det_complete(
    ATA: Array,
    activeb: Array,
    tau: float,
    i: int,
) -> float:
    """Helper function to compute log determinant term.

    Args:
        ATA (Array): Array of shape (m, m), the gram matrix X.T @ X
        activeb (Array): Array of shape (m,), boolean mask indicating active features
        tau (float): Precision parameter (scalar)
        i (int): Index of feature to compute for (0 <= i < m)

    Returns:
        float: Log determinant term for feature i
    """
    m = ATA.shape[0]

    # Deactivate feature i
    mask = activeb.at[i].set(False)

    # Zero out row/col i while maintaining matrix properties
    masked_ATA = jnp.where(mask[:, None] & mask[None, :], ATA, 0.0)

    # Add 1 on diagonal i to keep positive-definiteness
    masked_ATA = masked_ATA + jnp.eye(m) * (1 - mask)

    # Get off-diagonal elements for feature i
    X_I_X_k = jnp.where(mask, ATA[:, i], 0.0)

    # Solve system to get equivalent of F @ X_I_X_k
    F_X_I_X_k = jax.scipy.linalg.solve(
        masked_ATA + jnp.eye(m) * 1e-8, X_I_X_k, assume_a="pos"
    )

    XXFXX = jnp.sum(jnp.where(mask, X_I_X_k * F_X_I_X_k, 0.0))
    G_k_inv = ATA[i, i] - XXFXX
    G_k_inv = jnp.maximum(G_k_inv, 1e-12)
    return -0.5 * jnp.log(G_k_inv) + 0.5 * jnp.log(tau)


def compute_loo_rss_complete(
    ATA: Array,
    ATb: Array,
    activeb: Array,
    i: int,
) -> float:
    """Compute leave-one-out transformed sum of squares with masking.

    Args:
        ATA (Array): Array of shape (m, m), the gram matrix X.T @ X
        ATb (Array): Array of shape (m,), the projection X.T @ y
        activeb (Array): Array of shape (m,), boolean mask indicating active features
        i (int): Index of feature to leave out (0 <= i < m)

    Returns:
        float:
            Transformed sum of squares when excluding feature i,
            or 0.0 if feature i is inactive
    """
    return jax.lax.cond(
        activeb[i],
        lambda: _compute_loo_rss_complete(ATA, ATb, activeb, i),
        lambda: 0.0,
    )


def _compute_loo_rss_complete(
    ATA: Array,
    ATb: Array,
    activeb: Array,
    i: int,
) -> float:
    """Compute leave-one-out transformed sum of squares.

    Args:
        ATA (Array): Array of shape (m, m), the gram matrix X.T @ X
        ATb (Array): Array of shape (m,), the projection X.T @ y
        activeb (Array): Array of shape (m,), boolean mask indicating active features
        i (int): Index of feature to leave out (0 <= i < m)

    Returns:
        float: Transformed sum of squares when excluding feature i
    """
    m = ATA.shape[0]

    # Deactivate feature i
    mask = activeb.at[i].set(False)

    # Zero out row/col i while maintaining matrix properties
    masked_ATA = ATA * mask[:, None] * mask[None, :]
    masked_ATA = masked_ATA + jnp.eye(m) * (1 - mask)  # Add 1 on diagonal i

    # Zero out element i in ATb
    masked_ATb = ATb * mask

    # Solve for coefficients
    c = jax.scipy.linalg.solve(
        masked_ATA + jnp.eye(m) * 1e-8, masked_ATb, assume_a="pos"
    )

    # Compute transformed sum of squares (equivalent to Zt_active_loo_sq)
    loo_sq = c @ ATb

    return loo_sq
