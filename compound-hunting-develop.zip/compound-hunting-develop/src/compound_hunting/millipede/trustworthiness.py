from typing import Callable, TypeAlias

import numpy as np

# Public type alias for custom trustworthiness checks
TrustworthinessCheck: TypeAlias = Callable[[np.ndarray, np.ndarray], np.ndarray]


def power_law_threshold(
    x: np.ndarray | list[float],
    a: float = 1.0,
    b: float = 0.010,
    n: float = 1.25,
    c: float = 0.0,
) -> np.ndarray:
    """Power law threshold function used to assess model trustworthiness.

    Returns a / (b * x)^n + c for each element of x.
    Note that x is taken as the absolute value to avoid NaN results.
    This means that the threshold is always positive, so checking for
    non-modelable datasets is not possible when the partial fit integral is negative.
    """
    x_arr = np.abs(np.asarray(x, dtype=float))
    return a / np.power(b * x_arr, n) + c


def default_trustworthiness_check(
    pfi_ratio: np.ndarray | list[float],
    adjusted_pfi: np.ndarray | list[float],
) -> np.ndarray:
    """Default check: trustworthy if pfi_ratio < power_law_threshold(adjusted_pfi)."""
    pfi_arr = np.asarray(pfi_ratio, dtype=float)
    adj_arr = np.asarray(adjusted_pfi, dtype=float)
    return pfi_arr < power_law_threshold(adj_arr)
