"""
This module provides functionality to convert MCMC samples from the Millipede model
into an ArviZ InferenceData object. This conversion enables visualization and analysis
using the ArviZ package, which offers various diagnostic plots and analyses for MCMC samples.
"""

import importlib

import numpy as np

from compound_hunting.millipede.data_structures import MCMCSample


def get_arviz_inference_data(
    samples: MCMCSample,
    cid_names: list[str | int] | None = None,
    datasets_names: list[str] | None = None,
):
    """Convert MCMCSample to ArviZ InferenceData for visualization and analysis.

    This function transforms the MCMC samples from the Millipede model into an
    ArviZ InferenceData object, which enables various diagnostic plots and
    analyses provided by the ArviZ package.

    Args:
        samples (MCMCSample):
            MCMCSample object containing the MCMC samples with attributes:
            - pip: Posterior inclusion probabilities (n_chains, n_draws, n_compounds)
            - active: Boolean mask for active features (n_chains, n_draws, n_compounds)
            - beta: Regression coefficients (n_chains, n_draws, n_compounds)
            - sigma: Noise standard deviation (n_chains, n_draws)
        cid_names (list[str | int] | None):
            Optional list of compound identifiers (strings or integers) to use
            as coordinate labels. If None, integer indices will be used.
        datasets_names (list[str] | None):
            Optional list of dataset names to use as coordinate labels.
            If None, ordinal indices will be used.

    Returns:
        arviz.InferenceData:
            An ArviZ InferenceData object containing the MCMC samples
            with appropriate dimensions and coordinates.

    Raises:
        ValueError: If samples.pip has more than 3 dimensions.
        ImportError: If the arviz package is not installed.
    """
    if samples.pip.ndim != 4:
        raise ValueError(
            "samples must have shape (n_datasets, n_chains, n_draws, n_compounds)"
        )

    has_arviz = importlib.util.find_spec("arviz") is not None

    if not has_arviz:
        raise ImportError("arviz is not installed")

    import arviz as az

    # Prepare the data
    idx_dataset, idx_chain, idx_draw, idx_compound = 0, 1, 2, 3
    chains = samples.pip.shape[idx_chain]
    draws = samples.pip.shape[idx_draw]

    if cid_names is None:
        cid_names = list(range(samples.pip.shape[idx_compound]))

    if datasets_names is None:
        datasets_names = [f"{i}" for i in range(samples.pip.shape[idx_dataset])]

    # Define the target axis order: (chain, draw, compound, dataset) for 4D
    # (chain, draw, dataset) for 3D
    # this is needed for arviz to understand the dimensions
    order_4d = (1, 2, 3, 0)
    order_3d = (1, 2, 0)

    datadict = {
        "gamma": np.array(samples.gamma).transpose(order_4d),
        "pip": np.array(samples.pip).transpose(order_4d),
        "beta": np.array(samples.beta).transpose(order_4d),
        "weight": np.array(samples.weight).transpose(order_3d),
        "sigma": np.array(samples.sigma).transpose(order_3d),
    }

    coords = {
        "chain": np.arange(chains),
        "draw": np.arange(draws),
        "compound": cid_names,
        "dataset": datasets_names,
    }

    # Update dims to reflect the new dimension order
    dims = {
        "gamma": ["chain", "draw", "compound", "dataset"],
        "pip": ["chain", "draw", "compound", "dataset"],
        "beta": ["chain", "draw", "compound", "dataset"],
        "sigma": ["chain", "draw", "dataset"],
        "weight": ["chain", "draw", "dataset"],
    }

    return az.convert_to_inference_data(datadict, coords=coords, dims=dims)
