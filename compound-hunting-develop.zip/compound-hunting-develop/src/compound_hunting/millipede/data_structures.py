"""Data structure definitions for the Millipede MCMC implementation.

- MCMCInputs: Container for input parameters and data
- MCMCSample: Container for the state of a single MCMC sample
- MCMCResults: Container for final MCMC results and statistics
- MCMCDiagnostics: Container for MCMC convergence diagnostics
"""

from typing import NamedTuple

import jax
from jax import Array


class MCMCInputs(NamedTuple):
    """Container for MCMC input parameters with static shapes.

    Args:
        P (int): Number of features. The output `gamma` will have shape (P,).
        Pa (int): Number of assumed features.
        X (Array): Design matrix of shape (N, P + Pa).
        Z (Array): Response projections of shape (P + Pa,).
        XX (Array): Covariance matrix (X.T @ X) of shape (P + Pa, P + Pa).
        XX_diag (Array): Diagonal of XX with shape (P + Pa,).
        YY (float): Sum of squares of response.
        N_nu0 (float): Parameter equal to N + nu0.
        tau (float): Precision parameter.
        tau_intercept (float): Intercept precision parameter.
        log_h_ratio (Array): Log odds ratio; shape as specified.
        epsilon (float): Small constant for numerical stability.
        explore (float): Exploration parameter.
        xi (Array): Array for h updates; shape as required.
        comb_factor (float): Combination factor.
        key (jax.random.PRNGKey): Random key for sampling.
        max_active (int): Maximum number of active features.
    """

    P: int
    Pa: int
    X: Array
    Z: Array
    XX: Array
    XX_diag: Array
    YY: float
    N_nu0: float
    tau: float
    tau_intercept: float
    log_h_ratio: Array
    epsilon: float
    explore: float
    xi: Array
    comb_factor: float
    key: jax.random.PRNGKey
    max_active: int


class MCMCResults(NamedTuple):
    """Container for MCMC results with static shapes.

    Args:
        pip: Array, shape (P,), posterior inclusion probabilities.
        beta: Array, shape (P + Pa,), regression coefficients.
        beta_std: Array, shape (P + Pa,), standard deviation of regression coefficients.
        conditional_beta: Array, shape (P + Pa,), conditional regression coefficients.
        conditional_beta_std: Array, shape (P + Pa,), standard deviation of conditional regression coefficients.
        sigma: Array, shape (), noise standard deviation.
        sigma_std: Array, shape (), standard deviation of noise standard deviation.
        active_count_max:
            Array, shape (), max number of simultaneously active
            features encountered in the chain.
    """

    pip: Array
    beta: Array
    beta_std: Array
    conditional_beta: Array
    conditional_beta_std: Array
    sigma: Array
    sigma_std: Array
    active_count_max: Array


class MCMCSample(NamedTuple):
    """Container for MCMC state with static shapes.

    Args:
        gamma: Array, shape (P,), boolean mask.
        activeb: Array, shape (P + Pa,), boolean mask including assumed features.
        beta: Array, shape (P + Pa,), regression coefficients.
        sigma: Array, scalar noise standard deviation.
        pip: Array, shape (P,), posterior incluion probabilities.
        idx: Array, scalar indicating the selected index.
        log_h_ratio: Array, same as the input.
        weight: Array, scalar importance sampling weight.
    """

    gamma: Array
    activeb: Array
    beta: Array
    sigma: Array
    pip: Array
    idx: Array
    log_h_ratio: Array
    weight: Array


class MCMCSampleReduced(NamedTuple):
    """Container for a reduced set of MCMC samples.

    Args:
        gamma: Array, shape (n_samples, compounds), boolean mask.
        pip: Array, shape (n_samples, compounds), posterior inclusion probabilities.
        weight: Array, shape (n_samples,), importance sampling weight.
    """

    gamma: Array
    pip: Array
    weight: Array


class MCMCDiagnostics(NamedTuple):
    """Container for MCMC convergence diagnostics summary.

    Args:
        rhat: Array, shape (P,), Gelman-Rubin convergence diagnostic for coefficients.
        ess: Array, shape (P,), effective sample size for coefficients.
        within_active_limit: Bool Array, shape (), indicates whether the maximum number of
            simultaneously active features observed across all MCMC samples remained
            within the specified maximum active limit.
    """

    rhat: Array
    ess: Array
    within_active_limit: Array


class WeightedFeatureStats(NamedTuple):
    """Weighted feature statistics for reuse across modules.

    Intended as the return type for shared weighted-aggregation helpers that
    summarize per-feature quantities across samples using normalized weights.

    Shapes:
        - pip: (F,)
        - beta_mean: (F[, ...])  # trailing dims allowed (e.g., time)
        - beta_std: (F[, ...])
        - conditional_beta: (F[, ...])
        - conditional_beta_std: (F[, ...])

    Notes:
        - "F" denotes the full feature dimension after aligning assumed
          covariates; callers should ensure `gamma` already includes assumed
          features when computing these statistics.
    """

    pip: Array
    beta_mean: Array
    beta_std: Array
    conditional_beta: Array
    conditional_beta_std: Array
