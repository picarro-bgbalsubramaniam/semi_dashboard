"""Utilities for managing feature permutations in MCMC analysis.

This module provides functions to handle the reordering of features (covariates)
to deal with assumed or fixed features like an intercept.
"""

import jax
import jax.numpy as jnp
from jax import Array

from compound_hunting.millipede.data_structures import MCMCSample


def get_feature_reordering_permutations(
    original_num_cols: int, assumed_covariates_idx: Array
) -> tuple[Array, Array]:
    """Calculates permutations to move assumed covariates to the front (and back).

    Given the total number of columns and the indices of covariates that are
    assumed to be in the model (e.g., an intercept or other fixed features),
    this function computes two permutation arrays:
    1.  `permutation_to_end`: Moves the `assumed_covariates_idx` to the
        beginning of the column sequence, followed by all other (selectable)
        covariates.
    2.  `permutation_to_original`: Reverses the effect of `permutation_to_end`,
        restoring the original column order.

    This is used to reorder a feature matrix `X` and associated arrays
    (like scaling factors) so that assumed covariates can be handled separately
    or explicitly during MCMC computations, and then to revert the results to
    the original feature order.

    Args:
        original_num_cols (int):
            The total number of columns (features, including any intercept) in the
            matrix to be permuted.
        assumed_covariates_idx (Array):
            A 1D JAX array of integer indices specifying which columns are considered
            "assumed". These indices should be valid for a matrix with
            `original_num_cols` columns.

    Returns:
        tuple[Array, Array]: A tuple containing:
            - permutation_to_end (Array): A 1D JAX array of indices. Applying this
              permutation to the columns of a matrix (e.g., `X[:, permutation_to_end]`)
              will place the `assumed_covariates_idx` at the beginning.
            - permutation_to_original (Array): A 1D JAX array of indices. Applying
              this permutation to the columns of a matrix already permuted by
              `permutation_to_end` (e.g., `X_permuted[:, permutation_to_original]`)
              will restore the original column order.
    """
    all_original_indices = jnp.arange(original_num_cols)
    is_assumed_mask = jnp.isin(all_original_indices, assumed_covariates_idx)
    selectable_indices = all_original_indices[~is_assumed_mask]

    permutation_to_end = jnp.concatenate([assumed_covariates_idx, selectable_indices])

    permutation_to_original = jnp.argsort(permutation_to_end)

    return permutation_to_end, permutation_to_original


def restore_sample_feature_order(
    samples: MCMCSample, permutation_to_original: Array
) -> MCMCSample:
    """Reorders the feature-related attributes of an MCMCSample object.

    This function iterates through the attributes of an `MCMCSample` PyTree.
    For attributes that are JAX arrays and whose last dimension's size matches
    the length of `permutation_to_original`, it reorders this last dimension
    using `permutation_to_original`. This is typically used to restore the
    original feature order to MCMC sample statistics after computations
    were performed on a permuted feature set.

    Args:
        samples (MCMCSample):
            The MCMC sample object (a PyTree, e.g., a dataclass)
            containing arrays (like `beta`, `pip`, etc.) whose last dimension
            corresponds to features and needs reordering.
        permutation_to_original (Array):
            A 1D JAX array of integer indices that
            defines the permutation to apply to the last dimension of relevant
            array attributes in `samples`. This permutation should map the
            current (permuted) feature order back to the original feature order.

    Returns:
        MCMCSample: A new `MCMCSample` object where all applicable array attributes
            have their last (feature) dimension reordered according to
            `permutation_to_original`.
    """

    def _reorder_attribute(attribute: Array) -> Array:
        if attribute.shape[-1] == permutation_to_original.shape[0]:
            return attribute[..., permutation_to_original]
        else:
            return attribute

    return jax.tree.map(_reorder_attribute, samples)
