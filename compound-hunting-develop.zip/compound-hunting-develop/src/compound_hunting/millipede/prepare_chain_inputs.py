import jax
import jax.numpy as jnp
from jax import Array

from compound_hunting.millipede.data_structures import MCMCInputs


def _add_intercept(X: Array) -> Array:
    """
    Add an intercept column to the design matrix X.

    Args:
        X (Array):
            Either a 2D array of shape (N, D) or a 3D array of shape (M, N, D),
            where M is the number of spectra, N is the number of observations,
            and D is the number of features (compounds).

    Returns:
        Array:
            A new array with a column of ones prepended as the first feature column.
            For 2D input: shape (N, 1 + D)
            For 3D input: shape (M, N, 1 + D)
    """
    ones = jnp.ones_like(X[..., :1], dtype=X.dtype)
    return jnp.concatenate([ones, X], axis=-1)


def _expand_y(Y: Array) -> Array:
    """Expand 1D array to 2D by adding a leading dimension if necessary.

    This is useful for handling both single target and multiple target cases
    uniformly by batching over the first axis.

    Args:
        Y (Array):
            Inputs array of shape (N,) or (M, N), where N is the number of samples (modes)
            and M is the number of targets/spectra.

    Returns:
        Array:
            Output array of shape (1, N) if input was 1D, or unchanged input
            of shape (M, N) if already 2D.
    """
    if Y.ndim == 1:
        Y = Y[jnp.newaxis, ...]
    return Y


def _prepare_chain_inputs(
    X: Array,
    y: Array,
    S: float,
    tau: float,
    tau_intercept: float,
    nu0: float,
    lambda0: float,
    explore: float,
    seed: int,
    max_active: int,
    Pa: int,
) -> MCMCInputs:
    """
    Prepares and packages the inputs necessary for initializing the MCMC chain.

    This function takes the raw design matrix and prepares and MCMCInputs instance.
    It adds an intercept to the design matrix, computes the covariance and its diagonal,
    calculates the response projection, and packages all parameters into MCMCInputs.

    Args:
        X (Array): Design matrix of shape (N, D)
        y (Array): Response vector of shape (N,).
        S (float): Expected number of active features.
        tau (float): Precision parameter.
        tau_intercept (float): Precision parameter for the intercept.
        nu0 (float): Hyperparameter used to adjust the sum of squares of y.
        lambda0 (float): Regularization parameter used in conjunction with nu0.
        explore (float): Exploration parameter.
        seed (int): Random seed used to generate a PRNGKey.
        max_active (int): Maximum number of active features.
        Pa (int): Number of assumed covariates (intercept, or
            other covariates whose presence is forced into the model).

    Returns:
        MCMCInputs: Populated MCMCInputs instance.
    """
    N = X.shape[0]
    P = X.shape[1] - Pa

    YY = jnp.sum(jnp.square(y)) + nu0 * lambda0
    Z = jnp.einsum("np,n->p", X, y)
    h = S / P
    log_h_ratio = jnp.log(h) - jnp.log(1.0 - h)
    xi = jnp.array([0.0])
    comb_factor = 1.0
    explore = explore / P
    N_nu0 = N + nu0
    XX = X.T @ X
    XX_diag = jnp.diag(XX)
    epsilon = 1.0e3 * jnp.finfo(y.dtype).tiny
    key = jax.random.PRNGKey(seed)

    return MCMCInputs(
        P=P,
        Pa=Pa,
        X=X,
        Z=Z,
        XX=XX,
        XX_diag=XX_diag,
        YY=YY,
        N_nu0=N_nu0,
        tau=tau,
        tau_intercept=tau_intercept,
        log_h_ratio=log_h_ratio,
        epsilon=epsilon,
        explore=explore,
        xi=xi,
        comb_factor=comb_factor,
        key=key,
        max_active=max_active,
    )
