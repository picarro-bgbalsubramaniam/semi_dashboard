"""MCMC statistics processing for xarray/ArviZ datasets.

This module provides functions to compute MCMC statistics from xarray datasets,
typically created by Millipede transformer using the `get_inference_data` method
(returns ArviZ InferenceData object, akin to an Xarray Dataset).
It mirrors the functionality in mcmc_statistics.py
but operates on xarray data structures instead of JAX arrays.

Functions:
    resample_beta_posteriors: Resample variable from posterior distributions
    summarize_inference_data: Main function to compute all MCMC statistics
    _explode_chains: Concatenate MCMC chains into single draw dimension
    _get_weights: Normalize sample weights with numerical stability
    _get_pip: Compute posterior inclusion probabilities
    _get_conditional_beta: Compute conditional regression coefficients
    _get_conditional_beta_std: Compute conditional coefficient standard deviations
    _get_sigma: Compute noise standard deviation estimates
    _get_sigma_std: Compute noise standard deviation uncertainties
"""

from typing import Optional

import numpy as np
import xarray as xr
from pydantic import ConfigDict, Field, validate_call
from tqdm.auto import trange

CHAIN_DIM = "chain"
DRAW_DIM = "draw"
DATASET_DIM = "dataset"
COMPOUND_DIM = "compound"


def _explode_chains(
    ds: xr.Dataset, chain_dim: str = CHAIN_DIM, draw_dim: str = DRAW_DIM
) -> xr.Dataset:
    """Concatenate MCMC chains into a single draw dimension.

    Takes an xarray dataset with separate 'chain' and 'draw' dimensions and
    combines them into a single 'draw' dimension. This is useful for treating
    multiple chains as one long chain for downstream analysis.

    Args:
        ds (xr.Dataset): Input dataset with chain and draw dimensions.
        chain_dim (str): Name of the chain dimension in the dataset.
        draw_dim (str): Name of the draw dimension in the dataset.

    Returns:
        xr.Dataset: Dataset with chains concatenated along the draw dimension.
        The chain dimension is removed and draw indices are renumbered
        continuously.
    """
    chains = ds[chain_dim].values + 1
    draws = ds[draw_dim].values + 1
    new_draws = np.outer(chains, draws).reshape(-1)
    old_draw_dim = f"old_{draw_dim}"
    stacked_ds = ds.rename({draw_dim: old_draw_dim})
    stacked_ds = stacked_ds.stack(**{draw_dim: (old_draw_dim, chain_dim)})

    stacked_ds = stacked_ds.reset_index(draw_dim)

    stacked_ds = stacked_ds.assign_coords(**{draw_dim: new_draws})

    stacked_ds = stacked_ds.drop_vars([old_draw_dim, chain_dim])
    return stacked_ds


def _get_weights(weights: xr.DataArray, draw_dim: str = DRAW_DIM) -> xr.DataArray:
    """Normalize sample weights with numerical stability.

    Applies log-space normalization to prevent numerical underflow when
    weights have very different magnitudes.

    Args:
        weights (xr.DataArray): Raw sample weights with draw dimension.
        draw_dim (str): Name of the draw dimension in the weights array.

    Returns:
        xr.DataArray: Normalized weights that sum to 1.0 along the draw dimension.
    """
    weights_safe = np.maximum(weights, 1e-12)
    log_weights = np.log(weights_safe)
    log_weights_adjusted = log_weights - log_weights.max(dim=draw_dim)
    weights = np.exp(log_weights_adjusted)
    weights = weights / weights.sum(dim=draw_dim)
    return weights


def _get_pip(
    pip: xr.DataArray, weights: xr.DataArray, draw_dim: str = DRAW_DIM
) -> xr.DataArray:
    """Compute posterior inclusion probabilities.

    Calculates weighted posterior inclusion probabilities by averaging
    the feature inclusion indicators across all MCMC samples.

    Args:
        pip (xr.DataArray): Feature inclusion indicators with draw dimension.
        weights (xr.DataArray): Normalized sample weights with draw dimension.
        draw_dim (str): Name of the draw dimension in the arrays.

    Returns:
        xr.DataArray: Posterior inclusion probabilities, one per feature.
    """
    pip = (pip * weights).sum(dim=draw_dim)
    return pip


def _get_conditional_beta(
    beta: xr.DataArray,
    gamma: xr.DataArray,
    weights: xr.DataArray,
    draw_dim: str = DRAW_DIM,
) -> xr.DataArray:
    """Compute conditional regression coefficients.

    Calculates the mean regression coefficient for each feature, conditioned
    on that feature being included in the model (gamma=1). This gives the
    expected coefficient value when the feature is active.

    Args:
        beta (xr.DataArray): Regression coefficients with draw dimension.
        gamma (xr.DataArray): Feature inclusion indicators with draw dimension.
        weights (xr.DataArray): Normalized sample weights with draw dimension.
        draw_dim (str): Name of the draw dimension in the arrays.

    Returns:
        xr.DataArray: Conditional mean regression coefficients, one per feature.

    Note:
        Uses a minimum denominator of 1e-10 to prevent division by zero
        when a feature is never included.
    """
    gamma_weighted = gamma * weights
    beta_sum = (beta * gamma_weighted).sum(dim=draw_dim, skipna=True)
    gamma_sum = gamma_weighted.sum(dim=draw_dim, skipna=True)
    return beta_sum / np.maximum(gamma_sum, 1e-10)


def _get_conditional_beta_std(
    beta: xr.DataArray,
    gamma: xr.DataArray,
    weights: xr.DataArray,
    conditional_beta: xr.DataArray,
    draw_dim: str = DRAW_DIM,
) -> xr.DataArray:
    """Compute conditional regression coefficient standard deviations.

    Calculates the standard deviation of regression coefficients, conditioned
    on feature inclusion (gamma=1). This quantifies uncertainty in the
    coefficient estimates when features are active.

    Args:
        beta (xr.DataArray): Regression coefficients with draw dimension.
        gamma (xr.DataArray): Feature inclusion indicators with draw dimension.
        weights (xr.DataArray): Normalized sample weights with draw dimension.
        conditional_beta (xr.DataArray): Conditional mean coefficients from _get_conditional_beta.
        draw_dim (str): Name of the draw dimension in the arrays.

    Returns:
        xr.DataArray: Conditional standard deviations of regression coefficients.

    Note:
        Computed as sqrt(E[beta^2 | gamma=1] - E[beta | gamma=1]^2).
    """
    # Weighted sum of beta squared (only when gamma=1)
    beta_sq_sum = (beta**2 * gamma * weights).sum(dim=draw_dim, skipna=True)

    # Weighted sum of gamma (same as in conditional_beta calculation)
    gamma_sum = (gamma * weights).sum(dim=draw_dim, skipna=True)

    # E[beta^2 | gamma=1]
    mean_beta_sq = beta_sq_sum / np.maximum(gamma_sum, 1e-10)

    # sqrt(E[beta^2 | gamma=1] - E[beta | gamma=1]^2)
    conditional_beta_std = np.sqrt(mean_beta_sq - conditional_beta**2)

    return conditional_beta_std


def _get_sigma(
    sigma: xr.DataArray, weights: xr.DataArray, draw_dim: str = DRAW_DIM
) -> xr.DataArray:
    """Compute weighted mean noise standard deviation.

    Calculates the posterior mean of the noise standard deviation parameter
    using weighted averaging across MCMC samples.

    Args:
        sigma (xr.DataArray): Noise standard deviation samples with draw dimension.
        weights (xr.DataArray): Normalized sample weights with draw dimension.
        draw_dim (str): Name of the draw dimension in the arrays.

    Returns:
        xr.DataArray: Weighted mean noise standard deviation.
    """
    return (sigma * weights).sum(dim=draw_dim, skipna=True)


def _get_sigma_std(
    sigma: xr.DataArray,
    weights: xr.DataArray,
    sigma_mean: xr.DataArray,
    draw_dim: str = DRAW_DIM,
) -> xr.DataArray:
    """Compute noise standard deviation uncertainty.

    Calculates the standard deviation of the noise parameter estimates
    to quantify posterior uncertainty in the noise level.

    Args:
        sigma (xr.DataArray): Noise standard deviation samples with draw dimension.
        weights (xr.DataArray): Normalized sample weights with draw dimension.
        sigma_mean (xr.DataArray): Mean noise standard deviation from _get_sigma.
        draw_dim (str): Name of the draw dimension in the arrays.

    Returns:
        xr.DataArray: Standard deviation of the noise parameter estimates.

    Note:
        Computed as sqrt(E[sigma^2] - E[sigma]^2).
    """
    return np.sqrt((sigma**2 * weights).sum(dim=draw_dim, skipna=True) - sigma_mean**2)


def summarize_inference_data(
    ds: xr.Dataset, chain_dim: str = CHAIN_DIM, draw_dim: str = DRAW_DIM
) -> xr.Dataset:
    """Compute comprehensive MCMC statistics from xarray dataset.

    Main function that processes raw MCMC samples (typically from ArviZ) and
    computes all posterior statistics including posterior inclusion probabilities,
    conditional regression coefficients, and noise parameters.

    The dataset usually comes from the
    :meth:`~compound_hunting.transformers.millipede_transformer.MillipedeTransformer.get_inference_data`
    method of the MillipedeTransformer class.

    Args:
        ds (xr.Dataset): Input dataset containing MCMC samples with variables:
            - 'weight': Sample weights (chain, draw)
            - 'pip': Posterior inclusion probabilities (chain, draw, compound)
            - 'beta': Regression coefficients (chain, draw, compound)
            - 'gamma': Feature inclusion indicators (chain, draw, compound)
            - 'sigma': Noise standard deviations (chain, draw)
        chain_dim (str): Name of the chain dimension in the dataset.
        draw_dim (str): Name of the draw dimension in the dataset.

    Returns:
        xr.Dataset: Dataset containing computed statistics:
            - 'pip': Posterior inclusion probabilities (compound, dataset)
            - 'beta_mean': Conditional mean coefficients (compound, dataset)
            - 'beta_std': Conditional coefficient std devs (compound, dataset)
            - 'sigma': Mean noise standard deviation (dataset)
            - 'sigma_std': Noise std dev uncertainty (dataset)
            - 'beta_marginal': Marginal beta mean coefficients (compound, dataset)

    Note:
        The function automatically handles chain concatenation and weight
        normalization. Input chains are combined into a single long chain
        before computing statistics.
    """
    sds = _explode_chains(ds, chain_dim=chain_dim, draw_dim=draw_dim)
    weights = _get_weights(sds.weight, draw_dim=draw_dim)
    pip = _get_pip(sds.pip, weights, draw_dim=draw_dim)
    beta_mean = _get_conditional_beta(sds.beta, sds.gamma, weights, draw_dim=draw_dim)
    beta_std = _get_conditional_beta_std(
        sds.beta, sds.gamma, weights, beta_mean, draw_dim=draw_dim
    )
    sigma = _get_sigma(sds.sigma, weights, draw_dim=draw_dim)
    sigma_std = _get_sigma_std(sds.sigma, weights, sigma, draw_dim=draw_dim)

    results = xr.Dataset(
        data_vars={
            "pip": pip,
            "beta_mean": beta_mean,
            "beta_std": beta_std,
            "sigma": sigma,
            "sigma_std": sigma_std,
            "beta_marginal": pip * beta_mean,
        }
    )
    return results


@validate_call(config=ConfigDict(arbitrary_types_allowed=True))
def resample_beta_posteriors(
    posterior_data: xr.Dataset,
    posterior_variable: str = "beta",
    num_samples: int = Field(default=10_000, ge=1),
    dataset_dim: str = DATASET_DIM,
    covariate_dim: str = COMPOUND_DIM,
    sample_dims: Optional[list[str]] = None,
    output_dim: str = "sample",
) -> xr.DataArray:
    """
    Generates posterior samples of a variable by performing weighted
    resampling from MCMC samples across multiple datasets/time periods.

    This implements the Bayesian approach of resampling from each dataset's
    posterior distribution, preserving uncertainty from each individual run.
    Returns samples from all datasets separately (not time-averaged) - useful
    for downstream analysis that needs per-dataset posterior distributions.

    For example, to combine 15-minute samples into a 2-week analysis while
    maintaining the temporal structure and uncertainty from each time period.

    Args:
        posterior_data (xr.Dataset):
            An xarray Dataset containing the MCMC samples from multiple
            runs (e.g., from
            :py:meth:`~compound_hunting.transformers.millipede_transformer.MillipedeTransformer.get_inference_data`).
            It must contain the variables 'variable' and 'weight' (sample weights).
            Variable should have shape (dataset, covariate, chain, draw),
            and weight should have shape (dataset, chain, draw).
        posterior_variable (str):
            The name of the variable to resample from the posterior distribution.
            Default is "beta" (regression coefficients).
            Another option is "pip" (posterior inclusion probabilities).
        num_samples (int):
            The number of samples to generate for each dataset's posterior
            distribution. Default is 10,000.
        dataset_dim (str):
            The name of the dimension corresponding to datasets/time periods.
            Default is "dataset".
        covariate_dim (str):
            The name of the covariate dimension. Default is "compound".
        sample_dims (list[str]):
            The name of the MCMC sample dimensions (e.g., ["chain", "draw"]).
            If None, defaults to all dimensions other than dataset and covariate.
            Default is None.
        output_dim (str):
            The name for the output sample dimension. Default is "sample".

    Returns:
        xr.DataArray:
            An xarray DataArray containing the posterior samples of the variable
            for each dataset. It will have dimensions
            (dataset, sample, covariate).

    Raises:
        ValueError: If posterior_data doesn't contain required variable and 'weight' variables.

    Note:
        If you want the actual time-averaged posterior (single distribution
        across all datasets), you should average the result across the dataset
        dimension after calling this function.
    """
    if (
        posterior_variable not in posterior_data.data_vars
        or "weight" not in posterior_data.data_vars
    ):
        raise ValueError(
            f"posterior_data must contain '{posterior_variable}' and 'weight' variables"
        )

    # Determine sample dimensions if not provided
    if sample_dims is None:
        sample_dims = [
            d for d in posterior_data.dims if d not in [dataset_dim, covariate_dim]
        ]

    # Stack all sample dimensions (e.g., 'chain' and 'draw') into one dimension
    stacked_data = posterior_data.stack({output_dim: sample_dims})

    variable_values = stacked_data[posterior_variable].transpose(
        dataset_dim, covariate_dim, output_dim
    )
    raw_weights = stacked_data.weight.transpose(dataset_dim, output_dim)

    datasets = variable_values[dataset_dim].values
    covariates = variable_values[covariate_dim].values
    n_datasets = len(datasets)
    n_mcmc_samples = variable_values.sizes[output_dim]

    normalized_weights = _get_weights(raw_weights, draw_dim=output_dim)

    # Vectorized resampling: generate sample indices for all datasets at once
    # Shape: (n_datasets, num_samples)
    rng = np.random.default_rng()
    all_sample_indices = np.array(
        [
            rng.choice(
                n_mcmc_samples,
                size=num_samples,
                replace=True,
                p=normalized_weights.values[dataset_idx],
            )
            for dataset_idx in trange(n_datasets, desc="Resampling from datasets")
        ]
    )

    dataset_idx = np.arange(n_datasets)[:, None]  # Shape: (n_datasets, 1)
    resampled_variable_distribution = variable_values.values[
        dataset_idx, :, all_sample_indices
    ]

    return xr.DataArray(
        resampled_variable_distribution,
        dims=[dataset_dim, output_dim, covariate_dim],
        coords={
            dataset_dim: datasets,
            output_dim: np.arange(num_samples),
            covariate_dim: covariates,
        },
    )
