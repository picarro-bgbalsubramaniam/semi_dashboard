"""
Here we implement the centipede fitter, that is using a subset of models from a Millipede fit to
go back to raw time resolution concentrations.
"""

from functools import partial
from typing import Literal

import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd

from compound_hunting.millipede.data_structures import (
    MCMCSample,
    MCMCSampleReduced,
    WeightedFeatureStats,
)
from compound_hunting.millipede.mcmc_statistics import (
    compute_weighted_feature_stats,
    normalize_weights,
)


def _standardize_columns(
    data: jnp.ndarray,
) -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]:
    """Standardize the data by subtracting the mean and dividing by the standard deviation.

    You can re-unstandardize the data by multiplying by the standard deviation and adding the mean.

    Args:
        data (jnp.ndarray):
            2-D array of shape (mode, x), where x might be time or compound,
            depending on if we standardize model function matrix or spectra matrix.

    Returns:
        data_ret (jnp.ndarray):
            2-D array of shape (mode, x)
            with mean 0 (column) and std 1 (column)
        data_mean (jnp.ndarray):
            1-D array of shape (x,)
        data_std (jnp.ndarray):
            1-D array of shape (x,)
    """
    data_mean = data.mean(axis=0)  # (x,)
    data_centered = data - data_mean[None, :]  # (mode, x)
    data_std = data_centered.std(axis=0)  # (x,)
    data_ret = data_centered / data_std[None, :]  # (mode, x)
    return data_ret, data_mean, data_std  # (mode, x), (x,), (x,)


def sample_model_by_weight(
    samples: MCMCSample, n_models: int, key: jax.random.PRNGKey
) -> MCMCSampleReduced:
    """Sample compounds from MCMC samples for a single spectrum.

    Args:
        samples: MCMC samples with gamma shape (chains, draws, compounds),
            pip shape (chains, draws, compounds), and weight shape (chains, draws).
        n_models: Number of models to sample, where a model is picked from (chains * draws) models.
        key: JAX random key for reproducible sampling.

    Returns:
        Reduced MCMC samples with gamma shape (n_models, compounds),
        pip shape (n_models, compounds), and weight shape (n_models,).
    """
    if samples.gamma.ndim != 3:
        raise ValueError(
            f"Gamma is {samples.gamma.ndim}-dimensional, expected 3 (chains, draws, compounds). "
            f"Got {samples.gamma.shape}. Did you get your output from a Millipede fit?"
        )

    # from (chains, draws, compounds) to (chains * draws, compounds)
    gamma = samples.gamma.reshape((-1, samples.gamma.shape[-1]))

    # same dimension as gamma
    pip = samples.pip.reshape((-1, samples.pip.shape[-1]))

    # from (chains, draws) to (chains * draws)
    weight = samples.weight.reshape((-1))

    sampled_indices = jax.random.choice(
        key, len(weight), shape=(n_models,), replace=True, p=weight
    )

    resampled_samples = MCMCSampleReduced(
        gamma=gamma[sampled_indices, :],  # (samples, compounds)
        pip=pip[sampled_indices, :],  # (samples, compounds)
        weight=weight[sampled_indices],  # (samples)
    )
    return resampled_samples


def _build_active_design_matrix(
    X: jnp.ndarray, gamma_i: jnp.ndarray, max_active: int
) -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray]:
    """Process a single gamma sample to create padded design matrix.

    Args:
        X (jnp.ndarray): Design matrix (model functions) of shape (mode, compound)
        gamma_i (jnp.ndarray): Boolean array of shape (compound,) indicating active features for a single model
        max_active (int): Maximum number of active features across all models

    Returns:
        X_padded_i (jnp.ndarray): Padded design matrix of shape (mode, max_active)
        feature_indices_i (jnp.ndarray): Original feature indices of shape (max_active,) (-1 for padding)
    """
    # Create sorted indices where active features come first
    indices = jnp.argsort(~gamma_i)  # False (inactive) sorts after True (active)

    # Reorder X columns so active features are first
    X_reordered = X[:, indices]

    # Take first max_active columns
    X_padded_i = X_reordered[:, :max_active]

    # Create mask: True for positions corresponding to active features
    n_active = jnp.sum(gamma_i)
    mask_i = jnp.arange(max_active) < n_active

    # Zero out padded columns (where mask is False)
    X_padded_i = jnp.where(mask_i[None, :], X_padded_i, 0.0)

    # Get feature indices for each position (padded with -1 for inactive positions)
    feature_indices_i = jnp.where(mask_i, indices[:max_active], -1)

    return X_padded_i, feature_indices_i


@partial(jax.jit, static_argnames=("max_active"))
def _solve_active_least_squares(
    X: jnp.ndarray,
    Y: jnp.ndarray,
    gamma: jnp.ndarray,
    max_active: int,
) -> jnp.ndarray:
    """Solve linear system for a single gamma configuration.

    Args:
        X (jnp.ndarray): (mode, compound) design matrix without an intercept column
        Y (jnp.ndarray): (mode, time) response matrix
        gamma (jnp.ndarray): (compound + 1,) boolean array indicating active features,
            where the first column is the intercept.
        max_active (int): Maximum number of active features

    Returns:
        beta_ret (jnp.ndarray): (compound + 1, time) coefficient matrix (NaN for inactive features)
    """
    X_padded, feature_indices_i = _build_active_design_matrix(X, gamma, max_active)

    beta, _, _, _ = jnp.linalg.lstsq(X_padded, Y, rcond=None)

    C, T = gamma.shape[0], Y.shape[1]
    beta_scatter = jnp.zeros((C + 1, T), dtype=beta.dtype)

    scatter_indices = jnp.where(feature_indices_i >= 0, feature_indices_i, C)

    # Scatter-add the solved beta values.
    # The solved beta for padded/inactive features is 0, so they add 0 to the dummy row.
    # Active features are added to their correct original index
    beta_scatter = beta_scatter.at[scatter_indices].add(beta)

    beta_ret = jnp.where(gamma[:, None], beta_scatter[:C], jnp.nan)

    return beta_ret


def compute_time_series_betas(
    X: jnp.ndarray,
    Y: jnp.ndarray,
    gamma: jnp.ndarray,
    weights: jnp.ndarray,
    dtype: Literal["float32", "float64"] = "float64",
) -> jnp.ndarray:
    """Get betas for a given gamma configuration.

    Args:
        X (jnp.ndarray): Design matrix (model functions) of shape (mode, compound).
            It must not contain an intercept column.
        Y (jnp.ndarray): Spectra (response matrix) of shape (mode, time)
        gamma (jnp.ndarray): Boolean array of shape (n_samples, compound + 1)
            indicating active features for each model. The first column is the intercept.
        weights (jnp.ndarray): Sample weights of shape (mode,).
            If you don't want to use weights, pass `np.ones(X.shape[0])`.
            Must be positive.

    Returns:
        betas (jnp.ndarray): Coefficient matrices of shape (n_samples, compound + 1, time)

    Notes:
        The first column of gamma is the intercept, but it MUST NOT be present in X.
    """
    max_active = int(jnp.sum(gamma, axis=1).max())

    dtype = jnp.float64 if dtype == "float64" else jnp.float32

    X = jnp.array(X, dtype=dtype)
    Y = jnp.array(Y, dtype=dtype)

    X, X_mean, X_std = _standardize_columns(X)
    Y, Y_mean, Y_std = _standardize_columns(Y)

    # Add intercept to standardized data
    X_with_intercept = jnp.concatenate([jnp.ones((X.shape[0], 1)), X], axis=1)

    weights = jnp.array(weights, dtype=dtype)
    weights_sqrt = jnp.sqrt(weights)  # (mode,)

    # Apply weights: multiply each row by sqrt(weight)
    X_with_intercept = X_with_intercept * weights_sqrt[:, None]  # (mode, compound+1)
    Y = Y * weights_sqrt[:, None]  # (mode, time)

    # betas is (n_samples, compound, time)
    betas = jax.vmap(
        lambda gamma: _solve_active_least_squares(
            X_with_intercept, Y, gamma, max_active
        )
    )(gamma)

    # Scaling back concentrations to original units
    # scale is (1, compound, time)
    scale = (
        Y_std[None, None, :] / jnp.concatenate([jnp.ones((1,)), X_std])[None, :, None]
    )
    betas = betas * scale

    # Fix intercept
    feature_contribution = jnp.nansum(
        X_mean[None, :, None] * betas[:, 1:, :], axis=1, keepdims=True
    )

    betas = betas.at[:, 0:1, :].set(
        betas[:, 0:1, :] + Y_mean[None, None, :] - feature_contribution
    )

    return betas


def summarize_time_feature_stats(
    betas: jnp.ndarray,  # (N, compound, time)
    gamma: jnp.ndarray,  # (N, compound)
    pip: jnp.ndarray,  # (N, compound)
    weights: jnp.ndarray,  # (N,)
) -> WeightedFeatureStats:
    """Compute time-resolved weighted feature statistics from per-time betas.

    Applies numerically stable weight normalization, then computes weighted
    per-feature statistics at each time slice using ``compute_weighted_feature_stats``.
    This function is a thin wrapper that vmaps over the time dimension.

    Args:
        betas (jnp.ndarray): Shape ``(N, compound, time)``. Regression
            coefficients for each sample, feature, and time.
        gamma (jnp.ndarray): Shape ``(N, compound)``. Boolean active-feature
            indicators per sample. Assumed covariates should already be included
            in this dimension (i.e., consistent with ``betas``).
        pip (jnp.ndarray): Shape ``(N, compound)``. Posterior inclusion
            probabilities per sample and feature.
        weights (jnp.ndarray): Shape ``(N,)``. Importance weights for each
            sample. They will be normalized to sum to 1.

    Returns:
        WeightedFeatureStats:
            Per-feature statistics with the following shapes:
            - pip: shape (compound,) — time-invariant weighted mean PIP
            - beta_mean: shape (time, compound)
            - beta_std: shape (time, compound)
            - conditional_beta: shape (time, compound)
            - conditional_beta_std: shape (time, compound)

    Notes:
        - This function assumes 2D inputs for the helper (no extra dims beyond
          feature), and uses ``jax.vmap`` to handle the time dimension.
        - For numerical stability, weights are normalized with
          ``normalize_weights`` before aggregation.
    """
    w = normalize_weights(weights)
    compute_stats_over_time = jax.vmap(
        compute_weighted_feature_stats, in_axes=(None, 2, None, None)
    )
    stats = compute_stats_over_time(w, betas, gamma, pip)

    # Compute time-invariant PIP once (avoid repeating across time)
    pip_mean = jnp.sum(pip * w[:, None], axis=0)  # (compound,)

    return WeightedFeatureStats(
        pip=pip_mean,
        beta_mean=stats.beta_mean,
        beta_std=stats.beta_std,
        conditional_beta=stats.conditional_beta,
        conditional_beta_std=stats.conditional_beta_std,
    )


def _stats_to_compound_by_time_matrix(stats: WeightedFeatureStats) -> jnp.ndarray:
    """Returns an array of shape (compound, 3 * time) with columns grouped by time.

    The columns are ordered as:
      [conditional_beta_mean_t, conditional_beta_std_t, pip_mean] for t = 0..T-1.
    """
    cbm = stats.conditional_beta  # (time, compound)
    cbs = stats.conditional_beta_std  # (time, compound)
    pip = stats.pip  # (compound,)

    T, C = cbm.shape
    pip_b = jnp.broadcast_to(pip[None, :], (T, C))  # (time, compound)

    # (time, compound, 3) -> (compound, time, 3) -> (compound, 3*time)
    t_c_3 = jnp.stack((cbm, cbs, pip_b), axis=-1)
    c_t_3 = jnp.transpose(t_c_3, (1, 0, 2))
    return c_t_3.reshape((C, 3 * T))


def _stats_to_beta_df(
    beta_summary: WeightedFeatureStats,
    feature_names: list[str],
    time_names: list[str],
) -> pd.DataFrame:
    """Converts weighted feature stats into a time-resolved beta DataFrame.

    Args:
        beta_summary (WeightedFeatureStats): Weighted feature statistics with time dimension.
        feature_names (list[str]): Names of the features (including intercept).
        time_names (list[str]): Names of the time points.

    Returns:
        pd.DataFrame: A DataFrame with MultiIndex columns containing beta_mean, beta_std,
            and pip_mean for each time point, indexed by feature names.
    """
    temp_output = _stats_to_compound_by_time_matrix(beta_summary)

    columns = pd.MultiIndex.from_product(
        [time_names, ["beta_mean", "beta_std", "pip_mean"]]
    )
    beta_df = pd.DataFrame(temp_output, columns=columns, index=feature_names)
    return beta_df


def propagate_model_to_time_series(
    samples: MCMCSample,
    X: pd.DataFrame | np.ndarray,
    Y: pd.DataFrame,
    feature_names: list[str],
    weights: pd.Series | np.ndarray | None = None,
    n: int = 500,
    seed: int = 42,
    dtype: Literal["float32", "float64"] = "float64",
) -> pd.DataFrame:
    """Propagates a fitted Millipede model over a time series Y.

    This function takes MCMC samples from a fitted Millipede model and uses them to compute
    time-resolved beta coefficients for a new time series dataset Y. It resamples models
    by their weight, computes time-series betas, and summarizes the results.

    Args:
        samples (MCMCSample): MCMC samples from a Millipede fit. If the gamma has shape
            (n_targets, chains, draws, compounds + 1), only the first target is used.
        X (pd.DataFrame | np.ndarray):
            The design matrix used for fitting, shape (n_samples, n_features).
            It shall NOT contain an intercept column.
        Y (pd.DataFrame): Time series data with shape (n_samples, n_time_steps).
        feature_names (list[str]): Names of the features, including intercept.
        weights (pd.Series | np.ndarray | None):
            Sample weights with shape (n_samples,). If None, uniform weights are used (unweighted regression).
        n (int, optional): Number of models to sample from the posterior. Defaults to 500.
        seed (int, optional): Random seed for reproducibility. Defaults to 42.
        dtype (Literal["float32", "float64"]): Data type for computations. Defaults to "float64".

    Returns:
        pd.DataFrame: A DataFrame with time-resolved beta coefficients, their standard
            deviation, and posterior inclusion probabilities. Has a MultiIndex with
            (time_point, statistic) where statistic is one of ['beta_mean', 'beta_std', 'pip_mean'].
    """
    # Handle multi-target case by selecting the first target
    if samples.gamma.ndim == 4:  # (targets, chains, draws, compounds)
        samples_spectrum = jax.tree_util.tree_map(lambda x: x[0, ...], samples)
    else:
        samples_spectrum = samples

    dtype_internal = jnp.float64 if dtype == "float64" else jnp.float32
    dataset_names = Y.columns.tolist()

    if weights is None:
        weights_u = np.ones(X.shape[0], dtype=dtype_internal)
    else:
        weights_u = np.array(weights, dtype=dtype_internal)

    def _run_model(
        X: jnp.ndarray,
        Y: jnp.ndarray,
        samples_spectrum: MCMCSample,
        w: jnp.ndarray,
        dtype: Literal["float32", "float64"],
    ) -> MCMCSampleReduced:
        key = jax.random.PRNGKey(seed)
        resamples = sample_model_by_weight(samples_spectrum, n, key)
        betas = compute_time_series_betas(
            X, Y, resamples.gamma, weights=w, dtype=dtype
        )  # (n_samples, compound + 1, time)
        beta_summary = summarize_time_feature_stats(
            betas=betas,
            pip=resamples.pip,
            gamma=resamples.gamma,
            weights=resamples.weight,
        )
        return beta_summary

    def _compute_and_convert():
        """Helper to run model and convert to DataFrame."""
        Xu = jnp.array(X, dtype=dtype_internal)
        Yu = jnp.array(Y, dtype=dtype_internal)
        wu = jnp.array(weights_u, dtype=dtype_internal)
        beta_summary = _run_model(Xu, Yu, samples_spectrum, wu, dtype)
        return _stats_to_beta_df(beta_summary, feature_names, dataset_names)

    if dtype == "float64":
        with jax.experimental.enable_x64():
            return _compute_and_convert()
    else:
        return _compute_and_convert()
