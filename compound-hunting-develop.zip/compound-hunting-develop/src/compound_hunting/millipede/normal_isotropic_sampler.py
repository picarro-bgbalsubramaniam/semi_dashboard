from typing import Callable

import jax
import jax.numpy as jnp
from jax import Array

from compound_hunting.millipede.data_structures import MCMCInputs, MCMCSample
from compound_hunting.millipede.isotropic_sampling import (
    _compute_i_prob,
    _compute_probs,
)


def initialize_mcmc_sample(
    chain_inputs: MCMCInputs,
) -> MCMCSample:
    """
    Initialize an MCMC sample with the starting state.

    Args:
        chain_inputs (MCMCInputs):
            A named tuple containing MCMC input parameters,
            see MCMCInputs for details and shapes.

    Returns:
        MCMCSample: Initialized MCMC sample state.
    """
    gamma = jnp.zeros(chain_inputs.P, dtype=bool)

    # set assumed covariates to active
    activeb_mask = jnp.zeros(chain_inputs.Pa + chain_inputs.P, dtype=bool)
    activeb_mask = activeb_mask.at[: chain_inputs.Pa].set(True)

    assumed_mask = activeb_mask

    # Compute initial probabilities
    beta, sigma, add_prob = _compute_probs(
        gamma,
        assumed_mask,
        chain_inputs.X,
        chain_inputs.Z,
        chain_inputs.XX,
        chain_inputs.XX_diag,
        chain_inputs.YY,
        chain_inputs.N_nu0,
        chain_inputs.P,
        chain_inputs.Pa,
        chain_inputs.tau,
        chain_inputs.tau_intercept,
        chain_inputs.log_h_ratio,
        chain_inputs.epsilon,
        chain_inputs.key,
        chain_inputs.max_active,
    )

    i_prob = _compute_i_prob(
        gamma,
        add_prob,
        chain_inputs.xi,
        chain_inputs.comb_factor,
        chain_inputs.epsilon,
        chain_inputs.explore,
    )

    initial_sample = MCMCSample(
        gamma=gamma,
        activeb=activeb_mask,
        beta=beta,
        sigma=sigma,
        pip=add_prob,
        idx=jnp.array(0),  # Initial idx
        log_h_ratio=chain_inputs.log_h_ratio,
        weight=1.0 / jnp.mean(i_prob),
    )

    return initial_sample


def run_mcmc_chain_scan(
    chain_inputs: MCMCInputs, n_burnin: int, n_samples: int
) -> tuple[MCMCSample, MCMCSample]:
    """
    Run the MCMC chain using jax.lax.scan.

    Args:
        chain_inputs (MCMCInputs): MCMC inputs.
        n_burnin (int): Number of burn-in iterations.
        n_samples (int): Number of sampling iterations.

    Returns:
        Tuple[MCMCSample, MCMCSample]:
            - Final MCMC state (MCMCSample) after n_samples sampling iterations.
            - A collection of MCMCSample objects representing the samples from each iteration.
              Each sample will have the shapes as defined in the MCMCSample named tuple.
    """
    init_state = initialize_mcmc_sample(chain_inputs)

    # the chain inputs are static, so we can create the mcmc move function once
    mcmc_move_isotropic = _create_mcmc_step_fn(chain_inputs)

    def scan_body(carry, _):
        state, key = carry
        key, subkey = jax.random.split(key)

        # Get next state values from mcmc_move_isotropic
        # activeb is the assumed covariates mask, that will not change during the MCMC
        next_state = mcmc_move_isotropic(
            gamma=state.gamma,
            assumed_mask=init_state.activeb,
            log_h_ratio=state.log_h_ratio,
            prev_add_prob=state.pip,
            key=subkey,
        )

        return (next_state, key), next_state

    # First run burn-in phase without collecting samples
    _, subkey = jax.random.split(chain_inputs.key)
    carry = (init_state, subkey)
    final_burnin_carry, _ = jax.lax.scan(scan_body, carry, None, length=n_burnin)

    # Then run sampling phase and collect samples
    final_carry, samples = jax.lax.scan(
        scan_body, final_burnin_carry, None, length=n_samples
    )
    final_state, _ = final_carry

    return final_state, samples


def _mcmc_move_isotropic(
    gamma: Array,
    assumed_mask: Array,
    log_h_ratio: Array,
    prev_add_prob: Array,
    key: jax.random.PRNGKey,
    inputs: MCMCInputs,
) -> MCMCSample:
    """
    Perform one MCMC move for an isotropic prior.

    Args:
        gamma (Array): Current inclusion state; shape (P,), boolean.
        assumed_mask (Array): Boolean mask for assumed features; shape (P + Pa,).
        log_h_ratio (Array): Log odds ratio. (1,) or (P,)
        prev_add_prob (Array): Previous add_prob. (P,)
        key (jax.random.PRNGKey): Random key for sampling.
        inputs (MCMCInputs): Container holding static MCMC parameters and data.

    Returns:
        MCMCSample: Updated MCMC state
    """
    # Compute probabilities and related values
    key_compute_probs, key_categorical = jax.random.split(key, 2)

    i_prob = _compute_i_prob(
        gamma,
        prev_add_prob,
        inputs.xi,
        inputs.comb_factor,
        inputs.epsilon,
        inputs.explore,
    )
    i_prob_safe = jnp.maximum(i_prob, 1e-12)
    log_i_prob = jnp.log(i_prob_safe)

    # Sample from categorical distribution
    idx = jax.random.categorical(key_categorical, logits=log_i_prob, shape=()) - 1

    # Update gamma
    gamma = gamma.at[idx].set(~gamma[idx])

    # activeb mask
    activeb = assumed_mask
    activeb = activeb.at[inputs.Pa :].set(gamma)

    # compute beta, sigma, add_prob
    beta, sigma, add_prob = _compute_probs(
        gamma,
        assumed_mask,
        inputs.X,
        inputs.Z,
        inputs.XX,
        inputs.XX_diag,
        inputs.YY,
        inputs.N_nu0,
        inputs.P,
        inputs.Pa,
        inputs.tau,
        inputs.tau_intercept,
        log_h_ratio,
        inputs.epsilon,
        key_compute_probs,
        inputs.max_active,
    )

    # compute i_prob
    i_prob_post = _compute_i_prob(
        gamma,
        add_prob,
        inputs.xi,
        inputs.comb_factor,
        inputs.epsilon,
        inputs.explore,
    )

    mean_i_prob = jnp.maximum(jnp.mean(i_prob_post), 1e-12)
    weight = 1.0 / mean_i_prob

    # Create results
    new_sample = MCMCSample(
        gamma=gamma,
        activeb=activeb,
        beta=beta,
        sigma=sigma,
        pip=add_prob,
        idx=idx,
        log_h_ratio=log_h_ratio,
        weight=weight,
    )

    return new_sample


def _create_mcmc_step_fn(inputs: MCMCInputs) -> Callable:
    """
    Create an MCMC step function with static inputs bound from MCMCInputs.

    Args:
        inputs (MCMCInputs): Container holding static MCMC parameters and data.
            See MCMCInputs for detailed descriptions and shapes.

    Returns:
        Callable:
            A function similar to _mcmc_move_isotropic, but with static inputs bound.
    """

    def step_fn(
        gamma: Array,
        assumed_mask: Array,
        log_h_ratio: Array,
        prev_add_prob: Array,
        key: jax.random.PRNGKey,
    ):
        return _mcmc_move_isotropic(
            gamma=gamma,
            assumed_mask=assumed_mask,
            log_h_ratio=log_h_ratio,
            prev_add_prob=prev_add_prob,
            key=key,
            inputs=inputs,
        )

    return step_fn
