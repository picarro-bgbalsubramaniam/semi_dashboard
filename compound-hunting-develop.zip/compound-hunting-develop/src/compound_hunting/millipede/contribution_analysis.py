"""Contribution analysis for Millipede model results.

This module provides functions for analyzing feature contributions from Millipede
model results, including area-under-curve calculations, contribution computations,
and detection of unknown/negative contributions.
"""

import numpy as np
import pandas as pd
from jax.typing import ArrayLike
from pydantic import ConfigDict, validate_call

# Excluse these CIDs (Big 3) from PFI calculations
PFI_EXCLUDE_CIDS = [280, 297, 962]


@validate_call(config=ConfigDict(arbitrary_types_allowed=True), validate_return=True)
def compute_areas(
    X: pd.DataFrame | np.ndarray,
    Y: pd.DataFrame | pd.Series | np.ndarray,
    frequencies: np.ndarray,
    add_intercept: bool = False,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute areas under curves using trapezoidal integration.

    Calculates the area under the curve for both features (X) and targets (Y)
    using trapezoidal integration over the frequency/index dimension.

    Args:
        X (pd.DataFrame | np.ndarray):
            Feature matrix with shape (n_samples, n_features).
        Y (pd.DataFrame | pd.Series | np.ndarray):
            Target values with shape (n_samples,) or (n_samples, n_targets).
        frequencies (np.ndarray):
            Array of frequency/index values for integration, shape (n_samples,).
        add_intercept (bool, optional):
            If True, adds intercept column to X before computing areas. Defaults to False.

    Returns:
        tuple[np.ndarray, np.ndarray]:
            - area_x: Areas for features, shape (n_features, n_targets) or (n_features+1, n_targets) if add_intercept=True
            - area_y: Areas for targets, shape (n_targets,)
    """
    if len(frequencies) != X.shape[0] or len(frequencies) != Y.shape[0]:
        raise ValueError(
            "X, Y, and frequencies must have the same number of samples (lengths must match)"
        )

    # Extract numpy values if pandas structures
    Xvals = X.values if hasattr(X, "values") else X
    yvals = Y.values if hasattr(Y, "values") else Y

    # Add intercept if requested to the design matrix
    if add_intercept:
        Xvals = np.hstack([np.ones((X.shape[0], 1)), Xvals])

    # Compute areas using trapezoidal integration over frequency
    area_x = np.trapezoid(x=frequencies, y=Xvals, axis=0)[:, np.newaxis]
    area_y = np.trapezoid(x=frequencies, y=yvals, axis=0)

    # Broadcast area_x to match dimensions of area_y
    n_features = area_x.shape[0]
    n_targets = area_y.shape[0] if area_y.ndim == 1 else 1
    if area_y.ndim == 0:
        n_targets = 1
        area_y = np.array([area_y])

    area_x = np.broadcast_to(area_x, (n_features, n_targets))

    return area_x, area_y


@validate_call(config=ConfigDict(arbitrary_types_allowed=True), validate_return=True)
def compute_contributions(
    beta: ArrayLike,
    area_x: pd.Series,
    feature_names: np.ndarray,
    dataset_names: list,
) -> pd.DataFrame:
    """Compute feature contributions from regression coefficients and areas.

    Multiplies beta coefficients by the area under the curve for each feature
    to get the contribution of each feature to the target.

    Args:
        beta (np.ndarray):
            Regression coefficients with shape (n_features,) or (n_datasets, n_features).
        area_x (pd.Series):
            Areas under the curve for each feature, indexed by feature names.
        feature_names (np.ndarray):
            Names of features corresponding to beta rows.
        dataset_names (list):
            Names of target datasets corresponding to beta columns.

    Returns:
        pd.DataFrame:
            Contributions matrix with shape (n_features, n_datasets),
            indexed by feature names and with dataset names as columns.
    """
    beta_df = pd.DataFrame(
        np.array(beta).T,
        index=feature_names,
        columns=dataset_names,
    )
    contributions = beta_df.multiply(area_x, axis=0)
    return contributions


@validate_call(config=ConfigDict(arbitrary_types_allowed=True), validate_return=True)
def spectral_contributions_breakdown(
    contributions: pd.DataFrame,
    pfi: pd.Series,
    offset_name: int | str,
    exclude_cids: list[int] | None = None,
) -> pd.DataFrame:
    """Aggregate signed feature contributions for each dataset.

    Args:
        contributions (pd.DataFrame): DataFrame with shape (n_features, n_datasets)
            where columns correspond to datasets and rows to feature
            contributions. Row index 0 must contain the offset (baseline)
            contribution for every dataset.
        pfi (pd.Series): Partial fit integral for the spectrum of each dataset, as
            provided to the `MillipedeTransformer` constructor. Shape (n_datasets,).
        offset_name (int | str): Name of the offset feature.
        exclude_cids (list[int]):
            List of CIDs to exclude from PFI calculations. If not provided,
            defaults to the `PFI_EXCLUDE_CIDS` (typically, the CIDs of the Big 3).

    Returns:
        pd.DataFrame: DataFrame indexed by dataset name containing:
            - `raw_pfi`: Raw partial fit integral for the spectrum of each dataset.
            - `model_pfi`: Sum of all feature contributions as provided by the `contributions` DataFrame,
            after excluding the contributions of the CIDs in `exclude_cids`.
            - `adjusted_pfi`: Partial fit integral for the spectrum of each dataset,
              after excluding the contributions of the CIDs in `exclude_cids`, based on
              their contributions in the `contributions` DataFrame.
            - `negative_pfi`: Sum of contributions < 0, after excluding the contributions
              of the CIDs in `exclude_cids`.
            - `positive_pfi`: Sum of contributions ≥ 0, after excluding the contributions
              of the CIDs in `exclude_cids`.
            - `offset_pfi`: Contribution attributed to the offset feature
              (row index 0).
    """
    if exclude_cids is None:
        exclude_cids = PFI_EXCLUDE_CIDS

    present_forbidden_cids = list(set(exclude_cids) & set(contributions.index))
    forbidden_contribs = contributions.loc[present_forbidden_cids]
    forbidden_pfi = forbidden_contribs.sum(axis=0)
    clean_pfi = pfi - forbidden_pfi
    clean_contribs = contributions.drop(present_forbidden_cids, axis=0)

    def _parse_contributions(contribs: pd.Series) -> pd.Series:
        return pd.Series(
            [
                contribs.sum(),  # spectrum as modeled by the model
                contribs[contribs < 0].sum(),  # negative contributions
                contribs[contribs >= 0].sum(),  # positive contributions
            ],
            index=["model_pfi", "negative_pfi", "positive_pfi"],
        )

    ret = clean_contribs.apply(_parse_contributions).T
    ret["raw_pfi"] = pfi  # spectrum as provided by the data
    ret["adjusted_pfi"] = clean_pfi  # raw minus forbidden contributions
    ret["offset_pfi"] = contributions.loc[
        offset_name
    ].values.tolist()  # offset contribution
    return ret


@validate_call(config=ConfigDict(arbitrary_types_allowed=True), validate_return=True)
def calculate_pfi_ratio(
    total_pfi: pd.Series,
    negative_pfi: pd.Series,
    positive_pfi: pd.Series,
) -> pd.Series:
    """Calculate the PFI ratio metric for each dataset.

    The ratio is the absolute value of the negative PFI divided by the total PFI
    if the total PFI is positive, or the positive PFI divided by the absolute value
    of the total PFI if the total PFI is negative.

    Args:
        total_pfi: pd.Series with shape (n_datasets,).
        negative_pfi: pd.Series with shape (n_datasets,).
        positive_pfi: pd.Series with shape (n_datasets,).

    Returns:
        pd.Series: Series indexed by dataset name containing the PFI ratio.
    """
    abs_neg = negative_pfi.abs()
    abs_tot = total_pfi.abs()
    return (abs_neg / total_pfi).where(total_pfi > 0, positive_pfi / abs_tot)
