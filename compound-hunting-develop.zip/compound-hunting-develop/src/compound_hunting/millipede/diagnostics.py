"""Diagnostic functions for MCMC sampling. JAX adaptations from ArviZ.
For more details see: https://python.arviz.org/en/stable/
"""

import jax
import jax.numpy as jnp
from jax import Array


def rhat(data: Array) -> Array:
    """Compute rank-normalized R-hat diagnostic for convergence of MCMC chains.

    The rank normalized R-hat diagnostic tests for lack of convergence by comparing
    the variance between multiple chains to the variance within each chain. If
    convergence has been achieved, the between-chain and within-chain variances
    should be identical. This implementation follows the approach recommended by
    Vehtari et al. (2021).

    Args:
        data: Array with shape (chains, draws) or (chains, draws, cids) containing
            MCMC samples.

    Returns:
        Array with shape (cids,). The potential scale reduction factor,
        R-hat. If input is 2D, a new dimension cid of size 1 is
        created, and the output shape is (1,).

        Interpretation guidelines:
        - R-hat < 1.01: Strong evidence of convergence
        - 1.01 < R-hat < 1.05: Acceptable convergence for most applications
        - 1.05 < R-hat < 1.10: Questionable convergence, may need longer chains
        - R-hat > 1.10: Poor convergence, results likely unreliable

        When R-hat is substantially above 1.0, it indicates that chains are exploring
        different regions of the parameter space and have not yet converged to the
        same stationary distribution. This suggests that more iterations are needed
        or that the sampler is having difficulty exploring the posterior effectively.

    References:
        Vehtari et al. (2021). Rank-normalization, folding, and localization:
        An improved R-hat for assessing convergence of MCMC.
        Bayesian analysis, 16(2):667-718.
    """
    if data.ndim == 2:
        data = data[..., jnp.newaxis]

    tol = 10.0 * jnp.finfo(data.dtype).eps
    const_mask = jnp.ptp(data, axis=(0, 1)) <= tol
    rh = jax.vmap(_rhat_rank, in_axes=2, out_axes=0)(data)
    return jnp.where(const_mask, 1.0, rh)


def _rhat_rank(data: Array) -> Array:
    """Compute the rank normalized rhat for 2d array.

    Computation follows https://arxiv.org/abs/1903.08008

    Args:
        data: Array with shape (chains, draws) containing MCMC samples.

    Returns:
        Array with shape (). The rank-normalized R-hat value.
    """
    # Split chains and compute z-scaled values
    split_data = _split_chains(data)
    z_scaled = _z_scale(split_data)
    rhat_bulk = _rhat(z_scaled)

    # Compute folded z-scaled values for tail convergence
    median = jnp.median(split_data)
    split_data_folded = jnp.abs(split_data - median)
    z_scaled_folded = _z_scale(split_data_folded)
    rhat_tail = _rhat(z_scaled_folded)

    # Return the maximum of bulk and tail R-hat
    return jnp.maximum(rhat_bulk, rhat_tail)


def _split_chains(data: Array) -> Array:
    """Split and stack chains.

    Args:
        data: Array with shape (chains, draws) containing MCMC samples.

    Returns:
        Array with shape (2*chains, draws//2) containing the split chains.
    """
    n_chain, n_draw = data.shape
    half = n_draw // 2
    first_half = data[:, :half]
    second_half = data[:, -half:]
    return jnp.vstack([first_half, second_half])


def _z_scale(data: Array) -> Array:
    """Calculate z-scale transformation of ranks.

    Args:
        data: Array containing MCMC samples.

    Returns:
        Array with same shape as input containing z-scaled values.
    """
    # Flatten array for ranking
    original_shape = data.shape
    flat_data = data.reshape(-1)

    # Use JAX's rankdata function
    ranks = jax.scipy.stats.rankdata(flat_data, method="average")

    # Backtransform ranks
    n = flat_data.size
    c = 3 / 8  # Blom's constant
    transformed_ranks = (ranks - c) / (n - 2 * c + 1)

    # Convert to normal distribution
    z = jax.scipy.stats.norm.ppf(transformed_ranks)

    # Reshape back to original shape
    return z.reshape(original_shape)


def _rhat(data: Array) -> Array:
    """Compute the rhat for a 2d array.

    Args:
        data: Array with shape (chains, draws) containing MCMC samples.

    Returns:
        Array with shape (). The R-hat value.
    """
    n_chain, n_samples = data.shape

    # Calculate chain mean
    chain_mean = jnp.mean(data, axis=1)

    # Calculate chain variance
    chain_var = jnp.var(data, axis=1, ddof=1)

    # Calculate within/between variances
    between_chain_variance = n_samples * jnp.var(chain_mean, ddof=1)
    within_chain_variance = jnp.mean(chain_var)

    # Robust guard for near-constant series
    eps = jnp.finfo(data.dtype).tiny
    safe_within = jnp.maximum(within_chain_variance, eps)

    # Estimate of marginal posterior variance
    rhat_value = jnp.sqrt(
        (between_chain_variance / safe_within + n_samples - 1) / n_samples
    )
    return rhat_value


def ess(data: Array, relative: bool = False) -> Array:
    """Compute the effective sample size (ESS) for MCMC samples.

    The effective sample size measures how many independent samples the MCMC chains
    are equivalent to, accounting for autocorrelation. This implementation uses the
    "bulk" method recommended by Vehtari et al. (2021), which is more robust than
    traditional ESS calculations.

    Args:
        data (Array):
            Array with shape (chains, draws) or (chains, draws, *sample_shape)
            containing MCMC samples.
        relative (bool):
            If True, returns the relative ESS (ESS / total samples).
            Defaults to False.

    Returns:
        Array with shape (cids,). The effective sample size. If input is 2D, a new
        dimension cid of size 1 is created, and the output shape is (1,). Values
        close to the total number of samples indicate efficient sampling, while
        smaller values suggest high autocorrelation (less efficient sampling).
        Typically, values below 100 would indicate unreliability of the posterior
        estimates. Above 100 is acceptable, above 400 is recommended, above 1000 is
        excellent.

    References:
        Vehtari et al. (2021). Rank-normalization, folding, and localization:
        An improved R-hat for assessing convergence of MCMC.
        Bayesian analysis, 16(2):667-718.
    """
    if data.ndim == 2:
        data = data[..., jnp.newaxis]

    def _ess_fn(data: Array) -> Array:
        return _ess_bulk(data, relative)

    return jax.vmap(_ess_fn, in_axes=2)(data)


def _ess_bulk(data: Array, relative: bool = False) -> Array:
    """Compute the effective sample size for the bulk of the distribution.

    Args:
        data: Array with shape (chains, draws) containing MCMC samples.
        relative: If True, returns the relative ESS (ESS / total samples).
            Defaults to False.

    Returns:
        Array with shape (). The effective sample size.
    """
    # Split chains and z-scale
    split_data = _split_chains(data)
    z_scaled = _z_scale(split_data)

    # Compute ESS on z-scaled values
    return _ess(z_scaled, relative)


def _ess(ary: Array, relative: bool = False) -> Array:
    """Compute the effective sample size for a 2D array.

    Args:
        ary: Array with shape (chains, draws) containing MCMC samples.
        relative: If True, returns the relative ESS (ESS / total samples).
            Defaults to False.

    Returns:
        Array with shape (). The effective sample size.
    """
    n_chain, n_draw = ary.shape

    # Check for constant values
    max_val = jnp.max(ary)
    min_val = jnp.min(ary)
    is_constant = (max_val - min_val) < jnp.finfo(jnp.float32).resolution

    # If constant, return total sample size or 1.0 if relative
    total_samples = n_chain * n_draw

    # Compute autocovariance
    acov = _autocov(ary)

    # Calculate mean variance
    chain_mean = jnp.mean(ary, axis=1)
    mean_var = jnp.mean(acov[:, 0]) * n_draw / (n_draw - 1.0)
    var_plus = mean_var * (n_draw - 1.0) / n_draw

    # Add between-chain variance if more than one chain
    var_plus = jnp.where(n_chain > 1, var_plus + jnp.var(chain_mean, ddof=1), var_plus)

    # Initialize rho_hat_t
    rho_hat_t = jnp.zeros(n_draw)

    rho_hat_even = 1.0
    rho_hat_odd = 1.0 - (mean_var - jnp.mean(acov[:, 1])) / var_plus

    rho_hat_t = rho_hat_t.at[0].set(rho_hat_even)
    rho_hat_t = rho_hat_t.at[1].set(rho_hat_odd)

    # Pre-compute all possible rho values
    t_values = jnp.arange(1, (n_draw - 2) // 2 * 2, 2)

    def compute_rho(t):
        rho_even = 1.0 - (mean_var - jnp.mean(acov[:, t + 1])) / var_plus
        rho_odd = 1.0 - (mean_var - jnp.mean(acov[:, t + 2])) / var_plus
        return rho_even, rho_odd, (rho_even + rho_odd) >= 0

    # Compute all rho values and their positivity
    rho_evens, rho_odds, is_positives = jax.vmap(compute_rho)(t_values)

    # Find the last positive index using cumulative product
    # Once we hit a non-positive value, all subsequent products will be 0
    cum_is_positive = jnp.cumprod(is_positives)
    max_positive_idx = jnp.sum(cum_is_positive)

    # Use scan to fill the rho_hat_t array up to max_positive_idx
    def fill_rho_hat_t(carry, idx_data):
        rho_hat_t, _ = carry
        idx, (rho_even, rho_odd, is_positive) = idx_data

        # Only update if within the max_positive_idx
        t = t_values[idx]
        rho_hat_t = jnp.where(
            idx < max_positive_idx,
            rho_hat_t.at[t + 1].set(rho_even).at[t + 2].set(rho_odd),
            rho_hat_t,
        )

        return (rho_hat_t, None), None

    # Create indices for the scan
    indices = jnp.arange(len(t_values))
    data = (indices, (rho_evens, rho_odds, is_positives))

    # Run the scan to fill rho_hat_t
    (rho_hat_t, _), _ = jax.lax.scan(fill_rho_hat_t, (rho_hat_t, None), data)

    # Calculate max_t based on max_positive_idx
    max_t = jnp.where(max_positive_idx > 0, t_values[max_positive_idx - 1] + 2, 1)

    # Improve estimation for the last even value if positive
    rho_hat_even_last = 1.0 - (mean_var - jnp.mean(acov[:, max_t + 1])) / var_plus
    rho_hat_t = jnp.where(
        rho_hat_even_last > 0, rho_hat_t.at[max_t + 1].set(rho_hat_even_last), rho_hat_t
    )

    # Apply monotone sequence constraint using a fixed-size scan
    # We'll create a mask to only apply adjustments up to max_t - 2
    t_values_monotone = jnp.arange(1, n_draw - 2, 2)

    def monotone_sequence_step(carry, t_idx):
        rho_hat_t = carry
        t = t_values_monotone[t_idx]

        # Check if we should process this t (t <= max_t - 2)
        should_process = t <= max_t - 2

        # Check if sequence needs adjustment
        needs_adjustment = (rho_hat_t[t + 1] + rho_hat_t[t + 2]) > (
            rho_hat_t[t - 1] + rho_hat_t[t]
        )

        # Calculate adjusted value
        adjusted_value = (rho_hat_t[t - 1] + rho_hat_t[t]) / 2.0

        # Update values if needed and if we should process this t
        rho_hat_t = jnp.where(
            should_process & needs_adjustment,
            rho_hat_t.at[t + 1].set(adjusted_value).at[t + 2].set(adjusted_value),
            rho_hat_t,
        )

        return rho_hat_t, None

    # Run the monotone sequence adjustment for all possible t values
    # but only apply changes for t <= max_t - 2
    rho_hat_t, _ = jax.lax.scan(
        monotone_sequence_step, rho_hat_t, jnp.arange(len(t_values_monotone))
    )

    # Calculate tau_hat using a safe slicing approach
    # Create a mask for the values we want to sum
    mask_first_part = jnp.arange(n_draw) <= max_t
    mask_second_part = jnp.arange(n_draw) == max_t + 1

    # Apply the mask and sum
    first_sum = jnp.sum(rho_hat_t * mask_first_part)
    second_sum = jnp.sum(rho_hat_t * mask_second_part)

    tau_sum = 2.0 * first_sum - 1.0 + second_sum
    min_tau = 1.0 / jnp.log10(total_samples)
    tau_hat = jnp.maximum(tau_sum, min_tau)

    # Calculate ESS
    # In ArviZ, the formula is (n_chain * n_draw) / tau_hat
    ess_value = total_samples / tau_hat

    # Apply relative scaling only if requested
    ess_value = jnp.where(relative, ess_value / total_samples, ess_value)

    # Return ESS or total samples if constant
    return jnp.where(is_constant, jnp.where(relative, 1.0, total_samples), ess_value)


def _autocov(ary: Array) -> Array:
    """Compute autocovariance estimates for every lag for the input array.

    Args:
        ary: Array containing MCMC samples with shape (chains, draws).

    Returns:
        Array containing autocovariance estimates with shape (chains, draws).
    """
    n_chain, n_draw = ary.shape

    # Center the data
    centered_data = ary - jnp.mean(ary, axis=1, keepdims=True)

    # Compute autocovariance for each lag using FFT
    def autocov_chain(chain_data):
        # Pad the data for FFT
        padded_data = jnp.pad(chain_data, (0, n_draw))

        # Compute FFT
        fft_data = jax.numpy.fft.rfft(padded_data)

        # Compute power spectrum
        power = jnp.abs(fft_data) ** 2

        # Compute inverse FFT of power spectrum
        acov_full = jax.numpy.fft.irfft(power, n=padded_data.shape[0])

        # Normalize by n_draw
        acov_full = acov_full[:n_draw] / n_draw

        return acov_full

    # Apply to each chain
    return jax.vmap(autocov_chain)(centered_data)
