"""Module for performing Bayesian variable selection using an isotropic prior.

This module provides computational routines for MCMC sampling with an isotropic prior,
including functions for computing importance sampling probabilities, expanding subset
values into the full feature space, calibrating the noise scale parameter (sigma),
determining regression coefficients (beta), and estimating inclusion probabilities.

These routines are designed for high-dimensional regression models and are informed by
the methodology described in "Bayesian Variable Selection in a Million Dimensions".

All input arrays and parameters are expected to have explicitly defined shapes as detailed
in the individual function docstrings.

The function _compute_probs represents the core MCMC update step for the isotropic prior:
it is long and ugly, I know, but all variables are interconnected and
I did not see a way to split it up without making it even more confusing.
Feel free to suggest improvements and clean-ups!
"""

import jax
import jax.numpy as jnp
from jax import Array

from compound_hunting.millipede.isotropic_loo import (
    compute_log_det_complete,
    compute_loo_rss_complete,
)


def _compute_i_prob(
    gamma: Array,  # (P,)
    add_prob: Array,  # (P,)
    xi: Array,  # (1,)
    comb_factor: float,
    epsilon: float,
    explore: float,
) -> Array:
    """Compute importance sampling probabilities for the isotropic prior MCMC update.

    This function computes a weighted probability for each feature by combining
    the inclusion probability (gamma) with an additive probability (add_prob) and an
    exploration term. It then concatenates a scaled baseline update (from xi) with the
    computed probabilities for each feature.

    Args:
        gamma (Array): A 1-D array of shape (P,) representing the current feature
            inclusion indicators (e.g. binary or probability values).
        add_prob (Array): A 1-D array of shape (P,) indicating the additional
            probabilities for including each feature.
        xi (Array): A 1-D array of shape (1,) holding a baseline probability update.
        comb_factor (float): A scaling (combination) factor to adjust the baseline update.
        epsilon (float): A small constant for numerical stability (to avoid division by zero).
        explore (float): An exploration parameter to adjust the probability balance.

    Returns:
        Array: A 1-D array of shape (P + 1,) containing the resultant importance
            sampling probabilities; the first element corresponds to the scaled xi value.
    """
    gamma_float = gamma.astype(add_prob.dtype)
    prob_gamma_i = gamma_float * add_prob + (1.0 - gamma_float) * (1.0 - add_prob)
    _i_prob = 0.5 * (add_prob + explore) / (prob_gamma_i + epsilon)
    i_prob = jnp.concatenate([xi * comb_factor, _i_prob])  # (P + 1,)
    return i_prob


def _expand_subset(subset_values: Array, subset_perm: Array, activeb: Array) -> Array:
    """Expand a subset of computed values into the full feature space.

    This function takes a compact computation (performed on a subset of indices) and
    "expands" it into an array matching the full dimension (P + Pa) of the model, using
    the provided permutation mapping and an active mask.

    Args:
        subset_values (Array): A 1-D array of shape (k,) representing values computed
            on the active subset (typically k = max_active).
        subset_perm (Array): A 1-D integer array of shape (k,) containing index mappings
            that specify how to place subset_values into the full array.
        activeb (Array): A 1-D boolean array of shape (P + Pa,) indicating which indices
            are active (and thus should receive values from subset_values).

    Returns:
        Array: A 1-D array of shape (P + Pa,) where the positions indicated by subset_perm
            (and for which activeb is True) are set to the corresponding values in subset_values;
            all other positions are zero.
    """
    result = jnp.zeros(activeb.shape[0], dtype=subset_values.dtype)
    result = result.at[subset_perm].set(subset_values)
    return jnp.where(activeb, result, 0.0)


def _compute_sigma(
    YY: float,
    Zt_active_sq: float,
    N_nu0: float,
    key: jax.random.PRNGKey,
) -> float:
    """Compute the noise scale parameter (sigma) for the MCMC sampling.

    This function follows the methodology described in [2208.01180v2] for computing
    the sigma parameter based on the overall response sum-of-squares (YY) and the sum-of-squares
    of the active projection (Zt_active_sq). A gamma sample is drawn using the updated degrees
    of freedom N_nu0, and sigma is set as the inverse square root of this sample.

    Args:
        YY (float): A scalar representing the total sum of squares of the response.
        Zt_active_sq (float): A scalar representing the sum of squares of the active projected response.
        N_nu0 (float): A scalar representing (N + nu0), where N is the number of observations and nu0 is a hyperparameter.
        key (jax.random.PRNGKey): A JAX random key for random number generation.

    Returns:
        tuple:
            sigma (float): The computed noise scale parameter (scalar).
    """
    sigma_beta = 0.5 * (YY - Zt_active_sq)
    gamma_sample = jax.random.gamma(key, 0.5 * N_nu0) / sigma_beta
    sigma = 1.0 / jnp.sqrt(gamma_sample)
    return sigma


def _compute_beta(
    L_subset: Array,  # (max_active, max_active)
    Zt_active_subset: Array,  # (max_active,)
    activeb: Array,  # (P + Pa,)
    subset_perm: Array,  # (max_active,)
    sigma: float,
    key: jax.random.PRNGKey,
) -> Array:
    """Compute the regression coefficients (beta) during MCMC sampling.

    The beta values are computed using both the deterministic part (via solving a triangular linear
    system from the Cholesky factor L_subset) and a random part (using standard normal noise scaled by sigma).
    The computed subset vectors are then expanded into the full feature array.

    Args:
        L_subset (Array): A 2-D array of shape (max_active, max_active) representing the (stabilized)
            Cholesky decomposition of a subset covariance matrix.
        Zt_active_subset (Array): A 1-D array of shape (max_active,) containing L_inv @ Z_active_subset.
        activeb (Array): A 1-D boolean array of shape (P + Pa,) marking active features.
        subset_perm (Array): A 1-D integer array of shape (max_active,) that provides the index mapping
            for the active subset.
        sigma (float): A scalar noise scale parameter.
        key (jax.random.PRNGKey): A JAX random key for generating randomness.

    Returns:
        tuple:
            beta (Array): A 1-D array of shape (P + Pa,) containing the computed regression coefficients.
                Coefficients for inactive features are set to zero.
    """
    # Compute deterministic part (posterior mean)
    # Solve L.T @ beta_mean = L_inv @ Z   (using Zt = L_inv @ Z)
    beta_active_subset = jax.scipy.linalg.solve_triangular(
        L_subset.T,
        Zt_active_subset,
        lower=False,
    )  # (max_active,)
    beta_active = _expand_subset(beta_active_subset, subset_perm, activeb)  # (P + Pa,)

    # Compute random part (sample from posterior covariance)
    epsilon_noise = jax.random.normal(
        key, shape=(activeb.shape[0],), dtype=L_subset.dtype
    )  # (P + Pa,)
    epsilon_noise = jnp.where(activeb, epsilon_noise, 0.0)
    epsilon_subset = epsilon_noise[subset_perm]  # (max_active,)

    # Solve L.T @ beta_noise_scaled = epsilon_std_normal
    beta_noise_subset = jax.scipy.linalg.solve_triangular(
        L_subset.T,
        epsilon_subset,
        lower=False,
    )  # (max_active,)
    beta_noise = _expand_subset(beta_noise_subset, subset_perm, activeb)  # (P + Pa,)

    # Combine deterministic and random components (beta = mean + noise_sample)
    beta = jnp.where(
        activeb,
        beta_active + sigma * beta_noise,
        jnp.nan,
    )  # (P + Pa,)

    return beta


def _compute_probs(
    gamma: Array,  # (P,)
    assumed_mask: Array,  # (P + Pa,)
    X: Array,  # (N, P + Pa)
    Z: Array,  # (P + Pa,)
    XX: Array,  # (P + Pa, P + Pa)
    XX_diag: Array,  # (P + Pa,)
    YY: float,
    N_nu0: float,
    P: int,
    Pa: int,
    tau: float,
    tau_intercept: float,
    log_h_ratio: Array,  # (1,) or (P,)
    epsilon: float,
    key: jax.random.PRNGKey,
    max_active: int = 30,
) -> tuple[Array, float, Array]:
    """Compute probabilities and related values for MCMC sampling under an isotropic prior.

    This function implements most of the key MCMC update steps for a Bayesian variable selection model
    with an isotropic prior, as described in [2208.01180v2]. It calculates the updated regression
    coefficients (beta), noise scale (sigma), and inclusion probabilities (add_prob) for the primary features.
    Computations include cholesky decompositions, leave-one-out (LOO) statistics, and adjustments based on
    the design matrix and covariance structure.

    Args:
        gamma (Array): A 1-D array of shape (P,) with binary indicators for the primary features.
        assumed_mask (Array): A 1-D boolean array of shape (P + Pa,) indicating assumed features.
        X (Array): A 2-D array of shape (N, P + Pa) representing the design matrix.
        Z (Array): A 1-D array of shape (P + Pa,) containing the response projections.
        XX (Array): A 2-D array of shape (P + Pa, P + Pa) representing the full predictor covariance matrix.
        XX_diag (Array): A 1-D array of shape (P + Pa,) with the diagonal of XX.
        YY (float): A scalar representing the sum-of-squares of the response.
        N_nu0 (float): A scalar equal to (N + nu0), with nu0 a hyperparameter.
        P (int): The number of primary features.
        Pa (int): The number of assumed features.
        tau (float): The precision parameter for the isotropic prior for features.
        tau_intercept (float): The precision parameter for the intercept.
        log_h_ratio (Array): A 1-D array of shape (1,) or (P,) giving the log-odds ratio h/(1-h).
        epsilon (float): A small positive constant for numerical stability.
        key (jax.random.PRNGKey): A JAX random key used for random number generation.
        max_active (int, optional): Maximum number of features used for subset computations
            (default is 30).

    Returns:
        tuple:
            beta (Array): A 1-D array of shape (P + Pa,) containing the updated regression coefficients,
                with zeros in non-active positions.
            sigma (float): A scalar representing the computed noise scale parameter.
            add_prob (Array): A 1-D array of shape (P,) representing the computed inclusion probabilities
                (after applying a sigmoid transformation to the log odds) for the primary features.
    """
    # Get active/inactive arrays
    active_mask = jnp.where(gamma, True, False)  # (P,)
    inactive_mask = jnp.where(gamma, False, True)  # (P,)

    # Create activeb mask
    activeb = jnp.zeros(Pa + P, dtype=bool)  # (Pa +,)
    activeb = activeb.at[Pa:].set(active_mask)  # (P + Pa,)
    activeb = jnp.logical_or(activeb, assumed_mask)  # (P + Pa,)

    # Compute permutations once
    perm = jnp.argsort(~activeb)  # (Pa + P,)
    inv_perm = jnp.argsort(perm)  # (Pa + P,)
    subset_perm = perm[:max_active]  # (max_active,)

    # Pre-compute arange_active
    arange_active = jnp.arange(max_active)  # (max_active,)

    # Pre-compute commonly used values
    XX_subset = XX[subset_perm][:, subset_perm]  # (max_active, max_active)
    activeb_subset = activeb[subset_perm]  # (max_active,)
    Z_subset = Z[subset_perm]  # (max_active,)
    X_subset = X.T[subset_perm]  # (max_active, N)

    X_k = jnp.where(inactive_mask[None, :], X[:, Pa:], 0.0)  # (N, P)
    Z_k = jnp.where(inactive_mask, Z[Pa:], 0.0)  # (P,)
    XX_k = jnp.where(inactive_mask, XX_diag[Pa:], 0.0)  # (P,)

    # Pad the covariance matrix with prior precision
    active_mask_2d = activeb[:, None] & activeb[None, :]  # (P + Pa, P + Pa)
    XX_active = jnp.where(active_mask_2d, XX, 0.0)  # (P + Pa, P + Pa)
    eye = jnp.eye(XX.shape[0], dtype=XX.dtype)  # (P + Pa, P + Pa)
    XX_active = XX_active + eye * jnp.where(activeb, tau, 0.0)  # (P + Pa, P + Pa)
    XX_active = XX_active.at[0, 0].add(tau_intercept - tau)  # (P + Pa, P + Pa)

    XX_subset = XX_active[subset_perm][:, subset_perm]
    jitter = jnp.maximum(epsilon, 1e-8 * jnp.mean(jnp.diag(XX_subset)))

    # Use subset_perm for Cholesky computations
    L_subset = jnp.linalg.cholesky(
        XX_subset + jitter * jnp.eye(subset_perm.shape[0])
    )  # (max_active, max_active)
    L_subset_stable = (
        L_subset + jnp.eye(L_subset.shape[0]) * epsilon
    )  # (max_active, max_active)

    Z_active_subset = jnp.where(activeb_subset, Z_subset, 0.0)  # (max_active,)

    Zt_active_subset = jax.scipy.linalg.solve_triangular(
        L_subset_stable,
        Z_active_subset,
        lower=True,
    )  # (max_active,)
    Zt_active = _expand_subset(Zt_active_subset, subset_perm, activeb)  # (P + Pa,)
    Zt_active = Zt_active.at[0].add(tau_intercept - tau)  # (P + Pa,)

    # Get active X values for subset
    X_active_subset = jnp.where(
        activeb_subset[:, None], X_subset, 0.0
    )  # (max_active, N)

    Xt_active_subset = jax.scipy.linalg.solve_triangular(
        L_subset_stable,
        X_active_subset,
        lower=True,
    )  # (max_active, N)

    Xt_active = jnp.zeros_like(X.T)  # (N, P + Pa)
    Xt_active = Xt_active.at[subset_perm].set(Xt_active_subset)  # (N, P + Pa)
    Xt_active = Xt_active.at[0].add(tau_intercept - tau)  # (N, P + Pa)
    Xt_active = Xt_active.T  # (P + Pa, N)

    XtZt_active = jnp.einsum("np,p->n", Xt_active, Zt_active)  # (N,)

    # Compute Wald statistics for inactive features
    mask_ordered = activeb[perm, None] & ~activeb[None, perm]  # (P + Pa, P + Pa)
    padded_XX_ordered = jnp.where(mask_ordered, XX[perm][:, perm], 0.0)[
        :max_active
    ]  # (max_active, P + Pa)
    normsq_ordered_new = jax.scipy.linalg.solve_triangular(
        L_subset_stable, padded_XX_ordered, lower=True
    )  # (max_active, P + Pa)
    normsq_new = jnp.zeros(XX.shape)  # (P + Pa, P + Pa)
    normsq_new = normsq_new.at[:max_active].set(
        normsq_ordered_new
    )  # (max_active, P + Pa)
    normsq_new = normsq_new[inv_perm][:, inv_perm]  # (P + Pa, P + Pa)
    error_new = jnp.nansum(normsq_new[:, Pa:] ** 2, axis=0)  # (P,)

    G_k_inv = XX_k + tau - error_new  # (P,)
    G_k_inv = jnp.maximum(G_k_inv, jnp.maximum(epsilon, 1e-12))
    log_det_inactive = -0.5 * jnp.log(G_k_inv) + 0.5 * jnp.log(tau)  # (P,)

    W_k_sq = (jnp.einsum("np,n->p", X_k, XtZt_active) - Z_k) ** 2 / (
        G_k_inv + epsilon
    )  # (P,)
    Zt_active_sq = jnp.sum(jnp.where(activeb, Zt_active, 0.0) ** 2)  # Scalar

    key_sigma, key_beta = jax.random.split(key)
    # Compute sigma using the residual sums of squares
    sigma = _compute_sigma(
        YY,
        Zt_active_sq,
        N_nu0,
        key_sigma,
    )

    # Compute beta coefficients via MCMC sampling
    beta = _compute_beta(
        L_subset_stable,
        Zt_active_subset,
        activeb,
        subset_perm,
        sigma,
        key_beta,
    )

    # Compute LOO leave-one-out statistics for active features
    slice_results = jax.vmap(compute_loo_rss_complete, in_axes=(None, None, None, 0))(
        XX_subset,
        Z_subset,
        activeb_subset.at[:Pa].set(False),  # do not remove assumed covariates
        arange_active,
    )  # (max_active,)
    result = _expand_subset(slice_results, subset_perm, activeb)  # (P + Pa,)
    Zt_active_loo_sq = result[Pa:]  # (P,)

    # Compute log determinants for LOO
    slice_results = jax.vmap(compute_log_det_complete, in_axes=(None, None, None, 0))(
        XX_subset,
        activeb_subset.at[:Pa].set(False),  # do not remove assumed covariates
        tau,
        arange_active,
    )  # (max_active,)
    result = _expand_subset(slice_results, subset_perm, activeb)  # (P + Pa,)
    log_det_active = result[Pa:]  # (P,)

    epsilon_safe = jnp.maximum(epsilon, 1e-12)

    # Compute final log odds and inclusion probabilities
    ratio = W_k_sq / (YY - Zt_active_sq)
    ratio = jnp.clip(ratio, 0.0, 1.0 - epsilon_safe)
    log_S_ratio = -jnp.log1p(-ratio)

    log_odds_inactive = log_h_ratio + log_det_inactive + 0.5 * N_nu0 * log_S_ratio

    diff1 = YY - Zt_active_loo_sq
    diff1 = jnp.maximum(diff1, epsilon_safe)
    diff2 = YY - Zt_active_sq
    diff2 = jnp.maximum(diff2, epsilon_safe)

    log_S_ratio = jnp.log(diff1) - jnp.log(diff2)
    log_odds_active = log_h_ratio + log_det_active + 0.5 * N_nu0 * log_S_ratio

    log_odds = jnp.where(
        inactive_mask,
        log_odds_inactive,
        jnp.where(active_mask, log_odds_active, -jnp.inf),
    )  # (P,)

    add_prob = jax.nn.sigmoid(log_odds)  # (P,)
    return beta, sigma, add_prob
