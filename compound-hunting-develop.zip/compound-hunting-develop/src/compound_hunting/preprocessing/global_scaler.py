import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.utils.validation import check_is_fitted


class GlobalScaler(BaseEstimator, TransformerMixin):
    """
    A transformer that scales data globally,
    by subtracting the mean and dividing
    by the standard deviation of the entire
    input array/DataFrame.

    If with_mean is False (no centering),
    the global mean is set to 0.
    If with_std is False (no scaling),
    the global standard deviation is set to 1.

    Attributes:
        global_mean_ (float):
            The global mean of the input data.
        global_std_ (float):
            The global standard deviation of the input data.
    """

    def __init__(self, with_mean: bool = True, with_std: bool = True):
        self.with_mean = with_mean
        self.with_std = with_std

    def fit(self, X, y=None):
        if isinstance(X, np.ndarray):
            X_flattened = X.flatten()
        else:
            # Pandas series / dataframe
            X_flattened = X.values.flatten()

        self.global_mean_ = np.mean(X_flattened) if self.with_mean else 0
        self.global_std_ = np.std(X_flattened) if self.with_std else 1
        return self

    def transform(self, X, y=None):
        check_is_fitted(self, ["global_mean_", "global_std_"])
        return (X - self.global_mean_) / self.global_std_

    def inverse_transform(self, X, y=None):
        check_is_fitted(self, ["global_mean_", "global_std_"])
        return X * self.global_std_ + self.global_mean_
