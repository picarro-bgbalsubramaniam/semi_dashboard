import math
import warnings

import pandas as pd
from numpy.typing import ArrayLike
from pydantic import Field, validate_call
import numpy as np

from compound_hunting.logger import get_logger

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def get_nan_rows_mask(
    data: ArrayLike,
    nan_threshold: float = Field(ge=0, lt=1, default=0.1),
) -> ArrayLike:
    """
    Returns a boolean mask with length equal to the
    number of rows in the input array.
    The mask is True for rows with less than ``nan_threshold``
    NaNs (keep) and False for rows with more NaNs (discard).

    Parameters:
        data (ArrayLike):
            Target array.
        nan_threshold (float):
            Maximum allowed ratio of NaNs in the array.
            Defaults to 0.1 (10%).
            Must be 0 <= nan_threshold < 1.

    Returns:
        np.ndarray:
            Boolean mask 1d array with length equal to the
            number of rows in the input array.
    """
    data = data.copy()

    is_2d = data.ndim == 2

    if isinstance(data, (pd.DataFrame, pd.Series)):
        data = data.values

    if not is_2d:
        data = data.reshape(-1, 1)

    total_columns_count = data.shape[1]
    nans_by_row = np.isnan(data).sum(axis=1)
    nans_percent = nans_by_row / total_columns_count
    row_keep_mask = nans_percent <= nan_threshold

    if any(~row_keep_mask):
        LOGGER.info(
            f"Found {sum(~row_keep_mask)} rows with more than "
            f"{nan_threshold:.1%} NaNs. These rows will be removed."
        )

    if all(~row_keep_mask):
        raise ValueError(
            "All rows contain NaNs. "
            "No data available to process "
            "after the NaNs filter."
        )

    return row_keep_mask


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def impute_nans_by_row(data: ArrayLike) -> ArrayLike:
    """
    Imputes NaN values in the data array
    using the mean of each row.

    If the array is 1D, it is returned as is.

    Parameters:
        data (ArrayLike):
            Data array with potential NaN values.

    Returns:
        np.ndarray: Data array with NaN values imputed.

    """
    if data.ndim == 1:
        LOGGER.debug("Data is 1D, returning as is, no NaNs to impute")
        return data

    yc = data.copy() if not isinstance(data, (pd.DataFrame, pd.Series)) else data.values

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        y_means = np.nanmean(yc, axis=1)

    idxs = np.where(np.isnan(yc))
    yc[idxs] = np.take(y_means, idxs[0])

    if isinstance(data, (pd.DataFrame, pd.Series)):
        dc = data.copy()
        dc.iloc[:] = yc
        return dc
    else:
        return yc


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def apply_row_filter(
    *data: ArrayLike,
    keep_rows_mask: ArrayLike,
) -> tuple[ArrayLike, ...]:
    """
    Applies the ``row_keep_mask`` to filter rows from the given data arrays.

    Parameters:
        *data (ArrayLike): Variable number of arrays to filter.
        keep_rows_mask (ArrayLike): Boolean mask indicating which rows to keep.

    Returns:
        Tuple[np.ndarray, ...]: Tuple of filtered arrays

    Raises:
        ValueError: If the arrays do not share the same number of rows.
    """
    num_rows = {data_array.shape[0] for data_array in data}
    if len(num_rows) > 1:
        raise ValueError(
            f"All matrices must have the same number of rows, found {num_rows}."
        )

    return tuple(
        data_array.iloc[keep_rows_mask]
        if isinstance(data_array, (pd.DataFrame, pd.Series))
        else data_array[keep_rows_mask]
        for data_array in data
    )
