import jax.numpy as jnp
from jax import Array
from sklearn.base import BaseEstimator


def get_scale_factors(
    scaler: BaseEstimator, expected_size: int, attr_name: str = "scale_"
) -> Array:
    """Get the scale factors from the scaler.

    If the scaler is not fitted, the default scale is a vector of ones.
    If the scaler has no attribute with the given name, the default scale is a vector of ones.
    If the scaler has a length less than expected_size, it is padded with ones (no scaling).

    Args:
        scaler (BaseEstimator): The scaler to get the scale factors from.
        expected_size (int):
            The expected size of the scale factors.
        attr_name (str, optional):
            The attribute name to get the scale factors from.
            Defaults to "scale_".

    Returns:
        Array: Scale factors as a JAX array with length equal to expected_size.
    """
    default_scale = jnp.ones(expected_size)
    scale = getattr(scaler, attr_name, default_scale)
    if scale.shape[0] < expected_size:
        scale = jnp.append(jnp.ones(expected_size - scale.shape[0]), scale)
    return scale
