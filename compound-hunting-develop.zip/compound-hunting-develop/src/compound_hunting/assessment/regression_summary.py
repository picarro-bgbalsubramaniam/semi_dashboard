"""
Provides a summary of regression coefficients and scores.
"""

from typing import Literal, Tuple, Union

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler

from compound_hunting.assessment.metrics import (
    adjusted_r2_metric,
    aic_metric,
    bic_metric,
    f_pvalue_metric,
    f_statistics_metric,
    log_likelihood_metric,
    r2_metric,
    spectrum_metric,
    dcorr_pvalue_metric,
)
from compound_hunting.preprocessing.global_scaler import GlobalScaler
from sklearn.dummy import DummyRegressor


def regression_summary(
    X: pd.DataFrame,
    Y: Union[pd.DataFrame, pd.Series],
    multioutput_coefs: Literal["raw_values", "uniform_average", "median"] = "median",
    multioutput_scores: Literal["raw_values", "uniform_average", "median"] = "median",
    positive: bool = False,
    nus: pd.Series | None = None,
) -> Tuple[Union[pd.DataFrame, pd.Series], Union[pd.DataFrame, pd.Series]]:
    """
    Provides a summary of regression coefficients and scores.

    The coefficients are calculated using linear least squares regression
    on the original X, Y data (unscaled), therefore they are express in the
    same units as X, typically ppb.

    The scores are calculated using linear least squares regression on the
    scaled X, Y data. This means that we can
    compare the fit performance on datasets that have different original scales.
    This is particularly important for mse, rmse, aic, bic.

    .. code-block:: python

        from spectral_toolkit.compound_search.metrics.regression_summary import regression_summary

        from sklearn.datasets import make_regression

        X, y = make_regression(
            n_samples=100, n_features=10, n_informative=5, random_state=0
        )

        coefs, scores = regression_summary(X, y)


    Args:
        X (pd.DataFrame):
            A pandas DataFrame representing the model functions.
        Y (Union[pd.DataFrame, pd.Series]):
            A pandas DataFrame or Series representing the spectra (or spectrum).
        multioutput_coefs (Literal["raw_values", "uniform_average", "median"], optional):
            Method to aggregate coefficients if Y is multi-output. Defaults to "median".
        multioutput_scores (Literal["raw_values", "uniform_average", "median"], optional):
            Method to aggregate scores if Y is multi-output. Defaults to "median".
        positive (bool):
            Indicates whether regression coefficients are positive or not.
        nus (pd.Series):
            Optional pandas Series representing the wavenumber axis for
            more accurate evaluation of some metrics.
            Default is None (assume no wavenumbers available).

    Returns:
        Tuple[Union[pd.DataFrame, pd.Series], Union[pd.DataFrame, pd.Series]]:
            A tuple containing the regression coefficients and scores.

    Raises:
        ValueError: If X and Y have different numbers of rows.
        NotImplementedError: If an unknown aggregation method is provided.
    """
    if isinstance(X, pd.Series):
        X = X.to_frame()

    if X.shape[0] != Y.shape[0]:
        raise ValueError(
            f"X and Y must have the same number of rows. "
            f"X has {X.shape[0]} rows, Y has {Y.shape[0]} rows."
        )

    coefs = _regression_coefs(X, Y, positive=positive)
    scores = _regression_scores(X, Y, positive=positive, nus=nus)

    if Y.ndim == 1:
        return coefs, scores

    # aggregation logic
    def _aggregate_data(data, method):
        if method == "uniform_average":
            return data.mean(axis=0)
        elif method == "median":
            return data.median(axis=0)
        elif method == "raw_values":
            return data
        else:
            raise NotImplementedError(f"Unknown multioutput value: {method}")

    coefs = _aggregate_data(coefs, multioutput_coefs)
    scores = _aggregate_data(scores, multioutput_scores)

    return coefs, scores


def _regression_coefs(
    X: pd.DataFrame,
    Y: Union[pd.DataFrame, pd.Series],
    positive: bool = False,
) -> Union[pd.DataFrame, pd.Series]:
    """
    Calculate the linear least squares regression coefficients given X and Y.

    The output is a pandas DataFrame if Y is a DataFrame (multitask),
    otherwise (single task) it is a Series.

    Args:
        X (pd.DataFrame):
            A pandas DataFrame representing the model functions.
        Y (Union[pd.DataFrame, pd.Series]):
            A pandas DataFrame or Series representing the spectra (or spectrum).

    Returns:
        Union[pd.DataFrame, pd.Series]:
            Concentrations values.
            Offset is included as the last element, with label 0.
    """
    if X.shape[1] == 0:
        coefs = np.empty(0) if Y.ndim == 1 else np.empty((Y.shape[1], 0))
        offset = DummyRegressor(strategy="mean").fit(X, Y).constant_.T
    else:
        lr = LinearRegression(fit_intercept=True, positive=positive).fit(X, Y)
        coefs = lr.coef_
        offset = lr.intercept_

    if coefs.ndim == 1:
        coefficients = pd.Series(data=coefs, index=X.columns)
        coefficients.loc[0] = offset
    else:
        coefficients = pd.DataFrame(data=coefs, index=Y.columns, columns=X.columns)
        coefficients.loc[:, 0] = offset
    return coefficients


def _regression_scores(
    X: pd.DataFrame,
    Y: Union[pd.DataFrame, pd.Series],
    positive: bool = False,
    nus: pd.Series | None = None,
) -> Union[pd.DataFrame, pd.Series]:
    """
    Calculate regression scores, such as:
        - mse (mean squared error)
        - rmse (root mean squared error)
        - nmse (mean squared error on normalized spectra)
        - nrmse (root mean squared error on normalized spectra)
        - log-likelihood
        - R2 (coefficient of determination)
        - adjusted R2 (adjusted coefficient of determination)
        - AIC (Akaike information criterion)
        - BIC (Bayesian information criterion)
        - F-statistic
        - F-pvalue (p-value of the F-statistic)
        - dcorr statistic
        - dcorr-pvalue (p-value of the dcorr statistic)

    The output is a pandas DataFrame if Y is a DataFrame (multitask),
    otherwise (single task) it is a Series.

    Args:
        X (pd.DataFrame):
            A pandas DataFrame representing the model functions.
        Y (Union[pd.DataFrame, pd.Series]):
            A pandas DataFrame or Series representing the spectra (or spectrum).
        positive (bool):
            Indicates whether regression coefficients are positive or not.
        nus (pd.Series):
            Optional pandas Series representing the wavenumber axis for
            more accurate evaluation of some metrics.
            Default is None (assume no wavenumbers available).

    Returns:
        Union[pd.DataFrame, pd.Series]:
            Metric values
    """
    if X.shape[1] == 0:
        Xs = X.copy(deep=True)
        lr = DummyRegressor(strategy="mean")
    else:
        Xs = StandardScaler().fit_transform(X)
        lr = LinearRegression(positive=positive)

    Ys = GlobalScaler().fit_transform(Y)

    Xs = np.array(Xs)
    Ys = np.array(Ys)
    y_pred = lr.fit(Xs, Ys).predict(Xs)

    p = Xs.shape[1]  # Number of predictors
    residuals = Ys - y_pred
    llf = log_likelihood_metric(Xs, Ys, y_pred)
    r2 = r2_metric(Xs, Ys, y_pred)
    adj_r2 = adjusted_r2_metric(Xs, Ys, y_pred)
    ss = -spectrum_metric(Xs, Ys, y_pred)
    fscore = f_statistics_metric(Xs, Ys, y_pred)
    fpvalue = f_pvalue_metric(Xs, Ys, y_pred)
    aic = aic_metric(Xs, Ys, y_pred)
    bic = bic_metric(Xs, Ys, y_pred)
    nmse = np.mean(residuals**2, axis=0)
    nrmse = np.sqrt(nmse)
    dcorr, dcorrpvalue = dcorr_pvalue_metric(Xs, Ys, y_pred, nus)

    y_raw_pred = lr.fit(Xs, Y).predict(Xs)
    residuals_raw = Y - y_raw_pred
    mse = np.mean(residuals_raw**2, axis=0)
    rmse = np.sqrt(mse)

    results = {
        "rmse": rmse,
        "mse": mse,
        "nrmse": nrmse,
        "nmse": nmse,
        "log_likelihood": llf,
        "r2": r2,
        "adj_r2": adj_r2,
        "spectrum_score": ss,
        "F-statistic": fscore,
        "F-pvalue": fpvalue,
        "AIC": aic,
        "BIC": bic,
        "n_coefs": p,
        "dcorr": dcorr,
        "dcorr-pvalue": dcorrpvalue,
    }

    if y_pred.ndim == 1:
        scores = pd.Series(data=results).astype(float)
    else:
        scores = pd.DataFrame(
            data=results,
            index=Y.columns,
        ).astype(float)
    return scores
