"""
Metrics that generate one score per feature,
unlike metrics that generate one score per model.
"""

import numpy as np
import pandas as pd

from compound_hunting.logger import get_logger

LOGGER = get_logger(__name__)


def get_variance_inflation_factor(
    scaled_model_functions: pd.DataFrame, cids: list[int]
) -> pd.Series:
    """
    Calculates the Variance Inflation Factor (VIF) for a set of CIDs and
    the given model functions.

    Args:
        scaled_model_functions (pd.DataFrame):
            The scaled and demeaned model functions.
            Dimensions: (mode, cids)
        cids (List[int]):
            The CIDs to calculate the VIF for.

    Returns:
        pd.Series: The VIF scores for each CID.
    """
    if not set(cids).issubset(scaled_model_functions.columns):
        raise ValueError("One or more CIDs not in provided model functions.")

    if scaled_model_functions.empty:
        raise ValueError("No scaled model functions provided.")

    # make sure model functions are demeaned
    scaled_model_functions -= scaled_model_functions.mean(axis=0)
    X = scaled_model_functions.loc[:, cids]

    try:
        X_corr_inv = np.linalg.inv(X.T @ X)
    except np.linalg.LinAlgError as e:
        raise ValueError(
            "Could not calculate VIF " "(singular matrix? Duplicated features?)"
        ) from e

    vifs = []
    for k in range(X.shape[1]):
        X_k = X.iloc[:, k].values.reshape(-1, 1)
        vif_k = X_corr_inv[k, k] / np.linalg.inv(X_k.T @ X_k)[0, 0]
        vifs.append(vif_k)

    vifs = pd.Series(vifs, index=cids, name="VIF")
    vifs = vifs.sort_values(ascending=False)
    return vifs
