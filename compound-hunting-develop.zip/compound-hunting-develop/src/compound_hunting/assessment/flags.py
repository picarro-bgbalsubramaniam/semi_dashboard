"""
Flags for determining when there is a possible issue with data quality, unknown unknowns, Spectro-Temporal distortion etc...

The flags are computed with jax so they can be run on gpu.
"""

import jax
import jax.numpy as jnp
from jax.typing import ArrayLike


DEVICE_CPU = jax.devices("cpu")[0]
ESS_LIMIT = 1345.1761
ESS_QUANTILE = 0.965


def ess_check(
    ess: ArrayLike, ess_limit: float = ESS_LIMIT, quantile: float = ESS_QUANTILE
) -> ArrayLike:
    """
    Determine if the chosen quantile of the input ess values is smaller than ess_limit.
    Returns a boolean array. If an entry is TRUE, that spectrum is flagged as bad.
    The parameters ess_limit and quantile are chosen based on experiments with simulated data.
    See https://picarro.atlassian.net/wiki/x/GADF2w for details.
    In particular, quantile was determined to be the most predictive quantile for identifying unknown unknowns.
    And the ess_limit was chosen so that the false positive rate is 1/1000 (on simulated data).

    Args:
        ess:
            Array, shape (cid, dataset)
        ess_limit (float):
            Threshold for ess quantile to determine flag.
        quantile (float):
            quantile between zero and one.

    Returns:
        Array: boolean array of flags of shape (n,).
    """
    with jax.default_device(DEVICE_CPU):
        ess = jnp.asarray(ess)
        flag = jnp.nanquantile(ess, quantile, axis=0) < ess_limit
    return flag
