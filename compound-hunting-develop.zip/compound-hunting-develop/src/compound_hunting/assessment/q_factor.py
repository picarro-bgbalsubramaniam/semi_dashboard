from itertools import combinations
from typing import Tuple, Optional

import numpy as np
import pandas as pd
from pydantic import validate_call, Field

from compound_hunting.assessment.utils import evaluate_substitution
from compound_hunting.substitution.evaluate_alternative_solutions import _filter_available_substitutions
from compound_hunting.substitution.substitution_data.get_substitutions import get_one_to_two
from compound_hunting.substitution.utils import distance_based_alternatives


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def q_metric(
    X: pd.DataFrame,
    Y: pd.DataFrame | pd.Series,
    selected_cids: list[str | int],
    one_to_two_substitutions: dict[str | int, pd.Series] = Field(default_factory=get_one_to_two),
    substitutions_pairs_limit: Optional[int] = None,
    euclidean_distance_alternatives_limit: int = 25,
) -> Tuple[pd.Series, pd.Series]:
    """
    Calculate the Q factor for a set of selected CIDs
    using both their one-to-two substitutions and similar
    CIDs combinations.

    Similar CIDs are computed on the fly using the Euclidean
    distance. This is necessary to provide a Q factor also for
    compounds for which there is no similarity in the
    one_to_two_substitutions dictionary.

    Args:
        X (pd.DataFrame):
            Complete model functions matrix (modes x cids).
        Y (pd.DataFrame | pd.Series):
            Spectra matrix (modes x times) or array (modes x 1).
        selected_cids (list[str | int]):
            The CIDs in the original model.
            They need to be in the columns of X.
        one_to_two_substitutions (dict[str | int, pd.Series]):
            The one-to-two substitutions for each CID.
            The keys are the CIDs and the values are the possible
            substitutions.
            Values are provided as a pandas Series where the index
            is the possible substitution CID(s) in a tuple, and
            values are a metric for the substitution
            (the higher, the better). This substitution map is
            generally created using the `.find_substitutes` function
            with ``depth = 2``.
        substitutions_pairs_limit (int):
            The maximum number of pairs of substitutions
            from one_to_two_substitutions to consider
            for each CID. Defaults to None (test all provided).
        euclidean_distance_alternatives_limit (int):
            The maximum number of similar CIDs to consider
            as alternatives for each CID.
            Defaults to 25.

    Returns:
        Tuple[pd.Series, pd.Series]:
            A tuple containing two pandas Series:
            - The Q factors for each CID.
            - The best substitution for each CID.
    """
    # normalized matrix for euclidean distance calculation
    all_cids = X.columns.to_list()
    Xs = (X - X.mean()) / X.std()

    initial_rmse = evaluate_substitution(
        X=X,
        Y=Y,
        selected_cids=selected_cids,
        target_cid=0,
        replacement_cids=[],
    )

    q_factors = {}
    best_subs = {}

    for cid in selected_cids:
        available_subs = one_to_two_substitutions.get(cid, pd.Series())
        available_subs = _filter_available_substitutions(available_subs=available_subs, all_cids=all_cids)

        similar_cids = distance_based_alternatives(Xs, cid, euclidean_distance_alternatives_limit)
        available_pairs = (
            list(combinations(similar_cids, 2)) + available_subs.index.to_list()[:substitutions_pairs_limit]
        )

        best_rmse = np.inf
        best_substitution = None

        for i, cid_subs in enumerate(available_pairs):
            if set(cid_subs) & set(selected_cids):
                continue

            rmse = evaluate_substitution(
                X=X,
                Y=Y,
                selected_cids=selected_cids,
                target_cid=cid,
                replacement_cids=list(cid_subs),
            )

            if rmse < best_rmse:
                best_rmse = rmse
                best_substitution = cid_subs

        q_factors[cid] = best_rmse / initial_rmse if best_rmse < np.inf else np.nan
        best_subs[cid] = best_substitution

    return pd.Series(q_factors), pd.Series(best_subs)
