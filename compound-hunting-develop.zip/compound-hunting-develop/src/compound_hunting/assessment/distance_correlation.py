"""
Helper functions for calculating the distance correlation test statistic in metrics.py
The functions are computed with jax so they can be run on gpu.
"""

import jax.numpy as jnp
from jax.typing import ArrayLike
from pydantic import validate_call


def _cdist(x: ArrayLike, y: ArrayLike) -> ArrayLike:
    """
    jax implementation of scipy.spatial.distance.cdist for the Euclidean metric

    Args:
        x (ArrayLike):
            Array of shape m_x by n.
        y (ArrayLike):
            Array of shape m_y by n.

    Returns:
       ArrayLike: An m_x by m_y distance matrix

    """

    return jnp.sqrt(jnp.sum((x[:, None] - y[None, :]) ** 2, -1))


def _center_distmat(distx: ArrayLike, bias: bool = False) -> ArrayLike:
    """
    Center distance matrices (distance matrices are coming from _cdist).
    This is a jax implementation of the center_distmat calculation implemented in numpy at https://github.com/neurodata/hyppo.
    See documentation for class Dcorr(IndependenceTest) at https://github.com/neurodata/hyppo for details on the centering process.
    Args:
        distx (ArrayLike): n by n distance matrix.

    Returns:
       ArrayLike: Centered n by n distance matrix.

    """
    # get matrix size
    n = distx.shape[0]

    if bias:
        exp_distx = (
            jnp.reshape(jnp.repeat(jnp.sum(distx, axis=0) / n, n), shape=(-1, n)).T
            + jnp.reshape(jnp.repeat(jnp.sum(distx, axis=1) / n, n), shape=(-1, n))
            - (jnp.sum(distx) / (n * n))
        )
    else:
        exp_distx = (
            jnp.reshape(
                jnp.repeat((jnp.sum(distx, axis=0) / (n - 2)), n), shape=(-1, n)
            ).T
            + jnp.reshape(
                jnp.repeat((jnp.sum(distx, axis=1) / (n - 2)), n), shape=(-1, n)
            )
            - jnp.sum(distx) / ((n - 1) * (n - 2))
        )
    cent_distx = distx - exp_distx
    if not bias:
        diag_elements = jnp.diag_indices_from(cent_distx)
        cent_distx = cent_distx.at[diag_elements].set(0)

    return cent_distx


def _dcorr(x: ArrayLike, y: ArrayLike, bias: bool = False) -> ArrayLike:
    """
    Calculate the distance correlation of the two vectors x, y.
    There is a biased test statistic as well as an unbiased version.
    This is a jax implementation of the Dcorr calculation implemented in numpy at https://github.com/neurodata/hyppo.
    See documentation for class Dcorr(IndependenceTest) at https://github.com/neurodata/hyppo for details on the calculation.

    Args:
        x (ArrayLike):
            array of shape (n,1) or (n,)
        y (ArrayLike):
            array of shape (n,1) or (n,)
        bias (bool):
            whether to calculate the biased or unbiased test statistic. default is unbiased.

    Returns:
        float: distace correlation.

    References:
        Székely, G. J., Rizzo, M. L., & Bakirov, N. K. (2007).
        Measuring and testing dependence by correlation of distances.
        The annals of statistics, 35(6), 2769-2794.

    """

    # Extract number of samples
    n = x.shape[0]

    # Calculate pairwise Euclidean distances matrices
    distx = _cdist(jnp.reshape(x, shape=(-1, 1)), jnp.reshape(x, shape=(-1, 1)))
    disty = _cdist(jnp.reshape(y, shape=(-1, 1)), jnp.reshape(y, shape=(-1, 1)))

    # Centering the distance matrices
    cent_distx = _center_distmat(distx, bias=bias)
    cent_disty = _center_distmat(disty, bias=bias)

    # Compute squared distance covariances
    dcov2_xx = jnp.sum(cent_distx * cent_distx)
    dcov2_yy = jnp.sum(cent_disty * cent_disty)
    dcov2_xy = jnp.sum(cent_distx * cent_disty)

    if bias:
        # only biased Dcov is square-rooted
        # https://search.r-project.org/CRAN/refmans/energy/html/dcovu.html
        dcov2_xx = jnp.sqrt(1 / (n**2) * dcov2_xx)
        dcov2_yy = jnp.sqrt(1 / (n**2) * dcov2_yy)
        dcov2_xy = jnp.sqrt(1 / (n**2) * dcov2_xy)
    else:
        dcov2_xx = 1 / (n * (n - 3)) * dcov2_xx
        dcov2_yy = 1 / (n * (n - 3)) * dcov2_yy
        dcov2_xy = 1 / (n * (n - 3)) * dcov2_xy

    stat = dcov2_xy / jnp.sqrt(jnp.real(dcov2_xx * dcov2_yy))

    if bias:
        stat = jnp.sqrt(stat)

    return stat
