"""
Metrics for evaluating the performance of a compound search algorithm.

The metrics are computed with jax so they can be run on gpu.
"""

import jax.numpy as jnp
from jax import vmap
from jax.scipy.stats import chi2
from jax.typing import ArrayLike
from pydantic import validate_call
from scipy import stats

from compound_hunting.assessment.distance_correlation import (
    _dcorr,
)


def log_likelihood_metric(X: ArrayLike, y: ArrayLike, y_pred: ArrayLike) -> ArrayLike:
    """
    Calculate the log-likelihood of an ordinary least squares model
    given its residuals.

    This function computes the log-likelihood based on the residual sum of squares (RSS)
    of a model's predictions. It assumes that the errors (residuals) are normally distributed.

    The formula used for the log-likelihood calculation is::

        L = -0.5 * n * log(2 * pi) - 0.5 * n * log(RSS / n) - 0.5 * n

    where `n` is the number of observations and `RSS` is the residual sum of squares.

    Args:
        X (ArrayLike):
            The design matrix.
        y (ArrayLike):
            The target values.
        y_pred (ArrayLike):
            The predicted values.

    Returns:
        ArrayLike: The log-likelihood value for the given residuals.
    """
    nobs = X.shape[0]
    residuals = y - y_pred
    rss = jnp.sum(residuals**2, axis=0)  # residual sum of squares
    mult = -0.5 * nobs
    term1 = jnp.log(2 * jnp.pi)
    term2 = jnp.log(rss / nobs)
    term3 = 1
    return mult * (term1 + term2 + term3)


def aic_metric(X: ArrayLike, y: ArrayLike, y_pred: ArrayLike) -> ArrayLike:
    """
    Calculate the Akaike Information Criterion (AIC) for a model.
    Lower is better.

    AIC is a measure of the relative quality of a statistical model for a given set of data.
    It is calculated using the log-likelihood of the model and the number of features.

    The formula for AIC is::

        AIC = 2 * number of features - 2 * log-likelihood

    Args:
        X (ArrayLike):
            The design matrix.
        y (ArrayLike):
            The target values.
        y_pred (ArrayLike):
            The predicted values.

    Returns:
        ArrayLike: The calculated AIC value.
    """
    n_features = X.shape[1]
    llf = log_likelihood_metric(X, y, y_pred)
    aic = 2 * n_features - 2 * llf
    return aic


def bic_metric(X: ArrayLike, y: ArrayLike, y_pred: ArrayLike) -> ArrayLike:
    """
    Calculate the Bayesian Information Criterion (BIC) for a model.
    Lower is better.

    The formula for BIC is::

        BIC = log(n) * number of features - 2 * log-likelihood

    where 'n' is the number of samples.

    Args:
        X (ArrayLike):
            The design matrix.
        y (ArrayLike):
            The target values.
        y_pred (ArrayLike):
            The predicted values.

    Returns:
        ArrayLike: The calculated BIC value.
    """
    n_samples = X.shape[0]
    n_features = X.shape[1]
    llf = log_likelihood_metric(X, y, y_pred)
    bic = jnp.log(n_samples) * n_features - 2 * llf
    return bic


def spectrum_metric(X: ArrayLike, y: ArrayLike, y_pred: ArrayLike) -> ArrayLike:
    """
    Calculate the spectrum metric. Lower is better.

    The spectrum score is computed by normalizing y_true and y_pred,
    calculating their dot product, and then
    applying a logarithmic transformation to 1 minus this dot product.
    """
    ys_true = y / jnp.linalg.norm(y, axis=0)
    ys_pred = y_pred / jnp.linalg.norm(y_pred, axis=0)
    dot_product_norm = jnp.sum(ys_true * ys_pred, axis=0)
    spectrum_score = jnp.log10(1 - dot_product_norm)
    return spectrum_score


def adjusted_r2_metric(X: ArrayLike, y: ArrayLike, y_pred: ArrayLike) -> ArrayLike:
    """
    Calculate the adjusted R-squared (R²) value.

    The formula for adjusted R² is::

        adj_R² = 1 - (1 - R²) * (n - 1) / (n - p - 1)

    where:
    - R² is the coefficient of determination,
    - n is the number of observations,
    - p is the number of predictors (excluding the intercept).

    Args:
        X (ArrayLike):
            The design matrix.
        y (ArrayLike):
            The target values.
        y_pred (ArrayLike):
            The predicted values.

    Returns:
        ArrayLike: The adjusted R-squared value(s). Returns an array of adjusted R² values.
    """
    n_samples = X.shape[0]
    n_features = X.shape[1]
    r2 = r2_metric(X, y, y_pred)
    return 1 - (1 - r2) * (n_samples - 1) / (n_samples - n_features - 1)


def r2_metric(X: ArrayLike, y: ArrayLike, y_pred: ArrayLike) -> ArrayLike:
    """
    Calculate the coefficient of determination R-squared (R²).

    The R² is calculated using the formula::

        R² = 1 - (SS_res / SS_tot)

    where SS_res is the sum of squares of residuals and SS_tot is the total sum of squares.

    Args:
        X (ArrayLike): The design matrix.
        y (ArrayLike): True values of the dependent variable.
        y_pred (ArrayLike): Predicted values from the regression model.

    Returns:
        ArrayLike: The R-squared value. Returns an array of R² values.
    """
    # Calculate residuals
    residuals = y - y_pred

    # Calculate SS_res
    ss_res = jnp.sum(residuals**2, axis=0)

    # Calculate SS_tot
    y_mean = jnp.mean(y, axis=0)
    ss_tot = jnp.sum((y - y_mean) ** 2, axis=0)

    # Calculate R-squared
    r_squared = 1 - (ss_res / ss_tot)
    return r_squared


def f_statistics_metric(X: ArrayLike, y: ArrayLike, y_pred: ArrayLike) -> ArrayLike:
    """
    Calculate the F-statistic for a regression model.

    The F-statistic is used to test the overall significance of a regression model.
    It compares the variance explained by the model (sum of squares of the regression, SSR)
    to the variance unexplained by the model (sum of squares of the residuals/errors, SSE).

    The formula for the F-statistic is::

        F = MSR / MSE

    where MSR (Mean Square Regression) is SSR divided by the number of predictors, and MSE
    (Mean Square Error) is SSE divided by the degrees of freedom of the residuals.

    Args:
        X (ArrayLike): The design matrix.
        y (ArrayLike): True values of the dependent variable.
        y_pred (ArrayLike): Predicted values from the regression model.

    Returns:
        ArrayLike: The F-statistic. Returns an array of F-statistics.
    """
    n = y.shape[0]  # Number of observations
    p = X.shape[1]  # Number of predictors

    # Calculate SSR (sum of squares of the regression)
    y_mean = jnp.mean(y, axis=0)
    ssr = jnp.sum((y_pred - y_mean) ** 2, axis=0)

    # Calculate SSE (sum of squares of the residuals/errors)
    sse = jnp.sum((y - y_pred) ** 2, axis=0)

    # Calculate MSR and MSE
    msr = ssr / p
    mse = sse / (n - p - 1)

    # Calculate F-statistic
    f_statistic = msr / mse
    return f_statistic


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def f_pvalue_metric(X: ArrayLike, y: ArrayLike, y_pred: ArrayLike) -> ArrayLike:
    """
    Calculate the p-value of the F-statistic for a regression model.

    Args:
        X (ArrayLike): The design matrix.
        y (ArrayLike): True values of the dependent variable.
        y_pred (ArrayLike): Predicted values from the regression model.

    Returns:
        ArrayLike: The p-value of the F-statistic. Returns an array of p-values.
    """
    f_statistic = f_statistics_metric(X, y, y_pred)
    p = X.shape[1]  # Number of predictors
    nobs = y.shape[0]  # Number of observations
    df2 = nobs - p - 1
    # Calculate the p-value
    p_value = stats.f.sf(f_statistic, p, df2)
    return p_value


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def rmse_metric(X: ArrayLike, y: ArrayLike, y_pred: ArrayLike) -> ArrayLike:
    """
    Calculate the RMSE metric. Lower is better.

    Args:
        X (ArrayLike): The design matrix.
        y (ArrayLike): True values of the dependent variable.
        y_pred (ArrayLike): Predicted values from the regression model.

    Returns:
        ArrayLike: The RMSE array.
    """
    return jnp.sqrt(jnp.mean((y - y_pred) ** 2, axis=0))


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def dcorr_pvalue_metric(
    X: ArrayLike,
    y: ArrayLike,
    y_pred: ArrayLike,
    nus: ArrayLike | None = None,
    bias: bool = False,
) -> tuple[ArrayLike, ArrayLike]:
    """
    Calculate the Distance correlation (Dcorr) statistic of the residuals of a model and the p-value of the statistic.
    Lower Dcorr statistic is better.

    Dcorr is a measure of how independent the residual values are from the independent variables.
    The Dcorr statistic is a value between 0 and 1. A value of zero indicates that the residuals are independent from the wavenumber axis.
    The wavenumber axis is specified by the nus argument.
    See the _dcorr function for details on the definition of the distance correlation.

    Uses a fast chi-squared approximation for the p-value of the distance correlation test statistic.
    This is an alternative to the standard perumtation test, but close to as powerful, see second ref. below.

    Args:
        X (ArrayLike):
            The design matrix.
        y (ArrayLike):
            The target values.
        y_pred (ArrayLike):
            The predicted values.
        nus (ArrayLike):
            The wavenumber axis. If None, assumes evenly space wavenumbers.
        bias (bool):
            whether to calculate the biased or unbiased test statistic. default is unbiased.

    Returns:
        ArrayLike: The calculated dcorr value.
        ArrayLike: The calculated p-value.


    References:
        Székely, G. J., Rizzo, M. L., & Bakirov, N. K. (2007).
        Measuring and testing dependence by correlation of distances.

        Shen C, Panda S, Vogelstein JT.
        The Chi-Square Test of Distance Correlation.
        J Comput Graph Stat. 2022;31(1):254-262
    """
    n_samples = X.shape[0]
    residuals = y - y_pred

    if nus is None:
        nus = jnp.arange(0, n_samples, 1)

    def _calculate_stat_pvalue(spectrum_residuals):
        stat = _dcorr(nus, spectrum_residuals, bias)
        pvalue = chi2.sf(stat * n_samples + 1, 1)
        return stat, pvalue

    # Use vmap for batch processing when residuals
    # have multiple dimensions (multitask)
    if residuals.ndim == 1:
        return _calculate_stat_pvalue(residuals)
    else:
        return vmap(_calculate_stat_pvalue, in_axes=1)(residuals)
