"""
Implements custom scorers for use with scikit-learn's methods.

For more information on custom scorers, see here
https://scikit-learn.org/stable/modules/model_evaluation.html#defining-your-scoring-strategy-from-metric-functions'

Functions whose name end in '_loss' mean that lower values are better,
while functions with names ending in '_score' mean higher values are better.

To use a loss function as a scorer, use the ``make_scorer`` function
from sklearn.metrics.

Since this is a sklearn-compatible module, it uses CPU-only.
As metrics are implemented in JAX, they can be run on GPUs,
but here we explicitly bind to the CPU.
"""

import jax
import jax.numpy as jnp
import numpy as np

from compound_hunting.assessment.metrics import (
    aic_metric,
    bic_metric,
    spectrum_metric,
)

DEVICE_CPU = jax.devices("cpu")[0]


def aic_loss(model, X, y) -> float:
    """
    Calculate the Akaike Information Criterion (AIC) loss for a model.

    This function computes the AIC for a given model.
    Lower is better.
    It can handle single task (y) or multitask (Y).
    If multitask, the AIC is calculated for each task,
    and the median AIC across all tasks is returned.

    Args:
        model:
            A fitted model that supports the predict method.
        X (np.ndarray):
            Input features, with shape (n_samples, n_features).
        y (np.ndarray):
            True output values, with shape (n_samples,)
            or (n_samples, n_tasks).

    Returns:
        float: The median AIC value across all tasks.

    Note:
        The number of features is set to be X.shape[1] + 1 (include the intercept).
    """
    with jax.default_device(DEVICE_CPU):
        X, y = jnp.asarray(X), jnp.asarray(y)
        aic = aic_metric(X, y, model.predict(X))
        aic = float(jnp.median(aic))
    return aic


def bic_loss(model, X, y) -> float:
    """
    Calculate the Bayesian Information Criterion (BIC) loss for a model.

    This function computes the BIC for a given model.
    Lower is better.
    It can handle single task (y) or multitask (Y).
    If multitask, the BIC is calculated for each task,
    and the median BIC across all tasks is returned.

    Args:
        model:
            A fitted model that supports the predict method.
        X (np.ndarray):
            Input features, with shape (n_samples, n_features).
        y (np.ndarray):
            True output values, with shape (n_samples,)
            or (n_samples, n_tasks).

    Returns:
        float: The median BIC value across all tasks.

    Note:
        The number of features is set to be X.shape[1] + 1 (include the intercept).
    """
    with jax.default_device(DEVICE_CPU):
        X, y = jnp.asarray(X), jnp.asarray(y)
        bic = bic_metric(X, y, model.predict(X))
        bic = float(jnp.median(bic))
    return bic


def spectrum_score(model, X, y) -> float:
    """
    Calculate the spectrum score for a model.

    This function computes the spectrum score for a given model.
    Higher is better.
    It can handle single task (y) or multitask (Y).
    If multitask, the spectrum score is calculated for each task,
    and the median spectrum score across all tasks is returned.

    Args:
        model:
            A fitted model that supports the predict method.
        X (np.ndarray):
            Input features, with shape (n_samples, n_features).
        y (np.ndarray):
            True output values, with shape (n_samples,) or (n_samples, n_tasks).

    Returns:
        float: The median spectrum score across all tasks.

    """
    with jax.default_device(DEVICE_CPU):
        X, y = jnp.asarray(X), jnp.asarray(y)
        ss = -spectrum_metric(X, y, model.predict(X))
        ss = float(jnp.median(ss))
    return ss


def bic_score(model, X, y) -> float:
    """
    Calculate the Bayesian Information Criterion (BIC) score for a model.

    This function computes the BIC for a given model.
    Higher is better (unlike the bic_metric, where
    lower is better).
    It can handle single task (y) or multitask (Y).
    If multitask, the BIC is calculated for each task,
    and the median BIC across all tasks is returned.

    Args:
        model:
            A fitted model that supports the predict method.
        X (np.ndarray):
            Input features, with shape (n_samples, n_features).
        y (np.ndarray):
            True output values, with shape (n_samples,)
            or (n_samples, n_tasks).

    Returns:
        float: The median BIC value across all tasks.

    Note:
        The number of features is set to be X.shape[1] + 1 (include the intercept).
    """
    with jax.default_device(DEVICE_CPU):
        X, y = jnp.asarray(X), jnp.asarray(y)
        bic = bic_metric(X, y, model.predict(X))
        bic = float(-jnp.median(bic))
    return bic


def aic_score(model, X, y) -> float:
    """
    Calculate the Akaike Information Criterion (AIC) score for a model.

    This function computes the AIC for a given model.
    Higher is better (unlike the aic_metric, where
    lower is better).
    It can handle single task (y) or multitask (Y).
    If multitask, the AIC is calculated for each task,
    and the median AIC across all tasks is returned.

    Args:
        model:
            A fitted model that supports the predict method.
        X (np.ndarray):
            Input features, with shape (n_samples, n_features).
        y (np.ndarray):
            True output values, with shape (n_samples,)
            or (n_samples, n_tasks).

    Returns:
        float: The median AIC value across all tasks.

    Note:
        The number of features is set to be X.shape[1] + 1 (include the intercept).
    """
    with jax.default_device(DEVICE_CPU):
        X, y = jnp.asarray(X), jnp.asarray(y)
        aic = aic_metric(X, y, model.predict(X))
        aic = float(-jnp.median(aic))
    return aic


def rmse_score(model, X, y) -> float:
    """
    Calculate the root mean squared error (RMSE) score for a model.

    Args:
        model:
            A fitted model that supports the predict method.
        X (np.ndarray):
            Input features, with shape (n_samples, n_features).
        y (np.ndarray):
            True output values, with shape (n_samples,)
            or (n_samples, n_tasks).

    Returns:
        float: The median rmse value across all tasks.

    """
    with jax.default_device(DEVICE_CPU):
        X, y = jnp.asarray(X), jnp.asarray(y)
        residuals = y - model.predict(X)
        rmse = jnp.sqrt(jnp.mean(residuals**2, axis=0))
        rmse = float(jnp.median(rmse))
    return rmse


def r2_score(model, X, y) -> float:
    """
    Calculate the R^2 score for a model.

    Args:
        model:
            A fitted model that supports the predict method.
        X (np.ndarray):
            Input features, with shape (n_samples, n_features).
        y (np.ndarray):
            True output values, with shape (n_samples,)
            or (n_samples, n_tasks).

    Returns:
        float: The median R2 value across all tasks.

    """
    r2 = float(np.median(model.score(X, y)))
    return r2
