from typing import Literal

import numpy as np
import pandas as pd
from numpy.typing import ArrayLike
from pydantic import validate_call
from scipy.linalg import lstsq


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def evaluate_substitution(
    X: pd.DataFrame,
    Y: pd.DataFrame | pd.Series,
    selected_cids: list[str | int],
    target_cid: str | int,
    replacement_cids: list[str | int],
) -> float:
    """
    Take an original solution (``selected_cids``) and
    evaluate the RMSE of an alternative solution, where
    ``target_cid`` was substituted with ``replacement_cids``.

    Args:
        X (pd.DataFrame):
            Complete model functions matrix (modes x cids).
        Y (pd.DataFrame | pd.Series):
            Spectra matrix (modes x times) or array (modes x 1).
        selected_cids (list[str | int]):
            The CIDs in the original model.
            They need to be in the columns of X.
        target_cid (str | int):
            The CID to be replaced. It needs to be in the columns of X.
        replacement_cids (list[str | int]):
            The CID(s) to replace the target CID.
            They need to be in the columns of X.

    Returns:
        float: The calculated RMSE value.
    """
    sel_cids = list(set(selected_cids) - {target_cid} - set(replacement_cids))
    combo_arrays = [X.loc[:, cid].values for cid in replacement_cids]
    combo_arrays.append(np.ones(X.shape[0]))  # Add intercept
    A = np.column_stack([X.loc[:, sel_cids].values] + combo_arrays)
    _, rss, _, _ = lstsq(A, Y.values)
    rmse = np.sqrt(np.median(rss) / X.shape[0])
    return rmse


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def one_standard_error_rule(
    scores: ArrayLike,
    std_errors: ArrayLike,
    min_std_error: float = 0.0,
    how: Literal["first", "last"] = "first",
) -> tuple[int, float]:
    """
    Apply the one standard error rule to select the index of the score.

    This rule is used for model selection,
    where the simplest model within one standard error of the
    best performing model is chosen.
    The function identifies the index of the last score that is
    within one standard error of the minimum score.

    Args:
        scores (ArrayLike):
            A list or array of scores, typically representing
            model performance metrics (e.g., accuracy, error).
        std_errors (ArrayLike):
            A list or array of standard errors corresponding
            to each score.
        min_std_error (float):
            Minimum standard error to consider.
            This value is used to avoid selecting
            scores with an unreasonably low standard error.
            Defaults to 0.0.
        how (Literal["first", "last"]):
            Whether to select the first or last score within
            one standard error of the minimum score.
            If scores (and std_errors) are sorted in increasing
            level of complexity, then choose "first" to select
            the simplest model.
            If scores (and std_errors) are sorted in decreasing
            level of complexity, then choose "last" to select
            the simplest model.

    Returns:
        tuple[int, float]:
            The index of the last score within one standard error
            of the minimum score, and the selected score.
    """
    scores = np.asarray(scores)
    std_errors = np.asarray(std_errors)

    if scores.shape != std_errors.shape:
        raise ValueError("``scores`` and ``std_errors`` must have the same shape")

    best_score_idx = np.argmin(scores)
    best_score = scores[best_score_idx]
    err = max(std_errors[best_score_idx], min_std_error)
    score_to_beat = best_score + err
    mask = scores <= score_to_beat

    if how == "first":
        selected_index = np.min(np.where(mask)[0])
    elif how == "last":
        selected_index = np.max(np.where(mask)[0])
    else:
        raise ValueError("``how`` must be either ``first`` or ``last``")

    selected_score = scores[selected_index]

    return selected_index, selected_score


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def vip_scores(
    x_weights: np.ndarray,
    x_scores: np.ndarray,
    y_loadings: np.ndarray,
    eps: float = 1e-12,
) -> np.ndarray:
    """
    Calculate the variable importance in projection (VIP) scores
    for each feature in the partial least squares (PLS)
    regression model.

    In general, features with VIP scores > 1 are considered important.

    Explanation of arguments assumes the use of the sklearn PLSRegression class.

    Args:
      x_weights (np.array):
          The X weights. When using the sklearn PLSRegression class,
          this is the x_rotations_ attribute.
          Dimension: (n_features x n_components)
      x_scores (np.array):
          The X scores. When using the sklearn PLSRegression class,
          this is the x_scores_ attribute.
          Dimension: (n_samples x n_components)
      y_loadings (np.array):
          The Y loadings. When using the sklearn PLSRegression class,
          this is the y_loadings_ attribute.
          Dimension: (n_targets x n_components)
      eps (float):
          A small value to avoid division by zero.
          Defaults to 1e-12.

    Returns:
        np.array: The VIP scores for each feature.
    """
    p, h = x_weights.shape
    _, h_check = x_scores.shape
    _, h_check2 = y_loadings.shape

    if h != h_check or h != h_check2:
        raise ValueError("Inconsistent number of components in input arrays")

    vips = np.zeros(p)
    s = np.diag(x_scores.T @ x_scores @ y_loadings.T @ y_loadings).reshape(h, -1)
    total_s = np.sum(s)

    x_weights_norm = np.linalg.norm(x_weights, axis=0)

    # avoid division by zero
    x_weights_norm = np.where(x_weights_norm < eps, eps, x_weights_norm)

    for i in range(p):
        weight = (x_weights[i, :] / x_weights_norm) ** 2
        vips[i] = np.sqrt(p * (s.T @ weight).item() / total_s)

    return vips
