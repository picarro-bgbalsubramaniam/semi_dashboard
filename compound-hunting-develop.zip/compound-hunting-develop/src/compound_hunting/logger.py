"""Functions for logging"""

import logging
import sys


def get_logger(module_name, log_level=logging.INFO):
    """
    parameters:
        module_name: the __name__ property from each module
        log_level: base level to start logging to the stdout/stderr console

    Returns:
        Log message to stdout.
    """

    # Create and configure main logger.
    logger = logging.getLogger(module_name)

    # Format the log message.
    log_format = "%(asctime)s %(levelname)-8s [%(name)s:LineNo:%(lineno)d] %(message)s"
    formatter = logging.Formatter(log_format)

    # Setup logs to stdout console.
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(formatter)

    # Output logs to stdout console.
    logger.addHandler(stream_handler)

    # Set log output level.
    logger.setLevel(log_level)

    return logger
