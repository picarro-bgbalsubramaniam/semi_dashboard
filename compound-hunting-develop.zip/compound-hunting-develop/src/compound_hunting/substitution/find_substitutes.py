from functools import partial
from itertools import combinations
from typing import Optional

import jax.numpy as jnp
import numpy as np
import pandas as pd
from jax import jit, lax, vmap
from jax.typing import ArrayLike
from pydantic import Field, validate_call
from sklearn.preprocessing import StandardScaler

from compound_hunting.substitution.evaluate_substitute import SubstituteFunctionMetric


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def find_substitutes(
    data: pd.DataFrame,
    metric_function: SubstituteFunctionMetric,
    threshold: float,
    depth: int = Field(default=1, ge=1, le=2),
    batch_size: Optional[int] = 100,
    cids: list[int | str] | None = None,
) -> dict[int | str, pd.Series]:
    """
    Identifies potential substitutes for each column (CID) in the data
    based on a given metric function and threshold.

    Args:
        data (pd.DataFrame): Input data frame with shape (n_frequencies, n_cids).
        metric_function (SubstituteFunctionMetric): Function that evaluates substitution performance.
        threshold (float): Minimum performance required for a successful substitution.
        depth (int, optional): Number of columns to consider in each subset. Defaults to 1.
        batch_size (int, optional): Batch size for JAX operations. Defaults to 100 (Simultaneous CIDs).
        cids (list[int | str], optional): List of CIDs to find substitutes for. Defaults to all CIDs in the data.
    Returns:
        dict[int | str, pd.Series]:
            Dictionary where keys are column names and values are Pandas Series.
            Each Series has subsets of length `depth` as index and performance metric values as values.
    """
    all_cids = data.columns.tolist()

    if cids is None:
        cids = all_cids
    else:
        not_found = set(cids) - set(all_cids)

        if not_found:
            raise ValueError(
                f"The following requested CIDs were not found in the data: {list(not_found)}"
            )

    scaled_data = StandardScaler().fit_transform(data).astype(np.float32)
    scaled_data = jnp.array(scaled_data)

    # Generate all possible combinations of columns of size "depth"
    all_combinations = list(combinations(range(data.shape[1]), depth))
    all_combinations_jnp = jnp.array(all_combinations, dtype=np.int32)

    # index of the CIDs to find substitutes for
    cids_idxs = jnp.array([data.columns.get_loc(cid) for cid in cids])

    performances = _evaluate_all_substitutions_performance(
        scaled_data,
        all_combinations_jnp,
        metric_function,
        cids_idxs=cids_idxs,
        batch_size=batch_size,
    )

    # move back to cpu for the rest of the process
    performances_cpu = np.array(performances)

    all_combinations_cids = [
        tuple(data.columns[k] for k in combination) for combination in all_combinations
    ]

    results = _create_substitution_results_dictionary(
        performances_cpu, cids, all_combinations_cids, threshold
    )

    return results


@partial(jit, static_argnames=("metric_function", "batch_size"))
def _evaluate_all_substitutions_performance(
    scaled_model_function_data: jnp.ndarray,
    combinations: jnp.ndarray,
    metric_function: SubstituteFunctionMetric,
    cids_idxs: jnp.ndarray,
    batch_size: Optional[int] = 100,
) -> jnp.ndarray:
    """
    Evaluate the performance of all substitutions using JAX.

    This function applies the metric function to all combinations of columns
    in the scaled data. It uses JAX's jit, vmap, and lax.map. We need to use
    lax.map with batch_size due to memory constraints.

    Args:
        scaled_model_function_data (jnp.ndarray):
            The scaled input data.
            It has shape (n_frequencies, n_cids).
        combinations (jnp.ndarray):
            Integer array of column index combinations that are to be substituted,
            it represent indexes from ``n_cids choose depth`` combinations.
            It has shape (n_substitutions, depth).
        metric_function (SubstituteFunctionMetric):
            The metric function to use.
        cids_idxs (jnp.ndarray):
            The column indexes of the CIDs to find substitutes for.
        batch_size (int, optional):
            The size of batches to use in lax.map. Defaults to 100.
    Returns:
        jnp.ndarray:
            A 2D array of metric results for each column and combination.
            It has shape (n_cids, n_substitutions).

    Note:
        This function is JIT-compiled with the metric_function and batch_size as static arguments.
    """
    metric = jit(metric_function)
    indexed_combinations = vmap(lambda combo: scaled_model_function_data[:, combo])(
        combinations
    )  # Shape: (n_substitutions, n_frequencies, depth)

    # Shape: (n_cids_to_check, n_frequencies)
    selected_data = scaled_model_function_data.T[cids_idxs]

    map_fn = partial(vmap(metric, in_axes=(0, None)), selected_data)

    results = lax.map(
        map_fn,
        indexed_combinations,
        batch_size=batch_size,
    )
    return results.T


def _create_substitution_results_dictionary(
    performance: ArrayLike,
    cids: list[int | str],
    combinations_cid: list[tuple[int | str, ...]],
    threshold: float,
) -> dict[int | str, pd.Series]:
    """
    Create a dictionary with the performance metrics as values and the column names as keys.

    Args:
        performance (ArrayLike):
            The performance metrics.
            It is a 2D array with the shape (n_cids, n_substitutions).
        cids (list[int | str]):
            The column names. It has shape (n_cids).
        combinations_cid (list[tuple[int | str, ...]]):
            The combinations of column names.
            It is a list with the shape (n_substitutions).
            Each element (substitution) is a tuple with the shape (depth).
        threshold (float):
            The threshold for the performance metrics.

    Returns:
        dict[int | str, pd.Series]:
            A dictionary with the performance metrics as values and the column names as keys.
    """
    performance = np.array(performance)
    combinations_cid_np = np.array(combinations_cid)

    keep_mask = performance >= threshold

    result = {}

    for i, key in enumerate(cids):
        # exclude substitutions that include the CID that is being substituted
        second_mask = np.array([key not in r for r in combinations_cid])

        updated_mask = keep_mask[i, :] & second_mask

        # Get the performance data for the current CID and good substitutions
        good_performance_data = performance[i, :][updated_mask]

        if len(good_performance_data) > 0:
            viable_substitution_cids = combinations_cid_np[updated_mask]

            result[key] = pd.Series(
                data=good_performance_data,
                index=pd.MultiIndex.from_arrays(viable_substitution_cids.T),
            ).sort_values(ascending=False)
        else:
            result[key] = pd.Series()

    return result
