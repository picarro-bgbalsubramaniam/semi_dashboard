"""
In this module there are functions that
are used to evaluate the quality of a cid substitution.
The format of the functions is defined by the type CanSubstituteFunction.
The first argument is the original cid model function,
the second argument is the replacement cid model function(s) to be evaluated.
The return value is a float representing the quality of the substitution.
There is no constraint on the return value (or its meaning),
as different metrics with different scales can be used.
"""

from typing import Callable

import jax.lax as lax
import jax.numpy as jnp
from jax.typing import ArrayLike
from pydantic import NonNegativeFloat

SubstituteFunctionMetric = Callable[[ArrayLike, ArrayLike], ArrayLike]


def substitute_pca_metric(
    original: ArrayLike, substitute: ArrayLike
) -> NonNegativeFloat:
    """
    Calculates the absolute value of the Pearson correlation coefficient between
    the first principal component of the substitute array and the original array.

    Args:
        original (ArrayLike):
            A 1D array-like object containing the original data.
        substitute (ArrayLike):
            A 1D or 2D array-like object containing the substitute data.
            If it's a 1D array, it will be reshaped
            into a 2D array with a single column.

    Returns:
        jax.Array:
            The absolute value of the Pearson correlation
            coefficient between the first principal component of
            the substitute array and the original array.
            From 0 to 1, higher values indicate a better substitution.
            It can be cast directly to float.
    """
    original = jnp.asarray(original)
    substitute = jnp.asarray(substitute)
    substitute = substitute.reshape(-1, 1) if substitute.ndim == 1 else substitute

    # Compute PCA using SVD
    _, s, vt = jnp.linalg.svd(substitute, full_matrices=False)
    first_pc = substitute @ vt[0]

    # Compute correlation
    correlation = jnp.corrcoef(first_pc, original)[0, 1]
    return jnp.abs(correlation)


def substitute_cond_ratio_metric(
    original: ArrayLike, substitute: ArrayLike
) -> NonNegativeFloat:
    """
    Calculates the ratio of the condition number of the matrix formed by column-stacking
    the original array and the substitute array to the condition number of the substitute array alone.
    A high value of this metric indicates a large increase in multi-collinearity.
    The condition number is calculated using the 2-norm, i.e., the
    largest singular value of the matrix divided by the smallest.

    Args:
        original (ArrayLike):
            A 1D array-like object containing the original data.
        substitute (ArrayLike):
            A 1D or 2D array-like object containing the substitute data.
            If it's a 1D array, it will be reshaped
            into a 2D array with a single column.

    Returns:
        jax.Array:
            The ratio of the condition number of the extended matrix (original + substitute)
            to the condition number of the substitute matrix alone.
            If the extended condition number is smaller than the base condition number,
            the ratio is set to 0.0, indicating no increase in multi-collinearity.
            It can be cast directly to float.
    """
    original = jnp.asarray(original)
    substitute = jnp.asarray(substitute)
    substitute = substitute.reshape(-1, 1) if substitute.ndim == 1 else substitute
    extended_matrix = jnp.column_stack((original, substitute))
    _, s, _ = jnp.linalg.svd(extended_matrix, full_matrices=False)
    base_cond = jnp.linalg.cond(substitute)
    ext_cond = jnp.max(s) / jnp.min(s)
    cond_ratio = lax.cond(
        ext_cond >= base_cond,
        lambda: (ext_cond - base_cond) / base_cond,
        lambda: jnp.array(0.0),
    )
    return cond_ratio
