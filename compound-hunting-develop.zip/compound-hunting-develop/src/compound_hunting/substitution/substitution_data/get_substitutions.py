import importlib_resources
from pandas import Series
from compound_hunting.substitution.utils import import_substitution_json


PKG_NAME = "compound_hunting"
SUB_DIR = "substitution"
SUB_DATA_DIR = "substitution_data"
ONE_TO_TWO_FILE = "the_great_book_of_one_to_two_pca.json"


def get_one_to_two() -> dict[int, Series]:
    """
    Read json package data and return the one to two substitution list
    """
    pkg_path = importlib_resources.files(PKG_NAME)
    data_file = pkg_path / SUB_DIR / SUB_DATA_DIR / ONE_TO_TWO_FILE
    return import_substitution_json(data_file)


def get_one_to_one() -> dict[int, Series]:
    """
    Read json package data and return the one to one substitution list
    """
    pkg_path = importlib_resources.files(PKG_NAME)
    data_file = (
        pkg_path / SUB_DIR / SUB_DATA_DIR / "the_great_book_of_one_to_one_pca.json"
    )
    return import_substitution_json(data_file)
