import itertools
import random
from typing import Optional, Any, Callable

import pandas as pd
from pydantic import Field, validate_call
from sklearn.linear_model import LinearRegression
from tqdm.auto import tqdm

from compound_hunting.logger import get_logger
from compound_hunting.substitution.utils import (
    _get_one_to_one_cids_substitutes,
    get_two_to_one_substitutes,
)

LOGGER = get_logger(__name__)


def _evaluate_single_solution(
    X: pd.DataFrame,
    Y: pd.Series | pd.DataFrame,
    positive: bool,
    selected_cids: list[int | str],
    scorers: dict[str | int, Callable],
    **kwargs,
) -> dict[str | int, Any]:
    """
    Evaluate the model with the given cids and scorers.

    Args:
        X (pd.DataFrame):
            Model function dataframe (modes x cids).
        Y (pd.DataFrame | pd.Series):
            Spectra dataframe (modes x time) or (mode)
        selected_cids (list[str | int]):
            List of cids forming the original model.
        one_to_two_substitutions (dict[str | int, pd.Series]):
            Dictionary of cids and their possible substitutes.
            From :py:func:`.find_substitutes`.
        scorers (dict[str | int, Callable]):
            Dictionary of scorers to evaluate the model.
        **kwargs:
            Additional information to store in the record.

    Returns:
        dict[str | int, Any]:
            Record with the evaluated solution.
    """
    Xt = X.loc[:, selected_cids].to_numpy()
    Y = Y.to_numpy()
    lr = LinearRegression(positive=positive).fit(Xt, Y)
    current_record = {
        scorer_name: scorer_fun(lr, Xt, Y)
        for scorer_name, scorer_fun in scorers.items()
    }
    current_record["n"] = len(selected_cids)
    current_record["cids"] = selected_cids
    current_record["positive"] = positive

    if kwargs:
        current_record.update(kwargs)

    return current_record


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def evaluate_equilength_solutions(
    X: pd.DataFrame,
    Y: pd.DataFrame | pd.Series,
    selected_cids: list[str | int],
    one_to_one_substitutions: dict[str | int, pd.Series],
    scorers: dict[str | int, Callable],
    positive: bool = False,
    limit: Optional[int] = None,
    show_progress: bool = True,
) -> list[dict[str | int, Any]]:
    """
    Evaluate equilength solutions by substituting one-to-one cids.

    The loop generates all possible combinations of substitutes
    for each selected cid.

    Args:
        X (pd.DataFrame):
            Model function dataframe (modes x cids).
        Y (pd.DataFrame | pd.Series):
            Spectra dataframe (modes x time) or (mode)
        selected_cids (list[str | int]):
            List of cids forming the original model.
        one_to_one_substitutions (dict[str | int, pd.Series]):
            Dictionary of cids and their possible substitutes.
            From :py:func:`.find_substitutes`.
        scorers (dict[str | int, Callable]):
            Dictionary of scorers to evaluate the model.
        positive (bool):
            Whether to use positive linear regression.
        limit (int):
            Maximum number of solutions to evaluate.
        show_progress (bool):
            Whether to show a progress bar.

    Returns:
        list[dict[str | int, Any]]:
            List of records with the evaluated solutions.
    """
    current_record = _evaluate_single_solution(
        X=X,
        Y=Y,
        positive=positive,
        selected_cids=selected_cids,
        scorers=scorers,
        type="original",
    )

    records = [current_record]
    covered_cids_combos = set(frozenset(selected_cids))

    lists_of_substitutes = _get_one_to_one_cids_substitutes(
        selected_cids, one_to_one_substitutions
    )

    for combination in tqdm(
        itertools.product(*lists_of_substitutes), disable=not show_progress
    ):
        sel_cids = frozenset(itertools.chain.from_iterable(combination))

        if sel_cids in covered_cids_combos:
            LOGGER.debug(f"Skipping {sel_cids} as it is already present.")
            continue

        current_record = _evaluate_single_solution(
            X=X,
            Y=Y,
            positive=positive,
            selected_cids=list(sel_cids),
            scorers=scorers,
            type="combination",
        )
        records.append(current_record)
        covered_cids_combos.add(frozenset(sel_cids))

        if limit and len(records) >= limit:
            break

    return records


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def evaluate_simpler_solutions(
    X: pd.DataFrame,
    Y: pd.DataFrame | pd.Series,
    selected_cids: list[str | int],
    one_to_two_substitutions: dict[str | int, pd.Series],
    scorers: dict[str | int, Callable],
    positive: bool = False,
    max_concurrent_substitutions: int = Field(default=2, ge=1),
    limit: Optional[int] = None,
    show_progress: bool = True,
    seed: Optional[int] = None,
) -> list[dict[str | int, Any]]:
    """
    Evaluate simpler solutions by substituting two-to-one cids.

    Two-to-one substitutions are first generated by swapping the one-to-two substitutions
    into two-to-one substitutions.
    Only pairs that are present in `selected_cids` are kept.

    The first loop generates 'r', the number of pairs of substitutable cids that will be
    substituted simultaneously from the original solution 'selected_cids',
    spanning from 1 to 'max_concurrent_substitutions'. For example,
    if `r=3`, up to 3 pairs of substitutable cids will be substituted simultaneously.

    The second loop generates combinations of 'r' substitutable pairs.
    The resulting list of pairs is shuffled based on `seed`.

    Each pair can be substituted not just by a single cid, but by a
    list of possible single-cid substitutes. The third loop
    generates all possible combinations of substitutes for each pair
    and evaluates them.

    Args:
        X (pd.DataFrame):
            Model function dataframe (modes x cids).
        Y (pd.DataFrame | pd.Series):
            Spectra dataframe (modes x time) or (mode)
        selected_cids (list[str | int]):
            List of cids forming the original model.
        one_to_two_substitutions (dict[str | int, pd.Series]):
            Dictionary of cids and their possible substitutes.
            From :py:func:`.find_substitutes`.
        scorers (dict[str | int, Callable]):
            Dictionary of scorers to evaluate the model.
        positive (bool):
            Whether to use positive linear regression.
        max_concurrent_substitutions (int):
            Maximum number of pairs of substitutable
            cids to substitute simultaneously.
        limit (int):
            Maximum number of solutions to evaluate.
        show_progress (bool):
            Whether to show a progress bar.
        seed (int):
            Seed for random shuffling.
            Defaults to None.

    Returns:
        list[dict[str | int, Any]]:
            List of records with the evaluated solutions.
    """

    if seed is not None:
        random.seed(seed)

    selected_cids = set(selected_cids)
    two_to_one_substitutes = get_two_to_one_substitutes(one_to_two_substitutions)
    two_to_one_substitutes = {
        k: v for k, v in two_to_one_substitutes.items() if k.issubset(selected_cids)
    }

    current_record = _evaluate_single_solution(
        X=X,
        Y=Y,
        positive=positive,
        selected_cids=list(selected_cids),
        scorers=scorers,
        type="original",
    )

    records = [current_record]
    covered_cids_combos = set(frozenset(selected_cids))

    substitutable_pairs = list(two_to_one_substitutes.keys())

    pbar = tqdm(total=None, disable=not show_progress)

    for r in range(1, max_concurrent_substitutions + 1):
        # Number of pairs of substitutable cids to substitute simultaneously
        n = 2 * r  # Number of elements in the combination

        possible_pairs = list(itertools.combinations(substitutable_pairs, r))
        random.shuffle(possible_pairs)

        for combination in possible_pairs:
            # Generate all possible combinations of substitutable cids pairs
            all_terms = set().union(*combination)
            if len(all_terms) < n:
                # not a valid substitution, some cids repeat
                continue

            base_subset = selected_cids - all_terms

            lists_of_substitutes = [two_to_one_substitutes[k] for k in combination]

            for comb in itertools.product(*lists_of_substitutes):
                # Generate all possible combinations of substitutes for each pair
                sel_cids = set(comb).union(base_subset)

                if sel_cids in covered_cids_combos:
                    LOGGER.debug(f"Skipping {sel_cids} as it is already present.")
                    continue

                current_record = _evaluate_single_solution(
                    X=X,
                    Y=Y,
                    positive=positive,
                    selected_cids=list(sel_cids),
                    scorers=scorers,
                    type=f"reduce_{r}",
                )
                records.append(current_record)
                covered_cids_combos.add(frozenset(sel_cids))
                pbar.update(1)

                if limit and len(records) >= limit:
                    pbar.close()
                    return records

    pbar.close()
    return records


def _filter_available_substitutions(
    available_subs: pd.Series, all_cids: list[int | str]
) -> pd.Series:
    """
    Filter available substitutions and log excluded ones.

    Sometimes we receive from the substitution bank
    substitutions that contain CIDs that are not present
    in the model functions matrix.
    Usually this happens when your spectral library is outdated.
    These CIDs are logged, but they are excluded as they cannot
    be tested on the data (as you don't have them in your matrix).

    Args:
        available_subs (pd.Series):
            Series of available substitutions.
            Index is a tuple of CIDs,
            value is the substitution score.
        all_cids (list[int | str]):
            List of all available CIDs
            that are present in the model functions matrix.

    Returns:
        pd.Series: Filtered substitutions.
    """
    filtered_subs = available_subs[
        available_subs.index.map(lambda x: all(cid in all_cids for cid in x))
    ]

    excluded_subs = [
        idx for idx in available_subs.index if not all(cid in all_cids for cid in idx)
    ]
    excluded_subs = list(
        set(itertools.chain.from_iterable(excluded_subs)).difference(all_cids)
    )

    if excluded_subs:
        LOGGER.warning(
            f"Found possible candidates that you don't have in the spectral library. "
            f"You could get better results by updating the spectral library to retrieve "
            f"compounds with these CIDs: {excluded_subs}"
        )

    return filtered_subs
