import json
from collections import defaultdict
from os import PathLike

import numpy as np
import pandas as pd


def get_two_to_one_substitutes(
    one_to_two_substitutes: dict[str, pd.Series],
) -> dict[frozenset[str | int], list[str | int]]:
    """
    Generate a dictionary of two-to-one substitutes by
    inverting a dictionary of one-to-two substitutes.

    >>> one_to_two_substitutes = {
    ...     4: pd.Series({
    ...         (174, 6564): 0.965570,
    ...         (6564, 86240): 0.962925,
    ...         (6564, 13578): 0.961978
    ...     }),
    ...     5: pd.Series({
    ...         (174, 6564): 0.965570,
    ...     }),
    ...     6: pd.Series(dtype=float)
    ... }
    >>> get_two_to_one_substitutes(one_to_two_substitutes)  # doctest: +NORMALIZE_WHITESPACE +ELLIPSIS
    {frozenset({6564, 174}): [4, 5],
    frozenset({86240, 6564}): [4],
    frozenset({13578, 6564}): [4]}

    Args:
        one_to_two_substitutes (dict[str, pd.Series]):
            A dictionary where keys are cids and
            values are Pandas Series with
            alternative cid subsets as index
            and performance metrics as values.
            From :py:func:`find_substitutes``.

    Returns:
        dict:
            A dictionary where keys are frozensets of two cids
            and values are lists of cids that can be substituted
            for the two cids in the key.
    """

    two_to_one_substitutes = defaultdict(list)

    for cid, sublist in one_to_two_substitutes.items():
        for cid_pair in sublist.keys():
            two_to_one_substitutes[frozenset(cid_pair)].append(cid)

    return dict(two_to_one_substitutes)


def _get_one_to_one_cids_substitutes(
    selected_cids: list[int | str], one_to_one_substitutions: dict[int | str, pd.Series]
) -> list[list[int | str]]:
    """
    Get the list of plausible substitutes for each selected cid.
    Results in a list of lists. Each element in the inner list
    is a possible substitute for the corresponding selected cid.

    If no substitutes are found for a given cid, the original cid
    is used as a substitute.

    >>> one_to_one = {
    ...     4: pd.Series({
    ...         (174, ): 0.965570,
    ...         (6564, ): 0.962925}
    ...     ),
    ...     5: pd.Series(dtype=float),
    ... }
    >>> _get_one_to_one_cids_substitutes([4, 5], one_to_one)  # doctest: +NORMALIZE_WHITESPACE +ELLIPSIS
    [[(174,), (6564,)], [(5,)]]


    Args:
        selected_cids (list[int | str]):
            List of cids forming the original model.
        one_to_one_substitutions (dict[int | str, pd.Series]):
            Dictionary of cids and their possible substitutes.
            From :py:func:`.find_substitutes`.

    Returns:
        list[list[int | str]]:
            List of lists with the possible substitutes for each selected cid.
    """

    # first get the list of substitutes for each selected cid
    # it's going to be a list of lists, where each sublist
    # contains the possible substitutes for a given cid given as a tuple
    lists_of_substitutes = [
        one_to_one_substitutions.get(cid, pd.Series(dtype=float)).index.to_list()
        for cid in selected_cids
    ]
    # if the list of substitutes is empty,
    # we add the original cid as a substitute
    lists_of_substitutes = [
        sub if len(sub) > 0 else [(key,)]
        for key, sub in zip(selected_cids, lists_of_substitutes)
    ]
    return lists_of_substitutes


def export_substitution_json(
    data: dict[int, pd.Series], path: PathLike | str, decimals: int = 4
):
    """
    Export substitutions to a JSON file.

    Args:
        data (dict):
            The dictionary of substitutions to export.
        path (str):
            The path to the JSON file.
        decimals (int, optional):
            The number of decimal places to round the values to.
            Defaults to 4.
    """
    # Convert the pandas series to dictionaries with MultiIndex as lists of tuples
    data_converted = {
        key: {
            "index": [list(idx) for idx in value.index],
            "values": [round(float(v), decimals) for v in value.values],
        }
        for key, value in data.items()
    }

    with open(path, "w") as json_file:
        json.dump(data_converted, json_file)


def import_substitution_json(path: PathLike | str) -> dict[int, pd.Series]:
    """
    Import substitutions from a JSON file.

    Args:
        path (str):
            The path to the JSON file.

    Returns:
        dict:
            The dictionary of substitutions.
    """
    with open(path, "r") as json_file:
        loaded_data = json.load(json_file)

    # Convert dictionaries back to pandas series with tuple indices
    return {
        int(key): pd.Series(
            data=value["values"],
            index=pd.MultiIndex.from_tuples([tuple(idx) for idx in value["index"]]),
        )
        if value["index"]
        else pd.Series()
        for key, value in loaded_data.items()
    }


def distance_based_alternatives(
    X: pd.DataFrame, selected_cid: int | str, limit: int = 10
) -> list[int | str]:
    """
    Find the closest column alternatives based on Euclidean distance to a selected column.

    Args:
        X (pd.DataFrame): Normalized DataFrame containing the data with columns representing different candidates.
        selected_cid (int or str): The candidate CID for which to find the closest alternatives.
        limit (int, optional): The number of closest alternatives to return. Defaults to 10.

    Returns:
        List[int | str]:
            A list of closest alternatives to the selected column.
    """
    distances = np.linalg.norm(
        X.drop(columns=selected_cid).values - X[selected_cid].values[:, None], axis=0
    )
    distances = pd.Series(distances, index=X.columns.drop(selected_cid))
    return distances.nsmallest(limit).index.tolist()
