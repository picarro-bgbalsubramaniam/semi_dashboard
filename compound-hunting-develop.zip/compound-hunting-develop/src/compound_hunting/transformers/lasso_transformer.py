import numpy as np
import pandas as pd
from sklearn.linear_model import (
    LassoCV,
    MultiTaskLassoCV,
)
from sklearn.preprocessing import StandardScaler
from sklearn.utils.validation import check_is_fitted

from compound_hunting.logger import get_logger
from compound_hunting.preprocessing.cross_validation import get_empty_cv
from compound_hunting.preprocessing.global_scaler import GlobalScaler
from compound_hunting.transformers.template_transformer import BaseHuntingTransformer

LOGGER = get_logger(__name__)
SINGLE_TASK_ALPHAS = np.geomspace(0.1, 1.5, 30)
MULTI_TASK_ALPHAS = np.geomspace(0.5, 2, 30)


class LassoTransformer(BaseHuntingTransformer):
    """
    A transformer that applies ``LassoCV`` or ``MultiTaskLassoCV`` for feature selection.

    This transformer first preprocesses the data by imputing NaN values and scaling.
    ``X`` is scaled using ``StandardScaler`` (by cid),
    and ``y`` is scaled using ``GlobalScaler``.
    Then, it fits a ``LassoCV`` or ``MultiTaskLassoCV``
    model to the data for feature selection.

    The alpha values for regularization impact the number of features selected,
    with larger values leading to stronger regularization (i.e., sparser solution
    with fewer cids selected, at the expenses of a worse fit),
    and smaller values leading to weaker regularization (i.e.,
    a more dense solution with more cids selected at the
    expenses of overfitting and increased risk of false-positives).

    Attributes:
        max_iter (int): Maximum number of iterations for the Lasso estimator.
        tol (float): The tolerance for the optimization.
        alphas (array-like, or None):
            List of alphas to consider for regularization.
            Larger values specify stronger regularization, i.e., returning
            less cids at the expenses of worse fit.
            Smaller values specify weaker regularization, i.e., returning
            more cids at the expenses of overfitting and increase
            risk of false-positives.
            If None (default), SINGLE_TASK_ALPHAS or MULTI_TASK_ALPHAS
            are assigned at runtime based on the task.
        cv:
            Cross-validation strategy in a scikit-learn compatible format.
            Defaults to ``ShuffleSplit(n_splits=100, test_size=0.3)``.
        n_jobs (int or None): Number of jobs to run in parallel.
        threshold (float): Threshold value for feature selection.
        dtype (data-type): Desired data-type for the inputs.
        nan_threshold (float): Threshold ratio of NaNs in y to raise an error.

    Methods:
        fit(X, y, **fit_params): Fits the Lasso model to the data.
        get_feature_names_out(): Returns the selected features.

    Attributes (after fit):
        feature_importances_ (np.ndarray): The feature importances.
        threshold_ (float): The threshold value for feature selection.
        feature_names_in_ (list[str]): The input feature names
    """

    def __init__(
        self,
        dtype=np.float32,
        allow_multitask=True,
        nan_threshold=0.1,
        scaler_x=StandardScaler().set_output(transform="pandas"),
        scaler_y=GlobalScaler(),
        max_iter=300,
        tol=5e-3,
        alphas=None,
        cv=None,
        n_jobs=None,
        threshold=1e-5,
    ):
        """
        Initializes the LassoTransformer with specified parameters.
        """
        super().__init__(
            dtype=dtype,
            allow_multitask=allow_multitask,
            nan_threshold=nan_threshold,
            scaler_x=scaler_x,
            scaler_y=scaler_y,
        )
        self.max_iter = max_iter
        self.tol = tol
        self.alphas = alphas
        self.cv = cv
        self.n_jobs = n_jobs
        self.threshold = threshold

    def _get_estimator(self, y):
        """
        Selects and returns the appropriate Lasso estimator based on the shape of y.

        Parameters:
            y (np.ndarray): Target array.

        Returns:
            Estimator: Either a MultiTaskLassoCV or LassoCV estimator.
        """
        if self.cv is None:
            self.cv = get_empty_cv(y.shape[0])

        if y.ndim > 1 and y.shape[1] > 1:
            LOGGER.debug("Using MultiTaskLassoCV")
            estimator = MultiTaskLassoCV(
                max_iter=self.max_iter,
                tol=self.tol,
                alphas=self.alphas,
                cv=self.cv,
                n_jobs=self.n_jobs,
            )
        else:
            LOGGER.debug("Using LassoCV")
            estimator = LassoCV(
                max_iter=self.max_iter,
                tol=self.tol,
                alphas=self.alphas,
                cv=self.cv,
                n_jobs=self.n_jobs,
            )
        return estimator

    def _set_alphas(self, y):
        """
        Sets the alphas based on the shape of y.

        Parameters:
            y (np.ndarray): Target array.
        """
        if self.alphas is not None:
            return

        if y.ndim > 1 and y.shape[1] > 1:
            LOGGER.info("Using MULTI_TASK_ALPHAS")
            self.alphas = MULTI_TASK_ALPHAS
        else:
            LOGGER.info("Using SINGLE_TASK_ALPHAS")
            self.alphas = SINGLE_TASK_ALPHAS

    def fit(self, X: pd.DataFrame, y, **fit_params: dict):
        """
        Fits the Lasso model to the data after preprocessing.

        Parameters:
            X (pd.DataFrame): Feature matrix (mode x cids).
            y (pd.DataFrame | pd.Series): Target array (mode x time).
            fit_params (dict): Additional parameters for fitting.

        Returns:
            LassoTransformer: The instance itself.
        """
        Xc, yc, _ = self.preprocess(X, y)
        self._set_alphas(yc)
        estimator = self._get_estimator(yc)
        self.X_ = Xc
        self.Y_ = yc
        self.estimator_ = estimator.fit(Xc, yc)
        self.threshold_ = self.threshold
        self.feature_importances_ = self._get_estimator_importance(estimator.coef_)
        return self

    def _get_support_mask(self) -> np.ndarray:
        """
        Computes and returns the support mask of selected features
        based on feature importances.

        Returns:
            np.ndarray: Boolean array indicating selected features.
        """
        check_is_fitted(self, "estimator_")
        return self.feature_importances_ > self.threshold_

    def _get_estimator_importance(self, coefs: np.ndarray):
        """
        Computes and returns the feature importances of the estimator
        based on the coefficients.
        If single task, returns the absolute value of the coefficients.
        If multi task, returns the L1 norm of the coefficients.

        Args:
            coefs (np.ndarray): Coefficients of the estimator.

        Returns:
            np.ndarray: Feature importances of the estimator.
        """
        if isinstance(self.estimator_, LassoCV):
            return np.abs(coefs)
        elif isinstance(self.estimator_, MultiTaskLassoCV):
            return np.linalg.norm(coefs, axis=0, ord=1)
        else:
            raise ValueError("Estimator must be either LassoCV or MultiTaskLassoCV")
