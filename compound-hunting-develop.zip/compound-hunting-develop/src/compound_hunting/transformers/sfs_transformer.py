import numpy as np
from sklearn.feature_selection import SequentialFeatureSelector
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.utils.validation import check_is_fitted

from compound_hunting.assessment.scorers import bic_score
from compound_hunting.preprocessing.cross_validation import get_empty_cv
from compound_hunting.preprocessing.global_scaler import GlobalScaler
from compound_hunting.transformers.template_transformer import BaseHuntingTransformer


class SequentialTransformer(BaseHuntingTransformer):
    def __init__(
        self,
        scorer=bic_score,
        n_features_to_select="auto",
        positive=False,
        tol=None,
        cv=None,
        n_jobs=None,
        dtype=np.float32,
        nan_threshold=0.1,
        scaler_x=StandardScaler().set_output(transform="pandas"),
        scaler_y=GlobalScaler(),
        direction="forward",
        allow_multitask=True,
    ):
        """
        Initializes the Sequential Transformer with specified parameters.
        """
        self.scorer = scorer
        self.n_features_to_select = n_features_to_select
        self.positive = positive
        self.tol = tol
        self.cv = cv
        self.n_jobs = n_jobs
        self.dtype = dtype
        self.nan_threshold = nan_threshold
        self.scaler_x = scaler_x
        self.scaler_y = scaler_y
        self.direction = direction
        self.allow_multitask = allow_multitask

    def _get_estimator(self):
        """ """
        estimator = SequentialFeatureSelector(
            estimator=LinearRegression(positive=self.positive),
            scoring=self.scorer,
            direction=self.direction,
            tol=self.tol,
            cv=self.cv,
            n_jobs=self.n_jobs,
            n_features_to_select=self.n_features_to_select,
        )
        return estimator

    def fit(self, X, y, **fit_params: dict):
        """

        Parameters:
            X: Feature matrix (mode x cids).
            y: Target array (mode x time) or (mode).
            fit_params (dict): Additional parameters for fitting.

        Returns:
            The instance itself.
        """
        estimator = self._get_estimator()
        Xc, yc, _ = self.preprocess(X, y)
        self.X_ = Xc
        self.Y_ = yc

        if self.cv is None:
            self.cv = get_empty_cv(yc.shape[0])

        estimator.set_params(cv=self.cv)
        self.estimator_ = estimator.fit(Xc, yc)
        return self

    def _get_support_mask(self):
        """
        Returns the selected features based on the fitted estimator.

        Returns:
            np.ndarray: Boolean mask of selected features.
        """
        check_is_fitted(self, "estimator_")
        return self.estimator_.get_support()
