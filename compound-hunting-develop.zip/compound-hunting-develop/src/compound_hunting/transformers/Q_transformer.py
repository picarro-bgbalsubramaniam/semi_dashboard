"""
Takes in a model function matrix ``X``, a spectra matrix ``Y``,
and another model function matrix ``original_X`` (with ``X`` being
a column-subset of ``original_X``), and transform ``X`` by
dropping columns that do not satisfy Q criteria, based on
a provided Q threshold.
"""

import numpy as np
from sklearn.utils.validation import check_is_fitted

from compound_hunting.assessment.q_factor import q_metric
from compound_hunting.transformers.template_transformer import BaseHuntingTransformer


class QTransformer(BaseHuntingTransformer):
    def __init__(
        self,
        q_threshold=1.0,
        dtype=np.float32,
        nan_threshold=0.1,
        scaler_x=None,
        scaler_y=None,
        allow_multitask=True,
    ):
        """
        Initializes the Q Transformer with specified parameters.

        Args:
            q_threshold (float, optional):
                Threshold for Q score filtering. Defaults to 1.0.
        """
        self.q_threshold = q_threshold
        self.dtype = dtype
        self.nan_threshold = nan_threshold
        self.scaler_x = scaler_x
        self.scaler_y = scaler_y
        self.allow_multitask = allow_multitask

    def fit(self, X, y, original_X=None, **fit_params: dict):
        """

        Args:
            X: Feature matrix (mode x cids).
            y: Target array (mode x time) or (mode).
            original_X:
                Original feature matrix (mode x cids) of available model functions.
            fit_params (dict):
                Additional parameters for fitting, provided to q_metric function.

        Returns:
            The instance itself.
        """
        if original_X is None:
            raise ValueError(
                "Argument `original_X` must be provided in order "
                "to evaluate the q_metric on alternative solutions."
            )

        Xc, yc, _ = self.preprocess(X, y)
        self.X_ = Xc
        self.Y_ = yc

        # preprocessing might drop modes, make sure
        # original matrix is adjusted as well
        self.Xf_ = original_X.loc[Xc.index, :]

        qs, subs = q_metric(
            X=self.Xf_,
            Y=self.Y_,
            selected_cids=list(Xc.columns.astype(int)),
            **fit_params,
        )
        self.threshold_ = self.q_threshold
        self.feature_importances_ = qs.values
        self.best_substitutes_ = subs.values
        self.estimator_ = qs
        return self

    def _get_support_mask(self):
        """
        Returns the selected features based on the fitted estimator.

        Returns:
            np.ndarray: Boolean mask of selected features.
        """
        check_is_fitted(self, "feature_importances_")
        return self.feature_importances_ > self.threshold_
