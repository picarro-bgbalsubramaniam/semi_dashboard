from abc import ABC, abstractmethod

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator
from sklearn.feature_selection import SelectorMixin
from sklearn.utils.validation import check_is_fitted, validate_data

from compound_hunting.logger import get_logger
from compound_hunting.preprocessing.nan_filter import (
    apply_row_filter,
    get_nan_rows_mask,
    impute_nans_by_row,
)

LOGGER = get_logger(__name__)


class BaseHuntingTransformer(SelectorMixin, BaseEstimator, ABC):
    """
    Abstract base class for hunting transformers.

    Attributes:
        dtype (data type):
            Desired data-type for the inputs.
            Default is np.float64.
        allow_multitask (bool):
            Whether to allow multi-task learning.
            Default is True.
            If False, the target array (y) is reduced 1D
            by averaging.
        nan_threshold (float):
            Threshold ratio of NaNs in y to raise an error.
            Default is 0.1. Must be between 0 and 1.
        scaler_x:
            Scaler for the feature matrix.
            Default is None (passthrough).
            Example: ``StandardScaler()``
        scaler_y:
            Scaler for the target array.
            Default is None (passthrough).
            Example: ``GlobalScaler()``
    """

    def __init__(
        self,
        dtype=np.float64,
        allow_multitask=True,
        nan_threshold=0.1,
        scaler_x=None,
        scaler_y=None,
    ):
        """
        Initializes the BaseHuntingTransformer with specified parameters.
        """
        self.dtype = dtype
        self.allow_multitask = allow_multitask
        self.nan_threshold = nan_threshold
        self.scaler_x = scaler_x
        self.scaler_y = scaler_y

    def _scale(self, X, y):
        """
        Scales the feature matrix (X) and
        target array (y).
        If scalers are not provided (None), the input
        data is returned as is.

        Parameters:
            X: Feature matrix.
            y: Target array.

        Returns:
            Tuple: Scaled feature matrix and target array.
        """
        Xs = self.scaler_x.fit_transform(X) if self.scaler_x else X
        ys = self.scaler_y.fit_transform(y) if self.scaler_y else y
        return Xs, ys

    def _manage_nans(self, X, y):
        """
        Nan management for the feature matrix (X) and target array (y)
        is a multistep process:

            1. Mark rows with too many NaNs (>threshold) in the target array rows (y)
            2. For 2D target arrays, impute Nans by row (mode).
            3. Drop unmarked rows in the feature matrix (X) and target array (y).

        Parameters:
            X: Feature matrix.
            y: Target array.

        Returns:
            Tuple: Feature matrix, target array, and non-null boolean mask
        """
        nonnull_mask = get_nan_rows_mask(y, nan_threshold=self.nan_threshold)
        y = impute_nans_by_row(y)
        Xc, yc = apply_row_filter(X, y, keep_rows_mask=nonnull_mask)
        return Xc, yc, nonnull_mask

    def preprocess(self, X, y):
        """
        Preprocesses the input data by handling NaNs, scaling, and validating data.
        Transform the input data to the desired data type.

        Parameters:
            X: Feature matrix.
            y: Target array.

        Returns:
            Tuple[np.ndarray, np.ndarray, np.ndarray]:
                Preprocessed feature matrix, target array, and boolean mask indicating
                which rows were kept (True) or dropped (False) during preprocessing.
                The mask has the same length as the original input X and y.
        """
        Xc = X.copy()
        yc = y.copy()

        if isinstance(X, pd.DataFrame):
            Xc.columns = Xc.columns.astype(str)

        Xc, yc, keep_mask = self._manage_nans(Xc, yc)

        Xc, yc = self._scale(Xc, yc)

        Xc, yc = validate_data(
            self,
            Xc,
            yc,
            reset=True,
            skip_check_array=False,
            accept_sparse=False,
            y_numeric=True,
            multi_output=True,
            force_writeable=True,
        )

        if isinstance(X, pd.DataFrame):
            Xc = pd.DataFrame(Xc, columns=X.columns, index=X.index[keep_mask])

        if not self.allow_multitask:
            if yc.ndim > 1 and yc.shape[1] > 1:
                LOGGER.info("y is a multi-output array. Average will be used.")
                yc = np.mean(yc, axis=1)

        Xc = Xc.astype(self.dtype)
        yc = yc.astype(self.dtype)
        return Xc, yc, keep_mask

    def transform(self, X, **kwargs):
        """
        Transforms the feature matrix (X) based on the selected features.

        Parameters:
            X: Feature matrix (mode x cids).

        Returns:
            pd.DataFrame:
               Relevant feature matrix
                (mode x selected cids).
        """
        check_is_fitted(self, "estimator_")
        if isinstance(X, pd.DataFrame):
            return X.iloc[:, self.get_support()]
        else:
            return X[:, self.get_support()]

    @abstractmethod
    def fit(self, X, y, **fit_params: dict):
        """
        Fits the model to the data.
        Must be implemented in subclasses.

        It is recommended to use the following pattern:
        - Preprocess the data using the :py:func:`preprocess` method
        - Store the preprocessed data in the :py:attr:`X_` and :py:attr:`Y_` attributes
        - Fit the estimator using the preprocessed data

        Example

        .. code-block:: python

            estimator = self._get_estimator()
            Xc, yc, keep_mask = self.preprocess(X, y)
            self.X_ = Xc
            self.Y_ = yc
            self.estimator_ = estimator.fit(Xc, yc)

        Parameters:
            X: Feature matrix (mode x cids).
            y: Target matrix (mode x time) or array (mode).
            fit_params (dict): Additional parameters for fitting.
        """
        pass

    @abstractmethod
    def _get_support_mask(self):
        """
        Returns the mask of the selected features.
        Must be implemented in subclasses.
        """
        pass
