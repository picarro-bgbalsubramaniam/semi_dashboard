"""
Iterative PLS regression for feature removal
"""

import numpy as np
import pandas as pd
from scipy.stats import sem
from sklearn.base import BaseEstimator
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import (
    BaseCrossValidator,
    ShuffleSplit,
    check_cv,
    cross_validate,
)
from sklearn.preprocessing import StandardScaler

from compound_hunting.assessment.utils import one_standard_error_rule, vip_scores
from compound_hunting.logger import get_logger
from compound_hunting.preprocessing.global_scaler import GlobalScaler
from compound_hunting.transformers.template_transformer import BaseHuntingTransformer

LOGGER = get_logger(__name__)


DEFAULT_CV = ShuffleSplit(n_splits=20, test_size=0.25, train_size=0.75, random_state=42)


class PLSRegressionTransformer(BaseHuntingTransformer):
    """
    A transformer that performs iterative Partial Least Squares (PLS)
    regression for feature removal.

    This transformer fits a PLS model, determines the optimal number of components
    using cross-validation and the one standard error rule, and calculates
    feature importances using VIP scores.

    Attributes:
        max_n_components (int):
            Maximum number of PLS components to consider.
        vip_threshold (float):
            Threshold for VIP scores to select important features.
            Usually set to 1.0, or 0.9 to be more conservative
            and maintain more features in the result.
        tol (float):
            Minimum standard error to consider.
            Defaults to 1e-2.
        cv (BaseCrossValidator):
            Cross-validation strategy.
        n_jobs (int):
            Number of jobs to run in parallel.
        feature_importances_ (np.ndarray):
            VIP scores for each feature.
        n_components_ (int):
            Optimal number of components selected.
        estimator_ (PLSRegression):
            Fitted PLS model.
        threshold_ (float):
            Threshold for VIP scores to select important features.
    """

    def __init__(
        self,
        cv: BaseCrossValidator = DEFAULT_CV,
        nan_threshold: float = 0.1,
        scaler_x: BaseEstimator = StandardScaler().set_output(transform="pandas"),
        scaler_y: BaseEstimator = GlobalScaler(),
        dtype: np.dtype = np.float32,
        allow_multitask: bool = True,
        max_n_components: int = 10,
        vip_threshold: float = 1.0,
        tol: float = 1e-2,
        n_jobs: int = None,
    ):
        super().__init__(
            nan_threshold=nan_threshold,
            scaler_x=scaler_x,
            scaler_y=scaler_y,
            dtype=dtype,
            allow_multitask=allow_multitask,
        )
        self.max_n_components = max_n_components
        self.vip_threshold = vip_threshold
        self.eps = tol
        self.cv = cv
        self.n_jobs = n_jobs

    def fit(
        self,
        X: np.ndarray | pd.DataFrame,
        y: np.ndarray | pd.Series | pd.DataFrame,
    ) -> "PLSRegressionTransformer":
        """
        Fit the PLSRegressionTransformer to the input data.

        First, the optimal number of components is selected using cross-validation
        and the one standard error rule.
        Then, the feature importances are calculated using VIP scores.
        Features with a VIP score greater than the threshold are selected.

        Args:
            X (np.ndarray | pd.DataFrame): The design matrix ``(modes, cids)``.
            y (np.ndarray | pd.Series | pd.DataFrame): The spectrum ``(mode,)`` or ``(mode, time)``.

        Returns:
            PLSRegressionTransformer: The fitted transformer.
        """
        n_features = X.shape[1]
        self.feature_names_ = X.columns if hasattr(X, "columns") else range(n_features)

        Xu, yu, _ = self.preprocess(X, y)
        cv = check_cv(self.cv)

        rmse = []
        se = []
        expl_variance = []
        expl_se = []

        scoring = ["neg_root_mean_squared_error", "r2"]

        n_comps = np.arange(min(self.max_n_components, X.shape[1]), 0, -1)
        for i in n_comps:
            score = cross_validate(
                estimator=PLSRegression(n_components=i),
                X=Xu,
                y=yu,
                cv=cv,
                scoring=scoring,
                n_jobs=self.n_jobs,
            )
            rmse.append(-score["test_neg_root_mean_squared_error"].mean())
            se.append(sem(score["test_neg_root_mean_squared_error"]))
            expl_variance.append(score["test_r2"].mean())
            expl_se.append(sem(score["test_r2"]))

        idx_one_se, _ = one_standard_error_rule(
            scores=rmse, std_errors=se, min_std_error=self.eps, how="last"
        )
        selected_n_components = n_comps[idx_one_se]

        self.mse_path_ = np.array(rmse)
        self.mse_se_path_ = np.array(se)
        self.expl_variance_path_ = np.array(expl_variance)
        self.expl_variance_se_path_ = np.array(expl_se)
        self.n_components_path_ = n_comps
        self.n_components_ = selected_n_components

        pls = PLSRegression(n_components=selected_n_components).fit(Xu, yu)

        scores = vip_scores(
            x_weights=pls.x_rotations_,
            x_scores=pls.x_scores_,
            y_loadings=pls.y_loadings_,
        )
        self.threshold_ = self.vip_threshold
        self.feature_importances_ = scores
        self.estimator_ = pls

        return self

    def _get_support_mask(self):
        return self.feature_importances_ > self.threshold_
