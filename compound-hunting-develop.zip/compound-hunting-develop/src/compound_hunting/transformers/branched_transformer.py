import math
from typing import Callable

import jax.numpy as jnp
import numpy as np
import pandas as pd
from jax.lax import top_k
from jax.typing import ArrayLike
from pydantic import Field, validate_call
from sklearn.base import BaseEstimator
from sklearn.model_selection import BaseCrossValidator, ShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.utils.validation import check_is_fitted

from compound_hunting.assessment.metrics import rmse_metric
from compound_hunting.compute.branched_sequential_selector import (
    branched_sequential_selector,
)
from compound_hunting.logger import get_logger
from compound_hunting.preprocessing.cross_validation import get_jax_train_test_split
from compound_hunting.preprocessing.global_scaler import GlobalScaler
from compound_hunting.transformers.template_transformer import BaseHuntingTransformer

DEFAULT_CV = ShuffleSplit(n_splits=20, test_size=0.25, train_size=0.75, random_state=42)

LOGGER = get_logger(__name__)


@validate_call()
def create_exponential_decay_fn(
    initial_value: int = Field(ge=1),
    decay_rate: float = Field(ge=0, le=1),
) -> Callable[[int], int]:
    """Create a decay function with given initial value and decay rate."""

    def decay_fn(d: int) -> int:
        return max(1, round(initial_value * math.exp(-decay_rate * d)))

    return decay_fn


slow_decay_fn = create_exponential_decay_fn(initial_value=40, decay_rate=0.7)
fast_decay_fn = create_exponential_decay_fn(initial_value=20, decay_rate=0.9)


class BranchedTransformer(BaseHuntingTransformer):
    def __init__(
        self,
        cv: BaseCrossValidator = None,
        batch_size: int = 10,
        metric: Callable[[ArrayLike, ArrayLike, ArrayLike], float] = rmse_metric,
        metric_lower_is_better: bool = True,
        n_features: int = 10,
        nan_threshold: float = 0.1,
        tol: float | None = None,
        scaler_x: BaseEstimator = StandardScaler(with_std=False).set_output(
            transform="pandas"
        ),
        scaler_y: BaseEstimator = GlobalScaler(with_std=False),
        dtype: np.dtype = np.float32,
        allow_multitask: bool = False,
        decay_fn: Callable[[int], int] = fast_decay_fn,
        positive: bool = False,
        show_progress: bool = True,
    ):
        """
        Initialize the BranchedTransformer.

        It uses a score maximization approach to select features.
        The score is calculated using the provided metric function.

        Args:
            cv (BaseCrossValidator):
                Cross-validator strategy. If None, no cross-validation is performed.
            batch_size (int):
                Size of batches for vectorized processing.
                Reduce (down to 1) if you encounter memory issues.
            metric (Callable):
                Metric function for evaluation.
                Must take arguments (X, y, y_pred) and return a float metric.
                Example is :py:func:`compound_hunting.assessment.metrics.bic_metric`.
            metric_lower_is_better (bool):
                Set to True if lower metric values are better.
                If True, the score function will return the negative of the metric.
            n_features (int):
                Maximum number of features to select. The search will continue
                until either this many features are selected or the tolerance
                criterion is met.
            nan_threshold (float):
                Threshold for NaN values. Default is 0.1.
            tol (float | None):
                Convergence tolerance. The search stops when the score improvement
                falls below this value. If None, the search continues until
                ``n_features`` is reached. Defaults to None.
            scaler_x (BaseEstimator):
                Scaler for input features.
                Default is :py:class:`sklearn.preprocessing.StandardScaler`.
            scaler_y (BaseEstimator):
                Scaler for target variable.
                Default is :py:class:`compound_hunting.preprocessing.global_scaler.GlobalScaler`.
            dtype (np.dtype):
                Data type for computations.
            allow_multitask (bool):
                Whether to allow multitask evaluation.
                This transformer does not support multitask evaluation.
            decay_fn (Callable):
                Function to compute number of solutions to keep as function of the depth.
                Best to use a convergent series. If you encounter memory issues,
                try to reduce the number of solutions to keep at each depth.
                It must take a depth (int) and return an int (number of solutions to keep).
                Default is :py:func:`slow_decay_fn`.
            positive (bool):
                If True, use non-negative least squares solver.
            show_progress (bool):
                Whether to display progress during fitting.
                Defaults to True.
        """
        self.cv = cv
        self.batch_size = batch_size
        self.metric = metric
        self.metric_lower_is_better = metric_lower_is_better
        self.n_features = n_features
        self.nan_threshold = nan_threshold
        self.scaler_x = scaler_x
        self.scaler_y = scaler_y
        self.dtype = dtype
        self.decay_fn = decay_fn
        self.positive = positive
        self.tol = tol
        self.show_progress = show_progress
        if allow_multitask:
            LOGGER.warning(
                "Branched transformer does not allow for multitask evaluation. "
                "Setting allow_multitask to False."
            )
        self.allow_multitask = False

    def _setup_score_function(self) -> Callable:
        """Set up the score function based on the metric and whether lower is better."""
        if self.metric_lower_is_better:
            LOGGER.debug(
                "Metric is lower is better. Using negative metric as maximization objective."
            )
            return lambda *args: -self.metric(*args)
        return self.metric

    def fit(
        self,
        X: np.ndarray | pd.DataFrame,
        y: np.ndarray | pd.Series | pd.DataFrame,
    ) -> "BranchedTransformer":
        """
        Fit the BranchedTransformer to the input data.

        Args:
            X (np.ndarray | pd.DataFrame): The design matrix ``(modes, cids)``.
            y (np.ndarray | pd.Series | pd.DataFrame): The spectrum ``(mode,)`` or ``(mode, time)``.

        Returns:
            BranchedTransformer: The fitted transformer.
        """
        n_features = X.shape[1]
        self.feature_names_ = X.columns if hasattr(X, "columns") else range(n_features)

        Xc, yc, _ = self.preprocess(X, y)
        Xu, yu = jnp.asarray(Xc), jnp.asarray(yc)

        train_indices, test_indices = get_jax_train_test_split(X=Xu, y=yu, cv=self.cv)

        results = branched_sequential_selector(
            X=Xu,
            y=yu,
            train_indices=train_indices,
            test_indices=test_indices,
            decay_fn=self.decay_fn,
            scorer_fn=self._setup_score_function(),
            depth=self.n_features,
            batch_size=self.batch_size,
            show_progress=self.show_progress,
            positive=self.positive,
            tol=self.tol,
        )
        self.results_ = results
        self._set_support_mask()
        return self

    @property
    def search_depth(self) -> int:
        """
        Get the depth at which the search stopped.
        """
        if not hasattr(self, "results_"):
            raise ValueError(
                "Results not found. Fit the model first with ``fit()`` method."
            )
        last_depth = list(self.results_.keys())[-1]
        return last_depth

    def _get_depth_results(
        self, depth: int, top_n: int | None = 100
    ) -> tuple[list[tuple], np.ndarray, np.ndarray]:
        """
        Get the top feature combinations and their scores for a given depth.

        Args:
            depth (int): The depth to retrieve results for.
            top_n (Optional[int]): The number of top results to return. Defaults to 100.

        Returns:
            Tuple[List[Tuple], np.ndarray, np.ndarray]:
                A tuple containing top combinations, scores, and indexes.

        Raises:
            ValueError: If the model hasn't been fitted yet.
        """
        if not hasattr(self, "results_"):
            raise ValueError(
                "Results not found. Fit the model first with ``fit()`` method."
            )

        if depth > self.search_depth:
            raise ValueError(
                f"Depth {depth} is greater than "
                f"the maximum search depth achieved {self.search_depth}."
            )

        sols, scores = self.results_[depth]
        feature_names = self.feature_names_

        # if top_n is not provided, return all solutions
        top_n = min(top_n or len(scores), len(scores))

        top_scores, final_top_indices = top_k(scores, k=top_n)

        # get feature names for each solution
        top_combinations = [
            tuple(sorted(feature_names[int(idx)] for idx in sols[i]))
            for i in final_top_indices
        ]
        top_indexes = np.asarray(sols[final_top_indices])
        top_scores = (
            -np.asarray(top_scores)
            if self.metric_lower_is_better
            else np.asarray(top_scores)
        )
        return top_combinations, top_scores, top_indexes

    def _set_support_mask(self):
        """
        Set the support mask based on the best feature combination.
        """
        check_is_fitted(self, "results_")

        # get best combo for each depth
        df = self.get_results(depth=None, top_n=1)

        # get best of all depths
        deltas = df.score.diff(-1).abs()
        converged = deltas < self.tol

        if converged.any():
            best_row_idx = converged.idxmax()
        else:
            best_row_idx = (
                df.score.idxmin() if self.metric_lower_is_better else df.score.idxmax()
            )
        best_row = df.loc[best_row_idx]

        self.support_ = np.array(
            [feat in best_row.features for feat in self.feature_names_]
        )
        self.top_scores_ = best_row.score
        self.top_combinations_ = best_row.features
        self.estimator_ = self.support_

    def _get_support_mask(self):
        """
        Get the support mask for the selected features.

        Returns:
            np.ndarray: Boolean array indicating selected features.
        """
        check_is_fitted(self, "results_")
        return self.support_

    def get_feature_names_out(self, input_features=None):
        """
        Get the names of the selected features.

        Args:
            input_features (Optional[List[str]]):
                List of input feature names.
                If None, uses the feature names from fitting.

        Returns:
            np.ndarray: Array of selected feature names.
        """
        check_is_fitted(self, "feature_names_")
        if input_features is None:
            input_features = self.feature_names_
        return np.array(input_features)[self.support_]

    def get_results(self, depth: int | None = None, top_n: int | None = 100):
        """
        Get the top feature combinations and their scores.

        Args:
            depth (int | None):
                The depth to retrieve results for.
                If None, results for all depths up to self.n_features are concatenated.
            top_n (int | None):
                The number of top results to return for each depth.
                If None, all results are returned.

        Returns:
            pd.DataFrame:
                A DataFrame containing the scores, feature combinations,
                and number of features for the top results.
        """
        check_is_fitted(self, ["results_"])

        if depth is None:
            # get results for all depths
            all_combinations = []
            all_scores = []
            for d in range(self.search_depth + 1):
                combinations, scores, _ = self._get_depth_results(depth=d, top_n=top_n)
                all_combinations.extend(combinations)
                all_scores.extend(scores)
        else:
            # get results for a specific depth
            all_combinations, all_scores, _ = self._get_depth_results(
                depth=depth, top_n=top_n
            )

        return pd.DataFrame(
            {
                "score": all_scores,
                "features": all_combinations,
                "n_features": [len(comb) for comb in all_combinations],
            }
        )
