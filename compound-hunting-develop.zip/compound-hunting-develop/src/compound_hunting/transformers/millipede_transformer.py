"""Scikit-learn compatible transformer for Bayesian variable selection using the millipede algorithm.

This module provides a scikit-learn compatible transformer that implements the isotropic
millipede model for Bayesian variable selection. The transformer supports both single-task
and multi-task learning scenarios, with built-in data preprocessing and feature selection
based on posterior inclusion probabilities. For more details, refer to the paper
'Bayesian Variable Selection in a Million Dimensions'.
"""

import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator
from sklearn.preprocessing import StandardScaler
from sklearn.utils.validation import check_is_fitted

from compound_hunting import __version__
from compound_hunting.logger import get_logger
from compound_hunting.millipede.contribution_analysis import (
    calculate_pfi_ratio,
    compute_areas,
    spectral_contributions_breakdown,
)
from compound_hunting.millipede.export_samples import get_arviz_inference_data
from compound_hunting.millipede.mcmc_statistics import aggregate_chain_results
from compound_hunting.millipede.millipede_isotropic import isotropic_millipede
from compound_hunting.millipede.time_resolved_regression import (
    propagate_model_to_time_series,
)
from compound_hunting.millipede.trustworthiness import (
    TrustworthinessCheck,
    default_trustworthiness_check,
)
from compound_hunting.preprocessing.scale_factors import get_scale_factors
from compound_hunting.transformers.template_transformer import BaseHuntingTransformer

LOGGER = get_logger(__name__)

# ruff: noqa: E731


class MillipedeTransformer(BaseHuntingTransformer):
    """A scikit-learn transformer for Bayesian variable selection using the millipede algorithm.

    This transformer implements the isotropic millipede model for Bayesian variable selection,
    supporting both single-task and multi-task learning. It performs MCMC sampling to estimate
    posterior inclusion probabilities for each feature and selects features based on a threshold.
    If multi-task, each task/target is processed independently (useful for batch processing).

    Args:
        sample (int, optional): Number of MCMC samples to draw after tuning. Defaults to 2000.
        tune (int, optional): Number of tuning steps before sampling. Defaults to 1000.
        chains (int, optional): Number of parallel MCMC chains to run. Defaults to 4.
        threshold (float, optional):
            Threshold on posterior inclusion probability for feature selection.
            Default is 0.75.
        scaler_x (BaseEstimator, optional):
            Scikit-learn transformer for scaling features. Defaults to StandardScaler.
        scaler_y (BaseEstimator, optional):
            Scikit-learn transformer for scaling targets. Defaults to StandardScaler.
        nan_threshold (float, optional):
            Threshold ratio of NaNs in y to raise an error.
            Default is 0.1. Must be between 0 and 1.
        s (float, optional):
            Expected number of covariates to include in the model a priori.
            Does NOT determine the final number of features selected.
            Defaults to 1.0.
        tau (float, optional):
            Precision parameter for the isotropic prior on coefficients.
            This corresponds to a "ridge" regularization parameter.
            Lower values correspond to weaker regularization, and might results in
            less bias but more variance, with the risk of numerical instability
            due to collinearity. Stronger regularization will result in more
            shrinkage of the coefficients towards zero and better numerical stability.
            Defaults to 0.01.
        tau_intercept (float, optional):
            Precision parameter for the intercept term.
            Defaults to 1.0e-4.
        nu0 (float, optional):
            Shape parameter for inverse gamma prior on noise variance.
            This represents the "degree of belief" in the prior estimate of the variance
            of the noise in the spectrum ``lambda0``.
            Low values represent low confidence in the prior estimate, i.e., a prior
            that is more diffuse (weakly informative prior).
            High values represent high confidence, i.e., a prior that is more concentrated
            and influential.
            Very low nu0 and lambda0 will result in a prior that is uninformative, but they
            can create numerical stability issues.
            Defaults to 0.1.
        lambda0 (float, optional):
            Scale parameter for inverse gamma prior on noise variance.
            It's a prior estimate of the variance $\sigma^2$ of the noise in the spectrum.
            Low values will correspond to low expected noise, and vice versa.
            Defaults to 0.01.
            Remember that a spectrum is transformed (based on ``scaler_y``)
            before being used in the model, so this parameter is in the scale
            of the transformed spectra.
            Very low nu0 and lambda0 will result in a prior that is uninformative, but they
            can create numerical stability issues.
        explore (float, optional):
            Controls MCMC exploration vs exploitation. Higher values
            lead to more exploration. Defaults to 5.
        seed (int, optional):
            Random seed for reproducibility. Defaults to 0.
        batch_size (int, optional):
            Maximum number of spectra to analyze in parallel.
            If out-of-memory errors are encountered, reduce this number.
            Defaults to 5.
        max_active (int | None, optional):
            Maximum number of active features allowed.
            If None, defaults to N/10 where N is number of samples. Defaults to None.
            If the model hits and passes this limit, it means that the feature space is too large
            for the model to handle, and the results may be unreliable (check the results
            diagnostics to see if this is the case). Increasing precision (using dtype=np.float64)
            generally helps, as well as increasing ``tau``,``lambda0``,``nu0`` to solve a problem
            that is better conditioned.
        return_samples (bool, optional):
            Whether to store raw MCMC samples. Defaults to False.
        return_diagnostics (bool, optional):
            Whether to compute and store MCMC diagnostics.
            Defaults to True.
        allow_multitask (bool, optional):
            Whether to allow multiple target variables.
            If False, and y is a DataFrame, the columns will be averaged.
            Defaults to True.
        dtype (np.dtype, optional):
            Data type for computations. Using float32 may degrade
            performance in some situations. Defaults to np.float32.
            Using float64 is recommended for better convergence and on CPU.
            On GPU, float32 is recommended for lower memory usage
            and faster execution. If convergence issues are encountered,
            try using float64.

    Note:
        Using dtype=np.float32 can lead to degraded performance with complex datasets.
        Check R-hat and ESS values as diagnostics for chain performance and consider
        using dtype=np.float64 for better convergence at the cost of slower execution.
    """

    def __init__(
        self,
        sample: int = 2000,
        tune: int = 1000,
        chains: int = 4,
        threshold: float = 0.75,
        scaler_x: BaseEstimator = StandardScaler().set_output(transform="pandas"),
        scaler_y: BaseEstimator = StandardScaler().set_output(transform="pandas"),
        nan_threshold: float = 0.1,
        s: float = 1.0,
        tau: float = 0.01,
        tau_intercept: float = 1.0e-4,
        nu0: float = 0.1,
        lambda0: float = 0.01,
        explore: float = 5,
        seed: int = 0,
        batch_size: int = 5,
        max_active: int | None = None,
        return_samples: bool = False,
        return_diagnostics: bool = True,
        allow_multitask: bool = True,
        dtype: np.dtype = np.float32,
        assumed_covariates: list[int | str] | None = None,
    ):
        self.sample = sample
        self.tune = tune
        self.chains = chains
        self.s = s
        self.tau = tau
        self.tau_intercept = tau_intercept
        self.nu0 = nu0
        self.lambda0 = lambda0
        self.explore = explore
        self.seed = seed
        self.batch_size = batch_size
        self.max_active = max_active
        self.return_samples = return_samples
        self.return_diagnostics = return_diagnostics
        self.allow_multitask = allow_multitask
        self.threshold = threshold
        self.dtype = dtype
        self.scaler_x = scaler_x
        self.scaler_y = scaler_y
        self.nan_threshold = nan_threshold
        self.assumed_covariates = assumed_covariates

    def fit(
        self,
        X: np.ndarray | pd.DataFrame,
        y: np.ndarray | pd.Series | pd.DataFrame,
        weights: np.ndarray | pd.Series | None = None,
    ) -> "MillipedeTransformer":
        """Fit the MillipedeTransformer to the input data.

        Performs Bayesian variable selection using the millipede algorithm. For each target
        variable, estimates posterior inclusion probabilities (PIPs) for each feature through
        MCMC sampling. Features with PIPs above the threshold are selected.

        Args:
            X (np.ndarray | pd.DataFrame):
                The design matrix with shape (n_samples, n_features).
                If DataFrame, column names are used as feature names.
                It shall NOT contain an intercept column.
            y (np.ndarray | pd.Series | pd.DataFrame):
                Target variable(s). For single-task, should be 1D array-like with shape
                (n_samples,). For multi-task, should be 2D array-like with shape
                (n_samples, n_targets). If DataFrame, column names are used as target names.
            weights (np.ndarray | pd.Series | None, optional):
                Sample weights for weighted regression. Must have shape (n_samples,).
                If None, uniform weights are used (equivalent to unweighted regression).
                The same weights are applied to all targets. Defaults to None.

        Returns:
            MillipedeTransformer: The fitted transformer.

        Raises:
            ValueError: If input shapes are incompatible, if NaN ratio in y exceeds
                nan_threshold, if weights shape doesn't match n_samples, or if any
                weights are non-positive.
        """
        n_features = X.shape[1]
        n_samples_original = X.shape[0]

        if y.ndim == 1:
            y = np.array(y)[:, np.newaxis]
            self.datasets_names_ = ["y"]
        else:
            self.datasets_names_ = (
                y.columns.tolist() if hasattr(y, "columns") else range(y.shape[1])
            )

        if self.assumed_covariates is None:
            assumed_covariates_idx = jnp.array([], dtype=int)
        else:
            assumed_covariates_idx = jnp.array(
                [X.columns.get_loc(c) for c in self.assumed_covariates],
                dtype=int,
            )

        Xc, yc, keep_mask = self.preprocess(X, y)

        # Handle weights
        if weights is None:
            weights_array = np.ones(n_samples_original, dtype=self.dtype)
        else:
            weights_array = np.array(weights)

            # Validate shape
            if weights_array.shape != (n_samples_original,):
                raise ValueError(
                    f"weights must have shape (n_samples,), got {weights_array.shape}. "
                    f"Expected ({n_samples_original},)."
                )

            # Validate all weights are positive
            if np.any(weights_array <= 0):
                raise ValueError(
                    "All weights must be positive. Found non-positive weights."
                )

        # Filter weights using keep_mask
        weights_filtered = weights_array[keep_mask]

        # Convert Xc and yc to numpy arrays for matrix operations
        Xc_array = np.array(Xc) if not isinstance(Xc, np.ndarray) else Xc
        yc_array = np.array(yc) if not isinstance(yc, np.ndarray) else yc

        # Apply weights: W_half = diag(sqrt(weights))
        W_half = np.diag(np.sqrt(weights_filtered))
        X_tilde = W_half @ Xc_array
        y_tilde = W_half @ yc_array

        # X = (n_samples, n_features), y = (n_samples, n_targets)
        scale_X = get_scale_factors(
            self.scaler_x, Xc.shape[1] + 1, "scale_"
        )  # add intercept
        scale_Y = get_scale_factors(self.scaler_y, yc.shape[1], "scale_")

        mean_X = get_scale_factors(self.scaler_x, Xc.shape[1] + 1, "mean_")

        mean_Y = get_scale_factors(self.scaler_y, yc.shape[1], "mean_")

        self.feature_names_ = (
            np.array([0] + X.columns.tolist())
            if hasattr(X, "columns")
            else np.arange(n_features + 1)
        )

        frequencies = (
            Xc.index.values if hasattr(Xc, "index") else np.arange(Xc.shape[0])
        )
        area_X, area_Y = compute_areas(
            X=X.loc[keep_mask],
            Y=yc * scale_Y + mean_Y,
            frequencies=frequencies,
            add_intercept=True,
        )
        area_X = pd.Series(area_X[:, 0], index=self.feature_names_)
        area_Y = pd.Series(area_Y, index=self.datasets_names_)

        run_millipede = lambda xlambda, ylambda: isotropic_millipede(
            X=xlambda,
            Y=ylambda,
            sample=self.sample,
            tune=self.tune,
            chains=self.chains,
            s=self.s,
            tau=self.tau,
            tau_intercept=self.tau_intercept,
            nu0=self.nu0,
            lambda0=self.lambda0,
            explore=self.explore,
            seed=self.seed,
            batch_size=self.batch_size,
            max_active=self.max_active,
            return_samples=self.return_samples,
            return_diagnostics=self.return_diagnostics,
            scale_X=scale_X,
            scale_Y=scale_Y,
            mean_X=mean_X,
            mean_Y=mean_Y,
            assumed_covariates_idx=assumed_covariates_idx,
        )  # noqa: E731

        if self.dtype == np.float64:
            LOGGER.debug("Running millipede in double precision")
            with jax.experimental.enable_x64():
                Xu, yu = (
                    jnp.array(X_tilde.astype(self.dtype)),
                    jnp.array(y_tilde.T.astype(self.dtype)),
                )
                summary, diagnostics, samples = run_millipede(Xu, yu)
        else:
            LOGGER.debug(
                "Using dtype=np.float32 can lead to degraded performance with complex datasets. "
                "Please check R-hat and ESS values as diagnostics for chain performance. "
                "Consider using dtype=np.float64 for better convergence (but slower execution)."
            )
            Xu, yu = (
                jnp.array(X_tilde.astype(self.dtype)),
                jnp.array(y_tilde.T.astype(self.dtype)),
            )
            summary, diagnostics, samples = run_millipede(Xu, yu)

        self.results_ = summary
        self.diagnostics_ = diagnostics
        self.samples_ = samples
        self.area_x_ = area_X
        self.area_y_ = area_Y
        self.chain_results_ = aggregate_chain_results(
            diagnostics=self.diagnostics_,
            results=self.results_,
            area_x=self.area_x_.values,
        )
        self._set_support_mask()
        return self

    def propagate_time_series(
        self,
        X: pd.DataFrame,
        Y: pd.DataFrame,
        n: int = 500,
        seed: int = 42,
        weights: pd.Series | np.ndarray | None = None,
    ) -> pd.DataFrame:
        """Propagates the fitted model over a time series Y.

        This method uses the MCMC samples from the fitted model to compute
        time-resolved beta coefficients for a new time series dataset Y.

        Args:
            X (pd.DataFrame): The design matrix with shape (n_samples, n_features).
                It shall NOT contain an intercept column.
            Y (pd.DataFrame): Time series data with shape (n_samples, n_time_steps).
            n (int, optional): Number of samples to draw from the posterior. Defaults to 500.
            seed (int, optional): Random seed for reproducibility. Defaults to 42.
            weights (pd.Series | np.ndarray | None, optional):
                Sample weights with shape (n_samples,).
                If None, uniform weights are used. Defaults to None.

        Returns:
            pd.DataFrame: A DataFrame with time-resolved beta coefficients,
                their standard deviation, and posterior inclusion probabilities.

        Raises:
            NotFittedError: If the transformer has not been fitted.
            ValueError: If samples were not stored (return_samples=False).
            ValueError: If the samples have more than one target.
            ValueError: If weights shape doesn't match n_samples.
            ValueError: If any weights are non-positive.
        """
        check_is_fitted(self, ["samples_", "feature_names_"])

        n_samples_original = X.shape[0]

        if self.samples_ is None:
            raise ValueError(
                "No samples to use for propagation. "
                "Please set ``return_samples=True`` during initialization."
            )

        samples_shape = self.samples_.gamma.shape

        if (len(samples_shape) == 4) and (
            samples_shape[0] > 1
        ):  # (targets, chains, draws, compounds + 1)
            raise ValueError(
                "Time-series propagation only supports a single target. "
                "Please fit the transformer with a single target dataset."
            )

        # Handle weights
        if weights is None:
            weights_array = np.ones(n_samples_original, dtype=self.dtype)
        else:
            weights_array = np.array(weights)

            # Validate shape
            if weights_array.shape != (n_samples_original,):
                raise ValueError(
                    f"weights must have shape (n_samples,), got {weights_array.shape}. "
                    f"Expected ({n_samples_original},)."
                )

            # Validate all weights are positive
            if np.any(weights_array <= 0):
                raise ValueError(
                    "All weights must be positive. Found non-positive weights."
                )

        return propagate_model_to_time_series(
            samples=self.samples_,  # (targets, chains, draws, compounds + 1)
            X=X,  # (n_samples, n_features)
            Y=Y,  # (n_samples, n_times)
            feature_names=self.feature_names_,  # (n_features + 1,)
            n=n,
            seed=seed,
            dtype="float64"
            if self.dtype == np.float64
            else "float32",  # data type for computations
            weights=weights_array,
        )

    def _set_support_mask(self):
        """Set the support mask based on posterior inclusion probabilities.

        For each target variable, creates a boolean mask indicating which features
        have posterior inclusion probabilities above the threshold. These masks
        are stored in the support_ attribute and used for feature selection.
        """
        check_is_fitted(self, "results_")

        # (n_spectra, n_features)
        pip = self.results_.pip

        n_spectra = pip.shape[0]
        # we need to remove the intercept
        self.support_ = [
            np.array(pip[i, 1:]) > self.threshold for i in range(n_spectra)
        ]
        self.estimator_ = self.support_

    def _get_support_mask(self):
        """Get the support mask for the selected features.
        It returns the first support mask, which is the one for the first target variable,
        for compatibility with the other transformers (that expect a single boolean mask).

        Returns:
            list[np.ndarray]: List of boolean arrays indicating selected features for each
                target variable. Each array has shape (n_features,).
        """
        check_is_fitted(self, "results_")
        return self.support_[0]

    def get_feature_names_out(
        self, input_features=None
    ) -> list[np.ndarray] | np.ndarray:
        """Get the names of the selected features.

        Args:
            input_features (Optional[List[str]]):
                List of input feature names. If None, uses the feature names from fitting.
                Default is None.

        Returns:
            Union[np.ndarray, List[np.ndarray]]:
                For single-task: Array of selected feature names.
                For multi-task: List of arrays of selected feature names for each target.

        Raises:
            NotFittedError: If the transformer has not been fitted.
        """
        check_is_fitted(self, "feature_names_")
        if input_features is None:
            # need to remove the intercept
            input_features = self.feature_names_[1:]

        support = self.support_
        # If there's only one support mask, return a single array
        if len(support) == 1:
            return np.array(input_features[support[0]])
        # Otherwise return a list of arrays
        return [np.array(input_features[support[i]]) for i in range(len(support))]

    def get_results(self):
        """Get detailed results from the MCMC sampling.

        Returns a DataFrame containing posterior inclusion probabilities (PIPs) and
        MCMC diagnostics (if computed) for each feature and target variable.

        Returns:
            pd.DataFrame: DataFrame with MultiIndex columns:
                - Level 0: Target variable names
                - Level 1: Statistics ('pip_mean', 'pip_std', 'rhat', 'ess')
                Index: Feature names
                Values:
                    - pip_mean: Mean posterior inclusion probability
                    - pip_std: Standard deviation of posterior inclusion probability
                    - rhat: R-hat convergence diagnostic (if return_diagnostics=True)
                    - ess: Effective sample size (if return_diagnostics=True)

        Raises:
            NotFittedError: If the transformer has not been fitted.
        """
        check_is_fitted(self, ["results_"])

        stat_names = [
            "pip_mean",
            "rhat",
            "ess",
            "beta_mean",
            "beta_std",
            "contribution",
        ]

        columns = pd.MultiIndex.from_product(
            [self.datasets_names_, stat_names], names=["dataset", "stat"]
        )
        data = self.chain_results_.reshape(len(columns), len(self.feature_names_))

        df = pd.DataFrame(
            data.T,
            columns=columns,
            index=pd.Index(self.feature_names_, name="cid"),
        )
        return df

    def get_inference_data(self):
        """Get the inference data for the MCMC samples in ArviZ format.

        This function uses the `export_samples` module to convert the MCMC samples
        into an ArviZ InferenceData object.
        It requires ``return_samples=True`` in the constructor,
        and the `arviz` package to be installed.

        Returns:
            arviz.InferenceData: The inference data for the MCMC samples.
        """
        check_is_fitted(self, ["samples_"])

        if self.samples_ is None:
            raise ValueError(
                "No samples to export. Did you remember to set ``return_samples=True``?"
            )

        return get_arviz_inference_data(
            samples=self.samples_,
            cid_names=self.feature_names_,
            datasets_names=self.datasets_names_,
        )

    def get_metadata(
        self,
        exclude_cids: list[int] | None = None,
        trustworthiness_check: TrustworthinessCheck | None = None,
    ):
        """Summarize contribution and PFI diagnostics for each dataset.

        Uses the "contribution" slice from :py:meth:`get_results()` and the per‑dataset
        partial‑fit integrals computed at fit time. Optionally excludes specific
        CIDs from the accounting (see :py:func:`spectral_contributions_breakdown`).

        Args:
            exclude_cids (list[int] | None):
                CIDs to exclude; if None, the breakdown's default is used.
            trustworthiness_check (TrustworthinessCheck | None):
                Optional callable to evaluate whether each dataset is modelable.
                It receives two vectors, (`pfi_ratio`, `adjusted_pfi`), and must
                return a boolean vector of the same length. If None, a default
                power‑law based check is used: pfi_ratio < a/(b*adjusted_pfi)^n + c
                with a=1.0, b=0.010, n=1.25, c=0.0.

        Returns:
            dict with:
            - `version` (str): Package version.
            - `sigma` (list[float]): Estimated noise standard deviation for each dataset.
            - `pfi_ratio` (list[float]): For each dataset, a ratio computed on
                the adjusted PFI (see `adjusted_pfi`) as:
                abs(negative_pfi) / adjusted_pfi if adjusted_pfi > 0,
                else positive_pfi / abs(adjusted_pfi).
            - `is_modelable` (list[bool]): For each dataset, whether the model can be
                trusted to represent the data according to the trustworthiness check.
            - `sample` (int): Number of MCMC samples drawn after tuning.
            - `tune` (int): Number of tuning steps before sampling.
            - `chains` (int): Number of parallel MCMC chains run.
            - `s` (float): Expected number of covariates to include in the model a priori.
            - `tau` (float): Precision parameter for the isotropic prior on coefficients.
            - `tau_intercept` (float): Precision parameter for the intercept term.
            - `nu0` (float): Shape parameter for inverse gamma prior on noise variance.
            - `lambda0` (float): Scale parameter for inverse gamma prior on noise variance.
            - `explore` (float): MCMC exploration vs exploitation parameter.
            - `max_active` (int | None): Maximum number of active features allowed.
            - `dtype` (str): Data type precision used ("32" or "64").
            - `assumed_covariates` (list[int | str] | None): CIDs assumed to be in the model.
            - `model_pfi` (list[float]): Sum of modeled feature contributions
                after excluding the configured CIDs (see :py:func:`spectral_contributions_breakdown`).
            - `negative_pfi` (list[float]): Sum of contributions < 0, after exclusions.
            - `positive_pfi` (list[float]): Sum of contributions ≥ 0, after exclusions.
            - `offset_pfi` (list[float]): Contribution attributed to the intercept/offset
                feature (CID 0).
            - `raw_pfi` (list[float]): Integral of the target spectrum for each dataset
                (as provided during fit; no exclusions applied).
            - `adjusted_pfi` (list[float]): `raw_pfi` minus the contributions of the
                excluded CIDs (e.g., the "Big 3"), i.e., the reference used for `pfi_ratio`.
            - `datasets_names` (list[str]): Dataset names; all list-valued fields above
                are ordered to match this list.
        """
        check_is_fitted(self, "results_")

        contributions = self.get_results().xs("contribution", level=1, axis=1)

        # offset name is the first feature name that we manually added to self.feature_names_
        offset_name = self.feature_names_[0]

        contrib_breakdown = spectral_contributions_breakdown(
            contributions=contributions,
            pfi=self.area_y_,
            exclude_cids=exclude_cids,
            offset_name=offset_name,
        )
        pfi_ratio = calculate_pfi_ratio(
            total_pfi=contrib_breakdown["adjusted_pfi"],
            negative_pfi=contrib_breakdown["negative_pfi"],
            positive_pfi=contrib_breakdown["positive_pfi"],
        )

        # Compute trustworthiness flags
        checker = trustworthiness_check or default_trustworthiness_check
        adjusted_pfi = contrib_breakdown["adjusted_pfi"]
        is_modelable = np.asarray(checker(pfi_ratio, adjusted_pfi), dtype=bool)

        contrib_breakdown = contrib_breakdown.to_dict(orient="list")
        contrib_breakdown["datasets_names"] = self.datasets_names_

        metadata = {
            "version": __version__,
            "sigma": np.array(self.results_.sigma).tolist(),
            "pfi_ratio": pfi_ratio.tolist(),
            "is_modelable": is_modelable.tolist(),
            "sample": self.sample,
            "tune": self.tune,
            "chains": self.chains,
            "s": self.s,
            "tau": self.tau,
            "tau_intercept": self.tau_intercept,
            "nu0": self.nu0,
            "lambda0": self.lambda0,
            "explore": self.explore,
            "max_active": self.max_active,
            "dtype": "64" if self.dtype == np.float64 else "32",
            "assumed_covariates": self.assumed_covariates,
        }
        metadata.update(contrib_breakdown)
        return metadata

    def check_max_active_constraint(self):
        """Checks if the maximum active features constraint was hit during model fitting.

        This method verifies whether any dataset reached the max_active limit during
        the MCMC sampling process. If a dataset hit this constraint, it means the feature
        selection results for that target may be unreliable.

        Returns:
            bool: True if all datasets are within the max_active limit, False otherwise.

        Raises:
            NotFittedError: If the transformer has not been fitted.
            ValueError: If diagnostics were not computed during fitting (return_diagnostics=False).

        Note:
            If this method returns False, you should consider increasing the max_active parameter
            or using dtype=np.float64 for better numerical stability.
        """
        check_is_fitted(self, ["results_"])

        if not self.return_diagnostics:
            raise ValueError(
                "No diagnostics to check. Did you remember to set ``return_diagnostics=True``?"
            )

        datasets_names = self.datasets_names_
        for i, (dataset_name, within_active_limit) in enumerate(
            zip(datasets_names, self.diagnostics_.within_active_limit)
        ):
            if not within_active_limit:
                LOGGER.error(
                    f"Max active limit reached for dataset '{dataset_name}' (index {i}). "
                    f"The model hit the max_active constraint, which means "
                    f"feature selection results may be unreliable for this target. "
                    f"Please increase the max_active parameter. "
                    f"Alternatively, using dtype=np.float64 can help, too."
                )

        # return False if any of the datasets hit the max_active constraint
        if not self.diagnostics_.within_active_limit.all():
            return False

        return True
