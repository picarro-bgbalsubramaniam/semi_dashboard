from typing import Optional

import numpy as np
import pandas as pd

from compound_hunting.logger import get_logger
from compound_hunting.misc import r_cubed_rev_2 as r2
from compound_hunting.misc.r_cubed_rev_2 import (
    RCubedParameters,
)
from compound_hunting.transformers.template_transformer import BaseHuntingTransformer

LOGGER = get_logger(__name__)


DONT_FIT: list[int] = [280, 977, 947, 962, 297]
IF_DONT_USE: list[int] = [222, 280, 977, 947, 962, 297]


class R3Transformer(BaseHuntingTransformer):
    def __init__(
        self,
        name: str = "R3Transformer",
        kfactor: float = 2,
        fraction: float = 0.9,
        fom_threshold: float = 0.03,
        ban_negatives: bool = False,
        Nfits: int = 15,
        Mfits: int = 6,
        Lfits: int = 0,
        max_cycles: int = 12,
        num_close_compounds: int = 25,
        Q_threshold: float = 1.0,
        dont_fit: list[int] = DONT_FIT,
        dtype=np.float64,
        allow_multitask=False,
        nan_threshold=0.1,
        scaler_x=None,
        scaler_y=None,
        initial_seed_cids: Optional[list[int]] = None,
    ):
        super().__init__(
            dtype=dtype,
            allow_multitask=allow_multitask,
            nan_threshold=nan_threshold,
            scaler_x=scaler_x,
            scaler_y=scaler_y,
        )
        self.name = name
        self.kfactor = kfactor
        self.fraction = fraction
        self.fom_threshold = fom_threshold
        self.ban_negatives = ban_negatives
        self.Nfits = Nfits
        self.Mfits = Mfits
        self.Lfits = Lfits
        self.max_cycles = max_cycles
        self.num_close_compounds = num_close_compounds
        self.Q_threshold = Q_threshold
        self.dont_fit = dont_fit
        self.initial_seed_cids = initial_seed_cids

    def _check_dont_fit(self, X):
        if not isinstance(X, pd.DataFrame):
            raise ValueError("X must be a DataFrame for R3 Transformer.")

        is_present = np.isin(X.columns, self.dont_fit)

        if np.any(is_present):
            msg = (
                f"Found forbidden cids in X.columns: {X.columns[is_present]}. "
                f"Please remove all of {self.dont_fit} from "
                f"X.columns before fitting."
            )
            raise ValueError(msg)

    def fit(self, X, y):
        """A reference implementation of a fitting function for a transformer.

        Parameters
        ----------
        X : {array-like, sparse matrix}, shape (n_samples, n_features)
            The training input samples.

        y : array-like of shape (n_samples,) or (n_samples, n_targets)
            Target values. Will be cast to X's dtype if necessary.

        Returns
        -------
        self : object
            Returns self.
        """
        self._check_dont_fit(X)

        X, y, _ = self.preprocess(X, y)

        self.X_ = X
        self.Y_ = y

        mfs_nu = X.to_dict(orient="list")

        nu = X.index.values

        # Convert lists to numpy arrays
        mfs_nu = {int(k): np.array(v) for k, v in mfs_nu.items()}
        y = np.array(y)

        params = RCubedParameters(
            name=self.name,
            kfactor=self.kfactor,
            fraction=self.fraction,
            fom_threshold=self.fom_threshold,
            ban_negatives=self.ban_negatives,
            Nfits=self.Nfits,
            Mfits=self.Mfits,
            Lfits=self.Lfits,
            max_cycles=self.max_cycles,
            num_close_compounds=self.num_close_compounds,
            Q_threshold=self.Q_threshold,
        )

        hunting_results = r2.hunting_loop(
            mfs_nu,
            nu,
            y,
            [params],
            noise=None,
            required_cids_start=self.initial_seed_cids,
        )

        table = hunting_results[0].summary_results
        table.index = table.index.astype(str)
        Q = table["Q"]

        cids = self.feature_names_in_
        # add all the cids that were not found from X.columns with value 0
        Q = Q.reindex(cids, fill_value=np.nan)

        self.feature_importances_ = Q.values
        self.threshold_ = self.Q_threshold
        self.estimator_ = hunting_results[0]

        # Return the transformer
        return self

    def _get_support_mask(self):
        return self.feature_importances_ > self.threshold_
