from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("compound-hunting")
except PackageNotFoundError:
    __version__ = "N/A"
