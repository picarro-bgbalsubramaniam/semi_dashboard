import tempfile
import typing
from contextlib import nullcontext as does_not_raise
from unittest import mock
from typing import Dict

import h5py
import numpy as np
import pandas as pd
import pytest
from pydantic import ValidationError

from data_pooler.api.private_log_prescan import PrivateLogInfo


@pytest.mark.parametrize(
    "files_info, expectation",
    [
        (
            "broadband_gasConcs_180",
            pytest.raises(ValidationError),
        ),
        (
            ["broadband_gasConcs_180"],
            pytest.raises(ValidationError),
        ),
        (
            {"a": "broadband_gasConcs_180"},
            pytest.raises(ValidationError),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([1, 2, 3]), variables=["a", "b"]
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([4, 5, 6]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([7, 8, 9]), variables=["c", "d"]
                ),
            },
            does_not_raise(),
        ),
    ],
)
def test_get_time_regions(files_info, expectation):
    from data_pooler.api.private_log_prescan import _get_time_regions

    with expectation:
        result = _get_time_regions(
            files_info=files_info,
        )
        assert isinstance(result, Dict)
        assert len(result) == len(files_info)

        for key, value in result.items():
            assert isinstance(key, str)
            assert isinstance(value, slice)


@pytest.mark.parametrize(
    "files_info, expectation",
    [
        (
            "broadband_gasConcs_180",
            pytest.raises(ValidationError),
        ),
        (
            ["broadband_gasConcs_180"],
            pytest.raises(ValidationError),
        ),
        (
            {"a": "broadband_gasConcs_180"},
            pytest.raises(ValidationError),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([1, 2, 3]), variables=["a", "b"]
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([4, 5, 6]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([7, 8, 9]), variables=["c", "d"]
                ),
            },
            does_not_raise(),
        ),
    ],
)
def test_get_private_vars(files_info, expectation):
    from data_pooler.api.private_log_prescan import _get_private_vars

    with expectation:
        result = _get_private_vars(
            files_info=files_info,
        )
        assert isinstance(result, typing.List)
        assert all(isinstance(s, str) for s in result)


@pytest.mark.parametrize(
    "files_info, local_time_zone, expectation",
    [
        (
            "broadband_gasConcs_180",
            "US/Pacific",
            pytest.raises(ValidationError),
        ),
        (
            ["broadband_gasConcs_180"],
            "US/Pacific",
            pytest.raises(ValidationError),
        ),
        (
            {"a": "broadband_gasConcs_180"},
            "US/Pacific",
            pytest.raises(ValidationError),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([1, 2, 3]), variables=["a", "b"]
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([4, 5, 6]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([7, 8, 9]), variables=["c", "d"]
                ),
            },
            {151},
            pytest.raises(ValidationError),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([1, 2, 3]), variables=["a", "b"]
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([4, 5, 6]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([7, 8, 9]), variables=["c", "d"]
                ),
            },
            "US/wherever",
            pytest.raises(ValueError),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([63825842106000, 63825842106001]),
                    variables=["a", "b"],
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([63825842106002]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([63825842106003]), variables=["c", "d"]
                ),
            },
            "US/Pacific",
            does_not_raise(),
        ),
    ],
)
def test_get_file_origin(files_info, local_time_zone, expectation):
    from data_pooler.api.private_log_prescan import _get_file_origin
    import xarray as xr

    with expectation:
        result = _get_file_origin(
            files_info=files_info,
            local_time_zone=local_time_zone,
        )
        assert isinstance(result, xr.DataArray)
        assert "_datetime" in result.dims
        assert "files" in result.attrs
        total_time_len = sum(len(v.timestamp) for v in files_info.values())
        assert result.sizes["_datetime"] == total_time_len
        assert result.name == "private_logs_origin"


@mock.patch("xarray.backends.api.to_zarr", return_value="mocked")
def test_allocate_zarr_store(mocker):
    from data_pooler.api.private_log_prescan import _preallocate_private_zarr_store
    from pathlib import Path
    import xarray as xr

    datetime = pd.date_range("2021-01-01", "2021-01-02", freq="1H")
    zarr_path = Path("my_path")
    local_time_zone = "US/Pacific"
    private_vars = ["a", "b", "c"]
    analyzer_name = "my_analyzer"
    logs_origin = xr.DataArray(
        len(datetime) * ["my_file"],
        dims=["_datetime"],
        coords={"_datetime": datetime},
    )
    time_chunk = 50

    _preallocate_private_zarr_store(
        zarr_path=zarr_path,
        local_time_zone=local_time_zone,
        datetime=datetime,
        private_vars=private_vars,
        analyzer_name=analyzer_name,
        private_logs_origin=logs_origin,
        time_chunk_size=time_chunk,
    )

    assert mocker.called

    with pytest.raises(ValueError):
        # datetime not in coords of private_logs_origin
        _preallocate_private_zarr_store(
            zarr_path=zarr_path,
            local_time_zone=local_time_zone,
            datetime=datetime,
            private_vars=private_vars,
            analyzer_name=analyzer_name,
            private_logs_origin=xr.DataArray(
                len(datetime) * ["my_file"],
                dims=["abc"],
                coords={"abc": datetime},
            ),
            time_chunk_size=time_chunk,
        )

    with pytest.raises(ValueError):
        # dimension mismatch
        _preallocate_private_zarr_store(
            zarr_path=zarr_path,
            local_time_zone=local_time_zone,
            datetime=datetime,
            private_vars=private_vars,
            analyzer_name=analyzer_name,
            private_logs_origin=xr.DataArray(
                (len(datetime) - 1) * ["my_file"],
                dims=["_datetime"],
                coords={"_datetime": datetime[:-1]},
            ),
            time_chunk_size=time_chunk,
        )

    with pytest.raises(ValueError):
        # invalid tz
        _preallocate_private_zarr_store(
            zarr_path=zarr_path,
            local_time_zone="My_tz",
            datetime=datetime,
            private_vars=private_vars,
            analyzer_name=analyzer_name,
            private_logs_origin=logs_origin,
            time_chunk_size=time_chunk,
        )

    with pytest.raises(ValidationError):
        _preallocate_private_zarr_store(
            zarr_path=["a", "b"],
            local_time_zone=local_time_zone,
            datetime=datetime,
            private_vars=private_vars,
            analyzer_name=analyzer_name,
            private_logs_origin=logs_origin,
            time_chunk_size=time_chunk,
        )

    with pytest.raises(ValidationError):
        _preallocate_private_zarr_store(
            zarr_path=zarr_path,
            local_time_zone=pd.Series([], dtype=int),
            datetime=datetime,
            private_vars=private_vars,
            analyzer_name=analyzer_name,
            private_logs_origin=logs_origin,
            time_chunk_size=time_chunk,
        )

    with pytest.raises(ValidationError):
        _preallocate_private_zarr_store(
            zarr_path=zarr_path,
            local_time_zone=local_time_zone,
            datetime=[1, 2, 3],
            private_vars=private_vars,
            analyzer_name=analyzer_name,
            private_logs_origin=logs_origin,
            time_chunk_size=time_chunk,
        )

    with pytest.raises(ValidationError):
        _preallocate_private_zarr_store(
            zarr_path=zarr_path,
            local_time_zone=local_time_zone,
            datetime=datetime,
            private_vars=np.array([1, 2, 3]),
            analyzer_name=analyzer_name,
            private_logs_origin=logs_origin,
            time_chunk_size=time_chunk,
        )

    with pytest.raises(ValidationError):
        _preallocate_private_zarr_store(
            zarr_path=zarr_path,
            local_time_zone=local_time_zone,
            datetime=datetime,
            private_vars=private_vars,
            analyzer_name=None,
            private_logs_origin=logs_origin,
            time_chunk_size=time_chunk,
        )

    with pytest.raises(ValidationError):
        _preallocate_private_zarr_store(
            zarr_path=zarr_path,
            local_time_zone=local_time_zone,
            datetime=datetime,
            private_vars=private_vars,
            analyzer_name=analyzer_name,
            private_logs_origin=pd.Series([1, 2, 3]),
            time_chunk_size=time_chunk,
        )

    with pytest.raises(ValidationError):
        _preallocate_private_zarr_store(
            zarr_path=zarr_path,
            local_time_zone=local_time_zone,
            datetime=datetime,
            private_vars=private_vars,
            analyzer_name=analyzer_name,
            private_logs_origin=logs_origin,
            time_chunk_size="avbc",
        )


@pytest.mark.parametrize(
    "sorted_files_info, expectation",
    [
        (
            "broadband_gasConcs_180",
            pytest.raises(ValidationError),
        ),
        (
            ["broadband_gasConcs_180"],
            pytest.raises(ValidationError),
        ),
        (
            {"a": "broadband_gasConcs_180"},
            pytest.raises(ValidationError),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([1, 2, 3]), variables=["a", "b"]
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([3, 5, 6]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([7, 8, 9]), variables=["c", "d"]
                ),
            },
            pytest.raises(ValueError),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([1, 2, 3]), variables=["a", "b"]
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([10, 11, 12]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([15, 18, 20]), variables=["c", "d"]
                ),
            },
            does_not_raise(),
        ),
        (
            {
                "0.h5": PrivateLogInfo(
                    timestamp=np.array([1, 2, 3]), variables=["a", "b"]
                ),
                "1.h5": PrivateLogInfo(
                    timestamp=np.array([4, 5, 6]), variables=["b", "c"]
                ),
                "2.h5": PrivateLogInfo(
                    timestamp=np.array([7, 8, 9]), variables=["c", "d"]
                ),
            },
            does_not_raise(),
        ),
    ],
)
def test_verify_intervals_distinct(sorted_files_info, expectation):
    from data_pooler.api.private_log_prescan import _verify_intervals_distinct

    with expectation:
        _verify_intervals_distinct(
            sorted_files_info=sorted_files_info,
        )


def test_prescan_private_logs():
    import dask.bag as db
    from data_pooler.api.private_log_prescan import prescan_private_logs

    mock_results = [
        PrivateLogInfo(timestamp=np.array([4, 5, 6]), variables=["b", "c"]),
        PrivateLogInfo(timestamp=np.array([1, 2, 3]), variables=["a", "b"]),
    ]
    # Mock the result of db.from_sequence(...).map(...).compute()
    with mock.patch.object(db.Bag, "compute", return_value=mock_results):
        result = prescan_private_logs(["a", "b"])
        assert isinstance(result, Dict)
        assert len(result) == len(["a", "b"])
        assert all(isinstance(v, PrivateLogInfo) for v in result.values())
        assert all(isinstance(k, str) for k in result.keys())
        assert all(k in ["a", "b"] for k in result.keys())
        assert all(len(v.timestamp) == 3 for v in result.values())
        assert list(result.keys()) == ["b", "a"]

        result = prescan_private_logs(["b", "a"])
        assert isinstance(result, Dict)
        assert len(result) == len(["b", "a"])
        assert all(isinstance(v, PrivateLogInfo) for v in result.values())
        assert all(isinstance(k, str) for k in result.keys())
        assert all(k in ["b", "a"] for k in result.keys())
        assert all(len(v.timestamp) == 3 for v in result.values())
        assert list(result.keys()) == ["a", "b"]

        from pathlib import Path

        result = prescan_private_logs([Path("b"), Path("a")])
        assert isinstance(result, Dict)
        assert len(result) == len(["b", "a"])
        assert all(isinstance(v, PrivateLogInfo) for v in result.values())
        assert all(isinstance(k, str) for k in result.keys())
        assert all(k in ["b", "a"] for k in result.keys())
        assert all(len(v.timestamp) == 3 for v in result.values())
        assert list(result.keys()) == ["a", "b"]

    with pytest.raises(ValueError):
        mock_results = [
            PrivateLogInfo(timestamp=np.array([3, 5, 6]), variables=["b", "c"]),
            PrivateLogInfo(timestamp=np.array([1, 2, 3]), variables=["a", "b"]),
        ]
        # Mock the result of db.from_sequence(...).map(...).compute()
        with mock.patch.object(db.Bag, "compute", return_value=mock_results):
            _ = prescan_private_logs(["a", "b"])

    with pytest.raises(ValidationError):
        _ = prescan_private_logs({"a": 1, "b": 2})


def test_scan_private_log():
    from data_pooler.api.private_log_prescan import _scan_private_log

    len_t = 50
    ts = np.array(1e9 * np.arange(0, len_t) + 63798364799150, dtype=int)

    # create random data
    df1 = pd.DataFrame(
        data={
            "timestamp": ts,
            "a": np.random.rand(len_t).astype(int),
            "b": np.random.rand(len_t).astype(np.float64),
        }
    )

    with tempfile.NamedTemporaryFile() as tf1:
        with h5py.File(tf1.name, "w") as f:
            _ = f.create_dataset(name="results", data=df1.to_records(index=False))

        result = _scan_private_log(tf1.name)
        assert isinstance(result, PrivateLogInfo)
        assert isinstance(result.timestamp, np.ndarray)
        assert isinstance(result.variables, list)
        assert len(result.timestamp) == len_t
        assert len(result.variables) == len(df1.columns)

    with pytest.raises(ValidationError):
        _scan_private_log(pd.Series([1, 2, 3]))

    with pytest.raises(KeyError):
        with tempfile.NamedTemporaryFile() as tf1:
            with h5py.File(tf1.name, "w") as f:
                _ = f.create_dataset(
                    name="results",
                    data=df1.drop(columns="timestamp").to_records(index=False),
                )

            _ = _scan_private_log(tf1.name)

    with pytest.raises(KeyError):
        with tempfile.NamedTemporaryFile() as tf1:
            with h5py.File(tf1.name, "w") as f:
                _ = f.create_dataset(name="res", data=df1.to_records(index=False))

            _ = _scan_private_log(tf1.name)


def test_PrivateLogInfo_class():
    from data_pooler.api.private_log_prescan import PrivateLogInfo

    # Test cases for the start property
    model = PrivateLogInfo(timestamp=np.array([1, 2, 3]), variables=["a", "b", "c"])
    assert model.start == 1

    with pytest.raises(IndexError, match="No timestamp found"):
        model = PrivateLogInfo(timestamp=np.array([]), variables=["a", "b", "c"])
        _ = model.start

    # Test cases for the stop property
    model = PrivateLogInfo(timestamp=np.array([1, 2, 3]), variables=["a", "b", "c"])
    assert model.stop == 3

    with pytest.raises(IndexError, match="No timestamp found"):
        model = PrivateLogInfo(timestamp=np.array([]), variables=["a", "b", "c"])
        _ = model.stop

    # Test cases for the n_points property
    model = PrivateLogInfo(timestamp=np.array([1, 2, 3]), variables=["a", "b", "c"])
    assert model.n_points == 3

    model = PrivateLogInfo(timestamp=np.array([]), variables=["a", "b", "c"])
    assert model.n_points == 0

    # Test case for the timestamp_ascending validator
    timestamp = np.array([1, 2, 3])
    validated_timestamp = PrivateLogInfo._timestamp_ascending(timestamp)
    np.testing.assert_array_equal(validated_timestamp, timestamp)

    with pytest.raises(
        ValueError, match="Timestamps shall be sorted in ascending order"
    ):
        timestamp = np.array([3, 2, 1])
        PrivateLogInfo._timestamp_ascending(timestamp)
