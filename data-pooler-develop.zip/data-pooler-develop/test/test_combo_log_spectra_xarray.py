import tempfile
from concurrent.futures import Future
from unittest import mock

import dask
import h5py
import numpy as np
import pandas as pd
import pytest
import xarray as xr
from pydantic import ValidationError
from dask.distributed import Client

from data_pooler.data_models.h5_structures import H5SpectralInfo, NuTransformInfo


def test_get_nu_keys():
    from data_pooler.api.combo_log_spectra import _get_nu_key

    with tempfile.NamedTemporaryFile() as tf:
        with h5py.File(tf, "w") as f:
            # results timestamp not present
            with pytest.raises(KeyError):
                _get_nu_key(h5file=f, query_keys=["my_key"])

            f["results/timestamp"] = np.zeros(20)
            f["results/mykey"] = np.ones(20)

            # No key found
            with pytest.raises(KeyError):
                _get_nu_key(h5file=f, query_keys=["my_key"])

            # Default value used
            res = _get_nu_key(h5file=f, query_keys=["my_key"], default_value=5.0)
            assert isinstance(res, np.ndarray)
            assert np.allclose(res, np.ones(20) * 5.0)

            # Regular return value
            res = _get_nu_key(
                h5file=f, query_keys=["my_key", "mykey"], default_value=5.0
            )
            assert isinstance(res, np.ndarray)
            assert np.allclose(res, f["results/mykey"])

            with pytest.raises(ValidationError):
                _get_nu_key(
                    h5file="123", query_keys=["my_key", "mykey"], default_value=5.0
                )

            with pytest.raises(ValidationError):
                _get_nu_key(
                    h5file=f, query_keys=pd.Series([1, 2, 3]), default_value=5.0
                )

            with pytest.raises(ValidationError):
                _get_nu_key(
                    h5file=f, query_keys=["my_key", "mykey"], default_value=None
                )


def test_get_nu_data():
    from data_pooler.api.combo_log_spectra import _get_nu_data

    with tempfile.NamedTemporaryFile() as tf:
        with h5py.File(tf, "w") as f:
            f["results/timestamp"] = np.zeros(20)
            f["results/f0"] = np.ones(20)
            f["results/fitData_fitdata_params_nucenter"] = np.ones(20)
            f["results/fitData_nu_transform_n0"] = np.ones(20)
            f["results/fitData_nu_transform_n1"] = np.ones(20)

            res = _get_nu_data(f)
            assert isinstance(res, NuTransformInfo)

            with pytest.raises(ValidationError):
                _get_nu_data(h5file="abc")


def test_pre_scan_h5_files():
    from data_pooler.api.combo_log_spectra import _pre_scan_h5_files

    with tempfile.NamedTemporaryFile() as tf1, tempfile.NamedTemporaryFile() as tf2:
        f0 = 0.0205
        with h5py.File(tf1, "w") as f:
            f["results/timestamp"] = np.arange(0, 2) + 63819453033178
            f["results/f0"] = np.ones(2) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(2)
            f["results/fitData_nu_transform_n0"] = np.zeros(2)
            f["results/fitData_nu_transform_n1"] = np.zeros(2)
            f["spectra/0/nu"] = np.append(np.arange(start=0, stop=1, step=f0), 1.05)
            f["spectra/0/absorbance"] = np.ones_like(f["spectra/0/nu"])
            f["spectra/1/nu"] = np.arange(start=0, stop=1, step=f0)
            f["spectra/1/absorbance"] = np.ones_like(f["spectra/1/nu"])

        with h5py.File(tf2, "w") as f:
            f["results/timestamp"] = np.arange(0, 2) + 63819453033178
            f["results/f0"] = np.ones(2) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(2)
            f["results/fitData_nu_transform_n0"] = np.zeros(2)
            f["results/fitData_nu_transform_n1"] = np.zeros(2)
            f["spectra/0/nu"] = np.arange(start=0, stop=1, step=f0)
            f["spectra/0/absorbance"] = np.ones_like(f["spectra/0/nu"])
            f["spectra/1/nu"] = np.arange(start=0, stop=1, step=f0)
            f["spectra/1/absorbance"] = np.ones_like(f["spectra/1/nu"])

        res = _pre_scan_h5_files([tf1.name, tf2.name])
        assert isinstance(res, H5SpectralInfo)
        assert set(res.spectral_variables) == {"nu", "absorbance"}
        assert res.reported_errors == 1

        with h5py.File(tf2, "r+") as f:
            temp = f["results/timestamp"]
            del f["results/timestamp"]

        # No timestamp present
        with pytest.raises(KeyError):
            _pre_scan_h5_files([tf1.name, tf2.name])

        with h5py.File(tf2, "r+") as f:
            # Restore timestamp
            f["results/timestamp"] = np.arange(0, 2) + 63819453033178
            f["results/this_is_new"] = np.zeros(2)

        # Private vars not matching
        with pytest.raises(ValueError):
            _pre_scan_h5_files([tf1.name, tf2.name])

        with h5py.File(tf2, "r+") as f:
            del f["spectra"]
            del f["results/this_is_new"]

        # Spectra is empty
        with pytest.raises(ValueError):
            _pre_scan_h5_files([tf1.name, tf2.name])

        # Restore spectra, change names of spectral variables
        with h5py.File(tf2, "r+") as f:
            f["spectra/0/nu"] = np.arange(start=0, stop=1, step=f0)
            f["spectra/0/abs"] = np.ones_like(f["spectra/0/nu"])
            f["spectra/1/nu"] = np.arange(start=0, stop=1, step=f0)
            f["spectra/1/abs"] = np.ones_like(f["spectra/1/nu"])

        # Spectral vars not matching between files
        with pytest.raises(ValueError):
            _pre_scan_h5_files([tf1.name, tf2.name])

        # Restore spectra, change names of spectral variables inside file
        with h5py.File(tf2, "r+") as f:
            del f["spectra"]
            f["spectra/0/nu"] = np.arange(start=0, stop=1, step=f0)
            f["spectra/0/absorbance"] = np.ones_like(f["spectra/0/nu"])
            f["spectra/1/nu"] = np.arange(start=0, stop=1, step=f0)
            f["spectra/1/abs"] = np.ones_like(f["spectra/1/nu"])

        # Spectral vars not matching between files
        with pytest.raises(ValueError):
            _pre_scan_h5_files([tf1.name, tf2.name])

        # Restore spectra, change names of spectral variables inside file
        with h5py.File(tf2, "r+") as f:
            del f["spectra"]
            f["spectra/0/nu"] = np.arange(start=0, stop=1, step=f0)
            f["spectra/0/absorbance"] = np.ones_like(f["spectra/0/nu"])
            f["spectra/1/fake_nu"] = np.arange(start=0, stop=1, step=f0)
            f["spectra/1/absorbance"] = np.ones_like(f["spectra/1/fake_nu"])

        # Missing nu
        with pytest.raises(ValueError):
            _pre_scan_h5_files([tf1.name, tf2.name])

        with pytest.raises(ValidationError):
            _pre_scan_h5_files(files_list=pd.Series([1, 2, 3]))


@mock.patch("xarray.backends.api.to_zarr", return_value="mocked")
def test_allocate_zarr_store(mocker):
    from data_pooler.api.combo_log_spectra import _allocate_zarr_store

    my_info = H5SpectralInfo(
        files_info=pd.DataFrame(data={"recorded_timestamps": [0, 1, 2]}),
        scanned_modes=[0, 1, 2],
        spectral_variables=["a", "b"],
        fitter_variables=["c", "d"],
        datetime_coordinate_utc=pd.date_range(
            "2021-10-01", freq="5S", periods=3, tz="UTC"
        ),
        reported_errors=0,
    )

    res = _allocate_zarr_store(
        zarr_path="some_path",
        analyzer_name="some_analyzer",
        local_time_zone="US/Pacific",
        allocation_info=my_info,
    )
    assert res == "OK"

    with pytest.raises(ValidationError):
        _allocate_zarr_store(
            zarr_path=[],
            analyzer_name="some_analyzer",
            local_time_zone="US/Pacific",
            allocation_info=my_info,
        )

    with pytest.raises(ValidationError):
        _allocate_zarr_store(
            zarr_path="some_path",
            analyzer_name={},
            local_time_zone="US/Pacific",
            allocation_info=my_info,
        )

    with pytest.raises(ValidationError):
        _allocate_zarr_store(
            zarr_path="some_path",
            analyzer_name="some_analyzer",
            local_time_zone=pd.Series([1, 2, 3]),
            allocation_info=my_info,
        )

    with pytest.raises(ValidationError):
        _allocate_zarr_store(
            zarr_path="some_path",
            analyzer_name="some_analyzer",
            local_time_zone="US/Pacific",
            allocation_info=pd.DataFrame,
        )


def test_read_individual_h5():
    from data_pooler.api.combo_log_spectra import (
        _pre_scan_h5_files,
        _read_individual_h5,
    )

    with tempfile.NamedTemporaryFile() as tf1, tempfile.NamedTemporaryFile() as tf2:
        f0 = 0.0205
        with h5py.File(tf1, "w") as f:
            f["results/timestamp"] = np.arange(0, 2) + 63819453033178
            f["results/f0"] = np.ones(2) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(2)
            f["results/fitData_nu_transform_n0"] = np.zeros(2)
            f["results/fitData_nu_transform_n1"] = np.zeros(2)
            f["spectra/0/nu"] = np.append(np.arange(start=0, stop=1, step=f0), 1.05)
            f["spectra/0/absorbance"] = np.ones_like(f["spectra/0/nu"])
            f["spectra/1/nu"] = np.arange(start=0, stop=1, step=f0)
            f["spectra/1/absorbance"] = np.ones_like(f["spectra/1/nu"])

        with h5py.File(tf2, "w") as f:
            f["results/timestamp"] = np.arange(0, 2) + 63819453033178
            f["results/f0"] = np.ones(2) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(2)
            f["results/fitData_nu_transform_n0"] = np.zeros(2)
            f["results/fitData_nu_transform_n1"] = np.zeros(2)
            f["spectra/0/nu"] = np.arange(start=0, stop=1, step=f0)
            f["spectra/0/absorbance"] = np.ones_like(f["spectra/0/nu"])
            f["spectra/1/nu"] = np.arange(start=0, stop=1, step=f0)
            f["spectra/1/absorbance"] = np.ones_like(f["spectra/1/nu"])

        info = _pre_scan_h5_files([tf1.name, tf2.name])

        ds = _read_individual_h5(
            h5file_path=tf2.name,
            scanned_modes=info.scanned_modes,
            time_len=info.files_info.recorded_timestamps[1],
            spectral_variables=info.spectral_variables,
        )
        assert isinstance(ds, xr.Dataset)

        with h5py.File(tf2, "w") as f:
            del f["spectra/0/nu"]

        # Can't get nu
        with pytest.raises(ValueError):
            _ = _read_individual_h5(
                h5file_path=tf2,
                scanned_modes=info.scanned_modes,
                time_len=info.files_info.recorded_timestamps[1],
                spectral_variables=info.spectral_variables,
            )

        with pytest.raises(ValidationError):
            _ = _read_individual_h5(
                h5file_path=None,
                scanned_modes=info.scanned_modes,
                time_len=info.files_info.recorded_timestamps[1],
                spectral_variables=info.spectral_variables,
            )

        with pytest.raises(ValidationError):
            _ = _read_individual_h5(
                h5file_path=tf2,
                scanned_modes="abcdef",
                time_len=info.files_info.recorded_timestamps[1],
                spectral_variables=info.spectral_variables,
            )

        with pytest.raises(ValidationError):
            _ = _read_individual_h5(
                h5file_path=tf2,
                scanned_modes=info.scanned_modes,
                time_len="abc",
                spectral_variables=info.spectral_variables,
            )

        with pytest.raises(ValidationError):
            _ = _read_individual_h5(
                h5file_path=tf2,
                scanned_modes=info.scanned_modes,
                time_len=info.files_info.recorded_timestamps[1],
                spectral_variables=pd.Series([1, 2, 3]),
            )


@mock.patch("xarray.backends.api.to_zarr", return_value="mocked")
@mock.patch(
    "data_pooler.api.combo_log_spectra._read_individual_h5", return_value=xr.Dataset()
)
def test_process_h5_file(mock_h5, mock_zarr):
    from data_pooler.api.combo_log_spectra import _process_h5_file

    with Client() as client:
        res = _process_h5_file(
            filename="some_fname",
            zarr_path="some_path",
            file_time_length=10,
            mode_comb=[1, 2, 3],
            spectra_vars=["nu", "abs"],
            time_index_start=0,
        )
        assert res == "OK"
        mock_zarr.assert_called_once
        mock_h5.assert_called_once


@mock.patch("distributed.client.Client.submit", autospec=True)
def test_h5_to_zarr(mock_submit):
    from data_pooler.api.combo_log_spectra import _h5s_to_zarr

    my_info = H5SpectralInfo(
        files_info=pd.DataFrame(
            data={"recorded_timestamps": [0, 1, 2], "file_name": "abc" * 3}
        ),
        scanned_modes=[0, 1, 2],
        spectral_variables=["a", "b"],
        fitter_variables=["c", "d"],
        datetime_coordinate_utc=pd.date_range(
            "2021-10-01", freq="5S", periods=3, tz="UTC"
        ),
        reported_errors=0,
    )

    _h5s_to_zarr(
        pre_scan_info=my_info, allocated_store_path="some_path"
    )
    assert mock_submit.call_count == 3
    mock_submit.reset_mock()

    my_info.files_info = pd.DataFrame(
        data={"recorded_timestamps": np.arange(0, 10, 1), "file_name": "abc" * 10}
    )
    _h5s_to_zarr(
        pre_scan_info=my_info, allocated_store_path="some_path"
    )
    assert mock_submit.call_count == 10

    with pytest.raises(ValidationError):
        _h5s_to_zarr(
            pre_scan_info=pd.Series([1, 2, 3]),
            allocated_store_path="some_path",
        )

    with pytest.raises(ValidationError):
        _h5s_to_zarr(pre_scan_info=my_info, allocated_store_path=None)


@mock.patch("xarray.Dataset.close", return_value="closed")
@mock.patch(
    "xarray.open_zarr",
    return_value=xr.Dataset(
        coords={
            "_datetime": pd.date_range(
                start="2043-08-31 19:05:07.340226560",
                end="2043-09-02 12:28:27.340226560",
                periods=150,
                tz="UTC",
            ).tz_localize(None)
        }
    ),
)
@mock.patch("data_pooler.api.combo_log_spectra._h5s_to_zarr", return_value=["OK"])
@mock.patch("xarray.backends.api.to_zarr", return_value="OK")
def test_read_combologs_spectra_to_zarr_store(
        to_zarr_mock, process_h5_mock, open_zarr_mock, ds_close_mock
):
    from data_pooler.api.combo_log_spectra import read_combologs_spectra_to_zarr_store

    with tempfile.NamedTemporaryFile() as tf1, tempfile.NamedTemporaryFile() as tf2:
        f0 = 0.0205
        last_ts = 0
        with h5py.File(tf1, "w") as f:
            len_t = 100
            f["results/timestamp"] = 1e9 * np.arange(0, len_t) + 63819453033178
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])
            last_ts = f["results/timestamp"][-1]

        with h5py.File(tf2, "w") as f:
            len_t = 50
            f["results/timestamp"] = 1e9 * np.arange(1, len_t + 1) + last_ts
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])

        path = read_combologs_spectra_to_zarr_store(
            files_list=[tf1.name, tf2.name],
            local_time_zone="US/Pacific",
            path_to_zarr="some_path",
            analyzer_name="NUVxxxx",
            chunk_time_size=1000,
        )
        assert isinstance(path, str)

        assert to_zarr_mock.call_count == 1
        assert process_h5_mock.call_count == 1
        open_zarr_mock.assert_called_once
        ds_close_mock.assert_called_once

        with pytest.raises(ValidationError):
            read_combologs_spectra_to_zarr_store(
                files_list=None,
                local_time_zone="US/Pacific",
                path_to_zarr="some_path",
                analyzer_name="NUVxxxx",
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_combologs_spectra_to_zarr_store(
                files_list=[tf1.name, tf2.name],
                local_time_zone=None,
                path_to_zarr="some_path",
                analyzer_name="NUVxxxx",
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_combologs_spectra_to_zarr_store(
                files_list=[tf1.name, tf2.name],
                local_time_zone="US/Pacific",
                path_to_zarr=np.array([1, 2, 3]),
                analyzer_name="NUVxxxx",
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_combologs_spectra_to_zarr_store(
                files_list=[tf1.name, tf2.name],
                local_time_zone="US/Pacific",
                path_to_zarr="some_path",
                analyzer_name=pd.Series([1, 2, 3]),
                chunk_time_size=1000,
            )

        with pytest.raises(ValueError):
            read_combologs_spectra_to_zarr_store(
                files_list=[tf1.name, tf2.name],
                local_time_zone="US/Pacific",
                path_to_zarr="some_path",
                analyzer_name=None,
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_combologs_spectra_to_zarr_store(
                files_list=[tf1.name, tf2.name],
                local_time_zone="US/Pacific",
                path_to_zarr="some_path",
                analyzer_name="NUVxxxx",
                chunk_time_size="abc",
            )

    to_zarr_mock.reset_mock()
    process_h5_mock.reset_mock()
    open_zarr_mock.reset_mock()
    ds_close_mock.reset_mock()

    with tempfile.NamedTemporaryFile(
            suffix="_NUV1046.h5"
    ) as tf3, tempfile.NamedTemporaryFile(suffix="_NUV1046.h5") as tf4:
        f0 = 0.0205
        last_ts = 0
        with h5py.File(tf3, "w") as f:
            len_t = 100
            f["results/timestamp"] = 1e9 * np.arange(0, len_t) + 63819453033178
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])
            last_ts = f["results/timestamp"][-1]

        with h5py.File(tf4, "w") as f:
            len_t = 50
            f["results/timestamp"] = 1e9 * np.arange(1, len_t + 1) + last_ts
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])

        path = read_combologs_spectra_to_zarr_store(
            files_list=[tf3.name, tf4.name],
            local_time_zone="US/Pacific",
            path_to_zarr="some_path",
            analyzer_name=None,
            chunk_time_size=1000,
        )

        assert isinstance(path, str)
        assert to_zarr_mock.call_count == 1
        assert process_h5_mock.call_count == 1
        open_zarr_mock.assert_called_once
        ds_close_mock.assert_called_once


@mock.patch("data_pooler.api.combo_log_spectra.get_h5_files_paths")
@mock.patch(
    "xarray.open_zarr",
    return_value=xr.Dataset(
        coords={
            "_datetime": pd.date_range(
                start="2043-08-31 19:05:07.340226560",
                end="2043-09-02 12:28:27.340226560",
                periods=150,
                tz="UTC",
            ).tz_localize(None)
        }
    ),
)
@mock.patch("data_pooler.api.combo_log_spectra._h5s_to_zarr", return_value=["OK"])
@mock.patch("xarray.backends.api.to_zarr", return_value="OK")
def test_read_combologs_xarray(
        to_zarr_mock, process_h5_mock, open_zarr_mock, mock_get_h5_files_paths
):
    from data_pooler.api.combo_log_spectra import read_combologs_xarray

    with tempfile.NamedTemporaryFile(
            suffix="NUV1061"
    ) as tf1, tempfile.NamedTemporaryFile(suffix="NUV1061") as tf2:
        f0 = 0.0205
        last_ts = 0
        with h5py.File(tf1, "w") as f:
            len_t = 100
            f["results/timestamp"] = 1e9 * np.arange(0, len_t) + 63819453033178
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            f["results/some_private"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])
            last_ts = f["results/timestamp"][-1]

        with h5py.File(tf2, "w") as f:
            len_t = 50
            f["results/timestamp"] = 1e9 * np.arange(1, len_t + 1) + last_ts
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            f["results/some_private"] = np.zeros(len_t)
            for i in range(100, 100 + len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])

        mock_get_h5_files_paths.return_value = [tf1.name, tf2.name]

        read_combologs_xarray(
            folder_path="some_folder",
            local_time_zone="US/Pacific",
            path_to_zarr="some_path",
            analyzer_name="NUVxxxx",
            chunk_time_size=1000,
        )

        mock_get_h5_files_paths.assert_called_once
        assert to_zarr_mock.call_count == 2
        process_h5_mock.assert_called_once
        open_zarr_mock.assert_called_once

        with pytest.raises(ValidationError):
            read_combologs_xarray(
                folder_path=None,
                local_time_zone="US/Pacific",
                path_to_zarr="some_path",
                analyzer_name="NUVxxxx",
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_combologs_xarray(
                folder_path="some_folder",
                local_time_zone=None,
                path_to_zarr="some_path",
                analyzer_name="NUVxxxx",
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_combologs_xarray(
                folder_path="some_folder",
                local_time_zone="US/Pacific",
                path_to_zarr=pd.Series([1, 2, 3]),
                analyzer_name="NUVxxxx",
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_combologs_xarray(
                folder_path="some_folder",
                local_time_zone="US/Pacific",
                path_to_zarr="some_path",
                analyzer_name={},
                chunk_time_size=1000,
            )

        # Set to invalid names to verify error is raise from regex
        mock_get_h5_files_paths.return_value = ["foo", "bar"]
        with pytest.raises(ValueError):
            read_combologs_xarray(
                folder_path="some_folder",
                local_time_zone="US/Pacific",
                path_to_zarr="some_path",
                analyzer_name=None,
                chunk_time_size=1000,
            )
        mock_get_h5_files_paths.return_value = [tf1.name, tf2.name]

        with pytest.raises(ValidationError):
            read_combologs_xarray(
                folder_path="some_folder",
                local_time_zone="US/Pacific",
                path_to_zarr="some_path",
                analyzer_name="NUVxxxx",
                chunk_time_size="abc",
            )

    mock_get_h5_files_paths.reset_mock()
    to_zarr_mock.reset_mock()
    process_h5_mock.reset_mock()
    open_zarr_mock.reset_mock()

    with tempfile.NamedTemporaryFile(
            suffix="NUV1061"
    ) as tf3, tempfile.NamedTemporaryFile(suffix="NUV1061") as tf4:
        f0 = 0.0205
        last_ts = 0
        with h5py.File(tf3, "w") as f:
            len_t = 100
            f["results/timestamp"] = 1e9 * np.arange(0, len_t) + 63819453033178
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            f["results/some_private"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])
            last_ts = f["results/timestamp"][-1]

        with h5py.File(tf4, "w") as f:
            len_t = 50
            f["results/timestamp"] = 1e9 * np.arange(1, len_t + 1) + last_ts
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            f["results/some_private"] = np.zeros(len_t)
            for i in range(100, 100 + len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])

        mock_get_h5_files_paths.return_value = [tf3.name, tf4.name]

        read_combologs_xarray(
            folder_path="some_folder",
            local_time_zone="US/Pacific",
            path_to_zarr="some_path",
            analyzer_name="NUVxxxx",
            chunk_time_size=1000,
        )

        mock_get_h5_files_paths.assert_called_once
        assert to_zarr_mock.call_count == 2
        process_h5_mock.assert_called_once
        open_zarr_mock.assert_called_once
