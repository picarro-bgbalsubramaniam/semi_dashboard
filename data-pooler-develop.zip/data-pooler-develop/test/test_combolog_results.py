import tempfile
from typing import List

import h5py
import numpy as np
import pandas as pd
import xarray as xr
import pytest
from pydantic import ValidationError
from pytz.exceptions import UnknownTimeZoneError
from data_pooler.api.combo_log_results import get_h5_files_paths
from pathlib import Path
from pandas.errors import ParserError


def test_convert_h5_timestamp():
    from data_pooler.api.combo_log_results import _convert_h5_timestamp

    with pytest.raises(ValidationError):
        _ = _convert_h5_timestamp("abc")

    with pytest.raises(ValidationError):
        _ = _convert_h5_timestamp(63798364799150.86)

    ts = 1e9 * np.arange(0, 30) + 63798364799150.86

    utc = _convert_h5_timestamp(ts)
    assert isinstance(utc, pd.DatetimeIndex)
    assert utc[0].year == 2022
    assert utc[0].month == 9
    assert utc[0].day == 9


def test_preprocessor():
    from data_pooler.api.combo_log_results import _preprocessor

    with pytest.raises(ValidationError):
        _preprocessor("abc")

    with pytest.raises(ValidationError):
        _preprocessor(pd.DataFrame())

    with tempfile.NamedTemporaryFile() as tf1:
        f0 = 0.0205

        with h5py.File(tf1, "w") as f:
            len_t = 100
            f["results/timestamp"] = 1e9 * np.arange(0, len_t) + 63798364799150.86
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])

        ds = xr.open_dataset(
            tf1.name,
            engine="h5netcdf",
            decode_cf=False,
            group="results",
            phony_dims="access",
        )
        res = _preprocessor(ds)

        assert isinstance(res, xr.DataArray)
        assert all(
            coord in list(res.coords.keys())
            for coord in ["_datetime", "fitter_var", "fitter_origin_file"]
        )
        assert "fitter_values" == res.name

    with tempfile.NamedTemporaryFile() as tf1:
        f0 = 0.0205

        with h5py.File(tf1, "w") as f:
            len_t = 100
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])

        ds = xr.open_dataset(
            tf1.name,
            engine="h5netcdf",
            decode_cf=False,
            group="results",
            phony_dims="access",
        )

        # timestamp not found
        with pytest.raises(KeyError):
            _ = _preprocessor(ds)


def test_get_h5_files_path():

    with tempfile.NamedTemporaryFile(prefix="/tmp/", suffix="_broadband_123.h5") as tf1:
        f0 = 0.0205

        with h5py.File(tf1, "w") as f:
            len_t = 100
            f["results/timestamp"] = 1e9 * np.arange(0, len_t) + 63798364799150.86
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])

        my_dir = str(Path(tf1.name).parent)
        res = get_h5_files_paths(folder_path=my_dir, fitter_name="broadband")
        assert isinstance(res, List)
        assert len(res) == 1

        with pytest.raises(FileNotFoundError):
            _ = get_h5_files_paths(folder_path=my_dir, fitter_name="narrowband")

        with pytest.raises(FileNotFoundError):
            _ = get_h5_files_paths(folder_path="my_other_dir", fitter_name="broadband")

    with pytest.raises(ValidationError):
        _ = get_h5_files_paths(folder_path={}, fitter_name="abc")

    with pytest.raises(ValidationError):
        _ = get_h5_files_paths(folder_path=my_dir, fitter_name=[])


def test_local_date_to_utc_naive():
    from data_pooler.api.combo_log_results import _local_date_to_utc_naive

    with pytest.raises(UnknownTimeZoneError):
        _local_date_to_utc_naive(
            local_date_time="2022-08-01 10:10", local_time_zone="my_timezone"
        )

    with pytest.raises((ParserError, ValueError, TypeError)):
        _local_date_to_utc_naive(
            local_date_time="2022-02-17 7", local_time_zone="US/Pacific"
        )

    with pytest.raises((ParserError, ValueError, TypeError)):
        _local_date_to_utc_naive(local_date_time="20", local_time_zone="US/Pacific")

    with pytest.raises((ParserError, ValueError, TypeError)):
        _local_date_to_utc_naive(local_date_time="abc", local_time_zone="US/Pacific")

    with pytest.raises((ParserError, ValueError, TypeError)):
        _local_date_to_utc_naive(
            local_date_time="2022-08-01 10:10 +08", local_time_zone="UTC"
        )

    res = _local_date_to_utc_naive(
        local_date_time="2022-08-01 10:10", local_time_zone="US/Pacific"
    )
    assert isinstance(res, pd.Timestamp)
    assert res.tz is None


def test_read_combologs_timeseries_xarray():
    from data_pooler.api.combo_log_results import read_combologs_timeseries_xarray

    with tempfile.NamedTemporaryFile() as tf1, tempfile.NamedTemporaryFile() as tf2:
        f0 = 0.0205
        last_ts = 0
        with h5py.File(tf1, "w") as f:
            len_t = 100
            f["results/timestamp"] = 1e9 * np.arange(0, len_t) + 63819453033178
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            f["results/some_private"] = np.zeros(len_t)
            for i in range(len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])
            last_ts = f["results/timestamp"][-1]

        with h5py.File(tf2, "w") as f:
            len_t = 50
            f["results/timestamp"] = 1e9 * np.arange(1, len_t + 1) + last_ts
            f["results/f0"] = np.ones(len_t) * f0
            f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
            f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
            f["results/some_private"] = np.zeros(len_t)
            for i in range(100, 100 + len_t):
                f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])

        ds = read_combologs_timeseries_xarray(
            files_list=[tf1.name, tf2.name],
            analyzer_name="NUVxyz",
            local_time_zone="US/Pacific",
            chunk_time_size=1000,
        )

        assert isinstance(ds, xr.Dataset)
        assert len(list(ds.fitter_var.values)) == 6

        with pytest.raises(ValidationError):
            read_combologs_timeseries_xarray(
                files_list=12,
                analyzer_name="NUVxyz",
                local_time_zone="US/Pacific",
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_combologs_timeseries_xarray(
                files_list=[tf1.name, tf2.name],
                analyzer_name=np.array([1, 2]),
                local_time_zone="US/Pacific",
                chunk_time_size=1000,
            )

        with pytest.raises(ValueError):
            read_combologs_timeseries_xarray(
                files_list=[tf1.name, tf2.name],
                analyzer_name=None,
                local_time_zone="US/Pacific",
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_combologs_timeseries_xarray(
                files_list=[tf1.name, tf2.name],
                analyzer_name="NUVxyz",
                local_time_zone=[115],
                chunk_time_size=1000,
            )

        with pytest.raises(ValueError):
            read_combologs_timeseries_xarray(
                files_list=[tf1.name, tf2.name],
                analyzer_name="NUVxyz",
                local_time_zone="my_tz",
                chunk_time_size=1000,
            )

        with pytest.raises(ValueError):
            read_combologs_timeseries_xarray(
                files_list=[tf1.name, tf2.name],
                local_time_zone="US/Pacific",
                analyzer_name="NUVxyz",
                chunk_time_size=-1.5,
            )

        with pytest.raises(ValidationError):
            read_combologs_timeseries_xarray(
                files_list=[tf1.name, tf2.name],
                local_time_zone="US/Pacific",
                analyzer_name="NUVxyz",
                chunk_time_size=["abc"],
            )

        # Test the regex
        with tempfile.NamedTemporaryFile(
            suffix="_NUV1051.h5"
        ) as tf3, tempfile.NamedTemporaryFile(suffix="_NUV1051.h5") as tf4:
            f0 = 0.0205
            last_ts = 0
            with h5py.File(tf3, "w") as f:
                len_t = 100
                f["results/timestamp"] = 1e9 * np.arange(0, len_t) + 63819453033178
                f["results/f0"] = np.ones(len_t) * f0
                f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
                f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
                f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
                f["results/some_private"] = np.zeros(len_t)
                for i in range(len_t):
                    f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                    f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                    f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])
                last_ts = f["results/timestamp"][-1]

            with h5py.File(tf4, "w") as f:
                len_t = 50
                f["results/timestamp"] = 1e9 * np.arange(1, len_t + 1) + last_ts
                f["results/f0"] = np.ones(len_t) * f0
                f["results/fitData_fitdata_params_nucenter"] = np.zeros(len_t)
                f["results/fitData_nu_transform_n0"] = np.zeros(len_t)
                f["results/fitData_nu_transform_n1"] = np.zeros(len_t)
                f["results/some_private"] = np.zeros(len_t)
                for i in range(100, 100 + len_t):
                    f[f"spectra/{i}/nu"] = np.arange(start=0, stop=2, step=f0)
                    f[f"spectra/{i}/absorbance"] = np.ones_like(f[f"spectra/{i}/nu"])
                    f[f"spectra/{i}/partial_fit"] = np.ones_like(f[f"spectra/{i}/nu"])

            ds = read_combologs_timeseries_xarray(
                files_list=[tf3.name, tf4.name],
                analyzer_name=None,
                local_time_zone="US/Pacific",
                chunk_time_size=1000,
            )

            assert isinstance(ds, xr.Dataset)
