from data_pooler import interval_utils


SET = interval_utils.Intervals([1, 3, 6, 9])
INTERVALS = interval_utils.Intervals([14, 20])
INTERVALS_INTERSECT = interval_utils.Intervals([4, 16, 18, 21])

def test_interval_union():
    """
    We can join to intervals
    """
    assert interval_utils.Intervals([1, 3, 6, 9, 14, 20]) == INTERVALS.union(SET)

def test_interval_add():
    """
    We can add two intervals
    """
    SET.add_interval([2, 7]) == interval_utils.Intervals([1, 9])

def test_interval_intersection():
    assert (
        SET
        .add_interval([2, 7])
        .intersection(interval_utils
        .Intervals([4, 16, 18, 21]))) == interval_utils.Intervals([4, 9])
