import pytest
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd
import xarray as xr

from data_pooler.api import api_utils


date_range = pd.date_range("2022-10-18", periods=100, freq="4s")
DS = xr.Dataset(
    data_vars={
        "private_values": (("_datetime", "private_var"), np.random.rand(100, 4))
    },
    attrs={"Start": str(date_range[0]), "Stop": str(date_range[-1]), "tz": "UTC"},
    coords={
        "_datetime": ("_datetime", pd.date_range("2022-10-17", periods=100, freq="4s")),
        "private_var": ("private_var", [f"my_var{i}" for i in range(4)]),
        "private_logs_origin": (
            "_datetime",
            [f"my_path{i//2}" for i in range(1, 100 + 1)],
        ),
    },
)


def mocked_ds(path):
    return DS


def test_get_analyzer_name():
    FILE = "/foo/junk_NUV1047_stuff"
    assert api_utils.get_analyzer_name(FILE) == "NUV1047"

    with pytest.raises(ValueError):
        FILE = "/foo/bar/jun3k/2stuff1"
        api_utils.get_analyzer_name(FILE)


def test_check_for_overlapping_files():
    file_list = ["/tmp/NUV1047_1", "/tmp/NUV1047_2"]
    assert (
        api_utils.check_for_overlapping_files(
            file_list, "foo", api_utils.FileTypeEnum.combologs
        )
        == file_list
    )

    with tempfile.TemporaryDirectory(suffix="NUV1047.zarr", dir="/tmp"):
        assert (
            api_utils.check_for_overlapping_files(
                file_list, "/tmp/NUV1047.zarr", api_utils.FileTypeEnum.combologs
            )
            == file_list
        )


def test_get_start_end_time(monkeypatch):
    """Test that we get correct start and end times"""
    monkeypatch.setattr(xr, "open_zarr", mocked_ds)
    start, stop = api_utils.get_start_end_time(Path(".").resolve())
    assert str(start) == "2022-10-18 00:00:00"
    assert str(stop) == "2022-10-18 00:06:36"

    with pytest.raises(ValueError):
        api_utils.get_start_end_time("foo")

    with pytest.raises(ValueError):
        api_utils.get_start_end_time(Path(".").resolve(), time_zone="foo")

    # Test different time zone
    start, stop = api_utils.get_start_end_time(
        Path(".").resolve(), "America/Los_Angeles"
    )
    assert str(start) == "2022-10-17 17:00:00"
    assert str(stop) == "2022-10-17 17:06:36"

    # Test repr
    start, stop = api_utils.get_start_end_time(
        Path(".").resolve(), return_format="%Y%m%d"
    )
    assert str(start) == "20221018"
    assert str(stop) == "20221018"
