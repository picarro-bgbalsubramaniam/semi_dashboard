import ctypes
import mmap
import pickle
import random
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import zstd
from data_pooler import persist as p


class TestBlobStorage:
    def test_roundtrip(self):
        blob0 = {"metadata": {"model": "CFADS"}}
        blob1 = {"history": {"a": "starter"}}
        blob2 = pd.DataFrame({"x": [1, 2, 3, 4, 5], "y": [2, 4, 6, 8, 10]})
        with open("blobtest.zpic", "wb") as pp:
            for b in p.emit_zpickle_from_blobs([blob0, blob1, blob2]):
                pp.write(b)

        with open("blobtest.zpic", "rb") as pp:
            gen = p.get_blobs_from_zpickle(pp)
            meta, nblobs = next(gen)
            assert nblobs == 3, "Number of blobs is incorrect"
            assert meta == blob0, "Metadata does not match"
            assert next(gen) == blob1, "History does not match"
            assert blob2.equals(next(gen)), "Pandas dataframe does not match"
            with pytest.raises(StopIteration):
                next(gen)

    def test_random_access(self):
        blob0 = {"metadata": {"model": "CFADS"}}
        blob1 = {"history": {"a": "starter"}}
        blob2 = pd.DataFrame({"x": [1, 2, 3, 4, 5], "y": [2, 4, 6, 8, 10]})
        with open("blobtest.zpic", "wb") as pp:
            for b in p.emit_zpickle_from_blobs([blob0, blob1, blob2]):
                pp.write(b)

        with open("blobtest.zpic", "rb") as pp:
            gen = p.get_blobs_from_zpickle(pp)
            meta, nblobs = next(gen)
            assert nblobs == 3, "Number of blobs is incorrect"
            assert gen.send(2).equals(blob2), "Pandas dataframe does not match"
            assert gen.send(1) == blob1, "History does not match"
            assert gen.send(0) == blob0, "Metadata does not match"
            assert next(gen) == blob1, "History does not match"
            assert blob2.equals(next(gen)), "Pandas dataframe does not match"
            with pytest.raises(StopIteration):
                next(gen)

    def test_dispose_gen(self):
        blob0 = {"metadata": {"model": "CFADS"}}
        blob1 = {"history": {"a": "starter"}}
        blob2 = pd.DataFrame({"x": [1, 2, 3, 4, 5], "y": [2, 4, 6, 8, 10]})
        with open("blobtest.zpic", "wb") as pp:
            for b in p.emit_zpickle_from_blobs([blob0, blob1, blob2]):
                pp.write(b)

        with open("blobtest.zpic", "rb") as pp:
            gen = p.get_blobs_from_zpickle(pp)
            meta, nblobs = next(gen)
            assert nblobs == 3, "Number of blobs is incorrect"
            assert gen.send(2).equals(blob2), "Pandas dataframe does not match"
            gen.close()
            with pytest.raises(StopIteration):
                next(gen)


class TestFetchCompressedBlobs:
    def test_access(self):
        blob0 = {"metadata": {"model": "CFADS"}}
        blob1 = {"history": {"a": "starter"}}
        blob2 = pd.DataFrame({"x": [1, 2, 3, 4, 5], "y": [2, 4, 6, 8, 10]})
        blob3 = pd.DataFrame({"p": [1, 2, 3, 4, 5], "q": [2, 4, 6, 8, 10], "r": [3, 6, 9, 12, 15]})
        with open("blobtest.zpic", "wb") as pp:
            for b in p.emit_zpickle_from_blobs([blob0, blob1, blob2, blob3]):
                pp.write(b)

        with open("blobtest.zpic", "rb") as pp:
            compressed_blobs = p.fetch_compressed_blobs_from_zpickle(pp)
            assert pickle.loads(zstd.decompress(compressed_blobs[0])) == blob0
            assert pickle.loads(zstd.decompress(compressed_blobs[1])) == blob1
            assert pickle.loads(zstd.decompress(compressed_blobs[2])).equals(blob2)
            assert pickle.loads(zstd.decompress(compressed_blobs[3])).equals(blob3)

class TestZpickleDataFrame:
    def setup(self):
        self.metadata = {"metadata": {"model": "CFADS"}}
        self.history = {"a": "starter"}
        self.extra = {"ea": [1, 2, 3], "eb": [4, 5, 6]}
        self.dframe = pd.DataFrame({"x": [1, 2, 3, 4, 5], "y": [2, 4, 6, 8, 10], "z": [3, 6, 9, 12, 15]})

        with open("blobtest.zpic", "wb") as pp:
            for b in p.emit_zpickle_from_data_frame(self.dframe, dict(self.metadata, _history=self.history,
                                                                           _extra=self.extra)):
                pp.write(b)

    def test_roundtrip(self):
        with open("blobtest.zpic", "rb") as pp:
            gen = p.get_data_frame_from_zpickle(pp, get_history=True, get_extra=True)
            composite = next(gen)
            assert composite.pop("_history") == self.history, "History is not recovered correctly"
            assert composite.pop("_extra") == self.extra, "Extra is not recovered correctly"
            assert composite == self.metadata, "Bare Metadata is incorrect"
            assert next(gen).equals(self.dframe), "Dataframe is not correct"
            gen.close()

    def test_partial_frame(self):
        with open("blobtest.zpic", "rb") as pp:
            gen = p.get_data_frame_from_zpickle(pp, get_history=True, get_extra=True)
            composite = next(gen)
            assert composite.pop("_history") == self.history, "History is not recovered correctly"
            assert composite.pop("_extra") == self.extra, "Extra is not recovered correctly"
            assert composite == self.metadata, "Bare Metadata is incorrect"
            assert gen.send(['z', 'x']).equals(self.dframe[['z', 'x']]), "Incorrect partial dataframe"
            gen.close()

    def test_bare_metadata(self):
        with open("blobtest.zpic", "rb") as pp:
            gen = p.get_data_frame_from_zpickle(pp, get_history=False, get_extra=False)
            assert next(gen) == self.metadata, "Bare Metadata is incorrect"
            assert next(gen).equals(self.dframe)
            gen.close()

    def test_history_only(self):
        with open("blobtest.zpic", "rb") as pp:
            gen = p.get_data_frame_from_zpickle(pp, get_history=True, get_extra=False)
            composite = next(gen)
            assert composite.pop("_history") == self.history, "History is not recovered correctly"
            assert composite == self.metadata, "Bare Metadata is incorrect"
            assert next(gen).equals(self.dframe)
            gen.close()

    def test_extra_only(self):
        with open("blobtest.zpic", "rb") as pp:
            gen = p.get_data_frame_from_zpickle(pp, get_history=False, get_extra=True)
            composite = next(gen)
            assert composite.pop("_extra") == self.extra, "Extra is not recovered correctly"
            assert composite == self.metadata, "Bare Metadata is incorrect"
            assert next(gen).equals(self.dframe)
            gen.close()


class ValveSequenceEntryType(ctypes.Structure):
    _fields_ = [("mask_and_value", ctypes.c_uint16), ("dwell", (ctypes.c_uint16 * 2) * 3)]


class InnerStruct(ctypes.Structure):
    _fields_ = [('f', ctypes.c_int), ('g', ctypes.c_short), ('i', ValveSequenceEntryType)]


class MyStruct(ctypes.Structure):
    _fields_ = [('a', ctypes.c_int), ('b', ctypes.c_float * 10), ('d', InnerStruct * 2), ('c', ctypes.c_short)]


class TestPersistingCtypes:
    @staticmethod
    def ctypes_equal(obj1, obj2):
        return (type(obj1).__name__ == type(obj2).__name__) and (bytes(obj1) == bytes(obj2))

    def setup(self):
        """Sets up encoder and decoder contexts for processing"""
        self.enc = p.Persist()
        self.dec = p.Persist()

    def test_simple_datatypes(self):
        i1 = ctypes.c_uint16(0xbeef)
        i2 = ctypes.c_uint32(0x12345678)
        f1 = ctypes.c_float(27.375)
        # Write out the objects to a file
        with open("test.dat", "wb") as fp:
            for b in self.enc.emit([i1, i2, f1]):
                fp.write(b)
        # Read them back and check that they match
        with open("test.dat", "rb") as fp:
            gen = self.dec.get(fp)
            assert self.ctypes_equal(next(gen), i1), "i1 not recovered correctly"
            assert self.ctypes_equal(next(gen), i2), "i2 not recovered correctly"
            assert self.ctypes_equal(next(gen), f1), "f1 not recovered correctly"
            with pytest.raises(StopIteration):
                next(gen)

    def test_array_datatypes(self):
        i1 = (ctypes.c_uint16 * 5)()
        i1[:] = [5, 4, 3, 2, 1]
        i2 = ((ctypes.c_uint32 * 5) * 10)()
        for i in range(i2._type_._length_):
            for j in range(i2._length_):
                i2[j][i] = random.randrange(1 << 32)

        # Write out the objects to a file
        with open("test.dat", "wb") as fp:
            for b in self.enc.emit([i1, i2]):
                fp.write(b)
        # Read them back and check that they match
        with open("test.dat", "rb") as fp:
            gen = self.dec.get(fp)
            assert next(gen)[:] == i1[:], "Incorrect reconstruction of 1d array"
            i2_new = next(gen)
            for i in range(i2._type_._length_):
                for j in range(i2._length_):
                    assert i2[j][i] == i2_new[j][i], "Incorrect reconstruction of 2d array"

    def test_structure_types(self):
        vse = ValveSequenceEntryType(mask_and_value=0xBEEF)
        inner0 = InnerStruct(f=0x12345678, g=0x9876, i=vse)
        inner1 = InnerStruct(f=0x87654321, g=0x1234, i=vse)
        ms = MyStruct(a=-123, c=0x3456)
        ms.b[:] = [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
        ms.d[0] = inner0
        ms.d[1] = inner1

        for i in range(vse.dwell._type_._length_):
            for j in range(vse.dwell._length_):
                vse.dwell[j][i] = random.randrange(1 << 16)

        with open("test.dat", "wb") as fp:
            for b in self.enc.emit([ms, inner1, ctypes.c_float(37.0), vse, ms]):
                fp.write(b)

        with open("test.dat", "rb") as fp:
            gen = self.dec.get(fp)
            assert self.ctypes_equal(next(gen), ms), "Error in reconstructing ms"
            assert self.ctypes_equal(next(gen), inner1), "Error in reconstructing inner"
            assert self.ctypes_equal(next(gen), ctypes.c_float(37.0)), "Error in reconstructing float"
            assert self.ctypes_equal(next(gen), vse), "Error in reconstructing valve sequence entry"
            assert self.ctypes_equal(next(gen), ms), "Error in reconstructing ms"
            with pytest.raises(StopIteration):
                next(gen)
