import tempfile
from typing import List
from unittest import mock
from zipfile import ZipFile

import h5py
import numpy as np
import xarray as xr
import pandas as pd
import pytest
from pydantic import ValidationError

from data_pooler.api.private_log_prescan import PrivateLogInfo
from data_pooler.api.private_log_results import (
    convert_timezone,
    private_xarray_to_pandas,
)

from data_pooler.api.api_utils import DATE_FORMAT

date_range = pd.date_range("2022-10-18", periods=100, freq="4s")
my_paths = [f"my_path{i // 2}" for i in range(1, 100 + 1)]
DA = xr.DataArray(
    np.random.rand(100, 4),
    dims=["_datetime", "private_var"],
    attrs={
        "Start": f"{date_range[0]:{DATE_FORMAT}}",
        "Stop": f"{date_range[-1]:{DATE_FORMAT}}",
        "tz": "UTC",
    },
    coords={
        "_datetime": ("_datetime", date_range),
        "private_var": ("private_var", [f"my_var{i}" for i in range(4)]),
        "private_logs_origin": (
            "_datetime",
            my_paths,
            {"files": list(set(my_paths))},
        ),
    },
)

DS = xr.Dataset(
    data_vars={
        "private_values": (("_datetime", "private_var"), np.random.rand(100, 4)),
    },
    attrs={
        "Start": f"{date_range[0]:{DATE_FORMAT}}",
        "Stop": f"{date_range[-1]:{DATE_FORMAT}}",
        "tz": "UTC",
    },
    coords={
        "_datetime": ("_datetime", pd.date_range("2022-10-17", periods=100, freq="4s")),
        "private_var": ("private_var", [f"my_var{i}" for i in range(4)]),
        "private_logs_origin": (
            "_datetime",
            my_paths,
            {"files": list(set(my_paths))},
        ),
    },
)

DS2 = xr.Dataset(
    coords={
        "_datetime": ("_datetime", pd.date_range("2022-10-17", periods=100, freq="3s"))
    }
)


def test_get_private_logs_files_paths():
    from data_pooler.api.private_log_results import get_private_logs_files_paths

    with tempfile.TemporaryDirectory(prefix="tmp_zip_files") as td:
        names = [
            "NewFitter_Private01.h5",
            "OldFitter_Private02.h5",
            "NewFitter_Private03.h5",
            "OldFitter_Private04.h5",
        ]
        names = [f"{td}/{name}" for name in names]

        for name in names:
            with h5py.File(name, "w") as f:
                pass

        with ZipFile(f"{td}/test.zip", "w") as myzip:
            for name in names:
                myzip.write(name)

        res = get_private_logs_files_paths(folder_path=td)
        assert isinstance(res, List)
        assert len(res) == 2

    with pytest.raises(FileNotFoundError):
        _ = get_private_logs_files_paths(folder_path="my_other_dir")

    with pytest.raises(ValidationError):
        _ = get_private_logs_files_paths(folder_path={})


def test_tmp_files_cleanup():
    from data_pooler.api.private_log_results import _tmp_files_cleanup

    with tempfile.TemporaryDirectory(prefix="tmp_zip_files") as td:
        names = [
            "NewFitter_Private01.h5",
            "OldFitter_Private02.h5",
            "NewFitter_Private03.h5",
            "OldFitter_Private04.h5",
        ]
        names = [f"{td}/{name}" for name in names]

        for name in names:
            with h5py.File(name, "w") as f:
                pass

        with mock.patch("shutil.rmtree") as mock_rmtree:
            _tmp_files_cleanup(td)
            mock_rmtree.assert_called_once

    with pytest.raises(Exception):
        _tmp_files_cleanup("some_folder")


@mock.patch(
    "data_pooler.api.private_log_results.get_private_logs_files_paths",
    return_value=["NUV1047_0.h5", "NUV1047_1.h5"],
)
@mock.patch("data_pooler.api.private_log_results._tmp_files_cleanup")
@mock.patch(
    "data_pooler.api.private_log_results.prescan_private_logs",
    return_value={
        "NUV1047_0.h5": PrivateLogInfo(
            timestamp=np.array([1, 2, 3]) + 63798364799150, variables=["a", "b", "c"]
        ),
        "NUV1047_1.h5": PrivateLogInfo(
            timestamp=np.array([4, 5, 6]) + 63798364799150, variables=["a", "b"]
        ),
    },
)
@mock.patch("data_pooler.api.private_log_prescan._preallocate_private_zarr_store")
@mock.patch("data_pooler.api.private_log_results._h5s_privatelogs_to_zarr")
def test_read_private_logs_xarray(
    mock_zarr, mock_preallocate, mock_prescan_info, mock_cleanup, mock_get_private
):
    from data_pooler.api.private_log_results import read_private_logs_xarray

    with tempfile.TemporaryDirectory(dir="/tmp") as tempdir:
        with pytest.raises(ValidationError):
            read_private_logs_xarray(
                folder_path=None,
                local_time_zone="US/Pacific",
                path_to_zarr=tempdir,
                analyzer_name="NUV1041",
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_private_logs_xarray(
                folder_path="mypath",
                local_time_zone=[],
                path_to_zarr=tempdir,
                analyzer_name="NUV1041",
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_private_logs_xarray(
                folder_path="mypath",
                local_time_zone="US/Pacific",
                path_to_zarr=tempdir,
                analyzer_name=np.array([1, 2, 3]),
                chunk_time_size=1000,
            )

        with pytest.raises(ValidationError):
            read_private_logs_xarray(
                folder_path="mypath",
                local_time_zone="US/Pacific",
                path_to_zarr=tempdir,
                analyzer_name="NUV1041",
                chunk_time_size={"len": 1000},
            )

        # Chunk size must be >0
        with pytest.raises(ValueError):
            read_private_logs_xarray(
                folder_path="mypath",
                local_time_zone="US/Pacific",
                path_to_zarr=tempdir,
                analyzer_name="NUV1041",
                chunk_time_size=-1,
            )

        # Can't find tz
        with pytest.raises(ValueError):
            read_private_logs_xarray(
                folder_path="mypath",
                local_time_zone="mytz",
                path_to_zarr=tempdir,
                analyzer_name="NUV1041",
                chunk_time_size=1000,
            )

        with pytest.raises(ValueError):
            # No unique files
            with mock.patch(
                "data_pooler.api.private_log_results.check_for_overlapping_files",
                return_value=[],
            ) as mock_overlap:
                read_private_logs_xarray(
                    folder_path="mypath",
                    local_time_zone="US/Pacific",
                    path_to_zarr=tempdir,
                    analyzer_name="NUV1041",
                    chunk_time_size=1000,
                )
                mock_overlap.assert_called_once

        mock_overlap.reset_mock()
        mock_prescan_info.reset_mock()
        mock_cleanup.reset_mock()
        mock_get_private.reset_mock()
        mock_zarr.reset_mock()

        with mock.patch(
            "data_pooler.api.private_log_results.Path.exists"
        ) as mock_exist, mock.patch(
            "data_pooler.api.private_log_results.xr.open_zarr"
        ) as mock_open, mock.patch(
            "data_pooler.api.private_log_results.merge_private_zarr_stores",
            return_value=xr.Dataset(),
        ) as mock_merge, mock.patch(
            "shutil.rmtree"
        ) as mock_remove:
            read_private_logs_xarray(
                folder_path="mypath",
                local_time_zone="US/Pacific",
                path_to_zarr=tempdir,
                analyzer_name="NUV1041",
                chunk_time_size=1000,
            )

            mock_get_private.assert_called_once
            mock_overlap.assert_called_once
            mock_prescan_info.assert_called_once
            mock_preallocate.assert_called_once
            mock_zarr.assert_called_once
            mock_cleanup.assert_called_once
            mock_exist.assert_called_once
            mock_open.assert_called_once
            mock_merge.assert_called_once
            mock_remove.assert_called_once

        with mock.patch(
            "data_pooler.api.private_log_results.Path.exists", return_value=False
        ) as mock_exist:
            # Mock the os.rename call
            with mock.patch(
                "data_pooler.api.private_log_results.os.rename"
            ) as mock_os_rename:
                read_private_logs_xarray(
                    folder_path="mypath",
                    local_time_zone="US/Pacific",
                    path_to_zarr=tempdir,
                    analyzer_name="NUV1041",
                    chunk_time_size=1000,
                )

                mock_get_private.assert_called_once
                mock_overlap.assert_called_once
                mock_prescan_info.assert_called_once
                mock_preallocate.assert_called_once
                mock_zarr.assert_called_once
                mock_cleanup.assert_called_once
                mock_exist.assert_called_once
                mock_os_rename.assert_called_once

        with mock.patch(
            "data_pooler.api.private_log_results.Path.exists", return_value=False
        ) as mock_exist:
            # Mock the os.rename call
            with mock.patch(
                "data_pooler.api.private_log_results.os.rename"
            ) as mock_os_rename:
                read_private_logs_xarray(
                    folder_path="mypath",
                    local_time_zone="US/Pacific",
                    path_to_zarr=tempdir,
                    analyzer_name=None,
                    chunk_time_size=1000,
                )

                mock_get_private.assert_called_once
                mock_overlap.assert_called_once
                mock_prescan_info.assert_called_once
                mock_preallocate.assert_called_once
                mock_zarr.assert_called_once
                mock_cleanup.assert_called_once
                mock_exist.assert_called_once
                mock_os_rename.assert_called_once


@mock.patch("data_pooler.api.private_log_results.Path.exists")
@mock.patch("xarray.backends.api.to_zarr")
@mock.patch("data_pooler.api.private_log_results.xr.open_zarr")
def test_append_private_logs_to_spectral_zarr(mock_openzarr, mock_tozarr, mock_exist):
    from data_pooler.api.private_log_results import append_private_logs_to_spectral_zarr

    assert isinstance(DS, xr.Dataset)
    assert isinstance(DS2, xr.Dataset)

    with pytest.raises(ValidationError):
        append_private_logs_to_spectral_zarr(
            ds_private=None, zarr_store_path="mypath", chunk_time_size=1000
        )

    with pytest.raises(ValidationError):
        append_private_logs_to_spectral_zarr(
            ds_private=DS, zarr_store_path=None, chunk_time_size=1000
        )

    with pytest.raises(ValidationError):
        append_private_logs_to_spectral_zarr(
            ds_private=DS, zarr_store_path="path", chunk_time_size={"len": 1000}
        )

    mock_exist.return_value = False
    with pytest.raises(FileNotFoundError):
        append_private_logs_to_spectral_zarr(
            ds_private=DS, zarr_store_path="mypath", chunk_time_size=1000
        )

    mock_exist.return_value = True
    with pytest.raises(ValueError):
        append_private_logs_to_spectral_zarr(
            ds_private=DS, zarr_store_path="path", chunk_time_size=-1
        )

    mock_openzarr.return_value = DS2

    append_private_logs_to_spectral_zarr(
        ds_private=DS, zarr_store_path="path", chunk_time_size=1000
    )

    mock_tozarr.assert_called_once


def test_convert_timezone():
    """Test that timezone conversion of xarray works as expected"""
    converted_ds = convert_timezone(DA, "America/Los_Angeles")
    assert pd.Timestamp(converted_ds.attrs["Start"]) == pd.Timestamp(
        "2022-10-17 17:00:00"
    )
    assert pd.Timestamp(converted_ds.attrs["Stop"]) == pd.Timestamp(
        "2022-10-17 17:06:36"
    )
    assert converted_ds.attrs["tz"] == "America/Los_Angeles"

    with pytest.raises(ValueError):
        convert_timezone(DA, "mytz")

    with pytest.raises(ValueError):
        convert_timezone(DA.rename({"_datetime": "time"}), "US/Pacific")

    with pytest.raises(ValueError):
        tmp_da = DA.copy(deep=True)
        tmp_da.attrs = {}
        convert_timezone(tmp_da, "US/Pacific")

    with pytest.raises(ValidationError):
        convert_timezone(DA, {1, 2})

    with pytest.raises(ValidationError):
        convert_timezone(None, "US/Pacific")


def test_private_xarray_to_pandas():
    """
    Test that we can convert xarray into time series pandas df
    """
    df = private_xarray_to_pandas(DS, start="2022-10-17 00:00:16")
    assert str(df.index[0]) == "2022-10-17 00:00:16"
    assert str(df.index[-1]) == "2022-10-17 00:06:36"
    df = private_xarray_to_pandas(
        DS, start="2022-10-17 00:00:16", stop="2022-10-17 00:06:00"
    )
    assert str(df.index[0]) == "2022-10-17 00:00:16"
    assert str(df.index[-1]) == "2022-10-17 00:06:00"
    df = private_xarray_to_pandas(DS, stop="2022-10-17 00:06:00")
    assert str(df.index[0]) == "2022-10-17 00:00:00"
    assert str(df.index[-1]) == "2022-10-17 00:06:00"
    df = private_xarray_to_pandas(DS, columns=["my_var1", "my_var2"])
    assert set(df.columns) == {"my_var1", "my_var2"}


def test_process_h5_privatelog_file():
    from data_pooler.api.private_log_results import _process_h5_privatelog_file
    from dask.distributed import Client
    from pathlib import Path

    len_t = 50
    ts = np.array(1e9 * np.arange(0, len_t) + 63798364799150, dtype=int)

    # create random data
    df1 = pd.DataFrame(
        data={
            "timestamp": ts,
            "a": np.random.rand(len_t).astype(int),
            "b": np.random.rand(len_t).astype(np.float64),
        }
    )

    with tempfile.NamedTemporaryFile() as tf1:
        with h5py.File(tf1.name, "w") as f:
            _ = f.create_dataset(name="results", data=df1.to_records(index=False))

        with Client():
            with mock.patch("xarray.backends.api.to_zarr") as my_mock:
                _ = _process_h5_privatelog_file(
                    filename=tf1.name,
                    zarr_path="mypath",
                    file_info=PrivateLogInfo(
                        timestamp=ts,
                        variables=["a", "b"],
                    ),
                    time_region=slice(0, len(ts)),
                    private_vars=["a", "b", "c"],
                )
                assert my_mock.call_count == 1

            with mock.patch("xarray.backends.api.to_zarr") as my_mock:
                _ = _process_h5_privatelog_file(
                    filename=Path(tf1.name),
                    zarr_path=Path("mypath"),
                    file_info=PrivateLogInfo(
                        timestamp=ts,
                        variables=["a", "b"],
                    ),
                    time_region=slice(0, len(ts)),
                    private_vars=["a", "b", "c"],
                )
                assert my_mock.call_count == 1

            with pytest.raises(ValidationError):
                _ = _process_h5_privatelog_file(
                    filename=np.array([1, 2, 3]),
                    zarr_path="mypath",
                    file_info=PrivateLogInfo(
                        timestamp=ts,
                        variables=["a", "b"],
                    ),
                    time_region=slice(0, len(ts)),
                    private_vars=["a", "b", "c"],
                )

            with pytest.raises(ValidationError):
                _ = _process_h5_privatelog_file(
                    filename=tf1.name,
                    zarr_path=None,
                    file_info=PrivateLogInfo(
                        timestamp=ts,
                        variables=["a", "b"],
                    ),
                    time_region=slice(0, len(ts)),
                    private_vars=["a", "b", "c"],
                )

            with pytest.raises(ValidationError):
                _ = _process_h5_privatelog_file(
                    filename=tf1.name,
                    zarr_path="mypath",
                    file_info={"a": 1},
                    time_region=slice(0, len(ts)),
                    private_vars=["a", "b", "c"],
                )

            with pytest.raises(ValidationError):
                _ = _process_h5_privatelog_file(
                    filename=tf1.name,
                    zarr_path="mypath",
                    file_info=PrivateLogInfo(
                        timestamp=ts,
                        variables=["a", "b"],
                    ),
                    time_region=3,
                    private_vars=["a", "b", "c"],
                )

            with pytest.raises(ValidationError):
                _ = _process_h5_privatelog_file(
                    filename=tf1.name,
                    zarr_path="None",
                    file_info=PrivateLogInfo(
                        timestamp=ts,
                        variables=["a", "b"],
                    ),
                    time_region=slice(0, len(ts)),
                    private_vars=pd.Series(["a", "b", 1]),
                )


def test_read_individual_privatelog_h5():
    from data_pooler.api.private_log_results import _read_individual_privatelog_h5
    from pathlib import Path

    len_t = 50
    ts = np.array(1e9 * np.arange(0, len_t) + 63798364799150, dtype=int)

    # create random data
    df1 = pd.DataFrame(
        data={
            "timestamp": ts,
            "a": np.random.rand(len_t).astype(int),
            "b": np.random.rand(len_t).astype(np.float64),
        }
    )

    with tempfile.NamedTemporaryFile() as tf1:
        with h5py.File(tf1.name, "w") as f:
            _ = f.create_dataset(name="results", data=df1.to_records(index=False))

        info = PrivateLogInfo(
            timestamp=ts,
            variables=["a", "b", "timestamp"],
        )

        result = _read_individual_privatelog_h5(
            h5file_path=tf1.name,
            file_info=info,
        )

        assert isinstance(result, xr.Dataset)
        assert all(var_ in result.dims for var_ in ["_datetime", "private_var"])
        assert "private_values" in result.data_vars
        assert set(result.private_var.values) == set(["a", "b", "timestamp"])
        assert result.sizes["_datetime"] == len_t
        assert result.sizes["private_var"] == 3

        result = _read_individual_privatelog_h5(
            h5file_path=Path(tf1.name),
            file_info=info,
        )

        assert isinstance(result, xr.Dataset)
        assert all(var_ in result.dims for var_ in ["_datetime", "private_var"])
        assert "private_values" in result.data_vars
        assert set(result.private_var.values) == set(["a", "b", "timestamp"])
        assert result.sizes["_datetime"] == len_t
        assert result.sizes["private_var"] == 3

        with pytest.raises(ValidationError):
            _ = _read_individual_privatelog_h5(
                h5file_path="abc",
                file_info={"a": 1},
            )

        with pytest.raises(ValidationError):
            _ = _read_individual_privatelog_h5(
                h5file_path=pd.Series([1, 2, 3]),
                file_info=info,
            )

        with pytest.raises(ValueError):
            info = PrivateLogInfo(
                timestamp=ts[:-1],
                variables=["a", "b", "timestamp"],
            )

            _ = _read_individual_privatelog_h5(
                h5file_path=tf1.name,
                file_info=info,
            )

        with pytest.raises(ValueError):
            ts2 = ts
            ts2[0] -= 0.5
            info = PrivateLogInfo(
                timestamp=ts2,
                variables=["a", "b", "timestamp"],
            )

            _ = _read_individual_privatelog_h5(
                h5file_path=tf1.name,
                file_info=info,
            )

    with pytest.raises(KeyError):
        with tempfile.NamedTemporaryFile() as tf1:
            with h5py.File(tf1.name, "w") as f:
                _ = f.create_dataset(
                    name="results",
                    data=df1.drop(columns="timestamp").to_records(index=False),
                )

            info = PrivateLogInfo(
                timestamp=ts,
                variables=["a", "b", "timestamp"],
            )

            _ = _read_individual_privatelog_h5(
                h5file_path=tf1.name,
                file_info=info,
            )

    with pytest.raises(KeyError):
        with tempfile.NamedTemporaryFile() as tf1:
            with h5py.File(tf1.name, "w") as f:
                _ = f.create_dataset(name="resul", data=df1.to_records(index=False))

            info = PrivateLogInfo(
                timestamp=ts,
                variables=["a", "b", "timestamp"],
            )

            _ = _read_individual_privatelog_h5(
                h5file_path=tf1.name,
                file_info=info,
            )


@mock.patch("distributed.client.Client.submit", autospec=True)
def test_h5_to_zarr(mock_submit):
    from data_pooler.api.private_log_results import _h5s_privatelogs_to_zarr
    from pathlib import Path

    files_info = {
        "0.h5": PrivateLogInfo(timestamp=np.array([1, 2]), variables=["a"]),
        "1.h5": PrivateLogInfo(timestamp=np.array([3, 4]), variables=["a", "b"]),
        "2.h5": PrivateLogInfo(timestamp=np.array([5, 6]), variables=["a", "c"]),
    }

    _h5s_privatelogs_to_zarr(
        files_info=files_info,
        allocated_store_path="some_path",
        show_progress=True,
        n_workers=None,
    )
    assert mock_submit.call_count == 3
    mock_submit.reset_mock()

    _h5s_privatelogs_to_zarr(
        files_info=files_info,
        allocated_store_path=Path("some_path"),
        show_progress=True,
        n_workers=None,
    )
    assert mock_submit.call_count == 3
    mock_submit.reset_mock()

    _h5s_privatelogs_to_zarr(
        files_info=files_info,
        allocated_store_path="some_path",
        show_progress=False,
        n_workers=None,
    )
    assert mock_submit.call_count == 3
    mock_submit.reset_mock()

    _h5s_privatelogs_to_zarr(
        files_info=files_info,
        allocated_store_path="some_path",
        show_progress=True,
        n_workers=1,
    )
    assert mock_submit.call_count == 3
    mock_submit.reset_mock()

    with pytest.raises(ValidationError):
        _h5s_privatelogs_to_zarr(
            files_info=pd.Series([1, 2, 3]),
            allocated_store_path="some_path",
            show_progress=True,
            n_workers=1,
        )

    with pytest.raises(ValidationError):
        _h5s_privatelogs_to_zarr(
            files_info=files_info,
            allocated_store_path=np.array([1, 2, 3]),
            show_progress=True,
            n_workers=1,
        )

    with pytest.raises(ValidationError):
        _h5s_privatelogs_to_zarr(
            files_info=files_info,
            allocated_store_path="some_path",
            show_progress=True,
            n_workers={"a": 1.5},
        )


def test_merge_private_zarr_stores():
    from data_pooler.api.private_log_results import merge_private_zarr_stores
    from pathlib import Path

    dt = pd.date_range("2022-10-19", periods=100, freq="4s")
    my_new_paths = [f"my_new_path{i // 4}" for i in range(1, 100 + 1)]

    private_ds = xr.Dataset(
        data_vars={
            "private_values": (("_datetime", "private_var"), np.random.rand(100, 5))
        },
        attrs={
            "Start": f"{dt[0]:{DATE_FORMAT}}",
            "Stop": f"{dt[-1]:{DATE_FORMAT}}",
            "tz": "UTC",
        },
        coords={
            "_datetime": ("_datetime", dt),
            "private_var": ("private_var", [f"my_var{i}" for i in range(5)]),
            "private_logs_origin": (
                "_datetime",
                my_new_paths,
                {"files": list(set(my_new_paths))},
            ),
        },
    )

    with tempfile.TemporaryDirectory(prefix="tmp_zarr_", suffix=".zarr") as temp_zarr:
        with mock.patch(
            "data_pooler.api.private_log_results.xr.open_zarr", return_value=DS
        ) as mock_open:
            zarr_store_path = merge_private_zarr_stores(
                zarr_store_path=temp_zarr,
                private_ds=private_ds,
                chunk_time_size=50,
            )
            mock_open.assert_called_once

        ds_result = xr.open_zarr(zarr_store_path)

        assert isinstance(ds_result, xr.Dataset)
        assert pd.Timestamp(ds_result.attrs["Start"]) == min(
            pd.Timestamp(date_range[0]), pd.Timestamp(dt[0])
        )
        assert pd.Timestamp(ds_result.attrs["Stop"]) == max(
            pd.Timestamp(date_range[-1]), pd.Timestamp(dt[-1])
        )
        assert (
            ds_result.sizes["_datetime"]
            == private_ds.sizes["_datetime"] + DS.sizes["_datetime"]
        )
        assert ds_result.sizes["private_var"] == max(
            private_ds.sizes["private_var"], DS.sizes["private_var"]
        )
        assert set(ds_result.private_var.values) == set(
            private_ds.private_var.values
        ).union(DS.private_var.values)
        assert set(ds_result["private_logs_origin"].attrs["files"]) == set(
            my_new_paths
        ).union(my_paths)
        assert (
            len(ds_result["private_logs_origin"])
            == private_ds.sizes["_datetime"] + DS.sizes["_datetime"]
        )
        # check datetime is ascending
        assert all(
            ds_result["_datetime"].values[i] <= ds_result["_datetime"].values[i + 1]
            for i in range(len(ds_result["_datetime"]) - 1)
        )

    # check that even if I swap the files order, the time axis is still sorted
    with tempfile.TemporaryDirectory(prefix="tmp_zarr_", suffix=".zarr") as temp_zarr:
        with mock.patch(
            "data_pooler.api.private_log_results.xr.open_zarr", return_value=private_ds
        ) as mock_open:
            zarr_store_path = merge_private_zarr_stores(
                zarr_store_path=Path(temp_zarr),
                private_ds=DS,
                chunk_time_size=50,
            )
            mock_open.assert_called_once

        ds_result = xr.open_zarr(zarr_store_path)

        assert isinstance(ds_result, xr.Dataset)
        assert pd.Timestamp(ds_result.attrs["Start"]) == min(
            pd.Timestamp(date_range[0]), pd.Timestamp(dt[0])
        )
        assert pd.Timestamp(ds_result.attrs["Stop"]) == max(
            pd.Timestamp(date_range[-1]), pd.Timestamp(dt[-1])
        )
        assert (
            ds_result.sizes["_datetime"]
            == private_ds.sizes["_datetime"] + DS.sizes["_datetime"]
        )
        assert ds_result.sizes["private_var"] == max(
            private_ds.sizes["private_var"], DS.sizes["private_var"]
        )
        assert set(ds_result.private_var.values) == set(
            private_ds.private_var.values
        ).union(DS.private_var.values)
        assert set(ds_result["private_logs_origin"].attrs["files"]) == set(
            my_new_paths
        ).union(my_paths)
        assert (
            len(ds_result["private_logs_origin"])
            == private_ds.sizes["_datetime"] + DS.sizes["_datetime"]
        )
        # check datetime is ascending
        assert all(
            ds_result["_datetime"].values[i] <= ds_result["_datetime"].values[i + 1]
            for i in range(len(ds_result["_datetime"]) - 1)
        )

    with mock.patch(
        "data_pooler.api.private_log_results.xr.open_zarr", return_value=DS
    ) as mock_open, mock.patch(
        "xarray.backends.api.to_zarr", side_effect=ValueError
    ) as mock_write:
        with pytest.raises(ValueError):
            _ = merge_private_zarr_stores(
                zarr_store_path=temp_zarr,
                private_ds=private_ds,
                chunk_time_size=50,
            )
        mock_open.assert_called_once
        mock_write.assert_called_once

    with pytest.raises(ValidationError):
        _ = merge_private_zarr_stores(
            zarr_store_path=None,
            private_ds=private_ds,
            chunk_time_size=50,
        )

    with pytest.raises(ValidationError):
        _ = merge_private_zarr_stores(
            zarr_store_path="some_path",
            private_ds=None,
            chunk_time_size=50,
        )

    with pytest.raises(ValidationError):
        _ = merge_private_zarr_stores(
            zarr_store_path="some_path",
            private_ds=private_ds,
            chunk_time_size={"abc"},
        )

    with pytest.raises(ValueError):
        _ = merge_private_zarr_stores(
            zarr_store_path="some_path",
            private_ds=private_ds,
            chunk_time_size=-1,
        )

    with pytest.raises(ValueError):
        _ = merge_private_zarr_stores(
            zarr_store_path="some_path",
            private_ds=private_ds.rename({"private_var": "my_var"}),
            chunk_time_size=1,
        )

    with pytest.raises(ValueError):
        _ = merge_private_zarr_stores(
            zarr_store_path="some_path",
            private_ds=private_ds.rename({"private_values": "my_values"}),
            chunk_time_size=1,
        )
