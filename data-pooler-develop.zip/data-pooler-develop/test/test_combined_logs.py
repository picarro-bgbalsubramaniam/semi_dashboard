from data_pooler.api import combined_logs
import pytest

START_LOCAL = "2022-03-09 00:00:00"
END_LOCAL = "2022-03-10 23:00:00"

def mock_get_files(*args):
    if ["ComboLog", "broadband"] in args:
        return ['stuff']
    else:
        return []


def test_bad_timezone():
    with pytest.raises(ValueError) as e:
        combined_logs.get_timeseries_with_combo_info(
            START_LOCAL,
            END_LOCAL,
            "FAKE_TIME_ZONE",
            pool_location=".",
        )
    assert str(e.value) == "Time zone FAKE_TIME_ZONE is not in list of pytz timezones"


def test_no_combo_files():
    with pytest.raises(ValueError) as e:
        combined_logs.get_timeseries_with_combo_info(
            START_LOCAL,
            END_LOCAL,
            "Asia/Taipei",
            pool_location=".",
        )

    assert str(e.value) == (
        "Unable to find combo logs in pool . for specified dates "
        "2022-03-09 00:00:00 to 2022-03-10 23:00:00"
    )


def test_no_private_files(mocker):
    mocker.patch("data_pooler.api.combined_logs.get_file_paths_in_timerange", mock_get_files)
    with pytest.raises(ValueError) as e:
        combined_logs.get_timeseries_with_combo_info(
            START_LOCAL,
            END_LOCAL,
            "Asia/Taipei",
            pool_location=".",
        )

    assert str(e.value) == (
        "Unable to find private logs in pool . for specified dates "
        "2022-03-09 00:00:00 to 2022-03-10 23:00:00"
    )
