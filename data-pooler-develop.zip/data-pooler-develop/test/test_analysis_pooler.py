from data_pooler.api import analysis_pooler as ap
from data_pooler.data_models.meta_header import AnalysisHeader, History, AnalysisHeaderUpdate
import pytest
from pathlib import Path, PosixPath
import pandas as pd
import shutil


POOL_PATH = Path('.').parent.absolute() / 'test' / 'pools'
FULL_PATH = Path('.').parent.absolute() / 'test' / 'pools' / 'NUVTEST' / '2022' / '03' / '08'
FILE_PATH = FULL_PATH / 'NUVTEST_compact_test.zpic'

ANALYZER_NAME = 'NUVTEST'
TEST_FRAME = pd.DataFrame(data={'col1': [1, 2], 'col2': [3, 4]})
TEST_HISTORY_INIT = History()
TEST_HISTORY_INIT.add_history(
    action='test_calc',
    info='Running for test',
)

TEST_HEADER = AnalysisHeader(
    source=ANALYZER_NAME,
    name='test_analysis',
    history=TEST_HISTORY_INIT,
    extra_list=[{'random_stats': [1, 2, 3, 4]}]
)

UPDATE_HEADER = AnalysisHeaderUpdate(
    info='Updated pool',
    action='stats_anlaysis',
    extra_results={'more_stats': [5, 6, 7, 8]}
)


def test_analysis_pooler_smoke():
    analysis = ap.AnalysisPooler(
        pool_path=POOL_PATH,
        date_code=['2022', '03', '08'],
        source=ANALYZER_NAME,
        analysis='compact_test'
    )

def test_write_data_new():
    analysis = ap.AnalysisPooler(
        pool_path=POOL_PATH,
        date_code=['2022', '03', '08'],
        source=ANALYZER_NAME,
        analysis='compact_test'
    )
    analysis.write_data(data=[TEST_FRAME], header_info=TEST_HEADER)
    data_gen = analysis.get_data()
    header, nblobs = next(data_gen)
    assert header == TEST_HEADER.dict()
    assert AnalysisHeader.parse_obj(header) == TEST_HEADER
    data = list(data_gen)
    assert data[0].equals(TEST_FRAME)
    FILE_PATH.unlink()
    shutil.rmtree(POOL_PATH)

def test_update_data():
    analysis = ap.AnalysisPooler(
        pool_path=POOL_PATH,
        date_code=['2022', '03', '08'],
        source=ANALYZER_NAME,
        analysis='compact_test'
    )
    analysis.write_data(data=[TEST_FRAME], header_info=TEST_HEADER)
    analysis.update_data(data=5 * [TEST_FRAME], header_info=UPDATE_HEADER)
    data_gen = analysis.get_data()
    header, nblobs = next(data_gen)
    assert nblobs == 7
    parsed_header = AnalysisHeader.parse_obj(header)
    assert parsed_header.name == 'test_analysis'
    assert len(parsed_header.history.times) == 2
    assert parsed_header.history.action == ['test_calc', 'stats_anlaysis']
    assert parsed_header.history.info == ['Running for test', 'Updated pool']
    assert parsed_header.source == ANALYZER_NAME
    assert parsed_header.extra_list == [
        {'random_stats': [1, 2, 3, 4]}, {'more_stats': [5, 6, 7, 8]}
    ]
    assert parsed_header.version == 1
    FILE_PATH.unlink()
    shutil.rmtree(POOL_PATH)
    assert parsed_header.blobs_inserted == [1, 5]

def test_path_setters():
    analysis = ap.AnalysisPooler(
        pool_path=POOL_PATH,
        date_code=['2022', '03', '08'],
        source=ANALYZER_NAME,
        analysis='compact_test'
    )

    assert analysis.dest_path == FILE_PATH
    with pytest.raises(TypeError):
        analysis.pool_path = 1234
    analysis.pool_path = '/usr/bin'
    assert analysis.pool_path == PosixPath('/usr/bin')
    analysis.pool_path = Path('/usr/bin')
    assert analysis.pool_path == PosixPath('/usr/bin')

    with pytest.raises(TypeError):
        analysis.dest_path = 1234
    analysis.dest_path = '/usr/bin'
    assert analysis.dest_path == PosixPath('/usr/bin')
    analysis.dest_path = Path('/usr/bin')
    assert analysis.dest_path == PosixPath('/usr/bin')

def test_meta():
    analysis = ap.AnalysisPooler(
        pool_path=POOL_PATH,
        date_code=['2022', '03', '08'],
        source=ANALYZER_NAME,
        analysis='compact_test'
    )
    assert analysis.meta == ({}, 0)
    analysis.write_data(data=[TEST_FRAME], header_info=TEST_HEADER)
    assert analysis.meta == (TEST_HEADER.dict(), 2)
    FILE_PATH.unlink()
    shutil.rmtree(POOL_PATH)

def test_get_no_data():
    analysis = ap.AnalysisPooler(
        pool_path=POOL_PATH,
        date_code=['2022', '03', '08'],
        source=ANALYZER_NAME,
        analysis='compact_test'
    )
    data_gen = analysis.get_data()
    # No file created yet
    assert None == next(data_gen)
