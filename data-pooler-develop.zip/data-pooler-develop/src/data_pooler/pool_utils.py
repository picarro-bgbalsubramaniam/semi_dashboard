#!/usr/bin/env python
from functools import lru_cache
import time
from pathlib import Path
import numpy as np
import pandas as pd
import portalocker
import tables
from data_pooler import persist
from data_pooler.timeutils import UNIXORIGIN, ORIGIN
from datetime import timedelta


@lru_cache(maxsize=32)
def _get_data_columns(file_names):
    col_names = set()
    for fname in file_names:
        with open(fname, "rb") as pp:
            gen = persist.get_time_series_data_frame_from_zpickle(pp)
            metadata = next(gen)
            df = next(gen)
            col_names.update(df.columns)
    return col_names


def get_data_columns(file_names):
    return _get_data_columns(tuple(file_names))


@lru_cache(maxsize=32)
def _get_valve_positions(file_names):
    valve_positions = set()
    for fname in file_names:
        with open(fname, "rb") as pp:
            gen = persist.get_time_series_data_frame_from_zpickle(pp)
            metadata = next(gen)
            df = next(gen)
            if "valve_pos" in df.columns:
                valve_positions.update(
                    [int(p) for p in np.unique(np.round(df["valve_pos"].to_numpy()))]
                )
    return valve_positions


def get_valve_positions(file_names):
    return _get_valve_positions(tuple(file_names))


@lru_cache(maxsize=32)
def _get_data_frame(file_names, columns=None):
    data_frames = []
    for file_name in file_names:
        with open(file_name, "rb") as pp:
            gen = persist.get_time_series_data_frame_from_zpickle(pp)
            _ = next(gen)
            df = next(gen)
            cols_available = set(df.columns)
            if columns is not None:
                cols_available = cols_available.intersection(set(columns))
            data_frames.append(df[list(cols_available)])
    return pd.concat(data_frames)


def get_data_frame(file_names, columns=None):
    return _get_data_frame(
        tuple(file_names), None if columns is None else tuple(columns)
    )


def emit_pool_df(input_file, collation_interval):
    """Generate data frames from an input file in zpic format such that the timestamps
    lie between n*collation_interval and (n+1)*collation_interval. The collation
    interval is expressed in seconds and it must divide 1 day (86400s)"""
    if (24 * 60 * 60) % collation_interval != 0:
        raise ValueError("Collation interval must divide 24 hours")

    with Path(input_file).open("rb") as pp:
        gen = persist.get_time_series_data_frame_from_zpickle(pp, get_history=True)
        metadata = next(gen)
        df = next(gen)
        gen.close()
    # We break this into separate data frames according to the collation interval
    periods = pd.Series(
        [
            int((dt - UNIXORIGIN).total_seconds() // collation_interval)
            for dt in df.index
        ],
        index=df.index,
    )
    for period in periods.unique():
        dff = df[periods == period]
        # Get the year, month and day as a tuple for the directory name
        date_code = (dff.index.date[0].strftime("%Y/%m/%d")).split("/")
        # Get the start and end epoch times
        start_epoch = period * collation_interval
        stop_epoch = start_epoch + collation_interval
        yield metadata, date_code, start_epoch, stop_epoch, dff


def emit_pool_df_from_h5(h5_file, collation_interval):
    """Generate data frames from an input file in h5 format such that the timestamps
    lie between n*collation_interval and (n+1)*collation_interval. The collation
    interval is expressed in seconds and it must divide 1 day (86400s)"""
    if (24 * 60 * 60) % collation_interval != 0:
        raise ValueError("Collation interval must divide 24 hours")

    try:
        with tables.open_file(h5_file, "r") as h5:
            df = pd.DataFrame.from_records(h5.root.results.read())
            # Convert the timestamps to UTC localized datetimes
            df["_datetime"] = [ORIGIN + timedelta(milliseconds=ts) for ts in df.timestamp]
            df.drop("timestamp", axis="columns", inplace=True)
            df.set_index("_datetime", inplace=True)

            # We break this into separate data frames according to the collation interval
            periods = pd.Series(
                [
                    int((dt - UNIXORIGIN).total_seconds() // collation_interval)
                    for dt in df.index
                ],
                index=df.index,
            )
            for period in periods.unique():
                dff = df[periods == period]
                # Get the year, month and day as a tuple for the directory name
                date_code = (dff.index.date[0].strftime("%Y/%m/%d")).split("/")
                # Get the start and end epoch times
                start_epoch = period * collation_interval
                stop_epoch = start_epoch + collation_interval
                yield date_code, start_epoch, stop_epoch, dff
    except Exception as e:
        pass


def safe_update(lock_fname, dest_path, updater, overwrite=False):
    # It is important that we do not simultaneously access the same output file from multiple
    #  processes, hence we use a lock on the resulting file

    # Before accessing the output file (at dest_path), we check that it does not exist and create it
    #  if necessary using the appropriate mode. However, a race can occur between calling dest_path.exist()
    #  and opening it, which could lead to the output file being truncated incorrectly by being re-opened
    #  with the "wb+" mode. We thus use a lockfile to make the testing for the existence of the output
    #  file and opening it effectively atomic.

    lockfile = open(lock_fname, "a+")
    for _ in range(300):
        try:
            portalocker.lock(lockfile, portalocker.LOCK_EX | portalocker.LOCK_NB)
            break
        except portalocker.LockException:
            time.sleep(0.2)
            continue
    else:
        raise TimeoutError(f"Cannot acquire {lock_fname}")

    if dest_path.exists():
        # someone explicity wants to overwrite the file
        if overwrite:
            mode = "wb+"
        else:
            # updating existing file
            mode = "rb+"
    else:
        # Creating new file
        mode = "wb+"

    try:
        with portalocker.Lock(dest_path, mode=mode, timeout=60) as pp:
            portalocker.unlock(lockfile)
            updater(pp)
    finally:
        portalocker.unlock(lockfile)
