from datetime import MINYEAR, datetime, timedelta
import numpy as np
import pytz
from tzlocal import get_localzone


# Same code different repo...
ORIGIN = pytz.utc.localize(datetime(MINYEAR, 1, 1, 0, 0, 0, 0))
UNIXORIGIN = pytz.utc.localize(datetime(1970, 1, 1, 0, 0, 0, 0))
SEC_IN_DAY = 24 * 60 * 60


def get_local_timestamp():
    # Get a current local timestamp in IS0 8601 format
    # Example: '2019-06-27 10:40:34'
    local_iso_8601 = datetime.now().isoformat(" ")
    return local_iso_8601


def get_utc_timestamp():
    # Get a current utc timestamp in ISO 8601 format
    # Example: '2019-06-27 17:40:34'
    utc_iso_8601 = datetime.utcnow().isoformat(" ")
    return utc_iso_8601


def get_epoch_timestamp():
    # Get a current epoch timestamp
    epoch_time = datetime.timestamp(datetime.now())
    return epoch_time


def datetime_to_timestamp(t):
    # Converts a datetime object to a Picarro millisecond resolution timestamp
    td = t - ORIGIN
    return (td.days * 86400 + td.seconds) * 1000 + td.microseconds // 1000


def get_timestamp():
    # Returns current Picarro millisecond resolution timestamp
    return datetime_to_timestamp(pytz.utc.localize(datetime.utcnow()))


def timestamp_to_utc_datetime(timestamp):
    # Converts Picarro 64-bit millisecond resolution timestamp to UTC datetime
    try:
        if timestamp == 0.0:
            print("ZERO TIMESTAMP!!!")
        dt = ORIGIN + timedelta(microseconds=1000 * timestamp)
        return dt
    except OverflowError:
        print("Overflow timestamp", timestamp)


def timestamp_to_local_datetime(timestamp):
    # Converts Picarro 64-bit millisecond resolution timestamp to local datetime
    local_tz = get_localzone()
    utc_time = timestamp_to_utc_datetime(timestamp)
    try:
        return utc_time.astimezone(local_tz)
    except Exception:
        return utc_time


def format_time(date_time):
    # Convert `date_time` of type datetime to printable format %Y/%m/%d %H:%M:%S.SSS
    ms = date_time.microsecond // 1000
    return date_time.strftime("%Y/%m/%d %H:%M:%S") + (".%03d" % ms)


def unix_time(timestamp):
    # Converts Picarro 64-bit millisecond resolution timestamp to floating point seconds
    #  since Unix epoch
    dt = (ORIGIN - UNIXORIGIN) + timedelta(microseconds=1000 * float(timestamp))
    return 86400.0 * dt.days + dt.seconds + 1.0e-6 * dt.microseconds


def unix_time_to_timestamp(u):
    # Converts  seconds since Unix epoch to Picarro 64-bit millisecond resolution timestamp
    dt = UNIXORIGIN + timedelta(seconds=float(u))
    return datetime_to_timestamp(dt)


def display_interval(delta_time, intervals=None):
    # Return the smallest interval from the specified list of intervals (or from a preset list
    #  of "nice" intervals) which is less than the specified ``delta_time``, or zero if this
    #  does not exist
    if intervals is None:
        intervals = [
            1.0,
            2.0,
            5.0,
            10.0,
            15.0,
            30.0,
            60.0,
            120.0,
            300.0,
            600.0,
            900.0,
            1800.0,
            3600.0,
        ]
    which = np.digitize([delta_time], intervals).item()
    return intervals[which - 1] if which != 0 else 0.0


def string_to_datetime(date_string):
    """Converts a string to a datetime using formats '%Y-%m-%d %H:%M:%S.%f' or '%Y-%m-%d %H:%M:%S'"""
    try:
        return datetime.strptime(date_string, "%Y-%m-%d %H:%M:%S.%f")
    except ValueError:
        try:
            return datetime.strptime(date_string, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            return datetime.strptime(date_string, "%Y-%m-%d %H:%M")
