from sortedcontainers import SortedSet
from enum import Enum
import math


def is_interval(interval):
    """Determines if the input parameter defines a valid interval

    Args:
        interval (2 element iterable): Left and right endpoints of an interval. The first value must be
            strictly less than the second

    Returns:
        [boolean]: True if the input parameter defines a valid interval
    """
    return (
        len(interval) == 2
        and interval[0] < interval[1]
        and interval[0] >= Intervals.MINVAL
        and interval[1] <= Intervals.MAXVAL
    )


class PointLoc(Enum):
    LEFT_ENDPOINT = 1
    RIGHT_ENDPOINT = 2
    INTERIOR = 3
    EXTERIOR = 4


class Intervals:
    """Class representing a disjoint collection of right half-open intervals with
    methods to perform logical operations on such collections
    """

    MINVAL = -math.inf
    MAXVAL = math.inf

    def __init__(self, endpoints=None):
        """Construct a disjoint collection of right half-open intervals. Such a collection has the form
        [a_0, b_0) + [a_1, b_1) + ... + [a_n, b_n)
        where for each i, a_i < b_i < a_{i+1}. The a_i are left-hand endpoints and the b_i are right-hand
        endpoints

        Args:
            endpoints ([numeric list], optional): Endpoints of the intervals. The values must be distinct,
            and there must be an even number of endpoints. The endpoints can be specified in any order as they
            are sorted before use. Defaults to None.

        Raises:
            ValueError: Endpoints do not define a valid set of intervals
        """
        if endpoints is None:
            self.endpoints = SortedSet()
        else:
            self.endpoints = SortedSet(endpoints)
            if len(self.endpoints) % 2 != 0 or len(self.endpoints) != len(endpoints):
                raise ValueError(
                    "Endpoints must contain an even number of distinct values"
                )
            if self.endpoints:
                if self.endpoints[0] < self.MINVAL or self.endpoints[-1] > self.MAXVAL:
                    raise ValueError(
                        f"Endpoint values must lie between {self.MINVAL} and {self.MAXVAL}"
                    )

    def __eq__(self, other):
        return self.endpoints == other.endpoints

    def classify(self, point):
        """Classifies a `point` relative to the collection of intervals `self`

        Args:
            point ([numeric]): Value to be classified

        Returns:
            [PointLoc]: Point can be a LEFT_ENDPOINT, RIGHT_ENDPOINT, INTERIOR or EXTERIOR relative to the collection
        """
        try:
            return (
                PointLoc.RIGHT_ENDPOINT
                if self.endpoints.index(point) % 2
                else PointLoc.LEFT_ENDPOINT
            )
        except ValueError:
            return (
                PointLoc.INTERIOR
                if self.endpoints.bisect_left(point) % 2
                else PointLoc.EXTERIOR
            )

    def complement(self, inplace=False):
        """Calculates the complement of a collection of intervals. For example, the complement of [3, 5) + [7, 9] is [-inf, 3) + [5, 7) + [9, inf).

        Args:
            inplace (bool, optional): Specifies if the calculation is to occur in-place. Defaults to False.

        Returns:
            [Intervals]: Complement of the input set of intervals (self). Overwrites self if inplace is True.
        """
        target = self if inplace else self.copy()
        if target.MINVAL in target.endpoints:
            target.endpoints.discard(target.MINVAL)
        else:
            target.endpoints.add(target.MINVAL)
        if target.MAXVAL in target.endpoints:
            target.endpoints.discard(target.MAXVAL)
        else:
            target.endpoints.add(target.MAXVAL)
        return target

    def copy(self):
        """Makes a copy of an instance of Intervals

        Returns:
            Intervals: Copy of self
        """
        return Intervals(self.endpoints)

    def union(self, intervals, inplace=False):
        """Calculates union of self and ``intervals``. For example, the union of [1,3) + [5,8) and [2,6) is [1,8)

        Args:
            intervals  (Intervals): Set of intervals whose union with self is to be computed
            inplace (bool, optional): Specifies if the calculation is to occur in-place. Defaults to False.

        Returns:
            Intervals: Union of self and ``intervals``. Modifies ``self`` if inplace is True.
        """
        target = self if inplace else self.copy()
        for left, right in zip(intervals.endpoints[::2], intervals.endpoints[1::2]):
            target.add_interval([left, right], inplace=True)
        return target

    def intersection(self, intervals, inplace=False):
        """Calculates intersection of self and ``intervals``. For example the intersection of [1,3) + [5,8) and [2,6) is [2,3) + [5,6)

        Args:
            intervals (Intervals): Set of intervals whose intersection with self is to be computed
            inplace (bool, optional): Specifies if the calculation is to occur in-place. Defaults to False.

        Returns:
            Intervals: Intersection of self and ``intervals``. Modifies ``self`` if inplace is True.
        """
        target = self if inplace else self.copy()
        int_copy = intervals.copy()
        int_copy.complement(inplace=True)
        target.complement(inplace=True)
        target.union(int_copy, inplace=True)
        target.complement(inplace=True)
        return target

    def test_overlap(self, interval):
        """Calculates if the single interval intersects the collection of intervals in ``self``

        Args:
            interval (2-element numeric iterable): First element is left-hand and second element is right-hand endpoint of the interval

        Raises:
            ValueError: If ``interval`` does not specify a valid interval

        Returns:
            bool: Indicates if the interval and self overlap
        """
        if not is_interval(interval):
            raise ValueError(f"{interval} does not specify a valid interval")
        left, right = interval
        points_in_interval = set(self.endpoints.irange(minimum=left, maximum=right))
        lclass = self.classify(left)
        rclass = self.classify(right)
        if lclass == PointLoc.RIGHT_ENDPOINT:
            points_in_interval.discard(left)
        if rclass == PointLoc.LEFT_ENDPOINT:
            points_in_interval.discard(right)
        return (
            bool(points_in_interval)
            or lclass == PointLoc.INTERIOR
            or rclass == PointLoc.INTERIOR
        )

    def add_interval(self, interval, inplace=False):
        """Adds a single interval to the collection of intervals in ``self``

        Args:
            interval (2-element numeric iterable): First element is left-hand
                and second element is right-hand endpoint of the interval
            inplace (bool, optional): Specifies if the calculation is to occur in-place. Defaults to False.

        Raises:
            ValueError: If ``interval`` does not specify a valid interval

        Returns:
            Intervals: Collection of intervals in self with ``interval`` added. Modifies ``self`` if inplace is True.
        """
        if not is_interval(interval):
            raise ValueError(f"{interval} does not specify a valid interval")
        target = self if inplace else self.copy()
        left, right = interval
        to_delete = set(target.endpoints.irange(minimum=left, maximum=right))
        to_insert = set()
        lclass = target.classify(left)
        if lclass == PointLoc.LEFT_ENDPOINT:
            to_delete.discard(left)
        elif lclass == PointLoc.EXTERIOR:
            to_insert.add(left)
        rclass = target.classify(right)
        if rclass == PointLoc.RIGHT_ENDPOINT:
            to_delete.discard(right)
        elif rclass == PointLoc.EXTERIOR:
            to_insert.add(right)
        target.endpoints = (target.endpoints | to_insert) - to_delete
        return target

    def __repr__(self):
        """String representation of a collection of intervals [a_0,b_0) + [a_1, b_1) + ...

        Returns:
            str: Representation of ``self``
        """
        if self.endpoints:
            return "Intervals: " + " + ".join(
                f"[{left}, {right})"
                for left, right in zip(self.endpoints[::2], self.endpoints[1::2])
            )
        else:
            return "Empty"


if __name__ == "__main__":
    set2 = Intervals([1, 3, 6, 9])
    intervals = Intervals([14, 20])
    print(intervals.union(set2))
    print(intervals.union(set2).add_interval([2, 7]))
    print(
        intervals.union(set2)
        .add_interval([2, 7])
        .intersection(Intervals([4, 16, 18, 21]))
    )
    print(intervals)

    print(intervals.union(set2, inplace=True))
    print(intervals.union(set2, inplace=True).add_interval([2, 7], inplace=True))
    print(
        intervals.union(set2, inplace=True)
        .add_interval([2, 7], inplace=True)
        .intersection(Intervals([4, 16, 18, 21]), inplace=True)
    )
    print(intervals)
