import time
from calendar import monthrange
from datetime import datetime, timedelta
from pathlib import Path
import pytz

import data_pooler.persist as persist
from data_pooler.timeutils import SEC_IN_DAY, UNIXORIGIN
from data_pooler.interval_utils import Intervals


def sorted_subdirs(path, exclusions=[]):
    """
    Get all immediate subdirectories of the specified
    path sorted in lexicographic order, except those which are in
    the exclusion list

    Args:
        path (Path): Directory which to search
        exclusions (str, optional): Subdirectory names to exclude

    Returns:
        list of strings: Names of subdirectories (stems)
    """
    paths = sorted(
        [
            str(node.stem)
            for node in path.iterdir()
            if node.is_dir() and str(node.stem) not in exclusions
        ]
    )
    return paths


def zpickle_df_datetime_range(filename):
    """
    Get the minimum and maximum datetimes present in a zpickle
    file containing a data frame

    Args:
        filename (str): Name of zpickled data frame file

    Returns:
        [tuple]: Minimum and maximum datetimes (timezone aware) of data in the dataframe
    """
    with Path(filename).open("rb") as pp:
        data = persist.get_time_series_data_frame_from_zpickle(pp)
        # TODO: Organize metadata vs generator handling
        _ = next(data)
        df = next(data)
        return (
            df.index.get_level_values("_datetime").min(),
            df.index.get_level_values("_datetime").max(),
        )


def date_range(path, use_files=True):
    """Get the first and last datetimes associated with a path on disk.
    The path is assumed to be the root of a tree of directories organized
    by year, month and day. If "use_files" is True, the names of the files in the
    earliest and latest directories are used to determine the first and last
    dates and times. Otherwise, the first and last non-empty directory names are used.

    Args:
        path (Path): Path to a tree of directories organized as datetimes containing data files
        use_files (bool, optional): Use the index of the zpickled dataframes in the directories to find the
            minimum and maximum datetimes.

    Raises:
        ValueError: The directory names do not specify a valid datetime

    Returns:
        tuple of UTC localized datetimes: First and last datetimeget_epochtimes_from_filestems of non-empty
        directories under the specified path.
    """
    years = sorted_subdirs(path)

    def first():
        # Iterate forward to get the first date
        for year in years:
            months = sorted_subdirs(path / year)
            # If there are no months, continue to next year
            if not months:
                continue
            for month in months:
                days = sorted_subdirs(path / year / month)
                # If there are no days, continue to next month
                if not days:
                    continue
                for day in days:
                    for content in sorted((path / year / month / day).iterdir()):
                        if content.is_file():
                            # I must admit this is super pythonic
                            try:
                                min_date = pytz.utc.localize(
                                    datetime(int(year), int(month), int(day))
                                )
                                return min_date, content
                            except ValueError:
                                pass
                        else:
                            continue
        raise ValueError("No valid dates found")

    def last():
        # Iterate backwards to get the last date
        for year in reversed(years):
            months = sorted_subdirs(path / year)
            # If there are no months, continue to previous year
            if not months:
                continue
            for month in reversed(months):
                days = sorted_subdirs(path / year / month)
                # If there are no days, continue to previous month
                if not days:
                    continue
                for day in reversed(days):
                    for content in reversed(
                        sorted((path / year / month / day).iterdir())
                    ):
                        if content.is_file():
                            try:
                                max_date = pytz.utc.localize(
                                    datetime(
                                        int(year),
                                        int(month),
                                        int(day),
                                        23,
                                        59,
                                        59,
                                        999999,
                                    )
                                )
                                return max_date, content
                            except ValueError:
                                pass
                        else:
                            continue
        raise ValueError("No valid dates found")

    min_date, first_file = first()
    max_date, last_file = last()
    if use_files:
        min_date, _ = get_datetimes_from_filestem(first_file)
        _, max_date = get_datetimes_from_filestem(last_file)
        max_date = max_date - timedelta(microseconds=1)
    return min_date, max_date


def get_epochtimes_from_filestem(path):
    return map(int, str(path.stem).split("_")[-2:])


def get_datetimes_from_filestem(path):
    """Get the start and ending UTC localized datetimes from the filestem of the given path"""
    start_epoch, end_epoch = get_epochtimes_from_filestem(path)
    return UNIXORIGIN + timedelta(seconds=start_epoch), UNIXORIGIN + timedelta(
        seconds=end_epoch
    )


def is_int(x):
    try:
        int(x)
        return True
    except ValueError:
        return False


def gen_paths_from(base_dir, from_year, from_month, from_day):
    """This is a generator giving directories in sorted order starting from the year, month and day specified"""
    base_path = Path(base_dir)
    from_year = int(from_year)
    from_month = int(from_month)
    from_day = int(from_day)
    for year in sorted_subdirs(base_path):
        if (not is_int(year)) or (int(year) < from_year):
            continue
        for month in sorted_subdirs(base_path / year):
            if (not is_int(month)) or (
                int(year) == from_year and int(month) < from_month
            ):
                continue
            for day in sorted_subdirs(base_path / year / month):
                if (not is_int(day)) or (
                    int(year) == from_year
                    and int(month) == from_month
                    and int(day) < from_day
                ):
                    continue
                yield base_path / year / month / day


def any_files_in_interval(base_dir, file_type, start_epoch, end_epoch):
    """Returns True if there are files with the specified file_type which overlaps the interval
    start_epoch to end_epoch

    Args:
        base_dir (str): Name of directory which has the year-month-day subdirectory sequence underneath it. This is
            usually a subdirectory (defined by the source) of the pool directory
        file_type (Iterable): Specifies type of file, e.g. ["ComboLog", "broadband"]. The elements of this iterable
            are joined with "_" and compared against the field(s) of the filename immediately before the epoch times
        start_epoch (int): start of interval in seconds since Unix epoch
        end_epoch (int): end of interval in seconds since Unix epoch

    Returns:
        bool: Indicates if some file of the specified type has a time-stamp range which overlaps the
            specified interval
    """
    if isinstance(file_type, str):
        file_type = [file_type]
    file_type_string = "_".join(file_type)
    base_path = Path(base_dir)
    start_epoch = int(start_epoch)
    end_epoch = int(end_epoch)
    interval = Intervals((start_epoch, end_epoch))
    date_code = (
        (UNIXORIGIN + timedelta(seconds=start_epoch)).strftime("%Y/%m/%d")
    ).split("/")
    for p in gen_paths_from(base_path, *date_code):
        for f in sorted(p.glob(f"*{file_type_string}_*")):
            start_dt, end_dt = get_epochtimes_from_filestem(f)
            if interval.test_overlap((start_dt, end_dt)):
                return True
            elif end_dt > end_epoch:
                return False
    return False


def get_file_paths_in_timerange(start_datetime, stop_datetime, base_path, file_type):
    """Get the file paths in a time-organized directory tree rooted at base_path whose data intersect
    with the interval between start_datetime and stop_datetime.

    The data files in the directory tree have stems which end with <start_file_time>_<stop_file_time>
    where these times are expressed in seconds since UNIXORIGIN. _

    Args:
        start_datetime (time-zone aware datetime): First datetime of interest
        stop_datetime (time-zone aware datetime): Last datetime of interest
        base_path (Path): Path to root of a time-organized directory tree containing data
        file_type (Iterable): Specifies type of file, e.g. ["ComboLog", "broadband"] or ["PrivateLog", "NewFitter"]. 
        The elements of this iterable are joined with "_" and compared against the fields of the filename immediately before the epoch times.
            The example matches the filename 'NUV1028_ComboLog_broadband_1621879200_1621882800.zpic' or
            'NUV1028_PrivateLog_NewFitter_1621879200_1621882800.zpic'
    Returns:
        list of Path: File paths lying in time range
    """
    if isinstance(file_type, str):
        file_type = [file_type]
    file_type_str = "_".join(file_type)
    start_unix_time = (start_datetime - UNIXORIGIN).total_seconds()
    stop_unix_time = (stop_datetime - UNIXORIGIN).total_seconds()
    # Find the files which contain the data. These are organized in nested daily directories
    #  under base_path
    day_boundary = (start_unix_time // SEC_IN_DAY) * SEC_IN_DAY
    file_paths = []
    while day_boundary < stop_unix_time:
        # Find the names of the daily directories which contain the files of interest
        daily_path = base_path.joinpath(
            *(time.strftime("%Y_%m_%d", time.gmtime(day_boundary)).split("_"))
        )
        if daily_path.is_dir():
            # Within each daily directory, the filenames have a stem which ends with <start_file_time>_<stop_file_time>
            #  where these times are in seconds since Unix epoch
            for fpath in sorted(daily_path.iterdir()):
                if fpath.is_file():
                    file_components = fpath.stem.split("_")
                    if file_type_str not in fpath.stem:
                        continue
                    start_file_time, stop_file_time = [
                        int(s) for s in file_components[-2:]
                    ]
                    # Intervals [a,b] and [c,d] intersect iff a<=d and b>=c
                    if (
                        start_unix_time <= stop_file_time
                        and stop_unix_time >= start_file_time
                    ):
                        file_paths.append(fpath)
        day_boundary += SEC_IN_DAY
    return file_paths


def find_sources_in_pool(pool_dir, file_type, file_ext="zpic"):
    """Finds names of sources (e.g., analyzer serial numbers) in a data pool located under `pool_dir` for which
    there are files of the specified type and extension

    Args:
        pool_dir (str): Name of directory of data pool
        file_type (str or Iterable): Specifies type of file, e.g. ["ComboLog", "broadband"]. The elements of this iterable
            are joined with "_" and compared against the fields of the filename immediately before the epoch times.
            If the iterable has only one element, it may be sent as a string, e.g., "PrivateLog"
        file_ext (str): Extension of the files to be considered, defaults to "zpic"

    Returns:
        list of str: Sources for which there are files of the specified type and extension in the pool.
    """
    pool_path = Path(pool_dir)
    if isinstance(file_type, str):
        file_type = [file_type]
    file_type_string = "_".join(file_type)
    subdirs = sorted_subdirs(pool_path, exclusions=["done"])
    sources = set()
    for source in subdirs:
        for _ in (pool_path / source).glob(f"**/*{file_type_string}_*.{file_ext}"):
            sources.add(source)
            break
    return sorted(list(sources))


# Find years available in the pool for a particular file type
def find_years(pool_dir, file_type, time_zone):
    pool_path = Path(pool_dir)
    min_date, max_date = date_range(pool_path)
    year = int(min_date.astimezone(time_zone).strftime("%Y"))
    start_epoch = (
        time_zone.localize(datetime(year, 1, 1, 0, 0, 0)) - UNIXORIGIN
    ).total_seconds()
    years = []
    while start_epoch < (max_date - UNIXORIGIN).total_seconds():
        end_epoch = (
            time_zone.localize(datetime(year + 1, 1, 1, 0, 0, 0)) - UNIXORIGIN
        ).total_seconds()
        if any_files_in_interval(pool_dir, file_type, start_epoch, end_epoch):
            years.append(year)
        year += 1
        start_epoch = end_epoch
    return years


def find_months(base_dir, file_type, time_zone, year):
    start_epoch = (
        time_zone.localize(datetime(year, 1, 1, 0, 0, 0)) - UNIXORIGIN
    ).total_seconds()
    months = []
    for month in range(1, 13):
        _, days_in_month = monthrange(year, month)
        end_epoch = start_epoch + days_in_month * SEC_IN_DAY
        if any_files_in_interval(base_dir, file_type, start_epoch, end_epoch):
            months.append(month)
        start_epoch = end_epoch
    return months


def find_days(base_dir, file_type, time_zone, year, month):
    start_epoch = (
        time_zone.localize(datetime(year, month, 1, 0, 0, 0)) - UNIXORIGIN
    ).total_seconds()
    days = []
    _, days_in_month = monthrange(year, month)
    for day in range(1, days_in_month + 1):
        end_epoch = start_epoch + SEC_IN_DAY
        if any_files_in_interval(base_dir, file_type, start_epoch, end_epoch):
            days.append(day)
        start_epoch = end_epoch
    return days
