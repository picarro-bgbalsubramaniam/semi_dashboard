from datetime import datetime, timedelta
from data_pooler.allan_dev import AllanVar
from data_pooler.timeutils import UNIXORIGIN
import numpy as np
from scipy.interpolate import interp1d
import pytz
import pandas as pd


def data_by_group_and_valve_pos(df, ignore_start=60.0, ignore_end=0.0):
    """Routine to partition a data stream into blocks during which the valve position is unchanging
    and which allows data within time intervals at the start and end of each block to be discarded to
    remove the effects of pressure transients.

    Convert a data frame "df" with a datetime index called "_datetime" into one with a multi-level index that
        has the additional levels "_group" and "valve_pos". The value in the integer-valued "_group" index increments
        whenever the value of "valve_pos" changes. This function operates by using "groupby" to group the data
        into blocks according to unique values of "_group" and "valve_pos". An "apply" function is used to ignore
        data points within the specified intervals at the start and end of each block

    Args:
        df (DataFrame): Data frame with a datetime index called "_datetime" and a column named "valve_pos" which
            contains the valve position at which each datum is collected
        ignore_start (float, optional): Number of seconds to discard at the start of each block (immediately
            after switching to a new valve position). Defaults to 60.0
        ignore_end (float, optional): Number of seconds to discard at the end of each block (immediately
            before switching to a new valve position). Defaults to 0.0

    Returns:
        DataFrame: Grouped data frame with a multi-level index containing the levels "_datetime", "_group"
            and "valve_pos". The columns of the data frame are otherwise the same as those of the input.
    """
    # Calculate groups within which the valve position is fixed
    df = df.copy()
    df["_group"] = (df["valve_pos"].shift() != df["valve_pos"]).cumsum()

    # The following function factory is used to discard the first points in a dara frame which lie within
    # "start_sec" of the first timestamp and the last points which lie within "end_sec" of
    # the last timestamp.
    def discard_ends(start_sec, end_sec):
        def _discard(dframe):
            new_dframe = dframe[
                ((dframe.index - dframe.index[0]).total_seconds() > start_sec)
                & ((dframe.index[-1] - dframe.index).total_seconds() > end_sec)
            ]
            return new_dframe

        return _discard

    # After discarding the specified durations from the ends of each group, return a new data frame
    #  with a multi-index consisting of "_datetime", "_group" and "valve_pos"
    index_cols = ["_group", "valve_pos"]
    return (
        df.groupby(index_cols)
        .apply(discard_ends(ignore_start, ignore_end))
        .drop(columns=["_group"])
    )


def block_means(dfg):
    """Calculate the block means of the values in data columns of a grouped dataframe `dfg` having a multi-level
        index which includes a level named "_datetime". Within each block which is defined by unique values of
        the other index levels, the means of the values for each column are computed. The entry in the "_datetime"
        level of the index is replaced by the mean of the timestamps in the block. This works reliably if the
        datetime index is in the UTC zone which is free from daylight saving issues which can confuse the
        computation of the mean datetimes.

    Args:
        dfg (DataFrame): Data frame with a multi-level index which includes a level named `_datetime` as well as
            other levels whose unique values define the blocks into which the data are grouped.

    Raises:
        ValueError: If the input data frame does not have an index level named "_datetime"

    Returns:
        DataFrame: Data frame with columns containing the means of the values in the input data frame taken over blocks
            defined by unique values of the additional levels in the index. A "_datetime" level is included in the
            data frame and it is filled with the mean value of the time stamp for each block.
    """
    index_names = set(dfg.index.names)
    if "_datetime" not in index_names:
        raise ValueError(f'Dataframe must have "_datetime" in its index')

    def calc_mean_with_datetime_index(df1):
        mean_dt = UNIXORIGIN + timedelta(
            seconds=(df1.index.get_level_values("_datetime") - UNIXORIGIN)
            .total_seconds()
            .to_numpy()
            .mean()
        )
        return pd.DataFrame(
            data=[df1.mean()], index=pd.DatetimeIndex([mean_dt], name="_datetime")
        )

    grouping = list(index_names - {"_datetime"})
    if grouping:
        return dfg.groupby(level=grouping).apply(calc_mean_with_datetime_index)
    else:
        return calc_mean_with_datetime_index(dfg)


def resample_rolling_mean(dfg, roll_s=30, avg_roll=4):
    def worker(df):
        df.set_index(df.index.get_level_values("_datetime"), inplace=True)
        df1 = (
            df.resample(
                timedelta(seconds=roll_s), closed="right", label="right", origin="epoch"
            )
            .mean()
            .rolling(
                timedelta(seconds=avg_roll * roll_s),
                closed="right",
                min_periods=avg_roll,
            )
            .mean()
        )
        df1.index = df1.index - timedelta(seconds=avg_roll * roll_s / 2)
        return df1

    return dfg.groupby(level=["_group", "valve_pos"]).apply(worker)


def reset_non_datetime_index_levels(df, drop=True):
    return df.reset_index(level=list(set(df.index.names) - {"_datetime"}), drop=drop)


def get_ref_interp(df_ref, variables, zero_ref_time):
    df_ref_rolling = df_ref.rolling(
        timedelta(seconds=zero_ref_time), center=True
    ).mean()
    return [
        interp1d(
            (df_ref_rolling.index - UNIXORIGIN).total_seconds(),
            df_ref_rolling[v].to_numpy(),
            fill_value="extrapolate",
        )
        for v in variables
    ]


def get_epoch_from_datetime_index(df):
    return (df.index.get_level_values("_datetime") - UNIXORIGIN).total_seconds()


def remove_zero_reference_offsets(dfg, ref_pos=1, zero_ref_time=14400):
    # Compute dataframe with zero reference offsets removed
    df_ref = reset_non_datetime_index_levels(
        dfg[dfg.index.get_level_values("valve_pos") == ref_pos]
    )
    variables = list(dfg.columns)
    ref_interp = get_ref_interp(df_ref, variables, zero_ref_time)
    dfg_ref_removed = pd.DataFrame(index=dfg.index)
    for v, interp in zip(variables, ref_interp):
        dfg_ref_removed[v] = dfg[v] - interp(get_epoch_from_datetime_index(dfg))
    return dfg_ref_removed
