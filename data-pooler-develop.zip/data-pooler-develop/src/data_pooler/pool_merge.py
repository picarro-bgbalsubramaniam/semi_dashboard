from pathlib import Path
from typing import Tuple
import shutil
from data_pooler.logger import get_logger


LOGGER = get_logger(__name__)


def merge_source_pool_into_target_pool(
    source_pool_path: Path,
    target_pool_path: Path,
    modify_target: bool = False,
    verbose: bool = False,
) -> Tuple[int, int]:
    """
    Files are copied from a source pool path to a target pool path.
    If a source file does not exist in the target pool, it is copied to that location.
    If a source file exists in the target pool, the larger of the two files is retained in the target pool.

    returns the number of files copied and number of errors encountered

     Recommend first running with modify_target = False to make sure you are comfortable with the actions that will be taken
    """

    numfiles_copied = 0
    numerrors = 0
    if modify_target:
        txt = "  Merging source and target pools"
        if verbose:
            LOGGER.info(txt)

    # recursively walk source directory path
    for fn_src in source_pool_path.rglob("*"):
        # determine path relative to source root directory
        rel_src = fn_src.relative_to(source_pool_path)

        # create final target path
        fn_trg = target_pool_path / rel_src
        txt = (f"{rel_src}").ljust(80)

        # create target directories if needed
        if fn_src.is_dir():
            if not fn_trg.exists():
                txt += "create directory"
                if modify_target:
                    fn_trg.mkdir()
            else:
                txt += "directory exists"
        # manage files
        else:
            # ignore non zpic files
            if fn_src.name[-4:] != "zpic":
                continue

            if fn_trg.exists():
                # copy source to target only if source size is greater
                copy_file_to_target = fn_src.stat().st_size > fn_trg.stat().st_size
                if copy_file_to_target:
                    txt += "overwriting smaller target file"
                else:
                    txt += "retaining target file"
            else:
                # copy source file if target does not exist
                copy_file_to_target = True
                txt += "  copying source file"

            # copy file
            if copy_file_to_target and modify_target:
                try:
                    shutil.copyfile(fn_src, fn_trg)
                    numfiles_copied += 1
                except Exception as e:
                    txt += str(e)
                    numerrors += 1
        if verbose:
            LOGGER.debug(txt)
    return numfiles_copied, numerrors
