from datetime import datetime
import ctypes
import json
import mmap
import pickle
import struct
import pytz
import blosc
import numpy as np
import zstd

# The following are the primitive ctypes and the integer codes used to represent them on disk
code_to_ctype = [
    ctypes.c_bool,
    ctypes.c_char,
    ctypes.c_wchar,
    ctypes.c_byte,
    ctypes.c_ubyte,
    ctypes.c_short,
    ctypes.c_ushort,
    ctypes.c_int,
    ctypes.c_uint,
    ctypes.c_long,
    ctypes.c_ulong,
    ctypes.c_longlong,
    ctypes.c_ulonglong,
    ctypes.c_size_t,
    ctypes.c_ssize_t,
    ctypes.c_float,
    ctypes.c_double,
    ctypes.c_longdouble,
    ctypes.c_char_p,
    ctypes.c_wchar_p,
    ctypes.c_void_p,
]

SIGNATURE_BASE = 0x61636950
FIRST_USER_CODE = 100

BLOB_PYTHON_OBJECT = 1
BLOB_PANDAS_DATAFRAME = 2
BLOB_ARROW_TABLE = 3


s16 = struct.Struct("h")
u16 = struct.Struct("H")
s32 = struct.Struct("i")
u32 = struct.Struct("I")
s64 = struct.Struct("q")
u64 = struct.Struct("Q")


def PicarroSignature(major=1, minor=1):
    return (((major << 16) | minor) << 32) | SIGNATURE_BASE


def check_signature(sig):
    if (sig & 0xFFFFFFFF) != SIGNATURE_BASE:
        raise ValueError("Invalid signature code")
    else:
        minor = (sig >> 32) & 0xFFFF
        major = (sig >> 48) & 0xFFFF
        return major, minor


def read(fp, size):
    """Reads size bytes from file-like object fp and returns the result if the read succeeds.
    Raises StopIteration if there are insufficient bytes to satisfy read"""
    result = fp.read(size)
    if len(result) == size:
        return result
    raise StopIteration


def fetch_s16(fp):
    (value,) = s16.unpack(read(fp, s16.size))
    return value


def emit_s16(value):
    yield s16.pack(value)


def fetch_u16(fp):
    (value,) = u16.unpack(read(fp, u16.size))
    return value


def emit_u16(value):
    yield u16.pack(value)


def fetch_s32(fp):
    (value,) = s32.unpack(read(fp, s32.size))
    return value


def emit_s32(value):
    yield s32.pack(value)


def fetch_u32(fp):
    (value,) = u32.unpack(read(fp, u32.size))
    return value


def emit_u32(value):
    yield u32.pack(value)


def fetch_s64(fp):
    (value,) = s64.unpack(read(fp, s64.size))
    return value


def emit_s64(value):
    yield s64.pack(value)


def fetch_u64(fp):
    (value,) = u64.unpack(read(fp, u64.size))
    return value


def emit_u64(value):
    yield u64.pack(value)


def emit_as_json(obj):
    obj_as_json = json.dumps(obj).encode("ascii")
    yield from emit_bytes(obj_as_json)


def emit_bytes(bytes):
    yield from emit_u32(len(bytes))
    yield bytes


def fetch_bytes(fp):
    len = fetch_u32(fp)
    return read(fp, len)


def fetch_json(fp):
    len = fetch_u32(fp)
    return json.loads(read(fp, len).decode("ascii"))


def fetch_numpy_recarray(fp, sel_cols=None):
    """Gets a numpy record array from a byte stream on a file-like object. This
    record array can contain all the columns (if sel_col=None) or a subset of the
    columns (if sel_col is a set of strings with the selected column names).

    Args:
        fp (file-like object): Source of byte stream representing the numpy record array
        sel_cols (set, optional): Specify set of column names to include. Defaults to all columns.

    Returns:
        [numpy record array]: Record array reconstructed.
    """
    col_names = fetch_json(fp)
    offsets = fetch_json(fp)
    arrays = []
    if sel_cols is None:
        for name, offset in zip(col_names, offsets):
            arrays.append(blosc.unpack_array(fetch_bytes(fp)))
        names = col_names
    else:
        base = fp.tell()
        names = []
        for name, offset in zip(col_names, offsets):
            if name in sel_cols:
                fp.seek(base + offset)
                arrays.append(blosc.unpack_array(fetch_bytes(fp)))
                names.append(name)
    return np.core.records.fromarrays(arrays, names=names)


def emit_numpy_recarray(rec_array):
    """Converts a numpy record array into a stream of bytes with information allowing it or a subset of its columns
        to be reconstructed efficiently from the stream. The column names are stored in JSON format followed by a
        set of offsets allowing the columns to be accessed by seeking into the file.
        The blosc compressor is used along each column.

        Typical usage of this function is:

        with open(fname, "rb") as fp:
            for b in emit_numpy_recarray(rec_array):
                fp.write(b)

    Args:
        rec_array (numpy record array): Array to convert into a byte stream to persist the array

    Yields:
        bytes: Succession of bytes for persisting the array.
    """
    packed = [
        blosc.pack_array(rec_array[name], cname="lz4") for name in rec_array.dtype.names
    ]
    # Calculate offset to the packed array for each column
    offsets = np.concatenate(
        ([0], np.cumsum(4 + np.asarray([len(a) for a in packed]))[:-1]), dtype=int
    ).tolist()
    yield from emit_as_json(rec_array.dtype.names)
    yield from emit_as_json(offsets)
    # Emit the packed arrays
    for pack in packed:
        yield from emit_bytes(pack)


def emit_zpickle_from_compressed_blobs(compressed_blobs, maxblobs=8):
    """Generator which yields a stream of bytes representing a collection of up to maxblobs data blobs.
    Each compressed blob is serialized using pickle and compressed with zstd

    The byte stream consists of a u64 signature followed by a u32 number containing 4*(maxblobs+1) and
    another u32 number containing the number of blobs actually present (i.e., len(blobs)). This is followed
    by maxblobs u32 numbers containing offsets into the file where the compressed blobs are stored.

    Each compressed blob is stored in the file as:
    1) a u32 giving the length of the compressed blob
    2) The compressed blob itself
    """
    nblobs = len(compressed_blobs)
    if nblobs > maxblobs:
        raise ValueError("Cannot have more blobs than specified by maxblobs")
    yield from emit_u64(PicarroSignature())
    # Emit the vector of offsets into the compressed blobs
    yield from emit_u32(4 * (maxblobs + 1))
    yield from emit_u32(nblobs)
    offset = 0
    for i in range(maxblobs):
        if i < nblobs:
            yield from emit_u32(offset)
            offset += len(compressed_blobs[i]) + u32.size
        else:
            yield from emit_u32(offset)
    for i in range(nblobs):
        yield from emit_u32(len(compressed_blobs[i]))
        yield bytes(compressed_blobs[i])


def emit_zpickle_from_blobs(blobs, maxblobs=8):
    """Generator which yields a stream of bytes representing a collection of up to maxblobs data blobs."""
    if len(blobs) > maxblobs:
        raise ValueError("Cannot have more blobs than specified by maxblobs")
    compressed_blobs = [compress_blob(blob) for blob in blobs]
    yield from emit_zpickle_from_compressed_blobs(compressed_blobs, maxblobs)


def fetch_compressed_blobs_from_zpickle(qq):
    with mmap.mmap(qq.fileno(), 0, prot=mmap.PROT_READ) as pp:
        compressed_blobs, mv = fetch_compressed_blobs_from_zpickle_mmap(pp)
        compressed_blobs = [bytes(cb) for cb in compressed_blobs]
        mv.release()
    return compressed_blobs


def add_to_history(current, app_name, metadata_of_participants, when=None):
    def no_extra(meta):
        meta = meta.copy()
        if "_extra" in meta:
            meta.pop("_extra")
        return meta

    if when is None:
        when = pytz.utc.localize(datetime.utcnow())
    return dict(
        t=current.get("t", []) + [when],
        a=current.get("a", []) + [app_name],
        i=current.get("i", []) + [no_extra(meta) for meta in metadata_of_participants],
    )


def compress_blob(blob):
    return zstd.compress(pickle.dumps(blob, protocol=pickle.HIGHEST_PROTOCOL))


def decompress_blob(compressed_blob):
    return pickle.loads(zstd.decompress(bytes(compressed_blob)))


def fetch_compressed_blobs_from_zpickle_mmap(pp):
    if not isinstance(pp, mmap.mmap):
        raise ValueError(
            "fetch_compressed_blobs_from_zpickle_mmap must be called with a memory-mapped file"
        )
    mv = memoryview(pp)
    sig = fetch_u64(pp)
    major, minor = check_signature(sig)
    # Find the base position following the vector of offsets which is the origin
    #  for seeking to various blobs
    base = pp.tell()
    nbytes = fetch_u32(pp)
    base += nbytes + u32.size
    nblobs = fetch_u32(pp)
    # Calculate the list of offsets that allow us to get to an arbitrary blob
    offsets = [fetch_u32(pp) for i in range(nblobs)]
    compressed_blobs = []
    for offset in offsets:
        pp.seek(base + offset)
        nbytes = fetch_u32(pp)
        s = slice(base + offset + u32.size, base + offset + u32.size + nbytes)
        compressed_blobs.append(mv[s])
    return compressed_blobs, mv


def get_blobs_from_zpickle(qq):
    try:
        with mmap.mmap(qq.fileno(), 0, prot=mmap.PROT_READ) as pp:
            compressed_blobs, mv = fetch_compressed_blobs_from_zpickle_mmap(pp)
            nblobs = len(compressed_blobs)
            blob_index = 0
            try:
                blob = decompress_blob(compressed_blobs[blob_index])
                next_blob = yield blob, nblobs
                while True:
                    blob_index = blob_index + 1 if next_blob is None else next_blob
                    if 0 <= blob_index < nblobs:
                        blob = decompress_blob(compressed_blobs[blob_index])
                        next_blob = yield (blob)
                    else:
                        break  # StopIteration if we reach an invalid blob
            finally:
                del compressed_blobs
                mv.release()
    except ValueError:
        pass


def emit_zpickle_from_time_series_data_frame(df, metadata=None):
    yield from emit_zpickle_from_data_frame(df, metadata)


def emit_zpickle_from_data_frame(df, metadata=None):
    metadata = metadata.copy()
    history = metadata.pop("_history") if "_history" in metadata else None
    extra = metadata.pop("_extra") if "_extra" in metadata else None
    yield from emit_zpickle_from_blobs([metadata, history, extra, df], maxblobs=4)


def get_time_series_data_frame_from_zpickle(pp, get_history=False, get_extra=False):
    yield from get_data_frame_from_zpickle(pp, get_history, get_extra)


def get_data_frame_from_zpickle(pp, get_history=False, get_extra=False):
    """
    This is a generator with two yields, this handles the standard
    case of having metadata and timeseries data
    """
    try:
        gen = get_blobs_from_zpickle(pp)
        metadata, _ = next(gen)
        if get_history:
            metadata.update(dict(_history=gen.send(1)))
        if get_extra:
            metadata.update(dict(_extra=gen.send(2)))
        columns = yield metadata
        if columns is not None:
            yield gen.send(3)[columns]
        else:
            yield gen.send(3)
    except StopIteration:
        return
    finally:
        gen.close()


def get_combolog_from_zpickle(pp, get_history=False, get_extra=False):
    try:
        gen = get_blobs_from_zpickle(pp)
        metadata, nblobs = next(gen)
        if get_history:
            metadata.update(dict(_history=gen.send(1)))
        if get_extra:
            metadata.update(dict(_extra=gen.send(2)))
        request = yield metadata
        blob = 2
        while True:
            old_blob = blob
            if request is None:
                blob = old_blob + 1
            elif request == "fitdata":
                blob = 3
            elif 0 <= request < nblobs - 4:
                blob = request + 4
            else:
                raise ValueError("Invalid request for combolog data")
            request = yield gen.send(blob)
    except StopIteration:
        return
    finally:
        gen.close()


class Persist:
    def __init__(self):
        self.code_to_ctype = {i: ctype for i, ctype in enumerate(code_to_ctype)}
        self.ctype_to_code = {ctype: code for code, ctype in self.code_to_ctype.items()}
        self.next_code = FIRST_USER_CODE - 1

    def fetch_type_code(self):
        self.next_code += 1
        return self.next_code

    def make_ctype(self, descr):
        """Create a ctypes Structure from a dictionary description of the type"""

        def decode(t):
            # Decode a field description tuple from descr. This consists of a field
            #  name and a built-in or previously defined ctype, which may be an array (of array ,,,,)
            field_name = t[0]
            if isinstance(t[1], int):
                field_type = self.code_to_ctype[t[1]]
            else:
                field_type = self.code_to_ctype[t[1][0]]
                for length in t[1][1]:
                    field_type = field_type * length
            return (field_name, field_type)

        def __repr__(self):
            def handle_array(a):
                if hasattr(a, "_length_"):
                    if a._length_ <= 3:
                        arr_str = ", ".join(
                            f"{handle_array(a[i])}" for i in range(a._length_)
                        )
                    else:
                        arr_str = f"{handle_array(a[0])}, {handle_array(a[1])}, ..., {handle_array(a[a._length_-1])}"
                    return f"[{arr_str}]"
                else:
                    return a

            fields = ", ".join(
                [f"{n}={handle_array(getattr(self, n))}" for n, _ in self._fields_]
            )
            return f"{self.__class__.__name__}({fields})"

        # Construct a ctypes Structure from the description
        dyn_type = type(descr["name"], (ctypes.Structure,), {})
        if "_pack_" in descr:
            dyn_type._pack_ = descr["_pack_"]
        dyn_type._fields_ = [decode(t) for t in descr["fields"]]
        dyn_type.__repr__ = __repr__
        return dyn_type

    def register_struct_type(self, st):
        # Register a subclass of ctypes Structure with type "st"
        # This involves checking if it is already in the self.ctype_to_code
        #  dictionary and placing it there if it is not. While doing this,
        #  it is necessary to construct a description of the class which
        #  includes the _pack_ and _fields_ attributes, so that a dynamic
        #  version of the class can be re-constructed from the emitted byte
        #  stream. The dynamic class is registered into the
        #  self.code_to_ctype list to allow standalone objects of this
        #  class to be constructed.
        if not issubclass(st, ctypes.Structure):
            raise ValueError(f"{st} is not a subclass of ctypes.Structure")
        if st in self.ctype_to_code:
            return
        description = {}
        description["name"] = st.__name__
        description["fields"] = []
        if hasattr(st, "_pack_"):
            description["_pack_"] = st._pack_
        for field in st._fields_:
            ctype = field[1]
            # Deal with arrays (of arrays... of arrays) of ctypes objects. These have
            # the _length_ attribute and the type of the elements in the array is in
            # the attribute _type_)
            if hasattr(ctype, "_length_"):
                lengths = []
                while True:
                    lengths.append(ctype._length_)
                    ctype = ctype._type_
                    if hasattr(ctype, "_length_"):
                        continue
                    elif ctype in self.ctype_to_code:
                        f = list(field)
                        lengths.reverse()
                        f[1] = (self.ctype_to_code[ctype], lengths)
                        description["fields"].append(tuple(f))
                    else:
                        yield from self.register_struct_type(ctype)
                        f = list(field)
                        lengths.reverse()
                        f[1] = (self.ctype_to_code[ctype], lengths)
                        description["fields"].append(tuple(f))
                    break
            # Handle scalars. These do not have any _length_ attribute and we should
            #  not use the _type_ attribute since this is a short string abbrieviation
            #  for the type, rather than the type itself.
            elif ctype in self.ctype_to_code:
                f = list(field)
                f[1] = self.ctype_to_code[ctype]
                description["fields"].append(tuple(f))
            else:
                yield from self.register_struct_type(ctype)
                f = list(field)
                f[1] = self.ctype_to_code[ctype]
                description["fields"].append(tuple(f))
        # We have a description of the type to which we need to assign a typecode
        type_code = self.fetch_type_code()
        # Construct a dynamic type from the description
        dyn_type = self.make_ctype(description)
        self.code_to_ctype[type_code] = dyn_type
        # We associate both the newly created dynamic type and the type of the
        # original object with the type_code since they should have the same structure
        self.ctype_to_code[dyn_type] = type_code
        self.ctype_to_code[st] = type_code
        yield from emit_s32(-type_code)
        yield from emit_as_json(description)

    # =======================================================================
    # emit is a generator which takes an iterable of ctypes objects and
    #      yields a stream of bytes that may be written to a file
    # get is a generator which when given a file-like object yields a
    #      stream of ctypes objects
    # =======================================================================
    def emit(self, objs):
        yield from emit_u64(PicarroSignature())
        for obj in objs:
            # Analyze each object in the stream
            ctype = type(obj)
            # Determine if it is an array (of arrays...)
            lengths = []
            while hasattr(ctype, "_length_"):
                lengths.append(ctype._length_)
                ctype = ctype._type_
            lengths.reverse()
            ndims = len(lengths)
            if ndims > 7:
                raise ValueError("Arrays with more than 7 dimensions are not supported")
            if ctype in self.ctype_to_code:
                # This is based on a built-in type. We emit the code together with
                #  the number of dimensions in the array (0 for a scalar). This number of
                #  dimensions is shifted left by 29 places
                yield from emit_s32(self.ctype_to_code[ctype] | (ndims << 29))
                for i in range(ndims):
                    yield from emit_u32(lengths[i])
                yield bytes(obj)
            elif isinstance(obj, ctypes.Structure):
                # This is a code we have not seen before and we need first to emit a description
                #  of the type
                yield from self.register_struct_type(ctype)
                yield from emit_s32(self.ctype_to_code[ctype] | (ndims << 29))
                for i in range(ndims):
                    yield from emit_u32(lengths[i])
                yield bytes(obj)
            else:
                # Deal with Unions later
                raise NotImplementedError

    def get(self, fp):
        sig = fetch_u64(fp)
        major, minor = check_signature(sig)
        while True:
            try:
                type_code = fetch_s32(fp)

                if type_code < 0:
                    # This is the definition of a new type with a JSON description
                    # Register it for future use
                    descr = fetch_json(fp)
                    dyn_type = self.make_ctype(descr)
                    if -type_code in self.code_to_ctype:
                        raise ValueError("Cannot redefine type with code {-type_code}")
                    self.code_to_ctype[-type_code] = dyn_type
                    self.ctype_to_code[dyn_type] = -type_code
                elif type_code & 0xFFFFFFF in self.code_to_ctype:
                    ndims = (type_code >> 29) & 7
                    ctype = self.code_to_ctype[type_code & 0xFFFFFFF]
                    # Deal with arrays as well as scalars
                    for _ in range(ndims):
                        dim = fetch_u32(fp)
                        ctype = ctype * dim
                    yield ctype.from_buffer_copy(read(fp, ctypes.sizeof(ctype)))
                else:
                    raise NotImplementedError
            except StopIteration:
                return


if __name__ == "__main__":
    a = np.array([1, 2, 3, 4, 5], dtype=np.int32)
    b = np.array([10.0, 9.0, 8.0, 7.0, 6.0], dtype=np.float64)
    c = np.array([4.0, 5.0, 6.0, 7.0, 8.0], dtype=np.float32)
    ra = np.core.records.fromarrays([a, b, c], names=("a", "b", "c"))

    with open("test.dat", "wb") as fp:
        fp.write(b"".join(list(emit_numpy_recarray(ra))))
        # for b in emit_numpy_recarray(ra):
        #     fp.write(b)

    with open("test.dat", "rb") as fp:
        ra = fetch_numpy_recarray(fp)
        print(ra, ra.dtype)

    with open("test.dat", "rb") as fp:
        ra = fetch_numpy_recarray(fp, {"a", "c"})
        print(ra, ra.dtype)

    with open("test.dat", "rb") as fp:
        ra = fetch_numpy_recarray(fp, {"b"})
        print(ra, ra.dtype)

    class ValveSequenceEntryType(ctypes.Structure):
        _fields_ = [("mask_and_value", ctypes.c_uint16), ("dwell", ctypes.c_uint16)]

    class InnerStruct(ctypes.Structure):
        _fields_ = [
            ("f", ctypes.c_int),
            ("g", ctypes.c_short),
            ("i", ValveSequenceEntryType),
        ]

    class MyStruct(ctypes.Structure):
        _fields_ = [
            ("a", ctypes.c_int),
            ("b", ctypes.c_float * 10),
            ("d", InnerStruct * 2),
            ("c", ctypes.c_short),
        ]

    class FunnyStruct(ctypes.Structure):
        _fields_ = [("a", ctypes.c_float), ("b", (ctypes.c_float * 10) * 5)]

    # Construct some complex data types to write to disk and retrieve
    #  These trigger new structure definitions
    ms = MyStruct(a=10, c=42)
    ms.d[0] = InnerStruct(5, 6)
    ms.d[1] = InnerStruct(7, 8)
    ms.b[:3] = [1, 2, 3]
    # The following contains arrays of arrays
    f = FunnyStruct(a=2.71)
    f.b[1][1] = 11

    objects1 = [ctypes.c_float(42.0), ctypes.c_uint(123), ms, f]

    objects2 = [ms, f, ctypes.c_uint(456), ctypes.c_float(56.0), ms]

    # Construct a new Persist object for encoding at the transmitter
    p = Persist()

    # Write out a stream of objects into a file by sending the signature followed by
    #  calling emit() on the objects to send.
    with open("test.dat", "wb") as fp:
        for b in p.emit_u64(PicarroSignature()):
            fp.write(b)
        for b in p.emit(objects1):
            fp.write(b)
        for b in p.emit(objects2):
            fp.write(b)

    # At the receiver we construct a new Persist object for decoding
    q = Persist()

    # Recover the stream of objects
    with open("test.dat", "rb") as fp:
        try:
            for obj in q.get(fp):
                print(obj)
        except OSError as e:
            print(f"Processing terminated: {e}")
