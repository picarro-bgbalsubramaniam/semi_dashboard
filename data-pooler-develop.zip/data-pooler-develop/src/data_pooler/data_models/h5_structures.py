import numpy as np
import pandas as pd
from typing import List

from pydantic import BaseModel

ANALYZER_NAME_PATTERN = r"[A-Z]{2,}\d{4,}"
TIME_CHUNK_SIZE = 3000


class H5SpectralInfo(BaseModel):
    files_info: pd.DataFrame
    scanned_modes: List[int]
    spectral_variables: List[str]
    fitter_variables: List[str]
    datetime_coordinate_utc: pd.DatetimeIndex
    reported_errors: int

    class Config:
        arbitrary_types_allowed = True


class NuTransformInfo(BaseModel):
    f0: np.ndarray
    nu_center: np.ndarray
    nu_squish: np.ndarray
    nu_shift: np.ndarray

    class Config:
        arbitrary_types_allowed = True
