from pydantic import BaseModel, Extra
from typing import Dict, List, Any
from datetime import datetime
import pytz


class History(BaseModel, extra=Extra.forbid):
    """
    This is used to keep track of all operations on data produced in zpickle
    """

    times: List[datetime] = []
    action: List[str] = []
    info: List[str] = []

    def add_history(self, action: str = "Undefined", info: str = "Not recorded"):
        self.times.append(pytz.utc.localize(datetime.utcnow()))
        self.action.append(action)
        self.info.append(info)


class AnalysisHeaderUpdate(BaseModel, extra=Extra.forbid):
    """
    These are the fields that we can use to update our analysis pool file
    """

    extra_results: Any
    info: str
    action: str


class AnalysisHeader(BaseModel, extra=Extra.forbid):
    """
    This model is used for describing the contents of the zpickle

    These fields will be used for easy lookup of file contents and
    other need information for generating reports and finding relevant data
    Attributes:
        name (str) - name of the analysis performed
        history (History) - this keeps track of all data file operations
        source (str) - SAM/NUV1031/etc...  Source of data used to process
        extra_list - a list of objects (dict or other) that are useful for easy lookup
        version - schema version for pydantic models
        blobs_inserted - number of blobs inserted during each operation
    """

    name: str = "Undefined Analysis"
    history: History
    source: str = "Unknown"
    extra_list: List = []
    version: int = 1
    blobs_inserted: List = []

    def update_header(self, header: AnalysisHeaderUpdate, blobs: int):
        """
        This is used when appending analysis to existing zpic file, we need
        update info and the number of blobs inserted
        """
        self.extra_list.append(header.extra_results)
        self.history.add_history(header.action, header.info)
        self.blobs_inserted.append(blobs)
