import pandas as pd
import re
from data_pooler import persist
from data_pooler.pool_utils import safe_update
from data_pooler.logger import get_logger
from pathlib import Path

LOGGER = get_logger(__name__)
PATTERN = r"[A-Z]{2,}\d{4,}"


def update_pool_file(
    output_path,
    input_file,
    date_code,
    start_epoch,
    stop_epoch,
    df_in,
    file_type,
):
    file_name = Path(input_file).name
    if 'NewFitter' in file_name:
        fit_name = 'NewFitter'
    else:
        fit_name = 'OldFitter'
    try:
        source = re.search(PATTERN, str(input_file)).group(0)
    except Exception as e:
        LOGGER.warning(f"Unable to find analyzer with regex: {e}")
        return
    # Get the model name and name of pool file to be updated
    dest_path = (
        output_path
        / source
        / date_code[0]
        / date_code[1]
        / date_code[2]
        / f"{source}_{file_type}_{fit_name}_{start_epoch}_{stop_epoch}.zpic"
    )

    def updater(pp):
        # This updates a pool file associated with the file-like object pp. We cannot run this simultaneously
        #  for the same pool file from multiple processes, so it must be wrapped in a routine which enforces this
        df_new = df_in
        pp.seek(0)
        metadata_current = dict(model=source, file_name=str(dest_path))
        try:
            # We need to merge df_in into the existing pool file if it exists
            gen = persist.get_time_series_data_frame_from_zpickle(
                pp, get_history=True, get_extra=True
            )
            metadata_current = next(gen)
        except StopIteration:
            # Get here if reading the metadata or the dataframe fail. We just do not concatenate the failing frame into df_new
            LOGGER.info(f"Creating pool file {str(dest_path)} with {len(df_in)} records")
        else:
            df_current = next(gen)
            # Merge the data from df_in into df_current, replacing entries grouped by index with last value
            LOGGER.info(f"Updating existing {str(dest_path)} with {len(df_in)} records")
            df_new = pd.concat([df_current, df_in], axis=0).groupby(level=0).last()
        pp.seek(0)
        # Add the history from metadata_in to the current history in an existing pool file
        history_current = metadata_current.get("_history", {})
        history_new = persist.add_to_history(
            history_current,
            "populate_private_log_pool",
            [dict(model=source, file_name=input_file)],
        )
        metadata_current["_history"] = history_new
        # Write out the new version of the pool file
        for b in persist.emit_zpickle_from_time_series_data_frame(
            df_new, metadata_current
        ):
            pp.write(b)

    dest_path.parent.mkdir(parents=True, exist_ok=True)
    safe_update("/tmp/accesslock_" + str(dest_path.stem), dest_path, updater)
