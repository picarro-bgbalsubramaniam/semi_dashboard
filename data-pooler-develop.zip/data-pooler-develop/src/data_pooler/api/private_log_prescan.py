from os import PathLike
from pathlib import Path
from typing import List, Union, Dict

import h5py
import pandas as pd
import pytz
from dask.diagnostics import ProgressBar
import dask.array as da
import numpy as np
import dask.bag as db
import xarray as xr
from pydantic import BaseModel, validator, validate_arguments

from data_pooler.api.api_utils import DATE_FORMAT
from data_pooler.api.combo_log_results import _convert_h5_timestamp
from data_pooler.data_models.h5_structures import TIME_CHUNK_SIZE
from data_pooler.logger import get_logger

LOGGER = get_logger(__name__)


class PrivateLogInfo(BaseModel):
    """
    This model represents info extracted from
    a private log file to preallocate
    a zarr store.

    Attributes:
        timestamp (np.ndarray):
            Timestamps in the private log file.
            Must be sorted in ascending order.
        variables (List[str]):
            List of variables in the private log file.

    """

    timestamp: np.ndarray
    variables: List[str]

    class Config:
        arbitrary_types_allowed = True

    @property
    def start(self) -> int:
        try:
            return self.timestamp[0]
        except IndexError:
            raise IndexError("No timestamp found")

    @property
    def stop(self) -> int:
        try:
            return self.timestamp[-1]
        except IndexError:
            raise IndexError("No timestamp found")

    @property
    def n_points(self) -> int:
        return len(self.timestamp)

    @validator("timestamp")
    def _timestamp_ascending(cls, v):
        if not np.all(np.diff(v) >= 0):
            raise ValueError("Timestamps shall be sorted in ascending order")
        return v


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _scan_private_log(filename: Union[str, PathLike]) -> PrivateLogInfo:
    """
    Scan a private log file and return a PrivateLogInfo object.

    Args:
        filename (Union[str, PathLike]):
            Path to the private log file.

    Returns:
        PrivateLogInfo:
            PrivateLogInfo object.

    Raises:
        KeyError: If the private log file does not contain a TIMESTAMP in the RESULT group.

    """

    with h5py.File(str(filename), "r") as h5file:
        try:
            timestamp = np.array(h5file["results"]["timestamp"]).astype(int)
        except (KeyError, ValueError) as err:
            raise KeyError(
                f"Need TIMESTAMP in the RESULT group of H5 file ({filename})"
            ) from err

        variables = list(h5file["results"].dtype.names)

        log_info = PrivateLogInfo(timestamp=timestamp, variables=variables)

        return log_info


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def prescan_private_logs(
    files_list: List[Union[str, PathLike]]
) -> Dict[str, PrivateLogInfo]:
    """
    Scan a list of private log files and return a dictionary of PrivateLogInfo objects.
    The dictionary is sorted by start timestamp.

    Args:
        files_list (List[Union[str, PathLike]]):
            List of paths to the private log files.

    Returns:
        Dict[str, PrivateLogInfo]:
            Dictionary of PrivateLogInfo objects, sorted by start timestamp.
            Keys are the filenames.

    """
    files_list = [str(file) for file in files_list]

    with ProgressBar():
        results = db.from_sequence(files_list).map(_scan_private_log).compute()

    result_sorted = dict(zip(files_list, results))

    # sort by start timestamp (ascending)
    result_sorted = {
        k: v for k, v in sorted(result_sorted.items(), key=lambda item: item[1].start)
    }

    # check that intervals do not overlap
    _verify_intervals_distinct(result_sorted)

    return result_sorted


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _verify_intervals_distinct(sorted_files_info: Dict[str, PrivateLogInfo]):
    """
    Verify that the intervals of the private log files do not overlap.

    >>> info_ = {
    ...     '0.h5': PrivateLogInfo(timestamp=np.array([1, 2]), variables=['a']),
    ...     '1.h5': PrivateLogInfo(timestamp=np.array([3, 4]), variables=['a']),
    ...     '2.h5': PrivateLogInfo(timestamp=np.array([5, 6]), variables=['a']),
    ... }
    >>> _verify_intervals_distinct(info_)

    >>> info_ = {
    ...     '0.h5': PrivateLogInfo(timestamp=np.array([1, 2]), variables=['a']),
    ...     '1.h5': PrivateLogInfo(timestamp=np.array([2, 3]), variables=['a']),
    ...     '2.h5': PrivateLogInfo(timestamp=np.array([5, 6]), variables=['a']),
    ... }
    >>> _verify_intervals_distinct(info_)  # doctest: +NORMALIZE_WHITESPACE +ELLIPSIS
    Traceback (most recent call last):
    ...
    ValueError: Overlapping intervals: ...

    Args:
        sorted_files_info (Dict[str, PrivateLogInfo]):
            Dictionary of PrivateLogInfo objects, sorted by start timestamp.
            From `.prescan_private_logs()`.

    Returns:
        None

    Raises:
        ValueError: If the intervals overlap.
    """
    previous_interval = None

    for filename, file_info in sorted_files_info.items():
        if previous_interval is not None and file_info.start <= previous_interval.stop:
            raise ValueError(
                f"Overlapping intervals: {previous_interval} and {file_info} (file {filename})"
            )

        previous_interval = file_info


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _preallocate_private_zarr_store(
    zarr_path: Union[str, PathLike],
    local_time_zone: str,
    datetime: pd.DatetimeIndex,
    private_vars: List[str],
    analyzer_name: str,
    private_logs_origin: xr.DataArray,
    time_chunk_size: int = TIME_CHUNK_SIZE,
):
    """
    Preallocate a virtual zarr store based
    on the pre-scan info.

    Args:
        zarr_path (str):
            Path to the zarr store.
        local_time_zone (str):
            Local time zone in pytz format.
        _datetime (pd.DatetimeIndex):
            Datetime index of the private log files.
            It is one of the coordinates of the dataset.
        private_vars (List[str]):
            List of private variables. It is the other
            coordinate of the dataset.
        analyzer_name (str):
            Name of the analyzer. Used as an attribute.
        private_logs_origin (xr.DataArray):
            DataArray containing the origin file
            for each datetime recorded in the dataset.
            Must have dimension ``_datetime`` with the
            same length as ``_datetime``.
        time_chunk_size (int):
            Chunk size for the time dimension.
    Returns:
        None

    Raises:
        ValueError: If _datetime is not a coordinate of private_logs_origin.
        ValueError: If private_logs_origin _datetime does not have the same length as _datetime.
        ValueError: If local_time_zone is not in pytz.all_timezones.

    """
    time_len = len(datetime)
    private_vars_len = len(private_vars)

    if "_datetime" not in private_logs_origin.dims:
        raise ValueError("private_logs_origin must have dimension '_datetime'")

    if private_logs_origin.sizes["_datetime"] != time_len:
        raise ValueError("private_logs_origin must have the same length as _datetime")

    if local_time_zone not in pytz.all_timezones:
        raise ValueError(
            f"Time zone {local_time_zone} is not in list of pytz timezones"
        )

    LOGGER.info(f"Pre-allocating virtual zarr store at {zarr_path}")

    # Dummy lazy dask array
    dummies = da.zeros((time_len, private_vars_len), chunks=(time_chunk_size, -1))

    ds_dummy = xr.Dataset({"private_values": (("_datetime", "private_var"), dummies)})
    ds_dummy = ds_dummy.assign_coords(
        {
            "_datetime": datetime,
            "private_var": private_vars,
        }
    )

    LOGGER.info("Adding private_logs_origin to zarr store")
    ds_dummy["private_logs_origin"] = private_logs_origin

    ds_dummy.attrs["tz"] = local_time_zone
    ds_dummy.attrs["analyzer"] = analyzer_name
    ds_dummy.attrs["Start"] = f"{datetime[0]:{DATE_FORMAT}}"
    ds_dummy.attrs["Stop"] = f"{datetime[-1]:{DATE_FORMAT}}"

    ds_dummy.to_zarr(
        store=zarr_path, mode="w", compute=False
    )  # It is a delayed operation

    LOGGER.info(
        f"Virtual pre-allocation successful. Private values size: {dummies.shape}"
    )


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _get_file_origin(
    files_info: Dict[str, PrivateLogInfo],
    local_time_zone: str = "US/Pacific",
) -> xr.DataArray:
    """
    Get the origin file for each datetime recorded in the dataset
    starting from the pre-scan info from `.prescan_private_logs()`.
    >>> info_ = {
    ...     '0.h5': PrivateLogInfo(timestamp=np.array([63825842106000]), variables=['a', 'b']),
    ...     '1.h5': PrivateLogInfo(timestamp=np.array([63825842107000]), variables=['b', 'c']),
    ...     '2.h5': PrivateLogInfo(timestamp=np.array([63825842108000]), variables=['c', 'd']),
    ... }
    >>> _get_file_origin(info_, local_time_zone="US/Pacific")  # doctest: +NORMALIZE_WHITESPACE +ELLIPSIS
    <xarray.DataArray 'private_logs_origin' (_datetime: 3)>
    array(['0.h5', '1.h5', '2.h5'], dtype='<U4')
    Coordinates:
      * _datetime  (_datetime) datetime64[ns] 2023-07-24T17:35:06 ...
    Attributes:
        files:    ['0.h5', '1.h5', '2.h5']


    Args:
        files_info (Dict[str, PrivateLogInfo]):
            Dictionary of PrivateLogInfo objects, sorted by start timestamp.
        local_time_zone (str):
            Local time zone in pytz format.

    Returns:
        xr.DataArray:
            DataArray containing the origin file for each datetime recorded in the dataset.
            It has an attribute "files" containing the unique files list.

    """
    if local_time_zone not in pytz.all_timezones:
        raise ValueError(
            f"Time zone {local_time_zone} is not in list of pytz timezones"
        )

    unique_files_list = [Path(file).name for file in files_info.keys()]

    timestamps = np.array([])
    files_list = []

    for k, v in files_info.items():
        filename = Path(k).name
        timestamps = np.append(timestamps, v.timestamp)
        files_list.extend([filename] * v.n_points)

    datetime = _convert_h5_timestamp(timestamps)
    datetime = datetime.tz_localize("UTC").tz_convert(local_time_zone).tz_localize(None)

    file_origin = xr.DataArray(
        files_list,
        dims="_datetime",
        coords={"_datetime": datetime},
        name="private_logs_origin",
        attrs={"files": unique_files_list},
    )
    return file_origin


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _get_private_vars(
    files_info: Dict[str, PrivateLogInfo],
) -> List[str]:
    """
    Get the list of private variables from the pre-scan info.
    A private variable is included in the result as long
    as it is present in at least one of the private log files.

    >>> info_ = {
    ...     '0.h5': PrivateLogInfo(timestamp=np.array([1]), variables=['a', 'b']),
    ...     '1.h5': PrivateLogInfo(timestamp=np.array([2]), variables=['b', 'c']),
    ...     '2.h5': PrivateLogInfo(timestamp=np.array([3]), variables=['c', 'd']),
    ... }
    >>> _get_private_vars(info_)
    ['a', 'b', 'c', 'd']

    Args:
        files_info (Dict[str, PrivateLogInfo]):
            Dictionary of PrivateLogInfo objects, sorted by start timestamp.

    Returns:
        List[str]:
            List of private variables.

    """
    all_vars = set()
    for v in files_info.values():
        all_vars.update(v.variables)
    all_vars = sorted(list(all_vars))
    return all_vars


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _get_time_regions(
    files_info: Dict[str, PrivateLogInfo],
) -> Dict[str, slice]:
    """
    Get the indexes of the time regions corresponding to each file.

    >>> info_ = {
    ...     '0.h5': PrivateLogInfo(timestamp=np.array([1, 2, 3]), variables=['a', 'b']),
    ...     '1.h5': PrivateLogInfo(timestamp=np.array([4, 5, 6]), variables=['b', 'c']),
    ...     '2.h5': PrivateLogInfo(timestamp=np.array([7, 8, 9]), variables=['c', 'd']),
    ... }
    >>> _get_time_regions(info_)
    {'0.h5': slice(0, 3, None), '1.h5': slice(3, 6, None), '2.h5': slice(6, 9, None)}

    Args:
        files_info (Dict[str, PrivateLogInfo]):
            Dictionary of PrivateLogInfo objects, sorted by start timestamp.

    Returns:
        Dict[str, slice]:
            Dictionary of slices, sorted by start timestamp.
            Keys are the filenames. Values are the slices.
            Examples:
                {'2020-10-01_000000.h5': slice(0, 1000, None)}

    """
    time_slices = {}
    start_time = 0
    for filename, ti in files_info.items():
        time_slices[filename] = slice(start_time, start_time + ti.n_points)
        start_time += ti.n_points

    return time_slices
