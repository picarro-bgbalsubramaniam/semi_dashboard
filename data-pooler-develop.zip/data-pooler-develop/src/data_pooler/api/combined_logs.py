from datetime import datetime as dt
from pathlib import Path
from typing import List, Union

import numpy as np
import pandas as pd
import pytz

from data_pooler.data_access_utils import get_file_paths_in_timerange
from data_pooler.pool_utils import get_data_frame
from data_pooler import persist

TIME_REP = "%Y-%m-%d %H:%M:%S"
DEFAULT_COMBO_COLUMNS = [
    "fitData_nu_transform_n0",
    "fitData_nu_transform_n1",
    "f0",
    "f0_shift",
    "fitData_nu_transform_nnuc",
    "fitData_fitdata_params_nucenter"
]

def get_timeseries_with_combo_info(
    start_local: str,
    end_local: str,
    time_zone: str,
    pool_location: Union[str, Path],
    private_columns: Union[List, None] = None,
    combo_columns: Union[List, None] = DEFAULT_COMBO_COLUMNS,
    combo_fit_type: str = "broadband",
    private_fit_type: str = "NewFitter",
):
    """
    This function access the private logs and combo logs and joins them
    Times are expected as local time for the time zone being input

    Args:
        start_local: Beginning time of logs in format ('2022-03-09 00:00:00')
        end_local: End time of logs in format ('2022-03-10 23:00:00')
        time_zone: pytz timezone from list pytz.all_timezones
        pool_location: string or Path to the pool source ('/home/picarro/pools/NUV1047')
        private_columns: list of columns we'd like to access from private logs, defaults to all
        combo_columns: list of columns we'd like to access from the combo logs, defaults to only a few columns
                        needed to compactify data
        combo_fit_type: type of fitter you'd like to read (i.e. "broadband")
        private_fit_type: "NewFitter" or "OldFitter" for VOC private or old fitter private logs
    Returns:
        pd.DataFrame with private logs and information pointing to combo logs spectra
        with timezone aware Timestamp index and only values within time range
    """
    if time_zone not in pytz.all_timezones:
        raise ValueError(f"Time zone {time_zone} is not in list of pytz timezones")

    tz_aware = pytz.timezone(time_zone)
    start_tz = tz_aware.localize(dt.strptime(start_local, TIME_REP))
    end_tz = tz_aware.localize(dt.strptime(end_local, TIME_REP))

    # Access combo logs
    combo_files = get_file_paths_in_timerange(
        start_tz, end_tz, Path(pool_location), ["ComboLog", combo_fit_type]
    )
    if not combo_files:
        raise ValueError(
            f"Unable to find combo logs in pool {str(pool_location)} "
            f"for specified dates {start_local} to {end_local}"
        )

    private_files = get_file_paths_in_timerange(
        start_tz, end_tz, Path(pool_location), ["PrivateLog", private_fit_type]
    )
    if not private_files:
        raise ValueError(
            f"Unable to find private logs in pool {str(pool_location)} "
            f"for specified dates {start_local} to {end_local}"
        )

    # Iterate through combo logs to add associated meta data for spectra
    final_combo_df = pd.DataFrame()
    for file in combo_files:
        combo_df = get_data_frame([file], columns=combo_columns)
        combo_df["spec_gen_id"] = np.arange(len(combo_df.index))
        combo_df["spec_gen_file"] = file
        final_combo_df = pd.concat([final_combo_df, combo_df])

    # Access private logs
    private_df = get_data_frame(private_files, columns=private_columns)

    # Join private and combo dataframes
    combined_df = pd.merge_asof(
        private_df,
        final_combo_df,
        left_index=True,
        right_index=True,
        tolerance=pd.Timedelta(seconds=1),
    )

    # Drop data where we couldn't match combo/private and clip times
    if private_fit_type == "NewFitter":
        combined_df = combined_df.dropna()

    # Shift to correct timezone
    return_df = combined_df.reindex(combined_df.index.tz_convert(time_zone))
    return_df = return_df[start_local:end_local]

    return return_df


def get_private_df(
    start_local: str,
    end_local: str,
    time_zone: str,
    pool_location: Union[str, Path],
    private_columns: Union[List, None] = None,
    private_fit_type: str = "NewFitter",
):
    """
    This function access the private logs and produces a data frame

    Args:
        start_local: Beginning time of logs in format ('2022-03-09 00:00:00')
        end_local: End time of logs in format ('2022-03-10 23:00:00')
        time_zone: pytz timezone from list pytz.all_timezones
        pool_location: string or Path to the pool source ('/home/picarro/pools/NUV1047')
        combo_columns: list of columns to get, if None will return all columns
        private_fit_type: "NewFitter" or "OldFitter" for VOC private or old fitter private logs
    Returns:
        pd.DataFrame with private time series data in time range
    """
    if time_zone not in pytz.all_timezones:
        raise ValueError(f"Time zone {time_zone} is not in list of pytz timezones")

    tz_aware = pytz.timezone(time_zone)
    start_tz = tz_aware.localize(dt.strptime(start_local, TIME_REP))
    end_tz = tz_aware.localize(dt.strptime(end_local, TIME_REP))

    private_files = get_file_paths_in_timerange(
        start_tz, end_tz, Path(pool_location), ["PrivateLog", private_fit_type]
    )
    if not private_files:
        raise ValueError(
            f"Unable to find private logs in pool {str(pool_location)} "
            f"for specified dates {start_local} to {end_local}"
        )

    private_df = get_data_frame(private_files, columns=private_columns)

    return_df = private_df.reindex(private_df.index.tz_convert(time_zone))
    return_df = return_df[start_local:end_local]

    return return_df


def get_combo_df(
    start_local: str,
    end_local: str,
    time_zone: str,
    pool_location: Union[str, Path],
    combo_columns: Union[List, None] = None,
    combo_fit_type: str = "broadband",
):
    """
    This function access the combo logs and adds columns spec_gen_id and spec_gen_file

    Args:
        start_local: Beginning time of logs in format ('2022-03-09 00:00:00')
        end_local: End time of logs in format ('2022-03-10 23:00:00')
        time_zone: pytz timezone from list pytz.all_timezones
        pool_location: string or Path to the pool source ('/home/picarro/pools/NUV1047')
        combo_columns: list of columns to get, if None will return all columns
        combo_fit_type: type of fitter you'd like to read (i.e. "broadband")
    Returns:
        pd.DataFrame with combo logs time series and file/spectrum number
    """
    if time_zone not in pytz.all_timezones:
        raise ValueError(f"Time zone {time_zone} is not in list of pytz timezones")

    tz_aware = pytz.timezone(time_zone)
    start_tz = tz_aware.localize(dt.strptime(start_local, TIME_REP))
    end_tz = tz_aware.localize(dt.strptime(end_local, TIME_REP))

    # Access combo logs
    combo_files = get_file_paths_in_timerange(
        start_tz, end_tz, Path(pool_location), ["ComboLog", combo_fit_type]
    )
    if not combo_files:
        raise ValueError(
            f"Unable to find combo logs in pool {str(pool_location)} "
            f"for specified dates {start_local} to {end_local}"
        )

    # Iterate through combo logs to add associated meta data for spectra
    final_combo_df = pd.DataFrame()
    for file in combo_files:
        combo_df = get_data_frame([file], columns=combo_columns)
        combo_df["spec_gen_id"] = np.arange(len(combo_df.index))
        combo_df["spec_gen_file"] = file
        final_combo_df = pd.concat([final_combo_df, combo_df])

    # Shift to correct timezone
    return_df = final_combo_df.reindex(final_combo_df.index.tz_convert(time_zone))
    return_df = return_df[start_local:end_local]

    return return_df
