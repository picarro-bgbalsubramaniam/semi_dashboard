import pandas as pd
import tables
import re
from pathlib import Path
from data_pooler import persist
from data_pooler.logger import get_logger
from data_pooler.pool_utils import safe_update
from datetime import timedelta
from data_pooler.timeutils import ORIGIN, UNIXORIGIN


LOGGER = get_logger(__name__)
PATTERN = r"[A-Z]{2,}\d{4,}"


def emit_combo_log_df_from_h5(input_file, collation_interval):
    """Generate data frames and spectra from an input combo log file in csv format such that
    the timestamps lie between n*collation_interval and (n+1)*collation_interval. The collation
    interval is expressed in seconds and it must divide 1 day (86400s)"""
    if (24 * 60 * 60) % collation_interval != 0:
        raise ValueError("Collation interval must divide 24 hours")
    # The fields in the filename are separated by "_"
    #        self.file_stem = f'{self.ymd}_{self.hms}'
    #        fname = f'{self.hostname}_{fitname}_{self.file_stem}_{self.file_counters[fitname]}.h5'
    #  0: 6372-NUV1028      hostname
    #  1: broadband         fitname
    # -3: 20210524          Ymd
    # -2: 000002            HMS
    # -1: 0                 counter
    stem = Path(input_file).stem
    fields = stem.split("_")
    model = re.search(PATTERN, str(input_file)).group(0)
    fit_name = fields[1]
    try:
        with tables.open_file(input_file, "r") as h5:
            # Handle spectra by generating a dictionary with a dataframe for each spectrum
            spectra_df = {}
            for spectrum in h5.root.spectra:
                # The nodes of a spectrum are parallel arrays containing absorbance,
                #  the big3 etc. We convert them to a pandas data frame and place this
                #  in a dictionary indexed by the session row id which is in spectrum._v_name
                spectra_df[int(spectrum._v_name)] = pd.DataFrame.from_dict(
                    {node.name: node.read() for node in spectrum}
                )
            # Handle fit data portion by generating a data frame
            fit_data_dict = dict()
            for node in h5.root.results:
                try:
                    fit_data_dict[node.name] = node.read()
                except AttributeError:
                    pass
            fit_data_df = pd.DataFrame.from_dict(fit_data_dict)

            # Set up a UTC localized date-time index based on the timestamp
            fit_data_df["_datetime"] = [
                ORIGIN + timedelta(milliseconds=ts) for ts in fit_data_df.timestamp
            ]
            fit_data_df.set_index("_datetime", inplace=True)
            # We break this into separate sections according to the collation interval
            periods = pd.Series(
                [
                    int((dt - UNIXORIGIN).total_seconds() // collation_interval)
                    for dt in fit_data_df.index
                ],
                index=fit_data_df.index,
            )
            for period in periods.unique():
                fit_data_dff = fit_data_df[periods == period]
                # Collect the spectra into a list using the row_ids
                spectra_dff = [spectra_df.get(row, None) for row in fit_data_dff.row_id]
                # Get the year, month and day as a tuple for the directory name
                date_code = (fit_data_dff.index.date[0].strftime("%Y/%m/%d")).split("/")
                # Get the start and end epoch times
                start_epoch = period * collation_interval
                end_epoch = start_epoch + collation_interval
                # Generate some initial metadata
                metadata = dict(
                    fit_name=fit_name, model=model, file_name=input_file, _history={}
                )
                yield metadata, date_code, start_epoch, end_epoch, fit_data_dff, spectra_dff

    except Exception as e:
        LOGGER.warning(f"There was an issue reading {input_file}: {e}")


def update_pool_file(
    output_path,
    metadata_in,
    date_code,
    start_epoch,
    end_epoch,
    fit_data_in,
    spectra_in,
    file_type,
):
    # Get the model name and name of pool file to be updated
    model = metadata_in.get("model", "UNKNOWN")
    fit_name = metadata_in.get("fit_name", "UNKNOWN")
    dest_path = (
        output_path
        / model
        / date_code[0]
        / date_code[1]
        / date_code[2]
        / f"{model}_{file_type}_{fit_name}_{start_epoch}_{end_epoch}.zpic"
    )

    def updater(pp):
        # This updates a pool file associated with the file-like object pp. We cannot run this simultaneously
        #  for the same pool file from multiple processes, so it must be wrapped in a routine which enforces this
        rows_in = len(fit_data_in)

        # Initialize the output variables with the input in case there are no data currently in the pool for this collation interval
        fit_data_new = fit_data_in.copy()
        # Define an additional column _sequence which is used to help combine the spectra
        fit_data_new["_sequence"] = list(range(rows_in))
        compressed_spectra_in = [
            persist.compress_blob(spectrum) for spectrum in spectra_in
        ]
        if rows_in != len(compressed_spectra_in):
            raise ValueError(
                f'Inconsistent number of spectra in incoming combo log {metadata_in["file_name"]}'
            )

        compressed_spectra_new = compressed_spectra_in
        metadata_current = dict(
            model=model, file_name=str(dest_path), fit_name=fit_name
        )
        history_current = {}
        extra_new = {}
        extra_current = {}
        pp.seek(0)
        try:
            compressed_blobs = persist.fetch_compressed_blobs_from_zpickle(pp)
        except ValueError:
            # Get here if reading the metadata or the dataframe fail. We just 
            # do not concatenate the failing frame into df_new
            LOGGER.warning(
                f"Creating pool file {str(dest_path)} with {len(fit_data_in)} records"
            )
        else:
            metadata_current = persist.decompress_blob(compressed_blobs[0])
            history_current = persist.decompress_blob(compressed_blobs[1])
            extra_current = persist.decompress_blob(compressed_blobs[2])
            fit_data_current = persist.decompress_blob(compressed_blobs[3])
            rows_current = len(fit_data_current)
            fit_data_current["_sequence"] = list(range(rows_in, rows_in + rows_current))
            compressed_spectra_current = compressed_blobs[4:]
            if rows_current != len(compressed_spectra_current):
                raise RuntimeError(
                    f"Inconsistent number of spectra for combo log {dest_path} in pool"
                )
            # We need to merge fit_data into the existing pool file fit_data if it exists
            # Merge the data, replacing entries grouped by index with last value
            LOGGER.info(f"Updating existing {str(dest_path)} with {len(fit_data_in)} records")
            fit_data_new = (
                pd.concat([fit_data_current, fit_data_new], axis=0)
                .groupby(level=0)
                .last()
            )
            compressed_spectra = compressed_spectra_in + compressed_spectra_current
            compressed_spectra_new = [
                compressed_spectra[s] for s in fit_data_new["_sequence"]
            ]
            fit_data_new.drop("_sequence", axis="columns", inplace=True)
        pp.seek(0)
        # Add the history from metadata_in to the current history in an existing pool file
        metadata_new = metadata_current.copy()
        history_new = persist.add_to_history(
            history_current, "populate_combo_log_pool", [metadata_in]
        )
        extra_new = extra_current
        compressed_blobs_new = []
        compressed_blobs_new.append(persist.compress_blob(metadata_new))
        compressed_blobs_new.append(persist.compress_blob(history_new))
        compressed_blobs_new.append(persist.compress_blob(extra_new))
        compressed_blobs_new.append(persist.compress_blob(fit_data_new))
        compressed_blobs_new.extend(compressed_spectra_new)
        # Write out the new version of the pool file
        for b in persist.emit_zpickle_from_compressed_blobs(
            compressed_blobs_new, len(compressed_blobs_new)
        ):
            pp.write(b)

    dest_path.parent.mkdir(parents=True, exist_ok=True)
    safe_update("/tmp/accesslock_" + str(dest_path.stem), dest_path, updater)
