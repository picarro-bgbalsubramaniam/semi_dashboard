import os
from pathlib import Path
import pandas as pd
from pandas import DataFrame as df
from typing import TextIO, List, Dict, Any, Union
from data_pooler import persist
from data_pooler.logger import get_logger
from data_pooler.pool_utils import safe_update
from data_pooler.data_models.meta_header import (
    AnalysisHeader,
    History,
    AnalysisHeaderUpdate,
)


LOGGER = get_logger(__name__)


class AnalysisPooler:
    """
    This class is a conenvience object for pooling analysis data and metadata

    Args:
        pool_path (str): Full path to pool location (i.e. /usr/bin/pool)
        date_code (list{str}): list of year, month, day (i.e. ['2022', '03', '07'])
        source (str): Name of source for data (i.e. 'NUV1031', 'Infineon Data')
        analysis (str): Name of analysis performed
    """

    def __init__(self, pool_path: Path, date_code: list, source: str, analysis: str):
        self._pool_path = pool_path
        self.date_code = date_code
        self.source = source
        self.analysis = analysis
        self._dest_path = self._get_dest_path()

    @property
    def dest_path(self):
        """
        Full path to zpickle
        """
        return self._dest_path

    @dest_path.setter
    def dest_path(self, path: Union[str, Path]):
        """
        Path setter in case you want to redirect output,
        must be a string or PosixPath object
        """
        self._dest_path = Path(path)

    @property
    def pool_path(self):
        """
        Path to pool
        """
        return self._pool_path

    @pool_path.setter
    def pool_path(self, path):
        """
        Path setter in case you want to redirect output
        Args:
            path (str/PosixPath): path to different pool
        """
        self._pool_path = Path(path)

    @property
    def _fp_read(self):
        return open(self.dest_path, "r")

    @property
    def _fp_append(self):
        return open(self.dest_path, "a")

    def _get_dest_path(self):
        """
        Convenience function for combining all settable properties
        to direct zpickle location
        """
        dest_path = (
            self.pool_path
            / self.source
            / self.date_code[0]  # year
            / self.date_code[1]  # month
            / self.date_code[2]  # day
            / f"{self.source}_{self.analysis}.zpic"
        )
        return dest_path

    @property
    def meta(self):
        """
        In case we just want to get the meta data
        """
        try:
            data_gen = persist.get_blobs_from_zpickle(self._fp_read)
            meta, nblobs = next(data_gen)
            data_gen.close()
        except (StopIteration, FileNotFoundError):
            meta = {}
            nblobs = 0
        return meta, nblobs

    def get_data(self):
        """
        Get the data in the zpickle analysis file
        """
        try:
            data_gen = persist.get_blobs_from_zpickle(self._fp_read)
            while True:
                yield next(data_gen)
        except StopIteration:
            data_gen.close()
        except FileNotFoundError:
            LOGGER.warning("You have not created any analysis yet")
            yield None

    def update_data(self, data: List[Any], header_info: AnalysisHeaderUpdate):
        """
        Update data that already exists in data pool file
        Args:
            data: This can be any object produced during analysis
            header_info: Basic header to describe analysis in zpic file
        """

        def updater(file_pointer: TextIO):
            try:
                LOGGER.info("Appending analysis data to existing")
                data_gen = persist.get_blobs_from_zpickle(self._fp_read)
                header, nblobs = next(data_gen)
                current_blobs = list(data_gen)
                write_blobs = current_blobs + data

                # Add data to header
                header = AnalysisHeader.parse_obj(header)
                header.update_header(header_info, len(data))
                payload = []
                payload.append(header.dict())
                payload.extend(write_blobs)
                for b in persist.emit_zpickle_from_blobs(payload, maxblobs=len(write_blobs) + 1):
                    file_pointer.write(b)
            except StopIteration:
                LOGGER.warning(f"No data found in {self.dest_path}")

        if not self.dest_path.exists():
            LOGGER.warning(
                f"{self.dest_path} does not exist yet, please write data first"
            )
        else:
            safe_update(
                f"/tmp/accesslock_{self.dest_path.stem}", self.dest_path, updater
            )

    def write_data(self, data: List[Any], header_info: AnalysisHeader):
        """
        Write an analysis data frame with option to add notes and extra json
        Args:
            data: This can be any object produced during analysis
            header_info: Basic header to describe analysis in zpic file
        """

        def writer(file_pointer: TextIO):
            LOGGER.info(f"This is the first entry to {file_pointer.name}")
            payload = []
            header_info.blobs_inserted = [len(data)]
            payload.append(header_info.dict())
            payload.extend(data)
            for b in persist.emit_zpickle_from_blobs(payload, maxblobs=len(data) + 1):
                file_pointer.write(b)

        self.dest_path.parent.mkdir(parents=True, exist_ok=True)
        safe_update(f"/tmp/accesslock_{self.dest_path.stem}", self.dest_path, writer, overwrite=True)
