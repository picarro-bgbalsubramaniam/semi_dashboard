"""Read RESULTS group from H5 private logs files"""
import os
import shutil
import zipfile
from pathlib import Path

from typing import List, Optional, Union, Dict
from dask.distributed import Lock, LocalCluster, Client, progress, wait
from os import PathLike

import h5py
import numpy as np
import pandas as pd
import pytz
import xarray as xr
from pydantic import validate_arguments

from data_pooler.api.api_utils import DATE_FORMAT

from data_pooler.api.api_utils import (
    FileTypeEnum,
    check_for_overlapping_files,
    get_analyzer_name,
)
from data_pooler.api.private_log_prescan import (
    PrivateLogInfo,
    prescan_private_logs,
    _get_private_vars,
    _get_time_regions,
    _preallocate_private_zarr_store,
    _get_file_origin,
)
from data_pooler.data_models.h5_structures import TIME_CHUNK_SIZE
from data_pooler.logger import get_logger

LOGGER = get_logger(__name__)

NEW_FITTER_KEYS = ["NewFitter_Private", "Standard_Private"]


@validate_arguments()
def read_private_logs_xarray(
    folder_path: Union[str, Path],
    local_time_zone: str,
    path_to_zarr: str,
    analyzer_name: Optional[str] = None,
    chunk_time_size: int = TIME_CHUNK_SIZE,
) -> str:
    """
    Reads RESULTS group (timeseries data)
    from private logs H5 files.

    Args:
        folder_path (str):
            Folder path where the private logs
             .zip files are located.
        local_time_zone (str):
            Local time zone.
            Example `US/Pacific`.
        path_to_zarr (str):
            Location (folder) of the exported zarr store.
            The zarr store path is going to be:
            ``path_to_zarr/analyzer_name.zarr``.
        analyzer_name (str):
             Analyzer name. If None (default), it will be
            inferred from the first H5 file found at
            ``folder_path``.
        chunk_time_size (int):
            Chunk size for Dask arrays along the time axis.
            See https://docs.dask.org/en/stable/array-best-practices.html#select-a-good-chunk-size

    Returns:
        str: Path to the private logs zarr store.
    """

    if chunk_time_size < 0:
        raise ValueError("Chunk size must be positive")

    if local_time_zone not in pytz.all_timezones:
        raise ValueError("Time zone not in list of pytz timezones")

    folder_path = Path(folder_path)
    files_list = get_private_logs_files_paths(folder_path=folder_path)

    if analyzer_name is None:
        analyzer_name = get_analyzer_name(files_list[0])

    zarr_store_path = Path(f"{path_to_zarr}/{analyzer_name}_privatelogs_NewFitter.zarr")
    initial_len = len(files_list)
    files_list = check_for_overlapping_files(
        files_list, zarr_store_path, FileTypeEnum.privatelogs
    )

    if not files_list:
        raise ValueError("No unique files found in private log file list")
    else:
        LOGGER.info(
            f"Found {initial_len - len(files_list)} overlapping files, "
            f"pooling {len(files_list)} files"
        )

    tmp_path = Path(f"{path_to_zarr}/tmp_{analyzer_name}_privatelogs_NewFitter.zarr")

    LOGGER.info("Pre-scan files")
    files_info = prescan_private_logs(files_list)

    LOGGER.info("Get private variables")
    private_vars = _get_private_vars(
        files_info=files_info,
    )

    LOGGER.info("Get file origin")
    file_origin = _get_file_origin(
        files_info=files_info, local_time_zone=local_time_zone
    )

    LOGGER.info("Get time axis")
    datetime_ = pd.to_datetime(file_origin["_datetime"].values)

    _preallocate_private_zarr_store(
        zarr_path=tmp_path,
        local_time_zone=local_time_zone,
        datetime=datetime_,
        private_vars=private_vars,
        analyzer_name=analyzer_name,
        time_chunk_size=chunk_time_size,
        private_logs_origin=file_origin,
    )

    _h5s_privatelogs_to_zarr(
        files_info=files_info,
        allocated_store_path=tmp_path,
    )

    LOGGER.info(f"Removing temporary H5 files from {folder_path / 'tmp'}...")
    _tmp_files_cleanup(tmp_folder=str(folder_path / "tmp"))

    if zarr_store_path.exists():
        LOGGER.info(
            f"Found existing private log store at {zarr_store_path}, appending data"
        )
        timeseries_ds = xr.open_zarr(tmp_path)
        merge_private_zarr_stores(zarr_store_path, timeseries_ds, chunk_time_size)
        timeseries_ds.close()
        LOGGER.info(f"Removing temporary zarr store {tmp_path}")
        shutil.rmtree(tmp_path)
    else:
        LOGGER.info(f"Moving tmp store {tmp_path} to {zarr_store_path}")
        os.rename(tmp_path, zarr_store_path)

    return zarr_store_path


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def merge_private_zarr_stores(
    zarr_store_path: Union[str, PathLike],
    private_ds: xr.Dataset,
    chunk_time_size: int,
) -> Union[str, PathLike]:
    """
    Merge the new private data into existing zarr store

    Args:
        zarr_store_path (str): Path to existing zarr store
        private_ds (xr.Dataset):
            Dataset of new private data.
            Must have variable `private_values`, and dimensions
            `_datetime` and `private_var`.
        chunk_time_size (int):
            Chunk size for Dask arrays along the time axis.
            Must be positive.

    Returns:
        str: Path to the private logs zarr store.


    """
    if chunk_time_size < 0:
        raise ValueError("Chunk size must be positive")

    if "private_values" not in private_ds.data_vars:
        raise ValueError("private_values variable not found in private_ds")

    if not all([dim_ in private_ds.dims for dim_ in ["_datetime", "private_var"]]):
        raise ValueError(
            "private_ds must have dimensions `_datetime` and `private_var`"
        )

    original_ds = xr.open_zarr(zarr_store_path)
    # Update start and end values
    new_start = min(
        pd.Timestamp(original_ds.attrs["Start"]),
        pd.Timestamp(private_ds.attrs["Start"]),
    )
    new_end = max(
        pd.Timestamp(original_ds.attrs["Stop"]),
        pd.Timestamp(private_ds.attrs["Stop"]),
    )

    # Update files
    files = (
        original_ds.private_logs_origin.attrs["files"]
        + private_ds.private_logs_origin.attrs["files"]
    )

    # Merge datasets
    new_ds = xr.merge([original_ds, private_ds], compat="no_conflicts")

    assert pd.DatetimeIndex(
        new_ds["_datetime"]
    ).is_monotonic_increasing, "Time axis not monotonic increasing"

    original_ds.close()
    private_ds.close()

    new_ds.attrs["Start"] = f"{new_start:{DATE_FORMAT}}"
    new_ds.attrs["Stop"] = f"{new_end:{DATE_FORMAT}}"
    new_ds.private_logs_origin.attrs["files"] = files

    new_ds["private_logs_origin"] = new_ds["private_logs_origin"].astype(str)
    new_ds["private_var"] = new_ds["private_var"].astype(str)
    new_ds = new_ds.chunk({"_datetime": chunk_time_size, "private_var": -1})

    try:
        new_ds.to_zarr(zarr_store_path, mode="w", safe_chunks=True)
        new_ds.close()
    except (TypeError, ValueError) as e:
        raise ValueError(f"Merging of private logs to zarr path failed") from e

    return zarr_store_path


@validate_arguments()
def get_private_logs_files_paths(folder_path: Union[str, Path]) -> List[str]:
    """
    Get NewFitter H5 files from unzipping
    zip files from a folder (to a temporary folder).
    The search is recursive.

    Args:
        folder_path (str):
            Path to inspect.

    Returns:
        List[str]: List of files.

    """
    folder_path = Path(folder_path)
    ziplist = folder_path.rglob("*.zip")
    ziplist = [str(file) for file in ziplist if file.is_file()]

    if len(ziplist) == 0:
        raise FileNotFoundError("No zip files found in the directory.")

    LOGGER.info(f"Inspecting folder {folder_path}, found {len(ziplist)} zip files")

    flist = []
    for file in ziplist:
        with zipfile.ZipFile(file) as z:
            for h5file_name in z.namelist():
                if any(
                    private_log_key in h5file_name
                    for private_log_key in NEW_FITTER_KEYS
                ):
                    LOGGER.debug("Reading %s private log", str(h5file_name))
                    flist.append(
                        z.extract(member=h5file_name, path=Path(folder_path) / "tmp")
                    )

    LOGGER.info(f"Extracted {len(flist)} H5 files in {Path(folder_path) / 'tmp'}")
    return flist


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def append_private_logs_to_spectral_zarr(
    ds_private: xr.Dataset,
    zarr_store_path: str,
    chunk_time_size: int = TIME_CHUNK_SIZE,
):
    if not Path(zarr_store_path).exists():
        raise FileNotFoundError("Zarr store not found")

    if chunk_time_size < 0:
        raise ValueError("Chunk size must be positive")

    ds_spectral = xr.open_zarr(zarr_store_path)

    ds_private = ds_private.reindex_like(
        other=ds_spectral,
        fill_value=np.NaN,
        tolerance=pd.Timedelta("1s"),
        method="nearest",
    )

    # Overwrite attrs
    ds_private.attrs = ds_spectral.attrs
    ds_spectral.close()

    # Chunk time axis
    ds_private = ds_private.chunk(
        {"_datetime": chunk_time_size, "private_var": ds_private.private_var.shape[0]}
    )

    # Make sure strings are saved as strings after rechunking
    ds_private["private_logs_origin"] = ds_private["private_logs_origin"].astype(str)
    ds_private["private_var"] = ds_private["private_var"].astype(str)

    LOGGER.info("Appending private data to zarr store...")
    ds_private.to_zarr(store=zarr_store_path, mode="a")
    LOGGER.info("...operation completed")


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _tmp_files_cleanup(tmp_folder: Union[str, PathLike]):
    tmp_folder = Path(tmp_folder)

    try:
        shutil.rmtree(tmp_folder)
    except Exception:
        LOGGER.error(f"Error while removing the directory {tmp_folder.name}")
        raise
    else:
        LOGGER.info("Temporary files removed")


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def private_xarray_to_pandas(
    ds: xr.Dataset,
    start: Optional[str] = None,
    stop: Optional[str] = None,
    columns: List[str] = None,
) -> pd.DataFrame:
    """
    Convert private log dataset to pandas dataframe

    Arguments:
        ds: xarray dataset produced from pooling to zarr
        start (Optional[str]): beginning timestamp Format in '2022-03-10 13:17:08'
        stop (Optional[str]): ending timestamp Format in '2022-03-10 13:17:08'
        columns: List of columns we'd like to access i.e. ["ValveMask", "ACETIC_ACID_raw"]

    Returns:
        pd.DataFrame with requested data
    """

    # Check which of the columns are available
    if columns:
        keep_variables = list(set(ds.private_var.values).intersection(columns))
    else:
        keep_variables = list(ds.private_var.values)

    # Pull out time range if specified, defaults to full dataset
    ds = ds.sel(_datetime=slice(start, stop), private_var=keep_variables)

    # Create dataframe
    private_df = ds.private_values.to_pandas()

    return private_df


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def convert_timezone(
    ds: Union[xr.Dataset, xr.DataArray], new_timezone: str
) -> Union[xr.Dataset, xr.DataArray]:
    """
    Convert ds in dataset to different/local timezone

    Arguments:
        ds (xr.Dataset or xr.DataArray):
            xarray dataset or dataarray
            Must have dimension `_datetime` and attribute `tz`
        new_timezone (str): new pytz timezone str

    Returns:
        xr.DataSet with new tz attribute and shifted times
    """
    if new_timezone not in pytz.all_timezones:
        raise ValueError(f"{new_timezone} is not a valid timezone")

    if "_datetime" not in ds.dims:
        raise ValueError("ds must have dimension `_datetime`")

    if "tz" not in ds.attrs:
        raise ValueError("ds must have attribute `tz`")

    new_datetime = (
        ds._datetime.to_index()
        .tz_localize(ds.attrs["tz"])
        .tz_convert(pytz.timezone(new_timezone))
        .tz_localize(None)
    )

    ds["_datetime"] = new_datetime
    ds.attrs["tz"] = new_timezone
    ds.attrs["Start"] = f"{new_datetime[0].tz_localize(None):{DATE_FORMAT}}"
    ds.attrs["Stop"] = f"{new_datetime[-1].tz_localize(None):{DATE_FORMAT}}"

    return ds


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _process_h5_privatelog_file(
    filename: Union[str, os.PathLike],
    zarr_path: Union[str, os.PathLike],
    file_info: PrivateLogInfo,
    time_region: slice,
    private_vars: List[str],
) -> str:
    """
    Read an H5 file and writes it
    into a zarr store at a specified location.

    Args:
        filename (str):
            H5 file path to the file to be read.
        zarr_path (str):
            Zarr store path where to write.
        file_info (PrivateLogInfo):
            Info from H5 file pre-scan related to
            the current file in filename.
        time_region (slice):
            Time region to write into the zarr store.
        private_vars (List[str]):
            List of private variables to write into the zarr store.
            If they are different than the ones in the H5 file,
            their values will be filled with nans.

    Returns:
        str: "OK" if successful.

    """
    data = _read_individual_privatelog_h5(h5file_path=filename, file_info=file_info)
    data = data.reindex(private_var=private_vars)

    with Lock("writing_in_zarr"):
        data.to_zarr(
            zarr_path,
            region={
                "_datetime": time_region,
                "private_var": slice(0, len(private_vars)),
            },
            safe_chunks=True,
        )

    return "OK"


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _read_individual_privatelog_h5(
    h5file_path: Union[str, os.PathLike], file_info: PrivateLogInfo
) -> xr.Dataset:
    with h5py.File(h5file_path, "r") as h5file:
        try:
            timestamp = np.array(h5file["results"]["timestamp"]).astype(int)
        except (KeyError, ValueError) as err:
            raise KeyError(
                f"Need TIMESTAMP in the RESULT group of H5 file ({h5file_path})"
            ) from err

        if (timestamp[0], timestamp[-1], len(timestamp)) != (
            file_info.start,
            file_info.stop,
            file_info.n_points,
        ):
            raise ValueError(f"Timestamp mismatch in H5 file ({h5file_path})")

        values = np.array(h5file["results"][()].tolist())

        ds_temp = xr.Dataset(
            {"private_values": (("_datetime", "private_var"), values)},
            coords={
                "private_var": list(h5file["results"].dtype.names),
            },
        )
        return ds_temp


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _h5s_privatelogs_to_zarr(
    files_info: Dict[str, PrivateLogInfo],
    allocated_store_path: Union[str, os.PathLike],
    show_progress: bool = True,
    n_workers: int = None,
) -> None:
    """
    Create and execute action list to read H5 files
     spectral data into a zarr store.

    Args:
        pre_scan_info (H5SpectralInfo):
            Info from H5 files pre-scan
            from :py:func:`._pre_scan_h5_files`
        allocated_store_path (str):
            Zarr store location.
        show_progress (bool):
            If true, show a Dask progress bar.
        n_workers (int):
            Number of workers for dask local cluster.
            If None, all cores will be used.

    Returns:
        List: List of results.

    """
    time_regions = _get_time_regions(
        files_info=files_info,
    )

    private_vars = _get_private_vars(
        files_info=files_info,
    )

    LOGGER.info("Reading and saving H5 private data to zarr store")

    with LocalCluster(
        n_workers=n_workers, processes=True, threads_per_worker=1
    ) as cluster, Client(cluster) as client:
        # Create a list of delayed objects
        futures = [
            client.submit(
                _process_h5_privatelog_file,
                filename,
                allocated_store_path,
                file_info,
                time_regions[filename],
                private_vars,
            )
            for filename, file_info in files_info.items()
        ]

        if show_progress:
            progress(futures)

        wait(futures)

    LOGGER.info("Private data was written successfully")
