from datetime import timedelta
import pandas as pd
from data_pooler import persist
from data_pooler.pool_utils import safe_update
from data_pooler.timeutils import UNIXORIGIN


def emit_sam_pool_df_from_csv(csv_file, collation_interval, source_lookup):
    """Generate data frames from an input file in csv format such that the timestamps
    lie between n*collation_interval and (n+1)*collation_interval. The collation
    interval is expressed in seconds and it must divide 1 day (86400s)"""

    if (24 * 60 * 60) % collation_interval != 0:
        raise ValueError("Collation interval must divide 24 hours")
    df = pd.read_csv(csv_file)
    # Use source_lookup to replace the model number read from the CSV file with the actual
    #  source name. The value is unchanged if the entry is not in the CSV file
    df.model_number = [source_lookup.get(k, k) for k in df.model_number]
    models = df.model_number.unique()
    for model in models:
        dfm = (
            df[df.model_number == model]
            .dropna(axis=1, how="all")
            .dropna(axis=0, how="any")
            .reset_index(drop=True)
        )
        sec_since_epoch = dfm.time // 1000000000
        periods = sec_since_epoch // collation_interval
        for period in periods.unique():
            dff = dfm[periods == period].copy()
            dff["_datetime"] = [
                UNIXORIGIN + timedelta(microseconds=ns // 1000) for ns in dff.time
            ]
            dff.set_index("_datetime", inplace=True)
            # Get the year, month and day as a tuple for the directory name
            date_code = (dff.index.date[0].strftime("%Y/%m/%d")).split("/")
            # Get the start and end epoch times
            start_epoch = period * collation_interval
            stop_epoch = start_epoch + collation_interval
            # Generate some initial metadata
            metadata = dict(model=model, file_name=csv_file, _history={})
            yield metadata, date_code, start_epoch, stop_epoch, dff


def update_pool_file(
    output_path, metadata_in, date_code, start_epoch, stop_epoch, df_in, file_type
):
    # Get the model name and name of pool file to be updated
    model = metadata_in.get("model", "UNKNOWN")
    dest_path = (
        output_path
        / model
        / date_code[0]
        / date_code[1]
        / date_code[2]
        / f"{model}_{file_type}_{start_epoch}_{stop_epoch}.zpic"
    )

    def updater(pp):
        # This updates a pool file associated with the file-like object pp. We cannot run this simultaneously
        #  for the same pool file from multiple processes, so it must be wrapped in a routine which enforces this
        df_new = df_in
        pp.seek(0)
        metadata_current = dict(model=model, file_name=str(dest_path))
        try:
            # We need to merge df_in into the existing pool file if it exists
            gen = persist.get_time_series_data_frame_from_zpickle(
                pp, get_history=True, get_extra=True
            )
            metadata_current = next(gen)
        except StopIteration:
            # Get here if reading the metadata or the dataframe fail. We just do not concatenate the failing frame into df_new
            print(f"Creating pool file {str(dest_path)} with {len(df_in)} records")
        else:
            df_current = next(gen)
            # Merge the data from df_in into df_current, replacing entries grouped by index with last value
            print(f"Updating existing {str(dest_path)} with {len(df_in)} records")
            df_new = pd.concat([df_current, df_in], axis=0).groupby(level=0).last()
        pp.seek(0)
        # Add the history from metadata_in to the current history in an existing pool file
        history_current = metadata_current.get("_history", {})
        history_new = persist.add_to_history(
            history_current, "populate_sam_log_pool", [metadata_in]
        )
        metadata_current["_history"] = history_new
        # Write out the new version of the pool file
        for b in persist.emit_zpickle_from_time_series_data_frame(
            df_new, metadata_current
        ):
            pp.write(b)

    dest_path.parent.mkdir(parents=True, exist_ok=True)
    safe_update("/tmp/accesslock_" + str(dest_path.stem), dest_path, updater)
