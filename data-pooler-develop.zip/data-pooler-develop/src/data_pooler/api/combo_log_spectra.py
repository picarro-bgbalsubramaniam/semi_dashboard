"""Read SPECTRA group from H5 combo logs files"""
import shutil
from pathlib import Path
from typing import List, Optional, Union

import dask.array as da
import h5py
import numpy as np
import pandas as pd
import xarray as xr
from pydantic import validate_arguments
from spectral_arithmetic.nu_operations import calc_fsr, create_mode_index, nu_transform
from tqdm import tqdm

from data_pooler.api.api_utils import FileTypeEnum, check_for_overlapping_files
from data_pooler.api.combo_log_results import (
    get_analyzer_name,
    get_h5_files_paths,
    read_combologs_timeseries_xarray,
)
from data_pooler.data_models.h5_structures import (
    TIME_CHUNK_SIZE,
    H5SpectralInfo,
    NuTransformInfo,
)
from data_pooler.logger import get_logger
from data_pooler.timeutils import ORIGIN
from dask.distributed import Client, LocalCluster, wait, progress, Lock

DEFAULT_NU_CENTER_KEYS = [
    "fitData_fitdata_params_nucenter",
    "fitData_nu_transform_nnuc",
]
DEFAULT_NU_SHIFT_KEYS = ["fitData_nu_transform_n0"]
DEFAULT_NU_SQUISH_KEYS = ["fitData_nu_transform_n1"]
DEFAULT_F0_KEYS = ["f0"]
DEFAULT_NU_CENTER_VALUE = 6056.504
DEFAULT_F0_VALUE = 6056.5068
TEMP_SUFFIX = ".temp"

LOGGER = get_logger(__name__)


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _get_nu_key(
    h5file: h5py.File, query_keys: List[str], default_value: float = np.NaN
) -> np.ndarray:
    """
    The value corresponding
    to the first key of ``query_keys`` that
    is present in ``h5file`` RESULTS group is returned.
    If no key is present in RESULTS group, use a default value.
    If no default value is provided, raise an error.

    Args:
        h5file (h5py.File):
            H5 file object.
        query_keys (List[str]):
            Possible keys that identify the requested
            variable in RESULTS group, in decreasing
            priority order (that first key that is
            found is the one that will be used).
        default_value (float):
            Default value to return if no key is
            not present in the data.

    Returns:
        np.ndarray:
            Array of length #TIMESTAMP in RESULTS group.
            If the default value is used, then the default
            value is repeated #TIMESTAMP-times in the array.

    """

    time_array = h5file.get("results/timestamp", None)
    if time_array is None:
        raise KeyError(f"Group RESULTS/TIMESTAMP not present in {h5file.filename}")

    for query_key in query_keys:
        result = h5file.get(f"results/{query_key}", None)
        if result:
            result = np.array(result)
            break
    else:
        # I did not find any of the spectral keys provided
        if not np.isnan(default_value):
            LOGGER.warning(
                f"No key in {query_keys} found in {h5file.filename} RESULTS group:"
                f" using default value {default_value}"
            )
            result = np.full_like(time_array, fill_value=default_value)
        else:
            raise KeyError(
                f"No spectral keys in {query_keys} "
                f"present in {h5file.filename} RESULTS group."
                f" No default value was provided"
            )
    return result


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _get_nu_data(h5file: h5py.File) -> NuTransformInfo:
    """
    Get the spectral info
    needed to perform nu_transform
    for mode binning.

    The values needed are:
    f0, nu_center, nu_squish, nu_shift.

    They are read from an H5 file
    (RESULTS group).

    Args:
        h5file (h5py.File):
            H5 file object.

    Returns:
        NuTransformInfo:
            Spectral info for
            ``nu_transform`` for the
            file.

    """
    f0_value = _get_nu_key(
        h5file=h5file, query_keys=DEFAULT_F0_KEYS, default_value=DEFAULT_F0_VALUE
    )
    nu_center = _get_nu_key(
        h5file=h5file,
        query_keys=DEFAULT_NU_CENTER_KEYS,
        default_value=DEFAULT_NU_CENTER_VALUE,
    )
    nu_squish = _get_nu_key(
        h5file=h5file, query_keys=DEFAULT_NU_SQUISH_KEYS, default_value=np.NaN
    )
    nu_shift = _get_nu_key(
        h5file=h5file, query_keys=DEFAULT_NU_SHIFT_KEYS, default_value=np.NaN
    )

    spectral_info = NuTransformInfo(
        f0=f0_value, nu_center=nu_center, nu_squish=nu_squish, nu_shift=nu_shift
    )
    return spectral_info


@validate_arguments()
def _pre_scan_h5_files(files_list: List[str]) -> H5SpectralInfo:
    """
    Pre-scan all H5 files.
    Returns information regarding the spectral
    and time series variables present in the files,
    the full time axis values (in utc), and the number of mode
    binning errors generated while performing nu_transform.

    Pre-scan is needed to determine which modes were
    scanned during the course of the experiment
    (preliminary creation of mode bins).

    It also guarantees that the data is consistent
    between files:
    - all files have a timestamp
    - time series variables consistent between files
    - all files contain spectral data
    - spectral variables consistent between files
    - spectral variables consistent inside a single file
    - wavenumber information available for each spectrum

    Args:
        files_list (List[str]):
            List of H5 files to be scanned.

    Returns:
        H5SpectralInfo:
            Information about variables present
            in H5 files and other diagnostic
            info.

    """

    LOGGER.info(f"Scanning {len(files_list)} files for spectral data")

    # Store the time length of each file
    time_len = np.zeros(len(files_list), dtype=int)

    # Store the number of spectral variables and fitter variables in each file
    spectral_vars_no = np.zeros(len(files_list), dtype=int)
    fitter_vars_no = np.zeros(len(files_list), dtype=int)

    # Save the keys of spectral variables and fitter variables
    spectral_vars = []
    fitter_vars = []
    date_time_coordinate = pd.DatetimeIndex([])

    # Save the initial timestamp for every file, so they can be sorted
    start_timestamp = np.empty(len(files_list), dtype=int)
    end_timestamp = np.empty(len(files_list), dtype=int)

    modes_bin_errors_count = 0
    all_modes = set()

    for file_index, h5file in tqdm(
        enumerate(files_list), desc="Files", total=len(files_list)
    ):
        with h5py.File(h5file, "r") as h5file:
            time_array = h5file.get("results/timestamp", None)
            if time_array is None:
                raise KeyError(
                    f"Group RESULTS/TIMESTAMP not present in {h5file.filename}"
                )

            # Get number of recorded timestamps
            time_len[file_index] = len(time_array)

            # The timestamp field is milliseconds from 01-01-01 00:00:00
            original_time = np.array(time_array).astype("timedelta64[ms]")
            original_time = original_time + np.datetime64(ORIGIN.replace(tzinfo=None))

            start_timestamp[file_index] = time_array[0]
            end_timestamp[file_index] = time_array[-1]

            # Datetime (UTC-based)
            date_time_coordinate = date_time_coordinate.union(
                pd.to_datetime(original_time, utc=True)
            )

            fitter_vars_temp = list(h5file["results"].keys())
            if len(fitter_vars) > 0:
                if set(fitter_vars) != set(fitter_vars_temp):
                    raise ValueError(
                        "Fitter variable names not matching between H5 files"
                    )
            fitter_vars = fitter_vars_temp
            fitter_vars_no[file_index] = len(fitter_vars)

            # Get spectral info to perform nu_transform operation
            spectral_info = _get_nu_data(h5file)

            # Get the first spectrum identifier
            first_spectral_subgroup = next(iter(h5file.get("spectra", [None])))
            if first_spectral_subgroup is None:
                raise ValueError(f"Group SPECTRA in {h5file.filename} is empty")

            # Get spectral variables count from first spectrum
            spectral_vars_temp = list(
                h5file[f"spectra/{first_spectral_subgroup}"].keys()
            )
            if len(spectral_vars) > 0:
                if set(spectral_vars) != set(spectral_vars_temp):
                    raise ValueError(
                        "Spectral variable names not matching between H5 files"
                    )

            spectral_vars = spectral_vars_temp
            spectral_vars_no[file_index] = len(spectral_vars)

            # For each spectrum
            for time_index, time in enumerate(h5file["spectra"].keys()):
                spectral_vars_temp = list(h5file[f"spectra/{time}"].keys())

                if set(spectral_vars) != set(spectral_vars_temp):
                    raise ValueError(
                        f"Spectral variables mismatch in SPECTRA group of {h5file}"
                        f" at time index {time_index}:"
                        f" expecting {spectral_vars},"
                        f" found {spectral_vars_temp}"
                    )
                spectral_vars = spectral_vars_temp

                wavenumber_nu = h5file.get(f"spectra/{time}/nu", None)
                if wavenumber_nu is None:
                    raise ValueError(
                        f"Could not find NU in SPECTRA group of {h5file} at time index {time_index}"
                    )

                wavenumber_nu = np.array(wavenumber_nu)
                fsr = calc_fsr(wavenumber_nu)
                nu_prime, fsr_prime, f0_prime = nu_transform(
                    wavenumber_nu,
                    spectral_info.nu_squish[time_index],
                    spectral_info.nu_shift[time_index],
                    spectral_info.f0[time_index],
                    spectral_info.nu_center[time_index],
                    fsr,
                )

                try:
                    mode_idxs = create_mode_index(nu_prime, fsr_prime, f0_prime)
                except ValueError as err:
                    LOGGER.warning(
                        f"Issues with getting mode grid: {err} "
                        f"File: {h5file}, Time index: {time_index}"
                    )
                    modes_bin_errors_count += 1
                else:
                    all_modes.update(mode_idxs)

    pre_scan_results = H5SpectralInfo(
        files_info=pd.DataFrame(
            data={
                "file_name": files_list,
                "recorded_timestamps": time_len,
                "spectral_variables_count": spectral_vars_no,
                "fitter_variables_count": fitter_vars_no,
                "start_timestamp": start_timestamp,
                "end_timestamp": end_timestamp,
            }
        ).sort_values(by="start_timestamp", ascending=True),
        scanned_modes=sorted(list(all_modes)),
        spectral_variables=spectral_vars,
        fitter_variables=fitter_vars,
        reported_errors=modes_bin_errors_count,
        datetime_coordinate_utc=pd.to_datetime(date_time_coordinate),
    )

    if not pre_scan_results.files_info.start_timestamp.is_monotonic_increasing:
        raise ValueError("start_time: Files could not be read in chronological order")

    if not pre_scan_results.files_info.end_timestamp.is_monotonic_increasing:
        raise ValueError("end_time: Files could not be read in chronological order")

    if not pre_scan_results.datetime_coordinate_utc.is_monotonic_increasing:
        raise ValueError(
            "Datetime coordinate could not be pooled in chronological order"
        )

    return pre_scan_results


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _allocate_zarr_store(
    zarr_path: str,
    local_time_zone: str,
    allocation_info: H5SpectralInfo,
    analyzer_name: str,
    time_chunk_size: int = TIME_CHUNK_SIZE,
) -> str:
    """
    Preallocate a virtual zarr store based
    on the pre-scan info.

    Args:
        zarr_path (str):
            Location where to create a zarr store.
            Please use a ``.zarr`` extension.
            Example: `my_path/my_store.zarr`
        local_time_zone (str):
            Local time zone.
            Used for metadata.
            Example: `US/Pacific`
        allocation_info (H5SpectralInfo):
            Info from H5 files pre-scan
            from :py:func:`._pre_scan_h5_files`
        analyzer_name (str):
            Name of the analyzer.
            Used for metadata.
            Example: `NUV1041`
        time_chunk_size (int):
            Chunk size for Dask arrays along the time axis.

    Returns:
        str: "OK" if successful.

    """
    LOGGER.info(f"Pre-allocating virtual zarr store at {zarr_path}")

    # Coordinates: time / spectral_var / mode
    times = allocation_info.files_info.recorded_timestamps.sum()

    # Add +1 to spectral variables count to make space for the calculated nu_prime
    spectral_vars = allocation_info.spectral_variables + ["nu_prime"]
    spectra_vars_len = len(spectral_vars)

    modes_len = len(allocation_info.scanned_modes)

    # Dummy lazy dask array
    dummies = da.zeros(
        (times, spectra_vars_len, modes_len), chunks=(time_chunk_size, -1, -1)
    )

    ds_dummy = xr.Dataset(
        {"spectral_values": (("_datetime", "spectral_var", "mode"), dummies)}
    )
    ds_dummy = ds_dummy.assign_coords(
        {
            "_datetime": allocation_info.datetime_coordinate_utc.tz_convert(
                local_time_zone
            ).tz_localize(None),
            "spectral_var": spectral_vars,
            "mode": allocation_info.scanned_modes,
        }
    )
    ds_dummy.attrs["tz"] = local_time_zone
    ds_dummy.attrs["analyzer"] = analyzer_name

    ds_dummy.to_zarr(
        store=zarr_path, mode="w", compute=False
    )  # It is a delayed operation
    LOGGER.info(
        f"Virtual pre-allocation successful. Spectral values size: {dummies.shape}"
    )
    return "OK"


@validate_arguments()
def _read_individual_h5(
    h5file_path: str,
    time_len: int,
    spectral_variables: List[str],
    scanned_modes: List[int],
) -> xr.Dataset:
    """
    Read an individual H5 files,
    align spectral data on a mode grid,
    and return a Xarray Dataset.

    Args:
        h5file_path (str):
            Path of the H5 file.
        time_len (int):
            Length of the time coordinate.
        spectral_variables (List[str]):
             List of spectral variables to
             be queried from the file.
             Example: [`nu`, `absorbance`]
        scanned_modes (List[int]):
            List of modes bins to be used.

    Returns:
        xr.Dataset:
            Xarray dataset

    """
    spectral_temp = np.full(
        (time_len, len(spectral_variables) + 1, len(scanned_modes)), np.NaN
    )

    with h5py.File(h5file_path, "r") as h5file:
        spectral_info = _get_nu_data(h5file)

        for time_index, time in enumerate(h5file["spectra"].keys()):
            wavenumber_nu = h5file.get(f"spectra/{time}/nu", None)
            if wavenumber_nu is None:
                raise ValueError(
                    f"Could not find NU in SPECTRA group of {h5file_path} "
                    f"at time index {time_index}"
                )

            fsr = calc_fsr(wavenumber_nu)
            nu_prime, fsr_prime, f0_prime = nu_transform(
                wavenumber_nu,
                spectral_info.nu_squish[time_index],
                spectral_info.nu_shift[time_index],
                spectral_info.f0[time_index],
                spectral_info.nu_center[time_index],
                fsr,
            )

            try:
                mode_idxs = create_mode_index(nu_prime, fsr_prime, f0_prime)
            except ValueError as err:
                LOGGER.warning(
                    f"Issues with getting mode grid: {err} "
                    f"File: {h5file_path}, Time index: {time_index}"
                )
            else:
                indexes = np.searchsorted(scanned_modes, mode_idxs).astype(int)

                for spectral_var_index, spectral_var in enumerate(spectral_variables):
                    spectral_temp[time_index, spectral_var_index, indexes] = np.array(
                        h5file[f"spectra/{time}/{spectral_var}"]
                    )
                spectral_temp[time_index, len(spectral_variables), indexes] = nu_prime

        ds_file = xr.Dataset(
            {"spectral_values": (["_datetime", "spectral_var", "mode"], spectral_temp)}
        )

    return ds_file


def _process_h5_file(
    filename: str,
    zarr_path: str,
    file_time_length: int,
    mode_comb: List[int],
    spectra_vars: List[str],
    time_index_start: int,
) -> str:
    """
    Read an H5 files and write it
    into a zarr store.

    Args:
        filename (str):
            Name of the H5 file to be read.
        zarr_path (str):
            Zarr store location.
        file_time_length (int):
            Length of the time coordinate for
            this file.
        mode_comb (List[int]):
            List of modes bins to be used.
        spectra_vars (List[str]):
             List of spectral variables to
             be queried from the file.
             Example: [`nu`, `absorbance`]
        time_index_start (int):
             Index of the time axis in
             the zarr file at which to start
             writing the data.

    Returns:
        str: "OK" if successful

    """
    time_index_stop = time_index_start + file_time_length

    data = _read_individual_h5(
        h5file_path=filename,
        scanned_modes=mode_comb,
        time_len=file_time_length,
        spectral_variables=spectra_vars,
    )

    with Lock("writing_in_zarr"):
        data.to_zarr(
            zarr_path,
            region={
                "_datetime": slice(time_index_start, time_index_stop),
                "spectral_var": slice(0, len(spectra_vars) + 1),
                "mode": slice(0, len(mode_comb)),
            },
            safe_chunks=True,
        )

    return "OK"


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _h5s_to_zarr(
    pre_scan_info: H5SpectralInfo,
    allocated_store_path: str,
    show_progress: bool = True,
    n_workers: int = None,
) -> None:
    """
    Create and execute action list to read H5 files
     spectral data into a zarr store.

    Args:
        pre_scan_info (H5SpectralInfo):
            Info from H5 files pre-scan
            from :py:func:`._pre_scan_h5_files`
        allocated_store_path (str):
            Zarr store location.
        show_progress (bool):
            If true, show a Dask progress bar.
        n_workers (int):
            Number of workers for dask local cluster.
            If None, all cores will be used.

    Returns:
        List: List of results.

    """
    futures = []
    allocate_time_index = 0

    LOGGER.info("Reading and saving H5 spectral data to zarr store")

    with LocalCluster(
        n_workers=n_workers, processes=True, threads_per_worker=1
    ) as cluster, Client(cluster) as client:
        for row in pre_scan_info.files_info.itertuples(index=False):
            futures.append(
                client.submit(
                    _process_h5_file,
                    row.file_name,
                    allocated_store_path,
                    row.recorded_timestamps,
                    pre_scan_info.scanned_modes,
                    pre_scan_info.spectral_variables,
                    allocate_time_index,
                )
            )
            allocate_time_index += row.recorded_timestamps

        if show_progress:
            progress(futures)

        wait(futures)

    LOGGER.info("Spectral data was written successfully")


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def read_combologs_spectra_to_zarr_store(
    files_list: List,
    local_time_zone: str,
    path_to_zarr: str,
    analyzer_name: Optional[str] = None,
    chunk_time_size: int = TIME_CHUNK_SIZE,
    fitter_name: str = "broadband",
) -> str:
    """
    Read H5 files and write their
    binned spectral data into a Zarr store.

    Args:
        files_list (List[str]):
            List of H5 files to be read.
        local_time_zone (str):
            Local time zone.
            Example `US/Pacific`.
        path_to_zarr (str):
            Location (folder) of the exported zarr store.
            The zarr store path is going to be:
            ``path_to_zarr/analyzer_name.zarr``.
        analyzer_name (str):
            Name of the analyzer. Example "NUV1044".
            Used as name of the zarr store.
        chunk_time_size (int):
            Chunk size for Dask arrays along the time axis.
            See https://docs.dask.org/en/stable/array-best-practices.html#select-a-good-chunk-size
        fitter_name (str):
            Name of the fitter files to read. Default is `broadband`.

    Returns:
        str: Full zarr store path

    """

    if analyzer_name is None:
        analyzer_name = get_analyzer_name(files_list[0])

    zarr_store_path = (
        Path(path_to_zarr) / f"{analyzer_name}_combologs_{fitter_name}.zarr"
    )
    if zarr_store_path.exists():
        zarr_store_path = f"{zarr_store_path}{TEMP_SUFFIX}"
        LOGGER.info(
            f"Found existing zarr store, creating temp store in {zarr_store_path}"
        )

    zarr_store_path = str(zarr_store_path)

    files_info = _pre_scan_h5_files(files_list=files_list)

    _ = _allocate_zarr_store(
        zarr_path=zarr_store_path,
        analyzer_name=analyzer_name,
        local_time_zone=local_time_zone,
        allocation_info=files_info,
        time_chunk_size=chunk_time_size,
    )

    _h5s_to_zarr(pre_scan_info=files_info, allocated_store_path=zarr_store_path)

    return zarr_store_path


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def read_combologs_xarray(
    folder_path: Union[str, Path],
    local_time_zone: str,
    path_to_zarr: str,
    analyzer_name: Optional[str] = None,
    fitter_name: str = "broadband",
    chunk_time_size: int = TIME_CHUNK_SIZE,
) -> str:
    """
    Read RESULTS group (timeseries data)
    and SPECTRA group (spectral data)
    from combo logs H5 files for a specific fitter.

    Args:
        folder_path (str):
            Path where H5 files are located.
            The search is recursive.
        local_time_zone (str):
            Local time zone.
            Example `US/Pacific`.
        path_to_zarr (str):
            Location (folder) of the exported zarr store.
            The zarr store path is going to be named:
            ``path_to_zarr/analyzer_name.zarr``.
        analyzer_name (str):
            Name of the analyzer. Example "NUV1044".
            Used as name for the zarr store.
            Default is None, in which case the analyzer name
            is extracted from the first found H5 file name.
        fitter_name (str):
             Requested fitter data. Default is `broadband`.
        chunk_time_size (int):
            Chunk size for Dask arrays along the time axis.
            See https://docs.dask.org/en/stable/array-best-practices.html#select-a-good-chunk-size

    Returns:
        str: Full path of the zarr store

    """
    folder_path = Path(folder_path)
    files_list = get_h5_files_paths(folder_path=folder_path, fitter_name=fitter_name)

    if analyzer_name is None:
        analyzer_name = get_analyzer_name(files_list[0])

    full_path = f"{path_to_zarr}/{analyzer_name}_combologs_{fitter_name}.zarr"

    # Check for existing zarr store
    files_list = check_for_overlapping_files(
        files_list, full_path, FileTypeEnum.combologs
    )
    if not files_list:
        raise ValueError("No unique files found in combo log file list")

    LOGGER.info("Reading fitter time series data")
    # fitter_data is an xarray dataset
    fitter_data = read_combologs_timeseries_xarray(
        files_list=files_list,
        local_time_zone=local_time_zone,
        analyzer_name=analyzer_name,
        chunk_time_size=chunk_time_size,
    )

    LOGGER.info("Reading fitter spectral data")
    zarr_store_path = read_combologs_spectra_to_zarr_store(
        files_list=files_list,
        local_time_zone=local_time_zone,
        path_to_zarr=path_to_zarr,
        analyzer_name=analyzer_name,
        chunk_time_size=chunk_time_size,
        fitter_name=fitter_name,
    )

    fitter_data.attrs["Fitter"] = fitter_name
    LOGGER.info("Appending fitter data to zarr store...")
    fitter_data.to_zarr(store=zarr_store_path, mode="a")
    fitter_data.close()

    # TODO: what does this section do? Should we have a separate function for this for separation of concerns?
    if TEMP_SUFFIX in zarr_store_path:
        LOGGER.info("Merging to original zarr store")
        zarr_store_path = merge_combo_zarr_stores(zarr_store_path, chunk_time_size)

    LOGGER.info("...operation completed")
    return zarr_store_path


def merge_combo_zarr_stores(temp_store_path: str, chunk_time_size: int) -> str:
    """
    Function to merge new combolog data into existing combo zarr store.

    Args:
        temp_store_path (str):
            Path of temporary zarr store.

        chunk_time_size (int):
            Chunk size for Dask arrays along the time axis.

    Return:
        str: Path of merged zarr store

    """
    original_path = temp_store_path.replace(TEMP_SUFFIX, "")
    original_store = xr.open_zarr(original_path)
    new_store = xr.open_zarr(temp_store_path)

    # Update start and end values
    new_start = min(original_store.attrs["Start"], new_store.attrs["Start"])
    new_end = max(original_store.attrs["Stop"], new_store.attrs["Stop"])

    # Update files
    files = (
        original_store.fitter_origin_file.attrs["files"]
        + new_store.fitter_origin_file.attrs["files"]
    )

    # Merge the new store in and set the new attributes
    new_ds = xr.merge([original_store, new_store], compat="no_conflicts")
    new_store.close()
    original_store.close()
    new_ds = new_ds.chunk(
        {"_datetime": chunk_time_size, "fitter_var": new_ds.fitter_var.shape[0]}
    )
    new_ds.attrs["Start"] = new_start
    new_ds.attrs["Stop"] = new_end
    new_ds.fitter_origin_file.attrs["files"] = files

    # Uncertain why this is needed, but we think it's because it's dask array
    new_ds["fitter_origin_file"] = new_ds["fitter_origin_file"].astype(str)
    new_ds["fitter_var"] = new_ds["fitter_var"].astype(str)

    try:
        new_ds.to_zarr(original_path, mode="w")
        new_ds.close()
    except (TypeError, ValueError) as e:
        LOGGER.error(f"Merging of combo logs to zarr path failed{e}")

    # Remove temp store
    shutil.rmtree(temp_store_path)

    return original_path
