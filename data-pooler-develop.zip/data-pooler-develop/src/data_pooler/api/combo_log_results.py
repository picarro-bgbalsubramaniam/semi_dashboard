"""Read RESULTS group from H5 combo logs files"""
import re
from pathlib import Path
from typing import List, Optional, Union

import numpy as np
import pandas as pd
import pytz
import xarray as xr
from pandas.errors import ParserError
from pydantic import validate_arguments
from pytz.exceptions import UnknownTimeZoneError

from data_pooler.data_models.h5_structures import TIME_CHUNK_SIZE
from data_pooler.logger import get_logger
from data_pooler.timeutils import ORIGIN
from data_pooler.api.api_utils import get_analyzer_name

LOGGER = get_logger(__name__)

TIME_REP = "%Y-%m-%d %H:%M:%S"


@validate_arguments()
def read_combologs_timeseries_xarray(
    files_list: List[str],
    local_time_zone: str,
    analyzer_name: Optional[str] = None,
    chunk_time_size: int = TIME_CHUNK_SIZE,
) -> xr.Dataset:
    """
    Reads RESULTS group (timeseries data)
    from combo logs H5 files for a specific fitter.

    Args:
        files_list (str):
            List of H5 files to be read.
        local_time_zone (str):
            Local time zone.
            Example `US/Pacific`.
        analyzer_name (str):
             Analyzer name.
        chunk_time_size (int):
            Chunk size for Dask arrays along the time axis.
            See https://docs.dask.org/en/stable/array-best-practices.html#select-a-good-chunk-size

    Returns:
        xr.Dataset:
            Xarray dataset with coordinates ``datetime, fitter_var``,
            and variables ``fitter_values``.
            Also, a temporary coordinate ``fitter_origin_file`` is present.

    """

    if chunk_time_size < 0:
        raise ValueError("Chunk size must be positive")

    if local_time_zone not in pytz.all_timezones:
        raise ValueError("Time zone not in list of pytz timezones")

    if analyzer_name is None:
        analyzer_name = get_analyzer_name(str(files_list[0]))

    timeseries_ds = xr.open_mfdataset(
        paths=files_list,
        engine="h5netcdf",
        group="results",
        invalid_netcdf=True,
        phony_dims="access",
        preprocess=_preprocessor,
        decode_cf=False,
        combine="by_coords",
        parallel=True,
    )

    # Localize the datetime coordinate to local time
    timeseries_ds["_datetime"] = (
        pd.to_datetime(timeseries_ds._datetime, utc=True)
        .tz_convert(local_time_zone)
        .tz_localize(None)
    )

    # Drop duplicates dates
    timeseries_ds = timeseries_ds.drop_duplicates(dim="_datetime", keep="first")

    # Attributes
    timeseries_ds.attrs["tz"] = local_time_zone
    timeseries_ds.attrs["Analyzer"] = analyzer_name
    timeseries_ds.attrs[
        "Start"
    ] = f"{pd.to_datetime(timeseries_ds._datetime.values[0]):%Y-%m-%d %H:%M:%S}"
    timeseries_ds.attrs[
        "Stop"
    ] = f"{pd.to_datetime(timeseries_ds._datetime.values[-1]):%Y-%m-%d %H:%M:%S}"

    # Save list of unique files pooled in an attribute of fitter_origin_file
    unique_files = list(np.unique(timeseries_ds["fitter_origin_file"].values))
    unique_files = [str(Path(file).name) for file in unique_files]
    timeseries_ds.fitter_origin_file.attrs["files"] = unique_files

    # Chunk time axis
    timeseries_ds = timeseries_ds.chunk(
        {"_datetime": chunk_time_size, "fitter_var": timeseries_ds.fitter_var.shape[0]}
    )
    return timeseries_ds


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _convert_h5_timestamp(timestamp: np.ndarray):
    # The timestamp field is milliseconds from 01-01-01 00:00:00
    original_time = np.array(timestamp).astype("timedelta64[ms]")
    original_time = original_time + np.datetime64(ORIGIN.replace(tzinfo=None))

    # Re-align naive datetime (UTC-based)
    datetime_utc_naive = pd.to_datetime(original_time, utc=True).tz_localize(None)

    return datetime_utc_naive


@validate_arguments(config=dict(arbitrary_types_allowed=True))
def _preprocessor(ds_xr: xr.Dataset) -> xr.DataArray:
    """
    Preprocessor is an intermediate step
    in preparing a single file dataset
    before it is merged with others.
    It is used by Xarray ``open_mfdataset``.

    Adds a time axis centered at UTC time,
    but expressed in naive format.
    Adds a reference to the file it was read
    from.

    Args:
        ds_xr (xr.Dataset):
            Xarray dataset.

    Returns:
        xr.Dataset: Preprocessed dataset.

    """
    # Verify timestamp is available
    if "timestamp" not in list(ds_xr.data_vars.keys()):
        raise KeyError(
            f"Need TIMESTAMP in the RESULT group of H5 file ({ds_xr.encoding['source']}). "
            f"Found {list(ds_xr.data_vars.keys())}"
        )

    # Rename dummy coordinate
    ds_xr = ds_xr.rename({"phony_dim_0": "_datetime"})

    # Remember origin file name, and associate it to all this file datetimes
    file_origin = np.full(len(ds_xr._datetime), ds_xr.encoding["source"])

    # Convert timestamps to utc naive
    ds_xr["_datetime"] = _convert_h5_timestamp(ds_xr["timestamp"].values)

    # Arrange data so that fitter_values are indexed by datetime
    # and fitter_var
    ds_xr = ds_xr.to_array(dim="fitter_var", name="fitter_values")
    ds_xr = ds_xr.transpose("_datetime", "fitter_var")

    # Add variable to track the original file name
    ds_xr["fitter_origin_file"] = ("_datetime", file_origin)
    ds_xr["spec_gen_id"] = ("_datetime", np.arange(ds_xr.sizes["_datetime"]))

    return ds_xr


@validate_arguments()
def get_h5_files_paths(folder_path: Union[str, Path], fitter_name: str) -> List[str]:
    """
    Get fitter-specific H5 files from a folder.
    The search is recursive.

    Args:
        folder_path (str):
            Path to inspect.

        fitter_name (str):
             Requested fitter data.

    Returns:
        List[str]: List of files.

    """
    folder_path = Path(folder_path)
    files_list = folder_path.rglob(f"*_{fitter_name}_*.h5")
    files_list = [str(file) for file in files_list if file.is_file()]

    if len(files_list) == 0:
        raise FileNotFoundError("No H5 files found in the directory.")

    LOGGER.info(
        f"Inspecting folder {folder_path.name}, found {len(files_list)} H5 files"
    )
    return files_list


@validate_arguments()
def _local_date_to_utc_naive(
    local_date_time: str, local_time_zone: str
) -> pd.Timestamp:
    try:
        # Get requested cutoff times in naive UTC dates
        naive_utc = (
            pd.to_datetime(local_date_time, infer_datetime_format=True)
            .tz_localize(local_time_zone)
            .tz_convert("UTC")
            .tz_localize(None)
        )
    except UnknownTimeZoneError as err:
        raise UnknownTimeZoneError(f"Unknown time zone: {err}") from err
    except ParserError as err:
        raise ParserError(f"Date parse error: {err}") from err
    except (ValueError, TypeError) as err:
        raise ValueError(
            f"Please verify start and stop date are not tz-aware"
            f" and are not ambiguous (use of 24H-format is preferred): {err}"
        ) from err

    return naive_utc
