import enum
import re
from datetime import datetime as dt
from os import PathLike
from pathlib import Path
from typing import List, Tuple, Union

import pytz
import xarray as xr

from data_pooler.data_models.h5_structures import ANALYZER_NAME_PATTERN
from data_pooler.logger import get_logger

LOGGER = get_logger(__name__)
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

class FileTypeEnum(str, enum.Enum):
    """
    All plot types that can be cached
    """

    combologs = "combologs"
    privatelogs = "privatelogs"


def get_analyzer_name(file: str) -> str:
    """
    Get the analyzer name via regex from a file in file list to pool

    Arguments:
        Any file that has properly formatted naming convention (private or combo)

    Returns:
        (str): Name of analyzer found with regex

    Raises:
        ValueError if the naming convention is different or file poorly formatted
    """
    try:
        analyzer_name = re.search(ANALYZER_NAME_PATTERN, file).group(0)
    except AttributeError as err:
        raise ValueError(
            f"Improperly formatted file name.  Unable to find analyzer name: {err}. "
            f"Please pass in a valid analyzer name"
        ) from err

    return analyzer_name


def check_for_overlapping_files(
    files_list: List[str], path_to_zarr: Union[str, PathLike], file_type: FileTypeEnum
) -> List[str]:
    """
    Function to check for overlapping files and return unpooled files files

    Args:
        files_list: List of files to pool, this includes path
        path_to_zarr: full path to the zarr store to pool to
        file_type (FileTypeEnum): type of log file

    Returns:
        list(str): list of files that haven't yet been pooled in specified zarr store
    """
    path_to_zarr = Path(path_to_zarr)
    if path_to_zarr.exists():
        LOGGER.info("Found existing zarr store, checking for overlapping files")
        zarr_store = xr.open_zarr(str(path_to_zarr))
        if file_type == FileTypeEnum.combologs:
            existing_files = zarr_store.fitter_origin_file.attrs["files"]
        else:
            existing_files = zarr_store.private_logs_origin.attrs["files"]
        files_list = [f for f in files_list if Path(f).name not in existing_files]
        zarr_store.close()

    return files_list


def get_start_end_time(
    path_to_zarr: str, time_zone: str = None, return_format: str = "%Y-%m-%d %H:%M:%S"
) -> Tuple[str, str]:
    """
    Get the possible start and stop times for a pool path in a given time zone

    Arguments:
        path_to_zarr (str): full path to zarr store
        time_zone Optional(str): pytz timezone to get start and end time in, if no
                                 timezone then will just return start and stop

    Returns:
        Tuple(str, str): start and stop string representations
    """
    if time_zone is not None and time_zone not in pytz.all_timezones:
        raise ValueError(
            f"Provided Time Zone ({time_zone}) for start/stop times not a valid timezone"
        )

    if not Path(path_to_zarr).exists():
        raise ValueError(f"zarr store {path_to_zarr} does not exist")

    ds = xr.open_zarr(path_to_zarr)
    tz = pytz.timezone(ds.attrs["tz"])

    if time_zone is None:
        start = dt.strptime(ds.attrs["Start"], "%Y-%m-%d %H:%M:%S").strftime(
            return_format
        )
        stop = dt.strptime(ds.attrs["Stop"], "%Y-%m-%d %H:%M:%S").strftime(
            return_format
        )
    else:
        # Localize to existing timezone and shift to requested time zone
        start = tz.localize(dt.strptime(ds.attrs["Start"], "%Y-%m-%d %H:%M:%S"))
        start = start.astimezone(tz=pytz.timezone(time_zone)).strftime(return_format)
        stop = tz.localize(dt.strptime(ds.attrs["Stop"], "%Y-%m-%d %H:%M:%S"))
        stop = stop.astimezone(tz=pytz.timezone(time_zone)).strftime(return_format)

    ds.close()

    return (start, stop)
