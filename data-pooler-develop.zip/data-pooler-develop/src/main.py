import sys
import time
from PyQt6 import QtWidgets, QtCore, QtGui
from view.ui_data_pooler import Ui_MainWindow
from snakemake import snakemake
from pathlib import Path
import yaml
import signal
from threading import Thread
import subprocess
import multiprocessing as mp
from enum import Enum


CUR_PATH = Path.cwd()
SNAKEFILE = CUR_PATH / "src/snakemake_scripts/workflow/Snakefile"
COMBO_CMD = "populate_pool_from_combo_logs"
COMBO_CFG = CUR_PATH / "src/snakemake_scripts/config/config_combo_log.yaml"
COMBO_FILE_TYPE = "ComboLog"
COMBO_EXT = ".h5"
PRIVATE_CMD = "populate_pool_from_private_logs"
PRIVATE_CFG = CUR_PATH / "src/snakemake_scripts/config/config_private_log.yaml"
PRIVATE_FILE_TYPE = "PrivateLog"
PRIVATE_EXT = ".zip"
SAM_CMD = "populate_pool_from_sam_logs"
SAM_CFG = CUR_PATH / "src/snakemake_scripts/config/config_sam_log.yaml"
SAM_FILE_TYPE = "SamLog"
SAM_EXT = ".csv"
DEFAULT_POOL = Path('~').expanduser() / "pools"
LOG_LOC = DEFAULT_POOL / ".snakemake/log"
JOB_INFO = CUR_PATH / "job_info"

COMBO_SETUP = {
    "_config_to_use": COMBO_CFG,
    "_cmd_to_use": COMBO_CMD,
    "_file_type": COMBO_FILE_TYPE,
}

PRIVATE_SETUP = {
    "_config_to_use": PRIVATE_CFG,
    "_cmd_to_use": PRIVATE_CMD,
    "_file_type": PRIVATE_FILE_TYPE,
}

SAM_SETUP = {
    "_config_to_use": SAM_CFG,
    "_cmd_to_use": SAM_CMD,
    "_file_type": SAM_FILE_TYPE,
}


class LogTypes(Enum):
    PRIVATE_LOGS = "Private Logs"
    COMBO_LOGS = "Combo Logs"
    SAM_LOGS = "SAM Logs"


class Ui_Main(QtWidgets.QMainWindow):
    _selected_files = ""
    _process = None
    _pool_directory = DEFAULT_POOL
    _config_to_use = PRIVATE_CFG
    _cmd_to_use = PRIVATE_CMD
    _file_type = PRIVATE_FILE_TYPE
    _source_lookup = {}
    _message_signal = QtCore.pyqtSignal(str, bool)
    _pool_btn_signal = QtCore.pyqtSignal()

    def __init__(self):
        super(Ui_Main, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.show_selections()
        self.connect_signals()
        self.show()

    def connect_signals(self):
        self.ui.target_files_btn.clicked.connect(self._choose_target_files)
        self.ui.pool_data_btn.clicked.connect(self.start_pool)
        self.ui.pool_loc_btn.clicked.connect(self._choose_pool_dir)
        self.ui.log_type_combo.activated.connect(self._log_type_select)
        self._message_signal.connect(self.update_message)
        self._pool_btn_signal.connect(self._enable_pool_btn)

    @property
    def selected_files(self):
        text = self.ui.log_type_combo.currentText()
        if not self._selected_files:
            path = "No Files Selected"
        elif text == LogTypes.PRIVATE_LOGS.value:
            path = f"{self._selected_files}/*{PRIVATE_EXT}"
        elif text == LogTypes.COMBO_LOGS.value:
            path = f"{self._selected_files}/*{COMBO_EXT}"
        elif text == LogTypes.SAM_LOGS.value:
            path = f"{self._selected_files}/*{SAM_EXT}"

        return path

    @property
    def pool_directory(self):
        return str(self._pool_directory)

    @property
    def cmd_to_use(self):
        return str(self._cmd_to_use)

    @property
    def config_to_use(self):
        return str(self._config_to_use)

    def _enable_pool_btn(self):
        self.ui.pool_data_btn.setEnabled(True)

    def _choose_target_files(self):
        """
        Choose target directory with files for specific type of log
        """
        select_dir = QtWidgets.QFileDialog.getExistingDirectory(self)
        if select_dir:
            self._selected_files = select_dir
            self.ui.target_file_edit.setText(self.selected_files)

    def _choose_pool_dir(self):
        """
        Select the location of the data pool
        """
        pool_selection = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Select Pool Directory"
        )
        if pool_selection:
            self._pool_directory = pool_selection
            self.ui.pool_dir_edit.setText(self.pool_directory)

    def _set_params(self, setup: dict):
        for attr, value in setup.items():
            setattr(self, attr, value)

    def _log_type_select(self):
        """
        Set all the appropiate values for config, command, and file type
        based on user selection
        """
        text = self.ui.log_type_combo.currentText()
        if text == LogTypes.PRIVATE_LOGS.value:
            self._set_params(PRIVATE_SETUP)
            self.ui.col_hours_sb.setValue(24)
        elif text == LogTypes.COMBO_LOGS.value:
            self._set_params(COMBO_SETUP)
            self.ui.col_hours_sb.setValue(1)
        elif text == LogTypes.SAM_LOGS.value:
            self._set_params(SAM_SETUP)
            self.ui.col_hours_sb.setValue(24)
        self.show_selections()

    def show_selections(self):
        """
        Conveninece to show which files have been selected and
        where the pool results will go
        """
        self.ui.pool_dir_edit.setText(self.pool_directory)
        self.ui.target_file_edit.setText(self.selected_files)

    def update_message(self, msg, clear=False):
        """function to update from information from thread"""
        if clear:
            self.ui.config_text.clear()
        self.ui.config_text.append(msg)

    def check_status(self):
        """
        Main thread to watch the progress of the job and report
        to user
        """
        files = list(LOG_LOC.glob("*"))
        while True:
            if self._process.is_alive():
                if list(LOG_LOC.glob("*")) != files:
                    fp = open(sorted(list(LOG_LOC.glob("*")))[-1], "r")
                    lines = "".join(fp.readlines()[-200:])
                    self._message_signal.emit(lines, True)
                time.sleep(1)
            else:
                self._pool_btn_signal.emit()
                self._message_signal.emit("Job Finished", False)
                self._process.join()
                break

    def start_pool(self):
        """
        Main function to actually run the pool job defined
        by the user inputs
        """
        self.ui.config_text.clear()
        self.ui.pool_data_btn.setEnabled(False)
        self._process = mp.Process(
            target=pool_data,
            args=(
                [self.ui.target_file_edit.toPlainText()],
                self.config_to_use,
                self.cmd_to_use,
                self._file_type,
                self._source_lookup,
                self.ui.col_hours_sb.value(),
                self.pool_directory,
                SNAKEFILE,
            ),
        )
        self._process.start()
        status_thread = Thread(target=self.check_status, daemon=True)
        status_thread.start()


def pool_data(
    log_files: list,
    config_name: str,
    command_name: str,
    file_type: str,
    source_lookup: dict,
    collation_hours: int,
    pool_dir: str,
    snakefile: str,
):
    config_path = Path(config_name)
    if not config_path.exists():
        config_path.parent.mkdir(parents=True, exist_ok=True)
    with open(config_name, "w") as yp:
        cur_config = {
            "log_files": log_files,
            "pool_dir": pool_dir,
            "file_type": file_type,
            "source_lookup": source_lookup,
            "collation_hours": collation_hours,
        }
        yaml.dump(cur_config, yp, default_flow_style=False)
    snakemake(
        snakefile,
        targets=[command_name],
        configfiles=[config_name],
        workdir=DEFAULT_POOL,
        cores=4,
        forceall=True,
    )


if __name__ == "__main__":
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    app = QtWidgets.QApplication(sys.argv)
    window = Ui_Main()
    sys.exit(app.exec())
