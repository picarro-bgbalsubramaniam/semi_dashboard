#!/usr/bin/env python
from pathlib import Path
import sys
import time
from time import ctime
import click
from data_pooler.pool_utils import emit_pool_df_from_h5
from data_pooler.api import private_log as pl


def _main(input_file, output_dir, collation_interval, file_type):
    print(f"[{ctime()}]")
    print(f"Processing {input_file}")
    output_path = Path(output_dir)
    for date_code, start_epoch, end_epoch, df_in in emit_pool_df_from_h5(
        input_file, collation_interval
    ):
        pl.update_pool_file(
            output_path,
            input_file,
            date_code,
            start_epoch,
            end_epoch,
            df_in,
            file_type,
        )


@click.command()
@click.option("-i", "input_file", help=".h5 file with private log")
@click.option("-o", "output_dir", help="Output directory for pool of private logs")
@click.option(
    "-c", "collation_interval", default=86400, help="Collation interval in seconds"
)
@click.option("-t", "file_type", default="PrivateLog", help="File type string")
def main(input_file, output_dir, collation_interval, file_type):
    return _main(input_file, output_dir, collation_interval, file_type)


if __name__ == "__main__":
    try:
        snakemake
    except NameError:
        main()
    else:
        logp = open(snakemake.log[0], "w")
        sys.stdout = logp
        sys.stderr = logp
        pool_dir = Path(snakemake.params.pool_dir)
        input_file = snakemake.input[0]
        collation_interval = snakemake.params.collation_interval
        file_type = snakemake.params.file_type
        _main(input_file, pool_dir, collation_interval, file_type)
