import shutil
import sys
from pathlib import Path
import pprint


def _main(log_files, private_log_files, config):
    """Pretty print the configuration, the dictionary of zip files and the
        dictionary of private_log_files to stdout. This is used for logging.

    Args:
        log_files (dict): Dictionary of zip files, the keys are labels and values are
            Path objects for the files
        private_log_files (dict): Dictionary of h5 files, the keys are labels and values are
            Path objects for the files
        config (dict): Snakemake configuration as a dictionary
    """
    print("Configuration:")
    pprint.pprint(config, indent=4)
    if "log_files" in config:
        print("log_files processed:")
        pprint.pprint(log_files, indent=4)
        unzip_path = Path("results/unzipped")
        if unzip_path.exists() and unzip_path.is_dir():
            shutil.rmtree(unzip_path)
    print("private_log_files processed:")
    pprint.pprint(private_log_files, indent=4)


with open(snakemake.log[0], "w") as logp:
    log_files = snakemake.params.log_files
    private_log_files = snakemake.params.private_log_files
    config = snakemake.config
    sys.stdout = logp
    sys.stderr = logp
    try:
        _main(log_files, private_log_files, config)
    finally:
        sys.stderr = sys.__stderr__
        sys.stdout = sys.__stdout__
