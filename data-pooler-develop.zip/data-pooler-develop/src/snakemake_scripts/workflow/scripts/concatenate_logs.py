from cmath import log
import click
import os
import sys
from pathlib import Path


def _main(input_file_names, log_dir):
    """Concatenate log files with the specified file names in order of last modification
        time, writing the result to stdout. Files are separated by 72 '-' characters

    Args:
        input_file_names (list of str): Names of the input files. The stem of each file
            name is taken and the `<stem>.log` is looked up in the directory `log_dir`.
        log_dir (str): Name of the directory containing log files
    """
    log_files = [Path(log_dir) / f"{Path(name).stem}.log" for name in input_file_names]
    log_files = sorted(log_files, key=os.path.getmtime)
    for log_file in log_files:
        with log_file.open("r") as lp:
            print(lp.read())
        print(
            "------------------------------------------------------------------------"
        )
        os.remove(log_file)


@click.command()
@click.option("-i", "input_file_names", help="List of private log h5 files")
@click.option("-l", "log_dir", help="Directory containing logs")
def main(input_file_names, log_dir):
    return _main(input_file_names, log_dir)


if __name__ == "__main__":
    try:
        snakemake
    except NameError:
        main()
    else:
        logp = open(snakemake.log[0], "w")
        log_dir = snakemake.params.log_dir
        sys.stdout = logp
        sys.stderr = logp
        input_file_names = snakemake.input
        _main(input_file_names, log_dir)
