#!/usr/bin/env python
from pathlib import Path
from time import ctime
import click
from data_pooler.api import combo_log as cl


def _main(input_file, output_dir, collation_interval, file_type):
    print(f"[{ctime()}]")
    print(f"Processing {input_file}")
    output_path = Path(output_dir)
    for (
        metadata_in,
        date_code,
        start_epoch,
        end_epoch,
        fit_data_dff,
        spectra_dff,
    ) in cl.emit_combo_log_df_from_h5(input_file, collation_interval):
        cl.update_pool_file(
            output_path,
            metadata_in,
            date_code,
            start_epoch,
            end_epoch,
            fit_data_dff,
            spectra_dff,
            file_type,
        )


@click.command()
@click.option("-i", "input_file", help=".h5 file with combo log")
@click.option("-o", "output_dir", help="Output directory for pool of combo logs")
@click.option(
    "-c", "collation_interval", default=86400, help="Collation interval in seconds"
)
@click.option("-t", "file_type", default="ComboLog", help="File type string")
def main(input_file, output_dir, collation_interval, file_type):
    return _main(input_file, output_dir, collation_interval, file_type)


if __name__ == "__main__":
    try:
        snakemake
    except NameError:
        main()
    else:
        logp = open(snakemake.log[0], "w")
        sys.stdout = logp
        sys.stderr = logp
        pool_dir = Path(snakemake.params.pool_dir)
        input_file = snakemake.input[0]
        collation_interval = snakemake.params.collation_interval
        file_type = snakemake.params.file_type
        _main(input_file, pool_dir, collation_interval, file_type)
