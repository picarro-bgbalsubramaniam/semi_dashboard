import shutil
import sys
from pathlib import Path
import pprint


def _main(log_files, config):
    """Pretty print the configuration and the dictionary of log_files to stdout.
        This is used for logging.

    Args:
        log_files (dict): Dictionary of h5 files, the keys are labels and values are
            Path objects for the files
        config (dict): Snakemake configuration as a dictionary
    """
    print("Configuration:")
    pprint.pprint(config, indent=4)
    print("log_files processed:")
    pprint.pprint(log_files, indent=4)


with open(snakemake.log[0], "w") as logp:
    log_files = snakemake.params.log_files
    config = snakemake.config
    sys.stdout = logp
    sys.stderr = logp
    try:
        _main(log_files, config)
    finally:
        sys.stderr = sys.__stderr__
        sys.stdout = sys.__stdout__
