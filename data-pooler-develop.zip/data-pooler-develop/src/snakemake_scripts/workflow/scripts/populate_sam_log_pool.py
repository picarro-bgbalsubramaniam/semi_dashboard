#!/usr/bin/env python
from datetime import timedelta
from pathlib import Path
import json
from time import ctime
import click
from data_pooler.api import sam_log as sl


def _main(input_file, output_dir, collation_interval, source_lookup, file_type):
    print(f"[{ctime()}]")
    print(f"Processing {input_file}")
    output_path = Path(output_dir)
    for (
        metadata_in,
        date_code,
        start_epoch,
        end_epoch,
        df_in,
    ) in sl.emit_sam_pool_df_from_csv(input_file, collation_interval, source_lookup):
        sl.update_pool_file(
            output_path,
            metadata_in,
            date_code,
            start_epoch,
            end_epoch,
            df_in,
            file_type,
        )


@click.command()
@click.option("-i", "input_file", help=".csv file with sam log")
@click.option("-o", "output_dir", help="Output directory for pool of private logs")
@click.option(
    "-c", "collation_interval", default=86400, help="Collation interval in seconds"
)
@click.option(
    "-s", "source_lookup", default="{}", help="JSON coded source lookup dictionary"
)
@click.option("-t", "file_type", default="SamLog", help="File type string")
def main(input_file, output_dir, collation_interval, source_lookup, file_type):
    return _main(
        input_file, output_dir, collation_interval, json.loads(source_lookup), file_type
    )


if __name__ == "__main__":
    try:
        snakemake
    except NameError:
        main()
    else:
        logp = open(snakemake.log[0], "w")
        sys.stdout = logp
        sys.stderr = logp
        pool_dir = Path(snakemake.params.pool_dir)
        input_file = snakemake.input[0]
        collation_interval = snakemake.params.collation_interval
        source_lookup = snakemake.config.get("source_lookup", {})
        file_type = snakemake.params.file_type
        _main(input_file, pool_dir, collation_interval, source_lookup, file_type)
