checkpoint check_decompress_done:
    input:
        lambda wildcards: [f"results/done/decompress/{label}.done"
                           for label in get_zip_lookup(config.get("log_files"))]
    output:
        touch("results/done/decompress.done")
    log:
        "results/logs/decompress.log"
    params:
        log_dir="results/logs",
    script:
        "../scripts/concatenate_logs.py"

rule decompress:
    input:
        lambda wildcards: str(get_zip_lookup(config.get("log_files"))[wildcards["label"]])
    params:
        unzip_dir="results/unzipped"
    log:
        "results/logs/{label}.log"
    output:
        touch("results/done/decompress/{label}.done")
    shell:
        "unzip -d {params.unzip_dir:q} -jo {input:q} > {log} 2>&1"

rule check_populate_private_log_pool_done:
    # N.B. This cannot run until checkpoint check_decompress_done is complete 
    #  (see get_private_log_lookup)
    input:
        lambda wildcards: [f"results/done/populate_private_log_pool/{label}.done" 
                           for label in get_private_log_lookup(config.get("private_log_files"))]
    output:
        touch("results/done/populate_private_log_pool.done")
    log:
        "results/logs/populate_private_log_pool.log"
    params:
        log_dir="results/logs",
    script:
        "../scripts/concatenate_logs.py"

rule populate_private_log_pool:
    # N.B. This cannot run until checkpoint check_decompress_done is complete 
    #  (see get_private_log_lookup)
    input:
        lambda wildcards: str(get_private_log_lookup(config.get("private_log_files"))[wildcards["label"]])
    params:
        source=config.get("source", "UNKNOWN"),
        pool_dir=config.get("pool_dir", "results/pool"),
        collation_interval=3600*config.get("collation_hours", 24),
        file_type=config.get("file_type", "PrivateLog")
    log:
        "results/logs/{label}.log"
    output:
        touch("results/done/populate_private_log_pool/{label}.done")
    script:
        "../scripts/populate_private_log_pool.py"
