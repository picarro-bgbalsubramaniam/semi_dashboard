from glob import glob
from pathlib import Path
from functools import lru_cache

def get_zip_lookup(log_files):
    """Returns dictionary of zipped archives of private logs which have been specfied
       by expanding the 'log_files' entry in the config. The keys are 'zip_nnnn' and the
       values are the paths to the zip files.
    """
    if log_files is None:
        return {}
    elif not isinstance(log_files, str):
        log_files = tuple(log_files)
    else:
        log_files = (log_files,)
    return _get_zip_lookup(log_files)

@lru_cache
def _get_zip_lookup(log_files):
    file_list = []
    for zip_file in log_files:
        file_list.extend(list(glob(zip_file, recursive=True)))
    return {f"zip_{i:04d}": Path(f) for i, f in enumerate(file_list)}


def get_combo_log_lookup(log_files):
    """Returns dictionary of combo_log (h5) files which have been specified
       or specified by expanding the 'log_files' key in the config. 
       The keys of the resulting dictionary are 'combo_log_nnnn' and the values 
       are the paths to the h5 files.
       
       The argument `log_files` should be config['log_files']
    """
    if log_files is None:
        log_files = tuple()
    elif not isinstance(log_files, str):
        log_files = tuple(log_files)
    else:
        log_files = (log_files,)
    return _get_combo_log_lookup(log_files)

@lru_cache
def _get_combo_log_lookup(log_files):
    file_list = []
    for h5_file in log_files:
        file_list.extend(list(glob(h5_file, recursive=True)))
    return {f"combo_log_{i:04d}": Path(f) for i, f in enumerate(file_list)}


def get_private_log_lookup(private_log_files):
    """Returns dictionary of private log (h5) files which have either been unzipped 
       (in the results/unzipped directory, from the 'log_files' specified in the config) 
       or specified by expanding the 'private_log_files' key in the config. The keys of the resulting
       dictionary are 'private_log_nnnn' and the values are the paths to the h5 files.
       
       The argument `private_log_files` should be config['private_log_files']

       NOTE: This checks for completion of the checkpoint check_decompress_done, so it
       raises an exception if decompression has not yet been done. This is to ensure that
       we do not cache stale data based on the contents of the results/unzipped directory
    """
    # The next line raises snakemake.exceptions.IncompleteCheckpointException if we have not yet
    #  decompressed the zipfiles 
    #  (see https://snakemake.readthedocs.io/en/stable/snakefiles/rules.html#data-dependent-conditional-execution)
    checkpoints.check_decompress_done.get().output
    if private_log_files is None:
        private_log_files = tuple()
    elif not isinstance(private_log_files, str):
        private_log_files = tuple(private_log_files)
    else:
        private_log_files = (private_log_files,)
    return _get_private_log_lookup(private_log_files)

@lru_cache
def _get_private_log_lookup(private_log_files):
    file_list = list(glob("results/unzipped/*.h5", recursive=True))
    for h5_file in private_log_files:
        file_list.extend(list(glob(h5_file, recursive=True)))
    return {f"private_log_{i:04d}": Path(f) for i, f in enumerate(file_list)}


def get_sam_log_lookup(log_files):
    """Returns dictionary of sam_log (csv) files which have been specified
       or specified by expanding the 'log_files' key in the config. 
       The keys of the resulting dictionary are 'sam_log_nnnn' and the values 
       are the paths to the csv files.
       
       The argument `log_files` should be config['log_files']
    """
    if log_files is None:
        log_files = tuple()
    elif not isinstance(log_files, str):
        log_files = tuple(log_files)
    else:
        log_files = (log_files,)
    return _get_sam_log_lookup(log_files)


@lru_cache
def _get_sam_log_lookup(log_files):
    file_list = []
    for h5_file in log_files:
        file_list.extend(list(glob(h5_file, recursive=True)))
    return {f"sam_log_{i:04d}": Path(f) for i, f in enumerate(file_list)}
