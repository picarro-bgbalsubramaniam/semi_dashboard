rule check_populate_combo_log_pool_done:
    input:
        lambda wildcards: [f"results/done/populate_combo_log_pool/{label}.done" 
                           for label in get_combo_log_lookup(config.get("log_files"))]
    output:
        touch("results/done/populate_combo_log_pool.done")
    log:
        "results/logs/populate_combo_log_pool.log"
    params:
        log_dir="results/logs",
    script:
        "../scripts/concatenate_logs.py"

rule populate_combo_log_pool:
    input:
        lambda wildcards: str(get_combo_log_lookup(config.get("log_files"))[wildcards["label"]])
    params:
        pool_dir=config.get("pool_dir", "results/pool"),
        collation_interval=3600*config.get("collation_hours", 1),
        file_type=config.get("file_type", "ComboLog")
    log:
        "results/logs/{label}.log"
    output:
        touch("results/done/populate_combo_log_pool/{label}.done")
    script:
        "../scripts/populate_combo_log_pool.py"
