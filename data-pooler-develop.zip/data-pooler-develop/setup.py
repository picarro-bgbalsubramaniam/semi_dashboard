from os import getenv
from setuptools import setup, find_packages
from subprocess import check_output

with open("README.md", "r") as f:
    readme = f.read()

def get_version():
    # Check for these environment variables, set by the build system
    major = getenv('majorVersion')
    minor = getenv('minorVersion')
    patch = getenv('patchVersion')
    git_hash = ''
    if not all((major, minor, patch)):
        # No env variables set, so we got here by git checkout
        git_hash = '-' + check_output(['git',
                                       'rev-parse',
                                       '--verify',
                                       'HEAD',
                                       '--short'],
                                       encoding='utf-8')[:-1]
        major = minor = patch = '0'
    return ".".join((major, minor, patch))  # + git_hash

version = get_version()

# Create a version number that is accessible from python runtime
with open('src/data_pooler/version.py', 'w') as f:
    f.write(f'__version__ = "{version}"\n')

setup(
    name='data-pooler',
    version=version,
    license="Copyright Picarro internal use only",
    author="Adam Egger",
    author_email="aegger@picarro.com",
    project_urls={
        "Code": "https://github.com/picarro/data-pooler",
    },
    description="data-pooler",
    long_description=readme,
    long_description_content_type="text/markdown",
    maintainer="Picarro",
    packages=find_packages("src"),
    package_dir={"": "src"},
    install_requires=[
        "blosc>=1.10.6",
        "click>=7.1.2",
        "dask[distributed]>=2022.10.0",
        "pandas>=1.3.5",
        "portalocker>=2.3.2",
        "pydantic>=1.9.0",
        "pytz>=2021.1",
        "tables>=3.6.1",
        "tzlocal>=4.1",
        "numpy>=1.21.5",
        "scipy>=1.7.3",
        "sortedcontainers>=2.4.0",
        "spectral-arithmetic>=0.3.17",
        "zarr>=2.12.0",
        "zstd>=1.5.1.0",
    ],
    python_requires=">=3.8",
)
