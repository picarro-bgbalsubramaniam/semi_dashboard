spectral-arithmetic modules reference
=====================================

Spectral Arithmetic
-------------------

.. automodule:: spectral_arithmetic.aggregate_operations
   :members:

.. automodule:: spectral_arithmetic.crosstalk
   :members:

.. automodule:: spectral_arithmetic.spectrum_operations
   :members:

.. automodule:: spectral_arithmetic.nu_operations.nu_operations
   :members:

.. automodule:: spectral_arithmetic.nu_operations.gridify
   :members:

.. automodule:: spectral_arithmetic.scheme_builder
   :members:

.. automodule:: spectral_arithmetic.linear_least_squares
   :members:

.. autoclass:: spectral_arithmetic.linear_least_squares.LinearLeastSquares
   :members:


Data models
-----------

.. automodule:: spectral_arithmetic.data_models.least_squares
   :members:

.. automodule:: spectral_arithmetic.data_models.spectra
   :members:

.. automodule:: spectral_arithmetic.data_models.scheme_models
   :members:
