.. spectral-arithmetic documentation master file, created by
   sphinx-quickstart on Tue Oct 22 09:52:53 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to spectral-arithmetic documentation!
=============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:


Source documentation
====================
.. toctree::
   :maxdepth: 4
   :caption: Contents:

   modules

Index
=====
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
