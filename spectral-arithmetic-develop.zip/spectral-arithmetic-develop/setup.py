from os import getenv
from setuptools import setup, find_packages
from subprocess import check_output

with open("README.md", "r") as f:
    readme = f.read()

def get_version():
    # Check for these environment variables, set by the build system
    major = getenv('majorVersion')
    minor = getenv('minorVersion')
    patch = getenv('patchVersion')
    git_hash = ''
    if not all((major, minor, patch)):
        # No env variables set, so we got here by git checkout
        git_hash = '+' + check_output(['git',
                                       'rev-parse',
                                       '--verify',
                                       'HEAD',
                                       '--short'],
                                       encoding='utf-8')[:-1]
        major = minor = patch = '0'
    return ".".join((major, minor, patch)) + git_hash

version = get_version()

# Create a version number that is accessible from python runtime
with open('src/spectral_arithmetic/version.py', 'w') as f:
    f.write(f'__version__ = "{version}"\n')

setup(
    name='spectral-arithmetic',
    version=version,
    license="Copyright Picarro internal use only",
    author="Adam Egger",
    author_email="aegger@picarro.com",
    project_urls={
        "Code": "https://github.com/picarro/spectral-arithmetic",
    },
    description="spectral-arithmetic",
    long_description=readme,
    long_description_content_type="text/markdown",
    maintainer="Picarro",
    packages=find_packages("src"),
    package_dir={"": "src"},
    install_requires=[
        "numpy>=1.22.0",
        "pydantic~=2.0",
    ],
    python_requires=">=3.10",
)
