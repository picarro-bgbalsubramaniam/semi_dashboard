from spectral_arithmetic import aggregate_operations as ao
from spectral_arithmetic.data_models.spectra import TransformSpectrum, ModeBin
import numpy as np


# File with 10 spectra results from combo logs including results keys
# fitData_nu_transform_n1, fitData_nu_transform_n0 fitData_nu_transform_nnuc and f0

TEST_DATA = np.load("./test/spectrum_data.npy", allow_pickle=True)
NUM_SPECTRA = 10
LEN_ARRAYS = 333
AVE_FSR_PRIME = 0.020618313074680334
AVE_F0_PRIME = 6056.506928290569
AVE_EPOCH = 1647897481.731133

SPEC_COMBINE = TransformSpectrum(
    absorbance=np.array([20, 40, 60, 80, 100]),
    absorbance_sq=np.array([4, 9, 16, 9, 4]),
    nu_prime=np.array([20, 40, 60, 80, 100]),
    xtalk=np.array([0.1, 0.1, 0.1, 0.1, 0.1]),
    nu_prime_sq=np.array([1, 4, 9, 16, 25]),
    fsr_prime=1.0,
    f0_prime=5.0,
    num_spectra=10,
    epoch_time=1000,
    npoints=np.array([20, 20, 20, 20, 20]),
    mode_idxs=np.array([-2, -1, 0, 1, 2]),
)


def test_tranform_spectra():
    # Mostly a smoke test
    modified_spectra, mask = zip(*list(ao.transform_spectra(TEST_DATA)))
    assert len(modified_spectra) == NUM_SPECTRA
    assert (
        all([type(spectra) == TransformSpectrum for spectra in modified_spectra])
        == True
    )
    assert all([m for m in mask]) == True
    assert len(mask) == NUM_SPECTRA


def test_invalid_transform_spectra():
    modified_spectra, mask = zip(*list(ao.transform_spectra([{}] * NUM_SPECTRA)))
    assert len(modified_spectra) == NUM_SPECTRA
    assert (
        all([type(spectra) == TransformSpectrum for spectra in modified_spectra])
        == True
    )
    assert any([m for m in mask]) == False
    assert len(mask) == NUM_SPECTRA


def test_filter_spectral_data():
    spectrum_gen = ao.transform_spectra(TEST_DATA)
    filtered_spectra = ao.filter_spectral_data(spectrum_gen, fsr_thresh=5, f0_thresh=5)
    assert filtered_spectra.ave_fsr_prime == AVE_FSR_PRIME
    assert filtered_spectra.ave_f0_prime == AVE_F0_PRIME
    assert filtered_spectra.ave_epoch_time == AVE_EPOCH
    assert len(filtered_spectra.spectra) == NUM_SPECTRA


def test_filter_spectral_data_below_thresh():
    # fsr test
    spectrum_gen = ao.transform_spectra(TEST_DATA)
    filtered_spectra = ao.filter_spectral_data(spectrum_gen, fsr_thresh=0)
    assert filtered_spectra.ave_fsr_prime == AVE_FSR_PRIME
    assert filtered_spectra.ave_f0_prime == AVE_F0_PRIME
    assert filtered_spectra.ave_epoch_time == AVE_EPOCH
    assert len(filtered_spectra.spectra) == 0

    # f0 test
    spectrum_gen = ao.transform_spectra(TEST_DATA)
    filtered_spectra = ao.filter_spectral_data(spectrum_gen, f0_thresh=0)
    assert filtered_spectra.ave_fsr_prime == AVE_FSR_PRIME
    assert filtered_spectra.ave_f0_prime == AVE_F0_PRIME
    assert filtered_spectra.ave_epoch_time == AVE_EPOCH
    assert len(filtered_spectra.spectra) == 0


def test_bin_spectral_data():
    spectrum_gen = ao.transform_spectra(TEST_DATA)
    filtered_spectra = ao.filter_spectral_data(spectrum_gen)
    binned_data = ao.bin_spectral_data(filtered_spectra)
    assert binned_data.num_spectra == NUM_SPECTRA
    assert binned_data.epoch_time == AVE_EPOCH
    # Test that every key has the same number of values
    assert all([isinstance(key, int) for key in binned_data.binned_data.keys()]) == True
    for value in binned_data.binned_data.values():
        for item in value:
            assert type(item) == ModeBin
