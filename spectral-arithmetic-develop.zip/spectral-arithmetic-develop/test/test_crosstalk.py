from unittest import mock
from spectral_arithmetic.data_models.crosstalk_args import (
    CrosstalkConcentration,
    CrosstalkLoss,
    PerFrequencyCorrection,
)
from spectral_arithmetic.crosstalk import (
    loss_crosstalk_correction,
    concentration_crosstalk_correction,
    xtalk_freq_mask,
)
import numpy as np

# CIDs are used to index into a concentration dictionary.
# These concentrations are the variables in the crosstalk polynomials.
CID_1 = 1
CID_2 = 2
CID_3 = 3


@mock.patch("spectral_arithmetic.crosstalk.np.zeros")
@mock.patch("spectral_arithmetic.crosstalk.interp1d")
def test_that_interp1d_was_called(mock_interp1d, mock_numpy_zeros):
    """When calculating the overall crosstalk correction, we use scipy.interpolate.interp1d.
    Note that this function call may change in the future, and that's fine, we'd just need to
    update this test."""
    wavenumbers = np.array([6000.0, 6001.0, 6002.0])
    concentrations = {1: 0.5, 2: 0.4}

    per_frequency_correction_args = [
        PerFrequencyCorrection(cids=[1], loss_correction=np.array([1.0, 2.0, 3.0])),
        PerFrequencyCorrection(cids=[1, 1], loss_correction=np.array([1.0, 2.0, 3.0])),
        PerFrequencyCorrection(cids=[1, 2], loss_correction=np.array([1.0, 2.0, 3.0])),
    ]
    crosstalk_args = CrosstalkLoss(
        wavenumbers=wavenumbers, corrections=per_frequency_correction_args
    )

    eval_array = np.linspace(6000.0, 6002.0, 10)
    loss_crosstalk_correction(eval_array, concentrations, crosstalk_args)

    # We should get as many calls to interp1d as there are items in list "per_frequency_correction"
    mock_interp1d.call_count == len(per_frequency_correction_args)


def test_that_extrapolation_occurs():
    """If we ask for crosstalk corrections completely outside of the valid correction range, we get
    an array that is identically zero.
    """
    wavenumbers = np.array([6000.0, 6001.0, 6002.0])
    dummy_conc_value = 5
    lower_absorbance = 1.0
    concentrations = {1: dummy_conc_value}
    crosstalk_args = CrosstalkLoss(
        wavenumbers=wavenumbers,
        corrections=[
            PerFrequencyCorrection(cids=[1], loss_correction=np.array([lower_absorbance, 2.0, 3.0])),
        ],
    )

    # The array that we will evaluate has wavenumbers that do not overlap with the interpolated
    # wavenumbers. Here, they start at 5000 wvn and end below 6000, whereas the `frequencies`
    num_points_nu = 1000
    eval_array = np.linspace(5000.0, 5999.999, num_points_nu)
    loss_correction = loss_crosstalk_correction(
        eval_array, concentrations, crosstalk_args
    )
    # If the "extrapolate" policy was set on the interpolation function, then the following is true
    assert sum(loss_correction) == num_points_nu * lower_absorbance * dummy_conc_value


def correction_args_harness():
    return {
        "fit_name": "dummy_fitter",
        "offset": 10,
        "traversal_directives": ["fake", "traversal", "directives"],
        "crosstalk": {
            "cids": [[CID_1], [CID_2], [CID_3], [CID_1, CID_3]],
            "coefficients": [0.1, 0.2, 0.3, 0.4],
            "output_name": "fake_crosstalk_output",
        },
        "calibration": {
            "output_name": "fake_calibration_output",
            "coefficients": [10.0, 3.0],
        },
    }


def test_apply_corrections():
    """Test the full "correction" calculation suite."""

    crosstalk = CrosstalkConcentration(
        offset=10,
        cids=[[CID_1], [CID_2], [CID_3], [CID_1, CID_3]],
        concentration_coefficients=[0.1, 0.2, 0.3, 0.4],
        polynomial_coefficients=[10.0, 3.0],
    )

    model_parameter = 0.3  # This will be the model parameter used for crosstalk
    concentrations = {CID_1: 0.1, CID_2: 0.2, CID_3: 0.3}
    crosstalk_value, calibration_value = concentration_crosstalk_correction(
        model_param=model_parameter, concentrations=concentrations, crosstalk=crosstalk
    )

    # This will first calculate f(x, y, z) = 0.3 + 10 + 0.1x + 0.2y + 0.3z + 0.4xz with x=0.1, y=0.2, z=0.3
    x = 0.1
    y = 0.2
    z = 0.3
    fake_crosstalk_output = 0.3 + 10 + 0.1 * x + 0.2 * y + 0.3 * z + 0.4 * x * z

    # Next step is to calculate g(f) = m*f + b
    fake_calibration_output = 10.0 * fake_crosstalk_output + 3.0

    assert crosstalk_value == fake_crosstalk_output
    assert calibration_value == fake_calibration_output


def test_xtalk_freq_error_does_not_reject():
    """ If all the wavenumbers in our dataset line up with a value in the xtalk.wavenumbers
    array, then we should not reject anything.
    """
    # Create a nu array and an xtalk_nu array where there will be zero rejections
    np.random.seed(0)
    # For fun, add some noise
    nu = np.linspace(11, 20, 10) + np.random.normal(0, .01, 10)
    xtalk_nu = np.linspace(1, 50, 50)
    keep, reject = xtalk_freq_mask(nu, xtalk_nu, max_dist=.49)
    assert len(reject) == 0
    assert len(keep) == len(nu)

    # Do the same thing but for a more simple case
    nu = np.array([3.01])
    xtalk_nu = np.linspace(1, 10, 10)
    _, reject = xtalk_freq_mask(nu, xtalk_nu, max_dist=.1)
    assert len(reject) == 0


def test_xtalk_freq_error_does_reject():
    """ If a the wavenumber in our dataset does not line up with a value in the xtalk.wavenumbers
    array, then we should reject it.
    """
    # Create a nu array and an xtalk_nu array where there will be zero rejections
    np.random.seed(0)
    nu = np.linspace(11, 20, 10) + np.random.normal(0, .001, 10)

    # This is our outlier:
    nu[5] = 10000
    xtalk_nu = np.linspace(1, 50, 50)
    keep, reject = xtalk_freq_mask(nu, xtalk_nu, max_dist=.499)
    assert len(reject) == 1
    assert len(keep) == len(nu) - 1

    # Here's another couple of examples. These arrays totally don't line up!
    nu = np.r_[50:100:1]
    xtalk_nu = np.r_[-10:10:1]
    _, reject = xtalk_freq_mask(nu, xtalk_nu)
    assert len(reject) == len(nu)

    nu = np.r_[5:100:1]
    xtalk_nu = np.array([0])
    _, reject = xtalk_freq_mask(nu, xtalk_nu)
    assert len(reject) == len(nu)
