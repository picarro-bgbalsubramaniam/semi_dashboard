from spectral_arithmetic.data_models import spectra
from spectral_arithmetic.allan_deviation import AllanBin
import pytest
import pydantic
import numpy as np


TEST_BIN_NU = spectra.ModeBin(
    n_points=10, val_sum=10, val_sum_sq=100, spectra_in_bin=10, key="nu_prime"
)

TEST_BIN_ABSORBANCE = spectra.ModeBin(
    n_points=10, val_sum=10, val_sum_sq=100, spectra_in_bin=10, key="absorbance"
)

TEST_BIN_PARTIAL = spectra.ModeBin(
    n_points=10, val_sum=10, val_sum_sq=100, spectra_in_bin=10, key="partial_fit"
)

TEST_BIN_RESIDUAL = spectra.ModeBin(
    n_points=10, val_sum=10, val_sum_sq=100, spectra_in_bin=10, key="residuals"
)

TEST_BIN_XTALK = spectra.ModeBin(
    n_points=10, val_sum=10, val_sum_sq=100, spectra_in_bin=10, key="xtalk"
)

TEST_BIN_STATIC = spectra.ModeBin(
    n_points=10, val_sum=10, val_sum_sq=100, spectra_in_bin=10, key="static_compounds"
)

FAKE_DATA = np.arange(1, 10, 0.1)

TEST_ABIN = AllanBin(1)
for val in FAKE_DATA:
    TEST_ABIN.process(val)


BINNED_SPECTRA_NUM_SPECTRA = spectra.BinnedSpectra(
    num_spectra=20,
    fsr_prime=0.0206,
    f0_prime=6057,
    epoch_time=100,
    binned_data={
        -100: np.array(
            [TEST_BIN_NU, TEST_BIN_ABSORBANCE, TEST_BIN_PARTIAL, TEST_BIN_RESIDUAL, TEST_BIN_XTALK, TEST_BIN_STATIC]
        ),
        100: np.array(
            [TEST_BIN_NU, TEST_BIN_ABSORBANCE, TEST_BIN_PARTIAL, TEST_BIN_RESIDUAL, TEST_BIN_XTALK, TEST_BIN_STATIC]
        ),
        0: np.array(
            [TEST_BIN_NU, TEST_BIN_ABSORBANCE, TEST_BIN_PARTIAL, TEST_BIN_RESIDUAL, TEST_BIN_XTALK, TEST_BIN_STATIC]
        ),
    },
    binned_allan={
        -100: {v: TEST_ABIN for v in spectra.SpectralEnum.list()},
        0: {v: TEST_ABIN for v in spectra.SpectralEnum.list()},
        100: {v: TEST_ABIN for v in spectra.SpectralEnum.list()},
    }
)


BINNED_SPECTRA = spectra.BinnedSpectra(
    num_spectra=10,
    fsr_prime=0.0206,
    f0_prime=6057,
    epoch_time=100,
    binned_data={
        -100: np.array(
            [TEST_BIN_NU, TEST_BIN_ABSORBANCE, TEST_BIN_PARTIAL, TEST_BIN_RESIDUAL, TEST_BIN_XTALK, TEST_BIN_STATIC]
        ),
        100: np.array(
            [TEST_BIN_NU, TEST_BIN_ABSORBANCE, TEST_BIN_PARTIAL, TEST_BIN_RESIDUAL, TEST_BIN_XTALK, TEST_BIN_STATIC]
        ),
    },
    binned_allan={
        -100: {v: TEST_ABIN for v in spectra.SpectralEnum.list()},
        100: {v: TEST_ABIN for v in spectra.SpectralEnum.list()},
    }
)


def test_multiply_bin():
    # Test nu not mutated
    assert TEST_BIN_NU * 5 == TEST_BIN_NU
    # Test that we can perform this action on absorbance
    abs_mult = TEST_BIN_ABSORBANCE * 5
    assert abs_mult.n_points == 10
    assert abs_mult.val_sum == 50
    assert abs_mult.val_sum_sq == 2500
    assert abs_mult.key == "absorbance"


def test_divide_bin():
    # Test nu not mutated
    assert TEST_BIN_NU / 5 == TEST_BIN_NU
    # Test that we can perform this action on absorbance
    abs_mult = TEST_BIN_ABSORBANCE / 5
    assert abs_mult.n_points == 10
    assert abs_mult.val_sum == 2
    assert round(abs_mult.val_sum_sq) == 4
    assert abs_mult.key == "absorbance"


def test_invalid_modebin_key():
    with pytest.raises(pydantic.ValidationError):
        spectra.ModeBin(n_points=10, val_sum=10, val_sum_sq=100, key="lol")


def test_join_bin():
    # This is how we join binned data
    new_bin = TEST_BIN_ABSORBANCE & TEST_BIN_ABSORBANCE
    assert new_bin.n_points == 20
    assert new_bin.val_sum == 20
    assert new_bin.val_sum_sq == 200
    assert new_bin.spectra_in_bin == 20


def test_bad_join_bin():
    with pytest.raises(Exception) as e:
        TEST_BIN_ABSORBANCE & "hi"
    assert e.type == TypeError


def test_stats_bin():
    assert TEST_BIN_NU.mean == 1
    assert TEST_BIN_NU.std == 3
    assert round(TEST_BIN_NU.std_err, 2) == 0.95


def test_add_bin_scalar():
    new_bin = TEST_BIN_NU + 5
    assert new_bin.mean == 6
    assert new_bin.spectra_in_bin == 10


def test_add_bin_nu():
    new_bin = TEST_BIN_NU + TEST_BIN_NU
    assert new_bin.mean == 1  # don't want this changed for nu_prime
    assert new_bin.n_points == 10  # This should remain the same
    assert new_bin.spectra_in_bin == 20


def test_add_bin_abs():
    new_bin = TEST_BIN_ABSORBANCE + TEST_BIN_ABSORBANCE
    assert new_bin.mean == 2
    assert new_bin.n_points == 10
    assert new_bin.spectra_in_bin == 20


def test_sub_spectra_scalar():
    new_bin = TEST_BIN_NU - 5
    assert new_bin.mean == -4
    assert new_bin.spectra_in_bin == 10


def test_sub_bin_nu():
    new_bin = TEST_BIN_NU - TEST_BIN_NU
    assert new_bin.mean == 1
    assert new_bin.n_points == 10
    assert new_bin.spectra_in_bin == 10


def test_sub_bin_abs():
    new_bin = TEST_BIN_ABSORBANCE - TEST_BIN_ABSORBANCE
    assert new_bin.mean == 0
    assert new_bin.n_points == 10
    assert new_bin.spectra_in_bin == 10


####  Binned Data tests ####


def test_n_points():
    n_points = BINNED_SPECTRA.n_points
    assert np.array_equal(n_points, np.array([10, 10]))


def test_nu_prime():
    nu_prime = BINNED_SPECTRA.nu_prime
    assert np.array_equal(nu_prime, np.array([1, 1]))


def test_absorption():
    absorption = BINNED_SPECTRA.absorption
    assert np.array_equal(absorption, np.array([1, 1]))


def test_residual():
    res = BINNED_SPECTRA.residuals
    assert np.array_equal(res, np.array([1, 1]))


def test_partial():
    part = BINNED_SPECTRA.partial_fit
    assert np.array_equal(part, np.array([1, 1]))


def test_xtalk():
    part = BINNED_SPECTRA.xtalk
    assert np.array_equal(part, np.array([1, 1]))


def test_static():
    part = BINNED_SPECTRA.static_compounds
    assert np.array_equal(part, np.array([1, 1]))


def test_nu_prime_std():
    nu_prime = BINNED_SPECTRA.nu_prime_std
    assert np.array_equal(nu_prime, np.array([3, 3]))


def test_absorption_std():
    absorption = BINNED_SPECTRA.absorption_std
    assert np.array_equal(absorption, np.array([3, 3]))


def test_residual_std():
    res = BINNED_SPECTRA.residuals_std
    assert np.array_equal(res, np.array([3, 3]))


def test_xtalk_std():
    res = BINNED_SPECTRA.xtalk_std
    assert np.array_equal(res, np.array([3, 3]))


def test_partial_std():
    part = BINNED_SPECTRA.partial_fit_std
    assert np.array_equal(part, np.array([3, 3]))


def test_static_std():
    part = BINNED_SPECTRA.static_compounds_std
    assert np.array_equal(part, np.array([3, 3]))


def test_nu_prime_std_err():
    nu_prime = np.around(BINNED_SPECTRA.nu_prime_std_err, 2)
    assert np.array_equal(nu_prime, np.array([0.95, 0.95]))


def test_absorption_std_err():
    absorption = np.around(BINNED_SPECTRA.absorption_std_err, 2)
    assert np.array_equal(absorption, np.array([0.95, 0.95]))


def test_residual_std_err():
    res = np.around(BINNED_SPECTRA.residuals_std_err, 2)
    assert np.array_equal(res, np.array([0.95, 0.95]))


def test_xtalk_std_err():
    res = np.around(BINNED_SPECTRA.xtalk_std_err, 2)
    assert np.array_equal(res, np.array([0.95, 0.95]))


def test_partial_std_err():
    part = np.around(BINNED_SPECTRA.partial_fit_std_err, 2)
    assert np.array_equal(part, np.array([0.95, 0.95]))


def test_static_std_err():
    part = np.around(BINNED_SPECTRA.static_compounds_std_err, 2)
    assert np.array_equal(part, np.array([0.95, 0.95]))


def test_nu_prime_avar():
    nu_avar = np.around(BINNED_SPECTRA.nu_prime_avar, 5)
    assert np.array_equal(nu_avar, np.array([0.005, 0.005]))

def test_nu_prime_adev():
    assert np.allclose(BINNED_SPECTRA.nu_prime_adev, np.array([0.07071, 0.07071]))

def test_nu_prime_astderr():
    nu_prime_astderr = np.around(BINNED_SPECTRA.nu_prime_astderr, 5)
    assert np.array_equal(nu_prime_astderr, np.array([0.00745, 0.00745]))

def test_partial_fit_avar():
    partial_fit_avar = np.around(BINNED_SPECTRA.partial_fit_avar, 5)
    assert np.array_equal(partial_fit_avar, np.array([0.005, 0.005]))

def test_partial_fit_adev():
    assert np.allclose(BINNED_SPECTRA.partial_fit_adev, np.array([0.07071, 0.07071]))

def test_partial_fit_astderr():
    partial_fit_astderr = np.around(BINNED_SPECTRA.partial_fit_astderr, 5)
    assert np.array_equal(partial_fit_astderr, np.array([0.00745, 0.00745]))

def test_absorption_avar():
    absorption_avar = np.around(BINNED_SPECTRA.absorption_avar, 5)
    assert np.array_equal(absorption_avar, np.array([0.005, 0.005]))

def test_xtalk_avar():
    xtalk_avar = np.around(BINNED_SPECTRA.xtalk_avar, 5)
    assert np.array_equal(xtalk_avar, np.array([0.005, 0.005]))

def test_residuals_avar():
    residuals_avar = np.around(BINNED_SPECTRA.residuals_avar, 5)
    assert np.array_equal(residuals_avar, np.array([0.005, 0.005]))


def test_static_avar():
    nu_avar = np.around(BINNED_SPECTRA.static_compounds_avar, 5)
    assert np.array_equal(nu_avar, np.array([0.005, 0.005]))


def test_static_adev():
    assert np.allclose(BINNED_SPECTRA.static_compounds_adev, np.array([0.07071, 0.07071]))


def test_static_astderr():
    static_compounds_astderr = np.around(BINNED_SPECTRA.static_compounds_astderr, 5)
    assert np.array_equal(static_compounds_astderr, np.array([0.00745, 0.00745]))


def test_multiply_binned():
    new_data = BINNED_SPECTRA.multiply(5)
    for v in new_data.binned_data.values():
        for b in v:
            if b.key.name == "nu_prime":
                assert b.val_sum == 10
            else:
                assert b.val_sum == 50
    new_nu_avar = np.around(new_data.nu_prime_avar, 5)
    assert np.array_equal(new_nu_avar, np.array([0.005, 0.005]))
    new_partial_fit_avar = np.around(new_data.partial_fit_avar, 5)
    assert np.array_equal(new_partial_fit_avar, np.array([0.125, 0.125]))

def test_divide_binned():
    new_data = BINNED_SPECTRA.divide(5)
    for v in new_data.binned_data.values():
        for b in v:
            if b.key.name == "nu_prime":
                assert b.val_sum == 10
            else:
                assert b.val_sum == 2
    new_nu_avar = np.around(new_data.nu_prime_avar, 5)
    assert np.array_equal(new_nu_avar, np.array([0.005, 0.005]))
    new_partial_fit_avar = np.around(new_data.partial_fit_avar, 5)
    assert np.array_equal(new_partial_fit_avar, np.array([0.0002, 0.0002]))

def test_subtract_binned():
    new_binned = BINNED_SPECTRA.subtract_binned_spectra(BINNED_SPECTRA_NUM_SPECTRA)
    assert np.array_equal(new_binned.nu_prime, np.array([1, 1]))
    for val in new_binned.binned_data.values():
        for b in val:
            if b.key.name == "nu_prime":
                assert b.val_sum == 10
            else:
                assert b.val_sum == 0
    new_nu_avar = np.around(new_binned.nu_prime_avar, 5)
    assert np.array_equal(new_nu_avar, np.array([0.005, 0.005]))
    new_partial_fit_avar = np.around(new_binned.partial_fit_avar, 5)
    assert np.array_equal(new_partial_fit_avar, np.array([0.005, 0.005]))



def test_union_binned_spectra_1():
    """
    Check two different binned spectra to make sure we pull out appropriate different values
    Specifically for one with a different number of modes than the other
    """
    union_binned = BINNED_SPECTRA.union_binned_spectra(BINNED_SPECTRA_NUM_SPECTRA)
    for val in union_binned.binned_data.values():
        for b in val:
            assert b.val_sum in [10, 20]
    assert np.array_equal(union_binned.nu_prime, np.array([1, 1, 1]))
    assert np.array_equal(union_binned.absorption, np.array([1, 1, 1]))
    assert union_binned.num_spectra == 30
    assert union_binned.fsr_prime == 0.0206
    assert union_binned.f0_prime == 6057
    # Check that we only use the spectra in bin from one mode
    assert union_binned.binned_data[0][0].spectra_in_bin == 10
    assert union_binned.binned_data[100][0].spectra_in_bin == 20


def test_intersecting_spectrum():
    intersecting_binned = BINNED_SPECTRA.intersecting_spectrum([-100])
    assert np.array_equal(intersecting_binned.nu_prime, np.array([1]))
    assert np.array_equal(intersecting_binned.absorption, np.array([1]))
    assert np.allclose(intersecting_binned.partial_fit_adev, np.array([0.07071]))

def test_filter_bins():
    new_spectra = BINNED_SPECTRA.filter_bins(threshold=1)
    assert len(new_spectra.binned_data.keys()) == 2
    # Test we raise error for threshold above 1
    with pytest.raises(ValueError):
        BINNED_SPECTRA.filter_bins(threshold=1.1)
    new_spectra = BINNED_SPECTRA_NUM_SPECTRA.filter_bins(threshold=1)
    assert len(new_spectra.binned_data.keys()) == 0


def test_mode_union():
    # smoke test
    assert (
        np.array_equal(
            BINNED_SPECTRA.mode_union(BINNED_SPECTRA_NUM_SPECTRA), np.array([100, 0, -100])
        )
        == True
    )
def test_mode_intersect():
    # smoke test
    assert (
        np.array_equal(
            BINNED_SPECTRA.mode_intersect(BINNED_SPECTRA_NUM_SPECTRA), np.array([-100, 100])
        )
        == True
    )


def test_union_binned_spectra2():
    """
    Older test of two of the same binned spectra
    """
    union_binned = BINNED_SPECTRA.union_binned_spectra(BINNED_SPECTRA)
    for val in union_binned.binned_data.values():
        for b in val:
            assert b.val_sum == 20
    assert np.array_equal(union_binned.nu_prime, np.array([1, 1]))
    assert np.array_equal(union_binned.absorption, np.array([1, 1]))
    assert union_binned.num_spectra == 20
    assert union_binned.fsr_prime == 0.0206
    assert union_binned.f0_prime == 6057
