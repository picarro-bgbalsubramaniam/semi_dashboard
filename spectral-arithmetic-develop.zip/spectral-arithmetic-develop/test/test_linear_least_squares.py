import scipy

from spectral_arithmetic.utils import spectrum_simulator
from spectral_arithmetic.linear_least_squares import LinearLeastSquares, least_squares, design_matrix
from spectral_arithmetic.data_models.model_function import ModelFunctions
from pytest import raises
import numpy as np


def spectrum_gen_harness():
    np.random.seed(1)
    line_args = [[(-30, 1, 0.3, 0.1)], [(10, 1.3, 1, 0.012)], [(50, 1.5, 1, 0.03)]]
    nu = np.linspace(-100, 100, 2000)
    concentrations = np.array([0.3, 0.22, 0.9])
    concentrations /= np.sum(concentrations)
    design_matrix, spectrum, _ = spectrum_simulator(nu, line_args, concentrations)
    baseline_columns = [np.ones(nu.shape), nu]
    design_matrix = np.vstack((baseline_columns, design_matrix.T)).T
    return design_matrix, spectrum, concentrations


def model_functions_harness(nu_min=6000, nu_max=6010):
    funcs = {
        1: lambda x: np.array([1, 2, 3, 4]),
        2: lambda x: np.array([1, 3, 3, 1]),
        3: lambda x: np.array([4, 2, 2, 4]),
        4: lambda x: np.array([4, 3, 2, 1]),
    }
    return ModelFunctions(nu_min=nu_min, nu_max=nu_max, funcs=funcs)


def test_design_matrix_cols_can_be_unordered():
    """ Default behavior is that the columns of the design matrix are model functions indexed by
    cid in numerical order, regardless of original insertion order.

    Now we also support the use case where columns are ordered according to insertion order of the
    model function dictionary, even of that leads to unsorted columns.
    """
    unsorted_model_functions = {
        4: lambda x: np.array([4, 4, 4, 4]),
        1: lambda x: np.array([1, 1, 1, 1]),
        3: lambda x: np.array([3, 3, 3, 3]),
        2: lambda x: np.array([2, 2, 2, 2]),
    }
    A = design_matrix(nu_array=np.array([]),
                      model_functions=unsorted_model_functions,
                      nu_center=0,
                      baseline_order=None,
                      sort_cols=False)
    # If the columns were sorted, we'd see [1, 2, 3, 4]. But since they were not sorted, we see
    # this instead:
    assert np.array_equal(A[0], np.array([4, 1, 3, 2]))

    # To prove that the above is correct, now we allow the columns to be sorted
    B = design_matrix(nu_array=np.array([]),
                      model_functions=unsorted_model_functions,
                      nu_center=0,
                      baseline_order=None,
                      sort_cols=True)
    assert np.array_equal(B[0], np.array([1, 2, 3, 4]))


def test_linear_least_squares():
    design_matrix, spectrum, concentrations = spectrum_gen_harness()
    solution, statistics = least_squares(design_matrix, spectrum)

    # Ensure that the solution we derived has concentrations close to what we passed in.
    # Remove the first two elements as they pertain to the baseline
    derived_concentrations = solution[2:]
    assert np.allclose(derived_concentrations, concentrations)

    # Ensure that the baseline we arrived at is close to zero
    derived_baseline = solution[:2]
    assert np.allclose(derived_baseline, [0, 0])

    # This problem is well-posed so the residues should be small
    residue = statistics.lsq_res
    assert np.allclose(0, residue)


def test_r2_linear_least_squares():
    # generate some random regression with large noise
    rng = np.random.RandomState(42)
    n_samples, n_features, noise = 100, 5, 0.1
    X = rng.randn(n_samples, n_features)
    true_coefficients = rng.randn(n_features)
    y = X @ true_coefficients + rng.normal(0, noise, size=n_samples)

    solution, statistics = least_squares(X, y)

    slope, intercept, r_value, p_value, std_err = scipy.stats.linregress(
        X @ solution, y
    )

    # verify R2 matches between scipy linregress and our solution
    assert np.isclose(r_value**2, statistics.R2, atol=1e-3)


def test_least_squares_doesnt_mutate():
    """Make sure that when we use the "y_err" parameter, which is used to
    divide the data and design matrices, does not mutate the original objects."""
    design_matrix, spectrum, _ = spectrum_gen_harness()

    # Retain a copy of the original objects
    original_design_matrix = design_matrix.copy()
    original_spectrum = spectrum.copy()

    # Run the algorithm
    _, _ = least_squares(design_matrix, spectrum, y_err=np.ones(spectrum.shape) * 0.5)

    # Verify the objects haven't been mutated after running the algorithm
    assert np.equal(design_matrix, original_design_matrix).all()
    assert np.equal(spectrum, original_spectrum).all()


def test_least_squares_nu_out_of_bounds():
    model_functions = model_functions_harness()
    lsq = LinearLeastSquares(model_functions)
    with raises(ValueError):
        _, _ = lsq.eval(
            nu_array=np.array([6001.0, 6002.0, 6003.0, 6004.0]) - 100,
            y_data=np.array([1.0, 2.0, 3.0, 4.0]),
        )


def test_least_squares_baseline_and_gasconcs_in_return_value():
    model_functions = model_functions_harness()
    cids = [1, 2, 3, 4]
    prefix = "dummyPrefix"
    lsq = LinearLeastSquares(model_functions, prefix=prefix)
    baseline_order = 3
    soln, _ = lsq.eval(
        nu_array=np.array([6001.0, 6002.0, 6003.0, 6004.0]),
        y_data=np.array([1.0, 2.0, 3.0, 4.0]),
        baseline_order=baseline_order,
    )
    for i in range(baseline_order):
        assert f"{prefix}_base_{i}" in soln.keys()

    for cid in cids:
        assert f"{prefix}_gasConcs_{cid}" in soln.keys()


def test_least_squares_baseline_and_gasconcs_keys():
    model_functions = model_functions_harness()
    cids = [1, 2, 3, 4]
    prefix = "dummyPrefix"
    lsq = LinearLeastSquares(model_functions, prefix=prefix)
    baseline_order = 3
    result_keys = lsq.get_results_keys(baseline_order=baseline_order)

    for i in range(baseline_order):
        assert f"{prefix}_base_{i}" == result_keys[i]

    offset_for_baseline = 0 if baseline_order is None else baseline_order + 1
    for i_cid, cid in enumerate(cids):
        assert f"{prefix}_gasConcs_{cid}" == result_keys[i_cid + offset_for_baseline]

    assert f"{prefix}_std_res" == result_keys[-1]


def test_least_squares_nu_center_out_of_bounds_raises():
    model_functions = model_functions_harness()

    lsq = LinearLeastSquares(model_functions)
    with raises(ValueError):
        _, _ = lsq.eval(
            nu_array=np.array([6001.0, 6002.0, 6003.0, 6004.0]),
            y_data=np.array([1.0, 2.0, 3.0, 4.0]),
            nu_center=6010.0,
        )
