from spectral_arithmetic.data_models.spectra import SpectrumData, SpectrumMask
from spectral_arithmetic.spectrum_operations import mask_spectrum
import numpy as np
import pytest


def test_spectrum_data_doesnt_mutate():
    """Test that the output of this function is not a mutated version of the input object"""
    np.random.seed(0)
    mask = SpectrumMask(
        **{
            "include": [[6056.39, 6056.64], [6056.9, 6057.3], [6057.59, 6058.0]],
            "exclude": [],
        }
    )
    spectrum = SpectrumData(
        temperature=80.0,
        pressure=140.0,
        nu=np.linspace(6056, 6058, 20),
        npoints=np.linspace(1, 20, 20),
        absorbance=np.random.normal(400, 5, 20),
        timestamp=12345,
    )
    masked_spectrum = mask_spectrum(spectrum, mask)
    assert id(spectrum) != id(masked_spectrum)


def test_mask_spectrum_without_include_doesnt_clobber():
    """ This tests that when a user doesn't provide an "include" section of the
    spectrum mask, the resulting spectrum is not completely masked out."""
    np.random.seed(0)
    mask = SpectrumMask(
        **{
            "include": [],
            "exclude": [[6000, 6001]],  # This exclude directive does nothing; out of bounds
        }
    )
    nu_array_test = np.linspace(6050, 6060, 20)
    spectrum = SpectrumData(
        temperature=80.0,
        pressure=140.0,
        nu=nu_array_test,
        npoints=np.linspace(1, 20, 20),
        absorbance=np.random.normal(400, 5, 20),
        timestamp=12345,
    )
    masked_spectrum = mask_spectrum(spectrum, mask)
    assert sum(masked_spectrum.nu -  nu_array_test) == 0

def test_mask_spectrum_without_include_exclude_doesnt_clobber():
    """ This tests that when a user doesn't provide an "exclude" or an "include" section of the
    spectrum mask, the resulting spectrum is not completely masked out."""
    np.random.seed(0)
    mask = SpectrumMask(
        **{
            "include": [],
            "exclude": [],
        }
    )
    nu_array_test = np.linspace(6050, 6060, 20)
    spectrum = SpectrumData(
        temperature=80.0,
        pressure=140.0,
        nu=nu_array_test,
        npoints=np.linspace(1, 20, 20),
        absorbance=np.random.normal(400, 5, 20),
        timestamp=12345,
    )
    masked_spectrum = mask_spectrum(spectrum, mask)
    assert sum(masked_spectrum.nu -  nu_array_test) == 0


def test_spectrum_data_different_array_lengths_raises():
    """Test that different array lengths in SpectrumData causes a ValueError"""
    with pytest.raises(ValueError):
        SpectrumData(
            temperature=80.0,
            pressure=140.0,
            nu=np.array([1.0, 2.0, 3.0]),  # Array length is 3
            npoints=np.array([1, 2, 3, 4]),  # Array length is 4
            absorbance=np.array([1.0, 2.0, 3.0]),
            timestamp=12345,
        )
