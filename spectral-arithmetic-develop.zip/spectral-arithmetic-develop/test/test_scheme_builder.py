import os
import tempfile

import pytest

from spectral_arithmetic import scheme_builder
from spectral_arithmetic.data_models import scheme_models

FSR = 0.0206
SID = 100

LASER_RANGE = """
[UU]
LOW = 6001
HIGH = 6180
[NN]
LOW = 5837
HIGH = 6000
"""

# BIG3
LINES_SCHEME = """
[CO2_6056]
center_frequency = 6056.50600
points_before = 3
points_after = 3
peak_dwell = 4
sides_dwell = 3
extra1 = 1
[CH4_6057]
center_frequency = 6057.09
points_before = 3
points_after = 3
peak_dwell = 4
sides_dwell = 3
extra1 = 2
[FREQUENCY]
f_master = 6056.50678
"""

OFFSETS = [-3, -2, -1, 0, 1, 2, 3]
DWELLS = [2, 1, 3, 4, 3, 1, 2]

SELECTED_FREQ = """
  -9832 5853.766457  0
  -9793 5854.570655  0
  -9759 5855.271750  0
  -9669 5857.127592  0
   6906 6198.911683  0
   6907 6198.932303  0
   6909 6198.973544  0
"""
ROW_COLS = list(scheme_models.Row.model_fields.keys())


def test_lasers():
    """Test lasers model config parsing and creation"""
    tf = tempfile.NamedTemporaryFile(delete=False, suffix="LaserRange.ini")
    with open(tf.name, "w") as f:
        f.write(LASER_RANGE)

    with pytest.raises(ValueError):
        lasers = scheme_models.VirtualLasers.read_from_ini("foo")

    lasers = scheme_models.VirtualLasers.read_from_ini(tf.name)

    tf.close()
    os.unlink(tf.name)

    assert lasers.lasers[0].name == "UU"
    assert lasers.lasers[0].number == 0
    assert lasers.lasers[0].high == 6180
    assert lasers.lasers[0].low == 6001

    assert lasers.lasers[1].name == "NN"
    assert lasers.lasers[1].number == 1
    assert lasers.lasers[1].high == 6000
    assert lasers.lasers[1].low == 5837

    assert lasers.get_laser(6105) == 0
    assert lasers.get_laser(5850) == 1
    with pytest.raises(ValueError):
        lasers.get_laser(0)


def test_line_subschemes():
    """Test line schemes model parsing and creation"""
    tf = tempfile.NamedTemporaryFile(delete=False, suffix="lines_config.ini")
    with open(tf.name, "w") as f:
        f.write(LINES_SCHEME)

    with pytest.raises(ValueError):
        lines = scheme_models.LineSchemes.read_from_ini("foo")

    lines = scheme_models.LineSchemes.read_from_ini(tf.name)
    tf.close()
    os.unlink(tf.name)

    assert lines.f_master == 6056.50678
    # Not sure this is how mask info should be referenced
    assert lines.bit_mask_info == {1: 6056.506, 2: 6057.09}

    for line in lines.line_scheme_models:
        assert line.offsets_and_dwells == (OFFSETS, DWELLS)


def test_make_subschemes():
    """
    Test we can produce subscheme dataframe from configs
    """
    tf_lines = tempfile.NamedTemporaryFile(delete=False, suffix="LaserRange.ini")
    with open(tf_lines.name, "w") as f:
        f.write(LINES_SCHEME)

    lines = scheme_models.LineSchemes.read_from_ini(tf_lines.name)
    tf_lines.close()
    os.unlink(tf_lines.name)

    tf_lasers = tempfile.NamedTemporaryFile(delete=False, suffix="LaserRange.ini")
    with open(tf_lasers.name, "w") as f:
        f.write(LASER_RANGE)

    lasers = scheme_models.VirtualLasers.read_from_ini(tf_lasers.name)
    tf_lasers.close()
    os.unlink(tf_lasers.name)

    subscheme_df = scheme_builder.make_subschemes(FSR, lines, lasers, SID)

    assert (subscheme_df["subschemeId"] == 100).all()
    masks = subscheme_df["extra1"].unique()
    assert list(masks) == [2, 4]
    masks_decode = [scheme_builder.decode_mask(mask)[0] for mask in masks]
    assert list(subscheme_df.columns) == ROW_COLS
    assert masks_decode == [1, 2]


def test_get_selected_frequencies():
    """
    Test we can generate a selected frequencies frame from file
    """
    tf_freq = tempfile.NamedTemporaryFile(
        delete=False, suffix="selected_frequencies.txt"
    )
    with open(tf_freq.name, "w") as f:
        f.write(SELECTED_FREQ)

    selected_freq_df = scheme_builder.get_selected_frequencies(tf_freq.name, FSR, 100)
    tf_freq.close()
    os.unlink(tf_freq.name)

    assert (selected_freq_df["subschemeId"] == 100).all()
    assert selected_freq_df["setpoint"].is_monotonic_increasing

    assert (selected_freq_df["dwell"] == 1).all()


def test_full_scheme_creation():
    """Test we can generate the full sweep down part of the scheme"""
    tf_lines = tempfile.NamedTemporaryFile(delete=False, suffix="LaserRange.ini")
    with open(tf_lines.name, "w") as f:
        f.write(LINES_SCHEME)

    lines = scheme_models.LineSchemes.read_from_ini(tf_lines.name)
    tf_lines.close()
    os.unlink(tf_lines.name)

    tf_lasers = tempfile.NamedTemporaryFile(delete=False, suffix="LaserRange.ini")
    with open(tf_lasers.name, "w") as f:
        f.write(LASER_RANGE)

    lasers = scheme_models.VirtualLasers.read_from_ini(tf_lasers.name)
    tf_lasers.close()
    os.unlink(tf_lasers.name)

    tf_freq = tempfile.NamedTemporaryFile(
        delete=False, suffix="selected_frequencies.txt"
    )
    with open(tf_freq.name, "w") as f:
        f.write(SELECTED_FREQ)

    selected_freq_df = scheme_builder.get_selected_frequencies(tf_freq.name, FSR, 100)
    tf_freq.close()
    os.unlink(tf_freq.name)

    subscheme_df = scheme_builder.make_subschemes(FSR, lines, lasers, SID)

    sweep_down_df = scheme_builder.combine_sweep_down(
        selected_freq_df, subscheme_df, lasers
    )

    # Final sweep down needs to be decreasing in wavenumber
    assert sweep_down_df["setpoint"].is_monotonic_decreasing
    laser1 = sweep_down_df[sweep_down_df["setpoint"] < 6000]

    # check lasers and ignore row assigned properly
    assert (laser1["virtualLaser"] == 1).all()
    assert laser1.iloc[0]["dwell"] == 5
    assert laser1.iloc[0]["subschemeId"] == 16484

    laser2 = sweep_down_df[sweep_down_df["setpoint"] > 6000]

    # check lasers and ignore row assigned properly
    assert (laser2["virtualLaser"] == 0).all()
    assert laser2.iloc[-1]["dwell"] == 5
    assert laser2.iloc[-1]["subschemeId"] == 16484
