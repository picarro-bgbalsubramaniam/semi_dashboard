from spectral_arithmetic import nu_operations as no
import numpy as np
import pytest

# Test values based on 6379-NUV1031_broadband_20211009_000003_0.h5

# Calculated from gridify, put into logs
NU_SHIFT = 0.0001359153048599909
NU_SQUISH = 2.7997618334296556e-06
# Center of nu range from combo logs
NU_CENTER = 6056.5

# After Transoform
f0_PRIME = 6056.5070338768255
FSR_PRIME = 0.02061827672610263

# f0
MASTER_FREQ = 6056.506897942208

# Expected FSR for all calculations
FSR_CALC = 0.020618219

# From nu_array.npy
NU_LOW_1 = 6070.17677714
NU_HI_1 = 6073.80558368
NU_LOW_2 = 5857.35552062
NU_HI_2 = 5860.32454416

SPARSE_ARR = np.array([NU_LOW_2, NU_HI_2, NU_LOW_1, NU_HI_1])

# For single mode, two fsrs
TWO_MODE_ARR = np.array([0.0206, 0.0412, 0.0612, 0.0812])

# For multi mode no fsr
MULTI_NO_FSR = np.array([0.0206, 0.103, 0.2, 0.4])

# Bad single mode FSR spacing map
BAD_ARR = np.array([0.0206, 0.0412, 1])

# BAD MODE CALC VALS
BAD_MODE_FSR = 0.020618219
BAD_MODE_F0 = 6056.496897942207

test_array = np.load("./test/test_array.npy")


def test_calc_fsr_single_mode():
    fsr = no.calc_fsr(test_array)
    assert fsr == FSR_CALC


def test_calc_fsr_no_single_mode():
    fsr = no.calc_fsr(SPARSE_ARR)
    assert fsr == FSR_CALC


def test_calc_fsrs():
    fsr_values_1 = no.nu_operations._calc_fsrs(NU_LOW_1, NU_HI_1)
    assert len(fsr_values_1) == 35
    assert FSR_CALC in fsr_values_1


def test_get_fsr_intersect():
    fsr = no.nu_operations._get_fsr_intersect(test_array)[0]
    assert fsr == FSR_CALC


def test_error_two_fsr_single_mode():
    with pytest.raises(Exception) as e:
        no.calc_fsr(TWO_MODE_ARR)
    assert str(e.value) == no.MULTI_FSR_SINGLE_MODE


def test_error_no_fsr_multi_mode():
    with pytest.raises(Exception) as e:
        no.calc_fsr(MULTI_NO_FSR)
    assert str(e.value) == no.NO_FSR


def test_create_mode_index():
    m_idx = no.create_mode_index(test_array, FSR_CALC, MASTER_FREQ)
    assert len(m_idx) == len(test_array)


def test_create_mode_index_raises():
    with pytest.raises(Exception) as e:
        no.create_mode_index(test_array, FSR_CALC, MASTER_FREQ - 0.01)
    assert str(e.value) == no.bad_mode_err_str(BAD_MODE_FSR, BAD_MODE_F0)


def test_nu_transform():
    nus, new_fsr, new_f0 = no.nu_transform(
        test_array, NU_SQUISH, NU_SHIFT, MASTER_FREQ, NU_CENTER, FSR_CALC
    )
    assert new_f0 == f0_PRIME
    assert new_fsr == FSR_PRIME
    # Check that the new nu values, fsr, and master freq still integers
    m_idx = (nus - new_f0) / new_fsr
    assert any(np.abs(m_idx - np.round(m_idx)) > 1e-6) == False


def test_chained_operation():
    """Test that you can chain these two operations and that they result in an array of int."""
    mode_indices = no.create_mode_index(
        *no.nu_transform(
            test_array, NU_SQUISH, NU_SHIFT, MASTER_FREQ, NU_CENTER, FSR_CALC
        )
    )
    assert sum(np.mod(mode_indices, 1)) == 0
