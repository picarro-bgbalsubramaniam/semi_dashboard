from unittest import mock

import numpy as np
import pytest
from spectral_arithmetic.data_models.constructors import create_reference_frequency
from spectral_arithmetic.data_models.spectra import SchemeInfo
from spectral_arithmetic.nu_operations.gridify import (
    TRANSFORM_METHOD,
    Gridify,
    compute_shift_and_squish,
    determine_f0,
    update_freq_param,
)

USE_ONLY_MASTER = TRANSFORM_METHOD.USE_ONLY_MASTER
USE_ALL_DATA = TRANSFORM_METHOD.USE_ALL_DATA
USE_SPECTRUM_CONTAINING_MASTER = TRANSFORM_METHOD.USE_SPECTRUM_CONTAINING_MASTER


def nu_array_harness(nu_min=6050.0, nu_max=6060.0, stepsize=0.02):
    num_steps = (
        int((nu_max - nu_min) / stepsize) + 1
    )  # Stepsize to num_steps approximately correct
    return np.linspace(nu_min, nu_max, num_steps, endpoint=True)


def test_process_spectrum_single_point():
    """Run through the gridify function ``process_spectrum``, taking the code path that
    causes only the "Single point" calculation"""
    # Create a nu array with some noise on the "phase" of the wavenumbers and FSR
    nu_array = nu_array_harness(
        nu_min=6050.1234567, nu_max=6060.456789, stepsize=0.020610365
    )
    fsr = 0.0206
    master_frequency = 6056.50678
    gridify = Gridify()
    scheme_info = SchemeInfo(fsr=fsr, master_frequency=master_frequency)
    grid = gridify.process_spectrum(nu_array, scheme_info)

    # This is approximately correct because "stepsize" and "fsr" were "close"
    assert np.allclose(np.diff(grid.nu_grid), fsr)

    # Create an array where the wavenumbers line up with the decimal numbers system
    nu_array = nu_array_harness(nu_min=6050.0, nu_max=6060.0, stepsize=0.020)
    fsr = 0.020
    master_frequency = (
        6050.099  # By construction, this master frequency is not in the nu_array,
    )
    # so we expect to see an f0_shift of about .001.
    scheme_info = SchemeInfo(fsr=fsr, master_frequency=master_frequency)
    grid = gridify.process_spectrum(nu_array, scheme_info)
    assert np.isclose(grid.f0_shift, 0.001)
    assert np.isclose(grid.f0, 6050.1)


def test_process_spectrum_group_based():
    """Run through the gridify function ``process_spectrum``, taking the code path that
    causes only the "Group based" calculation"""
    # Create a nu array with some noise on the "phase" of the wavenumbers and FSR
    nu_array = nu_array_harness(
        nu_min=6050.1234567, nu_max=6060.456789, stepsize=0.020610365
    )
    fsr = 0.0206
    master_frequency = 6056.50678
    gridify = Gridify(transform_method=USE_SPECTRUM_CONTAINING_MASTER)
    scheme_info = SchemeInfo(fsr=fsr, master_frequency=master_frequency)
    grid = gridify.process_spectrum(nu_array, scheme_info)

    # This is approximately correct because "stepsize" and "fsr" were "close"
    assert np.allclose(np.diff(grid.nu_grid), fsr)

    nu_array = nu_array_harness(nu_min=6050.0, nu_max=6060.0, stepsize=0.020)
    fsr = 0.020
    master_frequency = (
        6050.099  # By construction, this master frequency is not in the nu_array,
    )
    # so we expect to see an f0_shift of about .001.
    scheme_info = SchemeInfo(fsr=fsr, master_frequency=master_frequency)
    grid = gridify.process_spectrum(nu_array, scheme_info)
    assert np.isclose(grid.f0_shift, 0.001)
    assert np.isclose(grid.f0, 6050.1)


def test_process_spectrum_no_master():
    """Run through the gridify function ``process_spectrum``, taking the code path that
    causes only the "Group based" calculation. Use a nu array that does not contain the
    master frequency"""
    nu_array = nu_array_harness(nu_min=6050.0, nu_max=6060.0, stepsize=0.020)
    fsr = 0.020
    master_frequency = 4000.0  # This frequency is not contained in the nu array

    gridify = Gridify(transform_method=USE_SPECTRUM_CONTAINING_MASTER)
    scheme_info = SchemeInfo(fsr=fsr, master_frequency=master_frequency)
    grid = gridify.process_spectrum(nu_array, scheme_info)

    # No operations on array:
    assert grid.f0 is None
    assert grid.f0_shift is None
    assert sum(grid.nu_grid - nu_array) == 0.0


@mock.patch("spectral_arithmetic.nu_operations.gridify.determine_f0", return_value=None)
def test_process_spectrum_returns_none(mock_f0_func):
    """When there is no fsr/master frequency set, then Gridify.process_spectrum should
    return None where appropriate."""
    gridify = Gridify()
    synthetic_nu = nu_array_harness()
    grid = gridify.process_spectrum(
        nu_array=synthetic_nu,
        scheme_info=SchemeInfo(fsr=0.0205, master_frequency=6055.0),
    )
    assert grid.f0 is None
    assert grid.f0_shift is None


@mock.patch("spectral_arithmetic.nu_operations.gridify.group_based_f0")
@mock.patch("spectral_arithmetic.nu_operations.gridify.single_point_f0")
@mock.patch(
    "spectral_arithmetic.nu_operations.gridify.master_in_spectrum",
    side_effect=[False, True, False, True, False, True],
)
def test_determine_f0(
    mock_master_in_spectrum, mock_single_point_f0, mock_group_based_f0
):
    """Test the behavior of ``determine_f0`` when the master frequency is not present in the
    nu array, or if the master frequency is not close enough to any point in the array.
    Iterate through the different "transform methods" """
    synthetic_nu = nu_array_harness
    fsr = 0.02
    master_freq = 6055.05

    # In this call, we have mocked our data such that the master frequency is not in the nu array
    f0 = determine_f0(synthetic_nu, fsr, master_freq, USE_ONLY_MASTER)
    assert f0 is None
    assert not mock_single_point_f0.called

    # In this call, the master frequency IS in the nu array
    f0 = determine_f0(synthetic_nu, fsr, master_freq, USE_ONLY_MASTER)
    assert mock_single_point_f0.called

    # In this call, we have mocked our data such that the master frequency is not in the nu array
    f0 = determine_f0(synthetic_nu, fsr, master_freq, USE_SPECTRUM_CONTAINING_MASTER)
    assert f0 is None
    assert not mock_group_based_f0.called

    # In this call, the master frequency IS in the nu array
    f0 = determine_f0(synthetic_nu, fsr, master_freq, USE_SPECTRUM_CONTAINING_MASTER)
    assert mock_group_based_f0.called

    # Reset the mock since we will use it again in the same manner here:
    mock_group_based_f0.reset_mock()

    # In this call, we have mocked our data such that the master frequency is not in the nu array
    f0 = determine_f0(synthetic_nu, fsr, master_freq, USE_ALL_DATA)
    assert f0 is not None
    assert mock_group_based_f0.call_count == 1

    # In this call, the master frequency IS in the nu array
    f0 = determine_f0(synthetic_nu, fsr, master_freq, USE_ALL_DATA)
    assert mock_group_based_f0.call_count == 2


def test_shift_and_squish_bad_value():
    """"""
    freq_refs = {
        "model_A": {962: 0.0003},
        "model_B": {962: 0.0003},
    }
    model_params = {
        "model_A": {"nuc": 6059.9, "n0": 0.0},
        "model_B": {"nuc": 6060.1, "n0": 0.0},
    }
    references = create_reference_frequency(
        frequency_reference=freq_refs, model_params=model_params
    )
    with pytest.raises(ValueError):
        # We've constructed n0's that are uniquely zero, which is not allow
        n0, n1 = compute_shift_and_squish(nuc=6060.0, frequency_references=references)


def test_shift_and_squish():
    """"""

    def shift_and_squish_harness():
        freq_refs = {
            "model_A": {962: 0.0003},
            "model_B": {962: 0.0003},
        }
        model_params = {
            "model_A": {"nuc": 6059.9, "n0": 0.0},
            "model_B": {"nuc": 6060.1, "n0": 0.2},
        }
        return freq_refs, model_params

    # First test the case where both references lines are available
    freq_refs, model_params = shift_and_squish_harness()
    references = create_reference_frequency(
        frequency_reference=freq_refs, model_params=model_params
    )
    n0, n1 = compute_shift_and_squish(nuc=6060.0, frequency_references=references)
    # Do some rounding here because np.polyval introduces error
    assert all(np.around([n0, n1], decimals=9) == np.array([0.1, 1.0]))
    assert n0 != 0 and n1 != 0

    # Next, test the case where only one reference line is available
    freq_refs, model_params = shift_and_squish_harness()
    freq_refs.pop("model_A")
    model_params.pop("model_A")
    references = create_reference_frequency(
        frequency_reference=freq_refs, model_params=model_params
    )
    n0, n1 = compute_shift_and_squish(nuc=6060.0, frequency_references=references)
    assert n0 == model_params["model_B"]["n0"] and n1 == 0

    # Lastly, test the case where no reference lines are available
    freq_refs, model_params = {}, {}
    references = create_reference_frequency(
        frequency_reference=freq_refs, model_params=model_params
    )
    n0, n1 = compute_shift_and_squish(nuc=6060.0, frequency_references=references)
    assert n0 == 0 and n1 == 0


def test_frequency_reference_create_without_nuc():
    """ Let users create a frequency reference without an nuc or an n0 to support the case
    where complete model information is not yet available."""
    freq_refs = {
        "model_A": {962: 0.0003},
        "model_B": {962: 0.0003},
    }
    model_params = {
        "model_A": {"nuc": None, "n0": None},
        "model_B": {"nuc": None, "n0": None},
    }
    references = create_reference_frequency(
        frequency_reference=freq_refs, model_params=model_params
    )
    for k in references:
        assert references[k].nuc is None
        assert references[k].n0 is None


def test_update_freq_param():
    """here we test update_freq_param based on both input data params: smooth_n and target_n
    and fitter params: filter_const, max_n_range, max_n_incr"""
    FILTER_CONST = 0.5
    MAX_RANGE = 10.0
    MAX_INCR = 2.0

    # can be any value within +/- MAX_RANGE
    nonzero_value = 1.0

    # test if our smooth_n is zero, we return target_n value if within MAX_RANGE of zero
    smooth_n = 0.0
    target_n = nonzero_value
    new_n = update_freq_param(smooth_n, target_n, FILTER_CONST, MAX_RANGE, MAX_INCR)
    assert new_n == target_n

    # test that smooth_n is returned if absolute value of target_n exceeds MAX_RANGE
    smooth_n = nonzero_value
    target_n = MAX_RANGE + 1
    new_n = update_freq_param(smooth_n, target_n, FILTER_CONST, MAX_RANGE, MAX_INCR)
    assert new_n == smooth_n

    smooth_n = nonzero_value
    target_n = -(MAX_RANGE + 1)
    new_n = update_freq_param(smooth_n, target_n, FILTER_CONST, MAX_RANGE, MAX_INCR)
    assert new_n == smooth_n

    # test that we return smooth_n +/- MAX_INCR if the "full increment" is within MAX_RANGE but
    # exceeds (smooth_n +/- MAX_INCR)
    # (the full increment represents the value obtained by exponentially smoothening smooth_n and target_n)
    # full_incr = (1 - filter_const) * smooth_n + filter_const * target_n
    smooth_n = nonzero_value
    target_n = smooth_n + (MAX_INCR / FILTER_CONST)
    new_n = update_freq_param(smooth_n, target_n, FILTER_CONST, MAX_RANGE, MAX_INCR)
    assert new_n == smooth_n + MAX_INCR

    smooth_n = nonzero_value
    target_n = smooth_n - (MAX_INCR / FILTER_CONST)
    new_n = update_freq_param(smooth_n, target_n, FILTER_CONST, MAX_RANGE, MAX_INCR)
    assert new_n == smooth_n - MAX_INCR

    # this occurs for target_n values that range from smooth_n +/- MAX_INCR/FILTER_CONST to +/- MAX_RANGE
    smooth_n = nonzero_value
    target_n = MAX_RANGE
    new_n = update_freq_param(smooth_n, target_n, FILTER_CONST, MAX_RANGE, MAX_INCR)
    assert new_n == smooth_n + MAX_INCR

    smooth_n = nonzero_value
    target_n = -MAX_RANGE
    new_n = update_freq_param(smooth_n, target_n, FILTER_CONST, MAX_RANGE, MAX_INCR)
    assert new_n == smooth_n - MAX_INCR

    # test that full_incr is returned when none of the above are satisfied
    # this occurs for target_n values that are less than smooth_n + MAX_INCR/FILTER_CONST
    smooth_n = nonzero_value
    target_n = smooth_n + (MAX_INCR / FILTER_CONST) - 0.1
    new_n = update_freq_param(smooth_n, target_n, FILTER_CONST, MAX_RANGE, MAX_INCR)
    full_incr = (1 - FILTER_CONST) * smooth_n + FILTER_CONST * target_n
    assert new_n == full_incr

    smooth_n = nonzero_value
    target_n = smooth_n - ((MAX_INCR / FILTER_CONST) - 0.1)
    new_n = update_freq_param(smooth_n, target_n, FILTER_CONST, MAX_RANGE, MAX_INCR)
    full_incr = (1 - FILTER_CONST) * smooth_n + FILTER_CONST * target_n
    assert new_n == full_incr
