import numpy as np
from spectral_arithmetic import allan_deviation as ad


# Can't test output with random gauss
FAKE_SAMPLE = np.arange(0, 10, 0.01)
FAKE_SIGNAL = np.sin(FAKE_SAMPLE)

RESULTS = (
    2.6148382023242577e-05,
    0.00010458921750502087, 
    0.0004182879166471913,
    0.0016663275708213492,
    0.0066475186268105686,
    0.025649731633560345,
    0.08993688524786535,
    0.3444851316139133,
    0.7132123045119504,
    0
)

def test_allan_var():
    # Verify output doesn't change for defined signal
    av = ad.AllanVar(10)
    for val in FAKE_SIGNAL:
        av.process_dataum(val)
    (counter, allan_vars) = av.get_results()
    assert counter == 1000
    assert np.allclose(allan_vars, RESULTS) == True
