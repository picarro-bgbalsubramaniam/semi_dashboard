from typing import Optional, Tuple, List

import numpy as np
from spectral_arithmetic.data_models.least_squares import RegressionStatistic
from spectral_arithmetic.data_models.model_function import ModelFunctions
from spectral_arithmetic.data_models.base import Array, ArrayFloat


def least_squares(
    A_matrix: ArrayFloat,
    y_data: ArrayFloat,
    y_err: Optional[ArrayFloat] = None,
) -> Tuple[Array, RegressionStatistic]:
    """
    Perform an OLS fit on a design matrix and a dataset. In equation form, this is normally
    seen as ``Ax = y``. Here ``A`` is called a "design matrix", ``y`` is our "data vector",
    and we are attempting to solve our equation by arriving at an estimate for ``x`` under
    the L2 norm:

    .. math::
        \hat{\mathbf{y}} = \mathrm{min}(\mathbf{y}) \, ||\mathbf{y} - \mathbf{Ax}||_2

    The return type is a tuple. The first item is the ``y`` solution to that minimizes the error
    ``||y - Ax||`` as mentioned above. The second item is a
    :class:`RegressionStatistic <spectral_arithmetic.data_models.least_squares.RegressionStatistic>` object.

    Arguments:
        A_matrix (np.ndarray): Design matrix of shape (N, M)
        y_data (np.ndarray): Array of data to be fit, of shape (N)
        y_err (np.ndarray): Array of error estimates for data (proportional to ``sqrt(npoints))``

    Returns:
        solution (np.ndarray), statistics (RegressionStatistic)

    >>> from spectral_arithmetic.utils import spectrum_simulator
    >>> np.random.seed(1)
    >>> nu = np.linspace(0, 10, 10)  # Synthetic Nu array
    >>> line_args = [[(0.1, 1, 0.3)], [(0.3, 1.3, 1)], [(0.1, 1.5, 1)]]  # Add three model functions
    >>> design, spectrum, noise = spectrum_simulator(nu, line_args, concentrations=(.1, .2, .3))
    >>> spectrum *= np.random.normal(1, .001, spectrum.size)  # Add noise to the simulated spectrum
    >>> design = np.vstack((np.ones(nu.size), design.T)).T  # Augment matrix to include baseline offset
    >>> solution, statistics = least_squares(design, spectrum)
    >>> np.around(solution, decimals=4)
    array([-0.    ,  0.1085,  0.1917,  0.3064])
    """
    # Alter the design matrix and the data if needed, making a copy to prevent mutating outer scope
    y_data_weighted = y_data.copy()
    A_matrix_weighted = A_matrix.copy()

    if y_err is None:
        y_err = np.ones(y_data.size)

    y_data_weighted /= y_err
    A_matrix_weighted /= y_err[:, np.newaxis]

    solution, statistics = _linear_least_squares(
        A_matrix, A_matrix_weighted, y_data, y_data_weighted
    )
    return solution, statistics


def _linear_least_squares(
    A_matrix_original,
    A_matrix_weighted,
    y_data_original,
    y_data_weighted,
):
    # Since numpy and scipy don't provide the error statistics we want, we solve
    # the linear least squares problem with SVD.
    U, S, V = np.linalg.svd(A_matrix_weighted, full_matrices=False)
    solution = V.T @ np.diag(1 / S) @ U.T @ y_data_weighted

    # Do the sum of squares
    model_estimate = A_matrix_original @ solution
    residual_error = y_data_original - model_estimate
    total_variation = y_data_original - np.mean(y_data_original)
    ss_res = np.sum((np.array(residual_error)) ** 2)
    ss_tot = np.sum(total_variation ** 2)

    # Calculate the R scores
    m, n = A_matrix_weighted.shape
    adj = (m - 1) / (m - n - 1)
    R2 = 1 - (ss_res / ss_tot)
    R2_adj = 1 - (1 - R2) * adj

    # Calculate the standard deviation
    std_dev = V.T @ np.diag(1 / S ** 2) @ V
    std_dev = np.sqrt(np.diag(std_dev))

    statistics = RegressionStatistic(
        lsq_res=ss_res,
        R2=R2,
        R2_adj=R2_adj,
        model_estimate=model_estimate,
        residual_error=residual_error,
        std_dev=std_dev,
    )
    return solution, statistics


def design_matrix(nu_array, model_functions, nu_center, baseline_order, sort_cols=True):
    """Create a design matrix, or the ``A`` matrix in the ``Ax = b`` linear regression equation."""
    if sort_cols:
        cid_list = sorted(model_functions.keys())
    else:
        # Python's dictionaries used to be unordered but now we can count on them being ordered
        # i.e., they preserve insertion order. This is true as of python 3.7.
        cid_list = model_functions.keys()
    model_columns = [model_functions[cid](nu_array) for cid in cid_list]
    if baseline_order is not None:
        baseline_columns = [(nu_array - nu_center) ** power for power in range(baseline_order + 1)]
    else:
        baseline_columns = []
    design_matrix = np.vstack(baseline_columns + model_columns)
    return design_matrix.T


class LinearLeastSquares:
    def __init__(
        self,
        model_functions: ModelFunctions,
        prefix: str = "lsq",
    ):
        self.cid_list = model_functions.cids
        self.nu_min = model_functions.nu_min
        self.nu_max = model_functions.nu_max
        self.prefix = prefix
        self.model_functions = model_functions

    def get_results_keys(
        self,
        baseline_order: Optional[int] = 1,
    ) -> List[str]:
        """
        Returns a list of keys that will be used to store
        the results of the linear least squares fit
        (in the `.eval` method).

        Args:
            baseline_order (int|None):
                Order of baseline polynomial to be included in the model.

        Returns:
            List[str]:
                List of keys that will be used to store
                the results of the linear least squares fit.
        """
        baseline_names = (
            [str(x) for x in range(baseline_order + 1)]
            if baseline_order is not None
            else []
        )
        keys = [f"{self.prefix}_base_{k}" for k in baseline_names]
        keys.extend([f"{self.prefix}_gasConcs_{k}" for k in self.cid_list])
        keys.extend([f"{self.prefix}_std_res"])
        return keys

    def eval(
        self,
        nu_array: ArrayFloat,
        y_data: ArrayFloat,
        y_err: Optional[ArrayFloat] = None,
        nu_center: Optional[float] = None,
        baseline_order: Optional[int] = 1,
    ):
        """
        Evaluates a linear least squares fit for a specific set of wavenumbers (``nu_array``),
        and a loss dataset from the spectrometer (``y_data``).

        If users specify a ``baseline_order``, the algorithm will include a polynomial baseline
        offset in the model and will return the coefficients of the polynomial. If
        ``baseline_order`` is ``None``, then the baseline polynomial is not fit. For the baseline
        polynomial fit, the algorithm will center the ``nu_array`` around the origin by subtracting
        the mean of the ``nu_array``. If this is not desirable, users can specify a ``nu_center``
        value that will be used to center the ``nu_array``.

        To prevent adding the baseline to the model, set ``baseline_order=None``.

        Users can specify a certain error array (``y_err``) that represents the standard error
        of the loss, which is given by the loss standard deviation divided by the square root of
        weights:

        .. math::
            y_{\mathrm{err}} = \dfrac{s_{\mathrm{loss}}}{\sqrt{y_\mathrm{w}}}

        where :math:`y_w` is the "weights" array for the loss, and :math:`s_{\mathrm{loss}}` is
        the standard deviation of the loss array (``y_data`` parameter).

        Args:
            nu_array (np.array): Array of wavenumbers
            y_data (np.array): Array of loss data from the spectrometer
            y_err (np.array): Standard error of the loss
            nu_center (float): Wavenumber to be used to center the data
            baseline_order (int|None): Order of baseline polynomial to be included in the model

        Returns:
            results (dict), statistics (:py:mod:`~spectral_arithmetic.data_models.least_squares.RegressionStatistic`)

        """
        if nu_array.min() < self.nu_min or nu_array.max() > self.nu_max:
            raise ValueError(
                f"Nu array is out of bounds with min {nu_array.min()} < {self.nu_min} or {nu_array.max()} > {self.nu_max} "
            )
        if nu_center is None:
            nu_center = nu_array.mean()

        if nu_center < nu_array.min() or nu_center > nu_array.max():
            raise ValueError(
                f"Nu center is out of bounds with min {nu_array.min()} < {self.nu_min} or {nu_array.max()} > {self.nu_max} "
            )

        if y_err is None:
            y_err = np.ones(nu_array.shape)
        A_matrix = design_matrix(
            nu_array, self.model_functions.funcs, nu_center, baseline_order
        )
        solution, statistics = least_squares(A_matrix, y_data, y_err)

        result_keys = self.get_results_keys(baseline_order=baseline_order)
        solution_export = np.append(solution, statistics.lsq_res)
        results = {key: value for key, value in zip(result_keys, solution_export)}
        return results, statistics
