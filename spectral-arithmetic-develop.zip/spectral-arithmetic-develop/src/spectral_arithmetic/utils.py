import math
import numpy as np
from typing import List, Union, Tuple, Optional
from spectral_arithmetic.data_models.base import Array


def weighted_ave_and_std(array: Union[Array, List], weights: List[int]):
    """
    Convenience function to calculate weighted average and std
    """
    average = np.average(array, weights=weights)
    std = math.sqrt(np.average((array - average) ** 2, weights=weights))

    return average, std


def select_n_points(n_points1: int, n_points2: int):
    """
    Convenience function for finding the minimum number
    of n points used during arithmetic addition/subtraction
    of two ModeBins.  One is lowest possible value
    """
    return max([min([n_points1, n_points2]), 1])


def spectrum_gen(
    x: np.ndarray,
    center: float,
    width: float = 0.01,
    height: float = 1.0,
    noise_width: float = 0,
) -> np.ndarray:
    """
    Generates a Gaussian function on an array (``x``). Center, width, and height parameters.
    Can be used in conjunction with  :py:mod:`spectral_arithmetic.utils.spectrum_simulator`
    function to create a design matrix and simulated spectrum for OLS regression
    """
    if noise_width != 0:
        noise = np.random.normal(loc=0, scale=noise_width, size=x.size)
    else:
        noise = np.zeros(x.size)
    synthetic_spectrum = height * (np.exp(-((x - center) ** 2) / (2 * width ** 2)))
    return synthetic_spectrum + noise


def spectrum_simulator(
    X: np.ndarray,
    line_args: List[List[Tuple[float]]],
    concentrations: Optional[List[float]] = None,
):
    """
    Create a design matrix, a spectrum, and (optionally) concentrations of model functions.

    Users can optionally pass in a set of concentrations that can be used to scale the model
    functions up or down. If not, this will be done according to :py:mod:`np.random.uniform`.

    Arguments:
        X (np.ndarray): Array of "nu" or "wavenumbers"
        line_args (tuple): List of list of tuples with arguments to :py:mod:`spectral_arithmetic.utils.spectrum_gen`

    Returns:
        design_matrix (np.ndarray):
        spectrum (np.ndarray)
        concentrations (np.ndarray)

    >>> from spectral_arithmetic.utils import spectrum_simulator
    >>> np.random.seed(1)
    >>> line_args = [[(0.1, 1, 0.3)], [(0.3, 1.3, 1)], [(0.1, 1.5, 1)]]
    >>> nu = np.linspace(-10, 10, 10)
    >>> design, spectrum, noise = spectrum_simulator(nu, line_args)
    >>> design
    array([[2.11802560e-23, 2.33641415e-14, 1.42898163e-10],
           [1.00253034e-14, 4.13044854e-09, 1.02484012e-06],
           [3.40094597e-08, 3.93018133e-05, 8.18656182e-04],
           [8.26871138e-04, 2.01277831e-02, 7.28388237e-02],
           [1.44082696e-01, 5.54813835e-01, 7.21838853e-01],
           [1.79937512e-01, 8.23126540e-01, 7.96771032e-01],
           [1.61052506e-03, 6.57285286e-02, 9.79586453e-02],
           [1.03311616e-07, 2.82493981e-04, 1.34142982e-03],
           [4.74970588e-14, 6.53480258e-08, 2.04601632e-06],
           [1.56502100e-22, 8.13623956e-13, 3.47589128e-10]])
    """
    spectrum = np.zeros(X.shape)
    design_matrix = np.zeros((len(X), len(line_args)))
    if concentrations is None:
        concentrations = np.random.uniform(0, 1, len(line_args))
    elif len(concentrations) != len(line_args):
        raise ValueError(
            f"line_args and concentrations must be same length. "
            f"len(line_args): {len(line_args)}; len(concentrations): {len(concentrations)}"
        )
    for nl, line in enumerate(line_args):
        spec = np.zeros(X.shape)
        for args in line:
            spec += spectrum_gen(X, *args)
        design_matrix[:, nl] = spec.T
        spectrum += spec * concentrations[nl]
    return design_matrix, spectrum, concentrations
