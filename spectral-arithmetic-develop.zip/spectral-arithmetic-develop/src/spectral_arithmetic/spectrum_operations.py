from spectral_arithmetic.data_models.spectra import SpectrumData, SpectrumMask
from spectral_arithmetic.data_models.crosstalk_args import Big3CorrectionTerms
from spectral_arithmetic.nu_operations import nu_operations as no
from spectral_arithmetic.logger import get_logger
from spectral_arithmetic.data_models.base import ArrayInt, ArrayFloat, ArrayBool
from typing import Tuple, Optional
import numpy as np


LOGGER = get_logger(__name__)

ABSORBANCE_KEY = "absorbance"
NPOINTS_KEY = "npoints"
NU_KEY = "nu"
ARRAY_KEYS = [ABSORBANCE_KEY, NPOINTS_KEY, NU_KEY]


def mask_spectrum(
    spectrum: SpectrumData,
    mask_range: Optional[SpectrumMask] = None,
    mask_indices: Optional[ArrayInt] = None,
) -> SpectrumData:
    """
    Strips data from the flannel which will not be used by a fitter:
        - Replace "nu" with "nu_grid"
        - Mask arrays by "cutter" mask,
        - Add scalars: temperature, pressure, timestamp.

    >>> import numpy as np
    >>> from spectral_arithmetic.spectrum_operations import mask_spectrum
    >>> from spectral_arithmetic.data_models.spectra import SpectrumData, SpectrumMask
    >>> np.random.seed(0)
    >>> mask = SpectrumMask(
    ...     **{
    ...         "include": [[6056.39, 6056.64], [6056.9, 6057.3], [6057.59, 6058.0]],
    ...         "exclude": [],
    ...     }
    ... )
    >>> spectrum_data = SpectrumData(
    ...     temperature=80.0,
    ...     pressure=140.0,
    ...     nu=np.linspace(6056, 6058, 20),
    ...     npoints=np.linspace(1, 20, 20),
    ...     absorbance=np.random.normal(400, 5, 20),
    ...     timestamp=12345,
    ... )
    >>> mask_spectrum(spectrum_data, mask)
    SpectrumData(temperature=80.0, pressure=140.0, timestamp=12345.0, absorbance=array([409.33778995, 395.1136106 , 404.75044209, 402.05299251,
           400.72021786, 407.27136753, 403.80518863, 407.47039537,
           398.97420868, 401.56533851]), npoints=array([ 5.,  6.,  7., 10., 11., 12., 13., 17., 18., 19.]), nu=array([6056.42105263, 6056.52631579, 6056.63157895, 6056.94736842,
           6057.05263158, 6057.15789474, 6057.26315789, 6057.68421053,
           6057.78947368, 6057.89473684]))
    """
    if mask_range is None and mask_indices is None:
        raise ValueError(
            "Please provide at least one of mask_range or mask_indices to "
            "mask_spectrum function"
        )
    if mask_range:
        mask_indices = frequency_mask(spectrum.nu, mask_range)

    # Unpack the incoming SpectrumData object, making a deep copy
    spectrum = {k: v for k, v in spectrum.model_dump().items()}

    # Apply the mask
    for key in ARRAY_KEYS:
        spectrum[key] = spectrum[key][mask_indices]

    # Create a new SpectrumData object with the masked arrays
    return SpectrumData.model_validate(spectrum)


def frequency_mask(nu: ArrayFloat, mask: SpectrumMask) -> ArrayBool:
    """
    Apply a mask to an array of wavenumbers with "include" and "exclude" ranges.

    Argumements:
        nu (ndarray[float]): Array of wavenumbers
        mask (SpectrumMask): Mask object

    Returns:
        indices (ndarray[bool]): Boolean array to be used as a mask

    >>> import numpy as np
    >>> from spectral_arithmetic.data_models.spectra import SpectrumMask
    >>> from spectral_arithmetic.spectrum_operations import frequency_mask
    >>> nu = np.r_[6056.2:6058.2:.1]
    >>> mask = SpectrumMask(**{'include': [[6056.39, 6056.64],
    ...   [6056.9, 6057.3],
    ...   [6057.59, 6058.0]],
    ...  'exclude': []})
    >>> frequency_mask(nu, mask)
    array([False, False,  True,  True,  True, False, False,  True,  True,
            True,  True, False, False, False,  True,  True,  True,  True,
           False, False])
    """
    exclude = mask.exclude
    include = mask.include
    falsey = False if mask.include else True
    for incl in include:
        falsey |= (nu >= incl[0]) & (nu < incl[1])

    truthy = True
    for excl in exclude:
        truthy &= (nu < excl[0]) | (nu >= excl[1])

    return np.ones(len(nu), dtype=bool) & falsey & truthy


def big3_correction(
    correction_terms: Big3CorrectionTerms, CO2: float, CH4: float, H2O: float
):
    """
    Apply the big 3 correction, based on correction vectors and
    concentrations of big3

    Argumements:
        correction_terms (Big3CorrectionTerms): Correction factors with offset, Big3 linear and bilinear terms
        CO2 (float): CO2 concentration
        CH4 (float): CH4 concentration
        H2O (float): H2O concentration

    Returns:
        corrections (ndarray[float]): Corrections to apply to spectral data partial fit

    >>> from spectral_arithmetic.spectrum_operations import big3_correction
    >>> from spectral_arithmetic.data_models.crosstalk_args import Big3CorrectionTerms
    >>> import numpy as np
    >>> H2O = 0.1
    >>> CH4 = 0.1
    >>> CO2 = 0.1
    >>> offset = np.array([-0.1, 0, 0.1])
    >>> corr = np.array([-1, 0, 1])
    >>> correction_terms = Big3CorrectionTerms(offset=offset, CO2=corr, CH4=corr, H2O=corr, CO2_H2O=corr, CH4_H2O=corr, H2O_H2O=corr)
    >>> big3_correction(correction_terms, CO2, CH4, H2O)
    array([-0.43,  0.  ,  0.43])
    """
    correction = sum(
        [
            correction_terms.offset,
            correction_terms.CO2 * CO2,
            correction_terms.CH4 * CH4,
            correction_terms.H2O * H2O,
            correction_terms.CO2_H2O * CO2 * H2O,
            correction_terms.CH4_H2O * CH4 * H2O,
            correction_terms.H2O_H2O * H2O**2,
        ]
    )

    return correction


def get_common_mask_correction(
    nu_data: np.ndarray, nu_corr: np.ndarray, f0: float
) -> Tuple[ArrayInt]:
    """
    Get the common mask between a nu array of incoming spectrum and
    the big 3 correction nu array

    Argumements:
        nu_data (ndarray[float]): Array of wavenumbers
        nu_corr (ndarray[float]): Mask object

    Returns:
        intersection (Tuple[ndarray[int]]): First item is intersected modes
                                           Second item is spectrum intersected idxs mask
                                           Third item is correction intersected idxs mask

    >>> from spectral_arithmetic.spectrum_operations import get_common_mask_correction
    >>> import numpy as np
    >>> a = np.array(range(5)) * 0.0206
    >>> b = np.array(range(1,5)) * 0.0206
    >>> f0=0.0618
    >>> get_common_mask_correction(a, b, f0)
    (array([-2, -1,  0,  1]), array([1, 2, 3, 4]), array([0, 1, 2, 3]))
    >>> modes, data_idxs, corr_idxs = get_common_mask_correction(a, b, 5)
    >>> assert modes.size == data_idxs.size == corr_idxs.size == 0
    """
    try:
        fsr_data = no.calc_fsr(nu_data)
        fsr_correction = no.calc_fsr(nu_corr)

        modes_data = no.create_mode_index(nu_data, fsr_data, f0)
        modes_correction = no.create_mode_index(nu_corr, fsr_correction, f0)

        modes, data_idxs, corr_idxs = np.intersect1d(
            modes_data, modes_correction, return_indices=True
        )
    except Exception as e:
        LOGGER.warning(f"Unable to calculate a common mask: {e}")
        modes = data_idxs = corr_idxs = np.array([])

    return (modes, data_idxs, corr_idxs)
