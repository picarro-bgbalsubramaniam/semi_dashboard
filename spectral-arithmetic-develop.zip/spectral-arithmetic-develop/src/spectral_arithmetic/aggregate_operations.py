from typing import Dict, List, Tuple
from copy import deepcopy
import numpy as np

from spectral_arithmetic.logger import get_logger
from spectral_arithmetic import nu_operations as no
from spectral_arithmetic.data_models.spectra import (
    BinnedSpectra,
    FilteredSpectra,
    TransformSpectrum,
    ModeBin,
    SpectralEnum
)
from spectral_arithmetic import allan_deviation as ad


LOGGER = get_logger(__name__)

SPECTRAL_KEYS = SpectralEnum.list() + ["npoints"]

BAD_SPECTRUM = TransformSpectrum(
    absorbance=np.array([]),
    npoints=np.array([]),
    nu_prime=np.array([]),
    fsr_prime=np.nan,
    mode_idxs=np.array([]),
    f0_prime=np.nan,
    epoch_time=np.nan,
)
# This Module is for mutli array analysis only.  You can think
# of it as a place to use all the smaller pices for bigger
# aggregate operations on mutliple spectra.


def transform_spectra(spectra: List[dict], apply_transform: bool = True) -> List[Tuple[TransformSpectrum, int]]:
    """
    Pass in a list of spectra dictionaries. Perform a nu transform and get the mode idxs, and
    new fsr, f0, and nu values. We will not mutate the original spectrum and not pass that back.
    This is simply a way to get calculated values for further processing/analysis.

    Arguments:
        spectra (list[dict]): this is a list of spectra dictionaries that need to have results and spectra from combo logs via ComboLogReader

    Returns:
       transformed_spectra_tuple (TransformSpectrum, int): TransformData model with a flag of good (1) and bad (0) spectra

    """

    def create_transform_spectrum(spectrum_data: Dict) -> Tuple[TransformSpectrum, int]:
        """
        This function combins the following 3 operations:
        calc fsr, calc nu_prime, fsr_prime, f0_prime and puts into TransformSpectrum object
        for further analysis.
        """
        try:
            spectrum_data = deepcopy(spectrum_data)
            epoch_time = spectrum_data.pop("epoch_time", 1.)
            f0 = spectrum_data["f0"]

            # Calc FSR
            fsr = no.calc_fsr(spectrum_data["nu"])

            if apply_transform:
            # Perform Nu Transform
                nu_prime, fsr_prime, f0_prime = no.nu_transform(
                    spectrum_data["nu"],
                    spectrum_data["nu_squish"],
                    spectrum_data["nu_shift"],
                    f0,
                    spectrum_data["nu_center"],
                    fsr,
                )
            else:
                nu_prime, fsr_prime, f0_prime = spectrum_data["nu"], fsr, f0

            # Generate mode indices
            mode_idxs = no.create_mode_index(nu_prime, fsr_prime, f0_prime)

            # Create data model and update with spectrum data needed for binning
            transformed_spectrum_data = TransformSpectrum(
                nu_prime=nu_prime,
                fsr_prime=fsr_prime,
                f0_prime=f0_prime,
                epoch_time=epoch_time,
                mode_idxs=mode_idxs,
                **spectrum_data,
            )
            return (transformed_spectrum_data, 1)
        except Exception as e:
            # We need to return something to keep indices matched with incoming spectra
            LOGGER.warning(f"recived exception parsing spectra {e}")
            transformed_spectrum_data = BAD_SPECTRUM.model_copy(update=spectrum_data)

        return (transformed_spectrum_data, 0)

    return (create_transform_spectrum(spectrum) for spectrum in spectra)


def filter_spectral_data(
    modified_spectra: List[Tuple[TransformSpectrum, int]],
    fsr_thresh=None,
    f0_thresh=None,
) -> List[TransformSpectrum]:
    """Filter data based on mask from transform spectra and fsr_thres and f0 thresh
    if specified.

    Arguments:
        modified_spectra (list of TransformSpectrum): list of tuples of TransformSpectrum and int for the mask found tranforming
        fsr_thresh (float): fsr squish tolerance to filter on.  Distance from average fsr
        f0_thresh (float): f0 shift to filter on.  Distance from average f0

    Returns:
        spectra (FilteredSpectra): Filtered spectra
    """
    # TODO: Figure out how to get mean without loading into memory
    spectra, fsr_primes, f0_primes, epoch_times, mask = zip(
        *[
            (spectra, spectra.fsr_prime, spectra.f0_prime, spectra.epoch_time, mask)
            for (spectra, mask) in modified_spectra
        ]
    )
    ave_fsr = np.nanmean(fsr_primes)
    ave_f0 = np.nanmean(f0_primes)
    ave_epoch = np.nanmean(epoch_times)
    returned_spectrum = []
    for spectrum, mask in zip(spectra, mask):
        if mask == 1:
            # Reject on fsr
            if (
                fsr_thresh is not None
                and abs(spectrum.fsr_prime - ave_fsr) > fsr_thresh
            ):
                continue

            # If we want to reject on f0
            if f0_thresh is not None and abs(spectrum.f0_prime - ave_f0) > f0_thresh:
                continue

            returned_spectrum.append(spectrum)

    return FilteredSpectra(
        spectra=returned_spectrum,
        ave_f0_prime=ave_f0,
        ave_fsr_prime=ave_fsr,
        ave_epoch_time=ave_epoch,
    )


def bin_spectral_data(spectra: FilteredSpectra, keys=SPECTRAL_KEYS) -> BinnedSpectra:
    """
    Take list transform data and put into bins.

    Arguments:
        spectra (FilteredSpectra): list of tranformed spectra including calculating mode idxs
        keys (list): list of spectral keys we want to bin (i.e. npoints, residual_fit, etc...)

    Returns:
        BinnedSpectra: Model with
            binned_data (dict) : dictionary with mode_idx (bin) as key and np.array of spectral values,
            binned_allan (dict) : a dictionary of dictionaries (to compute spectral allan variance),
            with mode_idx (bin) as key, and dictionary of allan bin objects
            (keys being spectral qtys. e.g. partial fit, nu_prime, absorbance,) as values
            num_spectra (int) : num spectra in bins
            f0_prime (float) : average f0 in bins
            fsr_prime (float) : average fsr in bins
            epoch_time (float) : average epoch time in bins
    """
    num_spectra = len(spectra.spectra)
    # Get unique modes
    mode_keys = sorted(
        list(set(_ for spectrum in spectra.spectra for _ in spectrum.mode_idxs))
    )
    # Generate bins from mode keys and spectral_arrays
    binned_data = {mode: {key: [] for key in keys} for mode in mode_keys}
    # Calc Statistics ignoring nans if we had a bad transform
    for spectrum in spectra.spectra:
        spectrum_dict = spectrum.model_dump()
        # Go through modes in spectra and add values to bin
        for idx, mode in enumerate(spectrum.mode_idxs):
            for key in keys:
                key_value = spectrum_dict.get(key)
                if key_value is not None:
                    value = key_value[idx]
                    binned_data[mode][key].append(value)

    # TODO: Rewrite this algorithm
    # Convert all the binned data to BinnedSpectra Models
    converted_data = {}
    allan_data = {}
    for mode, value in binned_data.items():
        mode_bins = []
        allan_bins = {}
        npoints = np.array(value["npoints"])
        for key, value in value.items():
            if key == "npoints":
                pass
            else:
                if not value:
                    # handles cases where we don't have the keys we need
                    continue
                value = np.array(value)
                mode_bins.append(
                    ModeBin(
                        n_points=np.sum(npoints),
                        val_sum=np.sum(npoints * value),
                        val_sum_sq=np.sum(npoints * (value**2)),
                        spectra_in_bin=len(npoints),
                        key=key,
                    )
                )
                ab = ad.AllanBin(1)
                for val in value:
                    ab.process(val)
                allan_bins[key] = ab
        converted_data[mode] = np.array(mode_bins)
        allan_data[mode] = allan_bins

    returned_binned_data = BinnedSpectra(
        binned_data=converted_data,
        binned_allan=allan_data,
        num_spectra=num_spectra,
        f0_prime=spectra.ave_f0_prime,
        fsr_prime=spectra.ave_fsr_prime,
        epoch_time=spectra.ave_epoch_time,
    )

    return returned_binned_data
