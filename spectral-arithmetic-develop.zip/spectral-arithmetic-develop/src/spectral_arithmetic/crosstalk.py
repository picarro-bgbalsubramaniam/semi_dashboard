from typing import Dict, Tuple, Union

import numpy as np
from scipy.interpolate import interp1d
from scipy.spatial.distance import cdist
from spectral_arithmetic.constants import ONE_FSR
from spectral_arithmetic.data_models.base import ArrayFloat, ArrayInt
from spectral_arithmetic.data_models.crosstalk_args import (
    CrosstalkConcentration,
    CrosstalkLoss,
)

from math import prod


def xtalk_freq_mask(
    nu_array: np.ndarray, xtalk_nu_array: np.ndarray, max_dist: float = ONE_FSR
) -> Tuple[ArrayInt, ...]:
    """Returns the mask of valid and invalid points in ``nu_array``, based on a threshold on the
    distance to the nearest point in ``xtalk_nu_array``. The threshold is given in the ``max_dist``
    parameter.

    For a given wavenumber :math:`x` in ``nu_array`` :math:`X`, find the wavenumber :math:`y`
    in ``xtalk_nu_array`` (:math:`Y`) that minimizes :math:`|x - y|`. Define this value as the
    "distance" from a wavenumber :math:`x` to the wavenumber array :math:`Y`:

    .. math::
        \mathbf{distance}(x) = \min_{y \in Y} |x - y|

    We apply this distance function to each wavenumber in ``nu_array`` and apply a threshold to
    partition the set of wavenumbers in ``nu_array`` into two sets: Those that are greater than
    ``max_dist`` and those that are not.

    Arguments:
        nu_array (np.ndarray): A nu array from the Spectrum Collector
        xtalk_nu_array (np.ndarray): A nu array from the crosstalks correction algorithm

    Returns:
        keep, mask (np.ndarray): The indices to keep, and mask, in the dataset

    >>> from spectral_arithmetic.crosstalk import xtalk_freq_mask
    >>> from numpy import array
    >>> nu_array = array([1.0, 4.0, 5.0])
    >>> xtalk_array = array([0.1, 1.1, 4.1, 10.0])
    >>> keep, reject = xtalk_freq_mask(nu_array, xtalk_array, max_dist = 0.2)
    >>> print(f"Good points: {nu_array[keep]}")
    Good points: [1. 4.]
    >>> print(f"Number of rejected points: {len(reject)}")
    Number of rejected points: 1
    """

    def distances(nu: np.ndarray, xtalk_nu: np.ndarray):
        xtalk_nu = xtalk_nu.reshape((xtalk_nu.size, 1))
        nu = nu.reshape((nu.size, 1, 1))
        dists = []
        for x in nu:
            dists.append(np.min(cdist(x, xtalk_nu)))
        return np.array(dists)

    def where_to_mask(distances: np.ndarray, threshold: float):
        return np.where(distances <= threshold)[0], np.where(distances > threshold)[0]

    dists = distances(nu_array, xtalk_nu_array)
    keep, mask = where_to_mask(dists, max_dist)
    return keep, mask


def loss_crosstalk_correction(
    nu_array: ArrayFloat, concentrations: Dict[Union[str, int], float], crosstalks: CrosstalkLoss
) -> ArrayFloat:
    """Apply a correction to the loss array before a model sees it.

    The correction is calculated in an experiment beforehand, and becomes a part of application
    configuration. When we apply this type of correction, we require valid, and current
    concentrations for certain molecules in a model (typically, these are the "Big Three": water,
    CO2 and methane). This implies that a fit has been done beforehand in order to arrive at these
    concentrations. Having acquired that concentration set, we apply a pre-fit correction to the
    loss array for another model (typically a "broadband" model).

    The data type for the ``crosstalk`` argument is specified in the ``data_models.crosstalk_args``
    module.

    The calling function should apply the correction calculated here to the dataset in that context.
    In other words, inside the function, we know nothing about the calling environment and
    variables.

    Arguments
        nu_array (np.array): Wavenumber array for which we will evaluate the corrections
        concentrations (dict): Dictionary of current concentrations by CID in the model
        crosstalks (CrosstalkLoss): Crosstalk arguments

    Returns:
        loss_correction (np.array): Correction on loss to be applied to dataset

    >>> from spectral_arithmetic.data_models.crosstalk_args import *
    >>> from spectral_arithmetic.crosstalk import loss_crosstalk_correction
    >>> import numpy as np
    >>> wavenumbers = np.array([6000.0, 6001.0, 6002.0])
    >>> concentrations = {1: 0.5}
    >>> crosstalk_args = CrosstalkLoss(
    ...     wavenumbers=wavenumbers,
    ...     corrections=[
    ...         PerFrequencyCorrection(cids=[1], loss_correction=np.array([1.0, 2.0, 3.0])),
    ...     ],
    ... )
    >>> eval_wavenumber = np.linspace(6000, 6002, 50)
    >>> loss_crosstalk_correction(eval_wavenumber, concentrations, crosstalk_args)
    array([0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5,
           1. , 1. , 1. , 1. , 1. , 1. , 1. , 1. , 1. , 1. , 1. , 1. , 1. ,
           1. , 1. , 1. , 1. , 1. , 1. , 1. , 1. , 1. , 1. , 1. , 1.5, 1.5,
           1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5, 1.5])

    """
    loss_correction = np.zeros(nu_array.size)
    for idx in range(len(crosstalks.corrections)):
        crosstalk_correction_coefficients = crosstalks.corrections[idx].loss_correction
        interpolator = interp1d(
            crosstalks.wavenumbers,
            crosstalk_correction_coefficients,
            kind="nearest",  # "Nearest neighbor" interpolation prevents unphysical interpolation
            fill_value="extrapolate",
            bounds_error=False,
        )
        loss_correction_interp = interpolator(nu_array)
        cids = crosstalks.corrections[idx].cids
        loss_correction += prod([concentrations[x] for x in cids]) * loss_correction_interp
    return loss_correction


def concentration_crosstalk_correction(
    model_param: float,
    concentrations: Dict[int, float],
    crosstalk: CrosstalkConcentration,
) -> Tuple[float, ArrayFloat]:
    """Calculates the crosstalk and calibration values.

    This algorithm has two steps. In step one, we calculate a polynomial in variables of
    concentrations of compounds in a model, plus an offset, plus a model parameter. In step two,
    we apply another polynomial on the output of step one. The coefficients in the polynomials
    will have been derived in an experiment at the lab.

    This correction is applied after a fit. It is a correction to some model parameter based on
    the current "output" (model state) of a fit, which includes concentration values.

    Arguments:
        model_param (float): A model parameter that serves as an independent variable
        crosstalk (CrosstalkConcentration): Crosstalk data type

    Returns:
        tuple(crosstalk_value, calibration_value)

    >>> from spectral_arithmetic.data_models.crosstalk_args import CrosstalkConcentration
    >>> from spectral_arithmetic.crosstalk import concentration_crosstalk_correction
    >>> crosstalk = CrosstalkConcentration(
    ...     offset=-0.001,
    ...     cids=[[1]],
    ...     concentration_coefficients=[0.1, 0.2, 0.3, 0.4],
    ...     polynomial_coefficients=[1],
    ... )
    >>> a, b = concentration_crosstalk_correction(
    ...     model_param=0.04, concentrations={1: 0.3}, crosstalk=crosstalk
    ... )
    >>> float(a), float(b)   # doctest: +ELLIPSIS
    (0.069..., 1.0...)

    """

    def calculate_crosstalk_terms(cids, crosstalk_coefficients, concentrations):
        summation = sum(
            [
                prod([concentrations[x] for x in cids[idx]]) * crosstalk_coefficients[idx]
                for idx in range(len(cids))
            ]
        )
        return summation

    # Calculate crosstalk
    crosstalk_terms = calculate_crosstalk_terms(
        crosstalk.cids, crosstalk.concentration_coefficients, concentrations
    )
    crosstalk_value = model_param + crosstalk.offset + crosstalk_terms

    # Calculate calibration
    calibration_value = np.polyval(crosstalk.polynomial_coefficients, crosstalk_value)
    return crosstalk_value, calibration_value
