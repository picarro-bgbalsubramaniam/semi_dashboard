import copy
import warnings

import numpy as np

TIME_DIM = "_datetime"

XARRAY_DEPRECATION_MSG = (
    "The class AllanVarX is deprecated. "
    "Please use :py:func:`picarro_xarray.compute.allan_deviation.compute_allan_dev` instead, "
    "from the ``picarro-xarray`` package."
)


class AllanVar:
    """Class for computation of Allan Variance of a data series. Variances are computed over sets of
    size 1,2,...,2**(n_bins-1). In order to process a new data point call process_dataum(value). In order
    to recover the results, call get_results(). In order to reset the calculation, call reset().
    """

    counter = 0

    def __init__(self, n_bins):
        """Construct an allan_var object for calculating Allan variances over 1,2,...,2**(n_bins-1) points"""
        self.n_bins = n_bins
        self.bins = [AllanBin(2**i) for i in range(n_bins)]

    def reset(self):
        """Resets calculation"""
        self.counter = 0
        for bin in self.bins:
            bin.reset()

    def process_dataum(self, value: float):
        """Process a value for the Allan variance calculation"""
        for bin in self.bins:
            bin.process(value)
        self.counter += 1

    def get_results(self):
        """Get the result of the Allan variance calculation as (count,(var1,var2,var4,...))"""
        return (self.counter, tuple([bin.allan_var for bin in self.bins]))


class AllanBin:
    """Internal class for Allan variance calculation"""

    def __init__(self, averaging_length: int):
        self.averaging_length = averaging_length
        self.reset()

    def reset(self):
        self.sum, self.sum_sq = 0, 0
        self.sum_pos, self.num_pos = 0, 0
        self.sum_neg, self.num_neg = 0, 0
        self.n_pairs = 0

    def process(self, value: float):
        if self.num_pos < self.averaging_length:
            self.sum_pos += value
            self.num_pos += 1
        elif self.num_neg < self.averaging_length:
            self.sum_neg += value
            self.num_neg += 1
        if self.num_neg == self.averaging_length:
            y = (self.sum_pos / self.num_pos) - (self.sum_neg / self.num_neg)
            self.sum += y
            self.sum_sq += y**2
            self.n_pairs += 1
            self.sum_pos, self.num_pos = 0, 0
            self.sum_neg, self.num_neg = 0, 0

    @property
    def allan_var(self):
        if self.n_pairs < 1:
            return 0
        else:
            return 0.5 * self.sum_sq / self.n_pairs

    @property
    def allan_dev(self):
        if self.n_pairs < 1:
            return 0
        else:
            return np.sqrt(self.allan_var)

    @property
    def allan_std_err(self):
        if self.n_pairs < 1:
            return 0
        else:
            return self.allan_dev / np.sqrt(self.n_pairs * 2)

    def __add__(self, other_bin):
        """
        Method for adding two Allan bins (+ operation)
        """
        if not isinstance(other_bin, AllanBin):
            # A scalar addition (offset)
            ab = copy.deepcopy(self)
            ab.sum = other_bin + self.sum
            ab.sum_sq = self.sum_sq
            ab.n_pairs = ab.n_pairs
        else:
            ab = AllanBin(1)
            ab.sum = self.sum + other_bin.sum  # not sure if we need this
            ab.sum_sq = self.sum_sq + other_bin.sum_sq
            ab.n_pairs = self.n_pairs + other_bin.n_pairs

        return ab

    def __sub__(self, other_bin):
        """
        Method for subtracting two Allan bins (- operation)
        """
        if not isinstance(other_bin, AllanBin):
            # A scalar subtraction (offset)
            ab = copy.deepcopy(self)
            ab.sum = self.sum - other_bin  # not sure if we need this
            ab.sum_sq = self.sum_sq
            ab.n_pairs = ab.n_pairs
        else:
            ab = AllanBin(1)
            ab.sum = self.sum - other_bin.sum
            ab.sum_sq = self.sum_sq + other_bin.sum_sq
            ab.n_pairs = self.n_pairs + other_bin.n_pairs
        return ab

    def __and__(self, other_bin):
        """
        Method for joining 2 Allan bins (& operation)
        """
        if not isinstance(other_bin, AllanBin):
            raise TypeError(
                f"Unsupported operand type for &: {type(other_bin)} and AllanBin"
            )

        # Do we drop a point here an there?
        # Create new allan bin with averaging length of 1
        ab = AllanBin(1)
        ab.sum = self.sum + other_bin.sum
        ab.sum_sq = self.sum_sq + other_bin.sum_sq
        ab.n_pairs = self.n_pairs + other_bin.n_pairs

        return ab

    def __mul__(self, scalar):
        """
        Multiply Allan bin by scalar value (* operation)
        """

        ab = copy.deepcopy(self)
        ab.sum = scalar * self.sum
        ab.sum_sq = scalar**2 * self.sum_sq
        ab.n_pairs = ab.n_pairs
        return ab

    def __truediv__(self, scalar):
        """
        Dunder method to allow for division of binned data (/)
        """
        return self.__mul__(1 / scalar)

    def __rmul__(self, scalar):
        """Dunder method to allow for multiplication of binned data (*)"""
        return self.__mul__(scalar)


class AllanVarX:
    """
    This class is deprecated.
    Please use :py:func:`picarro_xarray.compute.allan_deviation.compute_allan_dev` instead,
    from the ``picarro-xarray`` package.

    Class for computing Allan Variance statistics
    of spectral variables (nu_prime, partial_fit, etc.)
    with xarray dataarrays.

    One of the dimensions need to be the time dimension (eg. : '_datetime')
    """

    def __init__(self, da, share_pair: bool = False):
        """
        Initialize AllanVarX object.
                Initialization include calculating the square of pairwise
                differences between consecutive values of the data array along
                the time dimension and counting the number of pairs used.

                Args:
                    da:
                        DataArray with a time dimension.
                    share_pair (bool, optional):
                        If True, the Allan Variance is computed
                        for all the pairs of consecutive values
                        (also known as overlapping Allan variance).
                        This means that each element of the data array along the
                        time dimension is used for two differences (vs previous and
                        vs next).
                        If False, compute Allan Variance using every
                        other pair of consecutive values in the data array.
                        Each element of the data array along the
                        time dimension is used only once.
                        Defaults to False.
        """
        warnings.warn(
            XARRAY_DEPRECATION_MSG,
            DeprecationWarning,
            stacklevel=2
        )

    @property
    def _allan_var(self):
        raise NotImplementedError(XARRAY_DEPRECATION_MSG)


    @property
    def _allan_dev(self):
        raise NotImplementedError(XARRAY_DEPRECATION_MSG)

    @property
    def _allan_std_err(self):
        raise NotImplementedError(XARRAY_DEPRECATION_MSG)
