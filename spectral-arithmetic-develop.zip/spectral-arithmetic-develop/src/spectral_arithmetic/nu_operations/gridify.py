from enum import IntEnum
from itertools import combinations
from typing import Union, Dict, Tuple
from spectral_arithmetic.data_models.spectra import (
    GridData,
    SchemeInfo,
    FrequencyReference,
    FrequencyFilter,
)

import numpy as np

from scipy.stats import linregress

TRANSFORM_METHOD = IntEnum(
    "transform_method", "USE_ONLY_MASTER, USE_SPECTRUM_CONTAINING_MASTER, USE_ALL_DATA"
)


class Gridify:
    """Gridify manages the nu array datasets and puts them onto a single FSR grid."""

    def __init__(
        self,
        fsr: float = None,
        master_freq: float = None,
        f0: float = None,
        f0_shift: float = None,
        transform_method: TRANSFORM_METHOD = TRANSFORM_METHOD.USE_ONLY_MASTER,
    ):
        self.fsr = fsr
        self.master_freq = master_freq
        self.f0 = f0
        self.f0_shift = f0_shift
        self.transform_method = transform_method

    def process_spectrum(self, nu_array: np.array, scheme_info: SchemeInfo) -> GridData:
        """
        Process a nu array and return a modified nu array that has been moved
        onto an FSR grid, given information about the master frequency and the cavity FSR.
        Under normal (complete information) circumstances, returns a :class:`GridData <spectral_arithmetic.data_models.spectra.GridData>`
        with updated values for ``f0``, ``f0_shift`` and a ``nu_grid`` array.

        Under incomplete information, the return object will have values coming from previous normal run.

        Arguments:
            nu_array (np.array): array of frequency axis (float)
            scheme_info (SchemeInfo): Cavity FSR and scheme master frequency

        Returns:
            GridData: GriData with results as described above
        """
        self.fsr = scheme_info.fsr
        self.master_freq = scheme_info.master_frequency

        new_f0 = None
        nu_grid = None

        new_f0 = determine_f0(
            nu_array, self.fsr, self.master_freq, self.transform_method
        )

        if new_f0:
            self.f0 = new_f0
            self.f0_shift = new_f0 - scheme_info.master_frequency

        if all((self.f0, self.fsr)):
            # Note: Calculations include class attributes. This has the side-effect of returning
            # previous values if current iteration did not produce new values
            nu_grid = compute_nu_grid(nu_array, self.f0, self.fsr)
        else:
            # Algorithm was not able to calculate a new f0. Return the nu array as it was passed in
            # f0 and f0_shift will be null
            nu_grid = nu_array
        return GridData(nu_grid=nu_grid, f0=self.f0, f0_shift=self.f0_shift)


def determine_f0(
    nu_array: np.array, fsr: float, master_freq: float, transform_method: IntEnum
) -> Union[None, float]:
    """
    The master frequency is the desired wavenumber that serves an absolute reference for
    wavenumbers, based on spectroscopy. The wavelength monitor on the other hand, sometimes
    reports a wavelength and a bias. The ``f0`` value is used to correct the bias by choosing
    the closest wavenumber in the dataset to the desired master frequency.

    Note on the ``transform method`` parameter:
        - ``USE_ONLY_MASTER``: uses the nearest fsr to the masterFrequency to determine f0
        - ``USE_SPECTRUM_CONTAINING_MASTER``: uses the whole spectrum containing the
          master frequency to determine f0
        - ``USE_ALL_DATA``: all data will be used to determine f0
    """
    f0 = None
    spectrum_contains_master = master_in_spectrum(nu_array, fsr, master_freq)
    if transform_method == TRANSFORM_METHOD.USE_ONLY_MASTER:
        if spectrum_contains_master:
            f0 = single_point_f0(nu_array, fsr, master_freq)
    elif transform_method == TRANSFORM_METHOD.USE_SPECTRUM_CONTAINING_MASTER:
        if spectrum_contains_master:
            f0 = group_based_f0(nu_array, fsr, master_freq)
    elif transform_method == TRANSFORM_METHOD.USE_ALL_DATA:
        f0 = group_based_f0(nu_array, fsr, master_freq)
    return f0


def master_in_spectrum(nu_array, fsr, master_freq):
    return np.min(abs(nu_array - master_freq)) < 2.5 * fsr


def single_point_f0(nu_array, fsr, master_freq):
    i0 = np.argmin(abs(nu_array - master_freq))
    f0 = nu_array[i0]
    return f0


def group_based_f0(nu_array, fsr, master_freq):
    mode_fraction = (nu_array - master_freq) / fsr
    mode_numbers = np.round(mode_fraction)

    mode_offset = mode_fraction - mode_numbers
    u = mode_offset.argsort()
    # this non-traditional median calculation doesn't take the average
    # of the two central data points for even number of samples
    med_mode_offset = mode_offset[u][int(len(mode_offset) / 2)]

    # determine the mean mode offset from the data, using the median
    mode_fraction_two = (nu_array - master_freq) / fsr - med_mode_offset

    mode_numbers_two = np.round(mode_fraction_two)
    mode_offset_two = mode_fraction_two - mode_numbers_two

    frac = mode_offset_two.mean() + med_mode_offset
    f0 = master_freq + frac * fsr
    return f0


def compute_nu_grid(nu_array, f0, fsr):
    # create the new frequency scale on the FSR grid
    return f0 + fsr * np.round((nu_array - f0) / fsr)


def compute_shift_and_squish(
    nuc: float,
    frequency_references: Dict[str, FrequencyReference],
    r_squared_threshold: float = 0.9,
):
    """Computes a shift and squish from the frequency scale data derived from line fits

    Arguments:
        nuc (float): Nu center of fitter
        references (dict): Dictionary of FrequencyReference

    Returns:
        target_n0, target_n1 (tuple): New "shift" and "squish" parameters for model

    >>> from spectral_arithmetic.data_models.spectra import FrequencyReference, ConcReferenceLevels
    >>> from spectral_arithmetic.data_models.constructors import create_reference_frequency
    >>> from spectral_arithmetic.nu_operations.gridify import compute_shift_and_squish
    >>> freq_refs = {
    ...     "threeGas": {962: 0.0003, 280: 0.0001, 297: 2e-08},
    ...     "water6099": {962: 0.0003},
    ... }
    >>> model_params = {
    ...     "threeGas": {"nuc": 6056.5, "n0": 0.012345},
    ...     "water6099": {"nuc": 6099.3, "n0": 0.056789},
    ... }
    >>> references = create_reference_frequency(frequency_reference=freq_refs, model_params=model_params)
    >>> n0, n1 = compute_shift_and_squish(nuc=6056.5, frequency_references=references)
    >>> float(n0), float(n1)  # doctest: +ELLIPSIS
    (0.012345000000000002..., 0.0010384112149532665...)
    """
    x, y = [], []
    for reference in frequency_references.values():
        if reference.n0 is not None:
            x.append(reference.nuc - nuc)
            y.append(reference.n0)

    if len(x) >= 2:
        if not any(y):
            raise ValueError(f"n0 values cannot all be 0.")

        slope, intercept, r_value, _, _ = linregress(x, y)
        # If the r squared of the linear regression is below threshold
        # then we choose the two frequency references with greatest nuc
        # separation for largest spectral coverage
        if r_value**2 < r_squared_threshold:
            sorted_references = sorted(frequency_references.values(), key=lambda x: x.nuc)
            selected_references = [sorted_references[0], sorted_references[-1]]
            x = [ref.nuc - nuc for ref in selected_references]
            y = [ref.n0 for ref in selected_references]
            slope, intercept, _, _, _ = linregress(x, y)

        target_n0 = intercept
        target_n1 = slope

    elif len(x) == 1:
        target_n0 = y[0]
        target_n1 = 0

    else:
        target_n0 = 0
        target_n1 = 0

    return (target_n0, target_n1)


def update_freq_param(
    smooth_n: float,
    target_n: float,
    filter_const: float,
    max_range: float,
    max_incr: float,
) -> float:
    """Helper function for update_exp_freq_filter that applies filter math and logic

    Args:
        smooth_n (float): value to be smoothened with target_n (in appication this parameter retains state and is a rolling average of the returned float)
        target_n (float): n value to be tested and exponentially averaged with smooth_n
        filter_const (float): the degree of exponential filter (1 is all the weight on target_n and 0 is all the weight on smooth_n)
        max_range (float): the acceptable range of values for target_n, values outside of the range result in no operation and return of smooth_n
        max_incr (float): the allowed range of new_n relative to smooth_n

    Returns:
        float: new smoothened n value

    """
    if target_n == 0 or abs(target_n) > max_range:
        # do nothing and return smooth_n if target_n is zero (due to frequency references below minimum concentrations)
        # or outside of acceptable range
        new_n = smooth_n
    else:
        if smooth_n != 0:
            # exponential filter if smooth_n value is nonzero
            full_incr = (1 - filter_const) * smooth_n + filter_const * target_n
            # threhold filter
            new_n = np.clip(
                full_incr,
                smooth_n - max_incr,
                smooth_n + max_incr,
            )
        else:
            # return target_n if no smooth_n to exponentially filter
            new_n = target_n
    return new_n


def update_exp_freq_filter(
    target_nuc: float,
    filter_data: FrequencyFilter,
    frequency_references: Dict[str, FrequencyReference],
) -> Tuple[float, float]:
    """Computes target n0 and n1 from frequency references and exponentialy smoothens them with nu_transform params in filter_data

    Args:
        target_nuc (float): center frequency from target fitter's model
        filter_data (FrequencyFilter): contains empirical constants and the state of n0 and n1
        frequency_references (Dict[str, FrequencyReference]): frequency reference data containing nu_transform params

    Returns:
        tuple: float values representing the smoothened n0 and n1 parameters

    """
    target_n0, target_n1 = compute_shift_and_squish(target_nuc, frequency_references)
    new_n0 = update_freq_param(
        filter_data.smooth_n0,
        target_n0,
        filter_data.filter_const,
        filter_data.max_range_n0,
        filter_data.max_incr_n0,
    )
    new_n1 = update_freq_param(
        filter_data.smooth_n1,
        target_n1,
        filter_data.filter_const,
        filter_data.max_range_n1,
        filter_data.max_incr_n1,
    )
    return new_n0, new_n1
