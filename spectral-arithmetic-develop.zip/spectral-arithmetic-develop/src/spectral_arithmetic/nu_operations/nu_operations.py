from functools import reduce
from typing import Tuple

import numpy as np

FSR_LOW = 0.01854  # 10% Below
FSR_HI = 0.02266  # 10% Above
FSR_NOM = 0.0206  # Nominal FSR
DEC = 10  # Precision we can expect to be valid
MODE_PREC = 1e-8  # Precision for modes to be integer multiples of fsr

# Error Messages
MULTI_FSR_SINGLE_MODE = (
    "There are more than one single mode fsr values in the FSR limit thresholds"
)
NO_FSR = "Could not find a common fsr value in array"


def bad_mode_err_str(fsr, f0):
    bad_modes = f"Mode Index does not provide integer modes with fsr: {fsr}, f0 {f0}, and nu array provided"
    return bad_modes


def _get_fsr_intersect(nu_array: np.ndarray) -> np.ndarray:
    """
    Finds the intersection of all possible nu values in the limits above
    for an entire nu array
    Arguments:
        nu_array (np.ndarray): array-like object of nu values after being
                                placed on an fsr grid spacing

    Returns:
        intersected_fsrs (np.ndarray): fsrs contained in all of the possible fsr arrays between nu points
    """
    # Get fsr arrays for every consecutive set of nu points
    fsrs = [_calc_fsrs(nu_array[i], nu_array[i + 1]) for i in range(len(nu_array) - 1)]
    intersected_fsrs = reduce(np.intersect1d, fsrs)

    return intersected_fsrs


def _calc_fsrs(
    nu_low: float, nu_hi: float, prec=DEC, fsr_hi=FSR_HI, fsr_low=FSR_LOW
) -> np.ndarray:
    """
    Finds the possible fsr values between two points assuming 10% possible
    error on nominal FSR value.  John's implementation
    Params:
        nu_low (float) - lower nu value
        nu_hi (float) - higher nu value
    Returns:
        fsr_values (np.ndarray) - list of possible fsr values in range
    """
    # Total distance between nu values
    distance = abs(nu_hi - nu_low)

    # The high integer is from the low FSR limit
    high = int(distance / fsr_low) + 1  # range takes up to high value so adding 1
    low = int(distance / fsr_hi) + 1  # We want ceiling for low integer

    return np.array([round((distance / modes), prec) for modes in range(low, high)])


def calc_fsr(
    nu_array: np.ndarray, prec=DEC, fsr_hi=FSR_HI, fsr_low=FSR_LOW
) -> Tuple[float, np.ndarray]:
    """
    Calculates the FSR based on spacing in nu array, this assumes
    at least one pair of single mode separation, but will default to
    multi mode separations if there is no single mode separation

    Arguments:
        nu_array (np.ndarray): array of nu values after being placed on an fsr grid spacing

    Returns:
        fsr (float): fsr value used to grid points
    """
    # Get the wave number separations (1/cm), precision is DEC=10
    separations = np.around(np.diff(nu_array), decimals=prec)

    # Get number of points between hi/low values
    fsr_candidate_locations = np.where(
        (separations > fsr_low) & (separations < fsr_hi)
    )[0]
    if fsr_candidate_locations.size == 0:
        # We have no single mode separation
        expected_fsrs = _get_fsr_intersect(nu_array)
        if expected_fsrs.size == 0:
            raise ValueError(NO_FSR)
        else:
            expected_fsr = expected_fsrs[0]
    else:
        # Check that all fsr_values are the same for single mode separation
        fsr_array = separations[fsr_candidate_locations]
        if np.all(fsr_array == fsr_array[0]):
            expected_fsr = fsr_array[0]
        else:
            raise ValueError(MULTI_FSR_SINGLE_MODE)

    return expected_fsr


def create_mode_index(
    nu_array: np.ndarray, fsr: float, f0: float, prec=MODE_PREC
) -> np.ndarray:
    """
    Generate a mode index, which is the number of FSRS away from nu center each nu point is

    Arguments:
        nu_array (np.ndarray): array of nu values after being placed on an fsr grid spacing
        fsr (float): calculated fsr for this nu array
        f0 (float): Master frequency
    Returns:
        np.ndarray: Array with integer fsrs away for each nu from nu center
    """
    m_idx = (nu_array - f0) / fsr
    rounded_m_idx = np.round(m_idx).astype("int")
    if any(np.abs(m_idx - rounded_m_idx) > prec):
        raise ValueError(bad_mode_err_str(fsr, f0))
    return rounded_m_idx


def nu_transform(
    nu_array: np.ndarray,
    nu_squish: float,
    nu_shift: float,
    f0: float,
    nu_center: float,
    fsr: float,
):
    """
    Perform a nu transform based on calculated squish, shift, and nu_center parameters and f0 in combo logs
    This way we can produce the array that was actually fitted in voc-fitter
    """
    tranformed_nus = nu_squish * (nu_array - nu_center) + nu_array + nu_shift
    new_fsr = fsr * (1 + nu_squish)
    new_f0 = f0 * (1 + nu_squish) + nu_shift - nu_squish * nu_center

    return (tranformed_nus, new_fsr, new_f0)
