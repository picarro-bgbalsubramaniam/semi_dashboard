from pathlib import Path
from typing import List

import pandas as pd

from spectral_arithmetic.data_models import scheme_models
from spectral_arithmetic.logger import get_logger

LOGGER = get_logger(__name__)
F_MASTER = 6056.50678  # Never seen this change, but is parametrizable

# Base Keys needed for a row from selected frequencies
MODE = "mode"
SID = "subschemeId"
SETPOINT = "setpoint"
DWELL = "dwell"
IGNORE = 16384


def make_subscheme(
    fsr: float,
    virtual_lasers: scheme_models.VirtualLasers,
    line_scheme: scheme_models.LineScheme,
    f_master: float,
    sid: int,
    extra1: int = 0,
) -> List[scheme_models.Row]:
    """
    Make a Line subscheme from the scheme config ini

    Args:
        fsr (float): instrument fsr
        virtual_lasers (VirtualLasers): laser models from LaserRange.ini
        line_scheme (LineScheme): model for a line scheme from scheme_config.ini
        f_master (float): master frequency of instrument
        sid (int): subscheme id to be a part of (i.e. 100)
        threshold (int): threshold to trigger ringdown, often defaulted by instrument
        extra1 (int): field to set bit mask in for lines

    Returns:
        list of scheme rows for a line subscheme
    """

    # Find mode center from line center frequency and master frequency and fsr
    offsets, dwells = line_scheme.offsets_and_dwells
    mode_center = int(round((line_scheme.center_frequency - f_master) / fsr))
    subscheme_row_list = []

    for offset, dwell in zip(offsets, dwells):
        # convert offset to nu value
        cur_mode = mode_center + offset
        nu = f_master + cur_mode * fsr

        # continue if nu outside of valid laser range
        try:
            laser = virtual_lasers.get_laser(nu)
        except ValueError as e:
            LOGGER.debug(f"Unable to find laser in range for nu {nu}: {e}")
            continue

        # add the row
        subscheme_row_list.append(
            scheme_models.Row(
                setpoint=nu,
                dwell=dwell,
                subschemeId=sid,
                virtualLaser=laser,
                threshold=line_scheme.threshold,
                extra1=extra1,
            )
        )

    return subscheme_row_list


def make_subschemes(
    fsr: float,
    line_schemes: scheme_models.LineSchemes,
    lasers: scheme_models.VirtualLasers,
    sid: int,
) -> pd.DataFrame:
    """
    Given LineSchemes model convert to subschemes dataframe with Row keys as columns
    Args:
        fsr (float): Cavity FSR
        line_schemes (LineSchemes): all the line subschemes
        lasers (VirtuaLasers): lasers model from LaserRange.ini

    Returns:
        pd.DataFrame with all subscheme rows in a single frame
    """
    subschemes = {}
    for line_scheme in line_schemes.line_scheme_models:
        subschemes[line_scheme.name] = make_subscheme(
            fsr,
            lasers,
            line_scheme,
            line_schemes.f_master,
            sid,
            2**line_scheme.extra1,
        )

    all_rows = []
    # iterate through all rows and make a dataframe for all subschemes
    for subscheme in subschemes.values():
        all_rows.extend([row.model_dump() for row in subscheme])
        sub_df: pd.DataFrame = pd.DataFrame(
            all_rows, columns=list(scheme_models.Row.model_fields.keys())
        )

    return sub_df


def get_selected_frequencies(
    selected_frequencies_file: str,
    fsr: float,
    broadband_sid: int = 100,
    f_master: float = F_MASTER,
) -> pd.DataFrame:
    """
    Reads in selected_frequencies.txt and returns dataframe with Row keys as columns

    Args:
        selected_frequencies_file (str): path to selected_frequencies files
        fsr (flaot): cavity fsr
        broaband_sid (int): sid to assign to this scheme
        f_master (float): master frequency
    """

    if not Path(selected_frequencies_file).exists():
        raise ValueError(
            f"Selected Frequencies file not found in {selected_frequencies_file}"
        )

    columns = [MODE] + list(scheme_models.Row.model_fields.keys())
    selected_frequencies = pd.read_csv(
        selected_frequencies_file, delim_whitespace=True, names=columns
    )
    selected_frequencies[SID] = broadband_sid
    selected_frequencies[DWELL] += 1  # Add the one
    selected_frequencies[SETPOINT] = f_master + selected_frequencies["mode"] * fsr
    selected_frequencies.drop(MODE, inplace=True, axis=1)

    return selected_frequencies.fillna(0)


def _set_laser_ignore_rows(
    laser_df: pd.DataFrame,
    ignore_first_row: bool = False,
    ignore_last_row: bool = False,
    ignore_flag: int = IGNORE,
    dwells: int = 5,
):
    """
    Add ignore dwells and flag to the last row before a laser transition

    Args:
        laser_df (pd.DataFrame): dataframe containing all rows for a given laser
        ignore_first_row (bool): ignore the first row after a transition
        ignore_last_row (bool): ignore the last row before a transition
        ignore_flag (int): bit mask power of 2 used to ignore a row
        dwells (int): Number of dwells in an ignore row

    Returns:
        pd.DataFrame with original laser frame and new ignore rows
    """
    first_row = laser_df.iloc[0].copy()
    last_row = laser_df.iloc[-1].copy()
    if ignore_first_row:
        new_sid = int(last_row[SID]) | ignore_flag
        first_row[DWELL] = dwells
        first_row[SID] = new_sid
        laser_df = pd.concat([first_row.to_frame().transpose(), laser_df])

    if ignore_last_row:
        new_sid = int(last_row[SID]) | ignore_flag
        last_row[DWELL] = dwells
        last_row[SID] = new_sid
        laser_df = pd.concat([laser_df, last_row.to_frame().transpose()])

    return laser_df


def combine_sweep_down(
    selected_frequencies_df: pd.DataFrame,
    subscheme_df: pd.DataFrame,
    lasers: scheme_models.VirtualLasers,
    add_laser_transition_ignore: bool = True,
) -> pd.DataFrame:
    """
    Combine all the subschemes and broadband scheme, assign lasers, and add ignore rows.

    Args:
        selected_frequencies_df (pd.DataFrame): Frame wit broadband selected frequencies and Row keys as columns
        susbcheme_df (pd.DataFrame): Frame with all subschemes and Row keys as columns
        lasers (Virtuallasers): laser models generated from LaserRange.ini
        add_laser_transition_ignore (bool): Add ignore rows between laser transitions
    """
    # Combine subschemes and broadband selected frequencies and sort
    full_df = pd.concat([selected_frequencies_df, subscheme_df])
    full_df = full_df.sort_values("setpoint", ascending=False)
    full_df.index = list(range(0, len(full_df.index)))

    laser_frames = []
    for i, laser in enumerate(lasers.lasers):
        laser_df = full_df[
            (full_df["setpoint"] >= laser.low) & (full_df["setpoint"] < laser.high)
        ].copy()
        # assign laser
        laser_df["virtualLaser"] = laser.number
        if add_laser_transition_ignore:
            # add ignore rows
            if i == 0:
                # first laser
                laser_df = _set_laser_ignore_rows(laser_df, ignore_last_row=True)
            elif i == len(lasers.lasers) - 1:
                # last laser
                laser_df = _set_laser_ignore_rows(laser_df, ignore_first_row=True)
            else:
                # middle laser (N laser proof)
                laser_df = _set_laser_ignore_rows(
                    laser_df, ignore_first_row=True, ignore_last_row=True
                )
        laser_frames.append(laser_df)

    # Reassemble and sort
    full_df = pd.concat(laser_frames)
    full_df = full_df.sort_values("setpoint", ascending=False)
    full_df.index = list(range(0, len(full_df.index)))

    return full_df


def decode_mask(mask: int, bits: int = 32) -> List[int]:
    """
    Given powers of 2 bit sum, decode into powers
    Args:
        mask (int): sum of powers of 2
        bits (int): Number of bits for field (32 bit default)

    Returns:
        list of integer powers used to create mask sum
    """
    return_vals = []
    for i in range(0, bits):
        x = 1

        if (mask & (x << i)) > 0:
            return_vals.append(i)
    return return_vals
