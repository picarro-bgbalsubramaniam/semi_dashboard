import warnings

import pandas as pd
from typing import Optional, List, Dict, Union

from spectral_arithmetic.logger import get_logger
import enum

LOGGER = get_logger(__name__)

TIME_DIM = "_datetime"
STACKING_DIM = "new_dim"
FREQ_DIM = "mode"

FRAC_THRESH = 0.8

FITTER_VARS = [
    "timestamp",
    "f0",
]

TIMELEN = "Timeseries Length"

SPECTRA_ATTRIBUTES = FITTER_VARS + [TIMELEN]

ANALYZER = "Analyzer"
FITTER = "Fitter"
COMPACT_THRESH = "FilterBins Threshold"
ORIG_ATTRIBUTES = [ANALYZER, FITTER]
EXTRA_ATTRIBUTES = ORIG_ATTRIBUTES + [COMPACT_THRESH]

SPECTRA_VARS = [
    "nu",
    "nu_prime",
    "partial_fit",
    "residuals",
    "absorbance",
    "big3",
    "xtalk",
    "model",
]
NU_VARS = ["nu", "nu_prime"]

MEAN = ""
STD = "_std"
STDERR = "_std_err"
ADEV = "_allan_dev"
AVAR = "_allan_var"
ASTDERR = "_allan_std_err"

STATS = [MEAN, STD, STDERR]
ALLANSTATS = [ADEV, AVAR, ASTDERR]

SUFFIXES = STATS + ALLANSTATS

NPOINTS = "npoints"
NPAIRS = "n_pairs"
NSPECTRA = "n_spectra"
SPECTRA_NUMS = [NPOINTS, NPAIRS, NSPECTRA]
ATTR_AGG_SPEC = {"description": "aggregate spectra"}

COMPACT_FLAG = "is_compact"

XARRAY_DEPRECATION_MSG = (
    "Spectral operations in ``spectral-arithmetic`` are deprecated. "
    "Please use :py:func:`picarro_xarray.compute.spectral_operations` instead, "
    "from the ``picarro-xarray`` package."
)


class Aggregation(enum.Enum):
    SUBTRACT = "subtract"
    ADD = "add"
    INTERSECTION = "intersection"
    UNION = "union"


def is_compact_spectra(ds, requested_key: str = COMPACT_FLAG) -> bool:
    raise NotImplementedError(XARRAY_DEPRECATION_MSG)


def get_compact_stats(dsm):
    raise NotImplementedError(XARRAY_DEPRECATION_MSG)


def compactify_x(
    ds,
    frac_thresh: float = FRAC_THRESH,
    time_start: Optional[pd.Timestamp] = None,
    time_end: Optional[pd.Timestamp] = None,
):
    raise NotImplementedError(XARRAY_DEPRECATION_MSG)


def aggregate_spectra(
    datasets: List, aggregate_mode: Aggregation = Aggregation.INTERSECTION
):
    raise NotImplementedError(XARRAY_DEPRECATION_MSG)


def add_spectra_stats(
    ds_agg,
    ds_out,
    join_mode: Aggregation = Aggregation.INTERSECTION,
):
    raise NotImplementedError(XARRAY_DEPRECATION_MSG)


def join_spectra(datasets: List, join_mode: Aggregation = Aggregation.INTERSECTION):
    raise NotImplementedError(XARRAY_DEPRECATION_MSG)


def join_spectra_pairwise(ds1, ds2, join_mode: Aggregation = Aggregation.ADD):
    raise NotImplementedError(XARRAY_DEPRECATION_MSG)


class SpectralOperationsX:
    """
    Class for doing spectral operations on xarray datasets.
    Arguments:
        ds1 (xr.Dataset): spectra (xarray dataset) to perform spectral operations on.
        If supplied dataset is not a compact spectra, it is compactified first.

    """

    def __init__(self, ds1, frac_thresh: float = FRAC_THRESH):
        warnings.warn(XARRAY_DEPRECATION_MSG, DeprecationWarning, stacklevel=2)

    def scalar_offset(self, scalar: Union[float, int]):
        raise NotImplementedError(XARRAY_DEPRECATION_MSG)

    def subtract(self, ds2):
        raise NotImplementedError(XARRAY_DEPRECATION_MSG)

    def add(self, ds2):
        raise NotImplementedError(XARRAY_DEPRECATION_MSG)

    def intersect(self):
        raise NotImplementedError(XARRAY_DEPRECATION_MSG)

    def union(self, ds2):
        raise NotImplementedError(XARRAY_DEPRECATION_MSG)

    def multiply(self, ds2: Union[float, int]):
        raise NotImplementedError(XARRAY_DEPRECATION_MSG)

    def divide(self, ds2: Union[float, int]):
        raise NotImplementedError(XARRAY_DEPRECATION_MSG)
