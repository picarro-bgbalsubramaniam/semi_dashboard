from typing import List, Union

from pydantic import BaseModel, ConfigDict, Field
from spectral_arithmetic.constants import ONE_FSR
from spectral_arithmetic.data_models.base import ArrayFloat


class PerFrequencyCorrection(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    cids: List[Union[str, int]]  # List of CIDs, or names like "HDO"
    loss_correction: ArrayFloat  # This is an interpolation node


class CrosstalkLoss(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    wavenumbers: ArrayFloat
    corrections: List[PerFrequencyCorrection]
    distance_threshold: float = Field(default=ONE_FSR)


class CrosstalkConcentration(BaseModel):
    offset: float
    cids: List[List[int]]
    concentration_coefficients: List[float]
    polynomial_coefficients: List[float]


class Big3CorrectionTerms(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    offset: ArrayFloat
    CO2: ArrayFloat
    CH4: ArrayFloat
    H2O: ArrayFloat
    CO2_H2O: ArrayFloat
    CH4_H2O: ArrayFloat
    H2O_H2O: ArrayFloat
