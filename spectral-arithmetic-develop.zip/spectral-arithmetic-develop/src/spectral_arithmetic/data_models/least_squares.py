from pydantic import BaseModel, ConfigDict
from typing import Optional
from spectral_arithmetic.data_models.base import ArrayFloat


class RegressionStatistic(BaseModel):
    """Linear regression statistics. After completing a linear regression the statistics on
    "goodness of fit" are returned in instances of this class."""
    model_config = ConfigDict(arbitrary_types_allowed=True,
                              frozen=False,
                              # Set the following to squelch warning from Pydantic that we are tresspassing
                              # into its namespace with our `model_estimate`. Future developers should be
                              # cautious not to accidentally clobber an actual Pydantic model configuration.
                              protected_namespaces=())

    lsq_res: float
    R2: Optional[float]
    R2_adj: Optional[float]
    residual_error: Optional[ArrayFloat] = None
    model_estimate: Optional[ArrayFloat] = None
    std_dev: Optional[ArrayFloat] = None
