from .spectra import FrequencyReference, ConcReferenceLevels
from typing import Dict


def create_reference_frequency(
    frequency_reference, model_params
) -> Dict[str, FrequencyReference]:
    """
    Create a FrequencyReference object

    Arguments:
        frequency_references (dict): Dictionary of fit names to cid-concentrations pairs
        model_params (dict): Dictionary of fit names to nuc and n0 values

    Returns:
        FrequencyReference

    >>> from spectral_arithmetic.data_models.spectra import FrequencyReference, ConcReferenceLevels
    >>> freq_refs = {
    ...     "threeGas": {962: 0.0003, 280: 0.0001, 297: 2e-08},
    ...     "water6099": {962: 0.0003},
    ... }
    >>> model_params = {
    ...     "threeGas": {"nuc": 6056.5, "n0": 0.0},
    ...     "water6099": {"nuc": 6099.3, "n0": 0.0},
    ... }
    >>> create_reference_frequency(frequency_reference=freq_refs, model_params=model_params)
    {'threeGas': FrequencyReference(name='threeGas', nuc=6056.5, n0=0.0, conc_levels=ConcReferenceLevels(concentration_levels={962: 0.0003, 280: 0.0001, 297: 2e-08})), 'water6099': FrequencyReference(name='water6099', nuc=6099.3, n0=0.0, conc_levels=ConcReferenceLevels(concentration_levels={962: 0.0003}))}

    """
    return {
        name: FrequencyReference(
            name=name,
            nuc=model_params[name]["nuc"],
            n0=model_params[name]["n0"],
            conc_levels=ConcReferenceLevels(
                concentration_levels=frequency_reference[name]
            ),
        )
        for name in frequency_reference
    }
