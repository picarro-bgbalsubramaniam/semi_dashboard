import numpy as np
from numpy.typing import NDArray
import sys


__minor_version = sys.version_info.minor


if __minor_version == 8:
    # With python3.8 we lose some typing resolution
    Array = np.ndarray
    ArrayInt = np.ndarray
    ArrayFloat = np.ndarray
    ArrayBool = np.ndarray

else:
    Array = NDArray
    ArrayInt = NDArray[np.int64]
    ArrayFloat = NDArray[np.float64]
    ArrayBool = NDArray[np.bool_]

