from pathlib import Path
from typing import Dict, List, Tuple, TypeVar, Union

from configobj import ConfigObj
from pydantic import BaseModel, ConfigDict

Lasers = TypeVar("Lasers", bound="VirtualLasers")
Lines = TypeVar("Lines", bound="LineSchemes")


class Row(BaseModel):
    """
    Represents a single row in a scheme.  All of these signals
    need to be present in the DSP

    :param float setpoint: nu value
    :param int dwell: Number of dwells for the row
    :param int subschemeId: typical subscheme id
    :param int virtualLaser: laser number to use for this row
    :param int threshold: threshold for light intensity to trigger ringdown (default=0)
    :param int pzt: set after scheme is created (default=0)
    :param int laserTemp: set after scheme is created (default=0)
    :param int extra1: Used to identify line subscheme vs broadband (default=0)
    :param int extra2: Used to identify which dwells go to which fitter for OmniZero (default=0)
    :param int extra3: Unused (default=0)
    :param int extra4: Unused (default=0)
    :param int frontMirrorDac: set after scheme is created (default=0)
    :param int backMirrorDac: set after scheme is created (default=0)
    :param coarsePhaseDac: set after scheme is created (default=0)
    """

    setpoint: float
    dwell: int
    subschemeId: int
    virtualLaser: int
    threshold: int = 0
    pzt: int = 0
    laserTemp: float = 0.0
    extra1: int = 0
    extra2: int = 0
    extra3: int = 0
    extra4: int = 0
    frontMirrorDac: int = 0
    backMirrorDac: int = 0
    coarsePhaseDac: int = 0

    @property
    def data(self) -> Dict:
        """For backwards compatibility with old Row class"""
        return self.model_dump()


class VirtualLaser(BaseModel):
    """
    Class Representing a laser model

    :param str name: laser name
    :param float low: lower nu limit
    :param float high: upper nu limit
    :param int number: laser number, ordered from high nu to low
    """

    name: str
    low: float
    high: float
    number: int = 0


class VirtualLasers(BaseModel):
    """Convenience for all lasers in LaserRange.ini"""

    model_config = ConfigDict(arbitrary_types_allowed=True)
    lasers: Union[List[VirtualLaser], None] = None

    def get_laser(self, nu: float) -> int:
        """Get laser with nu in range

        Args:
            nu (float): nu value being assessed

        Returns:
            int: laser number in list of lasers

        Raises:
            ValueError if nu outside of any laser range
        """
        for laser in self.lasers:
            if (nu >= laser.low) and (nu < laser.high):
                return laser.number

        raise ValueError(f"nu value {nu} no within laser range")

    @classmethod
    def read_from_ini(cls, laser_range_ini: str) -> Lasers:
        """
        Factory method to produce Virtual Lasers from config.

        Args:
            laser_range_ini (str): str repr of path to LaserRange.ini file

        Returns:
            VirtualLasers model

        Raises:
            ValueError if file doesn't exist
        """
        path = Path(laser_range_ini)
        if not path.exists():
            raise ValueError(f"Laser Config {laser_range_ini} not found")

        laser_config = ConfigObj(laser_range_ini)

        # sort lasers from high to low instead of relying on manual ordering
        laser_config = dict(
            sorted(laser_config.iteritems(), key=lambda kv: kv[1]["HIGH"], reverse=True)
        )

        laser_models = []
        for i, (laser_key, laser_vals) in enumerate(laser_config.items()):
            laser_models.append(
                VirtualLaser(
                    name=laser_key,
                    low=laser_vals["LOW"],
                    high=laser_vals["HIGH"],
                    number=i,
                )
            )
        return cls(lasers=laser_models)


def _make_offsets_and_dwells(
    points_before: int,
    points_after: int,
    peak_dwell: int,
    sides_dwell: int,
) -> Tuple[List[int], List[int]]:
    """
    Function to assign offsets and number of dwells for a given line.

    Args:
        points_before (int): points before peak
        points_after (int): points after peak
        peak_dwell (int): dwells of peak
        sides_dwell (int): dwells on either side of peak

    Returns:
        Tuple of lists of ints with first being offsets and second being dwells
    """
    offsets = list(range(-points_before, points_after + 1))
    dwells = []
    for off in offsets:
        if off == 0:  # peak dwell
            dwells.append(peak_dwell)
        elif abs(off) == 1:  # sides dwell
            dwells.append(sides_dwell)
        elif off in [-points_before, points_after]:  # boundary gets about half peak
            dwells.append(int(round(peak_dwell / 2)))
        else:  # everyting else gets one dwell
            dwells.append(1)

    return (offsets, dwells)


class LineScheme(BaseModel):
    """
    Class Representing a Line Scheme Model

    :param str name: line name (i.e. CO2_6056)
    :param float center_frequency: central frequency (nu) of line
    :param int points_before: Number of points before central frequency (fsr spacing)
    :param int points_after: Number of points after central frequency (fsr spacing)
    :param int peak_dwell: Number of dwells in central frequncy
    :param int sides_dwell: Number of dwells one fsr on either side of central frequency
    :param int threshold: Optional threshold value for triggering ring down
    :param int extra1: Used as bit mask for which point goes to which line subscheme
    """
    name: str
    center_frequency: float
    points_before: int
    points_after: int
    peak_dwell: int
    sides_dwell: int
    threshold: int = 0
    extra1: int

    @property
    def offsets_and_dwells(self) -> Tuple[List[int], List[int]]:
        """Returns tuple of offsets and dwell lists generated from config"""
        offsets, dwells = _make_offsets_and_dwells(
            self.points_before,
            self.points_after,
            self.peak_dwell,
            self.sides_dwell,
        )
        return (offsets, dwells)


class LineSchemes(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    f_master: float
    line_scheme_models: List[LineScheme]

    @property
    def bit_mask_info(self) -> Dict[int, float]:
        """
        Get the bit mask for all the lines in the LineSchemes model
        """
        return {
            model.extra1: model.center_frequency for model in self.line_scheme_models
        }

    @classmethod
    def read_from_ini(cls, scheme_config_ini: str) -> Lines:
        """
        Factory method parse ini file with the model information about line schemes

        Args:
            scheme_config_ini (str): path to ini config

        Returns:
            LineSchemes model

        Raises:
            ValueError if path doesn't exist
        """
        path = Path(scheme_config_ini)
        if not path.exists():
            raise ValueError(f"Lines Config {scheme_config_ini} not found")

        lines_config = ConfigObj(scheme_config_ini)

        lines_models = []
        master_frequency = lines_config.pop("FREQUENCY")

        for line_key, line_vals in lines_config.items():
            lines_models.append(LineScheme(name=line_key, **line_vals))

        return cls(**master_frequency, line_scheme_models=lines_models)
