from pydantic import BaseModel, model_validator
from typing import Callable, Dict, List, Optional


class ModelFunctions(BaseModel):
    nu_min: float
    nu_max: float
    funcs: Dict[int, Callable]
    cids: Optional[List[int]] = None

    @model_validator(mode="before")
    def copy_cids(cls, values):
        # Creates an attribute `cids` that is a sorted list of cids
        cids = sorted(values["funcs"].keys())
        values["cids"] = cids
        return values
