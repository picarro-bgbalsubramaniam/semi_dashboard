from typing import Dict, List, Optional, Union
import enum
import numpy as np
import math
from pydantic import BaseModel, ConfigDict, model_validator
from spectral_arithmetic.utils import select_n_points
from spectral_arithmetic.allan_deviation import AllanBin
from .base import Array, ArrayInt, ArrayFloat


MEAN = "mean"
STD = "std"
STD_ERR = "std_err"

AVAR = "allan_var"
ADEV = "allan_dev"
ASTDERR = "allan_std_err"


class SpectralEnum(str, enum.Enum):
    nu_prime = "nu_prime"
    absorbance = "absorbance"
    partial_fit = "partial_fit"
    residuals = "residuals"
    xtalk = "xtalk"
    static_compounds = "static_compounds"

    @classmethod
    def list(cls):
        return list(map(lambda c: c.value, cls))


class SchemeInfo(BaseModel):
    fsr: float
    master_frequency: float


class GridData(BaseModel):
    """
    GridData model
        - ``nu_grid``: array: float
        - ``f0``: float
        - ``f0_shift``: <float>
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    nu_grid: ArrayFloat
    f0: Union[None, float]
    f0_shift: Union[None, float]


class SpectrumData(BaseModel):
    """
    Data from spectrum collector to run fitter on
    """

    model_config = ConfigDict(arbitrary_types_allowed=True, frozen=True, extra="ignore")

    temperature: float
    pressure: float
    timestamp: float
    absorbance: ArrayFloat
    npoints: ArrayInt
    nu: ArrayFloat

    @model_validator(mode="before")
    def arrays_same_length(cls, values):
        # FIXME: Use .get (LBYL)
        absorbance_size = values["absorbance"].size
        npoints_size = values["npoints"].size
        nu_size = values["nu"].size
        if len(set((absorbance_size, npoints_size, nu_size))) != 1:
            raise ValueError("Length of array types must be the same")
        return values


class SpectrumMask(BaseModel):
    include: List[Optional[List[float]]]
    exclude: List[Optional[List[float]]]


class ConcReferenceLevels(BaseModel):
    """Immutable container for gas concentrations to be used to set the frequency axis"""

    model_config = ConfigDict(frozen=True)

    concentration_levels: Dict[int, float]


class FrequencyReference(BaseModel):
    """Container for tracking minimum concentration levels by molecule (CID) needed to serve as a
    frequency reference for the fitter."""

    name: str
    nuc: Optional[float] = None
    n0: Optional[float] = None
    conc_levels: ConcReferenceLevels


class FrequencyFilter(BaseModel):
    """Stores data for exponential filter math and the state of squish (n1) and shift (n0)
    nu_transform parameters"""

    smooth_n0: Optional[float] = 0.0
    smooth_n1: Optional[float] = 0.0
    filter_const: float
    max_range_n0: float
    max_range_n1: float
    max_incr_n0: float
    max_incr_n1: float


class TransformSpectrum(BaseModel, extra="ignore"):
    """
    This model represents the data model after doing the
    following transform.  Combo log data -> nu transform -> mode_idx

    If this contains more than one spectrum we keep a running sum of npoints
    and spectral array data.  If there is a _sq in the field name, we are keeping
    a running sum of the value squared for each point in the array.  This allows
    for easier calculation of mean and std dev later as we add/remove spectra
    from this model.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    absorbance: ArrayFloat
    nu_prime: ArrayFloat
    mode_idxs: ArrayFloat
    npoints: ArrayInt
    partial_fit: Optional[ArrayFloat] = None
    residuals: Optional[ArrayFloat] = None
    xtalk: Optional[ArrayFloat] = None
    static_compounds: Optional[ArrayFloat] = None
    num_spectra: int = 1
    fsr_prime: float
    f0_prime: float
    epoch_time: float = 1.0


class FilteredSpectra(BaseModel):
    """
    This is the output from a filter step
    """

    ave_fsr_prime: float
    ave_f0_prime: float
    ave_epoch_time: float = 1.0
    spectra: List[TransformSpectrum]


class ModeBin(BaseModel):
    """
    Base Model for a Bin for a specific spectral attribute (key), such as
    (nu_prime, absorbance, partial_fit, xtalk, residuals)
    This model is used to keep track of these properties in a specific
    form to allow for easier union and statistical computation with other
    binned spectral data
    """

    model_config = ConfigDict(frozen=True)

    n_points: int
    val_sum: float
    val_sum_sq: float
    spectra_in_bin: int
    key: SpectralEnum

    @property
    def mean(self) -> float:
        if self.n_points == 0:
            mean = 0
        else:
            mean = self.val_sum / self.n_points
        return mean

    @property
    def std(self) -> float:
        if self.n_points == 0:
            std = 0
        else:
            std = math.sqrt(
                abs(
                    self.val_sum_sq / self.n_points
                    - self.val_sum**2 / self.n_points**2
                )
            )
        return std

    @property
    def std_err(self) -> float:
        if self.n_points == 0:
            std_err = 0
        else:
            std_err = self.std / math.sqrt(self.n_points)
        return std_err

    def __add__(self, other_bin):
        """
        Method for adding two spectral bins
        """
        if not isinstance(other_bin, ModeBin):
            # A scalar addition (offset)
            return self.create_from_stats(
                self.n_points,
                self.mean + other_bin,
                self.std,
                self.spectra_in_bin,
                self.key,
            )
        else:
            # Adding a bin
            n_points_use = select_n_points(self.n_points, other_bin.n_points)
            spectra_use = self.spectra_in_bin + other_bin.spectra_in_bin
            if self.key.name == "nu_prime":
                mean = (self.mean + other_bin.mean) / 2
            else:
                mean = self.mean + other_bin.mean
            std = math.sqrt((self.std_err**2 + other_bin.std_err**2) * n_points_use)

            return self.create_from_stats(
                n_points_use, mean, std, spectra_use, self.key
            )

    def __sub__(self, other_bin):
        """
        Method for subtracting two spectral bins
        """
        if not isinstance(other_bin, ModeBin):
            # A scalar subtraction (offset)
            return self.create_from_stats(
                self.n_points,
                self.mean - other_bin,
                self.std,
                self.spectra_in_bin,
                self.key,
            )
        else:
            # Subtracting a bin
            n_points_use = select_n_points(self.n_points, other_bin.n_points)
            spectra_in_bin_use = select_n_points(
                self.spectra_in_bin, other_bin.spectra_in_bin
            )
            if self.key.name == "nu_prime":
                mean = (self.mean + other_bin.mean) / 2
            else:
                mean = self.mean - other_bin.mean
            std = math.sqrt((self.std_err**2 + other_bin.std_err**2) * n_points_use)

            return self.create_from_stats(
                n_points_use, mean, std, spectra_in_bin_use, self.key
            )

    def __and__(self, other_bin):
        """Joining another mode bin with this one.  This is combining values for
        accurate statistic reporting
        """
        if not isinstance(other_bin, ModeBin):
            raise TypeError(
                f"Unsupported operand type for &: {type(other_bin)} and ModeBin"
            )

        return ModeBin(
            n_points=self.n_points + other_bin.n_points,
            val_sum=self.val_sum + other_bin.val_sum,
            val_sum_sq=self.val_sum_sq + other_bin.val_sum_sq,
            spectra_in_bin=self.spectra_in_bin + other_bin.spectra_in_bin,
            key=self.key,
        )

    def __mul__(self, scalar):
        """Multiply bin by scalar value.  Nu should not be mutated by this operation"""
        if self.key.name == "nu_prime":
            return self
        else:
            return ModeBin(
                n_points=self.n_points,
                val_sum=scalar * self.val_sum,
                val_sum_sq=scalar**2 * self.val_sum_sq,
                spectra_in_bin=self.spectra_in_bin,
                key=self.key,
            )

    def __truediv__(self, scalar):
        """Dunder method to allow for division of binned data (/)"""
        return self.__mul__(1 / scalar)

    def __rmul__(self, scalar):
        """Dunder method to allow for multiplication of binned data (*)"""
        return self.__mul__(scalar)

    @classmethod
    def create_from_stats(
        cls,
        n_points: int,
        mean: float,
        std: float,
        spectra_in_bin: int,
        key: SpectralEnum,
    ):
        """
        Factory method to convert ModeBin stats back into original
        ModeBin model fields and generate new ModeBin.
        Needed to keep std_err reporting accurate
        """
        val_sum = n_points * mean
        if n_points == 0:
            val_sum_sq = 0
        else:
            val_sum_sq = n_points * (std**2 + (val_sum / n_points) ** 2)
        return cls(
            n_points=n_points,
            val_sum=val_sum,
            val_sum_sq=val_sum_sq,
            spectra_in_bin=spectra_in_bin,
            key=key,
        )


class BinnedSpectra(BaseModel):
    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)
    binned_data: Dict[int, np.ndarray]
    binned_allan: Dict[int, Dict[str, AllanBin]]
    num_spectra: int
    fsr_prime: float
    f0_prime: float
    epoch_time: float = 1.0

    # TODO: Add ability to multiply mode bins
    def multiply(self, scalar: float):
        """Multiply all binned data by scalar value"""
        new_binned_allan = {}
        for mode in self.binned_allan.keys():
            new_binned_allan[mode] = {}
            for v in self.binned_allan[mode].keys():
                if v == "nu_prime":
                    new_binned_allan[mode][v] = self.binned_allan[mode][v]
                else:
                    new_binned_allan[mode][v] = scalar * self.binned_allan[mode][v]

        return BinnedSpectra(
            fsr_prime=self.fsr_prime,
            f0_prime=self.f0_prime,
            num_spectra=self.num_spectra,
            epoch_time=self.epoch_time,
            binned_data={k: scalar * v for k, v in self.binned_data.items()},
            binned_allan=new_binned_allan,
        )

    def divide(self, scalar: float):
        """Divide all binned data by scalar value"""
        new_binned_allan = {}
        for mode in self.binned_allan.keys():
            new_binned_allan[mode] = {}
            for v in self.binned_allan[mode].keys():
                if v == "nu_prime":
                    new_binned_allan[mode][v] = self.binned_allan[mode][v]
                else:
                    new_binned_allan[mode][v] = self.binned_allan[mode][v] / scalar

        return BinnedSpectra(
            fsr_prime=self.fsr_prime,
            f0_prime=self.f0_prime,
            num_spectra=self.num_spectra,
            epoch_time=self.epoch_time,
            binned_data={k: v / scalar for k, v in self.binned_data.items()},
            binned_allan=new_binned_allan,
        )

    def mode_intersect(self, binned_spectra) -> np.ndarray:
        """
        Convenience method to return intersected modes of current spectra and
        another BinnedSpectra object
        """
        modes = np.intersect1d(
            list(self.binned_data.keys()), list(binned_spectra.binned_data.keys())
        )
        return modes

    def mode_union(self, binned_spectra) -> np.ndarray:
        """
        Method to get the union of all modes of two BinnedSpectra
        """
        modes = np.array(
            list(self.binned_data.keys() | binned_spectra.binned_data.keys())
        )
        return modes

    def subtract_binned_spectra(self, binned_spectra):
        """Subtract a binned spectra"""
        intersected_modes = self.mode_intersect(binned_spectra)
        new_binned_allan = {}
        for mode in intersected_modes:
            new_binned_allan[mode] = {}
            for key in self.binned_allan[mode].keys():
                new_binned_allan[mode][key] = (
                    self.binned_allan[mode][key]
                    - binned_spectra.binned_allan[mode][key]
                )
        new_binned_data = {
            mode: self.binned_data[mode] - binned_spectra.binned_data[mode]
            for mode in intersected_modes
        }
        return BinnedSpectra(
            fsr_prime=(self.fsr_prime + binned_spectra.fsr_prime) / 2,
            f0_prime=(self.f0_prime + binned_spectra.f0_prime) / 2,
            epoch_time=(self.epoch_time + binned_spectra.epoch_time) / 2,
            num_spectra=int((self.num_spectra + binned_spectra.num_spectra) / 2),
            binned_data=new_binned_data,
            binned_allan=new_binned_allan,
        )

    def intersect_binned_spectra(self, binned_spectra):
        """perform intersection with a binned spectrum"""
        intersected_modes = self.mode_intersect(binned_spectra)
        new_binned_allan = {}
        for mode in intersected_modes:
            new_binned_allan[mode] = {}
            for key in self.binned_allan[mode].keys():
                new_binned_allan[mode][key] = (
                    self.binned_allan[mode][key]
                    & binned_spectra.binned_allan[mode][key]
                )

        new_binned_data = {
            mode: self.binned_data[mode] & binned_spectra.binned_data[mode]
            for mode in intersected_modes
        }
        return BinnedSpectra(
            fsr_prime=(self.fsr_prime + binned_spectra.fsr_prime) / 2,
            f0_prime=(self.f0_prime + binned_spectra.f0_prime) / 2,
            num_spectra=(self.num_spectra + binned_spectra.num_spectra),
            binned_data=new_binned_data,
            binned_allan=new_binned_allan,
        )

    def union_binned_spectra(self, binned_spectra):
        """
        Returns a BinnedSpectrum object with union of ModeBins joined
        Args:
            binned_spectra (BinnedSpectra): list of mode indices we want to keep
        Returns:
            BinnedSpectra object with joined modes
        """
        union_modes = self.mode_union(binned_spectra)
        new_binned_data = {}
        new_binned_allan = {}
        for mode in union_modes:
            new_binned_allan[mode] = {}
            if mode in self.binned_data and mode in binned_spectra.binned_data:
                new_binned_data[mode] = (
                    self.binned_data[mode] & binned_spectra.binned_data[mode]
                )
                for key in self.binned_allan[mode].keys():
                    new_binned_allan[mode][key] = (
                        self.binned_allan[mode][key]
                        & binned_spectra.binned_allan[mode][key]
                    )
            elif mode in self.binned_data:
                new_binned_data[mode] = self.binned_data[mode]
                new_binned_allan[mode] = self.binned_allan[mode]
            elif mode in binned_spectra.binned_data:
                new_binned_data[mode] = binned_spectra.binned_data[mode]
                new_binned_allan[mode] = binned_spectra.binned_allan[mode]

        return BinnedSpectra(
            fsr_prime=(self.fsr_prime + binned_spectra.fsr_prime) / 2,
            f0_prime=(self.f0_prime + binned_spectra.f0_prime) / 2,
            epoch_time=(self.epoch_time + binned_spectra.epoch_time) / 2,
            num_spectra=(self.num_spectra + binned_spectra.num_spectra),
            binned_data=new_binned_data,
            binned_allan=new_binned_allan,
        )

    def intersecting_spectrum(self, mode_list: Union[List, Array]):
        """
        Returns a BinnedSpectrum object with those bins that intersect with a list of modes
        Args:
            mode_list (list): list of mode indices we want to keep
        Returns:
            BinnedSpectra object with modes defined in mode_list
        """
        intersected_modes = np.intersect1d(list(self.binned_data.keys()), mode_list)
        new_binned_data = {mode: self.binned_data[mode] for mode in intersected_modes}
        new_binned_allan = {
            mode: {
                key: self.binned_allan[mode][key]
                for key in self.binned_allan[mode].keys()
            }
            for mode in intersected_modes
        }

        return BinnedSpectra(
            fsr_prime=self.fsr_prime,
            f0_prime=self.f0_prime,
            epoch_time=self.epoch_time,
            num_spectra=self.num_spectra,
            binned_data=new_binned_data,
            binned_allan=new_binned_allan,
        )

    def filter_bins(self, threshold: float):
        """
        Filters all bins with a ratio of spectra contributing to bins over
        total spectra in binned spectra object.
        Args:
            threshold (float): between 0 and 1, ratio of bin spectra over total spectra

        Returns:
            BinnedSpectra missing bins with low number of spectra contributions
        """
        if not 0 <= threshold <= 1:
            raise ValueError("Bin filter threshold must be a value between 0 and 1")

        min_spectra = int(threshold * self.num_spectra)
        new_binned_data = {
            k: v
            for k, v in self.binned_data.items()
            if v[0].spectra_in_bin >= min_spectra
        }
        new_binned_allan = {k: self.binned_allan[k] for k in new_binned_data.keys()}

        return BinnedSpectra(
            fsr_prime=self.fsr_prime,
            f0_prime=self.f0_prime,
            epoch_time=self.epoch_time,
            num_spectra=self.num_spectra,
            binned_data=new_binned_data,
            binned_allan=new_binned_allan,
        )

    def _get_stat(self, key: SpectralEnum, stat_type: str) -> np.ndarray:
        """
        Get the statistical information from each bin based on the
        spectral key value and the statistical operation type.
        """
        return_array = np.array(
            [
                getattr(obj, stat_type)
                for value in self.binned_data.values()
                for obj in value
                if obj.key == key.name
            ]
        )

        return return_array

    def _get_stat_allan(self, key: SpectralEnum, stat_type: str) -> np.ndarray:
        """
        Get the Allan stats from each allan bin based on the
        spectral key value and the statistical operation type.
        """
        return_array = np.array(
            [getattr(v[key], stat_type) for v in self.binned_allan.values()]
        )

        return return_array

    @property
    def n_points(self) -> np.ndarray:
        """
        Get n_points from each mode bin and create array
        """
        return np.array([mode[0].n_points for mode in self.binned_data.values()])

    @property
    def nu_prime(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.nu_prime, MEAN)

    @property
    def absorption(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.absorbance, MEAN)

    @property
    def partial_fit(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.partial_fit, MEAN)

    @property
    def xtalk(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.xtalk, MEAN)

    @property
    def residuals(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.residuals, MEAN)

    @property
    def static_compounds(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.static_compounds, MEAN)

    @property
    def nu_prime_std(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.nu_prime, STD)

    @property
    def absorption_std(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.absorbance, STD)

    @property
    def partial_fit_std(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.partial_fit, STD)

    @property
    def xtalk_std(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.xtalk, STD)

    @property
    def residuals_std(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.residuals, STD)

    @property
    def static_compounds_std(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.static_compounds, STD)

    @property
    def nu_prime_std_err(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.nu_prime, STD_ERR)

    @property
    def absorption_std_err(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.absorbance, STD_ERR)

    @property
    def partial_fit_std_err(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.partial_fit, STD_ERR)

    @property
    def xtalk_std_err(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.xtalk, STD_ERR)

    @property
    def residuals_std_err(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.residuals, STD_ERR)

    @property
    def static_compounds_std_err(self) -> np.ndarray:
        return self._get_stat(SpectralEnum.static_compounds, STD_ERR)

    @property
    def nu_prime_avar(self) -> np.ndarray:
        """
        Get the allan variance for nu prime for each mode
        """
        return self._get_stat_allan(SpectralEnum.nu_prime, AVAR)

    @property
    def nu_prime_adev(self) -> np.ndarray:
        """
        Get the allan deviation for nu prime for each mode
        """
        return self._get_stat_allan(SpectralEnum.nu_prime, ADEV)

    @property
    def nu_prime_astderr(self) -> np.ndarray:
        """
        Get the allan standard error for nu prime for each mode
        """
        return self._get_stat_allan(SpectralEnum.nu_prime, ASTDERR)

    @property
    def absorption_avar(self) -> np.ndarray:
        """
        Get the allan variance for absorbance for each mode
        """
        return self._get_stat_allan(SpectralEnum.absorbance, AVAR)

    @property
    def absorption_adev(self) -> np.ndarray:
        """
        Get the allan deviation for absorbance for each mode
        """
        return self._get_stat_allan(SpectralEnum.absorbance, ADEV)

    @property
    def absorption_astderr(self) -> np.ndarray:
        """
        Get the allan standard error for absorbance for each mode
        """
        return self._get_stat_allan(SpectralEnum.absorbance, ASTDERR)

    @property
    def partial_fit_avar(self) -> np.ndarray:
        return self._get_stat_allan(SpectralEnum.partial_fit, AVAR)

    @property
    def partial_fit_adev(self) -> np.ndarray:
        return self._get_stat_allan(SpectralEnum.partial_fit, ADEV)

    @property
    def partial_fit_astderr(self) -> np.ndarray:
        return self._get_stat_allan(SpectralEnum.partial_fit, ASTDERR)

    @property
    def xtalk_avar(self) -> np.ndarray:
        return self._get_stat_allan(SpectralEnum.xtalk, AVAR)

    @property
    def xtalk_adev(self) -> np.ndarray:
        return self._get_stat_allan(SpectralEnum.xtalk, ADEV)

    @property
    def xtalk_astderr(self) -> np.ndarray:
        return self._get_stat_allan(SpectralEnum.xtalk, ASTDERR)

    @property
    def residuals_avar(self) -> np.ndarray:
        return self._get_stat_allan(SpectralEnum.residuals, AVAR)

    @property
    def residuals_adev(self) -> np.ndarray:
        return self._get_stat_allan(SpectralEnum.residuals, ADEV)

    @property
    def residuals_astderr(self) -> np.ndarray:
        return self._get_stat_allan(SpectralEnum.residuals, ASTDERR)

    @property
    def static_compounds_avar(self) -> np.ndarray:
        return self._get_stat_allan(SpectralEnum.static_compounds, AVAR)

    @property
    def static_compounds_adev(self) -> np.ndarray:
        return self._get_stat_allan(SpectralEnum.static_compounds, ADEV)

    @property
    def static_compounds_astderr(self) -> np.ndarray:
        return self._get_stat_allan(SpectralEnum.static_compounds, ASTDERR)

    @property
    def modes(self) -> list:
        return list(self.binned_data.keys())
