========================================
 Guide to Using FeatureSelectorTestSuite
========================================

Overview
--------
`FeatureSelectorTestSuite` is a base class designed for creating standardized tests for sklearn transformer/selector classes.
It is intended to be subclassed for specific feature selector implementations.
This approach ensures consistent testing across different data scenarios including normal, empty,
sparse, and very sparse conditions, for both single task and multi-task cases.

Structure of the Test Suite
---------------------------
- `setUp()`: Initializes the test environment for each test method.
  This method sets up the data and the feature selector instance.
  It is designed to be generic and should not be overridden in subclasses.
- `setup_data()`:
  Prepares various datasets used in testing. This method generates regular data,
  as well as variants with empty modes and varying degrees of sparsity.
- `create_regression_data()`, `create_empty_mode_data()`, `create_sparse_data()`, `create_very_sparse_data()`:
  These static methods generate different types of test data. Do not override.

Implementing a Subclass
-----------------------
When creating a test subclass for a specific feature selector, you should:

1. **Implement `create_selector()`**:
   This method must return an instance of the feature selector being tested.

2. **Override Test Methods**: Implement the following test methods as needed:
   - `test_fit_multitask()`
   - `test_fit_multitask_empty_mode()`
   - `test_fit_multitask_sparse()`
   - `test_fit_multitask_very_sparse()`
   - `test_fit()`
   - `test_fit_empty_mode()`
   - `test_fit_sparse()`
   - `test_fit_very_sparse()`

   These methods should contain assertions and logic specific to the feature selector being tested.
   For instance, checking if the selector correctly processes the data, handles exceptions,
   or processes different data conditions appropriately.

Example Subclass Implementation
--------------------------------
Below is an example of a subclass test for `LassoTransformer`:

.. code-block:: python

    class TestLassoTransformer(FeatureSelectorTestSuite):
        def create_selector(self):
            return LassoTransformer()

        def test_fit_multitask(self):
            self.selector.fit(self.X, self.Y)
            self.assertTrue(hasattr(self.selector, "feature_importances_"))
            self.assertTrue(hasattr(self.selector, "threshold_"))
            assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

        def test_fit_multitask_very_sparse(self):
            with self.assertRaises(ValueError):
                self.selector.fit(self.X, self.Y_very_sparse)