project = "spectral-toolbox"
copyright = "2022, Picarro"
author = "Cheyenne Nelson"

extensions = [
    "sphinx.ext.napoleon",
    "sphinx.ext.autodoc",
    "sphinx.ext.viewcode",
    "sphinx.ext.githubpages",
    "myst_parser",
]

autodoc_typehints = "description"

html_theme = "furo"
