import unittest
import pandas as pd
import numpy as np
from sklearn.datasets import make_regression

from spectral_toolkit.compound_search.transformers.lasso_transformer import (
    LassoTransformer,
)
from spectral_toolkit.compound_search.transformers.r3_transformer import R3Transformer


class FeatureSelectorTestSuite(unittest.TestCase):
    """
    A generic test suite for feature selector classes,
    to be subclassed for specific implementations.

    For a detailed guide on how to use this test suite, refer to the documentation:
    [Documentation Link](../docs/source/feature_selector.rst)
    """

    def setUp(self):
        if type(self) is FeatureSelectorTestSuite:
            self.skipTest("Skip Base Class tests, it's a base class")
        self.setup_data()
        self.selector = self.create_selector()

    def setup_data(self):
        self.X, self.Y = self.create_regression_data()
        self.Y_empty_mode = self.create_empty_mode_data(self.Y)
        self.Y_sparse = self.create_sparse_data(self.Y)
        self.Y_very_sparse = self.create_very_sparse_data(self.Y)
        self.y = self.Y.mean(axis=1)
        self.y_empty_mode = self.Y_empty_mode.mean(axis=1)
        self.y_sparse = self.Y_sparse.mean(axis=1)
        self.y_very_sparse = self.Y_very_sparse.mean(axis=1)

    @staticmethod
    def create_regression_data():
        X, Y = make_regression(
            n_samples=100, n_features=20, noise=0.1, n_targets=2, random_state=42
        )
        return pd.DataFrame(X), Y

    @staticmethod
    def create_empty_mode_data(Y):
        yc = Y.copy()
        yc[0, :] = np.nan
        return yc

    @staticmethod
    def create_sparse_data(Y):
        yc = Y.copy()
        yc[0, 0] = np.nan
        yc[1, 1] = np.nan
        return yc

    @staticmethod
    def create_very_sparse_data(Y):
        np.random.seed(42)

        yc = Y.copy()
        n_rows = yc.shape[0]
        n_cols = yc.shape[1]

        total_elements = n_rows * n_cols
        num_true = int(total_elements * 0.3)
        mask_flat = np.array([True] * num_true + [False] * (total_elements - num_true))
        np.random.shuffle(mask_flat)
        mask = mask_flat.reshape(n_rows, n_cols)
        yc[mask] = np.nan
        return yc

    def create_selector(self):
        """
        Create and return an instance of the feature selector class.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement this method")

    def test_fit_multitask(self):
        """
        Test fitting the selector to multitask data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit_multitask")

    def test_fit_multitask_empty_mode(self):
        """
        Test fitting the selector to multitask data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit_multitask")

    def test_fit_multitask_sparse(self):
        """
        Test fitting the selector to multitask data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit_multitask")

    def test_fit_multitask_very_sparse(self):
        """
        Test fitting the selector to multitask data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit_multitask")

    def test_fit(self):
        """
        Test fitting the selector to single-task data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit")

    def test_fit_empty_mode(self):
        """
        Test fitting the selector to single-task data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit")

    def test_fit_sparse(self):
        """
        Test fitting the selector to single-task data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit")

    def test_fit_very_sparse(self):
        """
        Test fitting the selector to single-task data.
        This method should be implemented in subclasses.
        """
        raise NotImplementedError("Subclasses should implement test_fit")

    def test_transform(self):
        """
        Test transforming the data using the selector.
        """
        self.selector.fit(self.X, self.y)
        transformed = self.selector.transform(self.X)
        assert transformed.shape[1] < self.X.shape[1]
        self.assertIsInstance(transformed, pd.DataFrame)


class TestLassoTransformer(FeatureSelectorTestSuite):
    def create_selector(self):
        return LassoTransformer()

    def test_fit_multitask(self):
        self.selector.fit(self.X, self.Y)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_empty_mode(self):
        with self.assertRaises(ValueError):
            self.selector.fit(self.X, self.Y_empty_mode)

    def test_fit_multitask_sparse(self):
        self.selector.fit(self.X, self.Y_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_very_sparse(self):
        with self.assertRaises(ValueError):
            self.selector.fit(self.X, self.Y_very_sparse)

    def test_fit(self):
        self.selector.fit(self.X, self.y)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_empty_mode(self):
        self.selector.fit(self.X, self.y_empty_mode)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_sparse(self):
        self.selector.fit(self.X, self.y_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_very_sparse(self):
        with self.assertRaises(ValueError):
            self.selector.fit(self.X, self.y_very_sparse)


class TestR3Transformer(FeatureSelectorTestSuite):
    def create_selector(self):
        return R3Transformer()

    def test_fit_multitask(self):
        self.selector.fit(self.X, self.Y)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_empty_mode(self):
        self.selector.fit(self.X, self.Y_empty_mode)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_sparse(self):
        self.selector.fit(self.X, self.Y_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_multitask_very_sparse(self):
        with self.assertRaises(ValueError):
            self.selector.fit(self.X, self.Y_very_sparse)

    def test_fit(self):
        self.selector.fit(self.X, self.y)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_empty_mode(self):
        self.selector.fit(self.X, self.y_empty_mode)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_sparse(self):
        self.selector.fit(self.X, self.y_sparse)
        self.assertTrue(hasattr(self.selector, "feature_importances_"))
        self.assertTrue(hasattr(self.selector, "threshold_"))
        assert isinstance(self.selector.get_feature_names_out(), np.ndarray)

    def test_fit_very_sparse(self):
        with self.assertRaises(ValueError):
            self.selector.fit(self.X, self.y_very_sparse)
