import numpy as np

np.random.seed(42)


def test_log_likelihood():
    from spectral_toolkit.compound_search.scorers.metrics import log_likelihood_metric

    residuals = np.random.rand(100)
    llf = log_likelihood_metric(residuals)
    assert isinstance(llf, float)

    residuals = np.random.rand(100, 5)
    llf = log_likelihood_metric(residuals)
    assert isinstance(llf, np.ndarray)
    assert llf.shape == (5,)


def test_aic_metric():
    from spectral_toolkit.compound_search.scorers.metrics import aic_metric

    residuals = np.random.rand(100)
    aic = aic_metric(residuals, 3)
    assert isinstance(aic, float)

    residuals = np.random.rand(100, 5)
    aic = aic_metric(residuals, 3)
    assert isinstance(aic, np.ndarray)
    assert aic.shape == (5,)


def test_bic_metric():
    from spectral_toolkit.compound_search.scorers.metrics import bic_metric

    residuals = np.random.rand(100)
    bic = bic_metric(residuals, 3)
    assert isinstance(bic, float)

    residuals = np.random.rand(100, 5)
    bic = bic_metric(residuals, 3)
    assert isinstance(bic, np.ndarray)
    assert bic.shape == (5,)


def test_spectrum_score():
    from spectral_toolkit.compound_search.scorers.metrics import spectrum_score_metric

    y_true = np.random.rand(100)
    y_pred = np.random.rand(100)
    ss = spectrum_score_metric(y_true, y_pred)
    assert isinstance(ss, float)

    y_true = np.random.rand(100, 5)
    y_pred = np.random.rand(100, 5)
    ss = spectrum_score_metric(y_true, y_pred)
    assert isinstance(ss, np.ndarray)
    assert ss.shape == (5,)


def test_r2_metric():
    from spectral_toolkit.compound_search.scorers.metrics import r2_metric

    y_real = np.array([3, 4, 5, 6, 7])
    y_pred = np.array([2.8, 4.1, 4.9, 6.2, 6.8])
    r2 = r2_metric(y_real, y_pred)
    assert isinstance(r2, float)
    assert np.isclose(r2, 0.986, atol=1e-3)

    y_true = np.random.rand(100, 5)
    y_pred = np.random.rand(100, 5)
    r2 = r2_metric(y_true, y_pred)
    assert isinstance(r2, np.ndarray)
    assert r2.shape == (5,)


def test_adjusted_r2_metric():
    from spectral_toolkit.compound_search.scorers.metrics import adjusted_r2_metric

    r2 = 0.8
    n = 100
    p = 5
    r2 = adjusted_r2_metric(r2=r2, n=n, p=p)
    assert isinstance(r2, float)
    assert np.isclose(r2, 0.789, atol=0.001)

    r2 = np.array([0.8, 0.9])
    n = 100
    p = 5
    r2 = adjusted_r2_metric(r2=r2, n=n, p=p)
    assert isinstance(r2, np.ndarray)
    assert r2.shape == (2,)
    assert np.allclose(r2, [0.789, 0.894], atol=0.001)


def test_f_statistics_metric():
    from spectral_toolkit.compound_search.scorers.metrics import f_statistics_metric

    y_real = np.array([3, 4, 5, 6, 7])
    y_pred = np.array([2.8, 4.1, 4.9, 6.2, 6.8])
    f = f_statistics_metric(y_real, y_pred, p=2)
    assert isinstance(f, float)
    assert np.isclose(f, 73.857, atol=1e-3)

    y_true = np.random.rand(100, 5)
    y_pred = np.random.rand(100, 5)
    f = f_statistics_metric(y_true, y_pred, p=2)
    assert isinstance(f, np.ndarray)
    assert f.shape == (5,)


def test_f_pvalue_metric():
    from spectral_toolkit.compound_search.scorers.metrics import f_pvalue_metric

    fs = 73.857
    pvalue = f_pvalue_metric(f_statistic=fs, p=2, nobs=5)
    assert isinstance(pvalue, float)
    assert np.isclose(pvalue, 0.013359, atol=1e-3)

    fs = np.array([73.857, 21])
    expected = np.array([0.013359, 0.045455])
    pvalue = f_pvalue_metric(f_statistic=fs, p=2, nobs=5)
    assert isinstance(pvalue, np.ndarray)
    assert pvalue.shape == (2,)
    assert np.allclose(pvalue, expected, atol=1e-3)
