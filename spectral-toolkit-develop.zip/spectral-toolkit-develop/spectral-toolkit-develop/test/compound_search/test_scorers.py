import pytest


@pytest.fixture
def single_regression():
    from sklearn.datasets import make_regression
    from sklearn.linear_model import LinearRegression

    X, y = make_regression(
        n_samples=100, n_features=10, n_informative=5, random_state=0
    )
    model = LinearRegression().fit(X, y)
    return model, X, y


@pytest.fixture
def multitask_regression():
    from sklearn.datasets import make_regression
    from sklearn.linear_model import LinearRegression

    X, Y = make_regression(
        n_samples=100, n_features=10, n_informative=5, n_targets=5, random_state=0
    )
    model = LinearRegression().fit(X, Y)
    return model, X, Y


def test_aic_loss(single_regression, multitask_regression):
    from spectral_toolkit.compound_search.scorers.scorers import aic_loss

    model, X, y = single_regression
    aic = aic_loss(model, X, y)
    assert isinstance(aic, float)

    model, X, Y = multitask_regression
    aic = aic_loss(model, X, Y)
    assert isinstance(aic, float)


def test_bic_loss(single_regression, multitask_regression):
    from spectral_toolkit.compound_search.scorers.scorers import bic_loss

    model, X, y = single_regression
    bic = bic_loss(model, X, y)
    assert isinstance(bic, float)

    model, X, Y = multitask_regression
    bic = bic_loss(model, X, Y)
    assert isinstance(bic, float)


def test_spectrum_score(single_regression, multitask_regression):
    from spectral_toolkit.compound_search.scorers.scorers import spectrum_score

    model, X, y = single_regression
    ss = spectrum_score(model, X, y)
    assert isinstance(ss, float)

    model, X, Y = multitask_regression
    ss = spectrum_score(model, X, Y)
    assert isinstance(ss, float)
