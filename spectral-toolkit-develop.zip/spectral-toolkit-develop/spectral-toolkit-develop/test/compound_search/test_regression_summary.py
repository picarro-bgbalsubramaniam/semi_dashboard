import pandas as pd
import pytest


def test_regression_summary():
    from spectral_toolkit.compound_search.scorers.regression_summary import (
        regression_summary,
    )
    from sklearn.datasets import make_regression

    X, y = make_regression(
        n_samples=100, n_features=10, n_informative=5, random_state=0
    )
    X = pd.DataFrame(X)
    y = pd.Series(y)

    coefs, scores = regression_summary(X, y)
    assert isinstance(coefs, pd.Series)
    assert isinstance(scores, pd.Series)

    X, Y = make_regression(
        n_samples=100, n_features=10, n_informative=5, n_targets=5, random_state=0
    )
    X = pd.DataFrame(X)
    Y = pd.DataFrame(Y)
    coefs, scores = regression_summary(X, Y, multioutput_coefs="raw_values", multioutput_scores="raw_values")
    assert isinstance(coefs, pd.DataFrame)
    assert isinstance(scores, pd.DataFrame)

    coefs, scores = regression_summary(X, Y, multioutput_coefs="uniform_average", multioutput_scores="uniform_average")
    assert isinstance(coefs, pd.Series)
    assert isinstance(scores, pd.Series)

    coefs, scores = regression_summary(X, Y, multioutput_coefs="median", multioutput_scores="median")
    assert isinstance(coefs, pd.Series)
    assert isinstance(scores, pd.Series)

    with pytest.raises(ValueError):
        regression_summary(X, Y.iloc[1:])

    with pytest.raises(NotImplementedError):
        regression_summary(X, Y, multioutput_coefs="foo")

    with pytest.raises(NotImplementedError):
        regression_summary(X, Y, multioutput_scores="BAR")
