from typing import List

import pandas as pd
import pytest
from pydantic import ValidationError
import plotly.graph_objects as go

from contextlib import nullcontext as does_not_raise

from spectral_toolkit.plotting.refit_concentrations_plot import _get_species_list, _add_menu, \
    get_refit_concentrations_plot


@pytest.mark.parametrize(
    "original_columns, refit_columns, original_prefix, refit_prefix, expectation",
    [
        (
                "broadband_gasConcs_180",
                ["lsq_gasConcs_180", "lsq_gasConcs_276"],
                "broadband_gasConcs_",
                "lsq_gasConcs_",
                pytest.raises(ValidationError),
        ),
        (
                ["broadband_gasConcs_180"],
                "lsq_gasConcs_180",
                "broadband_gasConcs_",
                "lsq_gasConcs_",
                pytest.raises(ValidationError),
        ),
        (
                ["broadband_gasConcs_180"],
                ["lsq_gasConcs_180", "lsq_gasConcs_276"],
                ["broadband_gasConcs_"],
                "lsq_gasConcs_",
                pytest.raises(ValidationError),
        ),
        (
                ["broadband_gasConcs_180"],
                ["lsq_gasConcs_180", "lsq_gasConcs_276"],
                "broadband_gasConcs_",
                ["lsq_gasConcs_"],
                pytest.raises(ValidationError),
        ),
        (
                ["broadband_gasConcs_180"],
                ["lsq_gasConcs_180", "lsq_gasConcs_276"],
                "broadband_gasConcs_",
                "lsq_gasConcssssssssssss_",
                pytest.raises(ValueError),
        ),
        (
                ["broadband_gasConcs_180"],
                ["lsq_gasConcs_180", "lsq_gasConcs_276"],
                "broadband_gasConcsssssssssssss_",
                "lsq_gasConcs_",
                pytest.raises(ValueError),
        ),
        (
            ["broadband_gasConcs_180"],
            ["lsq_gasConcs_180", "lsq_gasConcs_276"],
            "broadband_gasConcs_",
            "lsq_gasConcs_",
            does_not_raise(),
        ),
    ]
)
def test_get_species_list(
    original_columns,
    refit_columns,
    original_prefix,
    refit_prefix,
    expectation
):
    """Test _get_species_list function"""
    with expectation:
        species = _get_species_list(
            original_columns=original_columns,
            refit_columns=refit_columns,
            original_prefix=original_prefix,
            refit_prefix=refit_prefix,
        )
        assert isinstance(species, List)
        assert len(original_columns) <= len(species)
        assert len(original_columns) + len(refit_columns) >= len(species)


def test_add_menu():
    with pytest.raises(ValidationError):
        _add_menu("abc", [1, 2, 3], "port")

    with pytest.raises(ValidationError):
        _add_menu(go.Figure(), "abc", "port")

    with pytest.raises(ValidationError):
        _add_menu(go.Figure(), [1, 2, 3], {})

    ret = _add_menu(go.Figure(), [1, 2, 3], "port")

    assert isinstance(ret, go.Figure)
    assert ret.layout
    assert len(ret.layout.updatemenus) > 0


@pytest.mark.parametrize(
    "refit_df, group_by, group_by_selector_label, original_columns_prefix, refit_columns_prefix, expectation",
    [
        (
                pd.Series([1, 2]),
                "port",
                "port",
                "a_",
                "b_",
                pytest.raises(ValidationError),
        ),
        (
                pd.DataFrame(
                    data={
                        '_datetime': pd.to_datetime(["00:00:00", "00:01:00"]),
                        'a_180': [1, 2],
                        'a_170': [1, 2],
                        'b_180': [1, 2],
                        'b_170': [1, 2],
                        'b_33A': [1, 2],
                        'port': [1, 2]
                    }
                ),
                {"port": "port"},
                "port",
                "a_",
                "b_",
                pytest.raises(ValidationError),
        ),
        (
                pd.DataFrame(
                    data={
                        '_datetime': pd.to_datetime(["00:00:00", "00:01:00"]),
                        'a_180': [1, 2],
                        'a_170': [1, 2],
                        'b_180': [1, 2],
                        'b_170': [1, 2],
                        'b_33A': [1, 2],
                        'port': [1, 2]
                    }
                ),
                "port",
                ["a"],
                "a_",
                "b_",
                pytest.raises(ValidationError),
        ),
        (
                pd.DataFrame(
                    data={
                        '_datetime': pd.to_datetime(["00:00:00", "00:01:00"]),
                        'a_180': [1, 2],
                        'a_170': [1, 2],
                        'b_180': [1, 2],
                        'b_170': [1, 2],
                        'b_33A': [1, 2],
                        'port': [1, 2]
                    }
                ),
                "port",
                "port",
                ["a_"],
                "b_",
                pytest.raises(ValidationError),
        ),
        (
                pd.DataFrame(
                    data={
                        '_datetime': pd.to_datetime(["00:00:00", "00:01:00"]),
                        'a_180': [1, 2],
                        'a_170': [1, 2],
                        'b_180': [1, 2],
                        'b_170': [1, 2],
                        'b_33A': [1, 2],
                        'port': [1, 2]
                    }
                ),
                "port",
                "port",
                "a_",
                {"b_": "_b"},
                pytest.raises(ValidationError),
        ),
        (
                pd.DataFrame(
                    data={
                        'date': pd.to_datetime(["00:00:00", "00:01:00"]),
                        'a_180': [1, 2],
                        'a_170': [1, 2],
                        'b_180': [1, 2],
                        'b_170': [1, 2],
                        'b_33A': [1, 2],
                        'port': [1, 2]
                    }
                ),
                "port",
                "port",
                "a_",
                "b_",
                pytest.raises(ValueError),
        ),
        (
                pd.DataFrame(
                    data={
                        '_datetime': pd.to_datetime(["00:00:00", "00:01:00"]),
                        'a_180': [1, 2],
                        'a_170': [1, 2],
                        'b_180': [1, 2],
                        'b_170': [1, 2],
                        'b_33A': [1, 2],
                        'port': [1, 2]
                    }
                ),
                "ValveMask",
                "port",
                "a_",
                "b_",
                pytest.raises(ValueError),
        ),
        (
                pd.DataFrame(
                    data={
                        '_datetime': pd.to_datetime(["00:00:00", "00:01:00"]),
                        'a_180': [1, 2],
                        'a_170': [1, 2],
                        'b_180': [1, 2],
                        'b_170': [1, 2],
                        'b_33A': [1, 2],
                        'port': [1, 2]
                    }
                ),
                "port",
                "port",
                "c_",
                "b_",
                pytest.raises(ValueError),
        ),
        (
                pd.DataFrame(
                    data={
                        '_datetime': pd.to_datetime(["00:00:00", "00:01:00"]),
                        'a_180': [1, 2],
                        'a_170': [1, 2],
                        'b_180': [1, 2],
                        'b_170': [1, 2],
                        'b_33A': [1, 2],
                        'port': [1, 2]
                    }
                ),
                "port",
                "port",
                "a_",
                "c_",
                pytest.raises(ValueError),
        ),
        (
            pd.DataFrame(
                data={
                    '_datetime': pd.to_datetime(["00:00:00", "00:01:00"]),
                    'a_180': [1, 2],
                    'a_170': [1, 2],
                    'b_180': [1, 2],
                    'b_170': [1, 2],
                    'b_33A': [1, 2],
                    'port': [1, 2]
                }
            ),
            "port",
            "port",
            "a_",
            "b_",
            does_not_raise(),
        ),
    ]
)
def test_get_refit_concentrations_plot(
    refit_df,
    group_by,
    group_by_selector_label,
    original_columns_prefix,
    refit_columns_prefix,
    expectation
):
    """Test get_refit_concentrations_plot function"""
    with expectation:
        fig = get_refit_concentrations_plot(
            refit_df=refit_df,
            group_by=group_by,
            group_by_selector_label=group_by_selector_label,
            original_columns_prefix=original_columns_prefix,
            refit_columns_prefix=refit_columns_prefix
        )
        assert isinstance(fig, go.Figure)
        assert fig.data
        assert fig.layout
