from contextlib import nullcontext as does_not_raise
from typing import List

import numpy as np
import plotly.graph_objects as go
import pytest
import xarray as xr
from pydantic import ValidationError

from spectral_toolkit.constants.plotting_constants import Averaging
from spectral_toolkit.plotting.summary_plot import (_adjust_layout,
                                                    _get_averaging_from_xray,
                                                    _get_row_heights,
                                                    _get_subplots_variables,
                                                    _set_sections_annotations,
                                                    get_summary_plot)


@pytest.mark.parametrize(
    "sensor_vars, species_vars, columns_number, expectation",
    [
        (
            {},
            ["efg", "ghi"],
            4,
            pytest.raises(ValidationError),
        ),
        (
            ["abc", "cde"],
            {},
            4,
            pytest.raises(ValidationError),
        ),
        (
            ["abc", "cde"],
            ["efg", "ghi"],
            {},
            pytest.raises(ValidationError),
        ),
        (
            ["abc", "cde"],
            ["efg", "ghi"],
            4,
            does_not_raise(),
        ),
        (
            ["abc", "cde"],
            ["efg", "ghi"],
            2,
            does_not_raise(),
        )
    ],
)
def test_get_subplots_variables(sensor_vars, species_vars, columns_number, expectation):
    """Run parametrized test on _get_subplots_variables"""
    with expectation:
        result = _get_subplots_variables(sensor_vars, species_vars, columns_number)
        assert isinstance(result, List)
        assert set(sensor_vars+species_vars).issubset(result)
        assert len(result) >= columns_number


@pytest.mark.parametrize(
    "plotly_subplot_figure, subplots_names, expectation",
    [
        (
            {},
            ["s1", "s2", '', '', 'c1', 'c2', 'c3'],
            pytest.raises(ValidationError),
        ),
        (
            (2, 2),
            "abc",
            pytest.raises(ValidationError),
        ),
        (
            (4, 3),
            ["s1", "s2", '', '', '', '', '', '', 'c1', 'c2', 'c3'],
            does_not_raise(),
        ),
        (
            (2, 4),
            ["s1", "s2", '', '', 'c1', 'c2', 'c3'],
            does_not_raise(),
        ),
        (
            (6, 4),
            ["s1", "s2", '', '', '', '', '', '', '', '', '', '', 'c1', 'c2', 'c3'],
            does_not_raise(),
        )
    ],
    indirect=["plotly_subplot_figure"]
)
def test_set_sections_annotations(plotly_subplot_figure, subplots_names, expectation):
    """Run parametrized test on _get_subplots_variables"""
    with expectation:
        result = _set_sections_annotations(plotly_subplot_figure, subplots_names)
        assert isinstance(result, go.Figure)

        annotations = [annot.text for annot in result.layout.annotations]
        assert {'<b>Concentration data</b>', '<b>Sensor data</b>'}.issubset(annotations)


@pytest.mark.parametrize(
    "plotly_subplot_figure, subplots_names, expectation",
    [
        (
            {},
            ["s1", "s2", '', '', 'c1', 'c2', 'c3'],
            pytest.raises(ValidationError),
        ),
        (
            (2, 2),
            "abc",
            pytest.raises(ValidationError),
        ),
        (
            (4, 3),
            ["s1", "s2", '', '', '', '', '', '', 'c1', 'c2', 'c3'],
            does_not_raise(),
        ),
        (
            (2, 4),
            ["s1", "s2", '', '', 'c1', 'c2', 'c3'],
            does_not_raise(),
        ),
        (
            (6, 4),
            ["s1", "s2", '', '', '', '', '', '', '', '', '', '', 'c1', 'c2', 'c3'],
            does_not_raise(),
        )
    ],
    indirect=["plotly_subplot_figure"]
)
def test_adjust_layout(plotly_subplot_figure, subplots_names, expectation):
    """Run parametrized test on _adjust_layout"""
    with expectation:
        result = _adjust_layout(plotly_subplot_figure, subplots_names)
        assert isinstance(result, go.Figure)

        assert result.layout.title.text

        for axis_index in range(1, len(subplots_names) + 1):
            assert result.layout[f"xaxis{axis_index}"].showline
            assert result.layout[f"xaxis{axis_index}"].mirror
            assert result.layout[f"yaxis{axis_index}"].showline
            assert result.layout[f"yaxis{axis_index}"].mirror


@pytest.mark.parametrize(
    "rows_no, cols_no, concentration_vars_count, expectation",
    [
        (
            "abc",
            4,
            3,
            pytest.raises(ValidationError),
        ),
        (
            3,
            [],
            3,
            pytest.raises(ValidationError),
        ),
        (
            3,
            4,
            {},
            pytest.raises(ValidationError),
        ),
        (
            3,
            4,
            3,
            does_not_raise(),
        ),
        (
            5,
            4,
            5,
            does_not_raise(),
        ),
        (
            6,
            3,
            4,
            does_not_raise(),
        )
    ]
)
def test_get_row_heights(rows_no, cols_no, concentration_vars_count, expectation):
    """Run parametrized test on _get_row_heights"""
    with expectation:
        result = _get_row_heights(rows_no, cols_no, concentration_vars_count)
        assert isinstance(result, List)
        assert len(result) == rows_no
        assert np.isclose(sum(result), 1.0)


@pytest.mark.parametrize(
    "resampled_xr, expectation",
    [
        (
            "abc",
            pytest.raises(ValidationError),
        ),
        (
            xr.DataArray(),
            pytest.raises(ValidationError),
        ),
        (
            xr.Dataset(attrs={"requested_avg": Averaging.ONE_MINUTE}),
            does_not_raise(),
        ),
        (
            xr.Dataset(attrs={"requested_avg": Averaging.TEN_SECONDS}),
            does_not_raise(),
        ),
        (
            xr.Dataset(),
            does_not_raise(),
        )
    ]
)
def test_get_averaging_from_xray(resampled_xr, expectation):
    """Run parametrized test on _get_averaging_from_xray"""
    with expectation:
        result = _get_averaging_from_xray(resampled_xr)
        assert isinstance(result, str)
        assert len(result) > 0


@pytest.mark.parametrize(
    "fake_plotting_xray, colorscale_port, columns_no, expectation",
    [
        (
            100,
            {"port1": "rgb(0,0,0)", "port2": "rgb(0,0,0)", "port3": "rgb(0,0,0)"},
            4,
            pytest.raises(ValidationError),
        ),
        (
            0,
            "abc",
            4,
            pytest.raises(ValidationError),
        ),
        (
            0,
            {"port1": "rgb(0,0,0)", "port2": "rgb(0,0,0)", "port3": "rgb(0,0,0)"},
            {},
            pytest.raises(ValidationError),
        ),
        (
            1,
            {"port1": "rgb(0,0,0)", "port2": "rgb(0,0,0)", "port3": "rgb(0,0,0)"},
            4,
            pytest.raises(ValueError),
        ),
        (
            2,
            {"port1": "rgb(0,0,0)", "port2": "rgb(0,0,0)", "port3": "rgb(0,0,0)"},
            4,
            pytest.raises(ValueError),
        ),
        (
            3,
            {"port1": "rgb(0,0,0)", "port2": "rgb(0,0,0)", "port3": "rgb(0,0,0)"},
            4,
            pytest.raises(ValueError),
        ),
        (
            4,
            {"port1": "rgb(0,0,0)", "port2": "rgb(0,0,0)", "port3": "rgb(0,0,0)"},
            4,
            pytest.raises(ValueError),
        ),
        (
            5,
            {"port1": "rgb(0,0,0)", "port2": "rgb(0,0,0)", "port3": "rgb(0,0,0)"},
            4,
            pytest.raises(ValueError),
        ),
        (
            6,
            {"port1": "rgb(0,0,0)", "port2": "rgb(0,0,0)", "port3": "rgb(0,0,0)"},
            4,
            pytest.raises(ValueError),
        ),
        (
            7,
            {"port1": "rgb(0,0,0)", "port2": "rgb(0,0,0)", "port3": "rgb(0,0,0)"},
            4,
            pytest.raises(ValueError),
        ),
        (
            8,
            {"port1": "rgb(0,0,0)", "port2": "rgb(0,0,0)", "port3": "rgb(0,0,0)"},
            4,
            pytest.raises(ValueError),
        ),
        (
            9,
            {"port1": "rgb(0,0,0)", "port2": "rgb(0,0,0)", "port3": "rgb(0,0,0)"},
            4,
            pytest.raises(ValueError),
        ),
        (
                0,
                {"port1": "rgb(0,0,0)", "port2": "rgb(0,0,0)"},
                4,
                pytest.raises(ValueError),
        ),
        (
                0,
                {"port1": "rgb(0,0,0)", "port2": "rgb(0,0,0)", "port3": "rgb(0,0,0)"},
                0,
                pytest.raises(ValueError),
        ),
        (
            0,
            {"port1": "rgb(0,0,0)", "port2": "rgb(0,0,0)", "port3": "rgb(0,0,0)"},
            4,
            does_not_raise(),
        )
    ],
    indirect=["fake_plotting_xray"]
)
def test_get_summary_plot(fake_plotting_xray, colorscale_port, columns_no, expectation):
    """Run parametrized test on get_summary_plot"""

    with expectation:
        result = get_summary_plot(fake_plotting_xray, colorscale_port, columns_no)

        assert isinstance(result, go.Figure)
        assert len(result.data) == 15

