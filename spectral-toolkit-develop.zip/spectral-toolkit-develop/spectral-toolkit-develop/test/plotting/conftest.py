"""Create fixtures for plotting tests"""
from enum import Enum

import numpy as np
import pandas as pd
import pytest
import xarray as xr
from plotly.subplots import make_subplots

from spectral_toolkit.constants.plotting_constants import AveragesSelection, Averaging

from spectral_toolkit.df_operations.timeline_aggregations_xarray import resample_dataset_xr
from spectral_toolkit.df_operations.timeline_process_xarray import timeseries_df_to_xarray


class FakeXrayTestsPlotting(Enum):
    """Create different xray situations"""

    OK = 0
    NO_TIME = 1
    NO_PORT = 2
    NO_VARIABLE_NAME = 3
    NO_VARIABLE_VALUE = 4
    NO_DATETIME = 5
    NO_DATA_POINTS = 6
    NO_REQUESTED_AVG_ATTR = 7
    NO_SENSORS_VARS_ATTR = 8
    NO_SPECIES_VARS_ATTR = 9


@pytest.fixture(name="fake_frequency")
def fixture_fake_frequency():
    """Fake time frequency used in the timeseries tests"""
    return 1.45


@pytest.fixture(name="fake_sigma")
def fixture_fake_sigma():
    """Fake instrument sigma used in tests"""
    return 35.1


@pytest.fixture(name="fake_unpivoted_data_frame")
def fixture_fake_unpivoted_data_frame(fake_frequency):
    """Fake Pandas dataframe used in tests"""
    freq_assert = fake_frequency
    len_array = 987
    np.random.seed(42)

    idx1 = pd.date_range("2022-04-18", periods=len_array, freq=f"{freq_assert}S")

    values = np.linspace(-10, -5, len_array) + np.random.normal(
        0, np.sqrt(5), len(idx1)
    )

    # Assign port numbers (each port number can have different sampling duration)
    port_gen = np.concatenate([np.repeat(1, 50), np.repeat(2, 64), np.repeat(3, 88)])
    port = np.concatenate(
        [port_gen, port_gen, port_gen, port_gen, port_gen, port_gen, port_gen]
    )[:len_array]

    # Create pandas dataframe. Most port data from DataProcessor will have this format
    df_test = pd.DataFrame(
        data={"values": values, "port": port, "_datetime": idx1.to_series()}
    )
    return df_test


@pytest.fixture(name="fake_data_frame")
def fixture_fake_data_frame(fake_unpivoted_data_frame):
    """Fake pivoted Pandas dataframe used in tests"""

    # We NEED to pivot the dataframe to generate one column (trace) for every port
    pivot_on = "port"
    df_pivot = fake_unpivoted_data_frame.pivot(
        index="_datetime", columns=pivot_on, values="values"
    ).add_prefix(pivot_on)
    df_pivot.columns = df_pivot.columns.get_level_values(0)

    return df_pivot


@pytest.fixture(name="fake_series")
def fixture_fake_series(fake_data_frame):
    """Fake series used in tests (extracted from fake dataframe)"""
    return fake_data_frame.port1


@pytest.fixture(name="fake_color_assignment")
def fixture_fake_color_assignment():
    """Fake color assignment for tests"""
    color_assignment = {
        "port1": "rgb(255,0,0)",
        "port2": "rgb(0,255,0)",
        "port3": "rgb(0,0,255)",
    }
    return color_assignment


@pytest.fixture(name="fake_plotting_requests")
def fixture_fake_plotting_requests():
    """Fake plot template assignment for tests"""
    plotting_requests = [
        AveragesSelection("6H", 6, [Averaging.TEN_SECONDS.value]),
    ]
    return plotting_requests


@pytest.fixture(name="fake_fit_solutions")
def fixture_fake_fit_solutions():
    """Fake fit solution data"""
    solutions_df = pd.DataFrame(
        data={
            "CID_0": [np.NaN, 12160],
            "conc_CID0": [np.NaN, 0.7],
            "conc_rcid180": [0.7, 3.1],
            "offset": [0.5, 0.2],
            "rmse": [1e-3, 1e-2],
            "negative_penalty": [0.3, 0.6],
            "model_functions_std": [0.3, 0.6],
            "wrmse": [0.3, 0.6],
            "relative_error": [0.3, 0.6],
            "span": [0.3, 0.6],
            "relative_contribution": [0.3, 0.6],
            "allan_dev": [0.3, 0.6],
            "rmse_over_allan": [0.3, 0.6],
            "new_comps": [[0], [12160]],
            "new_comps_display": [[], [12160]],
            "new_comps_count": [0, 1],
            "rank_by_cid_count": [0, 1],
            "ranking": [0, 1]
        },
    )
    return solutions_df


@pytest.fixture(name="fake_fit_experimental_datapoints")
def fixture_fake_fit_experimental_datapoints():
    """Fake fit fake_fit_experimental_datapoints"""
    experimental_datapoints = pd.Series(
        index=[5851, 5900, 5950, 6000], data=[3.1, 2, 4, 9]
    )
    return experimental_datapoints


@pytest.fixture(name="fake_summary_data")
def fixture_fake_summary_data():
    """Fake fit summary data"""
    summary_table = pd.DataFrame(data={"rmse": [1, 2, 3]})
    summary_table.index.name = "solution"
    summary_table.columns.name = "fit_parameters"
    return summary_table


@pytest.fixture(name="fake_dataset")
def fixture_fake_dataset(fake_summary_data):
    """Fake fit dataset"""
    temp = xr.Dataset(
        {
            "loss_scaled_cids": (
                ["wavenumber", "cid", "solution"],
                np.random.rand(6, 3, 3),
            ),
            "loss_cids": (["wavenumber", "cid"], np.random.rand(6, 3)),
            "concentrations_cids": (["solution", "cid"], np.random.rand(3, 3)),
            "summary_table": fake_summary_data,
            "new_cids": (["solution"], [0, 1, 2]),
            "new_cids_display": (["solution"], [0, 1, 2]),
            "experimental_loss_cids": (
                ["experimental_wavenumber", "cid"],
                np.random.rand(5, 3),
            ),
            "experimental_loss": (["experimental_wavenumber"], np.random.rand(5)),
        },
        coords={
            "wavenumber": np.random.rand(6),
            "cid": [180, 181, 182],
            "solution": [0, 1, 2],
            "experimental_wavenumber": [0, 1, 2, 3, 4],
            "new_cids_count": (("solution"), [0, 1, 1]),
            "ranking_by_cid_count": (("solution"), [0, 1, 2])
        },
    )
    return temp


@pytest.fixture(name="plotly_subplot_figure")
def fixture_plotly_subplot_figure(request):
    """
    Fake Plotly figure.
    """
    if len(request.param) == 2:
        fig = make_subplots(rows=request.param[0], cols=request.param[1])
    else:
        fig = "abc"
    return fig


@pytest.fixture(name="datagen")
def fixture_datagen():
    """
    Fake data generator.
    """
    freq_assert = 1.45
    len_array = 250
    np.random.seed(42)

    idx1 = pd.date_range("2022-04-18", periods=len_array, freq=f"{freq_assert}S")

    values = np.linspace(-10, -5, len_array) + np.random.normal(
        0, np.sqrt(5), len(idx1)
    )

    sensors = np.linspace(80, 80, len_array) + np.random.normal(
        0, np.sqrt(5), len(idx1)
    )

    # Assign port numbers (each port number can have different sampling duration)
    port_gen = np.concatenate(
        [np.repeat("port1", 50), np.repeat("port2", 64), np.repeat("port3", 88)]
    )

    port = np.concatenate(
        [port_gen, port_gen, port_gen, port_gen, port_gen, port_gen, port_gen]
    )[:len_array]

    # Create pandas dataframe. Most port data from DataProcessor will have this format
    df_test = pd.DataFrame(
        data={
            "values1": values,
            "values2": values[::-1],
            "values3": 2 * values,
            "sensor1": sensors,
            "sensor2": 2 * sensors[::-1],
            "port": port,
            "_datetime": idx1.to_series(),
        }
    )
    df_test = df_test.set_index("_datetime")
    return df_test


@pytest.fixture(name="fake_plotting_xray")
def fixture_fake_plotting_xray(datagen, request):
    """Fake Xray used in tests"""

    result_test_xr = timeseries_df_to_xarray(
        timeseries_df=datagen,
        port_col="port",
        sensor_cols=["sensor1", "sensor2"],
        species_cols=["values1", "values2", "values3"],
    )

    resampled_xr = resample_dataset_xr(
        dataset_xr=result_test_xr,
        data_variable="variable_value",
        averaging_request=Averaging.TEN_SECONDS,
        min_count=0
    )

    returned_xr = resampled_xr.copy()

    if request.param == FakeXrayTestsPlotting.OK.value:
        pass
    elif request.param == FakeXrayTestsPlotting.NO_PORT.value:
        returned_xr = returned_xr.drop_dims("port")
    elif request.param == FakeXrayTestsPlotting.NO_TIME.value:
        returned_xr = returned_xr.drop_dims("time")
    elif request.param == FakeXrayTestsPlotting.NO_VARIABLE_NAME.value:
        returned_xr = returned_xr.drop_dims("variable_name")
    elif request.param == FakeXrayTestsPlotting.NO_VARIABLE_VALUE.value:
        returned_xr = returned_xr.drop_vars("variable_value")
    elif request.param == FakeXrayTestsPlotting.NO_DATA_POINTS.value:
        returned_xr = returned_xr.drop_vars("data_points")
    elif request.param == FakeXrayTestsPlotting.NO_REQUESTED_AVG_ATTR.value:
        returned_xr.attrs.pop("requested_avg")
    elif request.param == FakeXrayTestsPlotting.NO_SENSORS_VARS_ATTR.value:
        returned_xr.attrs.pop("sensor_vars")
    elif request.param == FakeXrayTestsPlotting.NO_SPECIES_VARS_ATTR.value:
        returned_xr.attrs.pop("species_vars")
    elif request.param == FakeXrayTestsPlotting.NO_DATETIME.value:
        returned_xr["time"] = returned_xr.time.astype(int)
    else:
        returned_xr = "abc"

    return returned_xr
