"""Test spectral fits results aggregation"""
from contextlib import contextmanager
from typing import List
from unittest import mock

import numpy as np
import pandas as pd
import pytest
import xarray as xr
from pydantic import ValidationError
from pymongo import database
from scipy.interpolate import interp1d

from spectral_toolkit.df_operations.spectral_fits_results_aggregation import (
    _arrange_new_comps_column,
    _assign_ranking,
    _get_cids_spectra,
    _get_fits_new_cids_xray,
    _get_fits_summary_table_xray,
    _get_initial_species_cids,
    _get_new_cids,
    _get_new_cids_concentrations_df,
    _get_starting_cids_concentrations_df,
    _get_wavefunction_per_fit,
    define_solutions_spectral_dataset,
    get_all_cids_list,
    get_stacked_cids_concentrations_df,
    get_stacked_fit_solutions,
)


@contextmanager
def does_not_raise():
    yield


@pytest.mark.parametrize(
    "input,expectation",
    [
        (
            pd.DataFrame(data={"CID_0": [280, 281], "CID_1": [281, np.NaN]}),
            does_not_raise(),
        ),
        (0, pytest.raises(ValidationError)),
    ],
)
def test_arrange_new_comps_column(input, expectation):
    """Test _arrange_new_comps_column"""
    with expectation:
        assert isinstance(_arrange_new_comps_column(input), pd.DataFrame)
        assert "new_comps" in _arrange_new_comps_column(input).columns
        assert "new_comps_display" in _arrange_new_comps_column(input).columns


@pytest.mark.parametrize(
    "input1,input2,expectation",
    [
        (
            pd.DataFrame(data={"sortme": [280, 281]}),
            "sortme",
            does_not_raise(),
        ),
        (
            pd.DataFrame(data={"sortme": [280, 281]}),
            {},
            pytest.raises(ValidationError),
        ),
        (
            0,
            "sortme",
            pytest.raises(ValidationError),
        ),
        (
            pd.DataFrame(data={"sortme": [280, 281]}),
            "abc",
            pytest.raises(ValueError),
        ),
    ],
)
def test_assign_ranking(input1, input2, expectation):
    """Test _arrange_new_comps_column"""
    with expectation:
        assert isinstance(_assign_ranking(input1, input2), pd.DataFrame)
        assert "ranking" in _assign_ranking(input1, input2).columns


@pytest.mark.parametrize(
    "original_in, additional_in, sortby_in, expectation",
    [
        (
            pd.DataFrame(data={"rcid_1": [1], "rcid_2": [2], "performance": [4]}),
            [
                pd.DataFrame(
                    data={
                        "rcid_1": [0.8, 0.9],
                        "rcid_2": [1.6, 0.8],
                        "CID_0": [180, 182],
                        "conc_CID0": [4, 6],
                        "performance": [3, 1],
                    }
                )
            ],
            "performance",
            does_not_raise(),
        ),
        (
            pd.DataFrame(data={"rcid_1": [1], "rcid_2": [2], "performance": [4]}),
            [
                pd.DataFrame(
                    data={
                        "rcid_1": [0.8, 0.9],
                        "rcid_2": [1.6, 0.8],
                        "CID_0": [180, 182],
                        "conc_CID0": [4, 6],
                        "performance": [3, 1]
                    }
                )
            ],
            {},
            pytest.raises(ValidationError),
        ),
        (
            pd.DataFrame(data={"rcid_1": [1], "rcid_2": [2], "performance": [4]}),
            {},
            "performance",
            pytest.raises(ValidationError),
        ),
        (
            {},
            [
                pd.DataFrame(
                    data={
                        "rcid_1": [0.8, 0.9],
                        "rcid_2": [1.6, 0.8],
                        "CID_0": [180, 182],
                        "conc_CID0": [4, 6],
                        "performance": [3, 1],
                    }
                )
            ],
            "performance",
            pytest.raises(ValidationError),
        ),
        (
            pd.DataFrame(data={"rcid_1": [1], "rcid_2": [2], "performance": [4]}),
            [
                pd.DataFrame(
                    data={
                        "rcid_1": [0.8, 0.9],
                        "rcid_2": [1.6, 0.8],
                        "CID_0": [180, 182],
                        "conc_CID0": [4, 6],
                        "performance": [3, 1],
                    }
                )
            ],
            "wrmse",
            pytest.raises(ValueError),
        ),
    ],
)
def test_get_stacked_fit_solutions(original_in, additional_in, sortby_in, expectation):
    """Test get_stacked_fit_solutions"""
    with expectation:
        assert isinstance(
            get_stacked_fit_solutions(
                original_fit_solution_df=original_in,
                additional_fit_solutions=additional_in,
                sort_by=sortby_in,
            ),
            pd.DataFrame,
        )
        assert (
            "new_comps"
            in get_stacked_fit_solutions(
                original_fit_solution_df=original_in,
                additional_fit_solutions=additional_in,
                sort_by=sortby_in,
            ).columns
        )
        assert (
            "new_comps_display"
            in get_stacked_fit_solutions(
                original_fit_solution_df=original_in,
                additional_fit_solutions=additional_in,
                sort_by=sortby_in,
            ).columns
        )


@pytest.mark.parametrize(
    "input,expectation",
    [
        (
            pd.DataFrame(data={"new_comps": [[204, 91], [0, 204]]}),
            does_not_raise(),
        ),
        (
            pd.DataFrame(data={"abc": [[205, 601], [13, 205]]}),
            pytest.raises(ValueError),
        ),
        (0, pytest.raises(ValidationError)),
    ],
)
def test_get_new_cids(input, expectation):
    """Test _get_new_cids"""
    with expectation:
        assert isinstance(_get_new_cids(input), List)
        assert set(_get_new_cids(input)) == set([204, 91])


@pytest.mark.parametrize(
    "input1,input2,expectation",
    [
        (
            pd.DataFrame(data={"conc_rcid1801": [1], "conc_rcid18": [10]}),
            "conc",
            does_not_raise(),
        ),
        (
            "abc",
            "conc",
            pytest.raises(ValidationError),
        ),
        (
            pd.DataFrame(data={"conc_rcid180": [1], "conc_rcid1645": [10]}),
            {},
            pytest.raises(ValidationError),
        ),
    ],
)
def test_get_initial_species_cids(input1, input2, expectation):
    """Test _get_initial_species_cids"""
    with expectation:
        assert isinstance(_get_initial_species_cids(input1, input2), List)
        assert set(_get_initial_species_cids(input1, input2)) == set([1801, 18])


@pytest.mark.parametrize(
    "input,expectation",
    [
        (
            pd.DataFrame(
                data={"conc_rcid180": [1], "conc_rcid1645": [10], "test": [[604, 13]]}
            ),
            pytest.raises(ValueError),
        ),
        (
            pd.DataFrame(
                data={
                    "conc_rcid180": [1, 1],
                    "conc_rcid1645": [10, 1],
                    "new_comps": [[604, 13], [901, 13]],
                }
            ),
            does_not_raise(),
        ),
        (0, pytest.raises(ValidationError)),
    ],
)
def test_get_all_cids_list(input, expectation):
    """Test get_all_cids_list"""
    with expectation:
        assert isinstance(get_all_cids_list(input), List)
        assert set(get_all_cids_list(input)) == set([180, 1645, 604, 13, 901])


@pytest.mark.parametrize(
    "input1,input2,expectation",
    [
        (
            pd.DataFrame(
                data={
                    "CID_0": [180, 183, 183],
                    "conc_CID0": [0.9, 0.1, 0.1],
                    "CID_1": [15, 180, 0],
                    "conc_CID1": [0.3, 0.7, 0],
                    "ranking": [0, 1, 2]
                }),
            "conc",
            does_not_raise(),
        ),
        (
            0,
            "conc",
            pytest.raises(ValidationError),
        ),
        (
            pd.DataFrame(
                data={
                    "CID_0": [180, 183],
                    "conc_CID0": [0.9, 0.1],
                    "CID_1": [15, 180],
                    "conc_CID1": [0.3, 0.7],
                }),
            {},
            pytest.raises(ValidationError),
        ),
    ],
)
def test_get_new_cids_concentrations_df(input1, input2, expectation):
    """Test _get_new_cids_concentrations_df"""
    with expectation:
        result = _get_new_cids_concentrations_df(input1, input2)
        assert isinstance(result, pd.DataFrame)
        assert set(result.columns) == set([180, 183, 15])


@pytest.mark.parametrize(
    "input1,input2,expectation",
    [
        (
            pd.DataFrame(
                data={
                    "conc_rcid180": [0.9, 0.1],
                    "conc_rcid90": [0.3, 0.7],
                    "offset": [0.3, 0.7],
                },
                index=pd.Series(data=range(2), name="ranking"),
            ),
            "conc",
            does_not_raise(),
        ),
        (
            0,
            "conc",
            pytest.raises(ValidationError),
        ),
        (
            pd.DataFrame(
                data={
                    "conc_rcid180": [0.9, 0.1],
                    "conc_rcid90": [0.3, 0.7],
                    "offset": [0.3, 0.7],
                },
                index=pd.Series(data=range(2), name="ranking"),
            ),
            {},
            pytest.raises(ValidationError),
        ),
    ],
)
def test_get_starting_cids_concentrations_df(input1, input2, expectation):
    """Test _get_starting_cids_concentrations_df"""
    with expectation:
        result = _get_starting_cids_concentrations_df(input1, input2)
        assert isinstance(result, pd.DataFrame)
        assert set(result.columns) == set(["180", "90", "offset"])


@pytest.mark.parametrize(
    "input1,input2,expectation",
    [
        (
            pd.DataFrame(
                data={
                    "conc_rcid180": [0.9, 0.1],
                    "conc_rcid90": [0.3, 0.7],
                    "CID_0": [185, 31],
                    "conc_CID0": [0.7, 3.1],
                    "offset": [0.5, 0.2],
                    "CID_1": [185, 31],
                    "conc_CID1": [0.9, -0.2],
                    "ranking": [0, 1]
                },
            ),
            "conc",
            does_not_raise(),
        ),
        (
            0,
            "conc",
            pytest.raises(ValidationError),
        ),
        (
            pd.DataFrame(
                data={
                    "conc_rcid180": [0.9, 0.1],
                    "conc_rcid90": [0.3, 0.7],
                    "CID_0": [185, 31],
                    "conc_CID0": [0.7, 3.1],
                    "offset": [0.5, 0.2],
                    "CID_1": [185, 31],
                    "conc_CID1": [0.9, -0.2],
                    "ranking": [0, 1]
                },
            ),
            {},
            pytest.raises(ValidationError),
        ),
    ],
)
def test_get_stacked_cids_concentrations_df(input1, input2, expectation):
    """Test get_stacked_cids_concentrations_df"""
    with expectation:
        result = get_stacked_cids_concentrations_df(input1, input2)
        assert isinstance(result, pd.DataFrame)
        assert set(result.columns) == set(["180", "90", "31", "185", "offset"])


def test_get_cids_spectra(mocker):
    mock_db = mock.MagicMock(spec=database.Database)
    cids = [0, 1, 2, 3, 5]
    nu = np.arange(5850, 6150, 100)
    y_fake = np.linspace(0, 10, len(nu))

    mocker.patch(
        "spectral_toolkit.df_operations.spectral_fits_results_aggregation.model_function",
        return_value=interp1d(nu, y_fake),
    )

    ret = _get_cids_spectra(mock_db, cids, nu, add_static_offset_compound=True)
    assert ret.shape == (len(nu), len(cids) + 1)


@pytest.mark.parametrize(
    "input1,input2,expectation",
    [
        (
            np.random.RandomState(42).rand(3, 2),
            3,
            does_not_raise(),
        ),
        (
            {},
            1,
            pytest.raises(ValidationError),
        ),
        (
            np.random.RandomState(42).rand(3, 2),
            {},
            pytest.raises(ValidationError),
        ),
    ],
)
def test_get_wavefunction_per_fit(input1, input2, expectation):
    """Test _get_wavefunction_per_fit"""
    with expectation:
        result = _get_wavefunction_per_fit(
            cids_spectra=input1, ranked_solutions_count=input2
        )
        assert isinstance(result, np.ndarray)
        assert result.shape == (3, 2, 3)


@pytest.mark.parametrize(
    "input1,input2,expectation",
    [
        (
            pd.DataFrame(
                data={
                    "rmse": [0.9, 0.1],
                    "wrmse": [0.3, 0.7],
                    "allan_dev": [185, 31],
                },
                index=pd.Series(data=range(2), name="ranking"),
            ),
            ["wrmse", "rmse"],
            does_not_raise(),
        ),
        (
            {},
            1,
            pytest.raises(ValidationError),
        ),
        (
            pd.DataFrame(
                data={
                    "rmse": [0.9, 0.1],
                    "wrmse": [0.3, 0.7],
                    "allan_dev": [185, 31],
                },
                index=pd.Series(data=range(2), name="ranking"),
            ),
            ["abc", "wrmse"],
            pytest.raises(ValueError),
        ),
    ],
)
def test_get_fits_summary_table_xray(input1, input2, expectation):
    """Test _get_fits_summary_table_xray"""
    with expectation:
        result = _get_fits_summary_table_xray(
            solutions_fit_df=input1, info_columns=input2
        )
        assert isinstance(result, xr.DataArray)
        assert set(result["fit_parameters"].values) == set(input2)


@pytest.mark.parametrize(
    "input1,expectation",
    [
        (
            pd.DataFrame(
                data={
                    "new_comps": [[13, 2], [180, 220]],
                },
                index=pd.Series(data=range(2), name="ranking"),
            ),
            does_not_raise(),
        ),
        (
            {},
            pytest.raises(ValidationError),
        ),
        (
            pd.DataFrame(
                data={
                    "abc": [[13, 2], [180, 220]],
                },
                index=pd.Series(data=range(2), name="ranking"),
            ),
            pytest.raises(ValueError),
        ),
    ],
)
def test_get_fits_new_cids_xray(input1, expectation):
    """Test _get_fits_new_cids_xray"""
    with expectation:
        result = _get_fits_new_cids_xray(solutions_fit_df=input1)
        assert isinstance(result, xr.DataArray)


def test_define_solutions_spectral_dataset(
    fake_fit_solutions, fake_fit_experimental_datapoints, mocker
):
    """Test define_solutions_spectral_dataset"""
    mock_db = mock.MagicMock(spec=database.Database)

    with pytest.raises(ValidationError):
        define_solutions_spectral_dataset(
            db_client="abc",
            solutions_fit_df=fake_fit_solutions,
            experimental_datapoints=fake_fit_experimental_datapoints,
            evaluation_nu=np.linspace(0, 100, 5),
            top_n=5,
        )

    with pytest.raises(ValidationError):
        define_solutions_spectral_dataset(
            db_client=mock_db,
            solutions_fit_df="abc",
            experimental_datapoints=fake_fit_experimental_datapoints,
            evaluation_nu=np.linspace(0, 100, 20),
            top_n=5,
        )

    with pytest.raises(ValidationError):
        define_solutions_spectral_dataset(
            db_client=mock_db,
            solutions_fit_df=fake_fit_solutions,
            experimental_datapoints="abc",
            evaluation_nu=np.linspace(0, 100, 20),
            top_n=5,
        )

    with pytest.raises(ValidationError):
        define_solutions_spectral_dataset(
            db_client=mock_db,
            solutions_fit_df=fake_fit_solutions,
            experimental_datapoints=fake_fit_experimental_datapoints,
            evaluation_nu="abc",
            top_n=5,
        )

    with pytest.raises(ValidationError):
        define_solutions_spectral_dataset(
            db_client=mock_db,
            solutions_fit_df=fake_fit_solutions,
            experimental_datapoints=fake_fit_experimental_datapoints,
            evaluation_nu=np.linspace(0, 100, 20),
            top_n="abc",
        )

    nu = np.arange(5850, 6150, 10)
    y_fake = np.linspace(0, 10, len(nu))

    mocker.patch(
        "spectral_toolkit.df_operations.spectral_fits_results_aggregation.model_function",
        return_value=interp1d(nu, y_fake),
    )

    ret = define_solutions_spectral_dataset(
        db_client=mock_db,
        solutions_fit_df=fake_fit_solutions,
        experimental_datapoints=fake_fit_experimental_datapoints,
        evaluation_nu=nu,
        top_n=2,
    )

    assert isinstance(ret, xr.Dataset)
