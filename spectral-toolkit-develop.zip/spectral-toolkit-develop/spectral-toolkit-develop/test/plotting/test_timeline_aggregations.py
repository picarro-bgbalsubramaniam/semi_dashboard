import numpy as np
import pandas as pd
import pytest

from spectral_toolkit.df_operations.timeline_aggregations import (
    get_intervals_statistics,
    get_statistics_on_all_intervals,
)


def test_get_interval_statistics(fake_unpivoted_data_frame):
    """Test get_interval_statistics function"""
    test_df = fake_unpivoted_data_frame

    # Not a dataframe
    with pytest.raises(TypeError):
        get_intervals_statistics("abc")

    # Not a datetimeindex
    with pytest.raises(ValueError):
        get_intervals_statistics(pd.DataFrame(data={"port": [1]}))

    test_df = test_df.set_index("_datetime")

    # No port data
    with pytest.raises(ValueError):
        get_intervals_statistics(
            pd.DataFrame(data={"a": [1]}, index=pd.DatetimeIndex(["2020/01/01"]))
        )

    # No correct target_cols data
    with pytest.raises(ValueError):
        get_intervals_statistics(
            original_unmarked_df=fake_unpivoted_data_frame, target_cols=["abc"]
        )

    # Forbidden column names
    with pytest.raises(ValueError):
        get_intervals_statistics(
            original_unmarked_df=fake_unpivoted_data_frame.rename(
                columns={"values": "concentration"}
            ),
            target_cols=["abc"],
        )

    # All columns numeric
    with pytest.raises(ValueError):
        get_intervals_statistics(
            original_unmarked_df=fake_unpivoted_data_frame.assign(tdata="str"),
            target_cols=["tdata"],
        )

    expected_mean_ub = -6.915629155856981
    expected_mean_lb = -8.007537167389357
    expected_mean_conc = -7.46158316162317
    expected_max_sem = 0.3677336320683536
    expected_min_sem = 0.21847457876391638

    returned_df = get_intervals_statistics(test_df)

    assert np.isclose(
        np.mean(returned_df.upper_bound_ci_concentration), expected_mean_ub
    )
    assert np.isclose(
        np.mean(returned_df.lower_bound_ci_concentration), expected_mean_lb
    )
    assert np.isclose(np.mean(returned_df.concentration_mean), expected_mean_conc)
    assert np.isclose(np.max(returned_df.concentration_sem), expected_max_sem)
    assert np.isclose(np.min(returned_df.concentration_sem), expected_min_sem)


def test_get_statistics_on_all_intervals(fake_unpivoted_data_frame):
    """Test get_statistics_on_all_intervals function"""
    test_df = fake_unpivoted_data_frame
    test_df = test_df.set_index("_datetime")

    # Not a dataframe
    with pytest.raises(TypeError):
        get_statistics_on_all_intervals(df_intervals={}, instrument_sigma_dict={"a": 1})

    # Not a dict
    with pytest.raises(TypeError):
        get_statistics_on_all_intervals(
            df_intervals=pd.DataFrame(data={"port": [1]}), instrument_sigma_dict=1
        )

    # Not a datetimeindex
    with pytest.raises(ValueError):
        get_statistics_on_all_intervals(
            df_intervals=pd.DataFrame(data={"port": [1]}),
            instrument_sigma_dict={"a": 1},
        )

    # No columns data
    with pytest.raises(ValueError):
        get_statistics_on_all_intervals(
            df_intervals=fake_unpivoted_data_frame, instrument_sigma_dict={"a": 1}
        )

    df_intervals = get_intervals_statistics(test_df)

    # All species must be present in instrument_sigma_dict
    with pytest.raises(ValueError):
        get_statistics_on_all_intervals(
            df_intervals=df_intervals, instrument_sigma_dict={"a": 1}
        )

    # instrument_sigma_dict not a dict
    with pytest.raises(TypeError):
        get_statistics_on_all_intervals(
            df_intervals=df_intervals, instrument_sigma_dict="abc"
        )

    result_df = get_statistics_on_all_intervals(
        df_intervals=df_intervals, instrument_sigma_dict={"values": 1.2}
    )

    assert isinstance(result_df, pd.DataFrame)
    assert len(result_df) == 1
    assert np.isclose(result_df[1].concentration_mean, -7.795739)

    test_df = test_df.assign(species2=np.random.normal(5, 0.2, len(test_df)))
    df_intervals = get_intervals_statistics(
        original_unmarked_df=test_df, target_cols=["values", "species2"]
    )

    result_df = get_statistics_on_all_intervals(
        df_intervals=df_intervals,
        instrument_sigma_dict={"values": 1.2, "species2": 4.2},
    )

    assert isinstance(result_df, pd.DataFrame)
    assert len(result_df) == 2
