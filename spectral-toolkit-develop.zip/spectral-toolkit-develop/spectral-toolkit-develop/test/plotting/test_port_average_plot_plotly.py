"""Test port average plots."""
from unittest import mock

import pandas as pd
import pytest
import plotly.graph_objects as go

from spectral_toolkit.df_operations.timeline_aggregations import (
    get_intervals_statistics,
)
from spectral_toolkit.df_operations.timeline_process_df import (
    map_sampling_ports_name,
)
from spectral_toolkit.plotting.port_average_plot_plotly import (
    _get_plotly_make_subplots_specs,
    rgb_to_rgba,
    get_ports_average_plot,
    add_reference_three_sigma,
    add_three_sigma_instrument,
    get_comparison_port_average_plot, _add_menu_dropdowns, PortAvgActiveButton, _toggle_initial_traces_visibility,
)


def test_get_plotly_make_subplot_specs():
    """Test Plotly make_subplots specs"""
    with pytest.raises(TypeError):
        _get_plotly_make_subplots_specs(5.1)

    nports = 4

    test_specs = _get_plotly_make_subplots_specs(nports)

    assert len(test_specs) == nports
    assert isinstance(test_specs, list)


def test_rgb_to_rgba():
    "Test conversion rgb to rgba"
    with pytest.raises(TypeError):
        rgb_to_rgba(5.1, 1.0)

    with pytest.raises(TypeError):
        rgb_to_rgba("abc", "def")

    with pytest.raises(ValueError):
        rgb_to_rgba("abc", 5.2)

    assert isinstance(rgb_to_rgba("rgb(255,255,255)", 1.0), str)


def test_get_ports_average_plot(fake_unpivoted_data_frame, fake_color_assignment):
    """Test inputs format exception and that the return Plotly Figure
    is a figure, with data and layout fields."""

    # Not a dataframe
    with pytest.raises(TypeError):
        get_ports_average_plot([1], {})

    # No _datetime
    with pytest.raises(ValueError):
        get_ports_average_plot(
            pd.DataFrame(data={"a": [1]},
                         index=[pd.to_datetime("05:04:14")])
            , {})

    #  _datetime is not a DateTimeIndex
    with pytest.raises(ValueError):
        df = pd.DataFrame(data={"a": [1]}, index=["abc"])
        df.index.name = "_datetime"
        get_ports_average_plot(df, {})

    #  colorscale is not a dict
    with pytest.raises(TypeError):
        df = pd.DataFrame(data={"a": [1]}, index=[pd.to_datetime("05:04:14")])
        df.index.name = "_datetime"
        get_ports_average_plot(df, traces_colorscale="abc")

    test_df = fake_unpivoted_data_frame
    test_df = test_df.set_index("_datetime")

    test_df = map_sampling_ports_name(
        test_df, {1: "port1", 2: "port2", 3: "port3", 4: "port4"}
    )

    test_df = get_intervals_statistics(test_df)

    ret = get_ports_average_plot(
        data_frame=test_df,
        traces_colorscale=fake_color_assignment,
    )
    assert isinstance(ret, go.Figure)
    assert ret.data
    assert ret.layout

    ret = get_ports_average_plot(
        data_frame=test_df,
        traces_colorscale=fake_color_assignment,
        show_negative_values=True,
        multiline_plot=True,
    )
    assert isinstance(ret, go.Figure)
    assert ret.data
    assert ret.layout


def test_add_reference_three_sigma(fake_series):
    """Test inputs format exception and that the return Plotly Figure
    is a figure, with data and layout fields."""

    with pytest.raises(TypeError):
        add_reference_three_sigma({}, {})

    with pytest.raises(TypeError):
        add_reference_three_sigma(go.Figure(), [1])

    with pytest.raises(ValueError):
        add_reference_three_sigma(go.Figure(), pd.Series(["aaa"]))

    ret_fig = add_reference_three_sigma(
        original_fig=go.Figure(data=go.Scatter(x=[1], y=[1])),
        reference_port_ts=fake_series,
    )
    assert isinstance(ret_fig, go.Figure)
    assert ret_fig.data
    assert ret_fig.layout


def test_add_three_sigma_instrument():
    """Test inputs format exception and that the return Plotly Figure
    is a figure, with data and layout fields."""

    with pytest.raises(TypeError):
        add_three_sigma_instrument(
            original_fig={}, interval_durations={}, instrument_sigma={}
        )

    with pytest.raises(TypeError):
        add_three_sigma_instrument(
            original_fig=go.Figure(), interval_durations={}, instrument_sigma={}
        )

    with pytest.raises(TypeError):
        add_three_sigma_instrument(
            original_fig=go.Figure(),
            interval_durations=pd.Series(["aaa"]),
            instrument_sigma={},
        )

    with pytest.raises(TypeError):
        add_three_sigma_instrument(
            original_fig=go.Figure(),
            interval_durations=pd.Series(data=pd.Timedelta("1 days")),
            instrument_sigma={},
        )

    ret_fig = add_three_sigma_instrument(
        original_fig=go.Figure(data=go.Scatter(x=[1], y=[1])),
        instrument_sigma=12.0,
        interval_durations=pd.Series(data=pd.Timedelta("1 days")),
    )
    assert isinstance(ret_fig, go.Figure)
    assert ret_fig.data
    assert ret_fig.layout


def test_get_comparison_port_average_plot():
    """Test inputs format exception and that the return Plotly Figure
    is a figure, with data and layout fields."""

    with pytest.raises(TypeError):
        get_comparison_port_average_plot(fig_zero_referenced={}, fig_raw={})

    with pytest.raises(TypeError):
        get_comparison_port_average_plot(fig_zero_referenced=go.Figure(), fig_raw={})

    ret_fig = get_comparison_port_average_plot(
        fig_zero_referenced=go.Figure(
            data=go.Scatter(x=[1], y=[1], name="aa", legendgroup="abc")
        ),
        fig_raw=go.Figure(data=go.Scatter(x=[1], y=[1], name="aa", legendgroup="abc")),
    )
    assert isinstance(ret_fig, go.Figure)
    assert ret_fig.data
    assert ret_fig.layout


def test_add_menu_dropdowns():
    """
    Test _add_menu_dropdowns with fake figure.
    """
    fig = go.Figure()
    fig = _add_menu_dropdowns(fig, PortAvgActiveButton.REFERENCED_ALL)

    assert isinstance(fig, go.Figure)
    assert fig.layout
    assert len(fig.layout.updatemenus) > 0


def test_toggle_initial_traces_visibility():
    """
    Mock figure and test _toggle_initial_traces_visibility call to update_trace
    """
    fig_mock = mock.MagicMock()

    _toggle_initial_traces_visibility(fig_mock, PortAvgActiveButton.REFERENCED_ALL)
    _toggle_initial_traces_visibility(fig_mock, PortAvgActiveButton.REFERENCED_NONNEGATIVE)
    _toggle_initial_traces_visibility(fig_mock, PortAvgActiveButton.UNREFERENCED_ALL)
    assert fig_mock.for_each_trace.call_count == 3
