import pandas as pd
import pytest
import plotly.graph_objects as go

from spectral_toolkit.df_operations.timeline_aggregations import (
    get_intervals_statistics,
    get_statistics_on_all_intervals,
)
from spectral_toolkit.plotting.summary_table import get_summary_table


def test_get_summary_table(fake_unpivoted_data_frame):
    """Test get_summary_table function"""
    test_df = fake_unpivoted_data_frame
    test_df.port = test_df.port.astype(str)
    test_df = test_df.set_index("_datetime")

    # Not a dataframe
    with pytest.raises(TypeError):
        get_summary_table(stats_df="abc", colormap={"a": 1})

    # Not a dict
    with pytest.raises(TypeError):
        get_summary_table(stats_df=pd.DataFrame(data={"port": [1]}), colormap=1)

    df_intervals = get_intervals_statistics(test_df)
    result_df = get_statistics_on_all_intervals(
        df_intervals=df_intervals, instrument_sigma_dict={"values": 1.2}
    )

    # No all ports are mapped
    with pytest.raises(ValueError):
        get_summary_table(stats_df=result_df, colormap={"a": 1})

    # set color
    cl = "black"

    # Not all ports have a display column
    with pytest.raises(ValueError):
        get_summary_table(
            stats_df=result_df,
            colormap={"1": [cl], "2": cl, "3": [cl]},
        )

    # Not all ports have a display column
    with pytest.raises(ValueError):
        get_summary_table(
            stats_df=result_df.rename(columns={"display": "abc"}),
            colormap={"1": [cl, cl], "2": [cl, cl], "3": [cl, cl]},
        )

    # Title not a string
    with pytest.raises(TypeError):
        get_summary_table(
            stats_df=result_df,
            colormap={"1": [cl, cl], "2": [cl, cl], "3": [cl, cl]},
            title=1,
        )

    # Subtitle not a string
    with pytest.raises(TypeError):
        get_summary_table(
            stats_df=result_df,
            colormap={"1": [cl, cl], "2": [cl, cl], "3": [cl, cl]},
            title="a",
            subtitle=1,
        )

    fig_ret = get_summary_table(
        stats_df=result_df,
        colormap={"1": [cl, cl], "2": [cl, cl], "3": [cl, cl]},
        title="abc",
        subtitle="def",
    )

    assert isinstance(fig_ret, go.Figure)
