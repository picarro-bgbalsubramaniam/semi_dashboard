"""Test DataFrame functions to process time series data"""
from math import ceil
import pandas as pd
import numpy as np
import pytest
from pydantic import ValidationError

from spectral_toolkit.constants.plotting_constants import Averaging
from spectral_toolkit.df_operations.timeline_process_df import (
    get_timeline_exclusion_mask,
    get_median_dt,
    get_allan_deviation_dataframe,
    assign_sampling_sections_marker,
    map_sampling_ports_name,
    get_adjusted_dataframe_from_reference_line,
    get_resampled_df_timeseries,
    filter_port_transitions,
    get_lods,
    _get_default_resampling_min_count,
    get_zero_referenced_df,
)


def test_timeline_mask():
    """Test the timeline mask function with ad-hoc Pandas series"""
    freq_assert = 1.45
    idx1 = pd.date_range("2022-04-18", periods=10, freq=f"{freq_assert}S")
    values = np.full(10, 3.0)
    values[4:6] = np.NaN
    test_s = pd.Series(values, index=idx1)
    expected = pd.Series(
        [False, False, False, True, True, True, False, False, False, True], index=idx1
    )
    assert expected.equals(get_timeline_exclusion_mask(test_s))

    with pytest.raises(ValueError):
        get_timeline_exclusion_mask(pd.Series([1, 2]))


def test_allan_calculation(fake_series):
    """Test allan calculations on fake_series"""

    with pytest.raises(ValueError):
        get_allan_deviation_dataframe(pd.Series([1, 2]))

    expected_oadev = [
        2.2877553291518313,
        1.6960144464462208,
        1.1752579128985654,
        0.9310916293403607,
        0.9361579210879197,
        0.7711147393843527,
        0.9635874599182415,
    ]
    test = get_allan_deviation_dataframe(fake_series).allan_dev.to_numpy()
    assert isinstance(test, np.ndarray)
    assert np.allclose(expected_oadev, test)

    test = get_allan_deviation_dataframe(
        pd.Series(
            [1, np.NaN, 2, np.NaN], index=pd.date_range("06:00", "07:00", periods=4)
        )
    )
    assert isinstance(test, pd.DataFrame)

    series_index = pd.date_range("10:04:20.02", "10:04:46.996", 10)
    test = get_allan_deviation_dataframe(
        pd.Series(
            [np.NaN, np.NaN, 1, np.NaN, 2, 2.2, np.NaN, 5, np.NaN, np.NaN],
            index=series_index,
        )
    )
    assert isinstance(test, pd.DataFrame)

    test = get_allan_deviation_dataframe(
        pd.Series(
            [np.NaN, np.NaN, np.NaN, 2.1, 2, 2.2, np.NaN, 5, np.NaN, np.NaN],
            index=series_index,
        )
    )
    assert isinstance(test, pd.DataFrame)


def test_median_dt_calc(fake_frequency, fake_series):
    """Test median delta t calculations on the fake_series"""
    with pytest.raises(ValueError):
        get_median_dt(pd.Series([1, 2]))

    assert np.isclose(fake_frequency, get_median_dt(fake_series))


def test_sampling_sections_marker(fake_unpivoted_data_frame):
    """Test marking of different sampling sections"""
    with pytest.raises(TypeError):
        assign_sampling_sections_marker("abc")

    with pytest.raises(ValueError):
        assign_sampling_sections_marker(pd.DataFrame(data={"a": [1]}))

    with pytest.raises(ValueError):
        assign_sampling_sections_marker(
            pd.DataFrame(data={"a": [1]}, index=pd.DatetimeIndex(["2020/01/01"]))
        )

    expected_n_sections = 15
    expected_max_section_length = 88
    expected_min_section_length = 50
    expected_mean_section_length = 65.8

    returned_df = assign_sampling_sections_marker(fake_unpivoted_data_frame)
    sampling_section = returned_df.sampling_section_marker.value_counts()

    assert len(sampling_section) == expected_n_sections
    assert min(sampling_section) == expected_min_section_length
    assert max(sampling_section) == expected_max_section_length
    assert np.isclose(np.mean(sampling_section), expected_mean_section_length)


def test_map_sampling_port(fake_unpivoted_data_frame):
    """Test map_sampling_port"""
    with pytest.raises(TypeError):
        map_sampling_ports_name("abc", {})

    with pytest.raises(TypeError):
        map_sampling_ports_name(fake_unpivoted_data_frame, "abc")

    with pytest.raises(ValueError):
        map_sampling_ports_name(pd.DataFrame(data={"concentration": [1]}), {})

    test_df = map_sampling_ports_name(fake_unpivoted_data_frame, {})
    assert isinstance(test_df, pd.DataFrame)


def test_get_adjusted_dataframe_from_reference_line(fake_unpivoted_data_frame):
    """Test get_adjusted_dataframe_from_reference_line"""
    test_df = fake_unpivoted_data_frame.rename(columns={"values": "concentration"})
    test_df = test_df.set_index("_datetime")
    port_maps = {1: "Reference", 2: "Inlet", 3: "Middle", 4: "Outlet"}
    test_df = map_sampling_ports_name(test_df, port_maps)

    # Exception: not a dataframe
    with pytest.raises(TypeError):
        get_adjusted_dataframe_from_reference_line("abc")

    # Not a DateTimeIndex
    with pytest.raises(ValueError):
        get_adjusted_dataframe_from_reference_line(pd.DataFrame(data={"a": [1]}))

    # Does not contains proper columns
    with pytest.raises(ValueError):
        get_adjusted_dataframe_from_reference_line(
            pd.DataFrame(test_df.rename(columns={"concentration": "aaa"}))
        )

    # Target cols not a list of str
    with pytest.raises(TypeError):
        get_adjusted_dataframe_from_reference_line(
            pd.DataFrame(test_df.rename(columns={"concentration": "aaa"})),
            target_cols="abc",
        )

    # Does not contain reference column
    with pytest.raises(ValueError):
        get_adjusted_dataframe_from_reference_line(test_df, "abc")

    result_df = get_adjusted_dataframe_from_reference_line(test_df, "Reference")
    assert isinstance(result_df, pd.DataFrame)


def test_get_resampled_df_timeseries(fake_data_frame):
    """Test get_resampled_df_timeseries"""

    # Not a dataframe
    with pytest.raises(TypeError):
        get_resampled_df_timeseries(
            original_df="abc", averaging_time=Averaging.TEN_SECONDS, min_count=5
        )

    # Not a DateTimeIndex
    with pytest.raises(ValueError):
        get_resampled_df_timeseries(
            original_df=pd.DataFrame(data={"a": [1, 2, 3]}),
            averaging_time=Averaging.TEN_SECONDS,
            min_count=5,
        )

    # Not a valid Averaging
    with pytest.raises(TypeError):
        get_resampled_df_timeseries(
            original_df=fake_data_frame, averaging_time=123, min_count=5
        )

    # Not a valid min_count
    with pytest.raises(TypeError):
        get_resampled_df_timeseries(
            original_df=fake_data_frame,
            averaging_time=Averaging.TEN_SECONDS,
            min_count=5.0,
        )

    result_df = get_resampled_df_timeseries(
        original_df=fake_data_frame, averaging_time=Averaging.TEN_SECONDS, min_count=5
    )
    assert isinstance(result_df, pd.DataFrame)


def test_filter_port_transition(fake_unpivoted_data_frame):
    # Not a df
    with pytest.raises(TypeError):
        filter_port_transitions("abc", 10, 30)

    # Not a DateTimeIndex
    with pytest.raises(ValueError):
        filter_port_transitions(pd.DataFrame(data={"a": [1]}), 10, 30)

    # Port not in df
    with pytest.raises(ValueError):
        filter_port_transitions(
            fake_unpivoted_data_frame.rename(columns={"port": "abc"}), 10, 30
        )

    # trim_start not int
    with pytest.raises(TypeError):
        filter_port_transitions(fake_unpivoted_data_frame, 10.5, 30)

    # trim end not int
    with pytest.raises(TypeError):
        filter_port_transitions(fake_unpivoted_data_frame, 10, 30.5)

    # trim_start not non negative
    with pytest.raises(ValueError):
        filter_port_transitions(fake_unpivoted_data_frame, -1, 30)

    # trim end not non negative
    with pytest.raises(ValueError):
        filter_port_transitions(fake_unpivoted_data_frame, 10, -1)

    trim_start = 10
    trim_end = 30
    frequency_s = pd.Timedelta(
        pd.infer_freq(fake_unpivoted_data_frame.index)
    ).total_seconds()
    trimmed_start = ceil(trim_start / frequency_s)
    trimmed_end = ceil(trim_end / frequency_s)
    n_transitions = 15  # Encoded in the fake data
    expected_dropped = (n_transitions - 1) * (trimmed_start + trimmed_end)

    ret = filter_port_transitions(
        original_df=fake_unpivoted_data_frame,
        trim_start=trim_start,
        trim_end=trim_end,
        transition_reference="port",
    )

    assert isinstance(ret, pd.DataFrame)
    assert len(ret) < len(fake_unpivoted_data_frame)
    assert len(ret) == len(fake_unpivoted_data_frame) - expected_dropped

    trim_start = 10
    trim_end = 10
    frequency_s = pd.Timedelta(
        pd.infer_freq(fake_unpivoted_data_frame.index)
    ).total_seconds()
    trimmed_start = ceil(
        trim_start / frequency_s
    )  # Number of rows dropped at start of every transition
    trimmed_end = ceil(trim_end / frequency_s)
    expected_dropped = (n_transitions - 1) * (trimmed_start + trimmed_end)

    ret = filter_port_transitions(
        original_df=fake_unpivoted_data_frame,
        trim_start=trim_start,
        trim_end=trim_end,
        transition_reference="port",
    )

    assert isinstance(ret, pd.DataFrame)
    assert len(ret) < len(fake_unpivoted_data_frame)
    assert len(ret) == len(fake_unpivoted_data_frame) - expected_dropped

    ret = filter_port_transitions(
        original_df=fake_unpivoted_data_frame,
        trim_start=trim_start,
        trim_end=trim_end,
        transition_reference="port",
        keep_final_data=False,
        keep_initial_data=False,
    )
    expected_dropped = (
        (n_transitions - 1) * (trimmed_start + trimmed_end)
        + trimmed_start
        + trimmed_end
    )

    assert isinstance(ret, pd.DataFrame)
    assert len(ret) < len(fake_unpivoted_data_frame)
    assert len(ret) == len(fake_unpivoted_data_frame) - expected_dropped


def test_get_lods(fake_unpivoted_data_frame):
    """Test get_lods on fake_unpivoted_data_frame"""

    with pytest.raises(ValidationError):
        get_lods(
            timeseries_df="abc",
            reference_port=1,
            averaging_level=20,
            lod_sigma=3.0,
            port_column="port",
        )

    with pytest.raises(ValidationError):
        get_lods(
            timeseries_df=fake_unpivoted_data_frame,
            reference_port={},
            averaging_level=20,
            lod_sigma=3.0,
            port_column="port",
        )

    with pytest.raises(ValidationError):
        get_lods(
            timeseries_df=fake_unpivoted_data_frame,
            reference_port=1,
            averaging_level="abc",
            lod_sigma=3.0,
            port_column="port",
        )

    with pytest.raises(ValidationError):
        get_lods(
            timeseries_df=fake_unpivoted_data_frame,
            reference_port=1,
            averaging_level=20,
            lod_sigma="abc",
            port_column="port",
        )

    with pytest.raises(ValidationError):
        get_lods(
            timeseries_df=fake_unpivoted_data_frame,
            reference_port=1,
            averaging_level=20,
            lod_sigma=3.0,
            port_column={},
        )

    # Not a datetimeindex
    with pytest.raises(ValueError):
        get_lods(
            timeseries_df=pd.DataFrame(data={"d": [1]}),
            reference_port=1,
            averaging_level=20,
            lod_sigma=3.0,
            port_column="port",
        )

    df_test = fake_unpivoted_data_frame.copy(deep=True)
    df_test.set_index("_datetime", inplace=True)

    # port_column not present
    with pytest.raises(ValueError):
        get_lods(
            timeseries_df=df_test,
            reference_port=1,
            averaging_level=20,
            lod_sigma=3.0,
            port_column="me?never",
        )

    # lod sigma not finite
    with pytest.raises(ValueError):
        get_lods(
            timeseries_df=df_test,
            reference_port=1,
            averaging_level=20,
            lod_sigma=np.NaN,
            port_column="port",
        )

    # negative averaging level
    with pytest.raises(ValueError):
        get_lods(
            timeseries_df=df_test,
            reference_port=1,
            averaging_level=-20,
            lod_sigma=3.0,
            port_column="port",
        )

    # ref port not present
    with pytest.raises(ValueError):
        get_lods(
            timeseries_df=df_test,
            reference_port=50,
            averaging_level=20,
            lod_sigma=3.0,
            port_column="port",
        )

    # Not enough data
    with pytest.raises(ValueError):
        get_lods(
            timeseries_df=df_test.head(5),
            reference_port=1,
            averaging_level=20,
            lod_sigma=3.0,
            port_column="port",
        )

    lods_df = get_lods(
        timeseries_df=df_test,
        reference_port=1,
        averaging_level=20,
        lod_sigma=3.0,
        port_column="port",
    )

    assert isinstance(lods_df, pd.DataFrame)
    assert len(lods_df) == 1

    # Port column must be numeric
    df_test.port = df_test.port.astype(str)

    with pytest.raises(ValueError):
        get_lods(
            timeseries_df=df_test.head(5),
            reference_port=1,
            averaging_level=20,
            lod_sigma=3.0,
            port_column="port",
        )


def test_get_default_resampling_min_count():
    """Test min_count interface"""

    with pytest.raises(TypeError):
        _get_default_resampling_min_count("abc")

    assert isinstance(_get_default_resampling_min_count(), int)


def test_get_zero_referenced_df(fake_unpivoted_data_frame):
    """Test get_adjusted_dataframe_from_reference_line"""
    test_df = fake_unpivoted_data_frame.rename(columns={"values": "concentration"})
    test_df = test_df.set_index("_datetime")
    port_maps = {1: "Reference", 2: "Inlet", 3: "Middle", 4: "Outlet"}
    test_df = map_sampling_ports_name(test_df, port_maps)

    # Exception: not a dataframe
    with pytest.raises(ValidationError):
        get_zero_referenced_df("abc")

    # Exception: not a list
    with pytest.raises(ValidationError):
        get_zero_referenced_df(test_df, 145, "Reference", "port", 1, 1)

    # Exception: not a str
    with pytest.raises(ValidationError):
        get_zero_referenced_df(test_df, ["concentration"], {}, "port", 1, 1)

    # Exception: not a str
    with pytest.raises(ValidationError):
        get_zero_referenced_df(
            test_df, ["concentration"], "Reference", pd.Series([]), 1, 1
        )

    # Exception: not a int
    with pytest.raises(ValidationError):
        get_zero_referenced_df(test_df, ["concentration"], "Reference", "port", {}, 1)

    # Exception: not a int
    with pytest.raises(ValidationError):
        get_zero_referenced_df(test_df, ["concentration"], "Reference", "port", 1, [])

    # Exception: not positive
    with pytest.raises(ValueError):
        get_zero_referenced_df(test_df, ["concentration"], "Reference", "port", 1, 0)

    # Exception: not positive
    with pytest.raises(ValueError):
        get_zero_referenced_df(test_df, ["concentration"], "Reference", "port", -1, 1)

    # Exception: window size must be larger than min_events
    with pytest.raises(ValueError):
        get_zero_referenced_df(test_df, ["concentration"], "Reference", "port", 1, 3)

    # Not a DateTimeIndex
    with pytest.raises(ValueError):
        get_zero_referenced_df(pd.DataFrame(data={"a": [1]}))

    # Column non numeric
    with pytest.raises(ValueError):
        test2_df = test_df.copy()
        test2_df["concentration"] = "Yes!"
        get_zero_referenced_df(test2_df, ["concentration"], "Reference", "port", 1, 1)

    # Does not contains proper columns
    with pytest.raises(ValueError):
        test2_df = test_df.copy()
        test2_df = test2_df.rename(columns={"concentration": "aaa"})
        get_zero_referenced_df(test2_df, ["concentration"], "Reference", "port", 1, 1)

    # Target cols not a list of str
    with pytest.raises(TypeError):
        get_adjusted_dataframe_from_reference_line(
            pd.DataFrame(test_df.rename(columns={"concentration": "aaa"})),
            target_cols="abc",
        )

    # Does not contain reference column
    with pytest.raises(ValueError):
        get_zero_referenced_df(test_df, ["concentration"], "Reference", "abc", 1, 1)

    # Not enough reference data
    with pytest.raises(ValueError):
        get_zero_referenced_df(test_df, ["concentration"], "Reference", "port", 10, 10)

    result_df = get_zero_referenced_df(
        test_df, ["concentration"], "Reference", "port", 1, 1
    )
    assert isinstance(result_df, pd.DataFrame)
    assert len(result_df) == len(test_df)

    result_df = get_zero_referenced_df(
        test_df, None, "Reference", "port", 1, 1
    )
    assert isinstance(result_df, pd.DataFrame)
    assert len(result_df) == len(test_df)
