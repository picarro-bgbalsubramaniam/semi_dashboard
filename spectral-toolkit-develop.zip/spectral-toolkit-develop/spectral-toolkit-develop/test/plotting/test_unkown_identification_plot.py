"""Test unknown identification plot"""
from typing import Tuple

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import pytest
from pydantic import ValidationError

from spectral_toolkit.constants.plotting_constants import Averaging
from spectral_toolkit.df_operations.timeline_aggregations_xarray import (
    intervals_figure_of_merit_xarray,
)
from spectral_toolkit.df_operations.timeline_process_df import (
    get_adjusted_dataframe_from_reference_line,
)
from spectral_toolkit.plotting.unknown_identification_plot import (
    add_warning_lines,
    get_unknowns_fom_plot,
    add_port_menus,
    _get_figure_y_limits,
    _get_flags_labels,
    add_flags,
)


def test_add_port_menus():
    """Test add_port_menus"""

    with pytest.raises(ValidationError):
        add_port_menus("abc", ["port1"])

    with pytest.raises(ValidationError):
        add_port_menus(go.Figure, {})

    fig = go.Figure(go.Scatter(x=[1, 5], y=[0, 10], text="port1"))
    ret_fig = add_port_menus(fig, ["port1"])
    assert isinstance(ret_fig, go.Figure)
    assert len(ret_fig.layout.updatemenus) > 0


def test_add_warning_lines():
    """Test add_warning_lines"""

    with pytest.raises(ValidationError):
        add_warning_lines("abc")

    with pytest.raises(ValidationError):
        add_warning_lines(go.Figure, "a", 1)

    with pytest.raises(ValidationError):
        add_warning_lines(go.Figure, 1, "a")

    fig = go.Figure(go.Scatter(x=[1, 5], y=[0, 10]))

    ret_fig = add_warning_lines(fig)
    assert isinstance(ret_fig, go.Figure)
    assert len(ret_fig.layout.shapes) > 0


def test_get_figure_y_limits():
    """Test _get_figure_y_limits"""

    with pytest.raises(ValidationError):
        _get_figure_y_limits("abc")

    fig = go.Figure(go.Scatter(x=[1, 5], y=[0, 10]))
    result = _get_figure_y_limits(fig)

    assert isinstance(result, Tuple)
    assert len(result) == 2


def test_get_flags_labels():
    """Test _get_flags_labels"""

    with pytest.raises(ValidationError):
        _get_flags_labels("abc")

    test_df = pd.DataFrame(
        data={"flag_1": [True, False, False], "flag_2": [True, True, False]},
        index=pd.date_range("00:00", freq="1m", periods=3),
    )

    # No DTI
    with pytest.raises(ValueError):
        _get_flags_labels(test_df.reset_index())

    # Not all bool
    with pytest.raises(ValueError):
        _get_flags_labels(test_df.astype(int))

    result = _get_flags_labels(test_df)

    assert isinstance(result, pd.Series)
    assert len(result) == 2


def test_add_flags():
    """Test add_flags"""

    flags = pd.Series(
        data=[True, False, False], index=pd.date_range("00:00", freq="1m", periods=3)
    )

    with pytest.raises(ValidationError):
        add_flags("abc", flags)

    with pytest.raises(ValidationError):
        add_flags(go.Figure, {})

    fig = go.Figure(go.Scatter(x=[1, 5], y=[0, 10], text="port1"))
    ret_fig = add_flags(fig, flags)
    assert isinstance(ret_fig, go.Figure)
    assert len(ret_fig.data) - len(fig.data) == 1


def test_get_unknowns_fom_plot(fake_unpivoted_data_frame):
    df_test = fake_unpivoted_data_frame.copy()
    df_test = df_test.set_index("_datetime")
    df_test.port = df_test.port.astype(str)
    df_test = df_test.assign(values2=df_test["values"] + 1)
    df_test.port = "port" + df_test.port.astype(str)

    df_adj = get_adjusted_dataframe_from_reference_line(
        original_df=df_test,
        reference_column_name="port1",
        target_cols=["values", "values2"],
        ref_window_width=Averaging.TEN_SECONDS,
    )

    fom_xr = intervals_figure_of_merit_xarray(
        start_df=df_adj, instrument_lods={"values": 1.0, "values2": 2.0}
    )

    # Not a xr
    with pytest.raises(ValidationError):
        get_unknowns_fom_plot(
            intervals_fom_xr="abc",
            species_colormap={"values": "black"},
            show_boxplot=True,
        )

    # Not a dict
    with pytest.raises(ValidationError):
        get_unknowns_fom_plot(
            intervals_fom_xr=fom_xr,
            species_colormap="abc",
            show_boxplot=True,
        )

    # Not a bool
    with pytest.raises(ValidationError):
        get_unknowns_fom_plot(
            intervals_fom_xr=fom_xr,
            species_colormap={"values": "black"},
            show_boxplot="abc",
        )

    # Not a pandas series
    with pytest.raises(ValidationError):
        get_unknowns_fom_plot(
            intervals_fom_xr=fom_xr,
            species_colormap={"values": "black"},
            show_boxplot=True,
            legend_group="abc",
        )

    # Missing coord
    with pytest.raises(ValueError):
        get_unknowns_fom_plot(
            intervals_fom_xr=fom_xr.drop_dims("_datetime"),
            species_colormap={"values": "black"},
            show_boxplot=True,
        )

    # Not all species in dict
    with pytest.raises(ValueError):
        get_unknowns_fom_plot(
            intervals_fom_xr=fom_xr,
            species_colormap={"values": "black"},
            show_boxplot=True,
        )

    # Not all species in legend group
    with pytest.raises(ValueError):
        get_unknowns_fom_plot(
            intervals_fom_xr=fom_xr,
            species_colormap={"values": "black"},
            show_boxplot=True,
            legend_group=pd.Series({"values": "a"}),
        )

    fig_ret = get_unknowns_fom_plot(
        intervals_fom_xr=fom_xr,
        species_colormap={"values": "black", "values2": "blue"},
        show_boxplot=True,
    )

    assert isinstance(fig_ret, go.Figure)

    fig_ret = get_unknowns_fom_plot(
        intervals_fom_xr=fom_xr,
        species_colormap={"values": "black", "values2": "blue"},
        show_boxplot=True,
        legend_group=pd.Series({"values": "a", "values2": "b"}),
    )
    assert isinstance(fig_ret, go.Figure)
