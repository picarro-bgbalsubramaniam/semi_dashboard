from contextlib import contextmanager
from typing import List
from unittest import mock

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import pytest
from pydantic import ValidationError
from pymongo import database
from scipy.interpolate import interp1d
from plotly.subplots import make_subplots

from spectral_toolkit.df_operations.spectral_fits_results_aggregation import (
    define_solutions_spectral_dataset,
)
from spectral_toolkit.plotting.spectral_hunting_plot import (
    _get_comparison_table,
    get_spectral_hunting_plot,
    _get_fit_selector_slider,
    _generate_rank_cid_meta_combinations,
    _assign_trace_metadata,
    _add_comparison_table_trace,
    _add_residuals_trace,
    _add_cumulated_spectra_trace,
    _add_single_cid_spectrum,
    fit_result_plot,
)


@contextmanager
def does_not_raise():
    yield


def test_get_spectral_hunting_plot_inputs(
    fake_dataset, fake_fit_solutions, fake_fit_experimental_datapoints, mocker
):
    """Test get_all_cids_list"""

    with pytest.raises(ValidationError):
        get_spectral_hunting_plot(
            spectral_fits_ds="", species_colormap={}, title_text=""
        )

    with pytest.raises(ValidationError):
        get_spectral_hunting_plot(
            spectral_fits_ds=fake_dataset, species_colormap=1, title_text=""
        )

    with pytest.raises(ValidationError):
        get_spectral_hunting_plot(
            spectral_fits_ds=fake_dataset, species_colormap={}, title_text={}
        )

    with pytest.raises(ValueError):
        get_spectral_hunting_plot(
            spectral_fits_ds=fake_dataset.drop_dims("experimental_wavenumber")
        )

    with pytest.raises(ValueError):
        get_spectral_hunting_plot(
            spectral_fits_ds=fake_dataset.drop_vars("new_cids_display"),
        )

    nu = np.arange(5850, 6150, 10)
    y_fake = np.linspace(0, 10, len(nu))

    mocker.patch(
        "spectral_toolkit.df_operations.spectral_fits_results_aggregation.model_function",
        return_value=interp1d(nu, y_fake),
    )

    fdata = define_solutions_spectral_dataset(
        db_client=mock.MagicMock(spec=database.Database),
        solutions_fit_df=fake_fit_solutions,
        experimental_datapoints=fake_fit_experimental_datapoints,
        evaluation_nu=nu,
        top_n=2,
    )

    ret = get_spectral_hunting_plot(spectral_fits_ds=fdata)

    assert isinstance(ret, go.Figure)


def test_get_comparison_table(fake_dataset):
    """Test _get_comparison_table"""

    with pytest.raises(ValidationError):
        _get_comparison_table(
            spectral_fits_ds="fake_dataset", ranking_by_cid_count=1, new_cids_count=1
        )

    with pytest.raises(ValidationError):
        _get_comparison_table(
            spectral_fits_ds=fake_dataset, ranking_by_cid_count="abc", new_cids_count=1
        )

    with pytest.raises(ValidationError):
        _get_comparison_table(
            spectral_fits_ds=fake_dataset, ranking_by_cid_count=1, new_cids_count="def"
        )

    with pytest.raises(ValueError):
        _get_comparison_table(
            spectral_fits_ds=fake_dataset.drop_vars("fit_parameters"),
            ranking_by_cid_count=1,
            new_cids_count=1,
        )

    with pytest.raises(ValueError):
        _get_comparison_table(
            spectral_fits_ds=fake_dataset.drop_vars("summary_table"),
            ranking_by_cid_count=1,
            new_cids_count=1,
        )

    with pytest.raises(ValueError):
        _get_comparison_table(
            spectral_fits_ds=fake_dataset, ranking_by_cid_count=3, new_cids_count=1
        )

    with pytest.raises(ValueError):
        _get_comparison_table(
            spectral_fits_ds=fake_dataset, ranking_by_cid_count=1, new_cids_count=3
        )

    ret_df = _get_comparison_table(
        spectral_fits_ds=fake_dataset, ranking_by_cid_count=1, new_cids_count=1
    )

    assert isinstance(ret_df, pd.DataFrame)
    assert len(fake_dataset["summary_table"].sel(solution=0).values) == len(ret_df)
    assert set(ret_df.columns) == set(
        [
            "parameters",
            "current_fit_values",
            "improvement_original",
            "improvement_previous",
            "color_original_improvement",
            "color_previous_improvement",
        ]
    )
    assert all(ret_df.improvement_original == ret_df.improvement_previous)


@pytest.mark.parametrize(
    "original_fig, rankings_counts, new_cids_counts, expectation",
    [
        (
            {},
            [1, 2, 3],
            [1, 2],
            pytest.raises(ValidationError),
        ),
        (
            go.Figure(),
            {},
            [1, 2],
            pytest.raises(ValidationError),
        ),
        (
            go.Figure(),
            [1, 2, 3],
            {},
            pytest.raises(ValidationError),
        ),
        (
            go.Figure(),
            [1, 2, 3],
            [1, 2],
            does_not_raise(),
        ),
    ],
)
def test_get_fit_selector_slider(
    original_fig, rankings_counts, new_cids_counts, expectation
):
    """Test _get_fit_selector_slider function"""
    with expectation:
        result = _get_fit_selector_slider(
            original_fig=original_fig,
            rankings_counts=rankings_counts,
            new_cids_counts=new_cids_counts,
        )
        assert isinstance(result, List)
        assert len(result) > 0


@pytest.mark.parametrize(
    "unique_cids_counts, unique_ranks_counts, expectation",
    [
        (
            {},
            [1, 2],
            pytest.raises(ValidationError),
        ),
        (
            [1, 2, 3],
            {},
            pytest.raises(ValidationError),
        ),
        (
            [1, 2, 3],
            [1, 2],
            does_not_raise(),
        ),
    ],
)
def test_generate_rank_cid_meta_combinations(
    unique_cids_counts, unique_ranks_counts, expectation
):
    """Test _generate_rank_cid_meta_combinations function"""
    with expectation:
        result = _generate_rank_cid_meta_combinations(
            unique_cids_counts=unique_cids_counts,
            unique_ranks_counts=unique_ranks_counts,
        )
        assert isinstance(result, pd.DataFrame)


@pytest.mark.parametrize(
    "ranking_by_cid_count, new_cids_count, expectation",
    [
        (
            {},
            1,
            pytest.raises(ValidationError),
        ),
        (
            2,
            {},
            pytest.raises(ValidationError),
        ),
        (
            2,
            2,
            does_not_raise(),
        ),
    ],
)
def test_assign_trace_metadata(ranking_by_cid_count, new_cids_count, expectation):
    """Test _assign_trace_metadata function"""
    with expectation:
        result = _assign_trace_metadata(
            ranking_by_cid_count=ranking_by_cid_count,
            new_cids_count=new_cids_count,
        )
        assert isinstance(result, str)
        assert len(result) > 0


@pytest.mark.parametrize(
    "original_fig, comparison_df, current_ranking, new_cids_counts, expectation",
    [
        (
            [],
            pd.DataFrame(
                data={
                    "parameters": ["rmse", "wrmse"],
                    "current_fit_values": [0.01, 0.01],
                    "improvement_original": [0.75, 0.449],
                    "improvement_previous": [0.75, 0.45],
                    "color_original_improvement": ["seagreen", "seagreen"],
                    "color_previous_improvement": ["darkred", "seagreen"],
                }
            ),
            1,
            1,
            pytest.raises(ValidationError),
        ),
        (
            go.Figure(),
            {},
            1,
            1,
            pytest.raises(ValidationError),
        ),
        (
            go.Figure(),
            pd.DataFrame(
                data={
                    "parameters": ["rmse", "wrmse"],
                    "current_fit_values": [0.01, 0.01],
                    "improvement_original": [0.75, 0.449],
                    "improvement_previous": [0.75, 0.45],
                    "color_original_improvement": ["seagreen", "seagreen"],
                    "color_previous_improvement": ["darkred", "seagreen"],
                }
            ),
            {},
            1,
            pytest.raises(ValidationError),
        ),
        (
            go.Figure(),
            pd.DataFrame(
                data={
                    "parameters": ["rmse", "wrmse"],
                    "current_fit_values": [0.01, 0.01],
                    "improvement_original": [0.75, 0.449],
                    "improvement_previous": [0.75, 0.45],
                    "color_original_improvement": ["seagreen", "seagreen"],
                    "color_previous_improvement": ["darkred", "seagreen"],
                }
            ),
            1,
            {},
            pytest.raises(ValidationError),
        ),
        (
            go.Figure(),
            pd.DataFrame(
                data={
                    "current_fit_values": [0.01, 0.01],
                    "improvement_original": [0.75, 0.449],
                    "improvement_previous": [0.75, 0.45],
                    "color_original_improvement": ["seagreen", "seagreen"],
                    "color_previous_improvement": ["darkred", "seagreen"],
                }
            ),
            1,
            1,
            pytest.raises(ValueError),
        ),
        (
            make_subplots(
                rows=2,
                cols=2,
                specs=[[{"type": "xy"}, None], [{"type": "xy"}, {"type": "domain"}]],
            ),
            pd.DataFrame(
                data={
                    "parameters": ["rmse", "wrmse"],
                    "current_fit_values": [0.01, 0.01],
                    "improvement_original": [0.75, 0.449],
                    "improvement_previous": [0.75, 0.45],
                    "color_original_improvement": ["seagreen", "seagreen"],
                    "color_previous_improvement": ["darkred", "seagreen"],
                }
            ),
            1,
            1,
            does_not_raise(),
        ),
    ],
)
def test_add_comparison_table_trace(
    original_fig, comparison_df, current_ranking, new_cids_counts, expectation
):
    """Test _add_comparison_table_trace function"""
    with expectation:
        result = _add_comparison_table_trace(
            original_fig=original_fig,
            comparison_df=comparison_df,
            current_ranking=current_ranking,
            new_cids_count=new_cids_counts,
        )
        assert isinstance(result, go.Figure)
        assert result.data
        assert result.layout


@pytest.mark.parametrize(
    "original_fig, wavenumbers, residuals, current_ranking, new_cids_counts, traces_color, expectation",
    [
        (
            [],
            np.random.rand(5),
            np.random.rand(5),
            1,
            1,
            {"residual": "black", "reference": "black"},
            pytest.raises(ValidationError),
        ),
        (
            make_subplots(rows=2, cols=2),
            "abc",
            np.random.rand(5),
            1,
            1,
            {"residual": "black", "reference": "black"},
            pytest.raises(ValidationError),
        ),
        (
            make_subplots(rows=2, cols=2),
            np.random.rand(5),
            "abc",
            1,
            1,
            {"residual": "black", "reference": "black"},
            pytest.raises(ValidationError),
        ),
        (
            make_subplots(rows=2, cols=2),
            np.random.rand(5),
            np.random.rand(5),
            "abc",
            1,
            {"residual": "black", "reference": "black"},
            pytest.raises(ValidationError),
        ),
        (
            make_subplots(rows=2, cols=2),
            np.random.rand(5),
            np.random.rand(5),
            1,
            "abc",
            {"residual": "black", "reference": "black"},
            pytest.raises(ValidationError),
        ),
        (
            make_subplots(rows=2, cols=2),
            np.random.rand(5),
            np.random.rand(5),
            1,
            1,
            "abc",
            pytest.raises(ValidationError),
        ),
        (
            make_subplots(rows=2, cols=2),
            np.random.rand(5),
            np.random.rand(5),
            1,
            1,
            {"residual": "black", "abc": "black"},
            pytest.raises(ValueError),
        ),
        (
            make_subplots(rows=2, cols=2),
            np.random.rand(5),
            np.random.rand(5),
            1,
            1,
            {"residual": "black", "reference": "black"},
            does_not_raise(),
        ),
    ],
)
def test_add_residuals_trace(
    original_fig,
    wavenumbers,
    residuals,
    current_ranking,
    new_cids_counts,
    traces_color,
    expectation,
):
    """Test _add_comparison_table_trace function"""
    with expectation:
        result = _add_residuals_trace(
            original_fig=original_fig,
            wavenumbers=wavenumbers,
            residuals=residuals,
            current_ranking=current_ranking,
            new_cids_count=new_cids_counts,
            traces_color=traces_color,
        )
        assert isinstance(result, go.Figure)
        assert result.data
        assert result.layout


def test_add_cumulated_spectra_trace(fake_dataset):
    """Test _add_cumulated_spectra_trace function"""

    with pytest.raises(ValidationError):
        _add_cumulated_spectra_trace(
            original_fig="abc",
            solution_xr=fake_dataset.isel(solution=0),
            traces_color={"Fit result": "black", "reference": "black"},
        )

    with pytest.raises(ValidationError):
        _add_cumulated_spectra_trace(
            original_fig=make_subplots(rows=2, cols=2),
            solution_xr="abc",
            traces_color={"Fit result": "black", "reference": "black"},
        )

    with pytest.raises(ValidationError):
        _add_cumulated_spectra_trace(
            original_fig=make_subplots(rows=2, cols=2),
            solution_xr=fake_dataset.isel(solution=0),
            traces_color="abc",
        )

    with pytest.raises(ValueError):
        _add_cumulated_spectra_trace(
            original_fig=make_subplots(rows=2, cols=2),
            solution_xr=fake_dataset.isel(solution=0),
            traces_color={"Fittttt": "black", "reference": "black"},
        )

    with pytest.raises(ValueError):
        _add_cumulated_spectra_trace(
            original_fig=make_subplots(rows=2, cols=2),
            solution_xr=fake_dataset.isel(solution=0).drop_vars("cid"),
            traces_color={"Fit result": "black", "reference": "black"},
        )

    with pytest.raises(ValueError):
        _add_cumulated_spectra_trace(
            original_fig=make_subplots(rows=2, cols=2),
            solution_xr=fake_dataset.isel(solution=0).drop_vars("new_cids"),
            traces_color={"Fit result": "black", "reference": "black"},
        )

    result = _add_cumulated_spectra_trace(
        original_fig=make_subplots(rows=2, cols=2),
        solution_xr=fake_dataset.isel(solution=0),
        traces_color={"Fit result": "black", "reference": "black"},
    )
    assert isinstance(result, go.Figure)
    assert result.data
    assert result.layout


def test_add_single_cid_spectrum(fake_dataset):
    """Test _add_cumulated_spectra_trace function"""

    with pytest.raises(ValidationError):
        _add_single_cid_spectrum(
            original_fig="abc",
            single_cid_xr=fake_dataset.isel(solution=0, cid=0),
            colormap_cid={"180": "black"},
        )

    with pytest.raises(ValidationError):
        _add_single_cid_spectrum(
            original_fig=make_subplots(rows=2, cols=2),
            single_cid_xr="abc",
            colormap_cid={"180": "black"},
        )

    with pytest.raises(ValidationError):
        _add_single_cid_spectrum(
            original_fig=make_subplots(rows=2, cols=2),
            single_cid_xr=fake_dataset.isel(solution=0, cid=0),
            colormap_cid="abc",
        )

    with pytest.raises(ValueError):
        _add_single_cid_spectrum(
            original_fig=make_subplots(rows=2, cols=2),
            single_cid_xr=fake_dataset.isel(solution=0, cid=0),
            colormap_cid={"185": "black"},
        )

    with pytest.raises(ValueError):
        _add_single_cid_spectrum(
            original_fig=make_subplots(rows=2, cols=2),
            single_cid_xr=fake_dataset.isel(solution=0, cid=0).drop_vars("cid"),
            colormap_cid={"180": "black"},
        )

    with pytest.raises(ValueError):
        _add_single_cid_spectrum(
            original_fig=make_subplots(rows=2, cols=2),
            single_cid_xr=fake_dataset.isel(solution=0, cid=0).drop_vars(
                "loss_scaled_cids"
            ),
            colormap_cid={"180": "black"},
        )

    with pytest.raises(ValueError):
        _add_single_cid_spectrum(
            original_fig=make_subplots(rows=2, cols=2),
            single_cid_xr=fake_dataset.isel(solution=0),
            colormap_cid={"180": "black"},
        )

    result = _add_single_cid_spectrum(
        original_fig=make_subplots(rows=2, cols=2),
        single_cid_xr=fake_dataset.isel(solution=1, cid=1),
        colormap_cid={"181": "black"},
    )
    assert isinstance(result, go.Figure)
    assert result.data
    assert result.layout


@pytest.mark.parametrize(
    "experimental_datapoints, absorption_df, concentrations, annotations, species_colormap, title_text, expectation",
    [
        (
            [],
            pd.DataFrame(
                data={948: [0.3, 0.4], 962: [0.5, 0.6]}, index=[6057.1, 6058.2]
            ),
            pd.Series({948: 3.5, 962: 1.4}),
            "annotation",
            {},
            "title",
            pytest.raises(ValidationError),
        ),
        (
            pd.Series([1, 2], index=[6057.1, 6058.2]),
            "abc",
            pd.Series({948: 3.5, 962: 1.4}),
            "annotation",
            {},
            "title",
            pytest.raises(ValidationError),
        ),
        (
            pd.Series([1, 2], index=[6057.1, 6058.2]),
            pd.DataFrame(
                data={948: [0.3, 0.4], 962: [0.5, 0.6]}, index=[6057.1, 6058.2]
            ),
            {},
            "annotation",
            {},
            "title",
            pytest.raises(ValidationError),
        ),
        (
            pd.Series([1, 2], index=[6057.1, 6058.2]),
            pd.DataFrame(
                data={948: [0.3, 0.4], 962: [0.5, 0.6]}, index=[6057.1, 6058.2]
            ),
            pd.Series({948: 3.5, 962: 1.4}),
            pd.Series(),
            {},
            "title",
            pytest.raises(ValidationError),
        ),
        (
            pd.Series([1, 2], index=[6057.1, 6058.2]),
            pd.DataFrame(
                data={948: [0.3, 0.4], 962: [0.5, 0.6]}, index=[6057.1, 6058.2]
            ),
            pd.Series({948: 3.5, 962: 1.4}),
            "annotation",
            "12345",
            "title",
            pytest.raises(ValidationError),
        ),
        (
            pd.Series([1, 2], index=[6057.1, 6058.2]),
            pd.DataFrame(
                data={948: [0.3, 0.4], 962: [0.5, 0.6]}, index=[6057.1, 6058.2]
            ),
            pd.Series({948: 3.5, 962: 1.4}),
            "annotation",
            {},
            [],
            pytest.raises(ValidationError),
        ),
        (
            pd.Series([1], index=[6057.1]),
            pd.DataFrame(
                data={948: [0.3, 0.4], 962: [0.5, 0.6]}, index=[6057.1, 6058.2]
            ),
            pd.Series({948: 3.5, 962: 1.4}),
            "annotation",
            {},
            "title",
            pytest.raises(ValueError),
        ),
        (
            pd.Series([1, 2], index=[6057.1, 6058.2]),
            pd.DataFrame(
                data={948: [0.3, 0.4], 962: [0.5, 0.6]}, index=[6057.1, 6058.2]
            ),
            pd.Series({948: 3.5}),
            "annotation",
            {},
            "title",
            pytest.raises(ValueError),
        ),
        (
            pd.Series([1, 2], index=[6057.1, 6058.2]),
            pd.DataFrame(data={948: [0.3, 0.4], 962: [0.5, 0.6]}, index=[0, 1]),
            pd.Series({948: 3.5, 962: 1.4}),
            "annotation",
            {},
            "title",
            pytest.raises(TypeError),
        ),
        (
            pd.Series([1, 2], index=[6057.1, 6058.2]),
            pd.DataFrame(
                data={"948": [0.3, 0.4], "962": [0.5, 0.6]}, index=[6057.1, 6058.2]
            ),
            pd.Series({948: 3.5, 962: 1.4}),
            "annotation",
            {},
            "title",
            pytest.raises(TypeError),
        ),
        (
            pd.Series([1, 2], index=[6057.1, 6058.2]),
            pd.DataFrame(
                data={948: [0.3, 0.4], 962: [0.5, 0.6]}, index=[6057.1, 6058.2]
            ),
            pd.Series({948: 3.5, 982: 1.4}),
            "annotation",
            {},
            "title",
            pytest.raises(ValueError),
        ),
        (
            pd.Series([1, 2], index=[6057.1, 6058.2]),
            pd.DataFrame(
                data={948: [0.3, 0.4], 962: [0.5, 0.6]}, index=[6057.1, 6058.2]
            ),
            pd.Series({948: 3.5, 962: 1.4}),
            "annotation",
            None,
            "title",
            does_not_raise(),
        ),
    ],
)
def test_fit_result_plot(
    experimental_datapoints,
    absorption_df,
    concentrations,
    annotations,
    species_colormap,
    title_text,
    expectation,
):
    """Test _get_fit_selector_slider function"""
    with expectation:
        result = fit_result_plot(
            experimental_datapoints=experimental_datapoints,
            absorption_df=absorption_df,
            concentrations=concentrations,
            annotations=annotations,
            species_colormap=species_colormap,
            title_text=title_text,
        )
        assert isinstance(result, go.Figure)
        assert result.data
        assert result.layout
