from contextlib import nullcontext as does_not_raise
from typing import List

import numpy as np
import pandas as pd
import pytest
from spectral_toolkit.constants.plotting_constants import Averaging, AveragesSelection
from spectral_toolkit.plotting.timeline_plot import (
    _get_averaging_line_style,
    _get_averaging_marker_style,
    _update_annotation_y_coord,
    _get_three_sigma_instrument_dict,
    _add_range_menus,
    _add_averaging_trace,
    get_timeseries_plot_plotly,
    get_default_timeseries_template,
)
import plotly.graph_objects as go


def test_get_averaging_line_style():
    """Test line style interfaces"""

    with pytest.raises(TypeError):
        _get_averaging_line_style("abc")

    assert isinstance(_get_averaging_line_style(), dict)


def test_get_averaging_marker_style():
    """Test marker style interfaces"""

    with pytest.raises(TypeError):
        _get_averaging_marker_style("abc")

    assert isinstance(_get_averaging_marker_style(), dict)


def test_update_annotation_y_coord():
    """Test annotations interface"""

    with pytest.raises(TypeError):
        _update_annotation_y_coord("abc")

    assert isinstance(_update_annotation_y_coord([{"text": "abc", "y": 0.0}]), list)


def test_get_three_sigma_instrument_dict():
    """Test three sigma instrument dict interface"""

    # Not a series
    with pytest.raises(TypeError):
        _get_three_sigma_instrument_dict(
            interval_durations="abc",
            provided_averaging=Averaging.HUNDRED_SECONDS,
            instr_sigma=0.5,
        )

    # Not a timedelta
    with pytest.raises(TypeError):
        _get_three_sigma_instrument_dict(
            interval_durations=pd.Series(data=pd.Series([1])),
            provided_averaging=123,
            instr_sigma=0.5,
        )

    # Not a Averaging
    with pytest.raises(TypeError):
        _get_three_sigma_instrument_dict(
            interval_durations=pd.Series(data=pd.Timedelta("1 days")),
            provided_averaging=123,
            instr_sigma=0.5,
        )

    # Not a float
    with pytest.raises(TypeError):
        _get_three_sigma_instrument_dict(
            interval_durations=pd.Series(data=pd.Timedelta("1 days")),
            provided_averaging=Averaging.HUNDRED_SECONDS,
            instr_sigma=1,
        )

    ret = _get_three_sigma_instrument_dict(
        interval_durations=pd.Series(data=pd.Timedelta("1 days")),
        provided_averaging=Averaging.HUNDRED_SECONDS,
        instr_sigma=45.0,
    )
    assert isinstance(ret, dict)

    ret = _get_three_sigma_instrument_dict(
        interval_durations=pd.Series(data=pd.Timedelta("1 days")),
        provided_averaging=Averaging.HUNDRED_SECONDS,
        instr_sigma=np.NaN,
    )
    assert isinstance(ret, dict)


def test_add_range_menus():
    """Test menu interface"""

    mtime = pd.date_range("2022-04-14 00:00", "2022-04-14 01:55", periods=2)

    # Not a figure
    with pytest.raises(TypeError):
        _add_range_menus(
            original_fig="abv",
            plotting_averages=[AveragesSelection("Test", 1, [Averaging.ONE_HOUR])],
            max_time=mtime[-1],
        )

    # Not a list
    with pytest.raises(TypeError):
        _add_range_menus(
            original_fig=go.Figure(),
            plotting_averages={},
            max_time=mtime[-1],
        )

    # Not a timestamp
    with pytest.raises(TypeError):
        _add_range_menus(
            original_fig=go.Figure(),
            plotting_averages=[AveragesSelection("Test", 1, [Averaging.ONE_HOUR])],
            max_time="abc",
        )

    ret = _add_range_menus(
        original_fig=go.Figure(
            go.Scatter(x=mtime, y=[2, 3], text=Averaging.ONE_HOUR.value, name="abc")
        ),
        plotting_averages=[AveragesSelection("Test", 1, [Averaging.ONE_HOUR])],
        max_time=mtime[-1],
    )
    assert isinstance(ret, go.Figure)


def test_add_averaging_trace(fake_data_frame, fake_color_assignment, fake_sigma):
    # Not a figure
    with pytest.raises(TypeError):
        _add_averaging_trace(
            fig_original="abc",
            original_timeline_df=fake_data_frame,
            traces_colorscale=fake_color_assignment,
            show_marker=True,
            requested_averaging=Averaging.HUNDRED_SECONDS,
            reference_port_name="Port1",
            instrument_sigma=fake_sigma,
        )

    # Not a df
    with pytest.raises(TypeError):
        _add_averaging_trace(
            fig_original=go.Figure(),
            original_timeline_df=1,
            traces_colorscale=fake_color_assignment,
            show_marker=True,
            requested_averaging=Averaging.HUNDRED_SECONDS,
            reference_port_name="Port1",
            instrument_sigma=fake_sigma,
        )

    # Not a datetimeindex
    with pytest.raises(ValueError):
        _add_averaging_trace(
            fig_original=go.Figure(),
            original_timeline_df=pd.DataFrame(data={"a": [1, 2]}),
            traces_colorscale=fake_color_assignment,
            show_marker=True,
            requested_averaging=Averaging.HUNDRED_SECONDS,
            reference_port_name="Port1",
            instrument_sigma=fake_sigma,
        )

    # Not a dict
    with pytest.raises(TypeError):
        _add_averaging_trace(
            fig_original=go.Figure(),
            original_timeline_df=fake_data_frame,
            traces_colorscale=1,
            show_marker=True,
            requested_averaging=Averaging.HUNDRED_SECONDS,
            reference_port_name="Port1",
            instrument_sigma=fake_sigma,
        )

    # Not a bool
    with pytest.raises(TypeError):
        _add_averaging_trace(
            fig_original=go.Figure(),
            original_timeline_df=fake_data_frame,
            traces_colorscale=fake_color_assignment,
            show_marker=4,
            requested_averaging=Averaging.HUNDRED_SECONDS,
            reference_port_name="Port1",
            instrument_sigma=fake_sigma,
        )

    # Not a Averaging
    with pytest.raises(TypeError):
        _add_averaging_trace(
            fig_original=go.Figure(),
            original_timeline_df=fake_data_frame,
            traces_colorscale=fake_color_assignment,
            show_marker=True,
            requested_averaging=6,
            reference_port_name="Port1",
            instrument_sigma=fake_sigma,
        )

    # Not a str
    with pytest.raises(TypeError):
        _add_averaging_trace(
            fig_original=go.Figure(),
            original_timeline_df=fake_data_frame,
            traces_colorscale=fake_color_assignment,
            show_marker=True,
            requested_averaging=Averaging.HUNDRED_SECONDS,
            reference_port_name=8,
            instrument_sigma=fake_sigma,
        )

    # Ref not in columns
    with pytest.raises(ValueError):
        _add_averaging_trace(
            fig_original=go.Figure(),
            original_timeline_df=fake_data_frame,
            traces_colorscale=fake_color_assignment,
            show_marker=True,
            requested_averaging=Averaging.HUNDRED_SECONDS,
            reference_port_name="PortInf",
            instrument_sigma=fake_sigma,
        )

    # Not a float
    with pytest.raises(TypeError):
        _add_averaging_trace(
            fig_original=go.Figure(),
            original_timeline_df=fake_data_frame,
            traces_colorscale=fake_color_assignment,
            show_marker=True,
            requested_averaging=Averaging.HUNDRED_SECONDS,
            reference_port_name="port1",
            instrument_sigma="a",
        )

    ret = _add_averaging_trace(
        fig_original=go.Figure(),
        original_timeline_df=fake_data_frame,
        traces_colorscale=fake_color_assignment,
        show_marker=True,
        requested_averaging=Averaging.TEN_SECONDS,
        reference_port_name="port1",
        instrument_sigma=fake_sigma,
    )
    assert isinstance(ret, go.Figure)

    ret = _add_averaging_trace(
        fig_original=go.Figure(),
        original_timeline_df=fake_data_frame,
        traces_colorscale=fake_color_assignment,
        show_marker=True,
        requested_averaging=Averaging.TEN_SECONDS,
        reference_port_name="port1",
        instrument_sigma=np.NaN,
    )
    assert isinstance(ret, go.Figure)

    ret = _add_averaging_trace(
        fig_original=go.Figure(),
        original_timeline_df=fake_data_frame,
        traces_colorscale=fake_color_assignment,
        show_marker=False,
        requested_averaging=Averaging.TEN_SECONDS,
        reference_port_name="port1",
        instrument_sigma=np.NaN,
    )
    assert isinstance(ret, go.Figure)


def test_get_timeseries_plot_plotly(
    fake_data_frame, fake_color_assignment, fake_sigma, fake_plotting_requests
):
    # Not a df
    with pytest.raises(TypeError):
        get_timeseries_plot_plotly(
            original_df="abc",
            plot_template_request=fake_plotting_requests,
            traces_colorscale=fake_color_assignment,
            instrument_sigma=fake_sigma,
            show_negative_values=False,
            reference_port_name="port1",
            plot_title="Test",
        )

    # Not a datetimeindex
    with pytest.raises(ValueError):
        get_timeseries_plot_plotly(
            original_df=pd.DataFrame(data={"a": [1, 2]}),
            plot_template_request=fake_plotting_requests,
            traces_colorscale=fake_color_assignment,
            instrument_sigma=fake_sigma,
            show_negative_values=False,
            reference_port_name="port1",
            plot_title="Test",
        )

    # plot_template_request Not a list
    with pytest.raises(TypeError):
        get_timeseries_plot_plotly(
            original_df=fake_data_frame,
            plot_template_request=AveragesSelection("a", 1, [Averaging.ONE_HOUR]),
            traces_colorscale=fake_color_assignment,
            instrument_sigma=fake_sigma,
            show_negative_values=False,
            reference_port_name="port1",
            plot_title="Test",
        )

    # traces_colorscale Not a dict
    with pytest.raises(TypeError):
        get_timeseries_plot_plotly(
            original_df=fake_data_frame,
            plot_template_request=fake_plotting_requests,
            traces_colorscale="abc",
            instrument_sigma=fake_sigma,
            show_negative_values=False,
            reference_port_name="port1",
            plot_title="Test",
        )

    # instrument_sigma Not a float
    with pytest.raises(TypeError):
        get_timeseries_plot_plotly(
            original_df=fake_data_frame,
            plot_template_request=fake_plotting_requests,
            traces_colorscale=fake_color_assignment,
            instrument_sigma="a",
            show_negative_values=False,
            reference_port_name="port1",
            plot_title="Test",
        )

    # show_negative_values Not a bool
    with pytest.raises(TypeError):
        get_timeseries_plot_plotly(
            original_df=fake_data_frame,
            plot_template_request=fake_plotting_requests,
            traces_colorscale=fake_color_assignment,
            instrument_sigma=fake_sigma,
            show_negative_values="a",
            reference_port_name="port1",
            plot_title="Test",
        )

    # reference_port_name Not a str
    with pytest.raises(TypeError):
        get_timeseries_plot_plotly(
            original_df=fake_data_frame,
            plot_template_request=fake_plotting_requests,
            traces_colorscale=fake_color_assignment,
            instrument_sigma=fake_sigma,
            show_negative_values=True,
            reference_port_name=1,
            plot_title="Test",
        )

    # reference_port_name not in columns
    with pytest.raises(ValueError):
        get_timeseries_plot_plotly(
            original_df=fake_data_frame,
            plot_template_request=fake_plotting_requests,
            traces_colorscale=fake_color_assignment,
            instrument_sigma=fake_sigma,
            show_negative_values=True,
            reference_port_name="Port_blabla",
            plot_title="Test",
        )

    # plot_title Not a str
    with pytest.raises(TypeError):
        get_timeseries_plot_plotly(
            original_df=fake_data_frame,
            plot_template_request=fake_plotting_requests,
            traces_colorscale=fake_color_assignment,
            instrument_sigma=fake_sigma,
            show_negative_values=True,
            reference_port_name="port1",
            plot_title=1,
        )

    ret = get_timeseries_plot_plotly(
        original_df=fake_data_frame,
        plot_template_request=fake_plotting_requests,
        traces_colorscale=fake_color_assignment,
        instrument_sigma=fake_sigma,
        show_negative_values=True,
        reference_port_name="port1",
        plot_title="Test",
    )
    assert isinstance(ret, go.Figure)

    ret = get_timeseries_plot_plotly(
        original_df=fake_data_frame,
        plot_template_request=fake_plotting_requests,
        traces_colorscale=fake_color_assignment,
        instrument_sigma=fake_sigma,
        show_negative_values=False,
        reference_port_name="port1",
        plot_title="Test",
    )
    assert isinstance(ret, go.Figure)


@pytest.mark.parametrize(
    "fake_dt, expectation",
    [
        (
            1,
            pytest.raises(TypeError),
        ),
        (
            "abc",
            pytest.raises(TypeError),
        ),
        (
            pd.Timedelta("1H"),
            does_not_raise(),
        ),
        (
            pd.Timedelta(days=0.5),
            does_not_raise(),
        ),
        (
            pd.Timedelta(days=3),
            does_not_raise(),
        ),
        (
            pd.Timedelta(days=10),
            does_not_raise(),
        ),
        (
            pd.Timedelta(days=20),
            does_not_raise(),
        ),
        (
            pd.Timedelta(days=40),
            does_not_raise(),
        ),
        (
            pd.Timedelta(days=100),
            does_not_raise(),
        ),
        (
            pd.Timedelta(days=150),
            does_not_raise(),
        ),
        (
            pd.Timedelta(days=200),
            does_not_raise(),
        ),
        (
            pd.Timedelta(days=300),
            does_not_raise(),
        ),
        (
            pd.Timedelta(days=400),
            does_not_raise(),
        ),
        (
            pd.Timedelta(days=600),
            does_not_raise(),
        ),
    ],
)
def test_get_default_timeseries_template(fake_dt, expectation):
    """Test get_default_timeseries_template"""
    with expectation:
        result = get_default_timeseries_template(time_duration=fake_dt)
        assert isinstance(result, List)
        assert all(isinstance(button, AveragesSelection) for button in result)
        assert len(result) > 0
