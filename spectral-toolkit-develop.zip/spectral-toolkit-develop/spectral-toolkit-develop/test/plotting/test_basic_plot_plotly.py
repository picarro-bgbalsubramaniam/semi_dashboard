"""Test for basic plot (plotting and exporting)"""

from unittest import mock
import pandas as pd
import plotly.graph_objects
import pytest


from spectral_toolkit.plotting.basic_plot_plotly import (
    Orientation,
    PlotFileFormat,
    _add_basic_plot_layout,
    get_allan_deviation_dataframe,
    _get_allan_factory_line,
    _get_layout_decadic_shapes,
    _get_layout_ticks_info,
    export_graph_object_to_file,
    get_allan_plot_plotly,
    get_allan_single_frame,
)


def test_export_formats_call_counts():
    """Verify that the calls to the Figure methods
    to write figures to file are successful"""
    gr_obj_mock = mock.MagicMock()

    export_graph_object_to_file(gr_obj_fig=gr_obj_mock, file_format=PlotFileFormat.JSON)
    assert gr_obj_mock.write_json.call_count == 1

    gr_obj_mock.reset_mock()
    export_graph_object_to_file(gr_obj_fig=gr_obj_mock, file_format=PlotFileFormat.HTML)
    assert gr_obj_mock.write_html.call_count == 1

    gr_obj_mock.reset_mock()
    export_graph_object_to_file(gr_obj_fig=gr_obj_mock, file_format=PlotFileFormat.PNG)
    assert gr_obj_mock.write_image.call_count == 1

    gr_obj_mock.reset_mock()
    export_graph_object_to_file(gr_obj_fig=gr_obj_mock, file_format=PlotFileFormat.PDF)
    assert gr_obj_mock.write_image.call_count == 1


def test_export_exception():
    """Test wrong file path or export formats"""
    gr_obj_mock = mock.MagicMock()

    with pytest.raises(ValueError):
        export_graph_object_to_file(gr_obj_mock, file_format="xxx")

    with pytest.raises(NotADirectoryError):
        export_graph_object_to_file(gr_obj_mock, export_path="_%_y")


def test_ticks_info(fake_series):
    """Test the right ticks are generated from the fake_series"""
    with pytest.raises(TypeError):
        _get_layout_ticks_info([1])

    expected = {
        0.1: "10<sup>-1</sup>",
        0.2: " ",
        0.3: " ",
        0.4: " ",
        0.5: " ",
        0.6: " ",
        0.7: " ",
        0.8: " ",
        0.9: " ",
        1.0: "10<sup>0</sup>",
        2.0: " ",
        3.0: " ",
        4.0: " ",
        5.0: " ",
        6.0: " ",
        7.0: " ",
        8.0: " ",
        9.0: " ",
    }
    allan_df = get_allan_deviation_dataframe(fake_series)
    test = _get_layout_ticks_info(allan_df.allan_dev)
    assert isinstance(test, dict)
    assert expected == test


def test_layout_shapes(fake_series):
    """Test the right shapes are generated through the fake_series.
    Check the number of shapes generated, and if the vertical/horizontal lines
    are generated correctly."""
    with pytest.raises(TypeError):
        _get_layout_decadic_shapes([1], Orientation.VERTICAL)

    allan_df = get_allan_deviation_dataframe(fake_series)
    ticks = _get_layout_ticks_info(allan_df.allan_dev)
    test = _get_layout_decadic_shapes(ticks, Orientation.VERTICAL)
    expected_ntuples = 4

    assert isinstance(test, tuple)
    assert expected_ntuples == len(test)

    for shape in test:
        assert shape["x0"] == shape["x1"]

    test = _get_layout_decadic_shapes(ticks, Orientation.HORIZONTAL)

    for shape in test:
        assert shape["y0"] == shape["y1"]


def test_allan_factory_line(fake_series, fake_sigma):
    """Test that the allan factory line with fake_series and
    fake_sigma corresponds to the hardcoded one."""

    with pytest.raises(TypeError):
        _get_allan_factory_line([1])

    expected_x = (
        1.1600000000000001,
        3.469209172433232,
        10.375355415599024,
        31.029550150905983,
        92.80000000000001,
    )
    expected_y = (
        32.589531850072596,
        18.84481478959958,
        10.896966734228187,
        6.3011435948105055,
        3.643620428582841,
    )
    allan_df = get_allan_deviation_dataframe(fake_series)
    test = _get_allan_factory_line(allan_df.tau_scaled, fake_sigma)

    assert isinstance(test, zip)

    x_t, y_t = zip(*test)
    assert expected_y == pytest.approx(y_t)
    assert expected_x == pytest.approx(x_t)

    test = _get_allan_factory_line(allan_df.tau_scaled)
    assert isinstance(test, zip)


def test_add_basic_plot_layout(fake_data_frame):
    """Test input formats exceptions for the _add_basic_plot_layout"""

    with pytest.raises(TypeError):
        _add_basic_plot_layout(
            [1],
            synchronize_yaxis=True,
            concentration_units="ppb",
            title_text="",
            df_allan_dev=fake_data_frame,
        )

    with pytest.raises(TypeError):
        _add_basic_plot_layout(
            plotly.graph_objects.Figure(),
            synchronize_yaxis=True,
            concentration_units="ppb",
            title_text="",
            df_allan_dev=[1],
        )


def test_get_allan_single_frame(fake_series, fake_sigma):
    """Test input format exception and that the return Plotly Figure is
    a figure, with data and layout fields."""
    with pytest.raises(ValueError):
        get_allan_single_frame([1])

    ret = get_allan_single_frame(
        port_ts_data=fake_series, color="black", instrument_sigma=fake_sigma
    )
    assert isinstance(ret, plotly.graph_objects.Figure)
    assert ret.data
    assert ret.layout


def test_get_allan_plot_plotly(fake_data_frame, fake_color_assignment, fake_sigma):
    """Test inputs format exception and that the return Plotly Figure
    is a figure, with data and layout fields."""
    with pytest.raises(TypeError):
        get_allan_plot_plotly([1], {})

    with pytest.raises(ValueError):
        get_allan_plot_plotly(pd.DataFrame(data={"a": [1]}), {})

    with pytest.raises(TypeError):
        get_allan_plot_plotly(fake_data_frame, [1])

    ret = get_allan_plot_plotly(
        data_frame=fake_data_frame,
        traces_colorscale=fake_color_assignment,
        instrument_sigma=fake_sigma,
    )
    assert isinstance(ret, plotly.graph_objects.Figure)
    assert ret.data
    assert ret.layout
