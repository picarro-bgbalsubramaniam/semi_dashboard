from unittest.mock import patch

import math

import numpy as np
import pytest

from spectral_toolkit.data_models.allantools import _remove_small_ns, _tau_generator, _frequency2phase, \
    _calc_adev_phase, oadev


def test_remove_small_ns():
    """Test _remove_small_ns"""

    with pytest.raises(ValueError):
        _remove_small_ns(
            taus=np.array([1, 2, 3]),
            devs=np.array([1, 2, 3]),
            deverrs=np.array([1, 2, 3]),
            ns=np.array([1, 2]),
        )

    with pytest.raises(UserWarning):
        _remove_small_ns(
            taus=np.array([1, 2, 3]),
            devs=np.array([1, 2, 3]),
            deverrs=np.array([1, 2, 3]),
            ns=np.array([1, 1, 1]),
        )

    start_tau = np.array([1, 2, 3])
    r_tau, r_devs, r_dev_err, r_ns = _remove_small_ns(
        taus=start_tau,
        devs=np.array([1, 2, 3]),
        deverrs=np.array([1, 2, 3]),
        ns=np.array([1, 2, 3]),
    )

    assert all(isinstance(arr, np.ndarray)
               for arr in [r_tau, r_devs, r_dev_err, r_ns])

    len_check = len(r_tau)
    assert all(len(arr) == len_check
               for arr in [r_tau, r_devs, r_dev_err, r_ns])

    assert len_check <= len(start_tau)


def test_tau_generator():
    with pytest.raises(ValueError):
        _tau_generator(
            data=np.array([]),
        )

    with pytest.raises(UserWarning):
        _tau_generator(
            data=np.array([1]),
        )

    inp = np.array([1, 2, 3, 4, 5, 6])
    result = _tau_generator(
            data=inp,
        )

    assert isinstance(result, np.ndarray)
    assert len(result) <= len(inp)
    assert len(result) > 0


def test_frequency2phase():
    """Test _frequency2phase"""
    with pytest.raises(ValueError):
        _frequency2phase(np.array([]))

    inp = np.array([1, 2, 3, 4])
    result = _frequency2phase(inp)

    assert len(result) == len(inp) + 1
    assert isinstance(result, np.ndarray)

    inp = np.array([1])
    result = _frequency2phase(inp)

    assert len(result) == len(inp) + 1
    assert isinstance(result, np.ndarray)


@pytest.mark.filterwarnings('ignore::RuntimeWarning')
def test_calc_adev_phase():
    inp = np.array([1, 2, 3, 4, 3, 2, 1, 1])
    inp = inp - np.mean(inp)

    taus = _tau_generator(inp)

    dev, deverr, n = _calc_adev_phase(
        phase=inp,
        mj=taus[-1],
        stride=1
    )
    assert np.isclose(dev, 0)
    assert np.isclose(deverr, 0)
    assert n == 1

    for i in range(len(taus)-1):
        dev, deverr, n = _calc_adev_phase(
            phase=inp,
            mj=i,
            stride=1
        )
        assert isinstance(dev, float)
        assert isinstance(deverr, float)
        assert isinstance(n, int)


def test_oadev():
    inp = np.random.rand(20)
    taus, adev, err, n = oadev(inp)

    check_len = len(taus)
    assert all(len(arr) == check_len
               for arr in [taus, adev, err, n])

    assert check_len < len(inp)
