from spectral_toolkit import ica_isolation
import numpy as np
from pathlib import Path
import pytest
from spectral_arithmetic.allan_deviation import AllanBin
from spectral_arithmetic.data_models.spectra import BinnedSpectra, ModeBin


PICKLE_FILE = (
    Path(".").resolve()
    / "test/test_data/compact_data.pkl"
)


def load_pickle():
    spectra = []
    from pickle import load
    with open(PICKLE_FILE, 'rb') as f:
        from_pickle = load(f)
    test_spectra = from_pickle['spectra']
    group_df = from_pickle['group_df']
    for x in range(len(test_spectra)):
        mode_keys = test_spectra[x]['binned_data'].keys()
        binned_data = {k: np.array([ModeBin(**x) for x in test_spectra[x]['binned_data'][k]]) for k in mode_keys}
        binned_allan = {k: {'foo': AllanBin(1)} for k in mode_keys}
        num_spectra = test_spectra[x]['num_spectra']
        fsr_prime = test_spectra[x]['fsr_prime']
        f0_prime = test_spectra[x]['f0_prime']
        epoch_time = test_spectra[x]['epoch_time']

        binned_spectra = BinnedSpectra(binned_data=binned_data,
                                       binned_allan=binned_allan,
                                       num_spectra=num_spectra,
                                       fsr_prime=fsr_prime,
                                       f0_prime=f0_prime,
                                       epoch_time=epoch_time)
        spectra.append(binned_spectra)
    return group_df, spectra


GROUP_DF, SPECTRA = load_pickle()


# ICA data points
FIRST_0_0 = 5847.037749562862
FIRST_1_0 = 0.0012721622822048583
FIRST_2_0 = 1.1808839400528448e-05
FIRST_3_0 = -27.669777337599005

# Diff data points
NU_1_0 = 5847.037773449511
ABS_1_0 = 651.5432462013374

REFERENCE_PORT = 8
LODS = {
    "ACETIC_ACID_raw": 1.0,
    "D3_SILOXANE_raw": 1.0,
    "D6_SILOXANE_raw": 1.0,
    "FORMIC_ACID_raw": 1.0,
    "HMDSO_raw": 1.0,
    "NMP_raw": 1.0,
    "TRIMETHYL_SILANOL_raw": 1.0
}

LODS_ZERO = LODS.copy()
LODS_ZERO["ACETIC_ACID_raw"] = 0

CANARIES = [
    "ACETIC_ACID_raw",
    "D3_SILOXANE_raw",
    "D6_SILOXANE_raw",
    "FORMIC_ACID_raw",
    "HMDSO_raw",
    "NMP_raw",
    "TRIMETHYL_SILANOL_raw"
]


def test_zero_reference():
    df_referenced = ica_isolation.zero_reference_port_data(GROUP_DF, CANARIES, 14400, REFERENCE_PORT)
    assert np.around(df_referenced["ACETIC_ACID_raw"][:3], 5).tolist() == [-2.62181, 2.55947, -0.26805]
    assert np.around(df_referenced["TRIMETHYL_SILANOL_raw"][:3], 5).tolist() == [2.44577, -3.98309, 0.55521]
    assert np.around(df_referenced["D6_SILOXANE_raw"][:3], 5).tolist() == [-0.44408, 0.42094, -0.20672]

    # Check that we raise an error if canaries are not in df
    with pytest.raises(ValueError):
        df_referenced = ica_isolation.zero_reference_port_data(GROUP_DF, ["foo", "bar"], 14400, REFERENCE_PORT)


def test_scale_by_noise():
    df_referenced = ica_isolation.zero_reference_port_data(GROUP_DF, CANARIES, 14400, REFERENCE_PORT)
    df_fom = ica_isolation.scale_by_noise(df_referenced, CANARIES, LODS)
    assert np.around(df_fom["ACETIC_ACID_raw"][:3], 5).tolist() == [-6.30635, 14.02476, -0.65394]
    assert np.around(df_fom["TRIMETHYL_SILANOL_raw"][:3], 5).tolist() == [5.88292, -21.82561, 1.35449]
    assert np.around(df_fom["D6_SILOXANE_raw"][:3], 5).tolist() == [-1.06818, 2.30656, -0.50432]

    # test that we raise an error with a zero lod value
    with pytest.raises(ValueError):
        df_fom = ica_isolation.scale_by_noise(df_referenced, CANARIES, LODS_ZERO)

    # Raise an error if we don't have lods for all canaries defined
    with pytest.raises(ValueError):
        temp_lods = LODS.copy()
        del temp_lods["ACETIC_ACID_raw"]
        df_fom = ica_isolation.scale_by_noise(df_referenced, CANARIES, temp_lods)


def test_apply_ica():
    """Test that ICA produces expected results on standard test data"""
    df_referenced = ica_isolation.zero_reference_port_data(GROUP_DF, CANARIES, 14400, REFERENCE_PORT)
    df_fom = ica_isolation.scale_by_noise(df_referenced, CANARIES, LODS)
    signals = []
    for port in df_fom["ValveMask"].unique():
        if port != REFERENCE_PORT:
            # Get signals on specific port
            df_fom = df_fom[df_fom["ValveMask"] == port]
            # Select spectra for port
            spectra = [SPECTRA[i] for i in df_fom.index.tolist()]
            # append signals
            signals.append(ica_isolation.apply_ica(df_fom, spectra, CANARIES))

    assert len(signals) == 1
    assert list(signals[0].keys()) == [1]
    ica_results = signals[0][1]
    assert np.abs(np.around(ica_results.mapping, 5)).tolist() == list(map(abs, [-0.91554, -1.61028, 0.15583, 45.52934, 1.34113, 9.86945, -7.58405]))
    assert np.abs(np.around(ica_results.slope_fit, 5)).tolist()[:3] == list(map(abs, [-0.00127, -0.00121, -0.00124]))
