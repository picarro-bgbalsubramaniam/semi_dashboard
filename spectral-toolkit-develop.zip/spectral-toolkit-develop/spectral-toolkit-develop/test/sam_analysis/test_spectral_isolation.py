from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import pytest
from pydantic import BaseModel
from spectral_arithmetic.allan_deviation import AllanBin
from spectral_arithmetic.data_models.spectra import BinnedSpectra, ModeBin

from spectral_toolkit.data_models.filters import Filter, FilterType
from spectral_toolkit.sam_analysis import spectral_isolation as si

PICKLE_FILE = (
    Path(".").resolve()
    / "test/test_data/compact_data.pkl"
)


def load_pickle():
    spectra = []
    from pickle import load
    with open(PICKLE_FILE, 'rb') as f:
        from_pickle = load(f)
    test_spectra = from_pickle['spectra']
    group_df = from_pickle['group_df']
    for x in range(len(test_spectra)):
        mode_keys = test_spectra[x]['binned_data'].keys()
        binned_data = {k: np.array([ModeBin(**x) for x in test_spectra[x]['binned_data'][k]]) for k in mode_keys}
        binned_allan = {k: {'foo': AllanBin(1)} for k in mode_keys}
        num_spectra = test_spectra[x]['num_spectra']
        fsr_prime = test_spectra[x]['fsr_prime']
        f0_prime = test_spectra[x]['f0_prime']
        epoch_time = test_spectra[x]['epoch_time']

        binned_spectra = BinnedSpectra(binned_data=binned_data,
                                       binned_allan=binned_allan,
                                       num_spectra=num_spectra,
                                       fsr_prime=fsr_prime,
                                       f0_prime=f0_prime,
                                       epoch_time=epoch_time)
        spectra.append(binned_spectra)
    return group_df, spectra


GROUP_DF, SPECTRA = load_pickle()

# ICA data points
FIRST_0_0 = 5847.037749562862
FIRST_1_0 = 0.004368511745463854
FIRST_2_0 = 5.248963757787378e-05
FIRST_3_0 = 14.024756170126555

# Diff data points
NU_1_0 = 5847.037773449511
ABS_1_0 = 651.5432462013374

GHOSTS = [
    "broadband_gasConcs_222",
    "broadband_gasConcs_280",
    "broadband_gasConcs_297",
    "broadband_gasConcs_402",
    "broadband_gasConcs_6324",
    "broadband_gasConcs_6344",
    "broadband_gasConcs_8003",
    "broadband_gasConcs_948",
    "broadband_gasConcs_962"
]

WORKHORSES = [
    "broadband_gasConcs_180",
    "broadband_gasConcs_3776",
    "broadband_gasConcs_1140",
    "broadband_gasConcs_7344"
]

CANARIES = [
    "ACETIC_ACID_raw",
    "D3_SILOXANE_raw",
    "D6_SILOXANE_raw",
    "FORMIC_ACID_raw",
    "HMDSO_raw",
    "NMP_raw",
    "TRIMETHYL_SILANOL_raw"
]


filters = [
    Filter(
        column="cavityPressureStd",
        filter_type=FilterType.include, 
        high=0.5,
        low=0.0
    )
]


class Instrument(BaseModel):
    name: str = "NUV1047"
    LOD: Dict[str, float] = {"ACETIC_ACID_raw": 1.0}
    meta_data: Dict[str, Any] = {"ave_time": 100, "sigma": 3}


class ICACorrelation(BaseModel):
    name: str = "ica_correlation"
    filters: List[Filter] = filters
    time_cutters: Dict = {}
    ica_components: int = 1
    columns: str = "canaries"
    keep_top_canaries_frac: float = 0.2
    signal_strength_thresh: float = 1.25


class DiffIsolation(BaseModel):
    name: str = "difference_isolation"
    filters: List[Filter] = filters
    time_cutters: Dict = {}


def test_diff_isolation():
    """
    Difference isolation is pretty simple,
    just validate we can run with a good known
    group averaged dataframe and associated binned spectra
    """
    signals = si.difference_spectral_isolation(
        GROUP_DF,
        SPECTRA,
        {'1': 'port_01', '8': 'port_08'},
        filters
    )
    assert list(signals.keys()) == [1, 8]
    assert signals[1].nu_prime[0] == pytest.approx(NU_1_0)
    assert signals[1].absorption[0] == pytest.approx(ABS_1_0)


def test_corr_isolation():
    # Make sure we can run without error
    signals_corr = si.ica_spectral_isolation(
        GROUP_DF,
        SPECTRA,
        Instrument().model_dump(),
        CANARIES,
        8,
        {'1': 'port_01', '8': 'port_08'},
        ICACorrelation().model_dump(),
        14400,
    )
    assert list(signals_corr.keys()) == [(1, 1, 0), (1, 8, 0)]
    assert signals_corr[(1, 1, 0)][0][0] == pytest.approx(FIRST_0_0)
    assert abs(signals_corr[(1, 1, 0)][1][0]) == pytest.approx(FIRST_1_0)
    assert abs(signals_corr[(1, 1, 0)][2][0]) == pytest.approx(FIRST_2_0)
    assert abs(signals_corr[(1, 1, 0)][3][0]) == pytest.approx(FIRST_3_0)
