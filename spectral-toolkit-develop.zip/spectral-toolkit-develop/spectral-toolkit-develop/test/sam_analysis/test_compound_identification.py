from spectral_toolkit.sam_analysis import compound_identification as ci
import numpy as np
import pytest


P_NAMES = ["offset", "180"]
EXTRA_CIDS = ["280"]
A_LIST = [np.arange(1, 10, 1)] * 2
FIT = [-0.5, -0.5]
LOSS = np.array([0.5, 0.5])
Y_FIT = np.array([0.6, 0.4])
STD_ERR = np.array([0.01, 0.01])
NEG_PEN = 8.441
MODEL_STD = 3.979
REL_ERR = 10
DEF_ERR = np.array([0.07071068, 0.07071068])


def test_compute_neg_penalty():
    result = ci._compute_negative_penalty(FIT, A_LIST, P_NAMES)
    assert result == pytest.approx(NEG_PEN, 0.01)


def test_compute_model_func_std():
    result = ci._compute_model_func_std(FIT, A_LIST, P_NAMES)
    assert result == pytest.approx(MODEL_STD, 0.01)


def test_compute_relative_error():
    result = ci._compute_relative_error(Y_FIT, LOSS, STD_ERR)
    assert result == pytest.approx(REL_ERR, 0.01)


def test_compute_pos_neg_span():
    result = ci._compute_pos_neg_span(FIT, A_LIST, P_NAMES)
    assert result == 5.0


def test_relative_contribution():
    results = ci._compute_relative_contribution(FIT, A_LIST, EXTRA_CIDS)
    assert results == 0.5


def test_default_error():
    result = ci._get_default_error(np.array([1, 1]))
    assert result.tolist() == [pytest.approx(val, 0.0005) for val in DEF_ERR.tolist()]


def test_compute_allan():
    result = ci._compute_allan(np.arange(1000), np.arange(1000))
    assert result == 0
