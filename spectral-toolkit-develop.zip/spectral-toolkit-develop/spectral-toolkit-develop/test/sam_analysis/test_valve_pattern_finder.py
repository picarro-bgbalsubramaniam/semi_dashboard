from spectral_toolkit.sam_analysis import valve_pattern_finder as vpf
from pandas import DataFrame
from datetime import datetime as dt
import pytz
import pytest


def _produce_dt(stop_time: int) -> dt:
    if stop_time > 0:
        dt_obj = dt(1970, 1, 1, 0, 0, stop_time)
    else:
        dt_obj = dt(1970, 1, 1, 0, 0)

    return pytz.utc.localize(dt_obj)


# Simplest case, basic repeating patter
STANDARD_DATA = {
    "ValveMask": [1, 2, 3, 1, 2, 3],
    "time_delta": [60] * 6,
    "stop_time": [1, 2, 3, 4, 5, 6],
    "jump": [False] * 6,
}

PLAN_TIME_CHANGE_DATA = {
    "ValveMask": [1, 2, 3, 1, 2, 3, 2, 3, 2, 3],
    "time_delta": [60, 60, 60, 120, 60, 60, 60, 60, 60, 60],
    "stop_time": [1, 2, 3, 4, 5, 6, 7, 8, 9, 11],
    "jump": [False] * 10,
}

PLAN_NEW_MASK_DATA = {
    "ValveMask": [1, 2, 3, 1, 2, 3, 0],
    "time_delta": [60, 60, 60, 60, 60, 60, 1000],
    "stop_time": [1, 2, 3, 4, 5, 6, 7],
    "jump": [False] * 7,
}

PLAN_MASK_VALID_START_AFTER_MASK_CHANGE = {
    "ValveMask": [1, 2, 3, 1, 2, 3, 0, 1, 2, 3, 1, 2, 3],
    "time_delta": [60, 60, 60, 60, 60, 60, 1000, 60, 60, 60, 60, 60, 60],
    "stop_time": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
    "jump": [False] * 13,
}

PLAN_JUMP = {
    "ValveMask": [1, 2, 3, 1, 2, 3],
    "time_delta": [60] * 6,
    "stop_time": [1, 2, 3, 4, 5, 6],
    "jump": [False, False, True, False, False, False],
}

PLAN_BREAK_PATTERN = {
    "ValveMask": [1, 2, 3, 1, 2, 3, 2, 3, 4, 2, 3, 4, 3],
    "time_delta": [60] * 13,
    "stop_time": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
    "jump": [False] * 13,
}

NEW_MASK_AFTER_PATTERN = {
    "ValveMask": [1, 2, 3, 1, 2, 3, 2, 3, 4, 2, 3, 4, 0],
    "time_delta": [60] * 13,
    "stop_time": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
    "jump": [False] * 13,
}

IRREGULAR_MASK_PATTERN = {
    "ValveMask": [1, 2, 1, 2, 8, 1, 2, 1, 2, 8, 1, 2] + [0],
    "time_delta": [60] * 12 + [100],
    "stop_time": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
    "jump": [False] * 13,
}


SKIP_TEST_MESSAGE = "Refactors needed for Pydantic v2 with regards to timestamps"

@pytest.mark.skip(SKIP_TEST_MESSAGE)
def test_standard():
    plan_df = DataFrame(STANDARD_DATA)
    plan = vpf.detect_pattern(plan_df, min_duration=1)[0]
    assert plan.pattern == [1, 2, 3]
    assert plan.repeated == 2
    assert plan.start_time == _produce_dt(0)
    assert plan.stop_time == _produce_dt(6)


@pytest.mark.skip(SKIP_TEST_MESSAGE)
def test_time_changed():
    # Actually tests time shift and end of plan change
    plan_df = DataFrame(PLAN_TIME_CHANGE_DATA)
    plans = vpf.detect_pattern(plan_df, min_duration=1)
    assert len(plans) == 1
    assert plans[0].start_time == _produce_dt(4)
    assert plans[0].stop_time == _produce_dt(11)
    assert plans[0].pattern == [2, 3]
    assert plans[0].repeated == 3


@pytest.mark.skip(SKIP_TEST_MESSAGE)
def test_new_mask_after_pattern():
    plan_df = DataFrame(PLAN_NEW_MASK_DATA)
    plans = vpf.detect_pattern(plan_df, min_duration=1)
    assert len(plans) == 1
    assert plans[0].pattern == [1, 2, 3]


@pytest.mark.skip(SKIP_TEST_MESSAGE)
def test_single_bad_start_after_mask_change():
    plan_df = DataFrame(PLAN_MASK_VALID_START_AFTER_MASK_CHANGE)
    plans = vpf.detect_pattern(plan_df, min_duration=1)
    assert plans[0].pattern == [1, 2, 3]
    assert plans[0].start_time == _produce_dt(0)
    assert plans[0].stop_time == _produce_dt(6)
    assert plans[1].pattern == [1, 2, 3]
    assert plans[1].repeated == 2
    assert plans[1].start_time == _produce_dt(7)
    assert plans[1].stop_time == _produce_dt(13)


@pytest.mark.skip(SKIP_TEST_MESSAGE)
def test_plan_jump():
    # Make sure we don't include analyzer off step
    plan_df = DataFrame(PLAN_JUMP)
    plans = vpf.detect_pattern(plan_df, min_duration=1)
    assert plans[0].pattern == [1, 2, 3]
    assert plans[0].repeated == 2


@pytest.mark.skip(SKIP_TEST_MESSAGE)
def test_plan_break_pattern():
    plan_df = DataFrame(PLAN_BREAK_PATTERN)
    plans = vpf.detect_pattern(plan_df, min_duration=1)
    assert plans[0].pattern == [1, 2, 3]
    assert plans[0].start_time == _produce_dt(0)
    assert plans[0].stop_time == _produce_dt(6)
    assert plans[1].pattern == [2, 3, 4]
    assert plans[1].repeated == 2
    assert plans[1].start_time == _produce_dt(6)
    assert plans[1].stop_time == _produce_dt(12)


@pytest.mark.skip(SKIP_TEST_MESSAGE)
def test_new_mask():
    plan_df = DataFrame(NEW_MASK_AFTER_PATTERN)
    plans = vpf.detect_pattern(plan_df, min_duration=1)
    assert plans[0].pattern == [1, 2, 3]
    assert plans[0].start_time == _produce_dt(0)
    assert plans[0].stop_time == _produce_dt(6)
    assert plans[1].pattern == [2, 3, 4]
    assert plans[1].repeated == 2
    assert plans[1].start_time == _produce_dt(6)
    assert plans[1].stop_time == _produce_dt(12)


@pytest.mark.skip(SKIP_TEST_MESSAGE)
def test_irregular():
    plan_df = DataFrame(IRREGULAR_MASK_PATTERN)
    plans = vpf.detect_pattern(plan_df, min_duration=1)
    assert plans[0].pattern == [1, 2, 1, 2, 8]
    assert plans[0].repeated == 2
    assert plans[0].start_time == _produce_dt(0)
    assert plans[0].stop_time == _produce_dt(12)
