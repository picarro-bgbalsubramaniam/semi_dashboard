from spectral_toolkit.sam_analysis import compactify
import pytz
from datetime import datetime as dt
from pathlib import Path
import pandas as pd
from spectral_toolkit.df_operations import sam_df
from data_pooler.api.combined_logs import get_timeseries_with_combo_info


START_TME_STR = '2022-03-10 00:00:00'
END_TME_STR = '2022-03-10 23:59:00'

START = dt.strptime(START_TME_STR, '%Y-%m-%d %H:%M:%S')
END = dt.strptime(END_TME_STR, '%Y-%m-%d %H:%M:%S')
BASE = Path(".").resolve() / 'test/test_data/pools/NUV1047'
COMBO_COLS = [
    'f0',
    'f0_shift',
    'fitData_fitdata_params_nucenter',
    'fitData_nu_transform_n0',
    'fitData_nu_transform_n1',
    'gasConcs_280',
    'gasConcs_297',
    'gasConcs_962',
    'file_path',
    'zpickle_ordinal'
]
COMBO_LEN = 41983
PRIVATE_COLS = ['ValveMask', '_group', 'broadband_gasConcs_176']
PRIVATE_DAY_ONE_LEN = 20969
PRIVATE_DAY_TWO_LEN = 21014
TIME_ZONE = 'Asia/Taipei'


def test_regression():
    """
    Test that the new data pooled zpickles and compactify behave the same way as old 
    zpickles and compactify
    """
    # Old df gather
    combo_df = compactify.pull_combo_results(BASE, START, END, TIME_ZONE)
    private_df = compactify.get_dataframes(BASE, START, END, TIME_ZONE)

    # New df gather
    combined_df = get_timeseries_with_combo_info(
        START_TME_STR, END_TME_STR, TIME_ZONE, BASE, combo_columns=COMBO_COLS
    )

    # Same treatment as old way, mostly these transitions are filtered out when trimming steps
    combined_df["_group"] = (
        (abs(combined_df["ValveMask"] - combined_df["ValveMask"].shift()) >= 0.5)
        .cumsum()
        .to_numpy()
    )
    combined_df = combined_df.groupby("_group", group_keys=False).apply(sam_df.replace_valve_key_with_median)

    # Old way wasn't trimming based on user request this early, doing it here
    start, end = combined_df.index[0], combined_df.index[-1]
    combo_df = combo_df.loc[start:end]
    private_df = private_df.loc[start:end]

    # Verify our masks look the same
    assert combined_df['ValveMask'].tolist() == private_df["ValveMask"].tolist()
    # Verify all of our timestamps line up and are equal in both ways
    assert combined_df.index.tolist() == private_df.index.tolist()
    compact_gen = compactify.generate_spectrum_groups(private_df, combo_df)
    new_compact_gen = compactify.compact_data(combined_df)
    print(len(list(new_compact_gen)), len(list(compact_gen)))

    # The new version will include one more spectrum in the beginning.  Not sure
    # why this spectrum is dropped in old version
    # At least we can verify the next 40 compact spectra are exactly the same
    for (n_group, n_bin_spec, _), (o_group, o_bin_spec) in zip(new_compact_gen, compact_gen):
        if n_group > 0:
            assert n_group == o_group
            assert n_bin_spec.nu_prime.tolist() == o_bin_spec.nu_prime.tolist()
