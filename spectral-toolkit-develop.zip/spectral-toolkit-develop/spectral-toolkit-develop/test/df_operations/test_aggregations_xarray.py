"""
Text Xarray time series aggregations
"""
import logging
from contextlib import nullcontext as does_not_raise

import numpy as np
import pandas as pd
import pytest
import xarray as xr
from pydantic import ValidationError

from spectral_toolkit.constants.plotting_constants import Averaging
from spectral_toolkit.df_operations.timeline_aggregations import get_intervals_statistics
from spectral_toolkit.df_operations.timeline_aggregations_xarray import (
    resample_dataset_xr, intervals_figure_of_merit_xarray, _quantile_duration_filtering,
)


@pytest.mark.parametrize(
    "fake_private_xray, data_variable, averaging_request, min_count, expectation",
    [
        (
            100,
            "variable_value",
            Averaging.TEN_SECONDS,
            -1,
            pytest.raises(ValidationError),
        ),
        (
            0,
            {},
            Averaging.TEN_SECONDS,
            -1,
            pytest.raises(ValidationError),
        ),
        (
            0,
            "variable_value",
            {},
            -1,
            pytest.raises(ValidationError),
        ),
        (
            0,
            "variable_value",
            Averaging.TEN_SECONDS,
            {},
            pytest.raises(ValidationError),
        ),
        (
            1,
            "variable_value",
            Averaging.TEN_SECONDS,
            -1,
            pytest.raises(ValueError),
        ),
        (
            2,
            "variable_value",
            Averaging.TEN_SECONDS,
            -1,
            pytest.raises(ValueError),
        ),
        (
            3,
            "variable_value",
            Averaging.TEN_SECONDS,
            -1,
            pytest.raises(ValueError),
        ),
        (
            4,
            "variable_value",
            Averaging.TEN_SECONDS,
            -1,
            pytest.raises(ValueError),
        ),
        (
            5,
            "variable_value",
            Averaging.TEN_SECONDS,
            -1,
            pytest.raises(ValueError),
        ),
        (
            0,
            "variable_value",
            Averaging.TEN_SECONDS,
            -1,
            does_not_raise(),
        ),
        (
            0,
            "variable_value",
            Averaging.TEN_SECONDS,
            0,
            does_not_raise(),
        ),
    ],
    indirect=["fake_private_xray"],
)
def test_resample_dataset_xr(
    fake_private_xray, data_variable, averaging_request, min_count, expectation
):
    """Run parametrized test on resample_dataset_xr"""
    with expectation:
        result_resampled_xr = resample_dataset_xr(
            dataset_xr=fake_private_xray,
            data_variable=data_variable,
            averaging_request=averaging_request,
            min_count=min_count,
        )
        assert isinstance(result_resampled_xr, xr.Dataset)
        assert np.isclose(
            result_resampled_xr["variable_value"].mean().item(),
            42.04869160106766 if min_count == -1 else 41.99893044790161,
        )
        assert result_resampled_xr.dims.mapping == {
            "time": 38,
            "port": 3,
            "variable_name": 5,
        }
        assert set(result_resampled_xr.attrs.keys()) == {
            "sensor_vars",
            "species_vars",
            "requested_avg",
        }


def test_intervals_figure_of_merit_xarray(datagen):
    test_data = datagen.copy()
    test_data = test_data[
        [col for col in test_data.columns if col.startswith('values')]
        + ["port"]
    ]

    lods = {"values1": 1.0, "values2": 1.0, "values3": 0.0}

    # Not a df
    with pytest.raises(ValidationError):
        intervals_figure_of_merit_xarray(
            start_df="abc",
            instrument_lods=lods,
            lod_ave_time=100,
            lod_sigma=3,
            sigma_scale=3,
            duration_thresholding_percentile=True
        )

    # Not a dict
    with pytest.raises(ValidationError):
        intervals_figure_of_merit_xarray(
            start_df=test_data,
            instrument_lods="abc",
            lod_ave_time=100,
            lod_sigma=3,
            sigma_scale=3,
            duration_thresholding_percentile=True
        )

    # Not an int
    with pytest.raises(ValidationError):
        intervals_figure_of_merit_xarray(
            start_df=test_data,
            instrument_lods=lods,
            lod_ave_time="abc",
            lod_sigma=3,
            sigma_scale=3,
            duration_thresholding_percentile=True
        )

    # Not an int
    with pytest.raises(ValidationError):
        intervals_figure_of_merit_xarray(
            start_df=test_data,
            instrument_lods=lods,
            lod_ave_time=100,
            lod_sigma="abc",
            sigma_scale=3,
            duration_thresholding_percentile=True
        )

    # Not an int
    with pytest.raises(ValidationError):
        intervals_figure_of_merit_xarray(
            start_df=test_data,
            instrument_lods=lods,
            lod_ave_time=100,
            lod_sigma=3,
            sigma_scale="abc",
            duration_thresholding_percentile=True
        )

    # Not a bool
    with pytest.raises(ValidationError):
        intervals_figure_of_merit_xarray(
            start_df=test_data,
            instrument_lods=lods,
            lod_ave_time=100,
            lod_sigma=3,
            sigma_scale=3,
            duration_thresholding_percentile={}
        )

    # Not a datetimeindex
    with pytest.raises(ValueError):
        intervals_figure_of_merit_xarray(
            start_df=test_data.reset_index(),
            instrument_lods=lods,
            lod_ave_time=100,
            lod_sigma=3,
            sigma_scale=3,
            duration_thresholding_percentile=True
        )

    # Not all species in dict
    with pytest.raises(ValueError):
        intervals_figure_of_merit_xarray(
            start_df=test_data,
            instrument_lods={"values1": 1.0},
            lod_ave_time=100,
            lod_sigma=3,
            sigma_scale=3,
            duration_thresholding_percentile=True
        )

    result = intervals_figure_of_merit_xarray(
        start_df=test_data,
        instrument_lods=lods,
        lod_ave_time=100,
        lod_sigma=3,
        sigma_scale=3,
        duration_thresholding_percentile=True
    )

    assert isinstance(result, xr.Dataset)
    assert set(["_datetime", "port", "species"]) == set(result.coords.variables.mapping)


def test_quantile_duration_filtering(datagen, caplog):
    test_data = datagen.copy()
    test_data = test_data[
        [col for col in test_data.columns if col.startswith('values')]
        + ["port"]
    ]
    intervals_df = get_intervals_statistics(
        test_data, [col for col in test_data.columns if col != "port"]
    )

    # not df
    with pytest.raises(ValidationError):
        _quantile_duration_filtering(
            start_intervals_df=[],
            group_by="port",
            quantile=0.03,
            fraction=0.9
        )

    # not str
    with pytest.raises(ValidationError):
        _quantile_duration_filtering(
            start_intervals_df=intervals_df,
            group_by={},
            quantile=0.03,
            fraction=0.9
        )

    # not float
    with pytest.raises(ValidationError):
        _quantile_duration_filtering(
            start_intervals_df=intervals_df,
            group_by="port",
            quantile=[],
            fraction=0.9
        )

    # not float
    with pytest.raises(ValidationError):
        _quantile_duration_filtering(
            start_intervals_df=intervals_df,
            group_by="port",
            quantile=0.03,
            fraction=""
        )

    # group_by not in cols
    with pytest.raises(ValueError):
        _quantile_duration_filtering(
            start_intervals_df=intervals_df,
            group_by="groups",
            quantile=0.03,
            fraction=0.9
        )

    # interval_duration not in cols
    with pytest.raises(ValueError):
        _quantile_duration_filtering(
            start_intervals_df=intervals_df.drop(columns="interval_duration"),
            group_by="port",
            quantile=0.03,
            fraction=0.9
        )

    # quantile out of bounds
    with pytest.raises(ValueError):
        _quantile_duration_filtering(
            start_intervals_df=intervals_df,
            group_by="port",
            quantile=1.001,
            fraction=0.9
        )

    # fraction out of bounds
    with pytest.raises(ValueError):
        _quantile_duration_filtering(
            start_intervals_df=intervals_df,
            group_by="port",
            quantile=0.03,
            fraction=-0.0001
        )

    ret_df = _quantile_duration_filtering(
        start_intervals_df=intervals_df,
        group_by="port",
        quantile=0.03,
        fraction=0.9
    )

    assert isinstance(ret_df, pd.DataFrame)
    assert set(ret_df.columns) == set(intervals_df.columns)

    ret_df = _quantile_duration_filtering(
        start_intervals_df=intervals_df,
        group_by="port",
        quantile=0.03,
        fraction=0
    )

    assert isinstance(ret_df, pd.DataFrame)
    assert set(ret_df.columns) == set(intervals_df.columns)

    # Assert logging calls
    with caplog.at_level(logging.INFO):
        _ = _quantile_duration_filtering(
            start_intervals_df=intervals_df,
            group_by="port",
            quantile=0.5,
            fraction=1
        )
        assert "intervals_FOM" in caplog.text

