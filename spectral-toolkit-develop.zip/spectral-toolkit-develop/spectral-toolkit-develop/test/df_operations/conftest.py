"""Create fixtures for xarray tests"""
from enum import Enum

import numpy as np
import pandas as pd
import pytest

from spectral_toolkit.df_operations.timeline_process_xarray import (
    timeseries_df_to_xarray,
)


class FakePrivateDataTests(Enum):
    """Create different dataset situations"""

    OK = 0
    NO_SENSOR = 1
    NO_PORT = 2
    NO_SPECIES = 3
    NO_DATETIMEINDEX = 4
    NO_DATETIME_NAME = 5


class FakeXrayTests(Enum):
    """Create different xray situations"""

    OK = 0
    NO_TIME = 1
    NO_PORT = 2
    NO_VARIABLE_NAME = 3
    NO_VARIABLE_VALUE = 4
    NO_DATETIME = 5


@pytest.fixture(name="datagen")
def fixture_datagen():
    """
    Fake data generator.
    """
    freq_assert = 1.45
    len_array = 250
    np.random.seed(42)

    idx1 = pd.date_range("2022-04-18", periods=len_array, freq=f"{freq_assert}S")

    values = np.linspace(-10, -5, len_array) + np.random.normal(
        0, np.sqrt(5), len(idx1)
    )

    sensors = np.linspace(80, 80, len_array) + np.random.normal(
        0, np.sqrt(5), len(idx1)
    )

    # Assign port numbers (each port number can have different sampling duration)
    port_gen = np.concatenate(
        [np.repeat("port1", 50), np.repeat("port2", 64), np.repeat("port3", 88)]
    )

    port = np.concatenate(
        [port_gen, port_gen, port_gen, port_gen, port_gen, port_gen, port_gen]
    )[:len_array]

    # Create pandas dataframe. Most port data from DataProcessor will have this format
    df_test = pd.DataFrame(
        data={
            "values1": values,
            "values2": values[::-1],
            "values3": 2 * values,
            "sensor1": sensors,
            "sensor2": 2 * sensors[::-1],
            "port": port,
            "_datetime": idx1.to_series(),
        }
    )
    df_test = df_test.set_index("_datetime")
    return df_test


@pytest.fixture(name="fake_private_data")
def fixture_fake_private_data(datagen, request):
    """Fake Pandas dataframe used in tests"""

    df_test = datagen.copy()

    if request.param == FakePrivateDataTests.OK.value:
        pass
    elif request.param == FakePrivateDataTests.NO_PORT.value:
        df_test = df_test.drop(columns="port")
    elif request.param == FakePrivateDataTests.NO_SENSOR.value:
        df_test = df_test.drop(columns="sensor1")
    elif request.param == FakePrivateDataTests.NO_SPECIES.value:
        df_test = df_test.drop(columns="values1")
    elif request.param == FakePrivateDataTests.NO_DATETIMEINDEX.value:
        df_test = df_test.reset_index(drop=True)
    elif request.param == FakePrivateDataTests.NO_DATETIME_NAME.value:
        df_test.index.name = "somename"
    else:
        df_test = "abc"

    return df_test


@pytest.fixture(name="fake_private_xray")
def fixture_fake_private_xray(datagen, request):
    """Fake Xray used in tests"""

    result_test_xr = timeseries_df_to_xarray(
        timeseries_df=datagen,
        port_col="port",
        sensor_cols=["sensor1", "sensor2"],
        species_cols=["values1", "values2", "values3"],
    )

    returned_xr = result_test_xr.copy()

    if request.param == FakeXrayTests.OK.value:
        pass
    elif request.param == FakeXrayTests.NO_PORT.value:
        returned_xr = returned_xr.drop_dims("port")
    elif request.param == FakeXrayTests.NO_TIME.value:
        returned_xr = returned_xr.drop_dims("time")
    elif request.param == FakeXrayTests.NO_VARIABLE_NAME.value:
        returned_xr = returned_xr.drop_dims("variable_name")
    elif request.param == FakeXrayTests.NO_VARIABLE_VALUE.value:
        returned_xr = returned_xr.drop_vars("variable_value")
    elif request.param == FakeXrayTests.NO_DATETIME.value:
        returned_xr["time"] = returned_xr.time.astype(int)
    else:
        returned_xr = "abc"

    return returned_xr
