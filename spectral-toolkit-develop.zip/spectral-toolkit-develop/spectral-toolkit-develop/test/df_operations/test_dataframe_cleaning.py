import numpy as np
import pandas as pd
import pytest
from pydantic import ValidationError

from spectral_toolkit.df_operations.dataframe_cleaning import dedupe_rows


@pytest.fixture
def fake_private_logs():
    """
    Generate fake private logs structure.
    """
    dt1 = pd.date_range("00:00:00", "00:10:00", periods=100)
    dt2 = dt1 + pd.Timedelta("00:00:00.321")
    dt3 = pd.date_range("00:00:03.018", "00:10:01", periods=100)
    dt_index = dt1.union(dt2).union(dt3)
    np.random.seed(42)

    values_1 = pd.Series(
        np.linspace(-10, -5, len(dt2)) + np.random.normal(0, np.sqrt(5), len(dt2)),
        index=dt2,
    )
    values_2 = pd.Series(
        np.linspace(15, 21, len(dt1) + len(dt3))
        + np.random.normal(0, np.sqrt(3), len(dt1) + len(dt3)),
        index=dt1.union(dt3),
    )

    aux_3 = pd.Series(
        np.linspace(10800, 10800, len(dt2))
        + np.random.normal(0, np.sqrt(10), len(dt2)),
        index=dt2,
    )
    aux_1 = pd.Series(
        np.linspace(10800, 10800, len(dt3))
        + np.random.normal(0, np.sqrt(10), len(dt3)),
        index=dt3,
    )
    aux_2 = pd.Series(aux_3.values, index=dt1)
    values_3 = pd.concat([aux_1, aux_2, aux_3])

    df_testing = pd.DataFrame(
        data={"v1": values_1, "v2": values_2, "v3": values_3}, index=dt_index
    )
    df_testing.index.name = "_datetime"
    return df_testing


def test_dedupe_rows(fake_private_logs):
    """
    Test dedupe_rows function.
    """
    with pytest.raises(ValidationError):
        dedupe_rows(start_df=[], time_threshold=0.5)

    with pytest.raises(ValidationError):
        dedupe_rows(start_df=fake_private_logs, time_threshold="abc")

    with pytest.raises(ValueError):
        dedupe_rows(start_df=fake_private_logs, time_threshold=-0.5)

    with pytest.raises(ValueError):
        dedupe_rows(start_df=fake_private_logs, time_threshold=np.NaN)

    wrong_dti = fake_private_logs.copy()
    wrong_dti = wrong_dti.reset_index()
    with pytest.raises(ValueError):
        dedupe_rows(start_df=wrong_dti, time_threshold=0.5)

    wrong_dti = fake_private_logs.copy()
    wrong_dti.index.name = "abc"
    with pytest.raises(ValueError):
        dedupe_rows(start_df=wrong_dti, time_threshold=0.5)

    ret = dedupe_rows(start_df=fake_private_logs, time_threshold=0.5)
    assert isinstance(ret, pd.DataFrame)
    assert len(ret.columns) == len(fake_private_logs.columns)
    assert len(ret) <= len(fake_private_logs)
    assert ret["v1"].count() == fake_private_logs["v1"].count()
    assert ret["v2"].count() == fake_private_logs["v2"].count()
