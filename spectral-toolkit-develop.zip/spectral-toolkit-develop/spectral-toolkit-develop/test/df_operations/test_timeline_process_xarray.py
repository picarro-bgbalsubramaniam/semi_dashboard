"""Test Xarray time-series management"""
from contextlib import nullcontext as does_not_raise

import numpy as np
import pytest
import xarray as xr
from pydantic import ValidationError

from spectral_toolkit.df_operations.timeline_process_xarray import (
    timeseries_df_to_xarray,
)


@pytest.mark.parametrize(
    "fake_private_data, port_col, sensor_cols, species_cols, expectation",
    [
        (
            100,
            "port",
            ["sensor1", "sensor2"],
            ["values1", "values2", "values3"],
            pytest.raises(ValidationError),
        ),
        (
            0,
            {},
            ["sensor1", "sensor2"],
            ["values1", "values2", "values3"],
            pytest.raises(ValidationError),
        ),
        (
            0,
            "port",
            {},
            ["values1", "values2", "values3"],
            pytest.raises(ValidationError),
        ),
        (0, "port", ["sensor1", "sensor2"], {}, pytest.raises(ValidationError)),
        (
            1,
            "port",
            ["sensor1", "sensor2"],
            ["values1", "values2", "values3"],
            pytest.raises(ValueError),
        ),
        (
            2,
            "port",
            ["sensor1", "sensor2"],
            ["values1", "values2", "values3"],
            pytest.raises(ValueError),
        ),
        (
            3,
            "port",
            ["sensor1", "sensor2"],
            ["values1", "values2", "values3"],
            pytest.raises(ValueError),
        ),
        (
            4,
            "port",
            ["sensor1", "sensor2"],
            ["values1", "values2", "values3"],
            pytest.raises(ValueError),
        ),
        (
            5,
            "port",
            ["sensor1", "sensor2"],
            ["values1", "values2", "values3"],
            pytest.raises(ValueError),
        ),
        (
            0,
            "port",
            ["sensor1", "sensor2"],
            ["values1", "values2", "values3"],
            does_not_raise(),
        ),
    ],
    indirect=["fake_private_data"],
)
def test_timeseries_df_to_xarray(
    fake_private_data, port_col, sensor_cols, species_cols, expectation
):
    """Test timeseries_df_to_xarray function"""
    with expectation:
        result_test_xr = timeseries_df_to_xarray(
            timeseries_df=fake_private_data,
            port_col=port_col,
            sensor_cols=sensor_cols,
            species_cols=species_cols,
        )
        assert isinstance(result_test_xr, xr.Dataset)
        assert np.isclose(
            result_test_xr["variable_value"].mean().item(), 42.01726470921225
        )
        assert result_test_xr.dims.mapping == {
            "time": 250,
            "port": 3,
            "variable_name": 5,
        }
        assert result_test_xr.attrs == {
            "sensor_vars": ["sensor1", "sensor2"],
            "species_vars": ["values1", "values2", "values3"],
        }
