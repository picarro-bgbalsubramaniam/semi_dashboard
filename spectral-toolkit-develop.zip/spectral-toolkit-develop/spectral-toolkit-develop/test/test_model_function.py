from unittest import mock

import pytest
from spectral_toolkit.model_function.mongodb import (
    _query_spline_1d,
    _query_spline_2d,
    _query_spline_polynomial,
    model_function,
    get_pubchem_info,
)


# simplified version
PUBCHEM_ENTRY = {
    'cid': 962,
    'iupacName': 'oxidane',
    'molecularWeight': 18.015,
    'commonName': 'Water',
    'molecularFormula': 'H2O'
}

PUBCHEM_RETURNED = {
    962: {
        'commonName': 'Water',
        'iupacName': 'oxidane',
        'molecularFormula': 'H2O',
        'molecularWeight': 18.015
    }
}


def get_mock_db_client_with_error():
    """Returns a mock whose __next__ method is overriden to raise a StopIeteration error. This
    allows us to test code that looks like the following:

        result = db_client.MyCollection.aggregate(my_query)
        document = next(result)

    under the case where no results are found. Specifically, in pymongo, when you call ``next``
    on the database cursor, and no results are available, the client will raise a
    ``StopIteration`` exception.
    """
    mock_db_client = mock.MagicMock()
    result_mock = mock.MagicMock()
    result_mock.__next__ = mock.MagicMock(side_effect=StopIteration)
    mock_db_client.EmpiricalSpectra.aggregate.return_value = result_mock
    return mock_db_client


@mock.patch("spectral_toolkit.model_function.mongodb._query_splines")
@mock.patch(
    "spectral_toolkit.model_function.mongodb._latest_data_collection_date_by_upload_time",
    return_value=("date_one", "date_two"),
)
@mock.patch(
    "spectral_toolkit.model_function.mongodb._get_spline_type_and_concentration",
    return_value=("type_1", 0.12345),
)
def test_inner_function_call_counts(mock_get_spline, mock_latest_date, mock_query):
    """Test that inside the call to "model_function", we have called helper
    functions accordingly."""
    db_client = mock.MagicMock()
    model_function(db_client, cid=1, nu_min=0.0, nu_max=0.1)
    assert mock_get_spline.call_count == 1
    assert mock_latest_date.call_count == 1
    assert mock_query.call_count == 1


def test_model_function_fails_with_error():
    """Check that model function call with incorrect nominal_pressure raises error"""
    db_client = mock.MagicMock()
    with pytest.raises(ValueError):
        model_function(db_client, cid=1, nu_min=0.0, nu_max=0.1, nominal_pressure=42)


def test_query_1d_fails_with_error():
    """Query the database for a 1d spline, with a mock client which raises an error"""
    mock_db_client = get_mock_db_client_with_error()

    # By construction, the mock cursor will raise an error, which we capture and reraise
    with pytest.raises(ValueError):
        document = _query_spline_1d(
            mock_db_client,
            cid=1,
            nu_min=0.0,
            nu_max=0.1,
            nominal_pressure=42,
            data_collection_date="20770903",
            spline_creation_date="20440303",
        )

    # We don't make a call to DB if nominal pressure isn't in PRESSURE_MAP keys
    assert mock_db_client.EmpiricalSpectra.aggregate.call_count == 0


def test_query_2d_fails_with_error():
    """Query the database for a 2d spline, with a mock client which raises an error"""
    mock_db_client = get_mock_db_client_with_error()

    # By construction, the mock cursor will raise an error, which we capture and reraise
    with pytest.raises(ValueError):
        document = _query_spline_2d(
            mock_db_client,
            cid=1,
            nu_min=0.0,
            nu_max=0.1,
            nominal_pressure=42,
            data_collection_date="20770903",
            spline_creation_date="20440303",
        )

    # We don't make a call to DB if nominal pressure isn't in PRESSURE_MAP keys
    assert mock_db_client.EmpiricalSpectra.aggregate.call_count == 0


def test_query_polynomial_fails_with_error():
    """Query the database for a polynomial spline, with a mock client which raises an error"""
    mock_db_client = get_mock_db_client_with_error()

    # By construction, the mock cursor will raise an error, which we capture and reraise
    with pytest.raises(ValueError):
        document = _query_spline_polynomial(
            mock_db_client,
            cid=1,
            nu_min=0.0,
            nu_max=0.1,
            nominal_pressure=42,
            data_collection_date="20770903",
            spline_creation_date="20440303",
        )

    # We don't make a call to DB if nominal pressure isn't in PRESSURE_MAP keys
    assert mock_db_client.EmpiricalSpectra.aggregate.call_count == 0


def test_get_pubchem_info():
    mock_db_client = mock.MagicMock()
    mock_db_client.EmpiricalSpectra.distinct.return_value = [962]
    mock_db_client.pubChemEntries.find.return_value = [PUBCHEM_ENTRY]
    results = get_pubchem_info(mock_db_client)
    assert results == PUBCHEM_RETURNED
