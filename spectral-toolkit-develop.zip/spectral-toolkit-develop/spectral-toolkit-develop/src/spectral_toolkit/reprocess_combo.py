import os
from ast import literal_eval
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime as dt
from multiprocessing import pool
from pathlib import Path
from typing import List

import click
import numpy as np
import pandas as pd
import pytz
from data_pooler import persist
from data_pooler.data_access_utils import get_file_paths_in_timerange
from data_pooler.persist import get_combolog_from_zpickle
from data_pooler.pool_utils import get_data_columns
from spectral_arithmetic.data_models.model_function import ModelFunctions
from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from spectral_toolkit.db_clients.mongo_spectral_library import (
    get_mongo_spectral_library_client,
)
from spectral_toolkit.logger import get_logger
from spectral_toolkit.model_function.mongodb import model_function

LOGGER = get_logger(__name__)
TIME_REP = "%Y-%m-%d %H:%M:%S"
NUC1 = "fitData_nu_transform_nnuc"
NUC2 = "fitData_fitdata_params_nucenter"
DEFAULT_NU_CENTER = 6056.5
REMOVE_CIDS = [280, 962, 297, 947, 977]
CORES = os.cpu_count()


def get_least_squares(
    cids: List[int],
    nu_min: float = 5800,
    nu_max: float = 6300,
    nominal_pressure: float = 140,
) -> LinearLeastSquares:
    """
    Convenience to get the linear least squares minimizer for a given list of cids
    """
    LOGGER.info(f"Generating least squares fitter for {sorted(cids)}")
    client = get_mongo_spectral_library_client()
    library_splines = {}
    for cid in cids:
        try:
            library_splines[cid] = model_function(
                client,
                cid,
                nu_min,
                nu_max,
                nominal_pressure=nominal_pressure,
                use_exact_pressure=False
            )
        except Exception as e:
            LOGGER.warning(f"Unable to generate model function for {cid}: {e}")
    client.client.close()
    model_functions = ModelFunctions(
        nu_min=nu_min, nu_max=nu_max, funcs=library_splines
    )
    lsq = LinearLeastSquares(model_functions)

    return lsq


def _get_nu_key(columns: List[str]):
    """
    Convenience to get whatever nu center key is available
    """
    if NUC1 in columns:
        nu_key = NUC1
    elif NUC2 in columns:
        nu_key = NUC2
    else:
        nu_key = None

    return nu_key


def reprocess_combo_file(file_name: Path, lsq: LinearLeastSquares):
    """
    Reprocess a single combo file
    Arguments:
        file_name: Full path and file name
        lsq: LinearLeastSquares object with appropriate splines
    Returns:
        Tuple (df, str): New reprocessed dataframe and write file name
    """
    LOGGER.info(f"Reprocessing Combo Log File {file_name}")
    combo_gen = get_combolog_from_zpickle(open(file_name, "r"))
    _ = next(combo_gen)
    df = next(combo_gen)
    nu_key = _get_nu_key(df.columns)
    results = []
    write_file = str(file_name).replace("broadband", "reprocessed")
    for idx, (i, row) in enumerate(df.iterrows()):

        if nu_key:
            nu_center = row[nu_key]
        else:
            nu_center = DEFAULT_NU_CENTER

        spec = combo_gen.send(idx)
        nu = spec["nu"].to_numpy()
        nu_shift = row["fitData_nu_transform_n0"]
        nu_squish = row["fitData_nu_transform_n1"]
        transformed_nus = nu_squish * (nu - nu_center) + nu + nu_shift
        y_err = np.array(1 / np.sqrt(spec["npoints"].to_numpy()))
        res, stats = lsq.eval(
            transformed_nus,
            spec["partial_fit"].to_numpy(),
            y_err=y_err,
            nu_center=nu_center,
            baseline_order=1,
        )

        res["_datetime"] = i
        res["lsq_rmse"] = np.std(stats.residual_error)

        results.append(res)

    return (pd.DataFrame(results).set_index("_datetime"), write_file)


def reprocess_date_range(
    pool_path: str,
    start: str,
    end: str,
    added_cids: List[int] = [],
    cids_remove: List[int] = [],
    time_zone: str = "UTC",
):
    """
    Reprocess data with linear least squares and save to pool.  Automatically picks up gas
    concentrations being fit and removes the default to remove (i.e. big3, nitrogen, oxygen)
    Arguments:
        pool_path: location to analyzer with combo zpics (i.e. /Users/aegger/pools/NUV1056)
        start: start time for reprocessing in format ('2022-06-09 01:00:00')
        end: end time for reprocessing in format ('2022-06-10 01:00:00')
        added_cids: List of cids to add ([1, 2, 3, 4])
        cids_remove: List of cids to remove.  Default([280, 962, 297, 947, 977])
        time_zone: Can specify, but everything is UTC all the time, so may be easier to always leave default
    """
    pool_path = Path(pool_path)
    LOGGER.info(f"Reprocessing data for {pool_path.name} in time range {start} - {end}")
    # localize time for getting dataframe
    tz_aware = pytz.timezone(time_zone)
    start_tz = tz_aware.localize(dt.strptime(start, TIME_REP))
    end_tz = tz_aware.localize(dt.strptime(end, TIME_REP))
    files = get_file_paths_in_timerange(
        start_tz, end_tz, pool_path, ["ComboLog", "broadband"]
    )
    columns = get_data_columns(files)

    gas_concs = [int(col.split("_")[-1]) for col in columns if "gasConcs" in col]
    gas_concs += added_cids
    # remove unwanted
    cids_remove += REMOVE_CIDS
    gas_concs = list(set(gas_concs) - set(cids_remove))
    # generate lsq object
    lsq = get_least_squares(gas_concs)

    with ProcessPoolExecutor(max_workers=CORES) as executor:
        for df, write_file in executor.map(reprocess_combo_file, files, [lsq] * CORES):
            fp = open(write_file, "wb+")
            for blob in persist.emit_zpickle_from_time_series_data_frame(df, {}):
                fp.write(blob)


@click.command()
@click.option(
    "-p",
    "--pool-path",
    help="Full Path to pool and analyzer (i.e. /Users/aegger/pools/NUV1056)",
    type=str,
)
@click.option(
    "-s",
    "--start",
    help="start time for reprocessing in format ('2022-06-09 01:00:00')",
    type=str,
)
@click.option(
    "-e",
    "--end",
    help="end time for reprocessing in format ('2022-06-10 01:00:00'))",
    type=str,
)
@click.option(
    "-a",
    "--added-cids",
    help="List of cids to add ([6324, 6325]) to existing cids in fit",
    default=[],
)
@click.option(
    "-r",
    "--cids-remove",
    help="List of cids to remove from existing in addition to automatically removed [280, 962, 297, 947, 977]",
    default=[],
)
@click.option(
    "-t",
    "--time_zone",
    help="To set timezone, but should stay at UTC",
    default="UTC",
    type=str,
)
def main(
    pool_path,
    start,
    end,
    added_cids,
    cids_remove,
    time_zone,
):
    """
    Program to take a start and end time and reprocess combolog broadband logs with
    additional or removed cids.  This will automatically repool the reprocessed time series data

    Running Example:
        python -m spectral_toolkit.reprocess_combo -p /Users/aegger/pools/NUV1056 -s "2022-06-09 01:00:00" -e "2022-06-10 01:00:00" -a "[702, 31374]"
    """
    reprocess_date_range(
        pool_path,
        start,
        end,
        literal_eval(added_cids),
        literal_eval(cids_remove),
        time_zone,
    )


if __name__ == "__main__":
    main()
