"""Perform regularized fitting of time x modes absorption data"""

from typing import List

import numpy as np
import numpy.ma as ma
import pandas as pd
import xarray as xr
from sklearn.linear_model import LassoLarsCV
from sklearn.model_selection import ShuffleSplit
from sklearn.preprocessing import StandardScaler
from tqdm.auto import tqdm

from spectral_toolkit.compound_search.split_data import get_train_test


def _preallocate_models(n_time_splits: int, wavenumbers: np.ndarray, cids: List[int]):
    """
    Prepare an Xarray dataset to hold the results of the lasso models.

    Args:
        n_time_splits (int):
            Number of time splits/models trained
        wavenumbers (np.ndarray):
            Wavenumbers
        cids (List[int]):
            Cids

    Returns:
        xr.Dataset:
            Dataset. See more at `train_lars`

    """
    result_xr = xr.Dataset(
        {
            "X": (
                ["wavenumber", "cid"],
                np.full([len(wavenumbers), len(cids)], np.NaN),
            ),
            "coefficients": (
                ["time_split", "cid"],
                np.full([n_time_splits, len(cids)], np.NaN),
            ),
            "y_train": (
                ["time_split", "wavenumber"],
                np.full([n_time_splits, len(wavenumbers)], np.NaN),
            ),
            "y_test": (
                ["time_split", "wavenumber"],
                np.full([n_time_splits, len(wavenumbers)], np.NaN),
            ),
            "w_train": (
                ["time_split", "wavenumber"],
                np.full([n_time_splits, len(wavenumbers)], np.NaN),
            ),
            "w_test": (
                ["time_split", "wavenumber"],
                np.full([n_time_splits, len(wavenumbers)], np.NaN),
            ),
            "y_predict": (
                ["time_split", "wavenumber"],
                np.full([n_time_splits, len(wavenumbers)], np.NaN),
            ),
            "use_wavenumber": (
                ["time_split", "wavenumber"],
                np.full([n_time_splits, len(wavenumbers)], False),
            ),
            "coefficients": (
                ["time_split", "cid"],
                np.full([n_time_splits, len(cids)], np.NaN),
            ),
            "alpha": (
                ["time_split"],
                np.full([n_time_splits], np.NaN),
            ),
            "scale": (
                ["cid"],
                np.full([len(cids)], 1),
            ),
        },
        coords={
            "cid": ("cid", cids),
            "time_split": ("time_split", range(n_time_splits)),
            "wavenumber": ("wavenumber", wavenumbers),
        },
    )
    return result_xr


def train_lars(
    design_unscaled: pd.DataFrame,
    absorption: pd.DataFrame,
    time_split=ShuffleSplit(n_splits=200, test_size=0.3, random_state=0),
    wavenumber_cv=ShuffleSplit(n_splits=15, test_size=0.3),
    n_jobs: int = -1,
    report_progress: bool = False,
) -> xr.Dataset:
    """
    Train Lasso Lars algorithm for
    feature selection.

    Args:
        design_unscaled (pd.DataFrame):
            Design matrix, with basis functions as columns,
            as wavenumbers as rows.
            The column names must be the CID numbers (integers).
            Dimensions: (n_modes x n_cids)
        absorption (pd.DataFrame):
            Time series of absorption, with wavenumbers as columns,
            and times as rows.
            The column names must be the wavenumber values (float).
            Dimensions: (n_times x n_modes)
        time_split (sklearn.ShuffleSplit):
            Train as many models as the time_split.
            Training more than one model give an indication
            of the model stability in terms of CIDs downselection,
            in terms of occurrences and coefficient strenghts.
            Train size determines which percentage of times in
            the dataset are used for training each model. The
            rest of the data set is used to evaluate performance.
        wavenumber_cv (sklearn.ShuffleSplit):
            Provides cross validation on the wavenumber axis.
            Cross validation is used to determine the best amount
            of regularization strength.
            Train size determines which percentage of the wave numbers
            are used for training, the rest is used to estimate performance.
        n_jobs (int):
            Number of CPUs.
            Default is -1 (use all processors)
        report_progress (bool):
            If True, display a progress bar to monitor
            execution progress.

    Returns:
        xr.Dataset:
            Xarray dataset with coordinates: wavenumber, time_split, cid.
            Variables:
            - X (wavenumber, cid): the scaled design matrix
            - coefficients (time_split, cid): linear regression coefficient results
            - y_train (time_split, wavenumber): training data
            - y_test (time_split, wavenumber): test data
            - w_train (time_split, wavenumber): train weights (not used)
            - w_test (time_split, wavenumber): test weights
            - y_predict (time_split, wavenumber): fitted model prediction
            - use_wavenumber (time_split, wavenumber): boolean mask to skip nans
            - alpha (time_split): regularization strength
            - y_error (time_split, wavenumber): Difference between y_test and y_predict
    """

    # Scale model functions
    ss = StandardScaler()
    X = pd.DataFrame(ss.fit_transform(design_unscaled), columns=design_unscaled.columns)

    ds = _preallocate_models(
        n_time_splits=time_split.n_splits,
        wavenumbers=absorption.columns,
        cids=X.columns,
    )

    ds["scale"] = ("cid", ss.scale_)
    ds["X"] = (("wavenumber", "cid"), X.values)

    for i, (train, test) in enumerate(
        tqdm(
            time_split.split(absorption),
            total=time_split.n_splits,
            disable=not report_progress,
        )
    ):
        y_train, weights_train, y_test, weights_test = get_train_test(
            absorption_matrix=absorption, train_indexes=train, test_indexes=test
        )

        valid_modes = ~y_train.mask

        wavenumber_cv.random_state = i

        model = LassoLarsCV(
            cv=wavenumber_cv, fit_intercept=True, n_jobs=n_jobs
        )
        model.fit(X[valid_modes], y_train[valid_modes])

        # Predict values with the fitted lasso on the test set
        y_predict = ma.array(
            np.zeros_like(y_train), mask=y_train.mask, fill_value=np.NaN
        )
        y_predict[valid_modes] = model.predict(X[valid_modes])

        ds["y_train"].loc[dict(time_split=i)] = y_train
        ds["y_test"].loc[dict(time_split=i)] = y_test
        ds["w_train"].loc[dict(time_split=i)] = weights_train
        ds["w_test"].loc[dict(time_split=i)] = weights_test
        ds["y_predict"].loc[dict(time_split=i)] = y_predict
        ds["use_wavenumber"].loc[dict(time_split=i)] = valid_modes
        ds["coefficients"].loc[dict(time_split=i)] = model.coef_
        ds["alpha"].loc[dict(time_split=i)] = model.alpha_

    # Get design matrix to xarray
    design_unscaled.columns.name = "cid"
    design_unscaled.index.name = "wavenumber"
    design_xarray = xr.DataArray(design_unscaled)
    design_xarray["wavenumber"] = ds.wavenumber

    # Get absorption for every cid
    ds["absorption"] = design_xarray * ds["coefficients"] / ds["scale"]
    ds["y_error"] = ds["y_test"] - ds["y_predict"]
    return ds
