"""Utilities to manage the absorption time splitting"""
from typing import Tuple

import numpy as np
import pandas as pd
import numpy.ma as ma


def get_weights(absorption_matrix: np.ndarray) -> np.ndarray:
    """
    Given a absorption_matrix matrix (n_time x n_mode),
    get the weights associated to
    each mode.

    Args:
        absorption_matrix (np.ndarray):
            Absorption matrix.
            Dimension: (n_time x n_mode)

    Returns:
        np.ndarray: Array of dimension (n_mode)

    """
    variance = np.power(absorption_matrix.std(axis=0), 2)  # n_modes
    weights = 1 / variance
    return weights


def _get_split_set(
    absorption_matrix: pd.DataFrame, select_indexes: np.ndarray
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Given a absorption_matrix matrix (n_time x n_mode),
    keep only the selected_indexes rows.

    From this new submatrix (less_times x n_modes),
    take the time average `y_selected` (n_modes) and
    the associated `weights_selected` (n_modes).

    Args:
        absorption_matrix (np.ndarray):
            Absorption matrix.
            Dimension: (n_time x n_mode)
        select_indexes:
            Row indexes (aka, time) to keep.

    Returns:
        np.ndarray: Time average of absorption_matrix at the selected indexes
        np.ndarray: Weights associated to each mode
    """
    # Get mean of train set, and training weights
    submatrix = absorption_matrix.iloc[select_indexes, :]  # n_train x n_modes
    y_selected = submatrix.mean(axis=0)  # n_modes
    weights_selected = get_weights(submatrix)
    return y_selected, weights_selected


def get_train_test(
    absorption_matrix: np.ndarray,
    train_indexes: np.ndarray,
    test_indexes: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Get a train test split based
    on the train and test indexes.

    Args:
        absorption_matrix (np.ndarray):
            Absorption matrix.
            Dimension: (n_time x n_mode)
        train_indexes (np.ndarray):
            Row indexes (time) to use for
            training
        test_indexes (np.ndarray):
            Row indexes (time) to use for
            testing

    Returns:
        np.ndarray: Training array (n_modes)
        np.ndarray: Weights for training (n_modes)
        np.ndarray: Test array (n_modes)
        np.ndarray: Weights for testing (n_modes)

    """
    y_train, weights_train = _get_split_set(absorption_matrix, train_indexes)
    y_test, weights_test = _get_split_set(absorption_matrix, test_indexes)

    # Mask is True for invalid entries (NaNs)
    mask = (y_train.isna() | y_test.isna()).values  # n_modes

    y_train = ma.array(y_train.values, mask=mask)
    weights_train = ma.array(weights_train.values, mask=mask)
    y_test = ma.array(y_test.values, mask=mask)
    weights_test = ma.array(weights_test.values, mask=mask)

    return y_train, weights_train, y_test, weights_test
