import copy
import itertools
from collections import defaultdict
from typing import Dict
from pydantic import BaseModel, ConfigDict
import time

import numpy as np
import pandas as pd
from spectral_arithmetic.linear_least_squares import least_squares

from spectral_toolkit.logger import get_logger

LOGGER = get_logger(__name__)

QTHRESH_LIST_1 = [1.2, 1.05, 1.015, 1.000]
MAX_CYCLE_LIST_1 = [5, 10, 15, 20]
OUT_COLS_SUMMARY = [
    "Q",
    "conc_mean",
    "conc_std",
    "weighted_frac_of_iters",
]


def Amatrix(Alist):
    return np.array(Alist).T


def calc_FOM(X, noise):
    """FOM = mean variance scaled by the noise^2"""
    return (X**2).sum() / len(X) / noise**2


def rmse(X):
    return np.sqrt((X**2).sum() / len(X))


def euclid(X, Y):
    S = np.sqrt(((X - Y) ** 2).sum())
    return S


def norm(X):
    return X / np.sqrt((X**2).sum())


class Allan:
    def __init__(self, data, T=None, calc=True):
        self.data = data
        self.S = []
        self.N = 1
        self.T = []
        self.E = []
        self.white = -1.0
        self.drift = -1.0
        self.fraction = -1.0
        self.N64 = -1.0
        self.fraction64 = -1.0
        if T is None:
            self.dt = 1.0
        else:
            self.dt = self.calcDT(T)
        if calc:
            self.calcAllen()

    def calcDT(self, T):
        return (max(T) - min(T)) / (len(T) - 1)

    def calcAllen(self):
        if np.std(self.data) != 0:
            while len(self.data) >= 2:
                y = self.diffstdev(self.data)
                self.S.append(y)
                self.T.append(self.N)
                points = len(self.data)
                ebar = y / np.sqrt(points)
                self.E.append(ebar)
                self.N *= 2.0
                self.data = self.avepair(self.data)
        self.S = np.array(self.S)
        self.T = np.array(self.T) * self.dt
        self.E = np.array(self.E)
        return self.S, self.T, self.E

    def diffstdev(self, Y):
        x = []
        for i in range(len(Y) - 1):
            x.append(Y[i + 1] - Y[i])
        if len(x) > 1:
            # a = np.std(x)/np.sqrt(2)
            # a = np.sqrt(np.sum(np.array(x)**2)/(len(x)-1)/2) <-- error found by A. Biasioli 20220425
            a = np.sqrt(np.sum(np.array(x) ** 2) / len(x) / 2)
        else:
            a = abs(x[0]) / np.sqrt(2)
        return a

    def avepair(self, Y):
        x = []
        for i in range(int(len(Y) / 2)):
            x.append(0.5 * (Y[2 * i] + Y[2 * i + 1]))
        return x

    def allStats(self):
        R = {}
        R["N"] = self.N
        R["white"] = self.white
        R["drift"] = self.drift
        R["N64"] = self.N64
        R["fraction"] = self.fraction
        R["fraction64"] = self.fraction64d
        R["allenstd"] = self.S
        return R


class RCubedParameters(BaseModel):
    """parameters model for R3 compound hunting algorithm

    Args:
      name:
        name of the parameter set (author can define)
      kfactor:
        Criterion for deciding whether to keep a compound during gotta_catch_em_all.
         For the Mfits combinations of fits that have a fom less than fom_threshold,
         corresponds to the ratio of the mean concentration to the std concentration
         from the fit
      fraction:
        The fraction of times that a cid must appear in the combinations of the best
         Mfits
      fom_threshold:
        defines the population of "good" combinations of Mfits; all fits which are
         within fom_threshold of the best fit fom
      ban_negatives:
        allow or disallow negative concentrations during compound hunting
      Nfits:
        Number of compounds to add (one at a time) during each hunting cycle in
         gotta_catch_em_all
      Mfits:
        Number of compounds to include in the combinations of candidate cids in each
         cycle
      Lfits:
        Used to modify Mfits during each cycle, using [Lfits, Mfinal + Lfits, -1]
      max_cycles:
        maximum number of cycles to allow before gotta_catch_em_all terminates
      num_close_compounds:
        when assessing the quality parameter, this is the number of  compounds from the
         library to include, ranked by euclidean distance from the test cid
      Q_threshold:
        Ratio of rmse with the best two cids and the test cid removed, relative to the
         rmse of with the test cid included.  Q > 1 indicates a high likelihood that the
         test cid is present
      specific_fit_list:
        list of specific fits to perform in assess_final_results
      specific_fit_for_stats:
        specific fit to use when creating the summary table in assessment

    """

    name: str
    kfactor: float = 2
    fraction: float = 0.9
    fom_threshold: float = 0.03
    ban_negatives: bool = False
    Nfits: int = 15
    Mfits: int = 6
    Lfits: int = 0
    max_cycles: int = 12
    num_close_compounds: int = 25
    Q_threshold: float = 1.0
    specific_fit_for_stats: str = "CERTAIN_AND_MAYBES_N00"

    def __str__(self):
        return self.name


# Good starting point for a R3 parameters
BASIC_1 = RCubedParameters(name="nominal_parameter_set")

# An example of a list of parameters to feed to the hunting_loop function
BASIC_LIST_1 = []
for Qthresh, max_cycles in zip(QTHRESH_LIST_1, MAX_CYCLE_LIST_1):
    these_params = copy.deepcopy(BASIC_1)
    these_params.name = f"{these_params.name}_Q{Qthresh:.3f}_MaxCycles{max_cycles}"
    these_params.Q_threshold = Qthresh
    these_params.max_cycles = max_cycles
    BASIC_LIST_1.append(these_params)


class RecursiveFitter:
    _model_functions: Dict = {}

    """Class for recursively fitting an input spectrum.

    Takes as input a spectrum (nu and loss) and a library of model functions evaluated at nu.
    Recursively attempts to find all the compounds present in the spectrum
    Does a final check of Q (the 1-to-2 substitution) to determine likelihood of the fit
    
    The assessment attribute compiles the useful information in one place.

    Args:
      MF:
        dictionary of model functions evaluated at nu
      nu:
        frequency array
      loss:
        absorption array
      rcubed_params:
        parameters class to direct the fit
      noise:
        if None, uses an algorithm to determine
        if a float, this is a multiplier that will be applied evenly for all spectral points
        FIXME: we should be supplying the error array
      required_cids:
        cid list that will be used in every fit by default
      ignore_cids:
        cids to remove from MF
    """

    def __init__(
        self,
        MF,
        nu,
        loss,
        rcubed_params,
        noise=None,
        required_cids=[],
        ignore_cids=[],
        verbose=True,
    ):
        """"""
        self.start_time = time.time()
        # NOTE: explicit copy method -- not sure if copy.deepcopy works on interp1d scipy splines
        for cid, mf in MF.items():
            self._model_functions[cid] = mf
        self.set_parameters(rcubed_params)
        self.set_cid_categories(required_cids, ignore_cids)
        self.add_data(nu, loss, noise)
        self.sorted_by_distance = self.sort_cids_by_spectrum()
        self.candidate_population = set()
        self.verbose = verbose

    def set_cid_categories(self, required_cids, ignore_cids):
        """declare which compounds are to be required and ignored"""
        self.required_cids = required_cids
        self.ignore_cids = ignore_cids
        self.available_cids = list(
            set(self._model_functions.keys()) - set(required_cids) - set(ignore_cids)
        )

    def set_parameters(self, rcubed_params):
        """takes the parameter class as input"""
        self.params = rcubed_params

    def add_data(self, nu, loss, noise):
        """Add spectral data.  The noise is the inherent noise of the residuals.  It would be good
        to change this to a vector input derived from the first term of an Allan deviation of
        each mode in a compactified spectrum.  But we don't have that now, so the noise is
        typically derived using the determine_noise function"""
        self.nu = nu
        self.loss = loss
        self.error = np.ones(nu.shape)
        if noise is None:
            self.determine_noise()
        else:
            self.noise = noise
        self.error *= self.noise

    def determine_noise(self, N=30):
        """determine the noise by fitting N cids and taking the Allan deviation of the
        spectral residuals.  This is kind of stupid.  Replace with a real uncertainty
        estimate from the spectra themselves."""
        temp_fit_cids = []
        while len(temp_fit_cids) < N:
            temp_best = self.add_a_compound(temp_fit_cids)
            if temp_best[0] != -1:
                best = temp_best
                temp_fit_cids.append(best[0])
            else:
                break
        allan = Allan(best[2])
        self.noise = allan.S[0]

    def sort_cids_by_spectrum(self):
        """for each cid, creates a list of library compounds sorted by euclidean distance"""
        sorted_cids = {}
        valid_cids = self.available_cids + self.required_cids
        for cid in valid_cids:
            spec = self._model_functions[cid]
            scores = {}
            nspec = norm(spec)
            for tcid in valid_cids:
                if cid == tcid:
                    continue
                tspec = self._model_functions[tcid]
                scores[tcid] = euclid(nspec, norm(tspec))
            score_list = list(scores.keys())
            score_list.sort(key=lambda cid: scores[cid])
            sorted_cids[cid] = score_list
        return sorted_cids

    def add_a_compound(self, fit_cids):
        """Add a compound to the list of candidate CIDs, by going 1 by 1 through the library
        fit_cids are always in this fit"""

        # prepare list of required model functions
        Alist = []
        for rcid in self.required_cids:
            rmf = self._model_functions[rcid]
            Alist.append(rmf)

        # add additional model functions and fit the data
        if fit_cids:
            for cid in fit_cids:
                Alist.append(self._model_functions[cid])
            fit0 = least_squares(Amatrix(Alist), self.loss, y_err=self.error)
            fit0_lsq = fit0[1].lsq_res
            best = (
                -1,
                fit0_lsq,
            )
        else:
            best = (-1, np.inf)

        # iterate through available_cids and find the one that fits best (i.e. lowest RMSE)
        for cid in self.available_cids:
            if cid in fit_cids:
                continue
            Blist = Alist + [self._model_functions[cid]]

            fiti = least_squares(Amatrix(Blist), self.loss, y_err=self.error)
            if fiti[1].lsq_res < best[1]:
                best = (cid, fiti[1].lsq_res, fiti[1].residual_error)
        # add best compound to candidate set

        return best

    def pick_the_best_M(self, fit_cids, M):
        """find the best combination of a set of fit_cids"""
        best_combo = None

        # prepare a list of required model functions
        Astart = []
        for rcid in self.required_cids:
            rmf = self._model_functions[rcid]
            Astart.append(rmf)

        # iterate through combinations of fit_cids to find the best combination
        for combo in itertools.combinations(fit_cids, M):
            Alist = copy.deepcopy(Astart)
            for cid in combo:
                Alist.append(self._model_functions[cid])
            fit = least_squares(Amatrix(Alist), self.loss, y_err=self.error)
            if best_combo is None:
                best_combo = (fit[1].lsq_res, combo)
            else:
                if fit[1].lsq_res < best_combo[0]:
                    best_combo = (fit[1].lsq_res, combo)
        return list(best_combo[1])

    def add_N_pick_M(self, N, M, fit_cids=[]):
        """Basic recursion: Add N compounds, pick the best M.  If M = -1, it returns all N cids"""
        # first, add compounds until N have been found
        while len(fit_cids) < N:
            best = self.add_a_compound(fit_cids)
            best_cid = best[0]
            if best[0] != -1:
                fit_cids.append(best_cid)
                self.candidate_population.add(best_cid)
            else:
                break
        # then, pick the best M compounds if M != -1
        if M != -1:
            fit_cids = self.pick_the_best_M(fit_cids, M)
        return fit_cids

    def execute_cycle(self, N=10, Mfinal=3, L=2):
        """Executes on a set of loops of 'Add N' and 'Pick the best M'.
        Find the superset of all compounds found in this manner"""

        # First we identify candidate cids by repeatedly finding the best N and selecting the best M
        if L == 0:
            Mlist = [-1]
        else:
            # M = -1 means that add_N_pick_M returns all the compounds
            Mlist = [L, Mfinal + L, -1]
        if self.verbose:
            LOGGER.info(f"loop through combination search: {Mlist}")
        fit_cids = []
        all_cids = set()
        for loop, M in enumerate(Mlist):
            left = len(Mlist) - loop
            if self.verbose:
                LOGGER.info(f"Running {left}")
            fit_cids = self.add_N_pick_M(N, M, fit_cids=fit_cids)
            for cid in fit_cids:
                all_cids.add(cid)

        # Then we find the most robust cids from the list of candidates
        if self.verbose:
            LOGGER.info(f"checking combinations from {len(all_cids)} member set...")
        self.compile_statistics(list(all_cids), Mfinal)
        return fit_cids

    def compile_statistics(self, fit_cids, M):
        """Derive the statistics of all combinations of candidate fit_cids choose M"""

        # create a fitter with required model functions
        Astart = []
        for rcid in self.required_cids:
            rmf = self._model_functions[rcid]
            Astart.append(rmf)
        self.candidate_cids = fit_cids
        self.results = {}
        if self.verbose:
            LOGGER.info(f"Analyzing combinations of {M} compounds...")

        # iterate through combinations of fit_cids
        self.fom_stats = {}
        combination_counter = 0
        for combo in itertools.combinations(fit_cids, M):
            Alist = copy.deepcopy(Astart)
            for cid in combo:
                Alist.append(self._model_functions[cid])
            fit = least_squares(Amatrix(Alist), self.loss, y_err=self.error)
            fom = calc_FOM(fit[1].residual_error, self.noise)
            ampl = fit[0]
            self.fom_stats[combo] = (fom, ampl)
            combination_counter += 1

        self.summary = {}
        self.summary["extra_compounds"] = M
        # sort the combinations by fom in ascending order
        Xk = list(self.fom_stats.keys())
        Xk.sort(key=lambda e: self.fom_stats[e][0])

        # proceed with stats calculations only if there are one or more compound combinations evaluated
        self.summary["combinations_evaluated"] = combination_counter
        if combination_counter != 0:
            # the best FOM is minnie
            minnie = self.fom_stats[Xk[0]][0]
            self.summary["best_FOM"] = minnie

            # iterate through combinations until the fom_threshold is reached
            stats = defaultdict(int)
            concs = defaultdict(list)
            count = 0

            #   "residual" is the mean residual from all the different fits
            residual = np.zeros(self.nu.shape)
            for combo in Xk:
                count += 1
                this_residual = copy.deepcopy(self.loss)
                j = 0
                # first, iterate through the required cids
                for j, cid in enumerate(self.required_cids):
                    stats[cid] += 1
                    concs[cid].append(self.fom_stats[combo][1][j])
                    this_residual -= (
                        self.fom_stats[combo][1][j] * self._model_functions[cid]
                    )
                    j += 1
                # then, iterate through the cids in the combo itself
                for cid in combo:
                    stats[cid] += 1
                    concs[cid].append(self.fom_stats[combo][1][j])
                    this_residual -= (
                        self.fom_stats[combo][1][j] * self._model_functions[cid]
                    )
                    j += 1
                residual += this_residual

                # stop the loop if fom_threshold is reached
                if self.fom_stats[combo][0] - minnie >= self.params.fom_threshold:
                    break
            residual /= count

            self.summary["count"] = count

            cid_list = list(stats.keys())

            unaccounted = np.zeros(self.nu.shape)
            unaccounted += self.loss

            # create a dataframe with statistics
            self.summary["cid_stats"] = pd.DataFrame(
                columns=["cid", "num", "fraction", "mean", "std"]
            )
            for j, cid in enumerate(cid_list):
                num = stats[cid]
                if num > 0:
                    mn, st = np.mean(concs[cid]), np.std(concs[cid])
                else:
                    mn, st = np.nan, np.nan
                self.summary["cid_stats"].loc[j] = [
                    int(cid),
                    int(num),
                    num / count,
                    mn,
                    st,
                ]
                if num / count >= self.params.fraction:
                    unaccounted -= mn * self._model_functions[cid]

            self.summary["unaccounted_FOM"] = calc_FOM(unaccounted, self.noise)
            self.summary["nominal_residual_FOM"] = calc_FOM(residual, self.noise)

            self.summary["spectra"] = {}
            self.summary["spectra"]["nominal_residual"] = residual
            self.summary["spectra"]["unaccounted_residual"] = unaccounted
            self.summary["parameters"] = dict(self.params)

    def check_list(self):
        """Check for compounds that appear frequently in the statistics and have significant
        concentrations; negatives can be disallowed if desired"""
        cid_list = []
        if self.summary["combinations_evaluated"]:
            X = self.summary["cid_stats"]

            # select rows with cids that appear frequently in the best fits
            Y = X[X["fraction"] >= self.params.fraction]

            # select cids where the ratio of the amplitude to the std dev is greater than k-factor
            for row in Y.iterrows():
                if row[1]["num"] == 1:
                    cid_list.append(int(row[1]["cid"]))
                else:
                    z = row[1]["mean"] / row[1]["std"]
                    if not self.params.ban_negatives:
                        z = abs(z)
                    if z >= self.params.kfactor:
                        cid_list.append(int(row[1]["cid"]))
        return cid_list

    def gotta_catch_em_all(self):
        """Main loop for compound hunting.  Keeps going until there are no new CIDs discovered using this method."""
        keep_fitting = True
        count = 1
        while keep_fitting:
            if self.verbose:
                LOGGER.info(f"=== Cycle {count} ===")

            # first, execute a cycle to find candidates
            self.execute_cycle(
                N=self.params.Nfits, Mfinal=self.params.Mfits, L=self.params.Lfits
            )

            # check for compounds that appear clearly and frequently
            found_cids = self.check_list()

            # stop fitting if the list of cids doesn't change
            keep_fitting = set(found_cids) != set(self.required_cids)
            keep_fitting &= count < self.params.max_cycles
            self.required_cids = found_cids
            self.required_cids.sort()

            LOGGER.info(f"Required CIDs = {self.required_cids}")
            count += 1

        # once the list of cids is stable (self.required_cids), perform an assessment of the resulting compounds
        self.assessment = self.assess_final_results()
        self.run_duration = time.time() - self.start_time

    def assess_final_results(self):
        """assess quality and create summary metadata after GottaCatchEmAll has run"""
        res = {}

        if len(self.required_cids) > 0:
            cids_found, cids_rejected, confidence = self.determine_confidence(
                self.required_cids
            )
        else:
            cids_found = []
            cids_rejected = []
            confidence = {}

        res["candidate_population"] = self.candidate_population
        res["cids_found"] = cids_found
        res["cids_rejected"] = cids_rejected
        res["confidence"] = confidence

        res["combinations_evaluated"] = self.summary["combinations_evaluated"]
        res["combo_num"] = self.summary["extra_compounds"]
        res["candidate_cids"] = self.candidate_cids

        # assessment of fits:
        fits = {}
        fits["CERTAIN_ONLY"] = res["cids_found"] + []
        fits["CERTAIN_AND_MAYBES"] = fits["CERTAIN_ONLY"] + res["cids_rejected"]

        res["fits"] = fits
        spectra = {}
        spectra["nu"] = self.nu
        spectra["loss"] = self.loss
        spectra["error"] = self.error

        fit_FOM = {}
        fit_FOM["loss_fom"] = calc_FOM(self.loss, self.noise)

        specific_fit_results = {}
        # run a list of fits to include in saved statistics.
        # typically, the most useful fit is "CERTAIN_AND_MAYBES_N00" for the concentration estimates of the certains.
        for fit_type in ["CERTAIN_ONLY", "CERTAIN_AND_MAYBES"]:
            fit_name = f"{fit_type}_N00"
            fit_list = fits[fit_type]
            if self.verbose:
                LOGGER.info(f"Performing final assessment of fit {fit_name} ...")
            fit, these_cids = self.perform_specific_fit(fit_list, extra_from_library=0)
            if fit is not None:
                spectra[fit_name] = fit[1].residual_error
                fit_FOM[fit_name] = calc_FOM(fit[1].residual_error, self.noise)
                specific_fit_results[fit_name] = {
                    data[0]: (data[1], data[2])
                    for data in zip(these_cids, fit[0], fit[1].std_dev)
                }
        res["spectra"] = spectra
        res["fit_FOM"] = fit_FOM
        res["specific_fit_results"] = specific_fit_results

        if res["combinations_evaluated"] == 0:
            # populate summary table with empty dataframe
            res["summary_table"] = self.get_stats_dataframe()
        else:
            res["certain_only_FOM"] = res["fit_FOM"].get("CERTAIN_ONLY_N00", np.nan)
            res["certain_and_maybes_FOM"] = res["fit_FOM"].get(
                "CERTAIN_AND_MAYBES_N00", np.nan
            )

            # create summary table
            df = self.get_stats_dataframe()
            stats_table = self.summary["cid_stats"]
            namo = str(self.params.specific_fit_for_stats)
            for j, cid in enumerate(res["cids_found"] + res["cids_rejected"]):
                Q = res["confidence"][cid]["quality"]
                best2 = res["confidence"][cid]["best_2compound_alternative"]

                cid_result = res["specific_fit_results"][namo][cid]
                conc = cid_result[0]
                std = cid_result[1]
                if cid in stats_table["cid"].astype(int).to_numpy():
                    msk = stats_table["cid"] == cid
                    sconc = stats_table[msk]["mean"].values[0]
                    sstd = stats_table[msk]["std"].values[0]
                    snum = stats_table[msk]["num"].values[0]
                    sfrac = stats_table[msk]["fraction"].values[0]
                else:
                    sconc = np.nan
                    sstd = np.nan

                df.loc[j] = [int(cid), Q, conc, std, sconc, sstd, snum, sfrac, best2]
            res["summary_table"] = df
        return res

    def get_stats_dataframe(self):
        """get a clean empty dataframe to fill with delicious statistics"""
        df = pd.DataFrame(
            columns=[
                "cid",
                "Q",
                "specific_fit_mean",
                "specific_fit_std",
                "stats_mean",
                "stats_std",
                "stats_num",
                "stats_fraction",
                "best_2compound_alternative",
            ]
        )
        return df

    def determine_confidence(self, cids_found):
        """Flag compounds where a 2 compounds does a better job than one of the identified single compounds
        Note: this isn't great if there are missing compounds in the fit!"""

        # First create a fit of all the found compounds to determine the baseline rmse (all_rmse)
        A_all = []
        for fcid in cids_found:
            A_all.append(self._model_functions[fcid])
        fit_all = least_squares(
            Amatrix(A_all), self.loss, y_err=np.ones(self.loss.shape) * self.noise
        )
        all_rmse = rmse(fit_all[1].residual_error)

        if len(self.candidate_population) > 0:
            search_candidates = self.candidate_population - set(cids_found)
        else:
            search_candidates = set(self.available_cids) - set(cids_found)

        # cycle through each cid_found and determine the Q factor
        # quality (Q) factor = rmse with selected compound removed and best TWO alternatives included / all_rmse

        good_cids = []
        rejected_cids = []
        confidence = {}
        if self.verbose:
            LOGGER.info("Determining Confidence with 2 compound combinations...")
        for cid in cids_found:
            confidence[cid] = {}

            # start with all found model functions except the test compound `cid`
            Astart = []
            for fcid in cids_found:
                if fcid != cid:
                    Astart.append(self._model_functions[fcid])

            best_rmse = np.inf
            best_cid = None

            if len(self.candidate_population) > 0:
                # pick the top num_close_compounds and add it to the pool of alternatives
                close_cids = set(
                    self.sorted_by_distance[cid][: self.params.num_close_compounds]
                ) - set(cids_found)
                alternative_cids = close_cids | search_candidates
            else:
                alternative_cids = copy.deepcopy(search_candidates)

            # cycle through all pairwise combinations of available_cids
            for a, b in itertools.combinations(alternative_cids, 2):
                Alist = Astart + []
                for ccid in [a, b]:
                    Alist = Alist + [self._model_functions[ccid]]
                fit_cid = least_squares(
                    Amatrix(Alist),
                    self.loss,
                    y_err=np.ones(self.loss.shape) * self.noise,
                )
                if self.params.ban_negatives:
                    if fit_cid[0][-2] < 0 and fit_cid[0][-1] < 0:
                        continue
                this_rmse = rmse(fit_cid[1].residual_error)
                if this_rmse < best_rmse:
                    best_rmse = this_rmse
                    best_cid = (a, b)
            quality = best_rmse / all_rmse
            if quality > self.params.Q_threshold:
                good_cids.append(cid)
                keep_me = True
            else:
                rejected_cids.append(cid)
                keep_me = False
            confidence[cid]["quality"] = quality
            confidence[cid]["keep_me"] = keep_me
            confidence[cid]["best_2compound_alternative"] = best_cid
            message = "KEPT" if keep_me else "REJECTED"
            LOGGER.info(f"cid = {cid} {message} {quality:2}")
        return good_cids, rejected_cids, confidence

    def perform_specific_fit(self, cid_list, extra_from_library=0):
        """Helper function to fit a given set of compounds to the data set"""

        # create a starting point list of model functions
        Astart = []
        best_fit, best_cids = None, []
        for cid in cid_list:
            mf = self._model_functions[cid]
            Astart.append(mf)
        if extra_from_library == 0:
            if cid_list:
                best_fit = least_squares(Amatrix(Astart), self.loss, y_err=self.error)
                best_cids = cid_list
        else:
            candidates = self.available_cids
            best_rmse = np.inf
            for combo in itertools.combinations(candidates, extra_from_library):
                Alist = Astart + []
                for ccid in combo:
                    if ccid in cid_list:
                        continue
                    else:
                        Alist = Alist + [self._model_functions[ccid]]
                fit_cid = least_squares(
                    Amatrix(Alist),
                    self.loss,
                    y_err=np.ones(self.loss.shape) * self.noise,
                )
                this_rmse = rmse(fit_cid[1].residual_error)
                all_positive = np.all(fit_cid[0] >= 0)
                invalid_result = self.params.ban_negatives and not all_positive
                if (this_rmse < best_rmse) and not invalid_result:
                    best_rmse = this_rmse
                    best_cids = cid_list + list(combo)
                    best_fit = fit_cid
        return best_fit, best_cids


def hunting_loop(
    MF,
    nu,
    loss,
    r3_params_list,
    noise=None,
    required_cids_start=[],
    ignore_cids=[],
    verbose=False,
):
    """Iterate through the gotta_catch_em_all function, changing the r3_parameters with each iteration.
    Returns a summary of results in a RCubedResults model, and a list of instances of RecursiveFitter
    """

    required_cids = copy.deepcopy(required_cids_start)
    results_list = []
    for r3_params in r3_params_list:
        LOGGER.info(f"Catching em all with using {r3_params}")
        R3 = RecursiveFitter(
            MF,
            nu,
            loss,
            r3_params,
            noise=noise,
            required_cids=required_cids,
            ignore_cids=ignore_cids,
            verbose=verbose,
        )
        R3.gotta_catch_em_all()
        results_list.append(R3)
        # set required_cids from result of Q_factor test
        required_cids = R3.assessment["cids_found"]
    return summarize_hunting_loop_results(results_list), results_list


class RCubedResults(BaseModel):
    """Output data model for R-cubed algorithm

    Args:
    analysis_date (str): date-time string when the analysis was run
    num_rcubed_iterations (int): number of iterations in the hunting loop
    duration (float): computation time for the hunting
    full_candidate_population (int): all the compounds considered as part of the algorithm
    certain_only_FOM (float): figure of merit of residual with only the certain compounds in the fit. ~1.0 is good;
      computed only for the last iteration.
    certain_and_maybe_FOM (float): figure of merit of residual with certain and maybes in the fits. ~1.0 is good;
      computed only for the last iteration

    summary_results: pandas dataframe with the following columns:
      cid: Pubchem ID
      Q: Quality value weighted by the iteration, where later iterations have a higher weight.  If a cid was not reported
          in a given iteration, Q=0 is assumed.
      conc_mean: mean concentration (weighted by the std. dev.) for all iterations in which the compound was found (either
          certains or maybes).  This is determined from the final fit (typically using all certain and maybe compounds)
      conc_std: RMS of the std dev of the individual iterations
      weighted_frac_of_iters: the sum of the iterations in which the compound was found divided by the sum of the iterations.
          Equal to 1 for compounds found in all iterations.  Compounds found in only in the first iteration has the lowest score.
    last_iter_results: pandas dataframe with the following columns from the final iteration of the Rcubed algorithm:
      cid: PubchemId
      Q: Quality value
      conc_mean: mean concentration determined from the final fit (typically using all certain and maybe compounds)
      conc_std: parameter uncertainty from the least squares final fit

    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    analysis_date: str
    num_rcubed_iterations: int
    duration: float
    full_candidate_population: list
    certain_only_FOM: float
    certain_and_maybes_FOM: float
    summary_results: pd.DataFrame
    last_iter_results: pd.DataFrame


def thisDateTimeSec(epochTimeIn, fmt="%Y%m%d_%H%M%S"):
    """returns a formated string in local time, given an epoch time as input"""
    return time.strftime(fmt, time.localtime(epochTimeIn))


def create_summary_dframe(full_df, num_iterations) -> pd.DataFrame:
    """Computes important statistics from the summary tables from all iterations
    Args:
      full_df: concatenated summary tables from each Rcubed iteration
      num_iterations: number of Rcubed iterations

    Returns:
      dataframe with the statistical analysis of Q and concentration for each CID
    """
    OUT_COLS_SUMMARY = [
        "Q",
        "conc_mean",
        "conc_std",
        "weighted_frac_of_iters",
    ]

    def compound_stats(dframe):
        total_wt = sum(range(1, num_iterations + 1))
        Q_mean_wt = (dframe["Q"] * dframe["iteration"]).sum() / total_wt
        weight = (dframe["iteration"]).sum() / total_wt
        conc_mean = (
            dframe["specific_fit_mean"] / dframe["specific_fit_std"] ** 2
        ).sum() / (1 / dframe["specific_fit_std"] ** 2).sum()
        conc_std = np.sqrt(
            ((dframe["specific_fit_mean"] - conc_mean) ** 2).mean()
            + (dframe["specific_fit_std"] ** 2).mean()
        )
        new_df = pd.DataFrame(columns=OUT_COLS_SUMMARY)
        for i in range(1):
            new_df.loc[i] = [Q_mean_wt, conc_mean, conc_std, weight]
        return new_df

    if full_df.shape[0] != 0:
        proc_df = full_df.groupby("cid").apply(compound_stats)
        proc_df.sort_values("Q", inplace=True, ascending=False)
        proc_df.index = proc_df.index.droplevel(1)
    else:
        proc_df = pd.DataFrame(columns=OUT_COLS_SUMMARY + ["cid"])
        proc_df.set_index("cid", inplace=True)
    return proc_df


def create_simple_df(dframe):
    """creates a simple summary dataframe from the summary table from an Rcubed cycle"""
    new_df = dframe[["cid", "Q", "specific_fit_mean", "specific_fit_std"]].copy()
    new_df.rename(
        columns={"specific_fit_mean": "conc_mean", "specific_fit_std": "conc_std"},
        inplace=True,
    )
    new_df.sort_values("Q", inplace=True, ascending=False)
    new_df.set_index("cid", inplace=True)
    return new_df


def summarize_hunting_loop_results(results):
    """takes a list of Rcubed results from the hunting loop function and creates a
    summary of results in a pydantic data model"""
    summary_dict = {}

    # useful metadata
    summary_dict["analysis_date"] = thisDateTimeSec(time.time())

    summary_dict["num_rcubed_iterations"] = len(results)
    summary_dict["duration"] = np.sum([res.run_duration for res in results])

    # come up with complete candidate population -- i.e., all compounds that were considered by the algorithm at some point
    complete_pop = set()
    for res in results:
        this_pop = res.assessment["candidate_population"]
        for cid in this_pop:
            complete_pop.add(cid)
    summary_dict["full_candidate_population"] = sorted(list(complete_pop))

    # curate interesting stats from hunting
    summary_dict["certain_only_FOM"] = results[-1].assessment.get(
        "certain_only_FOM", np.nan
    )
    summary_dict["certain_and_maybes_FOM"] = results[-1].assessment.get(
        "certain_and_maybes_FOM", np.nan
    )

    # compile compound statistics

    # concatenate the summary table from all iterations (and add an iteration column)
    df_list = []
    for i, res in enumerate(results):
        sum_df = res.assessment["summary_table"].copy()
        sum_df["iteration"] = i + 1
        df_list.append(sum_df)
    full_df = pd.concat(df_list)

    summary_dict["summary_results"] = create_summary_dframe(full_df, len(results))
    summary_dict["last_iter_results"] = create_simple_df(df_list[-1])

    result_model = RCubedResults(**summary_dict)
    return result_model
