import copy
import itertools
from collections import defaultdict
from typing import Dict

import numpy as np
import pandas as pd
from spectral_arithmetic.linear_least_squares import least_squares

from spectral_toolkit.logger import get_logger

LOGGER = get_logger(__name__)


def Amatrix(Alist):
    return np.array(Alist).T


def calc_FOM(X, noise):
    """FOM = mean variance scaled by the noise^2"""
    return (X**2).sum() / len(X) / noise**2


def rmse(X):
    return np.sqrt((X**2).sum() / len(X))


class Allan:
    def __init__(self, data, T=None, calc=True):
        self.data = data
        self.S = []
        self.N = 1
        self.T = []
        self.E = []
        self.white = -1.0
        self.drift = -1.0
        self.fraction = -1.0
        self.N64 = -1.0
        self.fraction64 = -1.0
        if T is None:
            self.dt = 1.0
        else:
            self.dt = self.calcDT(T)
        if calc:
            self.calcAllen()

    def calcDT(self, T):
        return (max(T) - min(T)) / (len(T) - 1)

    def calcAllen(self):
        if np.std(self.data) != 0:
            while len(self.data) >= 2:
                y = self.diffstdev(self.data)
                self.S.append(y)
                self.T.append(self.N)
                points = len(self.data)
                ebar = y / np.sqrt(points)
                self.E.append(ebar)
                self.N *= 2.0
                self.data = self.avepair(self.data)
        self.S = np.array(self.S)
        self.T = np.array(self.T) * self.dt
        self.E = np.array(self.E)
        return self.S, self.T, self.E

    def diffstdev(self, Y):
        x = []
        for i in range(len(Y) - 1):
            x.append(Y[i + 1] - Y[i])
        if len(x) > 1:
            # a = np.std(x)/np.sqrt(2)
            # a = np.sqrt(np.sum(np.array(x)**2)/(len(x)-1)/2) <-- error found by A. Biasioli 20220425
            a = np.sqrt(np.sum(np.array(x) ** 2) / len(x) / 2)
        else:
            a = abs(x[0]) / np.sqrt(2)
        return a

    def avepair(self, Y):
        x = []
        for i in range(int(len(Y) / 2)):
            x.append(0.5 * (Y[2 * i] + Y[2 * i + 1]))
        return x

    def allStats(self):
        R = {}
        R["N"] = self.N
        R["white"] = self.white
        R["drift"] = self.drift
        R["N64"] = self.N64
        R["fraction"] = self.fraction
        R["fraction64"] = self.fraction64d
        R["allenstd"] = self.S
        return R


class RecursiveFitter:
    _model_functions: Dict = {}
    _required_model_functions: Dict = {}
    _ignore_model_functions: Dict = {}
    """Class for recursively fitting an input spectrum"""

    def __init__(self, MF, ignore_cids=[], check_cids=[], required_cids=[]):
        self.ignore_cids = ignore_cids
        self.check_cids = check_cids
        self.required_cids = required_cids
        for cid, mf in MF.items():
            if cid in self.ignore_cids:
                self._ignore_model_functions[cid] = mf
            elif cid in self.required_cids:
                self._required_model_functions[cid] = mf
            else:
                self._model_functions[cid] = mf

    def get_mf(self, cid):
        """convenience function for retrieving a model function from this class given a CID"""
        if cid in self._ignore_model_functions:
            y = self._ignore_model_functions[cid]
        elif cid in self._required_model_functions:
            y = self._required_model_functions[cid]
        elif cid in self._model_functions:
            y = self._model_functions[cid]
        else:
            y = None
        return y

    def add_data(self, nu, loss, noise=None):
        """Add spectral data.  The noise is the inherent noise of the residuals.  It would be good
        to change this to a vector input derived from the first term of an Allan deviation of
        each mode in a compactified spectrum.  But we don't have that now, so the noise is
        typically derived using the determine_noise function"""
        self.nu = nu
        self.loss = loss
        self.error = np.ones(nu.shape)
        if noise is None:
            self.determine_noise()
        else:
            self.noise = noise
        self.error *= self.noise

    def add_a_compound(self, fit_cids):
        """Add a compound to the list of candidate CIDs, by going 1 by 1 through the library
        fit_cids are always in this fit"""
        Alist = []
        for rcid in self.required_cids:
            rmf = self._required_model_functions[rcid]
            Alist.append(rmf)

        if fit_cids:
            for cid in fit_cids:
                Alist.append(self._model_functions[cid])
            fit0 = least_squares(Amatrix(Alist), self.loss, y_err=self.error)
            fit0_lsq = fit0[1].lsq_res
            best = (-1, fit0_lsq)
        else:
            best = (-1, np.inf)
        for cid in self._model_functions.keys():
            if cid in fit_cids:
                continue
            Blist = Alist + [self._model_functions[cid]]

            fiti = least_squares(Amatrix(Blist), self.loss, y_err=self.error)
            if fiti[1].lsq_res < best[1]:
                best = (cid, fiti[1].lsq_res, fiti[1].residual_error)
        return best

    def remove_many_compounds(self, fit_cids, N_remaining):
        """find the best combination of a set of fit_cids"""
        best_combo = None
        Astart = []
        for rcid in self.required_cids:
            rmf = self._required_model_functions[rcid]
            Astart.append(rmf)

        for combo in itertools.combinations(fit_cids, N_remaining):
            Alist = copy.deepcopy(Astart)
            for cid in combo:
                Alist.append(self._model_functions[cid])
            fit = least_squares(Amatrix(Alist), self.loss, y_err=self.error)
            if best_combo is None:
                best_combo = (fit[1].lsq_res, combo)
            else:
                if fit[1].lsq_res < best_combo[0]:
                    best_combo = (fit[1].lsq_res, combo)
        return best_combo[1]

    def determine_noise(self, N=15):
        """determine the noise by fitting N cids and taking the Allan deviation of the
        spectral residuals.  This is kind of stupid.  Replace with a real uncertainty
        estimate from the spectra themselves."""
        temp_fit_cids = []
        while len(temp_fit_cids) < N:
            temp_best = self.add_a_compound(temp_fit_cids)
            if temp_best[0] != -1:
                best = temp_best
                temp_fit_cids.append(best[0])
            else:
                break
        allan = Allan(best[2])
        self.noise = allan.S[0]

    def execute(self, N=10, Mfinal=3, L=2):
        """Executes on a set of loops of 'Add N' and 'Pick the best M'.
        Find the superset of all compounds found in this manner"""
        Mlist = list(range(2, Mfinal + L, 3)) + list(range(Mfinal + L, Mfinal - 1, -1))
        if L == 0:
            Mlist = [Mfinal + L, Mfinal]
        else:
            Mlist = [L, Mfinal + L, Mfinal]
        LOGGER.info(f"loop through combination search: {Mlist}")
        fit_cids = []
        all_cids = set()
        for loop, M in enumerate(Mlist):
            left = len(Mlist) - loop
            LOGGER.info(f"Running {left}")
            # first, add compounds until N have been found
            while len(fit_cids) < N:
                best = self.add_a_compound(fit_cids)
                if best[0] != -1:
                    fit_cids.append(best[0])
                else:
                    break

            # then, remove compounds until M remain
            if loop != len(Mlist) - 1:
                remaining = self.remove_many_compounds(fit_cids, M)
                fit_cids = list(remaining)

                for cid in fit_cids:
                    all_cids.add(cid)
            else:
                for cid in fit_cids:
                    all_cids.add(cid)
                LOGGER.info(f"checking combinations from {len(all_cids)} member set...")
                self.compile_statistics(list(all_cids), Mfinal)
        return fit_cids

    def compile_statistics(self, fit_cids, Mfinal):
        """Derive the statistics of all combinations of candidate fit_cids choose Mfinal"""
        Astart = []
        for rcid in self.required_cids:
            rmf = self._required_model_functions[rcid]
            Astart.append(rmf)
        self.candidate_cids = fit_cids
        self.results = {}
        LOGGER.info(f"Analyzing combinations of {Mfinal} compounds...")
        self.results[Mfinal] = {}
        for combo in itertools.combinations(fit_cids, Mfinal):
            Alist = copy.deepcopy(Astart)
            for cid in combo:
                Alist.append(self._model_functions[cid])
            fit = least_squares(Amatrix(Alist), self.loss, y_err=self.error)
            fom = calc_FOM(fit[1].residual_error, self.noise)
            ampl = fit[0]
            self.results[Mfinal][combo] = (fom, ampl)

    def process_statistics(self, fraction=0.8, fom_threshold=0.2):
        """Process the statistics to find the most frequent combinations that appear frequently in
        the combinations that have the best noise"""
        self.summary = []
        for mcomps in self.results.keys():
            metadata = {}
            metadata["extra_compounds"] = mcomps
            X = self.results[mcomps]
            Xk = list(X.keys())
            Xk.sort(key=lambda e: X[e][0])

            minnie = X[Xk[0]][0]
            metadata["best_FOM"] = minnie

            stats = defaultdict(int)
            concs = defaultdict(list)
            count = 0
            residual = np.zeros(self.nu.shape)
            for key in Xk:
                count += 1
                this_residual = copy.deepcopy(self.loss)
                j = 0
                for cid in self.required_cids:
                    stats[cid] += 1
                    concs[cid].append(X[key][1][j])
                    this_residual -= X[key][1][j] * self._required_model_functions[cid]
                    j += 1
                for cid in key:
                    stats[cid] += 1
                    concs[cid].append(X[key][1][j])
                    this_residual -= X[key][1][j] * self._model_functions[cid]
                    j += 1
                residual += this_residual
                if X[key][0] - minnie >= fom_threshold:
                    break
            residual /= count

            metadata["count"] = count

            cid_list = list(stats.keys())

            unaccounted = np.zeros(self.nu.shape)
            unaccounted += self.loss

            metadata["cid_stats"] = pd.DataFrame(
                columns=["cid", "num", "fraction", "mean", "std"]
            )
            for j, cid in enumerate(cid_list):
                num = stats[cid]
                if num > 0:
                    mn, st = np.mean(concs[cid]), np.std(concs[cid])
                else:
                    mn, st = np.nan, np.nan
                metadata["cid_stats"].loc[j] = [int(cid), int(num), num / count, mn, st]
                if num / count <= fraction:
                    continue

            metadata["unaccounted_FOM"] = calc_FOM(unaccounted, self.noise)
            metadata["nominal_residual_FOM"] = calc_FOM(residual, self.noise)

            metadata["spectra"] = {}
            metadata["spectra"]["nominal_residual"] = residual
            metadata["spectra"]["unaccounted_residual"] = unaccounted

            self.summary.append(metadata)

    def perform_specific_fit(self, cid_list, extra_from_library=0, ban_negatives=False):
        """Helper function to fit a given set of compounds to the data set"""
        Astart = []
        best_fit, best_cids = None, []
        for cid in cid_list:
            mf = self.get_mf(cid)
            Astart.append(mf)
        if extra_from_library == 0:
            if cid_list:
                best_fit = least_squares(Amatrix(Astart), self.loss, y_err=self.error)
                best_cids = cid_list
        else:
            candidates = list(self._required_model_functions.keys()) + list(
                self._model_functions.keys()
            )
            best_rmse = np.inf
            for combo in itertools.combinations(candidates, extra_from_library):
                Alist = Astart + []
                for ccid in combo:
                    if ccid in cid_list:
                        continue
                    else:
                        Alist = Alist + [self.get_mf(ccid)]
                fit_cid = least_squares(
                    Amatrix(Alist),
                    self.loss,
                    y_err=np.ones(self.loss.shape) * self.noise,
                )
                this_rmse = rmse(fit_cid[1].residual_error)
                all_positive = np.all(fit_cid[0] >= 0)
                invalid_result = ban_negatives and not all_positive
                if (this_rmse < best_rmse) and not invalid_result:
                    best_rmse = this_rmse
                    best_cids = cid_list + list(combo)
                    best_fit = fit_cid
        return best_fit, best_cids


def check_list(RF, fraction=0.9, kfactor=2, ban_negatives=True):
    """Check for compounds that appear frequently in the statistics and have significant
    concentrations; negatives can be disallowed if desired"""
    X = RF.summary[-1]["cid_stats"]
    Y = X[X["fraction"] >= fraction]
    cid_list = []
    for row in Y.iterrows():
        z = row[1]["mean"] / row[1]["std"]
        if not ban_negatives:
            z = abs(z)
        if z >= kfactor:
            cid_list.append((int(row[1]["cid"]), z))
    cid_list.sort(key=lambda e: e[1], reverse=True)
    return cid_list


def check_for_sufficient_fits(RF, fom_level=1.2):
    """Stop trying to improve things if the 'FOM' is within a certain level of 1"""
    for summary in RF.summary:
        M = summary["extra_compounds"]
        best = summary["best_FOM"]
        if best <= fom_level:
            break
    return M, best


def GottaFindEmAll(
    nu,
    loss,
    MF,
    Nfits,
    Mfits_start,
    ignore_cids=[],
    check_cids=[],
    required_cids=[],
    extra_compounds=2,
    ban_negatives=True,
    Mfits_max=5,
    Mfits_min=3,
    max_cycles=12,
    kfactor=2,
    fraction=0.9,
    fom_threshold=0.2,
    fom_level=1.2,
):
    """Main loop for compound hunting.  Keeps going until there are no new CIDs discovered using this method."""
    keep_fitting = True
    count = 1
    Mfits = Mfits_start
    while keep_fitting:
        LOGGER.info(f"=== Cycle {count} ===")
        RF = RecursiveFitter(
            MF,
            ignore_cids=ignore_cids,
            check_cids=check_cids,
            required_cids=required_cids,
        )
        RF.add_data(nu, loss)
        RF.execute(N=Nfits, Mfinal=Mfits)
        RF.process_statistics(fraction=fraction, fom_threshold=fom_threshold)
        good_cids = check_list(
            RF, ban_negatives=ban_negatives, kfactor=kfactor, fraction=fraction
        )
        found_cids = [e[0] for e in good_cids]
        keep_fitting = set(found_cids) != set(required_cids)
        keep_fitting &= count < max_cycles
        required_cids = found_cids

        M, res_fom = check_for_sufficient_fits(RF, fom_level=fom_level)
        Mfits = M + 2
        if Mfits < Mfits_min:
            Mfits = Mfits_min
        elif Mfits > Mfits_max:
            Mfits = Mfits_max
        count += 1
        required_cids.sort()
        LOGGER.info(f"Required CIDs = {required_cids}")

    # do one last fit with Mfits = extra_compounds, beyond the ones that were found
    LOGGER.info(f"=== Cycle {count} ===")
    RF = RecursiveFitter(
        MF, ignore_cids=ignore_cids, check_cids=check_cids, required_cids=required_cids
    )
    RF.add_data(nu, loss)
    RF.execute(N=Nfits, Mfinal=extra_compounds, L=0)
    RF.process_statistics(fraction=fraction, fom_threshold=fom_threshold)
    good_cids = check_list(
        RF, ban_negatives=ban_negatives, kfactor=kfactor, fraction=fraction
    )
    found_cids = [e[0] for e in good_cids]
    found_cids.sort()
    LOGGER.info(f"Final Candidate CIDs = {found_cids}")
    assessment = assess_analysis(RF, ban_negatives=ban_negatives)
    return RF, assessment


def rmse(X):
    return np.sqrt((X**2).sum() / len(X))


def determine_confidence(cids_found, RF):
    """Flag compounds where a 2 compounds does a better job than one of the identified single compounds
    Note: this isn't great if there are missing compounds in the fit!"""
    A_all = []
    for fcid in cids_found:
        A_all.append(RF.get_mf(fcid))
    fit_all = least_squares(
        Amatrix(A_all), RF.loss, y_err=np.ones(RF.loss.shape) * RF.noise
    )
    all_rmse = rmse(fit_all[1].residual_error)
    cids = list(RF._model_functions.keys())

    good_cids = []
    rejected_cids = []
    confidence = {}
    LOGGER.info("Determining Confidence with 2 compound combinations...")
    for cid in cids_found:
        confidence[cid] = {}
        Astart = []
        for fcid in cids_found:
            if fcid != cid:
                Astart.append(RF.get_mf(fcid))
        # fit = least_squares(Amatrix(Astart), RF.loss, y_err=np.ones(RF.loss.shape) * RF.noise)
        best_rmse = np.inf
        best_cid = None
        for a, b in itertools.combinations(cids, 2):
            Alist = Astart + []
            for ccid in [a, b]:
                if ccid in cids_found:
                    continue
                else:
                    Alist = Alist + [RF.get_mf(ccid)]
            fit_cid = least_squares(
                Amatrix(Alist), RF.loss, y_err=np.ones(RF.loss.shape) * RF.noise
            )
            this_rmse = rmse(fit_cid[1].residual_error)
            if this_rmse < best_rmse:
                best_rmse = this_rmse
                best_cid = (a, b)
        quality = best_rmse / all_rmse
        if quality > 1.0:
            good_cids.append(cid)
            keep_me = True
        else:
            rejected_cids.append(cid)
            keep_me = False
        confidence[cid]["quality"] = quality
        confidence[cid]["keep_me"] = keep_me
        confidence[cid]["best_2compound_alternative"] = best_cid
        message = "KEPT" if keep_me else "REJECTED"
        LOGGER.info(f"cid = {cid} {message} {quality:2}")
    return good_cids, rejected_cids, confidence


def check_similarity(cids_found, RF, concs, conc_std, k=2):
    """Useful for finding compounds spectrally similar to those that were rejected"""
    norm = lambda x: x / np.sqrt(np.dot(x, x))

    cids = list(RF._model_functions.keys())
    alternatives = defaultdict(list)
    for j, CID in enumerate(cids_found):
        conc_err = concs[j] / conc_std[j] / k
        y = norm(RF.get_mf(CID))
        for cid in cids:
            x = norm(RF.get_mf(cid))
            z = np.dot(x, y)
            if abs(z) > 1 - (1 / conc_err) ** 2:
                if cid != CID:
                    alternatives[CID].append((cid, z))
    alt_dict = {}
    for key, value in alternatives.items():
        alt_dict[key] = value
    return alt_dict


def assess_analysis(RF, fraction_thresh=0.9, extra_N=2, ban_negatives=False):
    """assess quality and create summary metadata"""
    res = {}
    stats = RF.summary[-1]["cid_stats"]
    U = stats[stats["fraction"] >= fraction_thresh]
    res["stats"] = stats
    prelim_cids_found = U["cid"].astype(int).to_list()
    if len(prelim_cids_found) > 0:
        cids_found, cids_rejected, confidence = determine_confidence(
            prelim_cids_found, RF
        )
    else:
        cids_found = []
        cids_rejected = []
        confidence = {}
    res["cids_found"] = cids_found
    res["cids_rejected"] = cids_rejected
    res["confidence"] = confidence
    res["concs"] = U["mean"].to_numpy()
    res["conc_std"] = U["std"].to_numpy()
    res["alternatives"] = check_similarity(
        cids_found, RF, res["concs"], res["conc_std"]
    )

    res["combo_num"] = RF.summary[-1]["extra_compounds"]
    res["candidate_cids"] = RF.candidate_cids
    res["probably_found_every_thing"] = RF.summary[-1]["unaccounted_FOM"]
    res["every_thing_probably_in_library"] = RF.summary[-1]["nominal_residual_FOM"]

    # assessment of fits:
    fits = {}
    fits["certain"] = res["cids_found"] + []
    fits["maybe"] = fits["certain"] + res["cids_rejected"]

    res["fits"] = fits
    spectra = {}
    spectra["nu"] = RF.nu
    spectra["loss"] = RF.loss

    extra_combos = [0]
    if extra_N not in extra_combos:
        extra_combos.append(extra_N)

    fit_FOM = {}
    fit_FOM["loss"] = calc_FOM(RF.loss, RF.noise)
    compounds = {}
    concentrations = {}
    for name, fit_list in fits.items():
        for extra in extra_combos:
            fit_name = "RES_%s_EXTRA%.2d" % (name, extra)
            LOGGER.info(f"Performing final assessment of fit {fit_name} ...")
            fit, these_cids = RF.perform_specific_fit(
                fit_list, extra_from_library=extra, ban_negatives=ban_negatives
            )
            if fit is not None:
                spectra[fit_name] = fit[1].residual_error
                fit_FOM[fit_name] = calc_FOM(fit[1].residual_error, RF.noise)
                compounds[fit_name] = these_cids
                concentrations[fit_name] = (fit[0], fit[1].std_dev)
    res["spectra"] = spectra
    res["fit_FOM"] = fit_FOM
    res["fit_list"] = compounds
    res["fit_results"] = concentrations

    return res
