"""Utilities to evaluate lasso lars performance and
perform a final selection suggestion"""
import numpy as np
import pandas as pd
import xarray as xr
from scipy.stats import binomtest, ttest_ind_from_stats
from sklearn.metrics import (mean_absolute_percentage_error,
                             mean_squared_error, r2_score)

from spectral_toolkit.compound_hunting import get_spectrum_score


def spectrum_score(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """
    Returns spectrum score.
    This function is suitable to create a sklearn
    scorer:
    ``make_scorer(spectrum_score, greater_is_better=True)``


    Args:
        y_true (np.ndarray):
            Real data
        y_pred (np.ndarray):
            Predicted/estimated data

    Returns:
        float: Spectrum score. Larger is better.

    """
    return get_spectrum_score(measured_spectrum=y_true, modeled_spectrum=y_pred)


def performance_summary(results_ds: xr.Dataset) -> pd.DataFrame:
    """
    Evaluates rmse, mape, R2, and spectrum score for
    all the models provided in ``ds`` (time_split).

    Args:
        results_ds (xr.Dataset):
            Result dataset from `.train_lars`

    Returns:
        pd.Dataframe:
            RMSE, MAPE, R2, SS as columns,
            models as rows.

    """
    rmse = []
    mape = []
    rsquared = []
    spectrum_s = []

    for i in results_ds.time_split.values:
        model = results_ds.sel(time_split=i)
        mask = model.use_wavenumber
        y_test = model["y_test"].where(mask, drop=True).values
        y_predict = model["y_predict"].where(mask, drop=True).values
        test_weights = model["w_test"].where(mask, drop=True).values

        rmse.append(mean_squared_error(y_test, y_predict, sample_weight=test_weights))
        mape.append(
            mean_absolute_percentage_error(
                y_test, y_predict, sample_weight=test_weights
            )
        )
        rsquared.append(r2_score(y_test, y_predict, sample_weight=test_weights))
        spectrum_s.append(spectrum_score(y_test, y_predict))

    performance_df = pd.DataFrame(
        data={"rmse": rmse, "mape": mape, "ss": spectrum_s, "R2": rsquared}
    )
    performance_df.index.name = "bootstrap"
    return performance_df


def _get_pvalues(sample_data: np.ndarray, noise_std: float) -> float:
    """
    T-test for means of two independent
    samples from descriptive statistics.

    The statistics (mean, std, n_obs) for the first
    sample are calculated from sample_data.

    The second sample mean is fixed at zero, n_obs are
    set at 1000, and the standard deviation is provided
    through `noise_std`.
    The role of the second sample is to describe a
    well-characterized distribution, such as noise or zero
    concentration.

    Example:
        - noise_std can represent absorbance (partial fit)
        noise. In this case, noise_std could be the noise
        level estimated from shot-to-shot error.

        - noise_std can represent concentration noise.
        It could be the limit of detection of a compound,
        or a threshold below which we are confident saying that
        the concentration is zero.

    From scipy: this is a test for the null hypothesis
    that the two independent samples have
    identical average (expected) values.

    We will reject the null hypothesis in favor of
    the alternative if the p-value is less than a set threshold.
    This function returns the p-values.

    Args:
        sample_data (np.ndarray):
            Samples from a first distribution.
        noise_std (float):
            Standard deviation of the second distribution.
            The second distribution has mean 0 and n_obs=1000.

    Returns:
        float: p-value associated with the alternative.
    """
    pvalue = 1.0

    if any(sample_data != 0):
        pvalue = ttest_ind_from_stats(
            mean1=sample_data.mean(),
            std1=sample_data.std(),
            nobs1=len(sample_data),
            mean2=0,
            std2=noise_std,
            nobs2=1000,
        ).pvalue

    if np.isnan(pvalue):
        pvalue = 1.0

    return pvalue


def _get_noise_pvalue(
    models: xr.Dataset,
    expected_noise_std: float = 0.08,
    reference_quantile: float = 0.05,
) -> pd.Series:
    """
    Get the p-value for each CID
    associated to its absorption.

    The lower the p-value, the less likely
    that the estimated absorption is
    spectral noise.

    Initially, p-values is a matrix
    (n_modes x n_cids).
    The reference quantile is used to summarize that
    matrix into an array (n_cids).

    if reference_quantile = 0.05, the 5% percentile
    level of p-values related to a CID is selected.
    If the 5% percentile of p-values is less than a decision
    boundary alpha, then the estimated absorption is
    not likely to be noise.
    In that case, the 5% percentile could be seen as:
    for this CID, at least 5% of the modes
    are statistically different from the noise
    (they are significant).

    If p-value is larger than the boundary alpha,
    it means that we don't have enough information
    to say that this estimated absorption is not noise.

    A low value of reference quantile ensures we can test
    the significance of 'spikey' compounds, that are likely
    significant only at a few wave numbers (the spikes).

    Args:
        models (xr.Dataset):
            Results from `.train_lars`
        expected_noise_std (float):
            Expected standard deviation of the
            spectral noise. This can be estimated
            using the shot to shot error.
            Default is 0.08.

        reference_quantile (float):
            Quantile level for p-value across
            the wave number axis.

    Returns:
        pd.Series: p-values as values, cids as index

    """
    p_value_noise = xr.apply_ufunc(
        _get_pvalues,
        models.absorption,
        input_core_dims=[["time_split"]],
        kwargs={"noise_std": expected_noise_std},
        vectorize=True,
    )
    quantiles = p_value_noise.quantile(
        q=reference_quantile, dim="wavenumber"
    ).to_pandas()
    return quantiles


def _get_concentration_pvalue(
    models: xr.Dataset, expected_concentration_noise_std: float = 0.5
) -> pd.Series:
    """
    Get the p-value for each CID
    associated to its concentration.

    The lower the p-value, the less likely
    that the estimated concentration is
    zero (or in its neighborhood).

    Args:
        models (xr.Dataset):
            Results from `.train_lars`
        expected_concentration_noise_std (float):
            Expected standard deviation of the
            concentration. This could be an LOD,
            or a level of concentration that we would
            typically set to zero.
            Default is 0.5 ppb.

    Returns:
        pd.Series: p-values as values, cids as index

    """
    scaled_coefs = models.coefficients / models.scale
    p_value_coefs = xr.apply_ufunc(
        _get_pvalues,
        scaled_coefs,
        input_core_dims=[["time_split"]],
        kwargs={"noise_std": expected_concentration_noise_std},
        vectorize=True,
    )
    concentration_pvalues = p_value_coefs.to_pandas()
    return concentration_pvalues


def get_quartile_dispersion(models: xr.Dataset):
    concentration = models.coefficients / models.scale
    concentration_df = concentration.to_pandas()
    Q1 = concentration_df.quantile(q=0.25)
    Q3 = concentration_df.quantile(q=0.75)
    dispersion = (0.5 * (Q3 - Q1)) / (0.5 * (Q3 + Q1))
    dispersion = abs(dispersion)
    dispersion = dispersion.sort_values(ascending=True)
    return dispersion


def _get_occurrences_pvalue(occurrences: pd.Series, n_models: int) -> pd.Series:
    """
    Get p-values based on the count
    a CID showed up in a model.

    The p-values are determined from
    a binomial test where the reference case
    is a coin toss (a CID is as likely to show up in
    a model as it is unlikely to do so).

    Args:
        occurrences (pd.Series):
            Occurrence count for every CID.

    Returns:
        pd.Series:
            p-values for every CID based on occurrences count.

    """
    occurrences_pvalues = pd.Series(
        [
            binomtest(
                occurrences.sel(cid=cid).item(),
                n=n_models,
                p=0.5,
                alternative="greater",
            ).pvalue
            for cid in occurrences.cid.values
        ],
        index=occurrences.cid.values,
    )
    return occurrences_pvalues


def pvalue_table(
    results_ds: xr.Dataset,
    concentration_noise_std: float = 0.50,
    absorption_quantile: float = 0.05,
    absorbance_noise_std: float = 0.08,
) -> pd.DataFrame:
    """
    Get summary table with p-values for
    occurrences, concentration, and absorption
    for every CID.


    Args:
        results_ds (xr.Dataset):
            Results dataset from `.train_lars`
        concentration_noise_std (float):
            Expected standard deviation of the
            concentration. This could be an LOD,
            or a level of concentration that we would
            typically set to zero.
            Default is 0.5 ppb.
        absorption_quantile (float):
            Quantile level for p-value across
            the wave number axis.
        absorbance_noise_std (float):
            Expected standard deviation of the
            spectral noise. This can be estimated
            using the shot to shot error.
            Default is 0.08.

    Returns:
        pd.DataFrame:
            P-values for different metrics,
            CIDs as index.

    """
    conc_pvalues = _get_concentration_pvalue(
        models=results_ds, expected_concentration_noise_std=concentration_noise_std
    )
    noise_pvalues = _get_noise_pvalue(
        models=results_ds,
        expected_noise_std=absorbance_noise_std,
        reference_quantile=absorption_quantile,
    )
    occurrences = (
        results_ds["coefficients"]
        .where(results_ds.coefficients != 0)
        .count(dim="time_split")
    )
    occurrences_pvalues = _get_occurrences_pvalue(
        occurrences=occurrences, n_models=len(results_ds.time_split.values)
    )

    pvalue_df = pd.DataFrame(
        data={
            "occurrences": occurrences,
            "occurrence_pvalue": occurrences_pvalues,
            "conc_pvalue": conc_pvalues,
            "noise_pvalue": noise_pvalues,
        }
    )
    pvalue_df = pvalue_df.sort_values(
        by=["noise_pvalue", "conc_pvalue", "occurrence_pvalue"], ascending=True
    )
    return pvalue_df


def run_decision(
    pvalue_df: pd.DataFrame,
    dispersion_measurement: pd.Series,
    decision_alpha: float = 0.01,
    use_alpha_correction: bool = True,
    dispersion_threshold: float = None,
) -> pd.DataFrame:
    """
    Compare p-values for number of observations,
    concentrations, and spectral absorption.

    It is suggested to keep CIDs that
    are significant in all the three p-values
    metrics. Significance is established
    by comparing the p-value
    to an alpha threshold. If p-value < alpha,
    the result is significant (keep CID).

    Performing significance test on many variables (CIDs),
    the probability of observing a rare event increases,
    and therefore, the likelihood of incorrectly
    rejecting a null hypothesis (from Wikipedia).

    Therefore, if `use_alpha_correction` is ``True``,
    the Šidák correction for alpha is used.

    Args:
        pvalue_df (pd.Dataframe):
            Significance level from `.pvalue_table`.
        dispersion_measurement (pd.Series):
            Interquartile dispersion from `.get_quartile_dispersion`
        decision_alpha (float):
            Alpha decision boundary.
            Threshold for 'too unusual'.
            If alpha=0.05, we reject the null hypothesis
            (that our result is random, noise, zero)
            if a result that contradicts it
            happens more than 95% of the times.
            A low value of alpha minimizes
            Type I error (false discovery of CIDs).
            Default is 0.01.
        use_alpha_correction (bool):
            Use Šidák correction based on the
            number of CIDs present in the model
            to make our alpha smaller.
        dispersion_threshold (float):
            Threshold to mark a CID with orange color.
            Orange color means that the variable has a
            high degree of variability across models.
            The threshold refers to concentration-based
            quartile coefficient of dispersion.
            A threshold of 0.1 means that all coefficients
            with QCD < 0.1 are colored green, and above that
            they are marked with orange color, indicating
            a degree of uncertainty in the model. It is
            usual to see this behavior for large molecules
            without sharp features.
            If None (default), then the maximum between 0.1
            and twice the minimum QCD is selected. This allows to
            avoid falsely marking species as uncertain in the
            thermal desorption case.
    Returns:
        pd.DataFrame:
            The column `suggested_use` expose the
            CIDs to be kept for fitting.

    """
    nonzero_coefs = len(pvalue_df.query("occurrences > 0"))

    if use_alpha_correction:
        # sidak correction
        alpha_use = 1 - np.power((1 - decision_alpha), 1 / nonzero_coefs)
    else:
        alpha_use = decision_alpha

    if dispersion_threshold is None:
        dispersion_threshold = max(2 * min(dispersion_measurement), 0.1)

    decision_df = pd.DataFrame(
        data={
            "keep_occurrences": pvalue_df.occurrence_pvalue < alpha_use,
            "keep_concentration_zero": pvalue_df.conc_pvalue < alpha_use,
            "keep_noise": pvalue_df.noise_pvalue < alpha_use,
            "keep_concentration_spread": dispersion_measurement < dispersion_threshold,
        }
    )
    decision_df["maybe_use"] = (
        decision_df.keep_occurrences
        & decision_df.keep_concentration_zero
        & decision_df.keep_noise
    )

    decision_df["suggested_use"] = (
        decision_df.maybe_use & decision_df.keep_concentration_spread
    )

    return decision_df
