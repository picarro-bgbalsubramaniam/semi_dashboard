import numpy as np
import pandas as pd
from sklearn.utils.validation import check_is_fitted
from sklearn.base import BaseEstimator, TransformerMixin


class GlobalScaler(BaseEstimator, TransformerMixin):
    """
    A transformer that scales data globally,
    by subtracting the mean and dividing
    by the standard deviation of the entire
    input array/DataFrame.
    """
    def __init__(self):
        self.global_mean_ = None
        self.global_std_ = None

    def fit(self, X, y=None):
        if isinstance(X, np.ndarray):
            X_flattened = X.flatten()
        else:
            # Pandas series / dataframe
            X_flattened = X.values.flatten()

        self.global_mean_ = np.mean(X_flattened)
        self.global_std_ = np.std(X_flattened)
        return self

    def transform(self, X, y=None):
        check_is_fitted(self, ["global_mean_", "global_std_"])
        return (X - self.global_mean_) / self.global_std_

    def inverse_transform(self, X, y=None):
        check_is_fitted(self, ["global_mean_", "global_std_"])
        return X * self.global_std_ + self.global_mean_
