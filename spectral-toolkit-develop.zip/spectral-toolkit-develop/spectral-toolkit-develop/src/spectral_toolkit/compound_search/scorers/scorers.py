"""
Implements custom scorers for use with scikit-learn's methods.

For more information on custom scorers, see here
https://scikit-learn.org/stable/modules/model_evaluation.html#defining-your-scoring-strategy-from-metric-functions'

Functions whose name end in '_loss' mean that lower values are better,
while functions with names ending in '_score' mean higher values are better.

To use a loss function as a scorer, use the ``make_scorer`` function
from sklearn.metrics.
"""

import numpy as np
from spectral_toolkit.compound_search.scorers.metrics import (
    aic_metric,
    bic_metric,
    spectrum_score_metric,
)


def aic_loss(model, X, y) -> float:
    """
    Calculate the Akaike Information Criterion (AIC) loss for a model.

    This function computes the AIC for a given model.
    Lower is better.
    It can handle single task (y) or multitask (Y).
    If multitask, the AIC is calculated for each task,
    and the median AIC across all tasks is returned.

    Args:
        model:
            A fitted model that supports the predict method.
        X (np.ndarray):
            Input features, with shape (n_samples, n_features).
        y (np.ndarray):
            True output values, with shape (n_samples,)
            or (n_samples, n_tasks).

    Returns:
        float: The median AIC value across all tasks.

    Note:
        The number of features is set to be X.shape[1] + 1 (include the intercept).
    """
    residuals = y - model.predict(X)
    aic = aic_metric(residuals, X.shape[1] + 1)
    return np.median(aic)


def bic_loss(model, X, y) -> float:
    """
    Calculate the Bayesian Information Criterion (BIC) loss for a model.

    This function computes the BIC for a given model.
    Lower is better.
    It can handle single task (y) or multitask (Y).
    If multitask, the BIC is calculated for each task,
    and the median BIC across all tasks is returned.

    Args:
        model:
            A fitted model that supports the predict method.
        X (np.ndarray):
            Input features, with shape (n_samples, n_features).
        y (np.ndarray):
            True output values, with shape (n_samples,)
            or (n_samples, n_tasks).

    Returns:
        float: The median BIC value across all tasks.

    Note:
        The number of features is set to be X.shape[1] + 1 (include the intercept).
    """
    residuals = y - model.predict(X)
    bic = bic_metric(residuals, X.shape[1] + 1)

    return np.median(bic)


def spectrum_score(model, X, y) -> float:
    """
    Calculate the spectrum score for a model.

    This function computes the spectrum score for a given model.
    Higher is better.
    It can handle single task (y) or multitask (Y).
    If multitask, the spectrum score is calculated for each task,
    and the median spectrum score across all tasks is returned.

    Args:
        model:
            A fitted model that supports the predict method.
        X (np.ndarray):
            Input features, with shape (n_samples, n_features).
        y (np.ndarray):
            True output values, with shape (n_samples,) or (n_samples, n_tasks).

    Returns:
        float: The median spectrum score across all tasks.

    """
    ss = spectrum_score_metric(y, model.predict(X))
    return np.median(ss)
