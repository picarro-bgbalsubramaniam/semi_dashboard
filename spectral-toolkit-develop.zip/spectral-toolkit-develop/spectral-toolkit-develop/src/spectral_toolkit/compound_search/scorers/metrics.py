"""
Metrics for evaluating the performance of a compound search algorithm.
"""
from typing import Union

import numpy as np
from scipy import stats
from pydantic import validate_call


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def log_likelihood_metric(residuals: np.ndarray) -> Union[np.ndarray, float]:
    """
    Calculate the log-likelihood of an ordinary least squares model
    given its residuals.

    This function computes the log-likelihood based on the residual sum of squares (RSS)
    of a model's predictions. It assumes that the errors (residuals) are normally distributed.

    The formula used for the log-likelihood calculation is::

        L = -0.5 * n * log(2 * pi) - 0.5 * n * log(RSS / n) - 0.5 * n

    where `n` is the number of observations and `RSS` is the residual sum of squares.

    Args:
        residuals (np.ndarray):
            An array of residuals, which are the differences between the observed
            and predicted values.

    Returns:
        np.ndarray: The log-likelihood value for the given residuals.

    """
    nobs = residuals.shape[0]
    rss = np.sum(residuals**2, axis=0)  # residual sum of squares
    term1 = -0.5 * nobs * np.log(2 * np.pi)
    term2 = -0.5 * nobs * np.log(rss / nobs)
    term3 = -0.5 * nobs
    return term1 + term2 + term3


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def aic_metric(residuals: np.ndarray, n_features: int) -> Union[np.ndarray, float]:
    """
    Calculate the Akaike Information Criterion (AIC) for a model.
    Lower is better.

    AIC is a measure of the relative quality of a statistical model for a given set of data.
    It is calculated using the log-likelihood of the model and the number of features.

    The formula for AIC is::

        AIC = 2 * number of features - 2 * log-likelihood

    Args:
        residuals (np.ndarray):
            An array of residuals from the model.
        n_features (int):
            The number of features (or parameters) in the model.
            The intercept must be included in this count.

    Returns:
        np.ndarray: The calculated AIC value.
    """
    llf = log_likelihood_metric(residuals)
    aic = 2 * n_features - 2 * llf
    return aic


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def bic_metric(residuals: np.ndarray, n_features: int) -> Union[np.ndarray, float]:
    """
    Calculate the Bayesian Information Criterion (BIC) for a model.
    Lower is better.

    The formula for BIC is::

        BIC = log(n) * number of features - 2 * log-likelihood

    where 'n' is the number of samples.

    Args:
        residuals (np.ndarray):
            An array of residuals from the model.
        n_features (int):
            The number of features (or parameters) in the model.
            The intercept must be included in this count.

    Returns:
        np.ndarray: The calculated BIC value.
    """
    llf = log_likelihood_metric(residuals)
    n_samples = residuals.shape[0]
    bic = np.log(n_samples) * n_features - 2 * llf
    return bic


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def spectrum_score_metric(
    y_true: np.ndarray, y_pred: np.ndarray
) -> Union[np.ndarray, float]:
    """
    Calculate spectrum score. Higher is better.

    The score is computed by normalizing y_true and y_pred,
    calculating their dot product, and then
    applying a negative logarithmic transformation to 1 minus this dot product.

    Args:
        y_true (np.ndarray): True values.
        y_pred (np.ndarray): Predicted values.

    Returns:
        np.ndarray: The calculated score.
    """
    ys_true = y_true / np.linalg.norm(y_true, axis=0)
    ys_pred = y_pred / np.linalg.norm(y_pred, axis=0)
    dot_product_norm = np.sum(ys_true * ys_pred, axis=0)
    spectrum_score = -1 * np.log10(1 - dot_product_norm)
    return spectrum_score


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def adjusted_r2_metric(
    r2: Union[float, np.ndarray], n: int, p: int
) -> Union[float, np.ndarray]:
    """
    Calculate the adjusted R-squared (R²) value.

    The formula for adjusted R² is::

        adj_R² = 1 - (1 - R²) * (n - 1) / (n - p - 1)

    where:
    - R² is the coefficient of determination,
    - n is the number of observations,
    - p is the number of predictors (excluding the intercept).

    Args:
        r2 (Union[float, np.ndarray]):
            The R-squared value(s). Can be a single value or an array.
        n (int):
            The number of samples in the dataset.
        p (int):
            The number of features (predictors) in the model, excluding the intercept.

    Returns:
        Union[float, np.ndarray]:
            The adjusted R-squared value(s). Returns a single value if R² is
            a single value, or an array of adjusted R² values if R² is an array.
    """
    return 1 - (1 - r2) * (n - 1) / (n - p - 1)


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def r2_metric(y_true: np.ndarray, y_pred: np.ndarray) -> Union[float, np.ndarray]:
    """
    Calculate the coefficient of determination R-squared (R²).

    The R² is calculated using the formula::

        R² = 1 - (SS_res / SS_tot)

    where SS_res is the sum of squares of residuals and SS_tot is the total sum of squares.

    Args:
        y_true (np.ndarray): True values of the dependent variable.
        y_pred (np.ndarray): Predicted values from the regression model.

    Returns:
        Union[float, np.ndarray]:
            The R-squared value. Returns a single value if the input
            is for a single output regression,
            or an array of R² values if it's a multitask regression.
    """
    residuals = y_true - y_pred

    # Calculate SS_res
    ss_res = np.sum(residuals**2, axis=0)

    # Calculate SS_tot
    y_mean = np.mean(y_true, axis=0)
    ss_tot = np.sum((y_true - y_mean) ** 2, axis=0)

    # Calculate R-squared
    r_squared = 1 - (ss_res / ss_tot)
    return r_squared


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def f_statistics_metric(
    y_true: np.ndarray, y_pred: np.ndarray, p: int
) -> Union[float, np.ndarray]:
    """
    Calculate the F-statistic for a regression model.

    The F-statistic is used to test the overall significance of a regression model.
    It compares the variance explained by the model (sum of squares of the regression, SSR)
    to the variance unexplained by the model (sum of squares of the residuals/errors, SSE).

    The formula for the F-statistic is::

        F = MSR / MSE

    where MSR (Mean Square Regression) is SSR divided by the number of predictors, and MSE
    (Mean Square Error) is SSE divided by the degrees of freedom of the residuals.

    Args:
        y_true (np.ndarray): True values of the dependent variable.
        y_pred (np.ndarray): Predicted values from the regression model.
        p (int): The number of predictors (features) in the model, excluding the intercept.

    Returns:
        Union[float, np.ndarray]:
            The F-statistic. If the input involves multiple outputs (multitask
            regression), an array of F-statistics is returned, one for each output.
    """
    n = y_true.shape[0]  # Number of observations

    # Calculate SSR (sum of squares of the regression)
    y_mean = np.mean(y_true, axis=0)

    ssr = np.sum((y_pred - y_mean) ** 2, axis=0)

    # Calculate SSE (sum of squares of the residuals/errors)
    sse = np.sum((y_true - y_pred) ** 2, axis=0)

    # Calculate MSR and MSE
    msr = ssr / p
    mse = sse / (n - p - 1)

    # Calculate F-statistic
    f_statistic = msr / mse
    return f_statistic


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def f_pvalue_metric(
    f_statistic: Union[float, np.ndarray], p: int, nobs: int
) -> Union[float, np.ndarray]:
    """
    Calculate the p-value of the F-statistic.

    Args:
        f_statistic (float): F-statistic
        p (int): Number of predictors (excluding intercept)
        nobs (int): Number of observations

    Returns:
        float: p-value
    """
    df2 = nobs - p - 1
    # Calculate the p-value
    p_value = stats.f.sf(f_statistic, p, df2)
    return p_value
