"""
Provides a summary of regression coefficients and scores.
"""

import pandas as pd
import numpy as np
from typing import Literal, Tuple, Union
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from spectral_toolkit.compound_search.global_scaler import GlobalScaler
from spectral_toolkit.compound_search.scorers.metrics import (
    log_likelihood_metric,
    r2_metric,
    adjusted_r2_metric,
    spectrum_score_metric,
    f_statistics_metric,
    f_pvalue_metric,
    aic_metric,
    bic_metric,
)


def regression_summary(
    X: pd.DataFrame,
    Y: Union[pd.DataFrame, pd.Series],
    multioutput_coefs: Literal["raw_values", "uniform_average", "median"] = "median",
    multioutput_scores: Literal["raw_values", "uniform_average", "median"] = "median",
) -> Tuple[Union[pd.DataFrame, pd.Series], Union[pd.DataFrame, pd.Series]]:
    """
    Provides a summary of regression coefficients and scores.

    The coefficients are calculated using linear least squares regression
    on the original X, Y data (unscaled), therefore they are express in the
    same units as X, typically ppb.

    The scores are calculated using linear least squares regression on the
    scaled X, Y data. This means that we can
    compare the fit performance on datasets that have different original scales.
    This is particularly important for mse, rmse, aic, bic.

    .. code-block:: python

        from spectral_toolkit.compound_search.metrics.regression_summary import regression_summary

        from sklearn.datasets import make_regression

        X, y = make_regression(
            n_samples=100, n_features=10, n_informative=5, random_state=0
        )

        coefs, scores = regression_summary(X, y)


    Args:
        X (pd.DataFrame):
            A pandas DataFrame representing the model functions.
        Y (Union[pd.DataFrame, pd.Series]):
            A pandas DataFrame or Series representing the spectra (or spectrum).
        multioutput_coefs (Literal["raw_values", "uniform_average", "median"], optional):
            Method to aggregate coefficients if Y is multi-output. Defaults to "median".
        multioutput_scores (Literal["raw_values", "uniform_average", "median"], optional):
            Method to aggregate scores if Y is multi-output. Defaults to "median".

    Returns:
        Tuple[Union[pd.DataFrame, pd.Series], Union[pd.DataFrame, pd.Series]]:
            A tuple containing the regression coefficients and scores.

    Raises:
        ValueError: If X and Y have different numbers of rows.
        NotImplementedError: If an unknown aggregation method is provided.
    """
    if X.shape[0] != Y.shape[0]:
        raise ValueError(
            f"X and Y must have the same number of rows. "
            f"X has {X.shape[0]} rows, Y has {Y.shape[0]} rows."
        )

    coefs = _regression_coefs(X, Y)
    scores = _regression_scores(X, Y)

    if Y.ndim == 1:
        return coefs, scores

    # aggregation logic
    def _aggregate_data(data, method):
        if method == "uniform_average":
            return data.mean(axis=0)
        elif method == "median":
            return data.median(axis=0)
        elif method == "raw_values":
            return data
        else:
            raise NotImplementedError(f"Unknown multioutput value: {method}")

    coefs = _aggregate_data(coefs, multioutput_coefs)
    scores = _aggregate_data(scores, multioutput_scores)

    return coefs, scores


def _regression_coefs(
    X: pd.DataFrame, Y: Union[pd.DataFrame, pd.Series]
) -> Union[pd.DataFrame, pd.Series]:
    """
    Calculate the linear least squares regression coefficients given X and Y.

    The output is a pandas DataFrame if Y is a DataFrame (multitask),
    otherwise (single task) it is a Series.

    Args:
        X (pd.DataFrame):
            A pandas DataFrame representing the model functions.
        Y (Union[pd.DataFrame, pd.Series]):
            A pandas DataFrame or Series representing the spectra (or spectrum).

    Returns:
        Union[pd.DataFrame, pd.Series]:
            Concentrations values.
            Offset is included as the last element, with label 0.
    """
    lr = LinearRegression(fit_intercept=True).fit(X, Y)
    coefs = lr.coef_

    if coefs.ndim == 1:
        coefficients = pd.Series(data=coefs, index=X.columns)
        coefficients.loc[0] = lr.intercept_
    else:
        coefficients = pd.DataFrame(data=coefs, index=Y.columns, columns=X.columns)
        coefficients.loc[:, 0] = lr.intercept_
    return coefficients


def _regression_scores(
    X: pd.DataFrame,
    Y: Union[pd.DataFrame, pd.Series],
) -> Union[pd.DataFrame, pd.Series]:
    """
    Calculate regression scores, such as:
        - mse (mean squared error)
        - rmse (root mean squared error)
        - log-likelihood
        - R2 (coefficient of determination)
        - adjusted R2 (adjusted coefficient of determination)
        - AIC (Akaike information criterion)
        - BIC (Bayesian information criterion)
        - F-statistic
        - F-pvalue (p-value of the F-statistic)

    The output is a pandas DataFrame if Y is a DataFrame (multitask),
    otherwise (single task) it is a Series.

    Args:
        X (pd.DataFrame):
            A pandas DataFrame representing the model functions.
        Y (Union[pd.DataFrame, pd.Series]):
            A pandas DataFrame or Series representing the spectra (or spectrum).

    Returns:
        Union[pd.DataFrame, pd.Series]:
            Metric values
    """
    Xs = StandardScaler().fit_transform(X)
    Ys = GlobalScaler().fit_transform(Y)

    Xs = np.array(Xs)
    Ys = np.array(Ys)
    y_pred = LinearRegression().fit(Xs, Ys).predict(Xs)

    n = Xs.shape[0]  # Number of observations
    p = Xs.shape[1]  # Number of predictors
    residuals = Ys - y_pred
    llf = log_likelihood_metric(residuals=residuals)
    r2 = r2_metric(y_true=Ys, y_pred=y_pred)
    adj_r2 = adjusted_r2_metric(r2=r2, n=n, p=p)
    ss = spectrum_score_metric(y_true=Ys, y_pred=y_pred)
    fscore = f_statistics_metric(y_true=Ys, y_pred=y_pred, p=p)
    fpvalue = f_pvalue_metric(f_statistic=fscore, p=p, nobs=n)
    aic = aic_metric(residuals=residuals, n_features=p + 1)
    bic = bic_metric(residuals=residuals, n_features=p + 1)
    mse = np.mean(residuals ** 2, axis=0)
    rmse = np.sqrt(mse)

    results = {
        "rmse": rmse,
        "mse": mse,
        "log_likelihood": llf,
        "r2": r2,
        "adj_r2": adj_r2,
        "spectrum_score": ss,
        "F-statistic": fscore,
        "F-pvalue": fpvalue,
        "AIC": aic,
        "BIC": bic,
        "n_coefs": p,
    }

    if y_pred.ndim == 1:
        scores = pd.Series(data=results)
    else:
        scores = pd.DataFrame(
            data=results,
            index=Y.columns,
        )
    return scores
