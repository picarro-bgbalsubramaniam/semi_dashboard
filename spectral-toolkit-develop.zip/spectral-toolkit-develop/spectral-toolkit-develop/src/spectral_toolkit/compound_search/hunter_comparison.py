import pickle
import time
from ast import literal_eval
from concurrent.futures.process import ProcessPoolExecutor
from functools import cached_property
from itertools import repeat
from pathlib import Path
from typing import Dict, List

import click
import numpy as np
import pandas as pd
import plotly.express as px

from spectral_toolkit import compound_hunting as ch
from spectral_toolkit.compound_hunting import FRACTION
from spectral_toolkit.compound_search import r_cubed
from spectral_toolkit.compound_search.lasso_lars import train_lars
from spectral_toolkit.compound_search.performance_evaluation import (
    get_quartile_dispersion,
    pvalue_table,
    run_decision,
)
from spectral_toolkit.db_clients.mongo_spectral_library import (
    get_mongo_spectral_library_client,
)
from spectral_toolkit.logger import get_logger
from spectral_toolkit.model_function import mongodb as mdb
from spectral_toolkit.sat_utils.td_sat_utils import create_refit_plot

LOGGER = get_logger(__name__)

RESULTS_CSV = "generator.csv"
FOLDER_ID = "folder_id"
UNNAMED = "Unnamed: 0"
IGNORE_CIDS = [92831, 637513, 15133]
N_FITS = 15
M_FITS_START = 6
M_FITS_MAX = 6
MAX_CYCLES = 20
FRACTION = 0.9
K_FACTOR = 0
FOM_THRESH = 0.2
FOM_LEVEL = 0
R_CUBED_PRE = "r_cubed"
A_HUNT_PRE = "a_hunt"
LASSO_PRE = "lasso"
BASE_COLS = []
ACTUAL_CIDS = "actual_cids"
ACTUAL_CONCS = "actual_concs"
PREFIX_LIST = [R_CUBED_PRE, A_HUNT_PRE, LASSO_PRE]


def find_pre_cols(ext: str, columns):
    """This could be smarter for sure"""
    return [f"{pre}_{ext}" for pre in PREFIX_LIST if f"{pre}_{ext}" in columns]


def histo_plot(
    frame: pd.DataFrame, columns: List[str], title: str, x_col: str = "index"
):
    """
    Used for generic group histogram
    """
    fig = px.bar(
        frame,
        x=x_col,
        y=columns,
        opacity=0.9,
        # orientation="v",
        barmode="group",
        title=title,
    )
    return fig


class ResultsFrameWrapper:
    """
    Convenient place to store all operations we will want to perform with results
    """

    _frame = None

    def __init__(self, csv_path: str):
        """
        Args:
            csv_path: full path to summary csv output
        """
        self._frame = pd.read_csv(csv_path)

    @cached_property
    def frame(self):
        return self._frame

    @cached_property
    def lasso_results(self):
        return self.frame.filter(like=LASSO_PRE)

    @cached_property
    def a_hunt_results(self):
        return self.frame.filter(like=A_HUNT_PRE)

    @cached_property
    def r_cubed_results(self):
        return self.frame.filter(like=R_CUBED_PRE)

    @cached_property
    def total_runs(self):
        return len(self.frame.index)

    @cached_property
    def runs(self):
        return self.frame.index.to_list()

    @cached_property
    def incorrect_plot(self) -> px.histogram:
        cols = find_pre_cols("number_incorrect", self.frame.columns)
        return histo_plot(self.frame, cols, "Incorrect CID Number Found Bar Plot")

    @cached_property
    def correct_plot(self) -> px.histogram:
        cols = find_pre_cols("number_correct", self.frame.columns)
        return histo_plot(self.frame, cols, "Correct CID Number Found Bar Plot")

    @cached_property
    def missed_plot(self) -> px.histogram:
        cols = find_pre_cols("number_missed", self.frame.columns)
        return histo_plot(self.frame, cols, "Missed CID Number Bar Plot")

    @cached_property
    def duration_plot(self) -> px.histogram:
        cols = find_pre_cols("duration", self.frame.columns)
        return histo_plot(self.frame, cols, "Missed CID Number Bar Plot")

    def actual(self, run: int):
        """
        Get the actual cids and concentrations used in simulation
        """
        return dict(
            zip(
                literal_eval(self.frame.iloc[run][ACTUAL_CIDS]),
                literal_eval(self.frame.iloc[run][ACTUAL_CONCS]),
            )
        )


def summarize_data(actual_cids: List[int], fit_cids: List[int], prefix: str) -> Dict:
    """
    Find the correct, incorrect, and missed CIDS found
    Args:
        actual_cids: List of the actual cids in the dataset
        fit_cids: List of the cids found in fit hunter
        prefix: str prefix used for easy lookup in results frame
    Returns:
        Dictionary with fit prefix and correct, missed, incorrect, and found cids from actual
    """
    return_dict = {}
    actual = set(actual_cids)
    found = set(fit_cids)
    correct = list(actual.intersection(found))
    return_dict[f"{prefix}_correct"] = str(correct)
    return_dict[f"{prefix}_number_correct"] = len(correct)
    missed = list(actual - found)
    return_dict[f"{prefix}_missed"] = str(missed)
    return_dict[f"{prefix}_number_missed"] = len(missed)
    incorrect = list(found - actual)
    return_dict[f"{prefix}_incorrect"] = str(incorrect)
    return_dict[f"{prefix}_number_incorrect"] = len(incorrect)
    return_dict[f"{prefix}_found"] = str(fit_cids)
    return_dict[f"{prefix}_number_found"] = len(fit_cids)

    return return_dict


def produce_refit_plot(
    run_num: int,
    nus: np.ndarray,
    results_dir: Path,
    partial_fit: np.ndarray,
    error: np.ndarray,
    mfs_nu: Dict[int, np.ndarray],
    cids: List[int],
    prefix: str,
    actual_cids: List[int],
) -> Dict:
    """
    Write refit image to specified directory
    Args:
        run_num: dataset number
        nus: nu values,
        results_dir: base directory to write the results,
        partial_fit: partial fit of spectrum we tried to fit,
        error: error estimate (not well defined),
        mfs_nu: model functions with cid as key and evaluated spline,
        cids: list of cids we found,
        prefix: hunter prefix to prepend data/plot file name with,
        actual_cids: list of cids in original dataset,
    Returns:
        Dictionary with different meta data yet to be modeled as this is first version
    """
    try:
        temp_mfs = {k: mfs_nu[k] for k in cids}
        score, rmse, wrmse, fit, _ = ch.get_fit_info(temp_mfs, partial_fit, error)
        f_name = f"{prefix}_{run_num}.png"
        title = f"{run_num}_{prefix}_actual_{actual_cids}"
        refit_plot = create_refit_plot(
            nus, partial_fit, cids, score, rmse, wrmse, fit, temp_mfs, title
        )
        refit_plot.write_image(results_dir / f_name)
    except Exception as e:
        LOGGER.error(f"Unable to create refit plot {e}")


def single_iteration(
    run_num: int,
    base_path: Path,
    pickle_mfs_path: str,
    truth_frame: pd.DataFrame,
    run_r_cubed: bool,
    run_a_hunter: bool,
    run_lasso: bool,
    nominal_pressure: float,
    results_dir: str,
):
    """
    Wrapper for an individual dataset run so we can run concurrently
    Args:
        run_num: dataset number,
        base_path: path to dataset,
        pickle_mfs_path: path to pickle file with spline model function dict,
        truth_frame: generator.csv as dataframe with true values,
        run_r_cubed: run r cubed bool,
        run_a_hunter: run a hunter bool,
        run_lasso: run lasso bool,
        nominal_pressure: pnom,
        results_dir: path to store results,
    """
    if pickle_mfs_path:
        with open(pickle_mfs_path, "rb") as f:
            mfs = pickle.load(f)
    else:
        client = get_mongo_spectral_library_client()
        mfs = mdb.get_model_functions(client, nominal_pressure=nominal_pressure)
        client.client.close()

    # Remove ignore CIDS
    for cid in IGNORE_CIDS:
        try:
            del mfs[cid]
        except Exception as e:
            LOGGER.warning(f"Did not find cid {cid} in model functions, unable to delete {e}")
    dataset_str = str(run_num).zfill(9)
    full_path = base_path / dataset_str / f"{dataset_str}.parquet"
    spectral_df = pd.read_parquet(full_path)
    nus = spectral_df.columns.to_numpy(dtype="float")
    partial_fit = spectral_df.mean().to_numpy()
    mfs_nu = {k: v(list(nus)) for k, v in mfs.items()}

    truth_row = truth_frame.iloc[run_num]
    truth_dict = truth_row.drop(FOLDER_ID).drop(UNNAMED)[truth_row != 0].to_dict()

    results_dict = {"index": run_num}
    actual_cids = [int(k) for k in truth_dict.keys()]
    results_dict[ACTUAL_CIDS] = str(actual_cids)
    results_dict[ACTUAL_CONCS] = str([round(v, 5) for v in truth_dict.values()])

    # Replace this with real error
    error = np.ones(len(nus))

    produce_refit_plot(
        run_num,
        nus,
        results_dir,
        partial_fit,
        error,
        mfs_nu,
        actual_cids,
        "ORIGINAL",
        actual_cids,
    )

    if run_r_cubed:
        # Rella Hunter
        LOGGER.info(f"Starting R_CUBED for run {run_num}")
        start = time.time()
        RF, r_cubed_results = r_cubed.GottaFindEmAll(
            nus,
            partial_fit,
            mfs_nu,
            N_FITS,
            M_FITS_START,
            ignore_cids=IGNORE_CIDS,
            Mfits_max=M_FITS_MAX,
            max_cycles=MAX_CYCLES,
            ban_negatives=True,
            fraction=FRACTION,
            kfactor=K_FACTOR,
            fom_threshold=FOM_THRESH,
            fom_level=FOM_LEVEL,
            required_cids=[],
        )
        r_found_cids = r_cubed_results["cids_found"]
        LOGGER.info(f"R Cubed Hunter found {r_found_cids} for run {run_num}")
        results_dict[f"{R_CUBED_PRE}_duration"] = time.time() - start
        summary_dict = summarize_data(actual_cids, r_found_cids, R_CUBED_PRE)
        results_dict.update(summary_dict)

        r_cubed_path = results_dir / R_CUBED_PRE
        if not r_cubed_path.exists():
            r_cubed_path.mkdir(parents=True, exist_ok=True)

        r_cubed_file = r_cubed_path / f"{run_num}_{R_CUBED_PRE}.pickle"

        with open(r_cubed_file, "wb") as f:
            pickle.dump(
                {"rella_finder": RF, "results": r_cubed_results},
                f,
                protocol=pickle.HIGHEST_PROTOCOL,
            )

        produce_refit_plot(
            run_num,
            nus,
            results_dir,
            partial_fit,
            error,
            mfs_nu,
            r_found_cids,
            R_CUBED_PRE,
            actual_cids,
        )

    if run_a_hunter:
        # Adam Hunter
        LOGGER.info(f"Starting A Hunter for run {run_num}")
        start = time.time()
        error = np.ones(len(nus))
        found_cids, _, _, _, _, _ = ch.adams_hunt(mfs_nu, partial_fit, error)
        LOGGER.info(f"A Hunter found {found_cids} for run {run_num}")
        results_dict[f"{A_HUNT_PRE}_duration"] = time.time() - start
        summary_dict = summarize_data(actual_cids, found_cids, A_HUNT_PRE)
        results_dict.update(summary_dict)
        produce_refit_plot(
            run_num,
            nus,
            results_dir,
            partial_fit,
            error,
            mfs_nu,
            found_cids,
            A_HUNT_PRE,
            actual_cids,
        )

    if run_lasso:
        # Andrea Hunter
        LOGGER.info(f"Starting LassoCV for run {run_num}")
        start = time.time()
        dx = train_lars(pd.DataFrame(mfs_nu), spectral_df, n_jobs=1)
        pvalue_df = pvalue_table(dx)
        dispersion = get_quartile_dispersion(dx)
        decision_df = run_decision(pvalue_df, dispersion_measurement=dispersion)
        use_cids_df = decision_df.loc[decision_df["suggested_use"] == True]
        use_cids = use_cids_df.index.tolist()
        LOGGER.info(f"LASSO found {use_cids} for run {run_num}")
        results_dict[f"{LASSO_PRE}_duration"] = time.time() - start
        summary_dict = summarize_data(actual_cids, use_cids, LASSO_PRE)
        results_dict.update(summary_dict)
        produce_refit_plot(
            run_num,
            nus,
            results_dir,
            partial_fit,
            error,
            mfs_nu,
            use_cids,
            LASSO_PRE,
            actual_cids,
        )

    return results_dict


@click.command()
@click.option(
    "-p",
    "--base_path",
    help="Base Path to golden dataset (/Volumes/Data/spectral-generator/golden-dataset-1)",
    type=str,
)
@click.option(
    "-s",
    "--start_idx",
    help="Start Index for dataset to run",
    default=0,
    show_default=True,
)
@click.option(
    "-e", "--end_idx", help="End index for dataset to run", default=1, show_default=True
)
@click.option(
    "--run_r_cubed",
    is_flag=True,
    show_default=True,
    default=True,
    help="Run R Cubed Hunter.",
)
@click.option(
    "--run_a_hunter",
    is_flag=True,
    show_default=True,
    default=True,
    help="Run A Hunter.",
)
@click.option(
    "--run_lasso",
    is_flag=True,
    show_default=True,
    default=True,
    help="Run Lasso Hunter.",
)
@click.option(
    "--nominal_pressure", default=140, show_default=True, help="Nominal Pressure"
)
@click.option(
    "-m",
    "--pickle_mfs_path",
    default=None,
    help="If specified, will load a pickle file with model function splines",
)
@click.option(
    "-r",
    "--run_name",
    default=str(time.time()),
    help="Define a name for results directory",
)
@click.option(
    "-w", "--max_workers", default=4, help="Number of workers to use concurrently"
)
def run_comparison(
    base_path: Path,
    start_idx: int,
    end_idx: int,
    run_r_cubed: bool = True,
    run_a_hunter: bool = True,
    run_lasso: bool = True,
    nominal_pressure: float = 140,
    pickle_mfs_path: str = None,
    run_name: str = None,
    max_workers: int = 4,
):
    base_path = Path(base_path)
    truth_path = base_path / RESULTS_CSV
    truth_frame = pd.read_csv(truth_path)

    results_frame = pd.DataFrame()
    results_dir = Path(".").resolve() / run_name
    if not results_dir.exists():
        results_dir.mkdir(parents=True, exist_ok=True)

    # Run concurrently
    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        results = executor.map(
            single_iteration,
            list(range(start_idx, end_idx)),
            repeat(base_path),
            repeat(pickle_mfs_path),
            repeat(truth_frame),
            repeat(run_r_cubed),
            repeat(run_a_hunter),
            repeat(run_lasso),
            repeat(nominal_pressure),
            repeat(results_dir),
        )

        for result in results:
            results_frame = pd.concat((pd.DataFrame(result, index=[0]), results_frame))

        results_frame = results_frame.set_index("index").sort_index()
        results_frame.to_csv(results_dir / "hunting_summary.csv")


if __name__ == "__main__":
    run_comparison()
