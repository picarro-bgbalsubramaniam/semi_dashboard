import pandas as pd
from sklearn.feature_selection import SelectorMixin
from sklearn.linear_model import (
    MultiTaskLassoCV,
    LassoCV,
)
import numpy as np
from sklearn.base import BaseEstimator
from sklearn.model_selection import ShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.utils.validation import check_is_fitted

from spectral_toolkit.compound_search.global_scaler import GlobalScaler
from spectral_toolkit.logger import get_logger

LOGGER = get_logger(__name__)
SINGLE_TASK_ALPHAS = np.geomspace(0.1, 1.5, 30)
MULTI_TASK_ALPHAS = np.geomspace(0.5, 2, 30)
DEFAULT_CV = ShuffleSplit(n_splits=100, test_size=0.3)


class LassoTransformer(SelectorMixin, BaseEstimator):
    """
    A transformer that applies ``LassoCV`` or ``MultiTaskLassoCV`` for feature selection.

    This transformer first preprocesses the data by imputing NaN values and scaling.
    ``X`` is scaled using ``StandardScaler`` (by cid),
    and ``y`` is scaled using ``GlobalScaler``.
    Then, it fits a ``LassoCV`` or ``MultiTaskLassoCV``
    model to the data for feature selection.

    The alpha values for regularization impact the number of features selected,
    with larger values leading to stronger regularization (i.e., sparser solution
    with fewer cids selected, at the expenses of a worse fit),
    and smaller values leading to weaker regularization (i.e.,
    a more dense solution with more cids selected at the
    expenses of overfitting and increased risk of false-positives).

    Attributes:
        max_iter (int): Maximum number of iterations for the Lasso estimator.
        tol (float): The tolerance for the optimization.
        alphas (array-like, or None):
            List of alphas to consider for regularization.
            Larger values specify stronger regularization, i.e., returning
            less cids at the expenses of worse fit.
            Smaller values specify weaker regularization, i.e., returning
            more cids at the expenses of overfitting and increase
            risk of false-positives.
            If None (default), SINGLE_TASK_ALPHAS or MULTI_TASK_ALPHAS
            are assigned at runtime based on the task.
        cv:
            Cross-validation strategy in a scikit-learn compatible format.
            Defaults to ``ShuffleSplit(n_splits=100, test_size=0.3)``.
        n_jobs (int or None): Number of jobs to run in parallel.
        threshold (float): Threshold value for feature selection.
        dtype (data-type): Desired data-type for the inputs.
        nan_threshold (float): Threshold ratio of NaNs in y to raise an error.

    Methods:
        fit(X, y, **fit_params): Fits the Lasso model to the data.
        get_feature_names_out(): Returns the selected features.

    Attributes (after fit):
        feature_importances_ (np.ndarray): The feature importances.
        threshold_ (float): The threshold value for feature selection.
        feature_names_in_ (list[str]): The input feature names
    """

    def __init__(
        self,
        max_iter=300,
        tol=5e-3,
        alphas=None,
        cv=DEFAULT_CV,
        n_jobs=None,
        threshold=1e-5,
        dtype=np.float32,
        nan_threshold=0.1,
    ):
        """
        Initializes the LassoTransformer with specified parameters.
        """
        self.max_iter = max_iter
        self.tol = tol
        self.alphas = alphas
        self.cv = cv
        self.n_jobs = n_jobs
        self.threshold = threshold
        self.dtype = dtype
        self.nan_threshold = nan_threshold

    def _count_nans(self, y: np.ndarray) -> int:
        """
        Counts the number of NaN values in the target array and checks against the threshold.

        Parameters:
            y (np.ndarray): Target array.

        Returns:
            int: Number of NaN values in the target array.

        Raises:
            ValueError: If the ratio of NaNs in y exceeds the specified nan_threshold.
        """
        num_nans = np.isnan(y).sum()
        total = y.size
        ratio = num_nans / total
        if num_nans > 0:
            LOGGER.info(
                f"Found {num_nans} NaNs in y ({total} total values) amounting to {ratio:.1%}"
            )

        if ratio > self.nan_threshold:
            raise ValueError(
                f"NaNs in y exceed the threshold of {self.nan_threshold:.1%}"
            )
        return num_nans

    def _impute_nans(self, y: np.ndarray) -> np.ndarray:
        """
        Imputes NaN values in the target array using the mean of each mode (row).

        Parameters:
            y (np.ndarray): Target array with potential NaN values.

        Returns:
            np.ndarray: Target array with NaN values imputed.

        Raises:
            ValueError: If any mode (row) in y is completely NaN.
        """
        yc = y.copy()
        y_means = np.nanmean(yc, axis=1)  # mean of each mode

        if np.isnan(y_means).sum() > 0:
            raise ValueError(
                "Some modes are empty. Please drop them before fitting the model."
            )

        # replace NaNs with mean of mode
        idxs = np.where(np.isnan(yc))
        yc[idxs] = np.take(y_means, idxs[0])
        return yc

    def _manage_nans(self, X: pd.DataFrame, y):
        """
        Nan management for X and y.

        Multitask:
        - If nan < nan_threshold, impute
        - If nan > nan_threshold, raise ValueError

        Single task:
        - If nan < nan_threshold, drop mode
        - If nan > nan_threshold, raise ValueError

        Args:
            X (pd.DataFrame): Mode x cids
            y: Mode x time (or mode)

        Returns:
            X, y

        """
        num_nans = self._count_nans(y)

        if num_nans > 0:
            if y.ndim > 1 and y.shape[1] > 1:
                LOGGER.info(f"Imputing {num_nans} NaNs in y")
                y = self._impute_nans(y)
            else:
                LOGGER.info(f"Dropping {num_nans} NaNs in y (and X)")
                mask = ~np.isnan(y)
                y = y[mask]
                X = X.iloc[mask, :]

        return X, y

    def _scale(self, X, y):
        """
        Scales the feature matrix (X) and
        target array (y) using
        StandardScaler and GlobalScaler respectively.

        Parameters:
            X (np.ndarray): Feature matrix.
            y (np.ndarray): Target array.

        Returns:
            Tuple[pd.DataFrame, pd.DataFrame | pd.Series]: Scaled feature matrix and target array.
        """
        self.scaler_X_ = StandardScaler().set_output(transform="pandas")
        self.scaler_Y_ = GlobalScaler()
        return self.scaler_X_.fit_transform(X), self.scaler_Y_.fit_transform(y)

    def _preprocess(self, X, y):
        """
        Preprocesses the input data by handling NaNs, scaling, and validating data.

        Parameters:
            X (np.ndarray): Feature matrix.
            y (np.ndarray): Target array.

        Returns:
            Tuple[np.ndarray, np.ndarray]: Preprocessed feature matrix and target array.
        """
        Xc = X.copy()
        yc = y.copy()

        if isinstance(yc, pd.DataFrame) or isinstance(yc, pd.Series):
            yc = yc.values

        Xc, yc = self._manage_nans(Xc, yc)

        Xc.columns = Xc.columns.astype(str)

        Xc, yc = self._scale(Xc, yc)

        Xc, yc = self._validate_data(
            Xc, yc, accept_sparse=False, y_numeric=True, multi_output=True, reset=True
        )

        Xc = Xc.astype(self.dtype)
        yc = yc.astype(self.dtype)
        return Xc, yc

    def _get_estimator(self, y):
        """
        Selects and returns the appropriate Lasso estimator based on the shape of y.

        Parameters:
            y (np.ndarray): Target array.

        Returns:
            Estimator: Either a MultiTaskLassoCV or LassoCV estimator.
        """
        if y.ndim > 1 and y.shape[1] > 1:
            LOGGER.debug("Using MultiTaskLassoCV")
            estimator = MultiTaskLassoCV(
                max_iter=self.max_iter,
                tol=self.tol,
                alphas=self.alphas,
                cv=self.cv,
                n_jobs=self.n_jobs,
            )
        else:
            LOGGER.debug("Using LassoCV")
            estimator = LassoCV(
                max_iter=self.max_iter,
                tol=self.tol,
                alphas=self.alphas,
                cv=self.cv,
                n_jobs=self.n_jobs,
            )
        return estimator

    def _set_alphas(self, y):
        """
        Sets the alphas based on the shape of y.

        Parameters:
            y (np.ndarray): Target array.
        """
        if self.alphas is not None:
            return

        if y.ndim > 1 and y.shape[1] > 1:
            LOGGER.info("Using MULTI_TASK_ALPHAS")
            self.alphas = MULTI_TASK_ALPHAS
        else:
            LOGGER.info("Using SINGLE_TASK_ALPHAS")
            self.alphas = SINGLE_TASK_ALPHAS

    def fit(self, X: pd.DataFrame, y, **fit_params: dict):
        """
        Fits the Lasso model to the data after preprocessing.

        Parameters:
            X (pd.DataFrame): Feature matrix (mode x cids).
            y (pd.DataFrame | pd.Series): Target array (mode x time).
            fit_params (dict): Additional parameters for fitting.

        Returns:
            LassoTransformer: The instance itself.
        """
        Xc, yc = self._preprocess(X, y)
        self._set_alphas(yc)
        estimator = self._get_estimator(yc)
        self.X_ = Xc
        self.Y_ = yc
        self.estimator_ = estimator.fit(Xc, yc)
        self.threshold_ = self.threshold
        self.feature_importances_ = self._get_estimator_importance(estimator.coef_)
        return self

    def transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        """
        Transforms the feature matrix (X) based on the selected features.

        Parameters:
            X (pd.DataFrame): Feature matrix (mode x cids).

        Returns:
            pd.DataFrame:
               Relevant feature matrix
                (mode x selected cids).
        """
        check_is_fitted(self, "estimator_")
        return X.iloc[:, self.get_support()]

    def _get_support_mask(self) -> np.ndarray:
        """
        Computes and returns the support mask of selected features
        based on feature importances.

        Returns:
            np.ndarray: Boolean array indicating selected features.
        """
        check_is_fitted(self, "estimator_")
        return self.feature_importances_ > self.threshold_

    def _get_estimator_importance(self, coefs: np.ndarray):
        """
        Computes and returns the feature importances of the estimator
        based on the coefficients.
        If single task, returns the absolute value of the coefficients.
        If multi task, returns the L1 norm of the coefficients.

        Args:
            coefs (np.ndarray): Coefficients of the estimator.

        Returns:
            np.ndarray: Feature importances of the estimator.
        """
        if isinstance(self.estimator_, LassoCV):
            return np.abs(coefs)
        elif isinstance(self.estimator_, MultiTaskLassoCV):
            return np.linalg.norm(coefs, axis=0, ord=1)
        else:
            raise ValueError("Estimator must be either LassoCV or MultiTaskLassoCV")
