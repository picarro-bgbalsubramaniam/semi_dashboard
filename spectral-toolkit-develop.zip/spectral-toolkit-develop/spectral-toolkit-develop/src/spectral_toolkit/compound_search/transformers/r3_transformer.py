import pandas as pd
from sklearn.base import BaseEstimator
from sklearn.feature_selection import SelectorMixin
import numpy as np
from sklearn.utils.validation import column_or_1d

from spectral_toolkit.logger import get_logger

LOGGER = get_logger(__name__)
from spectral_toolkit.compound_search.r_cubed.basic import r_cubed_rev_2 as r2
from spectral_toolkit.compound_search.r_cubed.basic.r_cubed_rev_2 import (
    RCubedParameters,
)

DONT_FIT: list[int] = [280, 977, 947, 962, 297]
IF_DONT_USE: list[int] = [222, 280, 977, 947, 962, 297]


class R3Transformer(SelectorMixin, BaseEstimator):
    def __init__(
        self,
        name: str = "R3Transformer",
        kfactor: float = 2,
        fraction: float = 0.9,
        fom_threshold: float = 0.03,
        ban_negatives: bool = False,
        Nfits: int = 15,
        Mfits: int = 6,
        Lfits: int = 0,
        max_cycles: int = 12,
        num_close_compounds: int = 25,
        Q_threshold: float = 1.0,
        dont_fit: list[int] = DONT_FIT,
        nan_threshold=0.1,
    ):
        self.name = name
        self.kfactor = kfactor
        self.fraction = fraction
        self.fom_threshold = fom_threshold
        self.ban_negatives = ban_negatives
        self.Nfits = Nfits
        self.Mfits = Mfits
        self.Lfits = Lfits
        self.max_cycles = max_cycles
        self.num_close_compounds = num_close_compounds
        self.Q_threshold = Q_threshold
        self.dont_fit = dont_fit
        self.nan_threshold = nan_threshold

    def _check_dont_fit(self, X):
        is_present = np.isin(X.columns, self.dont_fit)

        if np.any(is_present):
            msg = (
                f"Found forbidden cids in X.columns: {X.columns[is_present]}. "
                f"Please remove all of {self.dont_fit} from "
                f"X.columns before fitting."
            )
            raise ValueError(msg)

    def fit(self, X, y):
        """A reference implementation of a fitting function for a transformer.

        Parameters
        ----------
        X : {array-like, sparse matrix}, shape (n_samples, n_features)
            The training input samples.

        y : array-like of shape (n_samples,) or (n_samples, n_targets)
            Target values. Will be cast to X's dtype if necessary.

        Returns
        -------
        self : object
            Returns self.
        """
        self._check_dont_fit(X)

        X, y = self._preprocess(X, y)

        mfs_nu = X.to_dict(orient="list")

        nu = X.index.values

        # Convert lists to numpy arrays
        mfs_nu = {int(k): np.array(v) for k, v in mfs_nu.items()}

        params = RCubedParameters(
            name=self.name,
            kfactor=self.kfactor,
            fraction=self.fraction,
            fom_threshold=self.fom_threshold,
            ban_negatives=self.ban_negatives,
            Nfits=self.Nfits,
            Mfits=self.Mfits,
            Lfits=self.Lfits,
            max_cycles=self.max_cycles,
            num_close_compounds=self.num_close_compounds,
            Q_threshold=self.Q_threshold,
        )

        hunting_results = r2.hunting_loop(mfs_nu, nu, y, [params], noise=None)

        table = hunting_results[0].summary_results
        table.index = table.index.astype(str)
        Q = table["Q"]

        cids = self.feature_names_in_
        # add all the cids that were not found from X.columns with value 0
        Q = Q.reindex(cids, fill_value=np.NaN)

        self.feature_importances_ = Q.values
        self.threshold_ = self.Q_threshold

        # Return the transformer
        return self

    def _get_support_mask(self):
        return self.feature_importances_ > self.threshold_

    def _manage_nans(self, X: pd.DataFrame, y):
        """
        Nan management for X and y.

        Single task:
        - If nan < nan_threshold, drop mode
        - If nan > nan_threshold, raise ValueError

        Args:
            X (pd.DataFrame): Mode x cids
            y: Mode x time (or mode)

        Returns:
            X, y

        """
        num_nans = self._count_nans(y)

        if num_nans > 0:
            LOGGER.info(f"Dropping {num_nans} NaNs in y (and X)")
            mask = ~np.isnan(y)
            y = y[mask]
            X = X.iloc[mask, :]

        return X, y

    def _count_nans(self, y: np.ndarray) -> int:
        """
        Counts the number of NaN values in the target array and checks against the threshold.

        Parameters:
            y (np.ndarray): Target array.

        Returns:
            int: Number of NaN values in the target array.

        Raises:
            ValueError: If the ratio of NaNs in y exceeds the specified nan_threshold.
        """
        num_nans = np.isnan(y).sum()
        total = y.size
        ratio = num_nans / total
        if num_nans > 0:
            LOGGER.info(
                f"Found {num_nans} NaNs in y ({total} total values) amounting to {ratio:.1%}"
            )

        if ratio > self.nan_threshold:
            raise ValueError(
                f"NaNs in y exceed the threshold of {self.nan_threshold:.1%}"
            )
        return num_nans

    def _preprocess(self, X, y):
        """
        Preprocesses the input data by handling NaNs, scaling, and validating data.

        Parameters:
            X (np.ndarray): Feature matrix.
            y (np.ndarray): Target array.

        Returns:
            Tuple[np.ndarray, np.ndarray]: Preprocessed feature matrix and target array.
        """
        Xc = X.copy()
        yc = y.copy()

        if isinstance(yc, pd.DataFrame) or isinstance(yc, pd.Series):
            yc = yc.values

        Xc, yc = self._manage_nans(Xc, yc)

        Xc.columns = Xc.columns.astype(str)

        _, yc = self._validate_data(
            Xc, yc, accept_sparse=False, y_numeric=True, multi_output=True, reset=True
        )

        if yc.ndim > 1 and yc.shape[1] > 1:
            LOGGER.info("y is a multi-output array. Average will be used.")
            yc = np.mean(yc, axis=1)
        yc = column_or_1d(yc, warn=True)

        return Xc, yc

    def transform(self, X: pd.DataFrame, y=None) -> pd.DataFrame:
        """
        Transforms the feature matrix (X) based on the selected features.

        Parameters:
            X (pd.DataFrame): Feature matrix (mode x cids).

        Returns:
            pd.DataFrame:
               Relevant feature matrix
                (mode x selected cids).
        """
        return X.iloc[:, self.get_support()]
