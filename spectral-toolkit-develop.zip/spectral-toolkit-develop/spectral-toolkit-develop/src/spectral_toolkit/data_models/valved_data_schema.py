from typing import List, Optional
from pydantic import BaseModel

from spectral_toolkit.data_models.rnd_schema import (
    basic_trigger_schema
)

class valve_schema(basic_trigger_schema):
    latency: Optional[int] = 0
    num_reference_periods: Optional[int] = 10
    valve_var: Optional[str] = 'MPVPosition'
    valve_data_flnm: Optional[str] = None

class Trigger(BaseModel):
    """
    Defines parameters to detect and
    manage clustering of similar concentration
    values.

    Attributes:
        min_step_duration: Min duration of a group in seconds
        max_step_duration: Max duration of a group in seconds
        min_spectral_points: Min number of occurrences in a group
        trim_start: Seconds to drop at the start of a group
        trim_end: Seconds to drop at the end of a group
        clustering_eps: eps for DBSCAN
        min_clustering_samples: min_samples for DBSCAN

    """

    min_step_duration: int = 60
    trim_start: int = 30
    trim_end: int = 10
    clustering_eps: float = 0.01
    min_clustering_samples: int = 5
    cluster_vars: Optional[List[str]] = []
    latency: Optional[int] = 0
   

    class Config:
        frozen = True