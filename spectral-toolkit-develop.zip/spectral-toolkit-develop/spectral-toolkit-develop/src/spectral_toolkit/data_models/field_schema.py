from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime
import pandas as pd

from pathlib import Path
from spectral_toolkit.constants.plotting_constants import Averaging
from spectral_toolkit.data_models.rnd_schema import (
    TVOC_KEY, 
    hunt_paths_schema
)

class paths_schema(hunt_paths_schema):
    wind_folder: Optional[Path] = None
    ri_mapping_flnm: Optional[Path] = None
    cid_mapping_flnm: Optional[Path] = None

    @property
    def wind_path(self):
        if self.wind_folder is not None:
            return self.exp_path / self.wind_folder
        else:
            return None

    @property
    def original_path(self):
        (Path(self.exp_folder) / self.original).mkdir(exist_ok = True)
        return Path(self.exp_folder) / self.original
    
class wind_schema(BaseModel):
    averaging: Optional[Averaging] = '5T'
    analysis_file_type: Optional[str] = 'orig'
