"""
Provides Overlapping Allan Deviation measures.
Largely based on the allantools
(https://allantools.readthedocs.io/en/latest/) package,
but with fixed `rate=1.0`, `data_type="freq"`,
and `taus="octave"`.
"""
from typing import Tuple

import numpy as np


def oadev(data: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Overlapping Allan deviation.

    .. math::

        \\sigma^2_{OADEV}(m\\tau_0) = { 1 \\over 2 (m \\tau_0 )^2 (N-2m) }
        \\sum_{n=1}^{N-2m} ( {x}_{n+2m} - 2x_{n+1m} + x_{n} )^2

    where :math:`\\sigma^2_x(m\\tau_0)` is the overlapping Allan
    deviation at an averaging time of :math:`\\tau=m\\tau_0`, and
    :math:`x_n` is the time-series of phase observations, spaced by the
    measurement interval :math:`\\tau_0`, with length :math:`N`.

    NIST [SP1065]_ eqn (11), page 16.

    Args:
        data (np.ndarray):
            Input data.

    Returns:
        Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
            taus (np.ndarray):
                Tau values for which td computed
            adev (np.ndarray):
                Computed oadev for each tau value
            adev_err (np.ndarray):
                oadev errors
            samples_num (np.ndarray):
                Values of N used in each oadev calculation

    """
    phase = _frequency2phase(data)
    taus_used = _tau_generator(phase)
    adev = np.zeros_like(taus_used)
    adev_err = np.zeros_like(taus_used)
    samples_num = np.zeros_like(taus_used)

    # stride=1 for overlapping ADEV
    for idx, mj in enumerate(taus_used):
        (adev[idx], adev_err[idx], samples_num[idx]) = _calc_adev_phase(phase, mj, 1)

    tau_final, adev_final, adev_err_final, samples_num_final = _remove_small_ns(
        taus_used, adev, adev_err, samples_num
    )

    return tau_final, adev_final, adev_err_final, samples_num_final


def _tau_generator(data: np.ndarray) -> np.ndarray:
    """
    Generates a tau-list ('octave').

    Args:
        data (np.ndarray):
            Initial data.

    Returns:
        np.ndarray:
            Cleaned up list of tau values
    """

    data_len = len(data)

    if data_len == 0:
        raise ValueError("Data array is empty")

    maxn = np.floor(np.log2(data_len))
    taus = np.logspace(0, int(maxn), int(maxn + 1), base=2.0)
    taus_valid = (taus < data_len) & (taus > 0)

    m = np.floor(taus[taus_valid])
    m = m[m != 0]  # m is tau in units of datapoints
    m = np.unique(m)  # remove duplicates and sort

    if len(m) == 0:
        raise UserWarning(
            "tau_generator: insufficient data points to generate tau list"
        )

    return m


def _frequency2phase(freqdata: np.ndarray) -> np.ndarray:
    """integrate fractional frequency data and output phase data

    Args:
        freqdata (np.ndarray):
            Data array of fractional frequency measurements (nondimensional)

    Returns:
    np.ndarray:
        Time integral of fractional frequency data, i.e. phase (time) data
        in units of seconds.
        For phase in units of radians, see phase2radians()

    """

    if len(freqdata) == 0:
        raise ValueError("freqdata is empty")

    # Erik Benkler (PTB): Subtract mean value before cumsum in order to
    # avoid precision issues when we have small frequency fluctuations on
    # a large average frequency
    freqdata = freqdata - np.nanmean(freqdata)
    phasedata = np.cumsum(freqdata)
    phasedata = np.insert(phasedata, 0, 0)
    # so that phase starts at zero and len(phase)=len(freq)+1 ??
    return phasedata


def _calc_adev_phase(
    phase: np.ndarray, mj: int, stride: int
) -> Tuple[float, float, int]:
    """
    Main algorithm for adev() (stride=mj) and oadev() (stride=1)

    see http://www.leapsecond.com/tools/adev_lib.c
    stride = mj for nonoverlapping allan deviation

    Args:
        phase (np.ndarray):
            Phase data in seconds.
        mj: int
            M index value for stride
        stride: int
            Size of stride

    Returns:
        (dev, deverr, n): tuple
            Array of computed values.

    Notes
    -----
    stride = mj for nonoverlapping Allan deviation
    stride = 1 for overlapping Allan deviation

    References
    ----------
    * http://en.wikipedia.org/wiki/Allan_variance
    * http://www.leapsecond.com/tools/adev_lib.c
    NIST [SP1065]_ eqn (7) and (11) page 16
    """
    mj = int(mj)
    stride = int(stride)
    d2 = phase[2 * mj :: stride]
    d1 = phase[1 * mj :: stride]
    d0 = phase[::stride]

    n = min(len(d0), len(d1), len(d2))

    if n == 0:
        RuntimeWarning(f"Data array length is too small: {len(phase)}.")
        return 0.0, 0.0, 1

    v_arr = d2[:n] - 2 * d1[:n] + d0[:n]
    s = np.sum(v_arr * v_arr)

    dev = np.sqrt(s / (2.0 * n)) / mj
    deverr = dev / np.sqrt(n)

    return dev, deverr, n


def _remove_small_ns(
    taus: np.ndarray, devs: np.ndarray, deverrs: np.ndarray, ns: np.ndarray
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Remove results with small number of samples.
    If n is small (==1), reject the result

    Args:
        taus: array
            List of tau values for which deviation were computed
        devs: array
            List of deviations
        deverrs: array or list of arrays
            List of estimated errors
        ns: array
            Number of samples for each point

    Returns:
        (taus, devs, deverrs, ns): tuple
            Identical to input, except that values with low ns have been removed.

    """
    check_len = len(taus)
    if not all(
        len(input_array) == check_len for input_array in [taus, devs, deverrs, ns]
    ):
        raise ValueError("_remove_small_ns: input arrays sizes not matching")

    ns_big_enough = ns > 1

    o_taus = taus[ns_big_enough]
    o_devs = devs[ns_big_enough]
    o_ns = ns[ns_big_enough]
    o_deverrs = deverrs[ns_big_enough]

    if len(o_devs) == 0:
        raise UserWarning("remove_small_ns: No data left")

    return o_taus, o_devs, o_deverrs, o_ns
