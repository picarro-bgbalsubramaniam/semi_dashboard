from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime
import pandas as pd
import numpy as np

from pathlib import Path

from spectral_toolkit.data_models.rnd_schema import (
    basic_paths_schema, 
    fitting_schema,
    TVOC_KEY,
    NA_THRESH
)


class paths_schema(basic_paths_schema):
    temperature_name: Optional[Path] = None
    ri_mapping_flnm: Optional[Path] = None
    cid_mapping_flnm: Optional[Path] = None
    misc_results: Optional[str] = 'Misc_results'
    average_spectra: Optional[str] = 'average'
    correlation_spectra: Optional[str] = 'correlation'
    big_peak_correlation: Optional[str] = 'big_peaks'
    manual_peak_correlation: Optional[str] = 'manual_peaks'

    @property
    def temperature_path(self):
        if self.temperature_name is not None:
            return Path(self.exp_folder) / self.temperature_name
        else:
            return None
        
    @property
    def runs_path(self):
        runs_path = self.output_path / 'runs'
        runs_path.mkdir(exist_ok=True)
        return runs_path
    
    @property
    def labeled_peaks_path(self):
        _path = self.output_path / 'labeled_peaks'
        _path.mkdir(exist_ok = True)
        return _path

    def run_data_path(self, run_subpath):
        _path = run_subpath / 'data'
        _path.mkdir(exist_ok = True)
        return _path

class event_schema(BaseModel):
    start: datetime
    end: datetime

class MFC_schema(BaseModel):
    flow_name: str
    MFC_name: str = None
    flow_value: float = None

class scaled_MFC_schema(MFC_schema):
    scale_factor: Optional[float] = 1

class precon_schema(BaseModel):
    trap_time_min: float = 20.0
    desorb_time_min: float = 2.0

class compounds_schema(BaseModel):
    compound_name: str
    concentration_ppm: float


class fit_var_schema(BaseModel):
    set: Optional[float] = None
    min: Optional[float] = None
    max: Optional[float] = None
    hold: Optional[float] = None

    # TODO: force logic on set vs hold


class fits_schema(BaseModel):
    variable_name: str
    cen: fit_var_schema = None
    sigma: fit_var_schema = None
    sigma_left: fit_var_schema = None
    sigma_right: fit_var_schema = None
    f_left: fit_var_schema = None
    f_right: fit_var_schema = None
    offset: fit_var_schema = None
    offset_slope: fit_var_schema = None


class interp_schema(BaseModel):
    variable_name: str
    cen: float = None
    sigma: float = None
    sigma_left: float = None
    sigma_right: float = None
    f_left: float = None
    f_right: float = None

class big_schema(BaseModel):
    pfi_threshold: Optional[float] = 100
    adjacent_points: Optional[int] = 110
    max_width: Optional[float] = 70
    prominence: Optional[float] = 1.0
    distance: Optional[float] = 8.0
    # height: Optional[float] = 5.0
    na_thresh: Optional[float] = NA_THRESH
    corr_key: Optional[str] = TVOC_KEY


class find_peaks_schema(BaseModel):
    height: Optional[float] = None
    threshold: Optional[float] = None
    distance: Optional[float] = 5
    prominence: Optional[float] = 0.1
    width: Optional[float] = 6
    wlen: Optional[float] = None
    rel_height: Optional[float] = 0.3
    plateau_size: Optional[float] = None

class color_schema(BaseModel):
    name: str
    min: Optional[float] = -np.inf
    max: Optional[float] = np.inf

class Q_threshold_schema(BaseModel):
    transformer: Optional[float] = 1.0
    color_list: List[color_schema]
    retention_index_window_width: Optional[int] = 60
    spectral_threshold: Optional[float] = 0.1

class td_analysis_schema(BaseModel):
    baseline_duration_min: Optional[float] = 5
    ignore_start_min: Optional[float] = 0
    auto_peak_finding: Optional[bool] = True
    left_shoulder_support_s: Optional[float] = 15
    peak_finding: find_peaks_schema
    overwrite: Optional[bool] = True
    num_ids_to_print: Optional[int] = 2
    Q_threshold: Q_threshold_schema
    retention_index_window_width: Optional[float] = 60
    spectral_threshold: Optional[float] = 0.1

    @property
    def baseline_duration(self):
        return pd.Timedelta(self.baseline_duration_min, 'min')
    
    @property
    def ignore_start(self):
        return pd.Timedelta(self.ignore_start_min, 'min')
    
    @property
    def left_shoulder_support(self):
        return pd.Timedelta(self.left_shoulder_support_s, 's')
    
    @property
    def Q_threshold_dict(self):
        _dict = {}
        for color_obj in self.Q_threshold.color_list:
            _dict.update({color_obj.name: (color_obj.min, color_obj.max)})
        return _dict
    
class run_refit_schema(BaseModel):
    start: datetime
    refitting_cids: List[int]

class multi_run_fitting_schema(fitting_schema):
    run_refitting_cids: Optional[List[run_refit_schema]] = []

    def get_refit_cids(self, run_start):
        for refit_obj in self.run_refitting_cids:
            if refit_obj.start == run_start:
                return refit_obj.refitting_cids
        return None