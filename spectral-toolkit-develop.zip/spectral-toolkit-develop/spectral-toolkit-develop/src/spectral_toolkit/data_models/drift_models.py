from __future__ import annotations
from typing import List, Optional, TypeVar
import os
from pydantic import BaseModel

from pathlib import Path

from spectral_toolkit.data_models.rnd_schema import (
    main_schema,
    basic_paths_schema,
    times_schema,
    event_timing,
)
from spectral_toolkit.data_models.basic_timeseries_schema import (
    var_schema,
)

from spectral_toolkit.data_models.valved_data_schema import (
    valve_schema,
    Trigger,
)

from spectral_toolkit.data_models.drift_schema import compound_basics_schema, drift_schema

from spectral_toolkit.data_models.td_schema import scaled_MFC_schema


class configYaml(BaseModel):
    main: main_schema
    paths: basic_paths_schema
    times: times_schema
    data_to_drop: Optional[List[event_timing]] = None
    variables: var_schema
    MFCs: List[scaled_MFC_schema]
    steps: Trigger
    cluster_stats: Trigger
    compounds: List[compound_basics_schema]
    coarse_cluster_stats: Trigger
    drift: drift_schema

    @property
    def flow_names(self):
        flow_names = []
        for mfc_obj in self.MFCs:
            flow_names.append(mfc_obj.flow_name)
        return flow_names

    @property
    def mfc_names(self):
        mfc_names = []
        for mfc_obj in self.MFCs:
            mfc_names.append(mfc_obj.MFC_name)
        return mfc_names
    
    @property
    def compound_cids(self):
        compound_cids = []
        for compound_obj in self.compounds:
            compound_cids.append(compound_obj.cid)
        return compound_cids

    @property
    def compound_names(self):
        compound_names = []
        for compound_obj in self.compounds:
            compound_names.append(compound_obj.name)
        return compound_names

    @property
    def cid_dict(self):
        cid_dict = {}
        for compound_obj in self.compounds:
            cid_dict.update({
                compound_obj.cid: {
                    'unit': compound_obj.unit,
                    'name': compound_obj.name
                }
            })
        return cid_dict

    
    def get_mfc_obj_from_flow_name(self, flow_name):
        for mfc_obj in self.MFCs:
            if mfc_obj.flow_name == flow_name:
                return mfc_obj
        return None
    
    def get_mfc_obj_from_mfc_name(self, mfc_name):
        for mfc_obj in self.MFCs:
            if mfc_obj.MFC_name == mfc_name:
                return mfc_obj
        return None

    def get_mfc_name_from_flow_name(self, flow_name):
        mfc_obj = self.get_mfc_obj_from_flow_name(flow_name)
        if mfc_obj is not None:
            return mfc_obj.MFC_name
        else:
            return None

    def get_flow_name_from_mfc_name(self, mfc_name):
        mfc_obj = self.get_mfc_obj_from_mfc_name(mfc_name)
        if mfc_obj is not None:
            return mfc_obj.flow_name
        else:
            return None

    def mfc_scaling_factor_from_mfc_name(self, mfc_name):
        mfc_obj = self.get_mfc_obj_from_mfc_name(mfc_name)
        if mfc_obj is not None:
            return mfc_obj.scale_factor
        else:
            return None

    def mfc_scaling_factor_from_flow_name(self, flow_name):
        mfc_obj = self.get_mfc_obj_from_flow_name(flow_name)
        if mfc_obj is not None:
            return mfc_obj.scale_factor
        else:
            return None
    
   