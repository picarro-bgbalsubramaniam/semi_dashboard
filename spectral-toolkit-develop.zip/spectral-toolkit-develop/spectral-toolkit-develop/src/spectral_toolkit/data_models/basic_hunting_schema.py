from typing import Optional

from pathlib import Path
from spectral_toolkit.data_models.rnd_schema import basic_paths_schema, event_timing

class manual_event_timing(event_timing):
    corrections: bool = False
    averages: bool = False