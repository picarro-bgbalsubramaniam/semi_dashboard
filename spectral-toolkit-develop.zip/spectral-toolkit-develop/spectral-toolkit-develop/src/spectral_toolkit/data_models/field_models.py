from __future__ import annotations
from typing import List, Optional, TypeVar
import os
from pydantic import BaseModel
from datetime import datetime
import re

from pathlib import Path

from spectral_toolkit.data_models.field_schema import (
    wind_schema,
    paths_schema
)
from spectral_toolkit.data_models.drift_schema import compound_basics_schema, drift_schema
from spectral_toolkit.data_models.basic_timeseries_schema import var_schema
from spectral_toolkit.data_models.rnd_schema import (
    main_schema,
    times_schema,
    event_timing,
    BIG3,
    fitting_schema,
    windowing_schema,
    big_schema,
    basic_hunting_schema,
    basic_peak_definition_schema
)
from spectral_toolkit.data_models.basic_hunting_schema import (
    manual_event_timing
)
from spectral_toolkit.data_models.valved_data_schema import (
    valve_schema,
    Trigger,
)

class configYaml(BaseModel):
    main: main_schema
    paths: paths_schema
    times: times_schema
    valve_info: valve_schema
    wind: wind_schema
    fitting: fitting_schema
    average_spectra: windowing_schema
    correlation_spectra: windowing_schema
    big_peak_correlations: big_schema
    manual_peaks: Optional[List[manual_event_timing]] = None
    manual_peak_correlations: Optional[basic_peak_definition_schema] = None
    data_to_drop: Optional[List[event_timing]] = None
    variables: var_schema
    steps: Trigger
    hunting: basic_hunting_schema
    drift: Optional[drift_schema] = None
    compounds: Optional[List[compound_basics_schema]] = None


    @property    
    def peaks_folder_list(self):
        folder_list = []
        for peak_obj in self.hunting.peaks:
            folder_list.append(peak_obj.folder)
        return folder_list

    @property
    def vars_to_keep_list(self):
        single_vars_list = [
            self.valve_info.valve_var,
            self.correlation_spectra.corr_key,
            self.big_peak_correlations.corr_key,
            self.manual_peak_correlations.corr_key,
            self.variables.tvoc_var,
        ]
        
        all_vars_set = set(single_vars_list) | set(self.variables.vars_to_save) | set(self.variables.controls) | set(self.variables.alkanes) | set(BIG3)

        return list(all_vars_set)
    

    @property
    def compound_cids(self):
        compound_cids = []
        for compound_obj in self.compounds:
            compound_cids.append(compound_obj.cid)
        return compound_cids

    @property
    def compound_names(self):
        compound_names = []
        for compound_obj in self.compounds:
            compound_names.append(compound_obj.name)
        return compound_names
    
    @property
    def cid_dict(self):
        cid_dict = {}
        for compound_obj in self.compounds:
            cid_dict.update({
                compound_obj.cid: {
                    'unit': compound_obj.unit,
                    'name': compound_obj.name
                }
            })
        return cid_dict