from __future__ import annotations
from typing import List, Optional, TypeVar
import os
from pydantic import BaseModel

from pathlib import Path

from spectral_toolkit.data_models.basic_timeseries_schema import (
    var_schema,
)

from spectral_toolkit.data_models.rnd_schema import (
    main_schema,
    basic_paths_schema,
    times_schema,
    event_timing,
)

class configYaml(BaseModel):
    main: main_schema
    paths: basic_paths_schema
    times: times_schema
    data_to_drop: Optional[List[event_timing]] = None
    variables: var_schema
   