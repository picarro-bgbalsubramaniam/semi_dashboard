from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime
import pandas as pd

from pathlib import Path
from spectral_toolkit.constants.plotting_constants import Averaging

from spectral_toolkit.data_models.rnd_schema import TVOC_KEY
  
class var_schema(BaseModel):
    vars_to_save: Optional[List[str]]
    report_time_average: Optional[Averaging] = '100S'
    diurnal_average_min: Optional[float] = 10
    tvoc_var: Optional[str] = TVOC_KEY
    controls: Optional[list[str]] = [
        "CavityTemp",
        "EtalonTemp",
        "HotBoxHeatsinkTemp",
        "Laser1Temp",
        "Laser3Temp",
        "Laser4Temp",
        "WarmBoxTemp",
        "AmbientPressure",
        "CavityPressure",
        "cavityPressureStd",
        "OutletValve",
        "ValveMask",
        "MPVPosition"
    ]
    # alkanes: Optional[list[str]] = [
    #     'ethane',
    #     'propane',
    #     'butane'
    # ]