import warnings
from functools import cached_property
from os import PathLike
from pathlib import Path
import yaml
from datetime import datetime

import numpy as np
import pandas as pd
import voc_fitter.model.gas_sample
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
    field_serializer,
)
from typing import List, Dict, Optional, Union

from pydantic_core.core_schema import FieldValidationInfo
from typing_extensions import Self

from spectral_toolkit.logger import get_logger

LOGGER = get_logger(__name__)

DEFAULT_F_TRACKING = 6056.504
DEFAULT_BASELINE_UNCERTAINTIES = {-1: 10.0, 0: 10.0, 222: 5.0}
DEFAULT_UNCERTAINTY = 1.0
MISSING_GAS_KEY = -999


class InstrumentConfig(BaseModel):
    """
    Instrument Model, specific to each instrument,
    it contains information that is needed for the scheme optimizer.

    The corresponding yaml file is located in the config directory
    of each analyzer /I2000/InstrConfig/Config/OptimizedScheme

    Attributes:
        serial_number (str): name of instrument (i.e. NUV1047)
        baseline_set (List[float]): list of baseline polynomial coefficients
        fsr (float): free spectral range of cavity
        laser_gaps (Optional[List]): Ranges in [hi, low] list of gaps to avoid
        nu_min_analyzer (int): min nu value for evaluation/range of laser
        nu_max_analyzer (int): max nu value for evaluation/range of laser
        nuc_baseline (float): nu center for baseline polynomial evaluation
        shot_to_shot (float): shot to shot noise of instrument
    """

    serial_number: str
    baseline_set: List[float]
    fsr: float
    laser_gaps: Optional[List] = Field(default_factory=list)
    nu_min_analyzer: int = 5850
    nu_max_analyzer: int = 6210
    nuc_baseline: float = 6056.5
    shot_to_shot: Union[float, pd.Series] = 0.00023

    model_config = ConfigDict(
        frozen=True,
        arbitrary_types_allowed=True,
    )

    @classmethod
    def from_yaml(cls, filename: Union[str, PathLike]) -> "InstrumentConfig":
        if not Path(filename).exists():
            raise FileNotFoundError(f"Could not find {filename}")

        LOGGER.info(f"Parsing instrument config file: {filename}")
        with open(filename, "r") as f:
            dict_in = yaml.safe_load(f)

        return cls.model_validate(dict_in)

    @field_validator("shot_to_shot", mode="before")
    def load_shot_to_shot_if_file(cls, v):
        if isinstance(v, (str, PathLike)):
            file_path = Path(v)
            if not file_path.is_file():
                raise FileNotFoundError(f"Could not find shot-to-shot file at {v}")

            mode_col = "modeidx"
            s2s_col = "s2s"

            try:
                v = pd.read_csv(
                    v,
                    header=0,
                    dtype={s2s_col: float, mode_col: int},
                    sep=",",
                    index_col=mode_col,
                    usecols=[mode_col, s2s_col],
                )[s2s_col]
            except Exception as err:
                raise ValueError(f"Could not read shot-to-shot file at {v}: {err}")

        return v

    @field_serializer("shot_to_shot")
    def serialize_shot_to_shot(self, v, _info):
        return v.to_dict() if isinstance(v, pd.Series) else v


class ApplicationConfig(BaseModel):
    """
    Application-specific configuration
    for scheme optimizer

    Attributes:
        application_name (str): Name of application
        comment (str): User supplied comment
        f_tracking (float): The reference frequency
        default_uncertainty (float):
            Desired precision level for cids that are not
            specified in `target_uncertainties`, expressed as
            a fraction of the full mode list precision.
            Please see `target_uncertainties` for more details.
        gas_list: list of cids to optimize scheme for
        target_uncertainties (Dict[int, float]):
            Desired precision for specified cid, expressed as a
            fraction of the full mode list precision.
            Example, 180: 1.0 will attempt for CID 180 to match the
            same precision we would achieve by using all the modes available.
            Lower values will increase the "attention" for a CID:
            i.e., a cid with target_uncertainty of 10 will have
            ten times less attention in a least squares sense than
            a cid with target_uncertainty of 1)
        cavity_pressure (float):
            Pressure cavity will operate at in Torr
        min_spacing (int):
            minimum spacing between modes (in wavenumbers) before a penalty is incurred;
            penalty is proportional to the size of the gap in wavenumbers multipled by min_spacing_penalty
            Typical is 3 wavenumbers
        min_spacing_penalty (float):
            scaling factor to convert frequency gaps in wavenumbers to min_spacing penalties.
            Set to 1.0 to strongly discourage gaps.
            Set to a smaller number to more weakly discourage gaps.
        min_loss (float): used in creating the empirical compound from voc_fitter
        nu_pad_grid (float): padding when creating the grid to place points on
        nu_pad_gas (float): nu padding when creating gas sample
        points_in_scheme (int): Points to allocate in scheme
        spread_points (int):
            Number of dwells where the improvement in precision for an
            isolated sharp line is roughly balanced by the spread points penalty.
            The spread_points calculation follows the rough scaling law in
            which the incremental improvement in the
            precision of an isolated, sharp line (1 over twice number of dwells to the 3/2 power)
            is balanced by
            the incremental quadratic spread_points penalty
            (which is proportional to twice the number of dwells).
            This means that the penalty should be proportional
            to 1 / (4*spread_points^5/2).
            A value for spread_points of 10 - 100 is usually a good choice,
            with 25 being recommended.
        use_full_span (bool): Require full use of laser nu_ranges
        temperature (float): Temperature in degrees C of cavity operation
        nu_min_model_functions (float): minimum nu value measured in model function
        nu_max_model_functions (float): maximum nu value measured in model function
        version (int): version
    """

    application_name: str = Field(default="spectral-toolkit-application")
    comment: str = Field(default="")
    f_tracking: float = DEFAULT_F_TRACKING
    default_uncertainty: float = Field(default=DEFAULT_UNCERTAINTY, gt=0)
    gas_list: List[int]
    target_uncertainties: Optional[Dict[int, float]] = Field(
        default_factory=dict, validate_default=True
    )
    cavity_pressure: float = 450.0
    min_spacing: int = 3
    min_spacing_penalty: float = 1.0
    min_loss: float = 0.2
    nu_pad_grid: float = 0.02
    nu_pad_gas: float = 0.5
    points_in_scheme: int = 400
    spread_points: int = 25
    use_full_span: bool = True
    temperature: float = 80.0
    nu_min_model_functions: int = 5815
    nu_max_model_functions: int = 6210
    version: int = 1

    @field_validator("target_uncertainties", mode="after")
    def fill_target_uncertainties(cls, target_uncertainties, info: FieldValidationInfo):
        """Ensures all gases have a target uncertainty value, filling with defaults as necessary."""
        merged_uncertainties = {
            **DEFAULT_BASELINE_UNCERTAINTIES,
            **target_uncertainties,
        }

        if MISSING_GAS_KEY in merged_uncertainties:
            msg = (
                f"Using {MISSING_GAS_KEY} as a key in `target_uncertainties` is deprecated. "
                f"If you want to provide a default uncertainty for gases, "
                f"please use the `default_uncertainty` parameter of ApplicationConfig. "
                f"The key {MISSING_GAS_KEY} will be ignored."
            )
            warnings.warn(
                msg,
                DeprecationWarning,
                stacklevel=1,
            )
            LOGGER.warning(msg)
            del merged_uncertainties[MISSING_GAS_KEY]

        gas_list = info.data.get("gas_list", [])

        for gas in gas_list:
            merged_uncertainties[gas] = merged_uncertainties.get(
                gas, info.data["default_uncertainty"]
            )

        # drop any gases that are not in the gas list (and baseline 0, -1 terms)
        unused_gases = set(merged_uncertainties.keys()) - set(gas_list) - {0, -1}
        for unused in unused_gases:
            del merged_uncertainties[unused]
            LOGGER.info(f"Removed unused gas {unused} from target uncertainties")

        return merged_uncertainties

    @classmethod
    def from_yaml(cls, filename: Union[str, PathLike]) -> "ApplicationConfig":
        if not Path(filename).exists():
            raise FileNotFoundError(f"Could not find {filename}")

        LOGGER.info(f"Parsing application config file: {filename}")
        with open(filename, "r") as f:
            dict_in = yaml.safe_load(f)

        return cls.model_validate(dict_in)


class SchemeConfiguration(BaseModel):
    """
    Configuration containing all metadata
    needed for scheme optimizer

    Attributes:
        name (str): User supplied name for configuration.
        time_created (str): time of configuration creation in "YYYYMMDD"
        created_by (str): Person who created configuration
        forbidden_regions (np.ndarray):
            Forbidden regions in [hi, low] list of ranges to avoid.
            Forbidden regions are specified in wavenumbers.
            If a string or path is provided, it will be loaded from a file
            using np.loadtxt.
        max_iterations (int): maximum number of iterations
        instrument_config (InstrumentConfig):
            Instrument specific configuration.
            If a string or path is provided, it will be loaded from a file
            using InstrumentConfig.from_yaml.
        application_config (ApplicationConfig):
            Application specific configuration.
            If a string or path is provided, it will be loaded from a file
            using ApplicationConfig.from_yaml.
        allowed_modes (np.ndarray):
            Modes available for use in scheme.
            If a string or path is provided, it will be loaded from a file
            using np.loadtxt.
            Can be found on the instrument in
            /I2000/InstrConfig/Config/OptimizedScheme/SelectFromModesList.txt
        tvoc_cal_cids (list[int]):
            Cids to be used in the calculation of tvoc_cal, defaults to [3776]
    """

    model_config = ConfigDict(
        ignored_types=(cached_property,),
        frozen=True,
        arbitrary_types_allowed=True,
        extra="allow",
    )

    name: str = Field(default="spectral-toolkit-scheme")
    time_created: str = Field(
        default_factory=lambda: datetime.utcnow().isoformat() + "Z"
    )
    created_by: str = Field(default="spectral-toolkit")
    forbidden_regions: np.ndarray
    instrument_config: InstrumentConfig
    application_config: ApplicationConfig
    allowed_modes: Optional[np.ndarray] = Field(default_factory=lambda: np.array([]))
    max_iterations: int = 500
    tvoc_cal_cids: list[int] = Field(default_factory=lambda: [3776])

    @model_validator(mode="before")
    def parse_filenames(cls, values):
        """Maintain backwards compatibility with old yaml files"""
        if "forbidden_regions_file" in values:
            values["forbidden_regions"] = values["forbidden_regions_file"]

        if "instrument_config_file" in values:
            values["instrument_config"] = values["instrument_config_file"]

        if "application_config_file" in values:
            values["application_config"] = values["application_config_file"]

        if "allowed_modes_file" in values:
            values["allowed_modes"] = values["allowed_modes_file"]

        return values

    @classmethod
    def from_yaml(cls, filename: Union[str, PathLike]) -> "SchemeConfiguration":
        if not Path(filename).exists():
            raise FileNotFoundError(f"Could not find {filename}")

        LOGGER.info(f"Parsing scheme config file: {filename}")
        with open(filename, "r") as f:
            dict_in = yaml.safe_load(f)
        return cls.model_validate(dict_in)

    @field_validator("instrument_config", mode="before")
    def load_instrument_cfg_if_yaml(cls, v):
        if isinstance(v, (str, PathLike)):
            v = InstrumentConfig.from_yaml(v)
        return v

    @field_validator("application_config", mode="before")
    def load_application_cfg_if_yaml(cls, v):
        if isinstance(v, (str, PathLike)):
            v = ApplicationConfig.from_yaml(v)
        return v

    @field_validator("forbidden_regions", mode="before")
    def load_forbidden_regions_if_file(cls, v):
        if isinstance(v, (str, PathLike)):
            file_path = Path(v)
            if not file_path.is_file():
                raise FileNotFoundError(f"Could not find forbidden regions file at {v}")
            v = np.loadtxt(file_path, skiprows=1)
        return v

    @field_validator("allowed_modes", mode="before")
    def load_allowed_modes_if_file(cls, v):
        if isinstance(v, (str, PathLike)):
            file_path = Path(v)
            if not file_path.is_file():
                raise FileNotFoundError(f"Could not find allowed modes file at {v}")
            v = np.loadtxt(file_path, skiprows=0)
        return v

    @model_validator(mode="after")
    def validate_allowed_modes_and_s2s(self) -> Self:
        """
        Validate that the allowed modes are present in the shot-to-shot noise file,
        if the shot-to-shot noise file is present.
        """

        if isinstance(self.instrument_config.shot_to_shot, pd.Series):
            if len(self.allowed_modes) == 0:
                raise ValueError(
                    "Allowed modes are not set, but shot-to-shot noise file is. "
                    "Please set allowed modes or remove shot-to-shot noise file "
                    "using a scalar value instead."
                )

            missing_modes = set(self.allowed_modes.astype(int)) - set(
                self.instrument_config.shot_to_shot.index
            )
            if missing_modes:
                raise ValueError(
                    f"Some allowed modes are not in the shot-to-shot noise file. "
                    f"Please make sure to populate the shot-to-shot noise file with "
                    f"the following modes: {missing_modes}"
                )
        return self

    @cached_property
    def nu_range(self):
        """
        Produce the nu range which is inside of model function data range
        """
        if (
            self.instrument_config.nu_min_analyzer
            < self.application_config.nu_min_model_functions
        ):
            LOGGER.warning(
                f"Minimum laser freq (nu_range_min = {self.instrument_config.nu_min_analyzer:.1f}) is smaller "
                f"than minimum model function frequency (nu_min_mf = {self.application_config.nu_min_model_functions:.1f}). "
                f"Setting nu_range_min = {self.application_config.nu_min_model_functions:.1f}"
            )
            nu_min = self.application_config.nu_min_model_functions
        else:
            nu_min = self.instrument_config.nu_min_analyzer

        if (
            self.instrument_config.nu_max_analyzer
            > self.application_config.nu_max_model_functions
        ):
            LOGGER.warning(
                f"Maximum laser freq (nu_range_max = {self.instrument_config.nu_max_analyzer:.1f}) is greater "
                f"than maximum model function frequency (nu_max_mf = {self.application_config.nu_max_model_functions:.1f}). "
                f"Using nu_range_max = {self.application_config.nu_max_model_functions:.1f}"
            )
            nu_max = self.application_config.nu_max_model_functions
        else:
            nu_max = self.instrument_config.nu_max_analyzer

        return [nu_min, nu_max]


class OptimizerConstants(BaseModel):
    """
    These are properties that get reused while maintaing values in iterative algorithm
    """

    model_config = ConfigDict(arbitrary_types_allowed=True, frozen=True)

    cid_list: List[int]
    measurement_noise: np.ndarray
    target_noise: np.ndarray
    allowed_wavenumbers: np.ndarray
    model_functions: List[np.ndarray]
    gas_sample: voc_fitter.model.gas_sample.GasSample
    reference_performance: pd.Series
    nu_span_min: float
    min_spacing: int
    min_spacing_penalty: float
    spread_points: int
    pubchem_df: pd.DataFrame
