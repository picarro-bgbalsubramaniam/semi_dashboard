from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime
import pandas as pd
import numpy as np

from pathlib import Path

TVOC_KEY = 'partial_fit_integral'
BIG3 = ['CO2', 'CH4', 'H2O', 'CO2_VOC', 'CH4_VOC', 'H2O_VOC']
NA_THRESH = 0.03

class main_schema(BaseModel):
    time_zone: Optional[str] = 'US/Pacific'
    fitter_name: Optional[str] = 'broadband'

class basic_paths_schema(BaseModel):
    exp_folder: Path
    zarr_name: str
    output_suffix: Optional[str] = None
    original: Optional[str] = 'output'

    @property
    def temp_path(self):
        temp_path = Path(self.exp_folder)/ 'temp_data'
        temp_path.mkdir(exist_ok = True)
        return temp_path
    
    @property
    def exp_path(self):
        return Path(self.exp_folder)
    
    @property
    def combo_path(self):
        return Path(self.exp_folder) / 'combo'
    
    @property
    def private_path(self):
        return Path(self.exp_folder) / 'private'
    
    @property
    def rdf_path(self):
        return Path(self.exp_path) / 'RDF'
    
    @property
    def output_path(self):
        if self.output_suffix is None:
            output_path = Path(self.exp_folder) / 'output'
        else:
            output_path = Path(self.exp_folder) / f'output {self.output_suffix}'
        output_path.mkdir(exist_ok=True)
        return output_path

    @property
    def original_figures_path(self):
        figures_path = Path(self.original_path) / 'figures'
        figures_path.mkdir(exist_ok=True)
        return figures_path

    @property
    def figures_path(self):
        figures_path = Path(self.output_path) / 'figures'
        figures_path.mkdir(exist_ok=True)
        return figures_path
    
    @property
    def zarr_path(self):
        return Path(self.exp_folder) / self.zarr_name
    
    @property
    def original_path(self):
        original_path = Path(self.exp_folder) / self.original
        original_path.mkdir(exist_ok=True)
        return original_path
    
class hunt_paths_schema(basic_paths_schema):
    misc_results: Optional[str] = 'Misc_results'

    @property
    def misc_path(self):
        misc_path = Path(self.exp_path) / self.misc_results
        misc_path.mkdir(exist_ok=True)
        return misc_path
    
    def get_hunting_path_from_folder(self, folder_name):
        hunting_path = Path(self.exp_folder) / 'hunting' / folder_name
        hunting_path.mkdir(exist_ok=True, parents=True)
        return hunting_path

class times_schema(BaseModel):
    expt_start: datetime
    expt_end: datetime

def get_one_peak_path(run_path,time):
    if run_path is not None:
        _path = run_path / time.strftime('%Y%m%d_%H%M%S')
        Path(_path).mkdir(exist_ok=True)
        return _path
    return None

class event_timing(BaseModel):
    start: datetime
    end: datetime
    center: Optional[datetime] = None
    zero_start: Optional[datetime] = None
    zero_end: Optional[datetime] = None

    @property
    def cen(self):
        return self.center if self.center is not None else self.start + (self.end - self.start) / 2

    def set_peak_zeros(self, config, reference_type, run_start = None):
        if reference_type == 'absolute':
            zero_start = run_start - config.td_analysis_inputs.baseline_duration
            zero_end = run_start
        elif reference_type == 'local':
            zero_start = self.start - config.td_analysis_inputs.left_shoulder_support
            zero_end = self.start
        else:
            return self.zero_start, self.zero_end

        self.zero_start = zero_start
        self.zero_end = zero_end

        return zero_start, zero_end

    def save_single_peak_timing(self, save_path):
        timing_dict = {
                'start': self.start,
                'end': self.end,
                'zero_start': self.zero_start,
                'zero_end': self.zero_end,
                'peak_cen': self.cen,
            }
        
        pd.DataFrame.from_dict(timing_dict, orient='index').to_csv(get_one_peak_path(save_path, self.cen) / 'peak_timing.csv')

    @property
    def all_start(self):
        return np.min((self.start, self.zero_start))

    @property
    def all_end(self):
        return np.max((self.end, self.zero_end))

class basic_trigger_schema(BaseModel):
    start_trim: Optional[int] = 30
    end_trim: Optional[int] = 10
    ref_value: Optional[int] = 7
    sample_value: Optional[int] = 1
    min_len: Optional[int] = 10
    ref_min_duration: Optional[int] = 200
    sample_min_duration: Optional[int] = 1000
    port_map: Optional[List[dict]] = [{1: 'inlet'}, {7: 'ZAG'}]
    trigger_var: Optional[str] = 'MPVPosition'
    min_duration: Optional[int] = 200
    
    @property
    def port_map_dict(self):
        new_port_map = {}  
        for port_dict in self.port_map:
            new_port_map.update({port_dict[list(port_dict.keys())[0]]: list(port_dict.keys())[0]})
        return new_port_map
    
class peak_list_schema(BaseModel):
    spectra_type: str #average or correlation
    reference_type: Optional[str] = None #absolute, local, manual or None for correlation spectra
    windowed: Optional[bool] = False
    manual: Optional[bool] = False
    hunt: Optional[bool] = True
    folder: str #(ave_window, corr_window, peaks, peaks_left_sholder, peaks_corr, peaks_custom)

    def check_reference_type(self):
        if self.windowed and self.reference_type == 'local':
            print('windowed spectra cannot have local references, changing to absolute')
            self.reference_type = 'absolute'

class basic_hunting_schema(BaseModel):
    overwrite: Optional[bool] = True
    peaks: List[peak_list_schema]

    def get_peak_obj(self, folder):
        for peak_obj in self.peaks:
            if peak_obj.folder == folder:
                return peak_obj
        return None
    
    def get_folder(self, spectra_type, reference_type = None, windowed = False, manual = False):
        for peak_obj in self.peaks:
            if (
                (peak_obj.spectra_type == spectra_type) & 
                ((reference_type is None) | (peak_obj.reference_type == reference_type)) &
                (peak_obj.windowed == windowed) &
                (peak_obj.manual == manual)
                ):
                return peak_obj.folder
        return None

class fitting_schema(BaseModel):
    nu_min: Optional[float] = 5800
    nu_max: Optional[float] = 6300
    nominal_pressure: Optional[float] = 450
    use_exact_pressure: Optional[bool] = False
    dont_fit: Optional[List[int]] = [92831, 637513]
    exclude_list: Optional[List[List[float]]] = [[6075.5, 6075.7]]
    analyte_cids: Optional[List[int]] = []
    refitting_cids: Optional[List[int]] = []

class basic_peak_definition_schema(BaseModel):
    na_thresh: Optional[float] = NA_THRESH
    corr_key: Optional[str] = TVOC_KEY

class windowing_schema(basic_peak_definition_schema):
    duration_hours: Optional[float] = None
    shift_hours: Optional[float] = None
    duration_min: Optional[float] = None
    shift_min: Optional[float] = None
    duration_s: Optional[float] = None
    shift_s: Optional[float] = None

    @property
    def half_width(self):
        if self.duration_s is not None:
            return pd.Timedelta(self.duration_s/2, 'second')
        elif self.duration_min is not None:
            return pd.Timedelta(self.duration_min/2, 'minute')
        elif self.duration_hours is not None:
            return pd.Timedelta(self.duration_hours/2, 'hour')
        return None
    
    @property
    def shift(self):
        if self.duration_s is not None:
            return pd.Timedelta(self.shift_s, 'second')
        elif self.duration_min is not None:
            return pd.Timedelta(self.shift_min, 'minute')
        elif self.duration_hours is not None:
            return pd.Timedelta(self.shift_hours, 'hour')
        return None
    
    def get_time_list(self, start_doy, end_doy):
        time_periods = []
        for center in pd.date_range(start_doy, end_doy, freq=self.shift):
            time_obj = event_timing(start = center - self.half_width, end = center + self.half_width, center = center)
            time_periods.append(time_obj)
        return time_periods
    
    @property
    def subfolder_name(self):
        if self.duration_s is not None:
            return f"{self.duration_s:.0f}s_{self.shift_s:.0f}s"
        
        elif self.duration_min is not None:
            return f"{self.duration_min:.0f}min_{self.shift_min:.0f}min"
            
        elif self.duration_hours is not None:
            return f"{self.duration_hours:.0f}hr_{self.shift_hours:.0f}hr"
        
        return None

class big_schema(BaseModel):
    pfi_threshold: Optional[float] = 100
    adjacent_points: Optional[int] = 5
    max_width: Optional[float] = 2.0
    na_thresh: Optional[float] = NA_THRESH
    corr_key: Optional[str] = TVOC_KEY
    prominence: Optional[float] = None
    hampel_window_size: Optional[float] = None
    hampel_scale_factor: Optional[float] = None
    gmm_window_size: Optional[float] = None
    gmm_scale_factor: Optional[float] = None

    @property
    def find_outliers(self):
        return (self.hampel_window_size is not None) & (self.hampel_scale_factor is not None)
        
    @property
    def find_transitions(self):
        return (self.gmm_window_size is not None) & (self.gmm_scale_factor is not None)
    
    @property
    def subfolder_name(self):
        return f"{self.pfi_threshold:.0f}_{self.adjacent_points:.0f}_{self.max_width:.0f}"
