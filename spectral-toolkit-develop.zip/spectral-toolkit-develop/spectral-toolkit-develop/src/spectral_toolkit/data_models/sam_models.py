from pydantic import BaseModel, ConfigDict
from typing import List
from pandas import Timestamp


class Plan(BaseModel):
    """
    This model represents a SAM plan as determined
    from valve detection patterns.  This model is
    more for ease or organizing data in algorithm
    """
    model_config = ConfigDict(arbitrary_types_allowed=True)
    times: List[float] = []
    pattern: List[int] = []
    start_time: Timestamp = None
    stop_time: Timestamp = None
    repeated: int = 0

    @property
    def pattern_length(self):
        return len(self.pattern)

    @property
    def total_duration(self):
        """
        Total duration of the plan in hours
        """
        return (self.stop_time - self.start_time).total_seconds() / 3600
