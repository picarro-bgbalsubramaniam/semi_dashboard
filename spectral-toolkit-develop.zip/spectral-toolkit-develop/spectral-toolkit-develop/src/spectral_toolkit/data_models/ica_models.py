from pydantic import BaseModel, ConfigDict
import numpy as np


class ICAResults(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    nu_prime: np.ndarray
    slope_fit: np.ndarray
    slope_fit_err: np.ndarray
    time_series: np.ndarray
    mapping: np.ndarray
    mapping_mask: np.ndarray
    component: int
    n_components: int

