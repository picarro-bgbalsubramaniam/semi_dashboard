from pydantic import BaseModel
import numpy as np
from typing import Callable, Dict


class SplineBase(BaseModel):
    nu_min: float
    nu_max: float
    default_conc: float = 1e-9
    nominal_pressure: float

    def eval(self, **kwargs):
        raise NotImplementedError


class Spline1d(SplineBase):
    spline: Callable

    def eval(self, nu):
        return self.nominal_pressure * self.spline(nu) * self.default_conc


class Spline2d(SplineBase):
    spline: Callable
    width: float

    def eval(self, nu):
        return (
            self.nominal_pressure
            * self.spline(nu, self.width)[:, 0]
            * self.default_conc
        )


class SplinePoly(SplineBase):
    prefactors: Dict[str, float]
    sub_splines: Dict[str, Callable]

    def eval(self, nu):
        y = np.zeros(len(nu))
        for name in self.sub_splines:
            y += self.prefactors[name] * self.sub_splines[name](nu)
        y *= self.nominal_pressure
        return y * self.default_conc
