from typing import List, Optional
from pydantic import BaseModel

from spectral_toolkit.constants.plotting_constants import (
    ConcentrationUnits,
)

class compound_basics_schema(BaseModel):
    cid: int
    name: Optional[str] = None
    unit: Optional[ConcentrationUnits] = ConcentrationUnits.PPB

class drift_schema(BaseModel):
    cid_list: List[int]

