from pydantic import BaseModel
from typing import Optional
import enum


class FilterType(enum.Enum):
    include = "include"
    exclude = "exclude"


class Filter(BaseModel):
    """
    Basic filter on time series data
    """
    column: str
    filter_type: FilterType
    high: float
    low: float
