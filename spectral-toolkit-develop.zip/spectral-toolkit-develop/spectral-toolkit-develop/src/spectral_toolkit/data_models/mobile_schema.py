from typing import List, Optional
from pydantic import BaseModel

from pathlib import Path
from spectral_toolkit.data_models.rnd_schema import (
    basic_paths_schema, 
    basic_trigger_schema,
    basic_hunting_schema
)

class peak_detector_schema(basic_trigger_schema):
    armed_state: int = 1
    trigger_state: int = 3
    transition_state: int = 9
    holding_state: int = 10


class paths_schema(basic_paths_schema):
    misc_results: Optional[str] = 'Misc_results'
    average_spectra: Optional[str] = 'average'

    @property
    def misc_path(self):
        misc_path = Path(self.exp_folder) / self.misc_results
        misc_path.mkdir(exist_ok=True)
        return misc_path

    @property
    def original_path(self):
        (Path(self.exp_folder) / self.original).mkdir(exist_ok = True)
        return Path(self.exp_folder) / self.original
    
    def get_hunting_path(self, folder_name):
        hunting_path = Path(self.exp_folder) / 'hunting' / folder_name
        hunting_path.mkdir(exist_ok=True, parents=True)
        return hunting_path

class hunting_schema(basic_hunting_schema):
    def get_correlation_window_folder(self):
        for peak_obj in self.peaks:
            if peak_obj.windowed and peak_obj.spectra_type == 'correlation':
                return peak_obj.folder
        return None

    def get_average_window_folder(self):
        for peak_obj in self.peaks:
            if peak_obj.windowed and peak_obj.spectra_type == 'average':
                return peak_obj.folder
        return None
