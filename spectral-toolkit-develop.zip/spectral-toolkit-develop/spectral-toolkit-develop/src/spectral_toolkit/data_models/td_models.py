from __future__ import annotations
from typing import List, Optional, TypeVar
import os
from pydantic import BaseModel
from datetime import datetime
import re

from pathlib import Path

from spectral_toolkit.data_models.rnd_schema import (
    main_schema,
    times_schema,
    # manual_schema,
    event_timing,
    windowing_schema,
    basic_hunting_schema,
    basic_peak_definition_schema
)

from spectral_toolkit.data_models.basic_timeseries_schema import(
    var_schema,
)

from spectral_toolkit.data_models.basic_hunting_schema import (
    manual_event_timing
)

from spectral_toolkit.data_models.td_schema import (
    event_schema,
    paths_schema,
    MFC_schema,
    precon_schema,
    fits_schema,
    fit_var_schema,
    interp_schema,
    compounds_schema,
    td_analysis_schema,
    multi_run_fitting_schema
)

class configYamlTD(BaseModel):
    main: main_schema
    paths: paths_schema
    times: times_schema
    events: List[event_schema]
    filters: List[str]
    MFCs: List[MFC_schema]
    precon_timing: precon_schema
    fitting: multi_run_fitting_schema
    average_spectra: windowing_schema
    correlation_spectra: windowing_schema
    manual_peaks: Optional[List[manual_event_timing]] = None
    manual_peak_correlations: Optional[basic_peak_definition_schema] = None
    data_to_drop: Optional[List[event_timing]] = None
    variables: var_schema
    compound_list: List[str] = ["CO2", "CH4", "H2O"]
    td_analysis_inputs: td_analysis_schema
    hunting: basic_hunting_schema

    def create_fits_default(self):
        fits_default = []
        for compound in self.compound_list:
            fits_default.append(
                fits_schema(
                    variable_name=compound,
                    cen=fit_var_schema(set=100, min=10, max=200),
                    sigma_left=fit_var_schema(set=20, min=10, max=40),
                    sigma_right=fit_var_schema(set=20, min=10, max=40),
                    f_left=fit_var_schema(set=0.8, min=0, max=1),
                    f_right=fit_var_schema(set=0.8, min=0, max=1),
                    offset=fit_var_schema(set=0),
                    offset_slope=fit_var_schema(set=0),
                )
            )

        fits_dict_list = []
        for fit_now in fits_default:
            fit_temp = dict(fit_now)
            for key, value in fit_temp.items():
                if key != "variable_name" and value is not None:
                    fit_temp[key] = dict(value)
            fits_dict_list.append(fit_temp)

        return fits_dict_list
    
    def create_interp_default(self):
        interp_default = []
        for compound in self.compound_list:
            interp_default.append(dict(interp_schema(variable_name=compound)))
        return interp_default

    def create_compounds_default(self):
        compounds_default = []
        for compound in self.compound_list:
            compounds_default.append(
                dict(compounds_schema(compound_name=compound, concentration_ppm=0))
            )
        return compounds_default
    
    @property
    def MFC_list(self):
        MFC_list = []
        for mfc_obj in self.MFCs:
            MFC_list.append(mfc_obj.flow_name)
        return MFC_list
    
    
    @property    
    def peaks_folder_list(self):
        folder_list = []
        for peak_obj in self.hunting.peaks:
            folder_list.append(peak_obj.folder)
        return folder_list
        