from typing import List, Optional, TypeVar
import os
from pydantic import BaseModel

from pathlib import Path
from ruamel.yaml import YAML

from spectral_toolkit.data_models.basic_timeseries_models import configYaml

CUR_DIR = os.getcwd()
SRC_DIR = os.path.dirname(os.path.dirname(CUR_DIR))
CFG_DIR = os.path.join(SRC_DIR, "config")

CONFIG_FILE = "app_config.yaml"

yaml = YAML()


def get_input(config_file=CONFIG_FILE, cfg_dir: Optional[Path] = CFG_DIR, config_data_model: Optional = configYaml):
    yaml_dict = load_yaml_config(config_file, cfg_dir=cfg_dir)

    input_class = config_data_model.model_validate(yaml_dict)

    return input_class, config_file, yaml_dict


def load_yaml_config(ini_name: str, cfg_dir: Optional[Path] = CFG_DIR):
    """Load generic yaml config file.

    Parameters:
        ini_name: str
            file name of yaml config file
        cfg_dir: optional path, default CFG_DIR
            folder containing the yaml config file

    Returns:
        yaml_dict:
            dictionary containing data from the yaml file
    """
    config_path = os.path.join(cfg_dir, ini_name)
    with open(config_path, "r") as file:
        yaml_dict = yaml.load(file)

    return yaml_dict


def save_yaml(yaml_dict: dict, output_flnm: Path):
    """Save yaml file in the output folder.

    Parameters:
        yaml_dict: dict
            dictionary containing data for the yaml file
        output_flnm: path
            path, including file name ending in .yaml
            Location where the yaml file will be saved
    """

    with open(output_flnm, "w") as file:
        yaml.dump(yaml_dict, file)
