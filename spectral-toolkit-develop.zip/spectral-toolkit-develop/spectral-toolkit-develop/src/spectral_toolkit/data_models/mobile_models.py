from __future__ import annotations
from typing import List, Optional, TypeVar
import os
from pydantic import BaseModel
from datetime import datetime
import re
import xarray as xr

from pathlib import Path

from spectral_toolkit.data_models.rnd_schema import (
    main_schema,
    times_schema, 
    fitting_schema,
    basic_hunting_schema,
    basic_peak_definition_schema,
    hunt_paths_schema
)

from spectral_toolkit.data_models.mobile_schema import (
    peak_detector_schema,
    hunting_schema,
    paths_schema
)


class configYaml(BaseModel):
    main: main_schema
    paths: hunt_paths_schema
    times: times_schema
    peak_detector: peak_detector_schema
    fitting: fitting_schema
    hunting: basic_hunting_schema
    query: Optional[List[str]] = None
    average_spectra: basic_peak_definition_schema

    @property    
    def peaks_folder_list(self):
        folder_list = []
        for peak_obj in self.hunting.peaks:
            folder_list.append(peak_obj.folder)
        return folder_list

    @property
    def query_string(self):
        """Get a query string for Pandas"""
        return " & ".join(self.query)

    def _query_data(self, dataset: xr.Dataset) -> xr.Dataset:
        """
        Query the timeseries dataset.

        Args:
            dataset (xr.Dataset):
                Xarray dataset with variable ts_values
            query (str):
                Query string. Example:
                'gasConcs_962 > 0.1 & gasConcs_981 < 0.5'

        Returns:
            xr.Dataset: Filtered dataset

        """
        return_dataset = dataset.copy()

        timeseries_df = dataset.private_values.to_pandas()

        from pandas.errors import UndefinedVariableError

        if self.query_string:
            try:
                return_df = timeseries_df.query(self.query_string)
            except UndefinedVariableError as err:
                raise NameError(
                    f"No valid variable in query. Available variables: {list(timeseries_df.columns)}"
                ) from err
            else:
                dropped_datetimes = len(timeseries_df) - len(return_df)
                return_dataset = return_dataset.sel(_datetime=return_df.index.values)
            
        if return_dataset.sizes["_datetime"] == 0:
            raise ValueError("No data remaining after query")

        return return_dataset