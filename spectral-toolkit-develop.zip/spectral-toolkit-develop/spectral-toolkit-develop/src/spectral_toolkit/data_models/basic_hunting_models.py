from __future__ import annotations
from typing import List, Optional, TypeVar
import os
from pydantic import BaseModel

from pathlib import Path

from spectral_toolkit.data_models.rnd_schema import (
    main_schema,
    times_schema,
    event_timing,
    fitting_schema,
    basic_hunting_schema,
    big_schema,
    basic_peak_definition_schema,
    windowing_schema,
    hunt_paths_schema
)

from spectral_toolkit.data_models.basic_hunting_schema import (
    manual_event_timing
)

class configYaml(BaseModel):
    main: main_schema
    paths: hunt_paths_schema
    times: times_schema
    data_to_drop: Optional[List[event_timing]] = None

    manual_peaks: Optional[List[manual_event_timing]] = None
    manual_peak_correlations: Optional[basic_peak_definition_schema] = None
    manual_peak_averages: Optional[basic_peak_definition_schema] = None
    
    average_spectra: Optional[windowing_schema] = None
    correlation_spectra: Optional[windowing_schema] = None
    big_peak_correlations: big_schema
    hunting: basic_hunting_schema
    fitting: fitting_schema

    query: Optional[List[str]] = None
    
    @property
    def query_string(self):
        """Get a query string for Pandas"""
        return " & ".join(self.query)

    def _query_data(self, dataset: xr.Dataset) -> xr.Dataset:
        """
        Query the timeseries dataset.

        Args:
            dataset (xr.Dataset):
                Xarray dataset with variable ts_values
            query (str):
                Query string. Example:
                'gasConcs_962 > 0.1 & gasConcs_981 < 0.5'

        Returns:
            xr.Dataset: Filtered dataset

        """
        return_dataset = dataset.copy()

        timeseries_df = dataset.fitter_values.to_pandas()

        from pandas.errors import UndefinedVariableError

        if self.query_string:
            try:
                return_df = timeseries_df.query(self.query_string)
            except UndefinedVariableError as err:
                raise NameError(
                    f"No valid variable in query. Available variables: {list(timeseries_df.columns)}"
                ) from err
            else:
                dropped_datetimes = len(timeseries_df) - len(return_df)
                return_dataset = return_dataset.sel(_datetime=return_df.index.values)
            
        if return_dataset.sizes["_datetime"] == 0:
            raise ValueError("No data remaining after query")

        return return_dataset
    
    @property
    def manual_peaks_starts_list(self):
        starts_list = []
        for time_obj in self.manual_peaks:
            starts_list.append(time_obj.start)

        return starts_list
    
    @property
    def manual_peaks_ends_list(self):
        ends_list = []
        for time_obj in self.manual_peaks:
            ends_list.append(time_obj.end)
        
        return ends_list
    
    @property
    def manual_peaks_zero_starts_list(self):
        starts_list = []
        for time_obj in self.manual_peaks:
            starts_list.append(time_obj.zero_start)

        return starts_list
    
    @property
    def manual_peaks_zero_ends_list(self):
        ends_list = []
        for time_obj in self.manual_peaks:
            ends_list.append(time_obj.zero_end)
        
        return ends_list
    
    def get_manual_peak(self, start, end):
        for time_obj in self.manual_peaks:
            if time_obj.start == start and time_obj.end == end:
                return time_obj.__dict__
        return None
    
    @property    
    def peaks_folder_list(self):
        folder_list = []
        for peak_obj in self.hunting.peaks:
            folder_list.append(peak_obj.folder)
        return folder_list
    

    def get_hunting_folder(self, spectra_type = 'correlation'):
        for peak_obj in self.hunting.peaks:
            if peak_obj.spectra_type == spectra_type:
                return peak_obj.folder
        return None