import numpy as np
import pandas as pd
import pytz
from data_pooler.data_access_utils import get_file_paths_in_timerange
from data_pooler.persist import get_combolog_from_zpickle
from scipy.interpolate import interp1d
from scipy.stats import binned_statistic

from spectral_toolkit.constants.defaults_dict import name_dict
from spectral_toolkit.utilities_all.time_conversions import (
    timestamp_to_datetime,
    timestr_to_datetime,
    timestr_to_fDOY,
)


def process_data(df, times_dict, time_name, filters=[], tz=None):
    if tz is None:
        tz = pytz.timezone("America/Los_Angeles")
    df = filterData(filters, df)

    Ta = get_all_data(time_name, df)
    print("Process data")
    print(len(Ta))
    Ta = (Ta - Ta[0]) * 24
    good = Ta >= 0
    if "SpectrumID" in df:
        use_100 = True
        for f in filters:
            if f["key"] == "SpectrumID":
                use_100 = False
        if use_100:
            good &= df["SpectrumID"] == 100

    # add mask for specific timing in parameters
    bool_keep = np.zeros(len(good), dtype=bool)

    for event in times_dict:
        bool_keep |= good_times(df, times_dict[event][0], times_dict[event][1], tz=tz)
    if len(times_dict.keys()) > 0:
        good &= bool_keep

    T = Ta[good]
    print(len(T))

    df_new = df[good]

    return df_new


def good_times(df, start_str, end_str, tz=None):
    if tz is None:
        tz = pytz.timezone("America/Los_Angeles")
    bool_keep = np.ones(len(df.index)).astype(bool)
    if start_str is not None:
        start_dt = tz.localize(timestr_to_datetime(start_str))
        bool_keep &= df.index >= start_dt
    if end_str is not None:
        end_dt = tz.localize(timestr_to_datetime(end_str))
        bool_keep &= df.index <= end_dt

    return bool_keep


def find_name(name, df):
    if name in name_dict["new"]:
        data_name = name_dict["new"][name][0]
        data_factor = name_dict["new"][name][1]
        data_name_bits = data_name.split("_")
        short_data_name = "_".join(data_name_bits[1:])
        if data_name in df:
            return (data_name, data_factor)
        elif short_data_name in df:
            return (short_data_name, 1.0)
        elif name in df:
            return (name, 1.0)
        elif name == "JULIAN_DAYS":
            return (name, "timestamp")
        elif name == "index":
            return (name, "timestamp")
        else:
            print("%s aka %s is not in the data" % (name, data_name))
            return (None, None)
    else:
        name_bits = name.split("_")
        short_name = "_".join(name_bits[1:])
        if name in df:
            return (name, 1.0)
        elif short_name in df:
            return (short_name, 1.0)
        elif name == "JULIAN_DAYS":
            return (name, "timestamp")
        elif name == "index":
            return (name, "timestamp")
        else:
            print("%s is not in the data" % (name))
            return (None, None)


def get_all_data(name, df):
    new_name, data_factor = find_name(name, df)
    if name == "JULIAN_DAYS" and data_factor == "timestamp":
        df_dt = pd.DatetimeIndex(df.index)
        return (
            df_dt.dayofyear
            + df_dt.hour / 24.0
            + df_dt.minute / (24.0 * 60)
            + df_dt.second / (24.0 * 60 * 60)
        )
    elif data_factor == "timestamp":
        return df.index.values.astype(np.int64) // 10**9
    else:
        return df[new_name] * data_factor


def filterData(filters, df):
    """takes a filterDeck object and cleans df"""
    print("filtering")
    for f in filters:
        print(f)
        df = cleaner(df, f["key"], f["condition"])
    return df


def add_var_data(var_name, data_vector, df, overwrite=False, index_vector=None):
    if index_vector is None:
        if len(data_vector) != len(df.index):
            print("Data length does not match internal data array.")
        elif var_name in df and overwrite == False:
            print("Variable is already in the dataset. Rename it.")
        elif var_name in df and overwrite == True:
            df[var_name] = data_vector
            # print('Variable is already in the dataset. It was rewritten.')
        else:
            df[var_name] = data_vector
    else:
        if var_name not in df:
            df[var_name] = data_vector
        df[var_name][index_vector] = data_vector
    return df


def create_data_dict(ht, dat):
    data_dict = {}
    for key in ht:
        data_dict[key] = get_all_data(key, ht=ht, dat=dat)

    return data_dict


def add_multiple_var_data(x_name, x_vector, df_from, df_to, overwrite=False):
    # interpolates data from another dataset into this dataset
    for var_name in df_from:
        data_interp = interp1d(
            x_vector,
            get_all_data(var_name, df_from),
            bounds_error=False,
            fill_value="extrapolate",
        )
        data_vector = data_interp(get_all_data(x_name, df_to))
        df_to = add_var_data(var_name, data_vector, df_to, overwrite=overwrite)

    return df_to


def save_as_dat(filename, var_names, df):
    if "timestamp" in df:
        time_name = "timestamp"
    elif "broadband_timestamp" in df:
        time_name = "broadband_timestamp"
    timestamp_now = get_all_data(time_name, df)
    date_now = []
    time_now = []
    for ts_now in timestamp_now:
        dt = timestamp_to_datetime(ts_now)[0]

        date_now.append(dt.strftime("%Y-%m-%d"))
        time_now.append(dt.strftime("%H:%M"))

    df["DATE"] = np.array(date_now)
    df["TIME"] = np.array(time_now)

    var_names.append("Date")
    var_names.append("TIME")

    df.to_csv(filename, sep=" ", index=False, columns=var_names)


def cleaner(df, key, condition):
    """cleans data based on a given column name & condition (in an eval statement, where y is the variable name to be evaluated)"""

    df = df.dropna()  # remove NaNs
    condition.replace("y", "df[key]")
    eval("df.drop(df[" + condition + "])")

    return df


def get_spectra_from_combo(start_date_time, stop_date_time, base_path, log_name):
    files = get_file_paths_in_timerange(
        start_date_time, stop_date_time, base_path, log_name
    )
    spectrum_list = []

    for file_path in files:
        with file_path.open("rb") as pp:
            gen = get_combolog_from_zpickle(pp)
            metadata = next(gen)
            df = gen.send("fitdata")  # timeseries

            for spectrum_index in range(len(df)):
                spectrum_list.append(gen.send(int(spectrum_index)))
                # list of dataframes with absorbance, big3, model, npoints, nu, partial_fit, residuals
    return spectrum_list


def outputs(df, trig, name):
    return trig(get_all_data(name, df))


def compile_spectral_array(
    spectrum_list, time_name, df, event_dict=None, hr_offset=0.0, save_all=False
):
    t0 = get_all_data(time_name, df)[0]
    t_end = get_all_data(time_name, df)[-1]
    if event_dict is None:
        print("event_dict is None")

        event_dict = {}
        event_dict[0] = {"fDOY": (t0 + hr_offset / 24.0, t_end + hr_offset / 24.0)}
    else:
        for event in event_dict:
            start_fDOY = timestr_to_fDOY(event_dict[event]["times"][0])
            end_fDOY = timestr_to_fDOY(event_dict[event]["times"][1])

            event_dict[event]["fDOY"] = (
                start_fDOY + hr_offset / 24.0,
                end_fDOY + hr_offset / 24.0,
            )

    for event in event_dict:
        event_dict[event] = one_spectral_array_set(
            event_dict[event],
            event_dict[event]["fDOY"][0],
            event_dict[event]["fDOY"][1],
            spectrum_list,
            df,
            save_all=save_all,
            time_name=time_name,
        )

    return event_dict


def one_spectral_array_set(
    event_now, t0, t_end, spectrum_list, df, save_all=False, time_name=None
):
    print(t0, t_end)
    time_fDOY = get_all_data("JULIAN_DAYS", df)
    uid_starts = np.where(time_fDOY >= t0)[0]
    uid_ends = np.where(time_fDOY <= t_end)[0]
    if len(uid_starts) > 0 and len(uid_ends) > 0:
        uspecids = range(uid_starts[0], uid_ends[-1])
        time_JD = get_all_data("JULIAN_DAYS", df)[uspecids]
        if time_name == "index":
            time_tn = df.index[uspecids]
        elif time_name:
            time_tn = df.loc[time_name][uspecids]

        allnu, allpart, allres, allspec = (
            np.array([]),
            np.array([]),
            np.array([]),
            np.array([]),
        )

        count = 0
        length_list = []

        for spec in uspecids:
            allnu = np.append(allnu, np.array(spectrum_list[spec]["nu"]))
            allpart = np.append(allpart, np.array(spectrum_list[spec]["partial_fit"]))
            allres = np.append(allres, np.array(spectrum_list[spec]["residuals"]))
            allspec = np.append(
                allspec, np.ones(len(spectrum_list[spec]["nu"])) * count
            )
            count += 1
            length_list.append(len(spectrum_list[spec]["nu"]))
        spec_length = np.array(length_list).mean()

        I = np.arange(len(allnu))
        ind = np.argsort(allnu)
        transitions = I[np.diff(allnu[ind], prepend=0) > 0.005]
        numean = np.zeros(transitions.shape)
        nustd = np.zeros(transitions.shape)
        for j, start in enumerate(transitions):
            if j < len(transitions) - 1:
                end = transitions[j + 1]
            else:
                end = len(allnu[ind])
            N = end - start

            numean[j] = allnu[ind][start:end].mean()
            if N > 1:
                nustd[j] = allnu[ind][start:end].std() / np.sqrt(N - 1)

        fit_array, residual_array = (
            np.ones((len(transitions), count)) * np.nan,
            np.ones((len(transitions), count)) * np.nan,
        )

        for i in range(count):
            ind_2_use = np.where(allspec == i)[0]
            fit_interp = interp1d(
                allnu[ind_2_use],
                allpart[ind_2_use],
                kind="next",
                bounds_error=False,
                fill_value=np.nan,
            )
            res_interp = interp1d(
                allnu[ind_2_use],
                allres[ind_2_use],
                kind="next",
                bounds_error=False,
                fill_value=np.nan,
            )

            fit_array[:, i] = fit_interp(numean)
            residual_array[:, i] = res_interp(numean)

        if save_all:
            event_now["allnu"] = allnu
            event_now["allpart"] = allpart
            event_now["allres"] = allres
            event_now["allspec"] = allspec
            event_now["transitions"] = transitions
            event_now["nustd"] = nustd
            event_now["residual_array"] = residual_array

        event_now["JULIAN_DAYS"] = time_JD
        if time_name:
            event_now[time_name] = time_tn
        event_now["fit_array"] = fit_array

        event_now["numean"] = numean

    return event_now


def ewa(last_value, value, alpha=None, n=10):
    if alpha is None:
        alpha = 2 / (n + 1)
    return alpha * value + (1 - alpha) * last_value


def calculate_spectrum_score(loss, model):
    normalized_data_vector = loss / np.sqrt(np.sum(loss**2))
    normalized_model_vector = model / np.sqrt(np.sum(model**2))
    spectrum_score = sum(normalized_data_vector * normalized_model_vector)
    spectrum_score = -1 * np.log10(1 - spectrum_score)

    return spectrum_score


def stoplight_score(data_dict, threshold=0.1):
    """
    calcualte a stoplight score based on spectrum score and total VOC proxy
    0 good, 1 ok, 2 bad

    INPUT
    data_dict: dictionary containing entries of 'name'
    data_dict[name] must contain x_last, y_last, x, y

    options for name: 'raw_data', 'exponentially_weighted'
    """
    for key, dict_now in data_dict.items():
        x = float(dict_now["x"])
        y = float(dict_now["y"])
        x_last = float(dict_now["x_last"])
        y_last = float(dict_now["y_last"])

        current_slope = (y - y_last) / (x - x_last)

        data_dict[key]["slope"] = current_slope

        if current_slope >= threshold:
            data_dict[key]["stoplight_score"] = 0
        elif current_slope <= -threshold:
            data_dict[key]["stoplight_score"] = 2
        else:
            data_dict[key]["stoplight_score"] = 1
    return data_dict


def simple_bin(nu, absorbance):
    # absorbance: (N,) where N = len(nu), can be 2d
    bin_range = (5800, 6200)
    bin_width = 5
    bin_edges = np.arange(bin_range[0], bin_range[1] + bin_width / 2, bin_width)
    bin_centers = bin_edges[:-1] + bin_width / 2

    nu_min = np.nanmin(nu)
    nu_max = np.nanmax(nu)

    center_ind = np.intersect1d(
        np.where(bin_centers >= nu_min), np.where(bin_centers <= nu_max)
    )
    edge1_ind = np.intersect1d(
        np.where(bin_edges[1:] > nu_min), np.where(bin_edges[1:] < nu_max)
    )
    edge2_ind = np.intersect1d(
        np.where(bin_edges[:-1] > nu_min), np.where(bin_edges[:-1] < nu_max)
    )
    ind_2_use = np.unique(np.concatenate((center_ind, edge1_ind, edge2_ind)))

    absorbance_mean, edges, n = binned_statistic(
        nu, absorbance, statistic=np.nanmean, bins=bin_edges
    )
    dict_out = {}
    dict_out["simple_sum"] = np.nansum(absorbance_mean[ind_2_use])
    for nu_now, abs_now in zip(bin_centers[ind_2_use], absorbance_mean[ind_2_use]):
        dict_out["simple_nu_%d" % int(nu_now * 1000)] = abs_now
    return dict_out


def targeted_bin(nu, absorbance):
    nu_min = np.nanmin(nu)
    nu_max = np.nanmax(nu)

    bin_edges = [
        (5800, 5875),  # 1-alkenes
        (5875, 5950),  # 1-alkenes
        (5950, 6025),  # 1-alkenes
        (6110, 6150),  # 1-alkenes
        (5800, 5850),  # branched alkenes and alkanes
        (5850, 5900),  # branched alkenes and alkanes
        (5900, 5950),  # branched alkenes and alkanes
        (5950, 6000),  # branched alkenes
        (6100, 6175),  # branched alkenes
        (6000, 6100),
        (5950, 6050),  # BTEX
    ]
    dict_out = {}
    dict_out["target_sum"] = 0
    for bin_edge in bin_edges:
        bin_center = np.mean(bin_edge)

        if (
            (bin_center >= nu_min and bin_center <= nu_max)
            or (bin_edge[0] > nu_min and bin_edge[0] < nu_max)
            or (bin_edge[1] > nu_min and bin_edge[1] < nu_max)
        ):
            absorbance_mean, edges, n = binned_statistic(
                nu, absorbance, statistic=np.nanmean, bins=bin_edge
            )
            dict_out[
                "target_%d_%d_nu_%d"
                % (int(bin_edge[0]), int(bin_edge[1]), int(bin_center * 1000))
            ] = absorbance_mean[0]
            if np.isnan(absorbance_mean[0]) != True:
                dict_out["target_sum"] += absorbance_mean[0]

    return dict_out
