"""
Created on Aug 31, 2018

@author: rhernandez
"""
import inspect
import os
import os.path as osp
import sys

home = osp.expanduser("~")
database_name = "spectral_library"
if database_name in os.environ:
    database_path = os.environ[database_name]
else:
    database_path = osp.join(home, "database", "document_store", "mongo")

KEY_ADMIN_COLLECTION_NAME = r"admin"
KEY_DB_NAME = r"db_name"
KEY_DB_PATH = r"db_path"

KEY_ABSORBTION_UID = r"a"
KEY_CHEMICAL_UID = r"cid"
KEY_WAVENUMBER_UID = r"nu"


class Collection(object):
    KEY_MODE = r"mode"
    KEY_ACTIVE = r"active"
    KEY_NAME = r"name"

    def __init__(self, name):
        self.name = name


class Hitran(Collection):

    NAME = r"hitran"

    def __init__(self):
        super(Hitran, self).__init__(Hitran.NAME)


class HitranMolecules(Collection):

    NAME = r"hitran_molecules"

    def __init__(self):
        super(HitranMolecules, self).__init__(HitranMolecules.NAME)


class HitranPeaks(Collection):

    NAME = r"hitran_peaks"
    KEY_REQ_PEAKS = r"requested_peaks"

    def __init__(self):
        super(HitranPeaks, self).__init__(HitranPeaks.NAME)


class HitranAdmin(Collection):

    NAME = r"hitran_admin"
    KEY_ADMIN_FN = r"admin_fn"

    def __init__(self):
        super(HitranAdmin, self).__init__(HitranAdmin.NAME)


class PubChem(Collection):

    NAME = r"pub_chem"
    KEY_DOWNLOAD_2D_IMG = r"download_2d_image"
    KEY_DISP_IMG_INI_PY = r"display_images_ini_python"
    KEY_DATA_DIR = r"data_dir"
    KEY_SEARCH_TERM_FN = r"search_term_function"
    KEY_GET_ADD_INFO = r"get_additional_info"

    def __init__(self):
        super(PubChem, self).__init__(PubChem.NAME)


class Picarro(Collection):

    NAME = r"picarro"

    def __init__(self):
        super(Picarro, self).__init__(Picarro.NAME)


class Nist(Collection):

    NAME = r"nist"

    def __init__(self):
        super(Nist, self).__init__(Nist.NAME)


class Properties(Collection):

    NAME = r"properties"

    def __init__(self):
        super(Properties, self).__init__(Properties.NAME)


def collect_collections(predicate):
    c_of_cs = []
    for name, data in inspect.getmembers(sys.modules[__name__], inspect.isclass):
        if (
            "collection" in name.lower()
            and len(name) != len("collection")
            and "propertiescollection" not in name.lower()
        ):
            val = getattr(data, str(predicate))
            c_of_cs.append(val)
    return c_of_cs


collection_names = collect_collections("NAME")

if __name__ == "__main__":

    print(collection_names)
