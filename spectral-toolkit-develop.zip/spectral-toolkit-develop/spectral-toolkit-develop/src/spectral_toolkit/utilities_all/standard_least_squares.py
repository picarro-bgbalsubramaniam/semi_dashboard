# -*- coding: utf-8 -*-
"""
Created on Mon Jun 23 13:49:41 2014

@author: chris
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import lsq_linear


class LSQ:
    """Alist is a list of independent columns"""

    def __init__(
        self,
        Alist,
        y,
        e=None,
        plotme=None,
        labels=None,
        xlabel="",
        ylabel="",
        parameterNames=[],
        bounds=(-np.inf, np.inf),
    ):
        self.Alist = Alist
        self.y = y
        if e is None:
            self.e = np.ones(y.shape)
        else:
            self.e = e
        self.plotme = plotme
        self.A = None
        self.result = None
        self.err_result = None
        self.residuals = None
        self.std_residuals = None
        self.eigenvalues = None
        self.eigenvectors = None
        self.CL = None
        self.fity = None
        self.R2 = None
        if labels != None:
            self.labels = labels
        else:
            self.labels = ["" for i in range(len(Alist))]
        self.xlabel = xlabel
        self.ylabel = ylabel
        self.parameterNames = parameterNames
        if len(parameterNames) == 0:
            self.parameterNames = ["A%d" % i for i in range(len(Alist))]
        self.fitLSQ(bounds=bounds)

    def __str__(self):
        txt = ""
        for k in range(len(self.result)):
            if self.labels[k] == "":
                sl = ""
            else:
                sl = " (%s) " % self.labels[k]
            paramtxt = self.parameterNames[k]
            txt += "%s %s= %.7g +/- %.6g\n" % (
                paramtxt,
                sl,
                self.result[k],
                self.err_result[k],
            )
        txt += "R squared = %.6g\n" % self.R2
        txt += "std dev residuals = %.6g\n" % self.std_residuals

        return txt

    def reportCL(self, B):

        unc = B * self.eigenvectors * self.eigenvalues

        rows, cols = np.shape(unc)

        CL = []
        for r in range(rows):
            thisrow = []
            for k in range(cols):
                thisrow.append(unc.item(r, k) ** 2)
            CL.append(np.sqrt(sum(thisrow)))
        CLa = np.array(CL)
        return CLa

    def makeMatrix(self, Xlist):
        return np.matrix(Xlist).T

    def fitLSQ(self, bounds=(-np.inf, np.inf)):
        # Alist is a list of 1-D arrays that corresponds to the different parameters that will be fit
        atlist = []
        for al in self.Alist:
            atlist.append(al / self.e)

        A = self.makeMatrix(atlist)
        bigA = self.makeMatrix(self.Alist)

        self.A = bigA

        Y = np.matrix(self.y)
        E = np.matrix(self.e)
        YE = Y / E
        AT = A.T
        P = AT * A
        Q = P.I

        eigen = np.linalg.eig(Q)
        self.eigenvectors = eigen[1]

        # data (M, N)
        # matrices (M, K)
        # result (N, K)
        # residuals (K,)
        data = np.ndarray(len(YE.T))
        data[:] = YE.T.flatten()
        fit_output_dict = lsq_linear(A, data, bounds=bounds, verbose=0, max_iter=500)
        self.fit_output_dict = fit_output_dict
        # x: result
        # cost: cost function value
        # fun: vector of residuals at the solution
        # optimality
        # active_mask
        # nit: number of iterations. zero if the uncontstrained solution is optimal
        # status
        # message
        # success
        result = fit_output_dict["x"]  # [:,np.newaxis]
        self.result = fit_output_dict["x"]  # [:,np.newaxis]

        self.resultDict = {}
        for pname, res in zip(self.parameterNames, self.result):
            self.resultDict[pname] = res
        LM = np.sqrt(np.diag(eigen[0]))  # create diagonal matrix with eigenvalues
        self.eigenvalues = LM

        CLa = self.reportCL(bigA)

        self.CL = CLa

        err_result = np.matrix(np.sqrt(np.diag(Q))).T

        self.err_result = [er.item() for er in err_result]

        self.fity = np.array(bigA * result[:, np.newaxis])[:, 0]
        self.residuals = -fit_output_dict["fun"]  # [:,np.newaxis]
        self.std_residuals = np.std(self.residuals)
        self.R2 = (
            1 - np.std(self.residuals / self.e) ** 2 / np.std(self.y / self.e) ** 2
        )

        pm = self.plotme
        cbarflag = False
        if pm is not (None):
            X = self.Alist[pm[0]]
            if len(pm) <= 1:
                colr = "blue"
            elif pm[1] == -1:
                colr = list(self.e)
                cbarflag = True
            elif pm[1] >= 0:
                colr = list(self.Alist[pm[1]])
                cbarflag = True
            else:
                colr = "blue"
            plt.scatter(
                list(self.Alist[pm[0]]),
                list(self.y),
                c=colr,
                s=10 + 500 / np.sqrt(len(residuals)),
                alpha=0.5,
                edgecolors="none",
            )
            if cbarflag:
                plt.colorbar()
            PX, PY = self.dualSort(list(self.Alist[pm[0]]), list(self.fity))
            plt.plot(PX, PY, "g", linewidth=2)
            PX, PY = self.dualSort(list(self.Alist[pm[0]]), CLa + self.fity)
            plt.plot(PX, PY, "r--")
            PX, PY = self.dualSort(list(self.Alist[pm[0]]), self.fity - CLa)
            plt.plot(PX, PY, "b--")
            plt.xlabel(self.xlabel)
            plt.ylabel(self.ylabel)
            plt.show()
            #
        return

    def dualSort(self, X, Y):  # sorts on X
        Z = list(zip(X, Y))
        Z.sort(key=lambda row: row[0])
        X, Y = list(zip(*Z))
        return X, Y


if __name__ == "__main__":
    pass
