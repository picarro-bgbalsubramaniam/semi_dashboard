# -*- coding: utf-8 -*-
"""
Created on Thu Jun 14 13:26:38 2018

@author: chris
"""

from pymongo import MongoClient
from pymongo.errors import ConnectionFailure
import subprocess
import time
import json
import os
import platform


class SpectralDatabase:
    def __init__(self, dbname="PicarroCompoundLibrary", verbose=False):
        self.dbname = dbname
        self.verbose = verbose
        self.databaseConnect()

    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        self.close()

    def databaseConnect(self):
        self.client = MongoClient(serverSelectionTimeoutMS=2000)
        if self.verbose:
            print(
                f"MongoServer found at {self.client.address[0]}:{self.client.address[1]}"
            )
        self.db = self.client.get_database(self.dbname)
        self.collection_names = self.db.list_collection_names()
        if "W6040_6060" in self.collection_names:
            self.db_type = "Rella2019"
        elif "Lines" in self.collection_names:
            self.db_type = "Picarro2020"
        else:
            self.db_type = None
            if self.verbose:
                print(f"{self.dbname} not an expected db structure")
                print(self.collection_names)

    def close(self):
        self.client.close()
        if self.verbose:
            print("MongoServer closed")


def updateCollection(collection, searchDict, rec, mode):
    """0: delete one and create new;
    1: delete_all matching records and create new;
    2: upsert;
    3: update only;
    4: download only new records;
    anything else: no change to collection"""

    if mode == 0:  # delete one and insert
        thisRec = collection.find_one(searchDict)
        collection.delete_one({"_id": thisRec})
        collection.insert_one(rec)
    elif mode == 1:  # delete all and insert; cleans up old stuff
        theseRecs = collection.find(searchDict)
        for thisRec in theseRecs:
            collection.delete_one({"_id": thisRec["_id"]})
        collection.insert_one(rec)
    elif mode == 2 or mode == 4:  # upsert
        collection.update_one(searchDict, {"$set": rec}, upsert=True)
    elif mode == 3:
        collection.update_one(searchDict, {"$set": rec}, upsert=False)
    else:
        pass


if __name__ == "__main__":

    SDB = SpectralDatabase(verbose=True)
    U = SDB.empiricalSpectra.find_one({})
    for u in U:
        print(u)
