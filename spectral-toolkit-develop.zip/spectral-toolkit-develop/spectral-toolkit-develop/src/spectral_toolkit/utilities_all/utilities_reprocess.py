import collections
import copy
import os

import numpy as np

os.environ["LOLOGGER_SERVERLESS"] = "1"  # put this above all

import spectral_toolkit.utilities_all.standard_least_squares as LSQ
from spectral_toolkit.utilities_all.time_conversions import timestamp_to_fDOY
from spectral_toolkit.utilities_all.utilities_for_pool import (
    calculate_spectrum_score,
    simple_bin,
)


def load_allowed_frequencies(flnm):
    with open(flnm, "r") as f:
        line = f.readline()
        keywords = line.split()
        freq = []
        while True:
            if not line:
                break
            values = line.split()
            freq.append(float(values[1]))
            line = f.readline()
    return np.array(freq)


def screen_frequencies(nu, allowed_freq):
    diff_big_abs = np.absolute(
        np.tile(nu[:, np.newaxis], (1, len(allowed_freq)))
        - np.tile(allowed_freq, (len(nu), 1))
    )
    big_frequency_mask = diff_big_abs < 0.01
    frequency_mask = np.sum(big_frequency_mask, axis=1)

    return frequency_mask.astype(bool)


def process_one_day(MF, event_now, required_cids, nurange, bounds=None, time_name=None):
    results = collections.defaultdict(list)
    extra_list = ["spectrum_score", "fit", "JULIAN_DAYS", "simple_sum"]
    for extra_name in extra_list:
        results[extra_name] = []
    if time_name:
        results[time_name] = []

    good_fits = 0
    bad_fits = 0

    if bounds is not None:
        spectral_data = initialize_spectral_data(time_name=time_name)
        bounds_now = bounds
    else:
        bounds_now = (-np.inf, np.inf)

    # for event in self.event_dict:
    if "JULIAN_DAYS" in event_now:
        unique_id = range(len(event_now["JULIAN_DAYS"]))
        Nspec = len(unique_id)
        if "numean" in event_now:
            thisnu_all = event_now["numean"]
        elif "numean_list" in event_now:
            numean_list = event_now["numean_list"]
        if "fit_array" in event_now:
            fit_array = event_now["fit_array"]
        elif "fit_array_list" in event_now:
            fit_array_list = event_now["fit_array_list"]

        sum_dict = {}
        for sid in unique_id:
            if sid % 100 == 0:
                print("%.2f" % (100 * (sid) / Nspec))
            if "numean" in event_now and "fit_array" in event_now:
                loss = fit_array[:, sid]
                thisnu, loss = get_nu_fit(thisnu_all, loss, None, nurange)
            elif "numean_list" in event_now and "fit_array_list" in event_now:
                loss = fit_array_list[sid]
                thisnu = numean_list[sid]
                thisnu, loss = get_nu_fit(thisnu, loss, None, nurange)

            # calculate simple and targeted bins
            sum_dict["simple_sum"] = np.zeros(Nspec)
            dict_now = simple_bin(thisnu, loss)
            for key, value in dict_now.items():
                if key not in sum_dict:
                    sum_dict[key] = np.zeros(Nspec)
                sum_dict[key][sid] = dict_now[key]

            ones = np.ones(thisnu.shape)
            poly = [ones, thisnu - 6056]
            mfs = copy.deepcopy(poly)
            paramNames = ["offset", "slope"]
            for cid in required_cids:
                f = MF[cid]
                model = f(thisnu, overwrite_cache=True)
                mfs.append(model)
                paramNames.append("gasConcs_%d" % cid)

            try:
                fit = LSQ.LSQ(mfs, loss, parameterNames=paramNames, bounds=bounds_now)
                results["fit"].append(fit)
                for nm, val in zip(fit.parameterNames, fit.result):
                    results[nm].append(val)

                results["spectrum_score"].append(
                    calculate_spectrum_score(loss, fit.fity)
                )
                results["JULIAN_DAYS"].append(event_now["JULIAN_DAYS"][sid])
                if time_name:
                    results[time_name].append(event_now[time_name][sid])
                results["simple_sum"].append(sum_dict["simple_sum"][sid])
                good_fits += 1

                if bounds is not None:
                    time_now = timestamp_to_fDOY(event_now["JULIAN_DAYS"][sid])
                    if time_name:
                        time_name_now = event_now[time_name][sid]
                    else:
                        time_name_now = None
                    spectral_data = populate_spectral_data(
                        spectral_data,
                        time_now,
                        thisnu,
                        fit.residuals,
                        time_name=time_name,
                        time_name_now=time_name_now,
                    )
            except:
                breakpoint()
                print("bad fit")
                bad_fits += 1
    for nm in results:
        results[nm] = np.asarray(results[nm])

    return good_fits, bad_fits, results, spectral_data


def initialize_spectral_data(time_name=None):
    spectral_data = {}
    spectral_data["JULIAN_DAYS"] = []
    spectral_data["nu"] = []
    spectral_data["partial_fit"] = []
    if time_name:
        spectral_data[time_name] = []
    return spectral_data


def populate_spectral_data(
    spectral_data, time_now, nu, residual, time_name=None, time_name_now=None
):

    spectral_data["JULIAN_DAYS"].append(time_now)
    spectral_data["nu"].append(nu)
    spectral_data["partial_fit"].append(residual)
    if time_name:
        spectral_data[time_name].append(time_name_now)
    return spectral_data


def get_nu_fit(thisnu, loss, allowed_freq, nurange):
    if allowed_freq is not None:
        freq_mask = screen_frequencies(thisnu)
    else:
        freq_mask = np.ones(len(thisnu)).astype(bool)

    freq_mask &= thisnu >= nurange[0]
    freq_mask &= thisnu <= nurange[1]
    freq_mask &= np.isnan(loss) != True

    thisnu = copy.deepcopy(thisnu[freq_mask])
    loss = loss[freq_mask]

    return thisnu, loss


def trim_spectral_data(spectral_data):
    unique_nu = None
    for nu_now in spectral_data["nu"]:
        if unique_nu is None:
            unique_nu = nu_now
        else:
            unique_nu = np.unique(np.hstack((unique_nu, nu_now)))

    fit_array = np.zeros((len(spectral_data["JULIAN_DAYS"]), len(unique_nu))) * np.nan
    for i, (nu_now, data_now) in enumerate(
        zip(spectral_data["nu"], spectral_data["partial_fit"])
    ):
        _, x_ind, y_ind = np.intersect1d(unique_nu, nu_now, return_indices=True)
        fit_array[i, x_ind] = data_now[y_ind]

    spectral_data["nu"] = unique_nu
    spectral_data["partial_fit"] = fit_array.T

    return spectral_data
