import os

os.environ["LOLOGGER_SERVERLESS"] = "1"  # put this above all

import pickle

import spectral_toolkit.utilities_all.HitranDBModule as HTM
import spectral_toolkit.utilities_all.SpectralLibraryTools as stoolie
from spectral_toolkit.constants.defaults_dict import name_dict, trigger_defaults


def set_filters(filter_dict):
    filters = {}
    if filter_dict is not None:
        for key in filter_dict:
            if "var_" in key:
                new_key = filter_dict[key]
                condition_string = ""
                if "%s_min" % new_key in filter_dict:
                    min_value = filter_dict["%s_min" % new_key]
                    condition_string = "y <= %s" % min_value
                else:
                    min_value = None
                if "%s_max" % new_key in filter_dict:
                    max_value = filter_dict["%s_max" % new_key]
                    if len(condition_string) > 1:
                        condition_string += " or y >= %s" % max_value
                    else:
                        condition_string = "y >= %s" % max_value
                else:
                    max_value = None

                filters.append({"key": new_key, "condition": condition_string})
    return filters


def set_event_times(event_config):
    event_dict = {}
    for key in event_config:
        if "start" in key or "end" in key:
            key_parts = key.split("_")
            if int(key_parts[-1]) not in event_dict:
                start_date_time = event_config[key]
                end_date_time = event_config["end_date_time_%s" % key_parts[-1]]
                event_dict[int(key_parts[-1])] = {
                    "times": (start_date_time, end_date_time)
                }
    return event_dict


def set_events_FOM(event_config):
    event_dict = set_event_times(event_config)
    for key in event_config:
        if "create_splines" in key:
            spline_nums = event_config[key]
            spline_num_list = list(map(int, spline_nums))
            for spline_num in spline_num_list:
                print(spline_num)
                event_dict[spline_num]["create_spline"] = True
        elif "rank" in key:
            key_parts = key.split("_")
            new_key = "_".join(key_parts[:-1])
            event_dict[int(key_parts[-1])][new_key] = list(
                map(float, event_config[key])
            )
    return event_dict


def get_reprocess_variables(unknowns_dict):
    cid_list = {}
    unknown_vars = {}
    # unknown_vars['cid_list'] = {}
    unknown_vars["N_compounds"] = None
    unknown_vars["core_N_compounds"] = 1
    unknown_vars["N_plots"] = 1
    unknown_vars["N_cycle_list"] = [1, 2]
    unknown_vars["pct_cutoff"] = None
    unknown_vars["rejected_cids"] = []
    unknown_vars["std_res_factor"] = 1.0
    unknown_vars["neg_factor"] = 1.0
    unknown_vars["rating_slope"] = 1.0
    unknown_vars["rating_intercept"] = 0.0
    unknown_vars["fit_max"] = 2
    unknown_vars["use_key"] = "combined_fom"
    for key, value in unknowns_dict.items():
        if "cid_list" in key:
            key_bits = key.split("_")
            cids = list(value)
            cid_list[key_bits[-1]] = list(map(int, cids))
        elif "cid_names" in key:
            key_bits = key.split("_")
            names = list(value)
            cids = []
            for name in names:
                if name + "_ppb" in name_dict["new"]:
                    cids.append(int(name_dict["new"][name + "_ppb"][2]))
                elif name + "_ppm" in name_dict["new"]:
                    cids.append(int(name_dict["new"][name + "_ppm"][2]))
                else:
                    print("%s not in default dictionary" % name)
            cid_list[key_bits[-1]] = cids
        elif key == "N_compounds":
            unknown_vars["N_compounds"] = int(value)
        elif key == "core_N_compounds":
            unknown_vars["core_N_compounds"] = int(value)
        elif key == "N_plots":
            unknown_vars["N_plots"] = int(value)
        elif key == "nurange":
            unknown_vars["nurange"] = list(map(float, value))
        elif key == "N_cycle":
            N_cycle_list = list(value)
            unknown_vars["N_cycle_list"] = list(map(int, N_cycle_list))
        elif key == "pct_cutoff":
            unknown_vars[key] = float(value)
        elif "rejected_cids" in key:
            cids = list(value)
            unknown_vars["rejected_cids"] = list(map(int, cids))
        elif "scale" in key or "rating" in key:
            unknown_vars[key] = float(value)
        elif key == "use_key":
            unknown_vars[key] = value
    return unknown_vars, cid_list


def get_var_lims(Plot_y_axis_lim_dict, var_name):
    var_lims = {}
    if Plot_y_axis_lim_dict is not None:
        for lim_name in Plot_y_axis_lim_dict:
            if var_name in lim_name:
                key_bits = lim_name.split("_")
                suffix = key_bits[-1]
                var_lims[var_name][suffix] = float(Plot_y_axis_lim_dict[lim_name])
    return var_lims


def set_trigger_new(trigger_dict):
    if len(trigger_dict) == 0:  # empty dictionary results in default values
        TriggerSpecies = dict()
        TriggerSpecies["CO2"] = trigger_defaults["CO2"]
    else:
        if "name" in trigger_dict:
            name = trigger_dict["name"]
        else:
            name = None

    if name is None:
        TriggerSpecies = trigger_defaults["other"]
    elif name in trigger_defaults:
        TriggerSpecies = trigger_defaults[name]
    elif "_ppm" in name:
        TriggerSpecies = trigger_defaults["conc_ppm"]
    elif "_ppb" in name:
        TriggerSpecies = trigger_defaults["conc_ppb"]
    elif "gasConcs" in name:
        TriggerSpecies = trigger_defaults["conc_parts"]
    else:
        TriggerSpecies = trigger_defaults["other"]

    for key, value in trigger_dict.items():
        TriggerSpecies[key] = value

    if "pull_clean_data" in TriggerSpecies:
        if TriggerSpecies["pull_clean_data"] == "True":
            TriggerSpecies["pull_clean_data"] = True
        elif TriggerSpecies["pull_clean_data"] == "False":
            TriggerSpecies["pull_clean_data"] = False

    return TriggerSpecies


def parse_MFCs(MFC_ini):
    MFCs_dict = {
        "sample_flow": 0.0,
        "first_dilution_flow": 0.0,
        "second_dilution_flow": 0.0,
        "third_dilution_flow": 0.0,
        "overflow_dilution_flow": 0.0,
        "trap_flow": 0.0,
        "instrument_flow": 45.0,
    }
    for key, value in MFC_ini.items():
        if isinstance(value, int):
            MFCs_dict[key] = float(value)
        elif "MFC" in value or "MFM" in value:
            MFCs_dict[key] = value
    return MFCs_dict


def get_PCE_names():
    savefn = "PubChem_names.pkl"
    try:
        with open(savefn, "rb") as inpkl:
            PCE_names = pickle.load(inpkl)
    except:
        gases = stoolie.survey_library_for_ecompounds(version=2)
        gases.sort(key=lambda s: s["cid"])
        PCE_names = {}
        for gas in gases:
            cid = gas["cid"]
            PCE_names[cid] = "%s" % HTM.PubChemEntry(cid)

        with open(savefn, "wb") as outpkl:
            pickle.dump(PCE_names, outpkl, 1)
    return PCE_names


def set_file_paths(baseDIR, e_start=None, analysis_name=None):
    analysis_dir = None
    event_dir = None
    figures_dir = None

    output_dir = os.path.join(baseDIR, "Output")
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)

    if analysis_name is not None:
        analysis_dir = os.path.join(output_dir, analysis_name)
        if not os.path.exists(analysis_dir):
            os.mkdir(analysis_dir)

    if e_start is not None:
        event_dir = os.path.join(output_dir, e_start)
        if not os.path.exists(event_dir):
            os.mkdir(event_dir)

        if analysis_name is not None:
            figures_dir = os.path.join(event_dir, analysis_name)
            if not os.path.exists(figures_dir):
                os.mkdir(figures_dir)
    else:
        figures_parent = os.path.join(output_dir, "Figures")
        if not os.path.exists(figures_parent):
            os.mkdir(figures_parent)

        figures_dir = os.path.join(figures_parent, analysis_name)
        if not os.path.exists(figures_dir):
            os.mkdir(figures_dir)

    return output_dir, analysis_dir, event_dir, figures_dir
