# -*- coding: utf-8 -*-
"""
Created on Tue Jun 06 16:04:20 2017

@author: chris
"""

import numpy as np
import time
import os
import shutil
import json
import re
import datetime
import math
import copy
import pprint

import utilities_all.MongoDBRellaUtilities as mdbr_utils
import utilities_all.PubChemModule as PCM


class PubChemEntry(object):
    def __init__(self, cid, download_unknown_entry=False):
        self.cid = cid
        self.download_unknown_entry = download_unknown_entry
        self.entry = self.getPubChemRecord(cid)

    def getPubChemRecord(self, cid):
        with mdbr_utils.SpectralDatabase() as S:
            pubchem = S.db.pubChemEntries
            searcher = {"cid": cid}
            while True:
                entry = pubchem.find_one(searcher)
                if entry is None and self.download_unknown_entry:
                    print(
                        "No entry for cid %d in database.  Downloading information from PubChem..."
                        % cid
                    )
                    compound = PCM.PubChemCompound(cid, True)
                    compoundRecord = compound.createDBRecord()
                    print(compound)
                    mdbr_utils.updateCollection(pubchem, searcher, compoundRecord, 1)
                else:
                    break
        return entry

    def parseFormula(self):
        pattern = r"(\D+)(\d*)"
        formula = self.entry["molecularFormula"]
        if formula == "H3N":
            formula = "NH3"
        groups = re.findall(pattern, formula)
        txt = ""
        for alph, num in groups:
            if len(num) == 0:
                txt += alph
            else:
                txt += alph + "_{" + num + "}"
        return txt

    def __repr__(self):
        h = lambda name: self.entry[name]
        txt = "%d: %s (%s)" % (self.cid, h("commonName"), h("molecularFormula"))
        return txt
