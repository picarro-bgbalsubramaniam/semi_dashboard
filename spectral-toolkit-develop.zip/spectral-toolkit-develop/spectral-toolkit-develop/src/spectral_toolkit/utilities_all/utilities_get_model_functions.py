import os
from copy import deepcopy

import numpy as np

os.environ["LOLOGGER_SERVERLESS"] = "1"  # put this above all
import pickle

from voc_fitter.model.compound import EmpiricalCompound
from voc_fitter.model.gas_sample import GasSample
from voc_fitter.model.library import database

import spectral_toolkit.utilities_all.HitranDBModule as HTM
import spectral_toolkit.utilities_all.SpectralLibraryTools as stoolie


def get_single_gas(db, cid, nurange, e_compound_dict, conc=1e-9):
    records = database.load_empirical_spectrum(
        db, nurange[0], nurange[1], e_compound_dict=e_compound_dict
    )
    gas_sample = GasSample.create_sample({cid: conc}, {977: 0.8, 947: 0.2}, {})
    info_dict = records["infoDict"]
    spectrum_dict = records["spectrumDict"]
    spline_args = {}
    for key, dict_now in spectrum_dict.items():
        spline_args[key] = {}
        for dict_key, value in dict_now.items():
            if dict_key == "Pop":
                if np.all(np.array(value) == None):
                    spline_args[key][dict_key] = float(key[1:])
                else:
                    spline_args[key][dict_key] = np.mean(value)
            elif dict_key == "Top":
                if np.all(np.array(value) == None):
                    spline_args[key][dict_key] = float(key[1:])
                else:
                    spline_args[key][dict_key] = 80.0
            else:
                spline_args[key][dict_key] = np.array(value)

    pressure_measurement_type = info_dict["dataType"]
    if "version" in info_dict:
        version = info_dict["version"]
    else:
        version = None
    data_collection_date = info_dict["dataCollectionDate"]
    nominal_concentration = 1e-6
    flag = 0
    for key, value in info_dict.items():
        if key == "ReportedConcentration_ppm" and flag < 1 and value is not None:
            nominal_concentration = value * 1e-6
            flag += 1
        elif key == "CalibratedConcentration_ppm" and flag < 2 and value is not None:
            nominal_concentration = value * 1e-6
            flag += 1
        elif key == "EstimatedConcentration_ppm" and flag < 3 and value is not None:
            nominal_concentration = value * 1e-6
            flag += 1

    nominal_pressure = info_dict["pNominal"]
    if records["infoDict"]:
        if pressure_measurement_type == "PolynomialCandP":
            test = deepcopy(spline_args["P%d" % int(nominal_pressure)])
            key_list = test.keys()
            for key in key_list:
                if "C" in key and "P" in key:
                    key_bits = key.split(" ")
                    key_bits_new = []
                    for i, key_bit in enumerate(key_bits):
                        if key_bit == "C":
                            key_bits[i] = "C1"
                        elif key_bit == "P":
                            key_bits[i] = "P1"
                        if "C" in key_bit or "P" in key_bit:
                            key_bits_new.append(key_bits[i].replace("^", ""))
                    key_new = "_".join(key_bits_new)
                    spline_args["P%d" % int(nominal_pressure)][key_new] = spline_args[
                        "P%d" % int(nominal_pressure)
                    ][key]

        ec = EmpiricalCompound(
            cid,
            gas_sample.get_conc(cid),
            pressure_measurement_type,
            gas_sample.get_matrix(),
            version,
            data_collection_date,
            nominal_concentration,
            nominal_pressure,
            spline_args,
        )
    else:
        ec = None
    return ec


def get_model_functions(nurange=[5840, 6170], pNominal=140, conc=1e-9, PCE_names=None):
    savefn = "model_functions_P%d_%d_%d.pkl" % (pNominal, *nurange)
    try:
        with open(savefn, "rb") as inpkl:
            MF = pickle.load(inpkl)
    except:
        print("loading model functions...")
        gases = stoolie.survey_library_for_ecompounds(version=2)
        gases.sort(key=lambda s: s["cid"])
        db = database.SpectralDatabase()
        MF = {}
        for gas in gases:
            cid = gas["cid"]
            searchy = {
                x: gas[x]
                for x in ["cid", "dataCollectionDate", "version", "splineCreationDate"]
            }
            searchy["pNominal"] = pNominal
            ec = get_single_gas(db, cid, nurange, searchy, conc=conc)
            if ec:
                MF[cid] = ec
            elif PCE_names is not None:
                print(
                    "No valid model function for %s (%s)"
                    % (PCE_names[cid], gas["dataCollectionDate"])
                )
            else:
                print(
                    "No valid model function for %s (%s)"
                    % (HTM.PubChemEntry(cid), gas["dataCollectionDate"])
                )
        with open(savefn, "wb") as outpkl:
            pickle.dump(MF, outpkl, 1)
    return MF
