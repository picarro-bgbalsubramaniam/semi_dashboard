import re
import collections
from voc_fitter.model.library import database


class PubChemEntry(object):
    def __init__(self, cid, download_unknown_entry=False):
        self.cid = cid
        self.download_unknown_entry = download_unknown_entry
        self.entry = self.getPubChemRecord(cid)

    def getPubChemRecord(self, cid):
        S = database.SpectralDatabase().MDB.db
        pubchem = S.pubChemEntries
        searcher = {"cid": cid}
        # FIXME: if not found, there should be a method of downloading the entry from PubChem
        entry = pubchem.find_one(searcher)
        return entry

    def parseFormula(self):
        pattern = r"(\D+)(\d*)"
        formula = self.entry["molecularFormula"]
        if formula == "H3N":
            formula = "NH3"
        groups = re.findall(pattern, formula)
        txt = ""
        for alph, num in groups:
            if len(num) == 0:
                txt += alph
            else:
                txt += alph + "_{" + num + "}"
        return txt

    def __repr__(self):
        h = lambda name: self.entry[name]
        txt = "%d: %s (%s)" % (self.cid, h("commonName"), h("molecularFormula"))
        return txt


def survey_library_for_ecompounds(cid=None, version=None, dataCollectionDate=None):
    searchy = {}
    if cid:
        searchy["cid"] = cid
    if version:
        searchy["version"] = version
    if dataCollectionDate:
        searchy["dataCollectionDate"] = dataCollectionDate

    S = database.SpectralDatabase().MDB.db
    recs = S.EmpiricalSpectra.find(searchy)
    ecompid_list = []
    xtr_list = []
    for r in recs:
        ecompid = {
            k: r[k]
            for k in [
                "cid",
                "version",
                "dataCollectionDate",
                "dataType",
                "splineCreationDate",
            ]
        }
        if ecompid not in ecompid_list:
            xtr_list.append(database.extrema())
            ecompid_list.append(ecompid)
        dkeys = r["dataDict"].keys()
        akey = next(iter(dkeys))
        nuarray = r["dataDict"][akey]["nu"]
        xtr_list[ecompid_list.index(ecompid)].addData(nuarray)
    for j, x in enumerate(xtr_list):
        cid = ecompid_list[j]["cid"]
        ecompid_list[j].update(
            {"nustart": x.min, "nuend": x.max, "compound": str(PubChemEntry(cid))}
        )
    return ecompid_list
