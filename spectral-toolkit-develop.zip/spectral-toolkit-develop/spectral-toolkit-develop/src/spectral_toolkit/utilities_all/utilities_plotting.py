import os
from copy import deepcopy

import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

import spectral_toolkit.utilities_all.RellaColor as RC
from spectral_toolkit.utilities_all.utilities_for_pool import get_all_data, good_times

MATH = r"${%s}$"
wavenumbers = r"frequency " + MATH % r"[cm^{-1}]"


def plot_variable(
    x_name,
    y_name,
    df,
    prefix,
    figures_dir,
    df_mean=None,
    label_ave=False,
    scatter=False,
    var_lims={},
    start_date_time=None,
    end_date_time=None,
):
    good = good_times(df, start_date_time, end_date_time)

    data = get_all_data(y_name, df)[good]
    # plot the data.  You can use this interactive plot to select the time series you want in the step above
    kolor = RC.CuteNordicKnit()
    F = go.Figure()

    if x_name == "index":
        x_val = df.index[good]
    else:
        x_val = get_all_data(x_name, df)[good]
    if not scatter:
        F.add_trace(
            go.Scatter(
                x=x_val,
                y=data,
                marker_color=kolor.getNext(),
                line_width=1,
                name="%0.4e +- %0.4e" % (np.nanmean(data), np.nanstd(data)),
            )
        )
    else:
        F.add_trace(go.Scatter(x=x_val, y=data, marker_color=kolor.getNext()))

    if df_mean is not None:
        good = good_times(df_mean, (start_date_time, end_date_time))
        if x_name == "index":
            x_val = df_mean.index[good]
        else:
            x_val = get_all_data(x_name, df_mean)[good]
        data = get_all_data(y_name, df_mean)[good]
        F.add_trace(
            go.Scatter(x=x_val, y=data, marker_color=kolor.getNext(), line_width=1)
        )

    y_name_appended = deepcopy(y_name)
    if y_name in var_lims:
        if "min" in var_lims[y_name]:
            F.update_yaxes(range_min=var_lims[y_name]["min"])
            y_name_appended += "_zoom"
        if "max" in var_lims[y_name]:
            F.update_yaxes(range_max=var_lims[y_name]["max"])
            if "zoom" not in y_name_appended:
                y_name_appended += "_zoom"
    F.update_layout(xaxis_title=x_name, yaxis_title=y_name)

    flnm = "{prefix}_{x_name}_{y_name_appended}_ICA_timeseries".format(
        prefix=prefix, x_name=x_name, y_name_appended=y_name_appended
    )
    F.write_image(os.path.join(figures_dir, "%s.png" % flnm))
    F.write_json(os.path.join(figures_dir, "%s.json" % flnm))

    return F


# def add_trig_Plot(F, row, col, T, Y, color, trig, pull_clean_data, abs_vector):
#     F.add_trace(go.Scatter(x=T, y=Y, marker_color='#aaaaaa', lind_width=0.3), row=row, col=col)
#     if pull_clean_data:
#         T_new = trig.pull_clean_data(T, abs_vector=abs_vector)
#         Y_new = trig.pull_clean_data(Y, abs_vector=abs_vector)
#         bool_now = ~ np.isnan(T_new) & ~ np.isnan(Y_new)
#         F.add_trace(go.Scatter(x=T_new[bool_now], y=Y_new[bool_now], marker_color=color.getNext(), mode='markers'), row=row, col=col)
#     else:
#         F.add_trace(go.Scatter(x=T, y=Y, marker_color=color.getNext(), mode='markers'), row=row, col=col)
#     F.add_trace(go.Scatter(x=deepcopy(T)[trig.transitions], y=deepcopy(Y)[trig.transitions], marker_size=25, marker_style='line_ns', marker_color='#333333aa', mode='markers'), row=row, col=col)
#     # ax.scatter(deepcopy(T)[trig.transitions], deepcopy(Y)[trig.transitions],s=25, ec='#333333aa', zorder=1000, marker='|')
#     if len(trig.transitions)>2:
#         tY = trig(Y)
#         F.add_trace(go.Scatter(x=trig(T), y=tY, marker_style='circle', marker_color=color.getCurrent(), line_width=0.65, opacity=0.8), row=row, col=col)
#         # ax.scatter(trig(T), tY,s=25, ec='#333333aa', fc=color.getCurrent(), alpha=0.8, zorder=1000, marker='o', lw=0.65)
#         lower = min(tY)
#         upper = max(tY)
#         span = upper - lower
#         F.update_yaxes(range=[lower-0.2*span, upper+0.2*span],row=row,col=col)
#         # ax.set_ylim([lower-0.2*span, upper+0.2*span])

# def plot_n_compounds_triggered(trig, df, abs_vector, compound_names, trigger_name, extra_ending='n_compounds'):
#     if len(compound_names)>0:
#         kolor = RC.PsychedelicChakra()
#         F = make_subplots(rows=len(compound_names), cols=1)
#         F.update_layout(height=len(compound_names)*1.25*100, width=6.0*100)
#         if len(compound_names)==1:
#             name = compound_names[0]
#             add_trig_Plot(F, 1, 1, abs_vector, get_all_data(name, df), kolor, trig, True, abs_vector)
#             F.update_layout(yaxis_title=name, xaxis_title='time', row=1, col=1)
#         else:
#             for j, name in enumerate(compound_names):
#                 add_trig_Plot(F, j+1, 1, abs_vector, get_all_data(name, df), kolor, trig, True, abs_vector)
#                 F.update_layout(yaxis_title=name, row=j+1, col=1)
#                 if j == len(compound_names)-1:
#                     F.update_layout(xaxis_title='time', row=j+1, col=1)
#                 else:
#                     F.update_layout(xaxis_tickvals=[], row=j+1, col=1)
#         fname_suffix = 'basicSummary_%s_%s'%(extra_ending,trigger_name)
#         return (F, fname_suffix)
#     return None

# def plot_n_compound_segment_stats(trigger_name, compound_names, trig_df):
#     if len(compound_names)>0:
#         F = make_subplots(rows=len(compound_names), cols=1)
#         F.update_layout(height=len(compound_names)*1.25*100, width=6.0*100)
#         if len(compound_names)==1:
#             compound_name = compound_names[0]
#             F.add_trace(go.Scatter(x=trig_df['%s_mean'%(trigger_name)],y=trig_df['%s_std'%compound_name]),row=1,col=1)
#             F.update_layout(yaxis_title='%s StDev'%compound_name, xaxis_title='%s Concentration (average per step)'%trigger_name, row=1, col=1)
#         else:
#             for j,compound_name in enumerate(compound_names):
#                 F.add_trace(go.Scatter(x=trig_df['%s_mean'%(trigger_name)],y=trig_df['%s_std'%compound_name]), row=j+1, col=1)
#                 F.update_layout(yaxis_title='%s StDev'%compound_name, row=j, col=1)

#                 if j == len(compound_names)-1:
#                     F.update_layout(xaxis_title='%s Concentration (average per step)'%trigger_name, row=j+1, col=1)
#                 else:
#                     F.update_layout(xaxis_tickvals=[], row=j, col=1)
#         return F
#     return None


def ICA_model_function_plot(results, ica_results, prefix, figures_dir, applied=False):
    """
    plot all of the unmixing matrices from the ICA analysis (pseudo model functions)

    INPUT
    applied: If true use the model functions in self.results. If false, use the model functions in self.ica
    """
    if applied:
        model_functions_dict = results["model_functions"]
        nu = results["nu"]
    else:
        model_functions_dict = ica_results["model_functions"]
        nu = ica_results["nu"]

    sub_max = len(model_functions_dict)
    F = make_subplots(rows=sub_max, cols=1, shared_xaxes=True)
    F.update_layout(height=10.0 * 100, width=12.8 * 100)

    for i, (name, values) in enumerate(model_functions_dict.items()):
        index = np.intersect1d(np.where(~np.isnan(nu)), np.where(~np.isnan(values)))
        F.add_trace(go.Scatter(x=nu[index], y=values[index]), row=i + 1, col=1)
        F.update_yaxes(title_text=name, row=i + 1, col=1)
    F.update_xaxes(title_text="wavenumber", row=i + 1, col=1)

    flnm = "{prefix}_model_functions".format(prefix=prefix)
    F.write_image(os.path.join(figures_dir, "%s.png" % flnm))
    F.write_json(os.path.join(figures_dir, "%s.json" % flnm))


def ICA_canary_function_plot(ica_results, prefix, figures_dir):
    """
    plot all of the unmixing matrices from the ICA analysis (pseudo model functions)
    """

    model_functions_dict = ica_results["model_functions"]

    sub_max = len(model_functions_dict)
    F = make_subplots(rows=sub_max, cols=1, shared_xaxes=True)
    F.update_layout(height=10.0 * 100, width=12.8 * 100)

    for i, (name, values) in enumerate(model_functions_dict.items()):
        F.add_trace(
            go.Scatter(x=ica_results["canary_names"], y=values, mode="markers"),
            row=i + 1,
            col=1,
        )
        F.update_yaxes(title_text=name, row=i + 1, col=1)
    F.update_xaxes(title_text="wavenumber", row=i + 1, col=1)

    flnm = "{prefix}_canary_model_functions".format(prefix=prefix)
    F.write_image(os.path.join(figures_dir, "%s.png" % flnm))
    F.write_json(os.path.join(figures_dir, "%s.json" % flnm))


def plot_spectrum(
    nu,
    loss,
    fit,
    figures_dir,
    EXPT,
    std_res=None,
    mf_rmse=None,
    save_str=None,
    cid_list=[],
    title="",
):
    loss_integral = np.sum(loss)

    plots = []
    plots.append(((0, 2), (0, 1)))
    plots.append(((2, 3), (0, 1)))

    F = make_subplots(
        rows=3, cols=1, specs=[[{"rowspan": 2}], [None], [{}]], shared_xaxes=True
    )
    F.update_layout(height=10.0 * 100, width=12.8 * 100, title_text=title)

    kol = RC.SeventiesFunk(brtValue=0.25)
    F.add_trace(
        go.Scatter(
            x=nu,
            y=loss,
            marker_size=5,
            marker_color="black",
            mode="markers",
            name="data",
        ),
        col=1,
        row=1,
    )
    F.add_trace(
        go.Scatter(
            x=nu,
            y=fit.fity,
            line_width=2,
            opacity=0.4,
            marker_color=kol.getNext(),
            name="fit",
        ),
        col=1,
        row=1,
    )

    count = 0
    for mf, nm, val in zip(fit.Alist, fit.parameterNames, fit.result):
        mf_integral = np.sum(mf * val)
        if count <= len(cid_list) - 1:
            lw = 3
        else:
            lw = 0.7
        F.add_trace(
            go.Scatter(
                x=nu,
                y=mf * val,
                marker_color=kol.getNext(),
                line_width=lw,
                name="%.2f ppb, %.2f pct %s"
                % (val, 100 * mf_integral / loss_integral, nm),
                textfont_size=8,
            ),
            row=1,
            col=1,
        )

        count += 1

    if std_res and mf_rmse:
        F.add_annotation(
            text="std. dev. res. = %.6f | mf rmse = %.6f" % (std_res, mf_rmse),
            font=dict(size=12, color="#4444ff"),
            xref="paper",
            yref="paper",
            x=0.03,
            y=0.03,
            showarrow=False,
        )
    F.add_trace(
        go.Scatter(x=nu, y=fit.residuals, marker_color="grey", name="residuals"),
        row=3,
        col=1,
    )

    F.update_xaxes(title_text=wavenumbers, row=1, col=1)
    F.update_yaxes(title_text="loss [wacky units]", row=1, col=1)
    F.update_xaxes(title_text=wavenumbers, row=3, col=1)
    F.update_yaxes(title_text="loss [wacky units]", row=3, col=1)
    if save_str:
        fname = "%s_CID%s" % (EXPT, save_str)
    else:
        fname = EXPT
    F.write_image(os.path.join(figures_dir, "%s.png" % fname))
    F.write_json(os.path.join(figures_dir, "%s.json" % fname))

    return F


def plot_FOM_spectra(FOM_name, event_fit_dict, event_now, name, figure_dir):
    numean = event_fit_dict["numean"]
    fit_array = event_fit_dict["fit_array"]
    spectral_FOM = event_fit_dict["spectral_FOM"]

    start_date_time = event_now["times"][0]
    end_date_time = event_now["times"][1]

    # plot all corrected spectra
    kol2 = RC.PsychedelicChakra(brtValue=+0.15)
    figure_num = 10
    if len(numean) <= figure_num and len(numean) > 0:
        titles_list = []
        for key in range(len(numean)):
            titles_list.append("nu=%.4f" % numean[key])
        F = make_subplots(rows=len(numean), cols=1, subplot_titles=titles_list)
        F.update_layout(height=len(numean) * 2 * 100, width=8 * 100)

        for key in range(len(numean)):
            F.add_trace(
                go.Scatter(
                    x=spectral_FOM,
                    y=fit_array[key, :],
                    marker_color=kol2.getNext(),
                    mode="markers",
                ),
                row=key + 1,
                col=1,
            )

            line_coef = [event_fit_dict["slope"][key], event_fit_dict["offset"][key]]
            F.add_trace(
                go.Scatter(
                    x=spectral_FOM,
                    y=np.polyval(line_coef, spectral_FOM),
                    name="y = %.4e x + %.4e" % (line_coef[1], line_coef[0]),
                    marker_color="black",
                ),
                row=key + 1,
                col=1,
            )
            if key == len(numean) - 1:
                F.update_xaxes(title_text=FOM_name, row=key + 1, col=1)
            if key == int(len(numean) / 2):
                F.update_yaxes(title_text="partial fit absorbance", row=key + 1, col=1)

        fname = "%s_%s_%s_%s_FOM_correlation" % (
            start_date_time,
            end_date_time,
            FOM_name,
            name,
        )
        F.write_image(os.path.join(figure_dir, "%s.png" % fname))
        F.write_json(os.path.join(figure_dir, "%s.json" % fname))
    else:
        for i in range(int(np.ceil(len(numean) / figure_num))):
            kol2 = RC.PsychedelicChakra(brtValue=+0.15)
            nu_now = numean[i * figure_num : (i + 1) * figure_num]
            titles_list = []
            for key in range(len(nu_now)):
                titles_list.append("nu=%.4f" % nu_now[key])
            F = make_subplots(rows=len(nu_now), cols=1, subplot_titles=titles_list)
            F.update_layout(height=len(nu_now) * 2 * 100, width=8 * 100)

            for key in range(len(nu_now)):
                if len(nu_now) > 1:
                    F.add_trace(
                        go.Scatter(
                            x=spectral_FOM,
                            y=fit_array[i * figure_num + key, :],
                            marker_color=kol2.getNext(),
                            mode="markers",
                        ),
                        row=key + 1,
                        col=1,
                    )

                    line_coef = [
                        event_fit_dict["slope"][i * figure_num + key],
                        event_fit_dict["offset"][i * figure_num + key],
                    ]
                    F.add_trace(
                        go.Scatter(
                            x=spectral_FOM,
                            y=np.polyval(line_coef, spectral_FOM),
                            name="y = %.4e x + %.4e" % (line_coef[1], line_coef[0]),
                            marker_color="black",
                        ),
                        row=key + 1,
                        col=1,
                    )
                    if key == len(nu_now) - 1:
                        F.update_xaxes(title_text=FOM_name, row=key + 1, col=1)
                    if key == int(len(nu_now) / 2):
                        F.update_yaxes(
                            title_text="partial fit absorbance", row=key + 1, col=1
                        )
                else:
                    F.add_trace(
                        go.Scatter(
                            x=spectral_FOM,
                            y=fit_array[i * figure_num + key, :],
                            marker_color=kol2.getNext(),
                            mode="markers",
                        ),
                        row=key + 1,
                        col=1,
                    )

                    line_coef = [
                        event_fit_dict["slope"][i * figure_num + key],
                        event_fit_dict["offset"][i * figure_num + key],
                    ]
                    F.add_trace(
                        go.Scatter(
                            x=spectral_FOM,
                            y=np.polyval(line_coef, spectral_FOM),
                            name="y = %.4e x + %.4e" % (line_coef[1], line_coef[0]),
                            marker_color="black",
                        ),
                        row=key + 1,
                        col=1,
                    )
                    F.update_xaxes(title_text=FOM_name, row=key + 1, col=1)
                    F.update_yaxes(
                        title_text="partial fit absorbance", row=key + 1, col=1
                    )
            fname = "%s_%s_%s_%s_%d_FOM_correlation" % (
                start_date_time,
                end_date_time,
                FOM_name,
                name,
                i,
            )
            F.write_image(os.path.join(figure_dir, "%s.png" % fname))
            F.write_json(os.path.join(figure_dir, "%s.json" % fname))

    F = go.Figure()
    F.add_trace(go.Scatter(x=event_fit_dict["numean"], y=event_fit_dict["slope"]))
    F.update_layout(xaxis_title="nu mean")
    F.update_layout(yaxis_title="slope")
    fname = "%s_%s_%s_%s_FOM_slope_spectra" % (
        start_date_time,
        end_date_time,
        FOM_name,
        name,
    )
    F.write_image(os.path.join(figure_dir, "%s.png" % fname))
    F.write_json(os.path.join(figure_dir, "%s.json" % fname))


def plot_normalized_signals(
    precision_dict, df, time_name, start_date_time, run_suffix, figure_dir
):
    if precision_dict is not None:
        kol2 = RC.PsychedelicChakra(brtValue=+0.15)
        F = go.Figure()
        if time_name == "index":
            time_now = df.index
        else:
            time_now = get_all_data(time_name, df)
        for var_name in precision_dict:
            try:
                name_now = "normalized_" + var_name
                data = get_all_data(name_now, df)
            except:
                try:
                    name_now = var_name
                    data = get_all_data(name_now, df)
                except:
                    break
            F.add_trace(
                go.Scatter(
                    x=time_now, y=data, marker_color=kol2.getNext(), name=name_now
                )
            )
        F.add_hline(y=-1, line_color="grey", line_dash="dash")
        F.add_hline(y=-2, line_color="red", line_dash="dash")

        fname = "%s_%s_normalized_series" % (start_date_time, run_suffix)
        F.write_image(os.path.join(figure_dir, "%s.png" % fname))
        F.write_json(os.path.join(figure_dir, "%s.json" % fname))


def plot_all(
    var_names, start_date_time, end_date_time, df, time_name, run_suffix, figure_dir
):
    for var_name in var_names:
        if var_name in df:
            F, y_name_appended = plot_variable(time_name, var_name, df, label_ave=True)
            fname = "%s_%s_%s_%s_%s_timeseries" % (
                start_date_time,
                end_date_time,
                run_suffix,
                time_name,
                y_name_appended,
            )
            F.write_image(os.path.join(figure_dir, "%s.png" % fname))
            F.write_json(os.path.join(figure_dir, "%s.json" % fname))


def plot_found_peaks(
    time_vector,
    y_vector,
    peak_inds,
    peaks_left,
    peaks_right,
    time_name,
    y_name,
    prefix,
    figures_dir,
):
    F = go.Figure()
    F.add_trace(go.Scatter(x=time_vector, y=y_vector, line_color="grey"))
    F.update_layout(xaxis_title="time", yaxis_title=y_name)

    for ind, p_l, p_r in zip(peak_inds, peaks_left, peaks_right):
        F.add_vline(x=time_vector[ind], line_dash="solid", line_color="black")
        F.add_vline(x=time_vector[p_l], line_dash="dash", line_color="green")
        F.add_vline(x=time_vector[p_r], line_dash="dash", line_color="green")

    fname = "%s_%s_%s_found_peaks" % (prefix, time_name, y_name)
    F.write_image(os.path.join(figures_dir, "%s.png" % fname))
    F.write_json(os.path.join(figures_dir, "%s.json" % fname))


def plot_score_TVOC_ratio_timeseries(
    df, time_name, start_date_time_str, run_suffix, figures_dir
):
    score = get_all_data("broadband_spectrum_score", df)
    TVOC = get_all_data("broadband_simple_sum", df)
    time_val = get_all_data(time_name, df)

    kolor = RC.CuteNordicKnit()
    F = make_subplots(rows=3, cols=1, shared_xaxes=True)
    F.update_layout(height=10.0 * 100, width=12.8 * 100)
    F.add_trace(
        go.Scatter(x=time_val, y=score, mode="markers", marker_color=kolor.getNext()),
        row=1,
        col=1,
    )
    F.update_yaxes(title_text="spectrum score", row=1, col=1)

    F.add_trace(
        go.Scatter(x=time_val, y=TVOC, mode="markers", marker_color=kolor.getNext()),
        row=2,
        col=1,
    )
    F.update_yaxes(title_text="simple sum", row=1, col=1)

    F.add_trace(
        go.Scatter(
            x=time_val,
            y=score / np.abs(TVOC),
            mode="markers",
            marker_color=kolor.getNext(),
        ),
        row=3,
        col=1,
    )
    F.update_yaxes(title_text="abs(ratio)", row=3, col=1)
    F.update_xaxes(title_text=time_name, row=3, col=1)

    fname = "%s_%s_score_TVOC_timeseries.png" % (start_date_time_str, run_suffix)
    F.write_image(os.path.join(figures_dir, "%s.png" % fname))
    F.write_json(os.path.join(figures_dir, "%s.json" % fname))

    return F
