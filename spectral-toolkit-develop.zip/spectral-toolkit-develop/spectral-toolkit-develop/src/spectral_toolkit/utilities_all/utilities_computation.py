import numpy as np
from scipy.interpolate import splev

import spectral_toolkit.utilities_all.HitranDBModule as HTM
import spectral_toolkit.utilities_all.standard_least_squares as LSQ


def execute_fit(loss, weights, default_mf, default_names, new_mfs, new_names):
    ind_2_use = np.where(np.isnan(loss) != True)[0]
    mfs = new_mfs + default_mf
    pnames = new_names + default_names

    mf_2_use = []
    for mf in mfs:
        mf_2_use.append(mf[ind_2_use])

    return LSQ.LSQ(
        mf_2_use,
        loss[ind_2_use],
        e=weights[ind_2_use],
        parameterNames=pnames,
        bounds=(-np.inf, np.inf),
    )


def get_weights(nu, use_special_weight):
    w = 500 * 2e-4 / np.sqrt(np.ones(nu.shape) * 2)
    if use_special_weight:
        adjust = np.zeros(w.shape)
        for j, nu in enumerate(nu):
            num = sum((nu >= nu - 0.5) & (nu < nu + 0.5))
            adjust[j] = num
        w *= adjust
    return w


def create_required_mf(
    nu, MF, required_cids, unknown_splines={}, use_short_names=False
):
    default_mf = [np.ones(nu.shape)]
    default_names = ["offset"]
    for rcid in required_cids:
        default_mf.append(MF[rcid](nu, overwrite_cache=True))
        if use_short_names:
            nm = "%d" % rcid
        else:
            nm = "%s" % HTM.PubChemEntry(rcid)
        default_names.append(nm)
    for name in unknown_splines:
        this_mf = splev(nu, unknown_splines[name]["spline"])
        default_mf.append(this_mf)
        default_names.append(name)

    return (default_mf, default_names)


def compute_mf_rmse(fit, use_short_names=False, negative_exclude_list=[]):
    var = 0
    for vect, coeff, pname in zip(fit.Alist, fit.result, fit.parameterNames):
        if pname != "offset":
            if use_short_names:
                this_cid = int(pname)
            elif "unknown" in pname or "unk" in pname:
                this_cid = pname
            else:
                this_cid = int(pname.split(":")[0])
            if this_cid not in negative_exclude_list:
                scale = 0 if coeff >= 0 else 10
                var += scale * np.sum((vect * coeff) ** 2)
    return np.sqrt(var)


def calculated_combined_fom(
    std_res, mf_rmse, min_std_res, min_mf_rmse, std_res_factor=10, neg_factor=1
):
    if mf_rmse == 0:
        combined_fom = np.sqrt(std_res_factor * std_res**2 / min_std_res**2)
    else:
        combined_fom = np.sqrt(
            std_res_factor * std_res**2 / min_std_res**2
            + neg_factor * mf_rmse**2 / min_mf_rmse**2
        )
    return combined_fom
