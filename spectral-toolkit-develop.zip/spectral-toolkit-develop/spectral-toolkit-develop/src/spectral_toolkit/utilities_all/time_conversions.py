# -*- coding: utf-8 -*-
import datetime

import numpy as np

from spectral_toolkit.utilities_all.timestamp import unixTime

ORIGIN = datetime.datetime(datetime.MINYEAR, 1, 1, 0, 0, 0, 0)
UNIXORIGIN = datetime.datetime(1970, 1, 1, 0, 0, 0, 0)


def parse_time_date_to_fDOY(time_date):
    """
    convert an array of time and date ('%H:%M:%S.%f %Y-%m-%d') to fDOY

    """
    fDOY = np.ndarray((len(time_date)))
    d = datetime.datetime.now()
    for i, time_date_now in enumerate(time_date):  # convert DateTime to fDOY
        if time_date_now != "NaN":
            d = d.strptime(time_date_now, "%H:%M:%S.%f %Y-%m-%d")
            if int(d.strftime("%H")) < 8:
                d = d + datetime.timedelta(hours=12)
            fDOY[i] = (
                int(d.strftime("%j"))
                + d.hour / 24.0
                + d.minute / 60.0 / 24
                + d.second / 60.0 / 60 / 24
                + d.microsecond / 1000000.0 / 60 / 60 / 24
            )

            if fDOY[i] - fDOY[i - 1] < 0 and i > 0:
                fDOY[i] += 12 / 24.0
            elif abs(fDOY[i] - fDOY[i - 1]) > 1 / 60.0 / 24 and i > 0:
                fDOY[i] -= 12 / 24.0
        else:
            fDOY[i] = np.nan

    return fDOY


def parse_Markes_sequence_date_time_to_fDOY(time_date):
    """
    convert an array of time and date ('%m/%d/%y %H:%M') to fDOY

    """
    fDOY = np.ndarray((len(time_date)))
    date_list = list()
    time_list = list()
    d = datetime.datetime.now()
    if time_date != "NaN":
        d = d.strptime(time_date, "%Y/%m/%d %H:%M:%S")
        fDOY = (
            int(d.strftime("%j"))
            + d.hour / 24.0
            + d.minute / 60.0 / 24
            + d.second / 60.0 / 60 / 24
            + d.microsecond / 1000000.0 / 60 / 60 / 24
        )

        date_list.append(d.strftime("%Y%m%d"))
        time_list.append(d.strftime("%H%M%S"))
    else:
        fDOY = np.nan
        date_list.append(np.nan)
        time_list.append(np.nan)

    return (fDOY, date_list, time_list)


def parse_Markes_data_date_time_to_fDOY(time_date):
    """
    convert an array of time and date ('%m/%d/%y %H:%M') to fDOY

    """
    fDOY = np.ndarray((len(time_date)))
    d = datetime.datetime.now()
    for i, time_date_now in enumerate(time_date):  # convert DateTime to fDOY
        if time_date_now != "NaN":
            d = d.strptime(time_date_now, "%d/%m/%Y-%H:%M:%S ")
            fDOY[i] = (
                int(d.strftime("%j"))
                + d.hour / 24.0
                + d.minute / 60.0 / 24
                + d.second / 60.0 / 60 / 24
                + d.microsecond / 1000000.0 / 60 / 60 / 24
            )

            if fDOY[i] - fDOY[i - 1] < 0 and i > 0:
                fDOY[i] += 12 / 24.0
            elif abs(fDOY[i] - fDOY[i - 1]) > 1 / 60.0 / 24 and i > 0:
                fDOY[i] -= 12 / 24.0
        else:
            fDOY[i] = np.nan
    return fDOY


def datetime_to_fDOY(dt):
    """
    convert python datetime to fDOY
    """
    fDOY = (
        int(dt.strftime("%j"))
        + dt.hour / 24.0
        + dt.minute / 60.0 / 24
        + dt.second / 60.0 / 60 / 24
        + dt.microsecond / 1000000.0 / 60 / 60 / 24
    )

    return fDOY


def timestamp_to_fDOY(timestamp):
    """
    convert timestamp (since 1970, or year 0) to fractional day of year
    """
    try:
        if timestamp.dtype != float:
            timestamp = timestamp.astype(np.float)
        first_timestamp = timestamp[0]

        if first_timestamp > 5e13:
            for i in range(len(timestamp)):
                if timestamp[i] != "Nan" and timestamp[i] != "nan":
                    if not np.isnan(timestamp[i]):
                        timestamp[i] = unixTime(timestamp[i])
        timestamp_length = len(timestamp)
    except:
        if timestamp.dtype != float:
            timestamp = np.float(timestamp)

        if timestamp > 5e13 and not np.isnan(timestamp):
            timestamp = unixTime(timestamp)
        timestamp_length = 1

    dt_str = list()
    if timestamp_length == 1:
        if not np.isnan(timestamp):
            dt = datetime.datetime.fromtimestamp(timestamp)
            #            dt_str.append(dt.strftime('%H:%M:%S.%f %Y-%m-%d'))
            fDOY = (
                int(dt.strftime("%j"))
                + dt.hour / 24.0
                + dt.minute / 60.0 / 24
                + dt.second / 60.0 / 60 / 24
                + dt.microsecond / 1000000.0 / 60 / 60 / 24
            )
        else:
            dt_str.append("NaN")
    else:
        fDOY = np.ndarray((len(timestamp))) * np.nan
        for i, time_now in enumerate(timestamp):
            #        if np.issubdtype(time_now.dtype,np.str):
            #            if time_now!='NaN' and time_now!='nan':
            #                dt = datetime.datetime.fromtimestamp(float(time_now))
            #                dt_str.append(dt.strftime('%H:%M:%S.%f %Y-%m-%d'))
            #        elif not np.isnan(time_now):
            if not np.isnan(time_now):
                dt = datetime.datetime.fromtimestamp(time_now)
                fDOY[i] = (
                    int(dt.strftime("%j"))
                    + dt.hour / 24.0
                    + dt.minute / 60.0 / 24
                    + dt.second / 60.0 / 60 / 24
                    + dt.microsecond / 1000000.0 / 60 / 60 / 24
                )
            #                dt_str.append(dt.strftime('%H:%M:%S.%f %Y-%m-%d'))
            else:
                dt_str.append("NaN")
    #    fDOY = parse_time_date_to_fDOY(dt_str)

    return fDOY


def fDOY_to_datetime(fDOY, year):
    """
    convert fractional day of year (float) and year (integer) into a datetime variable
    """
    dt = datetime.datetime.strptime("%03.0f%d" % (np.floor(fDOY), year), "%j%Y")
    hour = (fDOY - np.floor(fDOY)) * 24.0
    minute = (hour - np.floor(hour)) * 60.0
    second = (minute - np.floor(minute)) * 60.0
    microsecond = (second - np.floor(second)) * 1e6

    hour = np.floor(hour)
    minute = np.floor(minute)
    second = np.floor(second)
    microsecond = np.int(np.round(microsecond))

    dt = dt + datetime.timedelta(
        hours=hour, minutes=minute, seconds=second, microseconds=microsecond
    )

    return dt


def timestamp_to_datetime(timestamp):
    """
    convert timestamp (since 1970, or year 0) to datetime
    """
    dt_list = []
    try:
        if timestamp.dtype != float:
            timestamp = timestamp.astype(np.float)
        first_timestamp = timestamp[0]

        if first_timestamp > 5e13:
            for i in range(len(timestamp)):
                if timestamp[i] != "Nan" and timestamp[i] != "nan":
                    if not np.isnan(timestamp[i]):
                        timestamp[i] = unixTime(timestamp[i])
        timestamp_length = len(timestamp)
    except:
        if timestamp.dtype != float:
            timestamp = np.float(timestamp)

        if timestamp > 5e13 and not np.isnan(timestamp):
            timestamp = unixTime(timestamp)
        timestamp_length = 1

    if timestamp_length == 1:
        if not np.isnan(timestamp):
            dt_list.append(datetime.datetime.fromtimestamp(timestamp))
    else:
        for i, time_now in enumerate(timestamp):
            if not np.isnan(time_now):
                dt_list.append(datetime.datetime.fromtimestamp(time_now))
    return dt_list


def timestr_to_fDOY(timestr):
    # if len(timestr)<=13:
    #     utc_time = datetime.datetime.strptime(timestr, "%Y%m%d_%H%M")
    # else:
    #     utc_time = datetime.datetime.strptime(timestr, "%Y%m%d_%H%M%S")
    fDOY = datetime_to_fDOY(timestr_to_datetime(timestr))
    return fDOY


def timestr_to_datetime(timestr):
    if len(timestr) <= 13:
        utc_time = datetime.datetime.strptime(timestr, "%Y%m%d_%H%M")
    else:
        utc_time = datetime.datetime.strptime(timestr, "%Y%m%d_%H%M%S")
    return utc_time


def update_time(vector: float, hr_offset: float, name="JULIAN_DAYS"):
    if name == "JULIAN_DAYS":
        factor = 1 / 24.0
    elif name == "timestamp" or name == "index":
        factor = 60.0 * 60.0

    vector = vector + hr_offset * factor

    return vector
