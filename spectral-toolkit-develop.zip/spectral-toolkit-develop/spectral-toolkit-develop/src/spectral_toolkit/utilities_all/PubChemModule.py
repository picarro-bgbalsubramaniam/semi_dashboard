# -*- coding: utf-8 -*-
"""
Created on Tue Jun 12 15:14:36 2018

@author: chris
"""

import os
import time
from typing import Optional, Any, Dict

import pubchempy as pcp
import requests
from IPython.display import Image as iImage
from IPython.display import display
import json
import csv
import copy

try:
    import openbabel.pybel as pybel
except:
    pass

import utilities_all.Schema as SpectralSchema


class BadPubChemSearch(Exception):
    pass


def downloadInfoFromPubChem(config):
    heading = "** Downloading PubChem Info from search list **"
    print()
    print("*" * len(heading))
    print(heading)
    print("*" * len(heading))
    print()

    # Shortened pub_chem_properties to pc_props
    pc_props = config
    getAdditionalInfo = pc_props[SpectralSchema.PubChem.KEY_GET_ADD_INFO]
    download2DImage = pc_props[SpectralSchema.PubChem.KEY_DOWNLOAD_2D_IMG]
    displayImagesIniPython = pc_props[SpectralSchema.PubChem.KEY_DISP_IMG_INI_PY]
    searchTermFn = pc_props[SpectralSchema.PubChem.KEY_SEARCH_TERM_FN]
    PubChemImagesDir = pc_props[SpectralSchema.PubChem.KEY_DATA_DIR]

    chemList = loadSearchTermList(searchTermFn)

    records = []
    updatedCIDs = []
    for st in chemList:
        downloadFlag = True

        if downloadFlag:
            rec = {}

            h = lambda x, y: rec.update({x: y})

            h("timeCreated", time.time())
            h("searchTerm", st)
            numRecords, result, CIDs = findCompoundOnPubChem(
                st, getAdditionalInfo=getAdditionalInfo
            )
            print(result)
            h("numRecords", numRecords)
            if numRecords != 1:
                h("comment", "bad PubChem search")
                searchDict = {"searchTerm": st}
            else:
                h("comment", "PubChem download successful")
                h("cid", result.CID)
                h("iupacName", result.C.iupac_name)
                h("commonName", result.commonName)
                h("molecularWeight", result.C.molecular_weight)
                h("molecularFormula", result.C.molecular_formula)
                h("commonSynonyms", result.C.synonyms[0:10])
                if getAdditionalInfo:
                    h("CAS", result.CAS)
                    h("boilingPoint", result.BoilingPoint)
                    h("meltingPoint", result.MeltingPoint)
                if download2DImage:
                    imageFN = result.get2DImage(outDIR=PubChemImagesDir)
                    h("imageFileName", imageFN)

            records.append(rec)

            updatedCIDs.append(result.CID)
            print("---- " * 5)
    return records


def loadSearchTermList(searchTermFn):
    homeDIR = os.path.dirname(os.path.realpath(__file__))
    searchTermFn = os.path.join(homeDIR, searchTermFn)
    chemList = []
    with open(searchTermFn, "r") as MCL:
        infile = csv.reader(MCL, delimiter=",", quotechar='"')
        for row in infile:
            if len(row) == 1:
                if len(row[0]) > 1:
                    chemList.append(row[0])
    return chemList


def findCompoundOnPubChem(name, getAdditionalInfo=False):
    """give it a search term; returns #compounds found, the pubchem data, and the CIDs"""

    query = pcp.get_compounds(name, "name")

    if len(query) > 0:
        CIDs = [q.cid for q in query]
        K = PubChemCompound(query[0].cid, getAdditionalInfo)
    else:
        CIDs = None
        K = None
    return len(query), K, CIDs


class PubChemCompound:
    image2dURL = r"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/%d/PNG"
    imageBaseName = "CID%d_2D_Image.png"
    PUG_VIEW = r"https://pubchem.ncbi.nlm.nih.gov/rest/pug_view/data/compound/%d/JSON"
    # PUG_REST_TITLE = r'https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/%d/description/JSON' #get general name of compound used to work
    PUG_REST_TITLE = r"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/%d/synonyms/JSON"  # get general name of compound | pubchem format appears to have changed (20190701)

    def __init__(self, CID, downloadAdditionalInfo):
        self.CID = CID
        self.getRecord()
        self.downloadAdditionalInfo = downloadAdditionalInfo
        if self.downloadAdditionalInfo:
            self.getAdditionalInfo()

    def getRecord(self):
        self.C = pcp.Compound.from_cid(self.CID)
        # get common name
        thisURL = self.PUG_REST_TITLE % self.CID
        this = requests.get(thisURL)
        results = json.loads(this.content)
        # self.commonName = results['InformationList']['Information'][0]['Title'] old format
        self.commonName = results["InformationList"]["Information"][0]["Synonym"][
            0
        ]  # new format 20190701

    def get2DImage(self, outDIR=None, showImage=False):
        self.imagePNG = self.imageBaseName % self.CID
        if outDIR is not None:
            self.imagePNG = os.path.join(outDIR, self.imagePNG)
        thisURL = self.image2dURL % self.CID
        response = requests.get(thisURL)
        if response.status_code == 200:
            with open(self.imagePNG, "wb") as out_file:
                out_file.write(response.content)
            out_file.close()
            if showImage:
                display(iImage(self.imagePNG))
        return self.imagePNG

    def generate2DImage(
        self, outDIR: Optional[str] = None, showImage: bool = False
    ) -> Optional[str]:
        """
        Generate a 2d image of the molecule from its SMILES representation
        """
        if outDIR is None and not showImage:
            # Image is not to be saved nor shown so no reason to do calculations
            return

        molecule = pybel.readstring("smi", self.C.isomeric_smiles)

        fileName = None
        if outDIR is not None:
            self.imagePNG = self.imageBaseName % self.CID
            fileName = os.path.join(outDIR, self.imagePNG)

        molecule.draw(show=showImage, filename=fileName)

        if outDIR is not None:
            return self.imagePNG

    def getAdditionalInfo(self):
        thisURL = self.PUG_VIEW % self.CID
        this = requests.get(thisURL)
        results = json.loads(this.content.decode("utf-8", "ignore"))
        self.CAS = self.pullInfoFromRecord(
            results,
            ["Names and Identifiers", "Other Identifiers", "CAS"],
            returnAll=True,
            verbose=False,
        )
        self.BoilingPoint = self.pullInfoFromRecord(
            results,
            [
                "Chemical and Physical Properties",
                "Experimental Properties",
                "Boiling Point",
            ],
            returnAll=True,
            verbose=False,
        )
        self.MeltingPoint = self.pullInfoFromRecord(
            results,
            [
                "Chemical and Physical Properties",
                "Experimental Properties",
                "Melting Point",
            ],
            returnAll=True,
            verbose=False,
        )

    def pullInfoFromRecord(self, Z, headingList, returnAll=False, verbose=False):
        data = Z["Record"]["Section"]
        for j, heading in enumerate(headingList):

            foundFlag = False
            for i, d in enumerate(data):
                # if verbose: print d['TOCHeading'], i
                if d["TOCHeading"] == heading:
                    foundFlag = True
                    if j != len(headingList) - 1:
                        data = data[i]["Section"]
                    else:
                        data = data[i]["Information"]
            if not foundFlag:
                # did not find entry
                return "not found"

        if verbose:
            print(data)
        uniques = []
        nums = []
        for d in data:
            if verbose:
                print("x" * 20)
                print(d)
            y = d["Value"]["StringWithMarkup"][0]["String"]
            # this had to be changed 20190606 -- PubChem changed their record definition?
            # not sure, and not sure how robust this is
            if y not in uniques:
                uniques.append(y)
                nums.append(1)
            else:
                i = uniques.index(y)
                nums[i] += 1

        uniques = [x for _, x in sorted(zip(nums, uniques), reverse=True)]
        if returnAll:
            return "\n     ".join(uniques).encode("ascii", "ignore")
        else:
            return uniques[0].encode("ascii", "ignore")

    def createDBRecord(
        self,
        searchTerm: str = "search by CID",
        numRecords: int = 1,
        download2DImage: bool = False,
        pubChemImagesDir: str = ".",
    ) -> Dict[str, Any]:
        rec = {}
        h = lambda x, y: rec.update({x: y})

        h("timeCreated", time.time())
        h("searchTerm", searchTerm)
        h("numRecords", numRecords)
        if numRecords != 1:
            h("comment", "bad PubChem search")
            searchDict = {"searchTerm": searchTerm}
        else:
            h("comment", "PubChem download successful")
            h("cid", self.CID)
            h("iupacName", self.C.iupac_name)
            h("commonName", self.commonName)
            MW = copy.copy(self.C.molecular_weight)
            if type(MW) is str:
                MW = float(MW)
            h("molecularWeight", MW)
            h("molecularFormula", self.C.molecular_formula)
            h("commonSynonyms", self.C.synonyms[0:10])
            if self.downloadAdditionalInfo:
                h("CAS", self.CAS)
                h("boilingPoint", self.BoilingPoint)
                h("meltingPoint", self.MeltingPoint)
            if download2DImage:
                imageFN = self.get2DImage(outDIR=pubChemImagesDir)
                h("imageFileName", imageFN)
        return rec

    def __str__(self):
        R = self.C
        txt = []
        txt.append(
            "%s: %s (iupac: %s)" % (R.synonyms[0], R.molecular_formula, R.iupac_name)
        )
        txt.append("CID: %d" % R.cid)
        txt.append("Molecular weight: %s" % R.molecular_weight)
        try:
            txt.append("CAS: %s" % self.CAS.decode("utf-8"))
            txt.append("Boiling point:\n     %s" % self.BoilingPoint.decode("utf-8"))
            txt.append("Melting point:\n     %s" % self.MeltingPoint.decode("utf-8"))
        except:
            pass
        outtxt = "\n".join(txt)
        return outtxt


if __name__ == "__main__":
    C = PubChemCompound(241, True)
    print(C)
    C.generate2DImage(showImage=True)
