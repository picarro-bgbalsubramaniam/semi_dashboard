import logging
import time
from typing import Any, Dict, List, Optional, Tuple, Union

import numpy as np
from pymongo import MongoClient  # typing
from pymongo.database import Database  # typing
from pymongo.encryption import ClientEncryption
from scipy.interpolate import RectBivariateSpline, UnivariateSpline

from spectral_toolkit.data_models.model_function import Spline1d, Spline2d, SplinePoly
from spectral_toolkit.logger import get_logger
from spectral_toolkit.utils import timed_lru_cache


LOGGER = get_logger(__name__)

# These are "data types" that are keys present in the mongo database. Fragile, but it works.
ONE_PRESSURE = "OnePressure"
THREE_PRESSURE = "ThreePressure"
POLYNOMIAL = "PolynomialCandP"

# These are strings that are keys present in the polynomial splines
OFFSET = "offset"
C1_P1 = "C x P"
C1_P2 = "C x P^2"
C2_P1 = "C^2 x P"
C1_P3 = "C x P^3"
C2_P2 = "C^2 x P^2"
C3_P1 = "C^3 x P"

# For creating a lookup dict from cid
DEFAULT_PUBCHEM_PARAMS = [
    "commonName",
    "molecularWeight",
    "molecularFormula",
    "iupacName",
]

PRESSURE_MAP = {
    140: {"low": 129, "hi": 151},
    300: {"low": 278, "hi": 322},
    450: {"low": 417, "hi": 483},
}

# This is the type which is used to decrpyt the library: 
EncryptionKey = Any


def get_client_encryption(client: Database, key: EncryptionKey) -> ClientEncryption:
    return ClientEncryption(key, "PicarroCompoundLibrary.__spectralLibraryKeyVault", client.client, client.EmpiricalSpectra.codec_options)


def closest_nominal_pressure(
    client: Database, cid: int, requested_pressure: float
) -> float:
    """
    Query the database and returns the available pressure
    that is closest to the requested pressure for the
    desired CID. If no data is found for the requested
    CID, an IndexError exception is raised.

    Args:
        client (Database): Database
        cid (int): CID for desired species
        requested_pressure (float): Requested pressure

    Returns:
        (float): Closest pressure recorded in database

    """
    query_results = client.EmpiricalSpectra.find(
        {"cid": cid, "version": 2}, {"pNominal": 1}
    ).distinct("pNominal")

    if query_results:
        abs_pressure_difference = [
            abs(requested_pressure - result) for result in query_results
        ]
        min_difference_index = abs_pressure_difference.index(
            min(abs_pressure_difference)
        )
        closest_pressure = query_results[min_difference_index]
    else:
        raise IndexError(f"No data found for CID {cid}")

    return closest_pressure


def model_function(
    client: Database,
    cid: int,
    nu_min: float,
    nu_max: float,
    desired_date: Optional[str] = None,
    nominal_pressure: float = 140.0,
    use_exact_pressure: bool = True,
    client_encryption: Optional[ClientEncryption] = None,
):
    """
    For a given set of CID, nu min, max, date, and nominal pressure, return a spline that can be
    evaluated with a ``nu`` array to create a "model function".

    If use_exact_pressure is True, only exact pressure matches are retrieved from the library.
    If False, the loss recorded at a different pressure
    (the closest available to nominal pressure) is used
    (resulting loss is scaled by ratio of nominal over libray pressure).
    Warning: ``use_exact_pressure = False`` is NOT appropriate for small molecules or Big3;
    it can provide an acceptable approximation for broadband spectra of other species.

    Note: Date arguments for the mongo version of the spectral library such as ``desired_date``
    follow a pattern of YYYYMMDD as a string, not a datetime object.

    Example usage:

    .. code-block:: python

        from spectral_toolkit.db_clients.mongo_spectral_library import get_mongo_spectral_library_client
        from spectral_toolkit.model_function.mongodb import model_function

        db_client = get_mongo_spectral_library_client()
        model = model_function(db_client, cid=280, nu_min=6050, nu_max=6060, nominal_pressure=140.0)

    """
    pressure_key = int(nominal_pressure)
    if pressure_key not in PRESSURE_MAP.keys():
        raise ValueError(f"Nominal Pressure {pressure_key} is not allowed")

    # If inexact match is allowed, get the closest pressure present in db
    query_pressure = (
        nominal_pressure
        if use_exact_pressure
        else closest_nominal_pressure(client, cid, nominal_pressure)
    )

    (
        data_collection_date,
        spline_creation_date,
    ) = _latest_data_collection_date_by_upload_time(
        client, cid, desired_date, query_pressure
    )

    spline_type, data_concentration = _get_spline_type_and_concentration(
        client, cid, query_pressure, data_collection_date, spline_creation_date
    )

    model_spline = _query_splines(
        spline_type,
        nu_min,
        nu_max,
        data_concentration,
        query_pressure,
        client=client,
        cid=cid,
        data_collection_date=data_collection_date,
        spline_creation_date=spline_creation_date,
        client_encryption=client_encryption,
    )

    pressure_within_bounds = (
        PRESSURE_MAP[pressure_key]["low"]
        <= query_pressure
        <= PRESSURE_MAP[pressure_key]["hi"]
    )

    if (not use_exact_pressure) & (not pressure_within_bounds):
        # Inexact match was allowed, and pressure outside bounds. Scaling is needed
        logging.warning(
            f"CID {cid:5}: requested pressure {nominal_pressure}T, found {query_pressure}T. "
            f"Will use pressure-scaled loss. "
            f"Please ensure this approximation is appropriate for your use case."
        )

        if spline_type == ONE_PRESSURE:
            model_spline.nominal_pressure = nominal_pressure
        else:
            raise NotImplementedError(
                f"Pressure scaling not implemented for spline type {spline_type}"
            )

    return model_spline.eval


def _query_splines(
    spline_type: str,
    nu_min: float,
    nu_max: float,
    data_concentration: float = None,
    nominal_pressure: float = None,
    client_encryption: Optional[ClientEncryption] = None,
    **kwargs,
):
    if spline_type == ONE_PRESSURE:
        records = _query_spline_1d(
            nominal_pressure=nominal_pressure, nu_min=nu_min, nu_max=nu_max, client_encryption=client_encryption, **kwargs
        )
        spline_args = _spline_1d_args(records, data_concentration, nominal_pressure)
        spline = Spline1d(nu_min=nu_min, nu_max=nu_max, **spline_args)

    elif spline_type == THREE_PRESSURE:
        records = _query_spline_2d(
            nominal_pressure=nominal_pressure, nu_min=nu_min, nu_max=nu_max, client_encryption=client_encryption, **kwargs
        )
        spline_args = _spline_2d_args(records, data_concentration, nominal_pressure)
        spline = Spline2d(nu_min=nu_min, nu_max=nu_max, **spline_args)

    elif spline_type == POLYNOMIAL:
        records = _query_spline_polynomial(
            nominal_pressure=nominal_pressure, nu_min=nu_min, nu_max=nu_max, client_encryption=client_encryption, **kwargs
        )
        spline_args = _spline_poly_args(records, nominal_pressure)
        spline = SplinePoly(nu_min=nu_min, nu_max=nu_max, **spline_args)
    else:
        raise NotImplementedError("Spline type not found")

    return spline


def _get_spline_type_and_concentration(
    client: Database,
    cid: int,
    nominal_pressure: float,
    data_collection_date: str,
    spline_creation_date: str,
) -> Tuple[Union[str, float]]:
    """Uses the mongodb spectral library client to find spline type and concentration of a
    molecule in the EmpiricalSpectra collection.
    """
    query = {
        "$and": [
            {"cid": cid},
            {"dataCollectionDate": data_collection_date},
            {"splineCreationDate": spline_creation_date},
            {"version": 2},
            {"pNominal": nominal_pressure},
        ]
    }
    projection = {"_id": 0, "dataType": 1, "calibration": 1}
    result = client.EmpiricalSpectra.find_one(query, projection=projection)

    # Choose the concentration from the latest calibration in the database records
    calibration_date = sorted(result["calibration"].keys())[-1]
    data_concentration = result["calibration"][calibration_date]["concentration"]

    data_type = result["dataType"]
    return data_type, data_concentration


def _latest_data_collection_date_by_upload_time(
    client: Database,
    cid: int,
    date_str: Optional[str] = None,
    nominal_pressure: Optional[float] = 140.0,
    encrypted: bool = False
) -> Tuple[str]:
    """Choose the latest ``dataCollectionDate`` for which ``splineCreationDate`` is prior to
    ``desired_date``. The ``desired_date`` must be a string with format YYYYMMDD.
    """
    if date_str is None:
        date_str = time.strftime("%Y%m%d", time.localtime())
    date_int = int(date_str)
    dates = set(
        [
            (x["dataCollectionDate"][-1], x["splineCreationDate"])
            for x in client.EmpiricalSpectra.find(
                {"cid": cid, "pNominal": nominal_pressure},
                {"dataCollectionDate": 1, "splineCreationDate": 1, "_id": 0},
            )
        ]
    )
    dates = sorted(dates, key=lambda x: int(x[1]))
    date_lambda = lambda x: int(x[1]) <= date_int
    dates_prior = list(filter(date_lambda, dates))
    if not dates_prior:
        raise ValueError(
            f"No records found prior to {date_str} for CID {cid}, with nominal pressure {nominal_pressure}"
        )
    data_collection_date = dates_prior[-1][0]
    spline_creation_date = dates_prior[-1][1]
    return (data_collection_date, spline_creation_date)


def _query_spline_1d(
    client,
    cid,
    nu_min,
    nu_max,
    nominal_pressure,
    data_collection_date,
    spline_creation_date,
    client_encryption: Optional[ClientEncryption] = None,
):
    pressure_key = int(nominal_pressure)
    if pressure_key not in PRESSURE_MAP.keys():
        raise ValueError(f"Nominal Pressure {pressure_key} is not allowed")
    query = {
        "$and": [
            {"cid": cid},
            {"dataCollectionDate": data_collection_date},
            {"splineCreationDate": spline_creation_date},
            {"version": 2},
            {"pNominal": nominal_pressure},
            {f"dataDict.P{pressure_key}.nu": {"$gte": nu_min}},
            {f"dataDict.P{pressure_key}.nu": {"$lte": nu_max}},
        ]
    }
    result = client.EmpiricalSpectra.aggregate(
        [
            {"$match": query},
            {
                "$group": {
                    "_id": None,  # This is required by mongodb
                    "nu": {"$push": f"$dataDict.P{pressure_key}.nu"},
                    "loss": {"$push": f"$dataDict.P{pressure_key}.loss"},
                    "Pop": {"$avg": f"$dataDict.P{pressure_key}.Pop"},
                }
            },
        ]
    )
    try:
        document = next(result)
    except StopIteration:
        raise ValueError(
            f"Splines 1d: No documents found for cid {cid} nominal pressure {nominal_pressure} and data_collection_date {data_collection_date}"
        )
    document.pop("_id")
    if client_encryption is not None:
        document["loss"] = [client_encryption.decrypt(loss) for loss in document["loss"]]
    return document


def _spline_1d_args(document, data_concentration, nominal_pressure):
    nu = np.concatenate(document["nu"])
    loss = np.concatenate(document["loss"])
    Pop = document["Pop"]
    scaled_loss = loss / Pop / data_concentration
    try:
        spline = UnivariateSpline(nu, scaled_loss, s=0, ext="raise")
    except ValueError:

        def clean_knots(nu, loss):
            sort_idx = np.argsort(nu)
            nu = nu[sort_idx]
            loss = loss[sort_idx]
            these = nu > 0
            for i in range(len(nu) - 1):
                if nu[i] == nu[i + 1]:
                    these[i + 1] = False
            return nu[these], loss[these]

        nu, loss = clean_knots(nu, loss)
        scaled_loss = loss / Pop / data_concentration
        spline = UnivariateSpline(nu, scaled_loss, s=0, ext="raise")

    return {"spline": spline, "nominal_pressure": nominal_pressure}


def _query_spline_2d(
    client: Database,
    cid: int,
    nu_min: float,
    nu_max: float,
    nominal_pressure: float,
    data_collection_date: str,
    spline_creation_date: str,
    client_encryption: Optional[ClientEncryption] = None,
):
    """Query the mongodb for a 2d spline object given paramaters to this function"""
    pressure_key = int(nominal_pressure)
    if pressure_key not in PRESSURE_MAP.keys():
        raise ValueError(f"Nominal Pressure {pressure_key} is not allowed")
    low_pressure = PRESSURE_MAP[pressure_key]["low"]
    hi_pressure = PRESSURE_MAP[pressure_key]["hi"]
    query = {
        "$and": [
            {"cid": cid},
            {"dataCollectionDate": data_collection_date},
            {"splineCreationDate": spline_creation_date},
            {"version": 2},
            {"pNominal": nominal_pressure},
            {f"dataDict.P{low_pressure}.nu": {"$gte": nu_min}},
            {f"dataDict.P{low_pressure}.nu": {"$lte": nu_max}},
        ]
    }
    result = client.EmpiricalSpectra.aggregate(
        [
            {"$match": query},
            {
                "$group": {
                    "_id": None,  # This is required by mongodb
                    f"nu_{low_pressure}": {"$push": f"$dataDict.P{low_pressure}.nu"},
                    f"loss_{low_pressure}": {
                        "$push": f"$dataDict.P{low_pressure}.loss"
                    },
                    f"operating_pressure_{low_pressure}": {
                        "$avg": f"$dataDict.P{low_pressure}.Pop"
                    },
                    f"nu_{pressure_key}": {"$push": f"$dataDict.P{pressure_key}.nu"},
                    f"loss_{pressure_key}": {
                        "$push": f"$dataDict.P{pressure_key}.loss"
                    },
                    f"operating_pressure_{pressure_key}": {
                        "$first": f"$dataDict.P{pressure_key}.Pop"
                    },
                    f"nu_{hi_pressure}": {"$push": f"$dataDict.P{hi_pressure}.nu"},
                    f"loss_{hi_pressure}": {"$push": f"$dataDict.P{hi_pressure}.loss"},
                    f"operating_pressure_{hi_pressure}": {
                        "$avg": f"$dataDict.P{hi_pressure}.Pop"
                    },
                }
            },
        ]
    )
    try:
        document = next(result)
    except StopIteration:
        raise ValueError(
            f"Splines 2d: No documents found for cid {cid} nominal pressure {nominal_pressure} and data_collection_date {data_collection_date}"
        )
    document.pop("_id")
    if client_encryption is not None:
        for pressure in [low_pressure, pressure_key, hi_pressure]:
            document[f"loss_{pressure}"] = [client_encryption.decrypt(loss) for loss in document[f"loss_{pressure}"]]
    return document


def _spline_2d_args(document, data_concentration, nominal_pressure):
    pressure_key = int(nominal_pressure)
    if pressure_key not in PRESSURE_MAP.keys():
        raise ValueError(f"Nominal Pressure {pressure_key} is not allowed")
    low_pressure = PRESSURE_MAP[pressure_key]["low"]
    hi_pressure = PRESSURE_MAP[pressure_key]["hi"]
    operating_pressure_names = [
        f"operating_pressure_{low_pressure}",
        f"operating_pressure_{pressure_key}",
        f"operating_pressure_{hi_pressure}",
    ]
    loss_names = [f"loss_{low_pressure}", f"loss_{pressure_key}", f"loss_{hi_pressure}"]
    widths = [document[x] / nominal_pressure for x in operating_pressure_names]
    scaled_loss = np.vstack(
        [
            np.concatenate(document[loss])
            / document[operating_pressure]
            / data_concentration
            for loss, operating_pressure in zip(loss_names, operating_pressure_names)
        ]
    ).T

    nu = np.concatenate(document[f"nu_{pressure_key}"])
    spline = RectBivariateSpline(nu, widths, scaled_loss, kx=3, ky=2)

    return {"spline": spline, "nominal_pressure": nominal_pressure, "width": 1.0}


def _query_spline_polynomial(
    client,
    cid,
    nu_min,
    nu_max,
    nominal_pressure,
    data_collection_date,
    spline_creation_date,
    client_encryption: Optional[ClientEncryption] = None,
):
    pressure_key = int(nominal_pressure)
    if pressure_key not in PRESSURE_MAP.keys():
        raise ValueError(f"Nominal Pressure {pressure_key} is not allowed")
    query = {
        "$and": [
            {"cid": cid},
            {"dataCollectionDate": data_collection_date},
            {"splineCreationDate": spline_creation_date},
            {"version": 2},
            {"pNominal": nominal_pressure},
            {f"dataDict.P{pressure_key}.nu": {"$gte": nu_min}},
            {f"dataDict.P{pressure_key}.nu": {"$lte": nu_max}},
        ]
    }

    result = client.EmpiricalSpectra.aggregate(
        [
            {"$match": query},
            {
                "$group": {
                    "_id": None,
                    "nu": {"$push": f"$dataDict.P{pressure_key}.nu"},
                    "C1_P1": {"$push": f"$dataDict.P{pressure_key}.{C1_P1}"},
                    "C1_P2": {"$push": f"$dataDict.P{pressure_key}.{C1_P2}"},
                    "C2_P1": {"$push": f"$dataDict.P{pressure_key}.{C2_P1}"},
                    "C1_P3": {"$push": f"$dataDict.P{pressure_key}.{C1_P3}"},
                    "C2_P2": {"$push": f"$dataDict.P{pressure_key}.{C2_P2}"},
                    "C3_P1": {"$push": f"$dataDict.P{pressure_key}.{C3_P1}"},
                }
            },
        ]
    )
    try:
        document = next(result)
    except StopIteration:
        raise ValueError(
            f"Polynomal splines: No documents found for cid {cid} nominal pressure {nominal_pressure} and data_collection_date {data_collection_date}"
        )
    document.pop("_id")
    if client_encryption is not None:
        for key in ["C1_P1", "C1_P2", "C2_P1", "C1_P3", "C2_P2", "C3_P1"]:
            document[key] = [client_encryption.decrypt(loss) for loss in document[key]]
    return document


def _spline_poly_args(document, nominal_pressure):
    nu = np.concatenate(document["nu"])
    arrays = {}
    arrays["C1_P1"] = np.concatenate(document["C1_P1"])
    arrays["C1_P2"] = np.concatenate(document["C1_P2"])
    arrays["C2_P1"] = np.concatenate(document["C2_P1"])
    arrays["C1_P3"] = np.concatenate(document["C1_P3"])
    arrays["C2_P2"] = np.concatenate(document["C2_P2"])
    arrays["C3_P1"] = np.concatenate(document["C3_P1"])

    sub_splines = {k: UnivariateSpline(nu, arrays[k], s=0, ext="zeros") for k in arrays}

    prefactors = {}
    # This code emulates voc-fitter's empirical spectrum for "polynomial" splines in concentration
    # and pressure
    a = (1.0, 0, 1.0)
    _conc = 0
    prefactors["offset"] = 0
    prefactors["C1_P1"] = a[2]
    prefactors["C1_P2"] = a[2] ** 2 * nominal_pressure
    prefactors["C1_P3"] = a[2] ** 3 * nominal_pressure**2
    prefactors["C2_P1"] = _conc * a[2]
    prefactors["C2_P2"] = _conc * a[2] ** 2 * nominal_pressure
    prefactors["C3_P1"] = _conc**2 * a[2]

    return {
        "sub_splines": sub_splines,
        "prefactors": prefactors,
        "nominal_pressure": nominal_pressure,
    }


def get_pubchem_info(
    client, cids: List = [], parameters: List = DEFAULT_PUBCHEM_PARAMS
):
    """
    Convenience fucntion to get certain pubchem properties
    for a list of cids and parameters.
    Args:
        client: the pymongo client
        cids: list of cids to get pubchem info for
        parameters: keys in pubchem documents to retrieve
    Returns:
        sorted dictionary with cid as key and requested key values from pubchem
    """
    if not cids:
        cids = client.EmpiricalSpectra.distinct("cid")
    cursor = client.pubChemEntries.find({"cid": {"$in": cids}})
    cid_map = {item["cid"]: {key: item[key] for key in parameters} for item in cursor}

    return dict(sorted(cid_map.items()))


@timed_lru_cache()
def get_model_functions(
    client,
    nu_min: int = 5800,
    nu_max: int = 6300,
    nominal_pressure: float = 140.0,
    use_exact_pressure: bool = False,
    query_cids: Optional[Tuple[int]] = (),
    client_encryption: Optional[ClientEncryption] = None,
) -> Dict[int, Union[Spline1d, Spline2d, SplinePoly]]:
    """
    Get a dictionary of cid and model function for every cid or cids specified in the library

    Args:
        nu_min (int, optional): minimum nu value to evaluate spline. Defaults to 5800.
        nu_max (int, optional): maximum nu value to evaluate spline. Defaults to 6300.
        nominal_pressure (float, optional): operating nominal pressure. Defaults to 140.0.
        use_exact_pressure (bool, optional): if true will not generate a model function if pressure doesn't match
        query_cids (Optional[Tuple[int]], optional): cids to get model functions for. Defaults to ().
    Returns:
        Dict: cid as key and model function data model
    """
    cids = client.EmpiricalSpectra.distinct("cid") if query_cids == () else list(query_cids)

    model_functions = {}
    for cid in cids:
        try:
            model_functions[cid] = model_function(
                client,
                cid=cid,
                nu_min=nu_min,
                nu_max=nu_max,
                nominal_pressure=nominal_pressure,
                use_exact_pressure=use_exact_pressure,
                client_encryption=client_encryption,
            )
        except Exception as e:
            LOGGER.warning(f"Unable to aquire model function for {cid}: {e}")

    return model_functions

def clear_mf_cache():
    """
    Convenience function to clear timed cache of model functions.
    Clears entire cache for instance.
    """
    get_model_functions.__wrapped__.cache_clear()
