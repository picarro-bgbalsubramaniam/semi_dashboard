from typing import List, Tuple, Optional, Dict

from datetime import timedelta
import numpy as np
import pandas as pd
from scipy.interpolate import interp1d
from sklearn.decomposition import FastICA

from spectral_arithmetic.data_models.spectra import BinnedSpectra
from spectral_arithmetic.linear_least_squares import least_squares
from spectral_toolkit.data_models import ica_models
from spectral_toolkit.logger import get_logger


LOGGER = get_logger(__name__)


def scale_by_noise(
    df: pd.DataFrame,
    canaries: List[str],
    lods: Dict[str, float],
    average_time: int = 100,
) -> pd.DataFrame:
    """
    Calculate figure of merit from lod values
    Arguments:
        df: pandas dataframe, typically of compact data
        canaries: list of canaries to calculate LOD for
        lods: dictionary with key of canary and LOD value
        average_time: averaging time used in LOD calculation
    """
    if 0 in lods.values():
        raise ValueError(f"LOD values can not contain 0")

    if not set(canaries).issubset(set(lods.keys())):
        raise ValueError("LOD values for scaling are defined for all canaries")

    df_fom = df.copy().reset_index(drop=True)
    scale = np.sqrt(average_time / df_fom["duration"].reset_index(drop=True))
    for canary in canaries:
        df_fom[canary] /= lods[canary] * scale

    return df_fom


def zero_reference_port_data(
    df: pd.DataFrame,
    canaries: List[str],
    zero_reference_time_window: int,
    reference_port: int,
    valve_key="ValveMask",
) -> pd.DataFrame:
    """
    Subtracts baseline offsets on reference port data from other port data
    Arguments:
        df: Dataframe with canaries and ValveKey in columns and datetime index
        canaires: list of canaries to zero reference
        zero_reference_time_window: number of seconds to use in rolling average
        reference_port: integer value of reference port
        valve_key: key for current port

    Returns:
        pd.DataFrame with zero referenced data
    """
    if not set(canaries).issubset(set(df.columns.tolist())):
        raise ValueError("Please make sure dataframe to be zero referenced contains all canaries passed")
    
    df_ref = df.copy()

    time_reference = df_ref.loc[df_ref[valve_key] == reference_port]
    total_time = (time_reference.index - time_reference.index[0]).total_seconds()
    window_frames = pd.DataFrame()

    # Get rolling window average
    for time in time_reference.index:
        start = time - timedelta(seconds=zero_reference_time_window)
        stop = time + timedelta(seconds=zero_reference_time_window)
        ref_data = time_reference.loc[start: stop]
        ave_data = ref_data[canaries].mean().to_frame().transpose()
        window_frames = pd.concat([window_frames, ave_data])

    # Fit across sampled data with linear fit and subtract from values
    data_total_times = (df_ref.index - df_ref.index[0]).total_seconds()
    for canary in canaries:
        spl = interp1d(total_time, window_frames[canary], fill_value="extrapolate")
        df_ref[canary] -= spl(data_total_times)

    return df_ref


def _intersect(spectra: List[BinnedSpectra]) -> BinnedSpectra:
    """
    Convenience to get the intersection of all the binned spectra
    Args:
        List of BinnedSpectra to perform intersection on
    Returns:
        BinnedSpectra after intersection
    """
    agg = spectra[0]
    for i in range(1, len(spectra)):
        agg = agg.intersect_binned_spectra(spectra[i])
    return agg


def correlation_fit(
    partial_fit_arr: np.ndarray, partial_fit_err_arr: np.ndarray, time_vect
):
    """
    Run least squares to get the slope and error for each port spectra.
    Args:
        data: 2D array of time series partial fit data
        err: 2D array of stderr partial fit data
        time_vect: reconstructed principle signal to optimize on
    Returns:
        slope terms of least squares fit
        slope std error of least squares fit
    """
    m, n = partial_fit_arr.shape
    ones = np.ones(m)
    slope_err = np.zeros(n)
    slope = np.zeros(n)
    for i in range(n):
        partial_fit = partial_fit_arr[:, i]
        partial_fit_err = partial_fit_err_arr[:, i]
        error = np.median(partial_fit_err)
        poly_fit, stats = least_squares(
            np.vstack((ones, time_vect)).T, partial_fit, ones * error
        )
        slope[i] = poly_fit[1]
        slope_err[i] = stats.std_dev[1]
    return (slope, slope_err)


def _create_specctrum_array(
    selected_spectra: List[BinnedSpectra], mode_list: List[int], single: bool = False
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Creates a convenient 2D array of spectral information from all compact spectra
    Arguments:
        selected_spectra: list of binned spectra.  Often for compact spectra on
                          different intervals for the same port
        mode_list: Modes from all spectra
    Returns:
        Tuple with spectra 2D np.array and error vector 2D np.array.  Stacked in consecutively
    """
    spec_array = np.zeros((len(selected_spectra), len(mode_list)))
    error_array = np.ones(spec_array.shape)
    for i, spec in enumerate(selected_spectra):
        spec = spec.intersecting_spectrum(mode_list)
        spec_array[i, :] = spec.partial_fit
        if not single:
            error_array[i, :] = spec.partial_fit_std_err / np.sqrt(spec.n_points)
    return (spec_array, error_array)


def apply_ica(
    analysis_df: pd.DataFrame,
    spectra: List[BinnedSpectra],
    canaries: List[str],
    n_components: int = 1,
    fraction: float = 0.2,
    single: bool = False,
) -> Dict[int, ica_models.ICAResults]:
    """
    Attempt at a general ICA utility that is not limited to ports

    Arguments:
        analysis_df: dataframe to run the analysis on.  We are assuming data has been cleaned and 
            transformed ahead of time (i.e. zero reference, filtered, sclaed by LOD, selected port, etc..)
        spectra: list of binned spectra to use in time series analysis
        canaries: list of canaries to use in ICA signal reconstruction
        n_components: number of componenets to use in ICA analysis, defaults to 1 for PCA
        fraction: keep fraction above maximum from mapping

    Returns:
        Dictionary with componenet number as key and results in ICAResults model
    """
    analysis_df = analysis_df[canaries]
    # Create ICA transform object
    transformer = FastICA(n_components=n_components, whiten="unit-variance")
    _ = transformer.fit_transform(analysis_df)

    # map sources to data
    mapping = transformer.mixing_
    analysis_np = analysis_df.to_numpy()

    # Get the compact spectrum
    compact_spectrum = _intersect(spectra)

    ica_signals = {}
    for component in range(n_components):
        mapping_n = mapping[:, component]

        # Only keep fraction above max
        abs_mapping = np.abs(mapping_n)

        # Pick out signals that saw excursions
        mapping_mask = abs_mapping > (fraction * abs_mapping.max())
        mapping_size = np.sqrt(np.sum(mapping_n**2))

        # create time series vector from our canary data
        time_series = 0
        for i, keep in enumerate(mapping_mask):
            if keep:
                time_series += analysis_np[:, i] * mapping[i, component] / mapping_size

        # Now create a 2D array with all spectra to get partial fit and error
        partial_fit_arr, partial_fit_err_arr = _create_specctrum_array(
            spectra, compact_spectrum.modes, single
        )
        # Correlation Fit, get slopes of fit and error from least squares
        slope_fit, slope_fit_err = correlation_fit(
            partial_fit_arr, partial_fit_err_arr, time_series
        )

        # accumulate results into data model
        ica_signals[component + 1] = ica_models.ICAResults(
            nu_prime=compact_spectrum.nu_prime,
            slope_fit=slope_fit,
            slope_fit_err=slope_fit_err,
            time_series=time_series,
            mapping=mapping[:, component],
            mapping_mask=mapping_mask,
            component=component + 1,  # for book keeping
            n_components=n_components,
        )

    return ica_signals
