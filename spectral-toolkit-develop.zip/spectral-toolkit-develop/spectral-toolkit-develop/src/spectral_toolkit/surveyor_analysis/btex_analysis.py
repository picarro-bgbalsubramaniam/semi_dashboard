import os
from collections import namedtuple
from datetime import datetime as dt
from pathlib import Path
from typing import Dict, List, Union, Tuple

import numpy as np
import pandas as pd
import pytz

from plotly.subplots import make_subplots
import plotly.graph_objects as go

from data_pooler.api.combined_logs import (
    get_combo_df,
    get_private_df,
    get_timeseries_with_combo_info,
)
from data_pooler.data_access_utils import date_range, get_file_paths_in_timerange
from data_pooler.persist import get_combolog_from_zpickle
from data_pooler.pool_utils import get_data_frame
from plotly.graph_objects import Figure
from spectral_arithmetic.aggregate_operations import (
    bin_spectral_data,
    filter_spectral_data,
    transform_spectra,
)
from spectral_arithmetic.data_models.spectra import BinnedSpectra

from spectral_toolkit.db_clients.mongo_spectral_library import (
    get_mongo_spectral_library_client,
)
from spectral_toolkit.df_operations.spectral_fits_results_aggregation import (
    define_solutions_spectral_dataset,
    get_stacked_fit_solutions,
)
from spectral_toolkit.logger import get_logger
from spectral_toolkit.plotting.spectral_hunting_plot import get_spectral_hunting_plot
from spectral_toolkit.sam_analysis import compactify  # TODO: Move to central location
from spectral_toolkit.sam_analysis.compound_identification import (
    IsoType,
    _create_return_data,
    _get_and_filter_model_functions,
    perform_multicomponent_fit,
)
from spectral_toolkit.sam_analysis.unknown_stats import (
    filter_and_summarize,
    make_unknown_results_stats,
    create_full_summary,
)

LOGGER = get_logger(__name__)

PEAK_DETECTOR_STATE = "peak_detector_state"
TRIGGER_STATE = 3
TRANSITION_STATE = 9
HOLDING_STATE = 10
COMPOUNDS_IGNORE = [92831, 637513, 102, 103, 104]
REQUIRED_CIDS = [180, 3776, 948, 222, 6324, 6325, 6334, 6360, 7843, 1140]
NUM_COMPOUNDS = [1, 2, 3]

Sequence = namedtuple(
    "Sequence", ["start_zero", "stop_zero", "start_holding", "stop_holding"]
)
# Use this to construct filters
Filter = namedtuple("Filter", ["name", "min", "max"])


def find_transitions(
    start: str,
    end: str,
    pool_path: Union[Path, str],
    time_zone: str = "UTC",
    fitter: str = "OldFitter",
) -> List[Sequence]:
    """Find the transitions that correspond to 3, 9, 10 peak_detector_state

    Args:
        start (str): Starting time to analyze (format: 2022-09-12 00:00:00)
        end (str): Ending time to analyze (format: 2022-10-12 00:00:00)
        pool_path (Union[Path, str]): Path to analyzer data (format: /home/picarro/pools/NUV1047)
        time_zone (str, optional): pytz timezone of data collected/viewed. Defaults to 'UTC'.
        fitter (str, optional): Type of private log fitter to use ('NewFitter' or 'OldFitter'). Defaults to 'OldFitter'

    Returns:
        list of sequences with start and end of reference/trigger state and start and end of holding
    """
    df = get_private_df(
        start,
        end,
        time_zone,
        Path(pool_path),
        private_columns=[PEAK_DETECTOR_STATE],
        private_fit_type=fitter,
    )

    if PEAK_DETECTOR_STATE not in df.columns:
        raise ValueError(
            f"Private Log data does not contain {PEAK_DETECTOR_STATE} data"
        )

    # Find stop and start of valve sequences
    transitions_start = df["peak_detector_state"].shift() != df["peak_detector_state"]
    transitions_end = df["peak_detector_state"].shift(-1) != df["peak_detector_state"]
    seq_start = df[transitions_start]["peak_detector_state"]
    seq_end = df[transitions_end]["peak_detector_state"]

    # Find all occurences of sequences
    sequences = []
    for i in range(len(seq_start) - 2):
        if seq_start[i] == TRIGGER_STATE:
            if (
                seq_start[i + 1] == TRANSITION_STATE
                and seq_start[i + 2] == HOLDING_STATE
            ):
                sequences.append(
                    Sequence(
                        seq_start.index[i],
                        seq_end.index[i],
                        seq_start.index[i + 2],
                        seq_end.index[i + 2],
                    )
                )

    return sequences


def _valid_filters(row: namedtuple, filters: List[Filter]) -> bool:
    """Convenience fitler for simple high low filtering on spectra time series data

    Args:
        row (namedtuple): pandas row with time series data to filter on
        filters (List[Filter], optional): Filters to filter out bad data. Defaults to [Filter('cavityPressureStd', 0, 0.1)].

    Returns:
        bool: True if all filters passed, False if any fail
    """
    for f in filters:
        val = getattr(row, f.name)
        if val < f.min or val > f.max:
            LOGGER.warning(
                f"skipping spectral from filter {f.name} outside of range with value {val}"
            )
            return False

    return True


def _compact_frame(df_combo: pd.DataFrame, filters: List[Filter]) -> BinnedSpectra:
    """Compact the spectra to get the holding and reference spectra and filter on user supplied filters

    Args:
        df_combo (pd.DataFrame): combo dataframe generated from data_pooler api
        filters (List[Filter], optional): List of filters. Defaults to [Filter('cavityPressureStd', 0, 0.1)].

    Returns:
        BinnedSpectra: Get the binned spectra object
    """
    spectra = []
    cur_file = df_combo["spec_gen_file"][0]
    combo_gen = get_combolog_from_zpickle(open(cur_file, "r"))
    _ = next(combo_gen)
    for row in df_combo.itertuples():

        valid = _valid_filters(row, filters)
        # Exclude if we fail filters
        if valid is False:
            continue

        if row.spec_gen_file != cur_file:
            cur_file = row.spec_gen_file
            combo_gen = get_combolog_from_zpickle(open(cur_file, "r"))
            _ = next(combo_gen)

        spec = combo_gen.send(int(row.spec_gen_id))
        spec_arr = dict(zip(spec.columns.values, spec.values.T))

        extra_info = compactify._combo_data_for_transform(row)
        spec_arr.update(extra_info)
        spectra.append(spec_arr)

    return compactify._compactify_spectra(spectra)


def create_diff_spec(
    sequences: List[Sequence],
    df_combo: pd.DataFrame,
    filters: List[Filter] = [Filter("cavityPressureStd", 0, 0.1)],
    trim_time: int = 5,
) -> Dict[pd.Timestamp, BinnedSpectra]:
    """Create a difference spectrum for each trigger -> transition -> holding sequence

    Args:
        sequences (List[Sequence]): sequences to generate diff spec from
        trim_time (int, optional): manually enter trim after valves transition in seconds. Defaults to 5.
        filters (List[Filter], optional): List of filters. Defaults to [Filter('cavityPressureStd', 0, 0.1)].
        trim_time(int): Time to trime after valve transition. Defaults to 5.

    Returns:
        Dict[pd.Timestamp, BinnedSpectra]: Dictionary with timestamp of start of sequence and difference binned spectrum
    """
    diff_spec = {}
    ref_spec_dict = {}
    holding_spec_dict = {}
    for sequence in sequences:
        # Get reference/triggered spectra
        ref_spec_combo = df_combo[
            sequence.start_zero + pd.Timedelta(seconds=trim_time) : sequence.stop_zero
        ]
        ref_spec = _compact_frame(ref_spec_combo, filters)
        ref_spec_dict.update({sequence.start_holding: ref_spec})

        # Get holding spectra
        holding_spec_combo = df_combo[
            sequence.start_holding
            + pd.Timedelta(seconds=trim_time) : sequence.stop_holding
        ]
        holding_spec = _compact_frame(holding_spec_combo, filters)
        holding_spec_dict.update({sequence.start_holding: holding_spec})

        # Get difference spectra
        diff_spec.update(
            {sequence.start_holding: holding_spec.subtract_binned_spectra(ref_spec)}
        )

    return diff_spec, ref_spec_dict, holding_spec_dict


def btex_compound_hunting(
    diff_spec: Dict[pd.Timestamp, BinnedSpectra],
    num_compounds: List[int] = NUM_COMPOUNDS,
    nominal_pressure: float = 140.0,
    required_cids: List[int] = REQUIRED_CIDS,
    compounds_ignore: List[int] = COMPOUNDS_IGNORE,
) -> Tuple[Dict, Dict, Dict]:
    """_summary_

    Args:
        diff_spec (Dict[pd.Timestamp, BinnedSpectra]): _description_
        num_compounds (List[int], optional): _description_. Defaults to NUM_COMPOUNDS.
        nominal_pressure (float, optional): _description_. Defaults to 140.0.
        required_cids (List[int], optional): _description_. Defaults to REQUIRED_CIDS.
        compounds_ignore (List[int], optional): _description_. Defaults to COMPOUNDS_IGNORE.

    Returns:
        Tuple[Dict, Dict, Dict]: Tuple with diff data (dictionary with time and frequency table)
                                            fit data (dictionary with time then dicitonary with time and stats)
                                            spec data (dictionary with time and spectral and LSQ fit data)
    """
    model_functions = _get_and_filter_model_functions(
        nominal_pressure, compounds_ignore
    )
    fit_data = {}
    diff_data = {}
    spec_data = {}
    for start, spec in diff_spec.items():
        try:
            loss_err = spec.partial_fit_std_err
            median_std_err = np.median(loss_err)
            loss_err[np.where(loss_err == 0)] = median_std_err
            fit_results, stats = perform_multicomponent_fit(
                spec.nu_prime,
                spec.partial_fit,
                loss_err,
                model_functions,
                num_compounds,
                required_cids=required_cids,
            )
            score = [val for val in stats.values()]
            subset_df = pd.DataFrame(score, index=stats.keys(), columns=["frequency"])
            subset_df.sort_values("frequency", inplace=True, ascending=False)

            diff_data, fit_data, spec_data = _create_return_data(
                fit_results,
                stats,
                diff_data,
                fit_data,
                spec_data,
                start,
                start,
                IsoType.DIFFERENCE,
            )

        except Exception as e:
            LOGGER.error(f"Unable to process even at {start}: {e}")

    return (diff_data, fit_data, spec_data)


def create_btex_compound_hunting_plot(
    fit_data: Dict[pd.Timestamp, Dict[pd.Timestamp, pd.DataFrame]],
    spec_data: Dict[pd.Timestamp, Dict],
) -> List[Figure]:
    """Create the plotly figures from compound hunting results

    Args:
        fit_data (Dict[pd.Timestamp, Dict[pd.Timestamp, pd.Dataframe]]): time and stats
        spec_data (Dict[pd.Timestamp, Dict]): time and spectral and LSQ fit data

    Returns:
        List[Figure]: Compound hunting plot for each sequence analyzed
    """
    figs = []
    for time in fit_data.keys():
        available_fits = list(fit_data[time].keys())
        nu = spec_data[time]["nu"]
        nu_min = min(nu)
        nu_max = max(nu)
        stacked_df = get_stacked_fit_solutions(
            fit_data[time][available_fits.pop(0)],
            [fit_data[time][fit].reset_index() for fit in available_fits],
        )
        experimental_datapoints = pd.Series(index=nu, data=spec_data[time]["loss"]).loc[
            nu_min:nu_max
        ]

        evaluation_nu = np.linspace(nu_min, nu_max, 2000)
        evaluation_nu = np.array(list(set(evaluation_nu).union(nu)))
        evaluation_nu = np.sort(evaluation_nu)

        solution_xrds = define_solutions_spectral_dataset(
            db_client=get_mongo_spectral_library_client(),
            solutions_fit_df=stacked_df,
            experimental_datapoints=experimental_datapoints,
            evaluation_nu=evaluation_nu,
            top_n=5,
        )
        fig = get_spectral_hunting_plot(
            spectral_fits_ds=solution_xrds,
            title_text=f"BTEX Compound Hunting Difference Results: {time}",
            species_colormap={"offset": "black"},
        )
        figs.append(fig)

    return figs


def get_unknown_summary(
    fit_data,
    analysis_dir: Path,
    run_suffix: str,
    save_tables=True,
) -> pd.DataFrame:
    """Summary of compound hunting with most likely CID candidates

    Args:
        fit_data (Dict[pd.Timestamp, Dict[pd.Timestamp, pd.Dataframe]]): time and stats

    Returns:
        DataFrame with summary of most likely compounds from fit stats
    """
    final_stats = []
    for time in fit_data.keys():
        ref_rmse = list(fit_data[time].values())[0]["rmse"]
        for name, df in fit_data[time].items():
            # Get port from name of data
            num_compounds = int(name.split("_")[-1])
            # Add filtered stats
            if num_compounds > 0:
                stats = make_unknown_results_stats(df, num_compounds, ref_rmse)

                summary = filter_and_summarize(stats, name, name)

                if save_tables:
                    start_date_time = time.strftime("%Y%m%d_%H%M%S")
                    event_name = f"{start_date_time}_{run_suffix}"
                    save_unk_tables(
                        stats,
                        summary,
                        event_name,
                        analysis_dir,
                    )

                # Add number compounds used when finding likelies
                summary = [dict(row, number_compounds=num_compounds) for row in summary]
                final_stats.extend(summary)

    df = pd.DataFrame(final_stats)
    # full_summary = create_full_summary(df)

    return df


def save_unk_tables(
    stats,
    summary,
    event_name: str,
    analysis_dir: Path,
):

    # save full list as html and excel
    fname = f"{event_name}_df"

    flnm = os.path.join(analysis_dir, f"{fname}.html")
    html = stats.to_html()
    with open(flnm, "w") as f:
        f.write(html)

    flnm = os.path.join(analysis_dir, f"{fname}.xlsx")
    stats.to_excel(flnm)

    # save filtered data as html and excel
    events_df = pd.DataFrame(summary)
    fname = f"{event_name}_events_df"

    flnm = os.path.join(analysis_dir, f"{fname}.html")
    html = events_df.to_html()
    with open(flnm, "w") as f:
        f.write(html)

    flnm = os.path.join(analysis_dir, f"{fname}.xlsx")
    events_df.to_excel(flnm)


def create_spectra_plot(
    holding_spec: Dict[pd.Timestamp, Dict], ref_spec: Dict[pd.Timestamp, Dict]
) -> List[Figure]:
    figs = []
    for time in holding_spec.keys():
        fig = make_subplots(rows=2, cols=1, shared_xaxes=True)
        fig.add_trace(
            go.Scattergl(
                x=holding_spec[time].nu_prime,
                y=holding_spec[time].partial_fit,
                line_width=2,
                mode="markers",
            ),
            row=1,
            col=1,
        )
        fig.add_trace(
            go.Scattergl(
                x=ref_spec[time].nu_prime,
                y=ref_spec[time].partial_fit,
                line_width=2,
                mode="markers",
            ),
            row=2,
            col=1,
        )
        fig.update_yaxes(title_text="peak signal", row=1, col=1)
        fig.update_yaxes(title_text="ref signal", row=2, col=1)
        fig.update_layout(showlegend=False)
        fig.update_xaxes(title_text="wavenumber", row=2, col=1, showticklabels=True)

        figs.append(fig)

    return figs
