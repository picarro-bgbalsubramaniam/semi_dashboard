import os
from pathlib import Path
import pickle
import pytz
from datetime import datetime
import pandas as pd
import ruamel.yaml
from typing import Optional, List

from data_pooler.data_access_utils import get_file_paths_in_timerange
from data_pooler.pool_utils import get_data_columns
from data_pooler.api.combined_logs import (
    get_timeseries_with_combo_info,
    DEFAULT_COMBO_COLUMNS,
    get_combo_df,
)

from spectral_toolkit.TD_analysis.data_models_TD.output_models import SpectralData
from spectral_toolkit.TD_analysis.data_models_TD.data_input import TdDataYaml
from spectral_toolkit.TD_analysis.data_models_TD.input import CFG_DIR


from spectral_toolkit.TD_analysis.TD_utilities.utilities_for_spectra import (
    get_numean,
    one_spectral_array_set,
    add_tvoc_df,
)
from spectral_toolkit.TD_analysis.TD_utilities.utilities_for_timeseries_TD import (
    process_data,
)

from spectral_toolkit.TD_analysis.TD_utilities.utilities_TD import (
    TD_flow,
)
from spectral_toolkit.TD_analysis.TD_utilities.markes_TD_utilities import (
    parse_Markes_parts,
    calculate_trap_times,
    update_parts_dict,
    filter_parts_data,
    parse_Markes_sequence,
)
from spectral_toolkit.TD_analysis.TD_utilities.TD_plotting import (
    plot_Markes_variable,
    plot_TD_variable_timeseries,
    plot_flows,
)

from spectral_toolkit.TD_analysis.TD_utilities.picarro_TD_utilities import (
    parse_picarro_sequence,
    parse_picarro_SAT_sequence,
)

from spectral_toolkit.TD_analysis.TD_utilities.time_conversions import (
    timestr_to_datetime,
)


COMBO_ADDITION = [
    "gasConcs",
    "HDO",
    "f0",
    "rmse",
    "row_id",
    "spectrum_id",
]

DEFAULT_COMBO_COLUMNS_PLUS = DEFAULT_COMBO_COLUMNS + COMBO_ADDITION


def filter_column_names(col_names, keep_list):
    names = []
    if keep_list is not None:
        for name in col_names:
            for keeper in keep_list:
                if keeper in name:
                    names.append(name)
    else:
        names = None
    return names


def rename_combo_columns(names):
    combo_columns = []
    for name in names:
        combo_columns.append(f"broadband_{name}")

    return combo_columns


# NEW
def load_compile_data(
    input_class: TdDataYaml,
    combo_keep_list: Optional[List[str]] = DEFAULT_COMBO_COLUMNS_PLUS,
    private_keep_list: Optional[List[str]] = None,
) -> pd.DataFrame:
    """Load compiled private and combo log data with spectral information.

    This function defines the variables to be collected from private and combo logs.
    Files within the specified times in the input_class are collected.
    All private log data is compiled.
    All combo log data with names that include ["gasConcs", "HDO", "f0", "rmse", "row_id", "spectrum_id"] are compiled.
    The function tries to load NewFitter private logs. If there are none, it uses OldFitter private logs.
    After all of the timeseries data is compiled, the filters in input_class are applied to the data, including a time filter.
    The data is saved in a pkl file and returned as a dataframe.

    Parameters:
        input_class: TdDataYaml
            input configuration information including:
                Parameters: YamlParameters
                Experiment_Times: List[BaseTimesSchema]
                Paths: YamlPaths
                Filters: Dict = None
                Variables_to_plot: List[str] = []
                MFCs: YamlMfcs
                Precon_timing: YamlPreconTiming
                Plot_y_axis_lim: Dict = None
                Steps: YamlTemperatureSteps = None

    Returns:
        df: pandas DataFrame
            dataframe with a timezone aware datetimeindex
            columns contain timeseries data from private and combo logs
            additional columns containing filepath information for spectra
    """
    # prep input_class for this analysis
    _, analysis_dir, _, _ = input_class.Paths.set_file_paths(
        event_start=None, analysis_name="raw data"
    )

    poolDIR = input_class.Paths.pool_name
    analyzer_name = input_class.Parameters.analyzer_name
    timezone = input_class.Parameters.timezone

    start_date_time_str, end_date_time_str = input_class.get_exp_date_time_str()

    base_path = Path(poolDIR) / analyzer_name
    tz = pytz.timezone(timezone)
    start_dt = tz.localize(timestr_to_datetime(start_date_time_str))
    stop_dt = tz.localize(timestr_to_datetime(end_date_time_str))

    # get requested private log data from the data pool
    # get the file names of all of the files within the time range specificed
    files = get_file_paths_in_timerange(
        start_dt, stop_dt, base_path, ["ComboLog", "broadband"]
    )
    # get all of the column names within the datafiles
    combo_col_names = get_data_columns(files)

    combo_names = filter_column_names(combo_col_names, combo_keep_list)
    combo_columns = rename_combo_columns(combo_names)

    start_local = start_dt.strftime("%Y-%m-%d %H:%M:%S")
    end_local = stop_dt.strftime("%Y-%m-%d %H:%M:%S")

    try:
        fitter_type = "NewFitter"
        files = get_file_paths_in_timerange(
            start_dt, stop_dt, base_path, ["PrivateLog", fitter_type]
        )
        if len(files) == 0:
            fitter_type = "OldFitter"
            files = get_file_paths_in_timerange(
                start_dt, stop_dt, base_path, ["PrivateLog", fitter_type]
            )
            if len(files) == 0:
                files = None
    except:
        try:
            fitter_type = "OldFitter"
            files = get_file_paths_in_timerange(
                start_dt, stop_dt, base_path, ["PrivateLog", fitter_type]
            )
        except:
            files = None

    if files is not None:
        # get all of the column names within the datafiles
        private_col_names = get_data_columns(files)

        private_names = filter_column_names(private_col_names, private_keep_list)

        df = get_timeseries_with_combo_info(
            start_local,
            end_local,
            timezone,
            base_path,
            private_columns=private_names,
            combo_columns=combo_names,
            combo_fit_type="broadband",
            private_fit_type=fitter_type,
        )

        for old_name, combo_name in zip(combo_names, combo_columns):
            df[combo_name] = df[old_name]

        df.drop(columns=combo_names, inplace=True)
    else:
        df = get_combo_df(
            start_local,
            end_local,
            timezone,
            base_path,
            combo_columns=combo_names,
            combo_fit_type="broadband",
        )
        df = df.add_prefix("broadband_")

        df.rename(
            columns={
                "broadband_row_id": "row_id",
                "broadband_spectrum_id": "spectrum_id",
                "broadband_spec_gen_id": "spec_gen_id",
                "broadband_spec_gen_file": "spec_gen_file",
            },
            inplace=True,
        )

    filters = input_class.get_filters()

    for key in df.keys().sort_values():
        print(key)

    df = process_data(df, start_dt=start_dt, end_dt=stop_dt, filters=filters, tz=tz)

    filename = os.path.join(analysis_dir, f"{input_class.output_prefix}_compiled.pkl")
    with open(filename, "wb") as outpkl:
        pickle.dump(df, outpkl, 1)

    return df


def get_spectra(
    input_class: TdDataYaml,
    start_datetime: datetime,
    sequence_series: pd.DataFrame,
    comp_df: pd.DataFrame,
    end_datetime: Optional[datetime] = None,
    return_output: Optional[bool] = False,
):
    """Compile combo spectra for TD sequence.

    Parameters:
        input_class: TdDataYaml
            input configuration information including:
                Parameters: YamlParameters
                Experiment_Times: List[BaseTimesSchema]
                Paths: YamlPaths
                Filters: Dict = None
                Variables_to_plot: List[str] = []
                MFCs: YamlMfcs
                Precon_timing: YamlPreconTiming
                Plot_y_axis_lim: Dict = None
                Steps: YamlTemperatureSteps = None
        start_datetime: datetime
            datetime at which the experiment begins
        sequence_series: pandas DataFrame
            Pandas dataframe containing sequence data.
            Each line is one run, indexed by a timezone aware datetime index.

            Common columns included:
            sample_volume_mL: volume of sample collected (mL)
            trap_flow: cold trap trapping flow (sccm)
            trap_time: cold trap trap time (min)
            post_sample_purge_time: post sample purge time (min)
            trap_purge_time: trap purge time (min)
            max_flow: maximum flow (sccm)
            min_flow: minimum flow (sccm)
            trap_low_temperature: trap low temperature (C)
            trap_heating_rate: trap heating rate (C/s)
            desorb_time_min: desorb time (min)
        comp_df: pandas DataFrame
            dataframe with a timezone aware datetimeindex
            columns contain timeseries data from private and combo logs
            additional columns containing filepath information for spectra

    Raises:

    Saves:
        spectra_dict = {
            "input_class": input_class,
            "start_datetime": start_datetime,
            "end_datetime": stop_datetime,
            "sequence_series": sequence_series,
            "spectra": spectra,
            "df": comp_df,
        }
            input_class: TD_yaml
            start_datetime: datetime
            end_datetime: datetime
            sequence_series: pd.DataFrame
            spectra: SpectralData
                fit_df: PandasDataFrame

                spectrum_df: Optional[PandasDataFrame]
                numean: Optional[Array[float]]
                modes: Optional[Array[int]]
                res_df: Optional[PandasDataFrame]
                good_fits: Optional[int]
                bad_fits: Optional[int]
            df: pd.DataFrame
                compiled private and combo log data
                dataframe with a timezone aware datetimeindex
                columns contain timeseries data from private and combo logs
                additional columns containing filepath information for spectra

        filename = os.path.join(
                analysis_dir,
                f"{start_date_time_str}_{input_class.run_suffix}_parse_combo_spectra.pkl",
            )
    """
    if end_datetime is None:
        end_datetime = sequence_series["end_datetime"]

    # prep input_class for this analysis
    start_date_time_str = start_datetime.strftime("%Y%m%d_%H%M%S")
    _, analysis_dir, _, _ = input_class.Paths.set_file_paths(
        event_start=start_date_time_str, analysis_name="combo spectra"
    )

    comp_df = comp_df[
        (comp_df.index >= start_datetime) & (comp_df.index <= end_datetime)
    ]

    if "broadband_simple_trapz" not in comp_df:
        comp_df = add_tvoc_df(
            comp_df,
        )

    numean, modes = get_numean(
        start_datetime,
        end_datetime,
        comp_df,
    )

    fit_df, res_df = one_spectral_array_set(
        start_datetime,
        end_datetime,
        comp_df,
        include_res=True,
    )

    spectra = SpectralData(numean=numean, fit_df=fit_df, res_df=res_df, modes=modes)

    spectra_dict = {
        "input_class": input_class,
        "start_datetime": start_datetime,
        "end_datetime": end_datetime,
        "sequence_series": sequence_series,
        "spectra": spectra,
        "df": comp_df,
    }

    filename = os.path.join(
        analysis_dir,
        f"{start_date_time_str}_{input_class.run_suffix}_parse_combo_spectra.pkl",
    )

    with open(filename, "wb") as outpkl:
        pickle.dump(spectra_dict, outpkl, -1)

    if return_output:
        return spectra_dict


def get_TD_sequences(
    input_class: TdDataYaml,
    config_file: Path,
    TD_type: Optional[str] = "markes",
    cfg_dir: Optional[Path] = CFG_DIR,
) -> pd.DataFrame:
    """Parse and compile TD sequences.

    Parameters:
        input_class: TdDataYaml
            input configuration information including:
                Parameters: YamlParameters
                Experiment_Times: List[BaseTimesSchema]
                Paths: YamlPaths
                Filters: Dict = None
                Variables_to_plot: List[str] = []
                MFCs: YamlMfcs
                Precon_timing: YamlPreconTiming
                Plot_y_axis_lim: Dict = None
                Steps: YamlTemperatureSteps = None
        config_file: Path
            path name of the updated config file
        TD_type: optional string, default 'markes'
            'markes': for Markes sequence files
            'picarro': for picarro TD log files
        cfg_dir: optional Path, default CGF_DIR
            path location where the updated config file will be saved

    Raises:

    Saves:
        seq_dict: dictionary
            sequences: pd.DataFrame
                Pandas dataframe containing sequence data.
                Each line is one run, indexed by a timezone aware datetime index.

                Common columns included:
                    sample_volume_mL: volume of sample collected (mL)
                    trap_flow: cold trap trapping flow (sccm)
                    trap_time: cold trap trap time (min)
                    post_sample_purge_time: post sample purge time (min)
                    trap_purge_time: trap purge time (min)
                    max_flow: maximum flow (sccm)
                    min_flow: minimum flow (sccm)
                    trap_low_temperature: trap low temperature (C)
                    trap_heating_rate: trap heating rate (C/s)
                    desorb_time_min: desorb time (min)

        filename = os.path.join(
                analysis_dir,
                f"{start_date_time_str}_{name}_parse_{TD_type}_sequences.pkl",
            )

        Updated config.yaml
            ["Events"] section updated

    Returns:
        sequences: pd.DataFrame
            Pandas dataframe containing sequence data.
            Each line is one run, indexed by a timezone aware datetime index.

            Common columns included:
                sample_volume_mL: volume of sample collected (mL)
                trap_flow: cold trap trapping flow (sccm)
                trap_time: cold trap trap time (min)
                post_sample_purge_time: post sample purge time (min)
                trap_purge_time: trap purge time (min)
                max_flow: maximum flow (sccm)
                min_flow: minimum flow (sccm)
                trap_low_temperature: trap low temperature (C)
                trap_heating_rate: trap heating rate (C/s)
                desorb_time_min: desorb time (min)

    """
    temperature_name = input_class.Paths.temperature_name
    # flow_path = None

    name = input_class.Paths.run_suffix
    timezone = input_class.Parameters.timezone
    step_dict = input_class.Steps
    start_date_time_str, _ = input_class.get_exp_date_time_str()
    start_dt, end_dt = input_class.get_exp_dt()

    if TD_type == "markes":
        _, analysis_dir, _, _ = input_class.Paths.set_file_paths(
            event_start=None, analysis_name="Markes"
        )
        sequences = parse_Markes_sequence(temperature_name, timezone, start_dt, end_dt)
    elif TD_type == "picarro":
        _, analysis_dir, _, _ = input_class.Paths.set_file_paths(
            event_start=None, analysis_name="Picarro TD"
        )
        sequences = parse_picarro_sequence(
            temperature_name,
            timezone,
            start_dt,
            end_dt,
            step_dict.__dict__,
            verbose=False,
        )
    elif TD_type == "picarroSAT":
        _, analysis_dir, _, _ = input_class.Paths.set_file_paths(
            event_start=None, analysis_name="Picarro TD"
        )
        sequences = parse_picarro_SAT_sequence(
            temperature_name,
            timezone,
            start_dt,
            end_dt,
        )

    if "trap_time" not in sequences:
        sequences["trap_time"] = float(input_class.Precon_timing.trap_time_min)

    filename = os.path.join(
        analysis_dir,
        f"{start_date_time_str}_{name}_parse_{TD_type}_sequences.pkl",
    )
    with open(filename, "wb") as outpkl:
        pickle.dump(sequences, outpkl, 1)

    # update config file
    file_name = os.path.join(cfg_dir, config_file)
    config, ind, bsi = ruamel.yaml.util.load_yaml_guess_indent(open(file_name))

    config["Events"] = []
    for n, start_datetime in enumerate(sequences.index):
        new_event_dict = {
            "time_num": n,
            "start_date_time": start_datetime.strftime("%Y%m%d_%H%M%S"),
            "end_date_time": sequences["end_datetime"]
            .iloc[n]
            .strftime("%Y%m%d_%H%M%S"),
        }
        config["Events"].append(new_event_dict)

    yaml = ruamel.yaml.YAML()
    yaml.indent(mapping=ind, sequence=ind, offset=bsi)
    with open(file_name, "w") as fp:
        yaml.dump(config, fp)

    return sequences


def compile_markes_data(
    input_class: TdDataYaml,
    start_datetime: datetime,
    sequence_series: pd.DataFrame,
):
    """
    Compile data from Markes csf files for run defined by sequence_series.

    Parameters:
        input_class: TdDataYaml
            input configuration information including:
                Parameters: YamlParameters
                Experiment_Times: List[BaseTimesSchema]
                Paths: YamlPaths
                Filters: Dict = None
                Variables_to_plot: List[str] = []
                MFCs: YamlMfcs
                Precon_timing: YamlPreconTiming
                Plot_y_axis_lim: Dict = None
                Steps: YamlTemperatureSteps = None
        start_datetime: datetime
            datetime at which the experiment begins
        sequence_series: pandas DataFrame
            Pandas dataframe containing sequence data.
            Each line is one run, indexed by a timezone aware datetime index.

            Common columns included:
            sample_volume_mL: volume of sample collected (mL)
            trap_flow: cold trap trapping flow (sccm)
            trap_time: cold trap trap time (min)
            post_sample_purge_time: post sample purge time (min)
            trap_purge_time: trap purge time (min)
            max_flow: maximum flow (sccm)
            min_flow: minimum flow (sccm)
            trap_low_temperature: trap low temperature (C)
            trap_heating_rate: trap heating rate (C/s)
            desorb_time_min: desorb time (min)

    Saves:
        markes_dict: dict
            {
            "start_datetime": start_datetime,
            "sequence": sequence,
            "parts": parts,
            "df_flow": df_flow,  # ini MFC designated flows
            "df_all": df_all,  # measured raw flows
            "dfg_runs": dfg_runs,  # run average measured flows
            "dfg_steps": dfg_steps,  # step average measured flows
            }
        filename = os.path.join(analysis_dir, f"{start_date_time}_{name}_parse_markes.pkl")

    """
    temperature_name = input_class.Paths.temperature_name
    start_dt, end_dt = input_class.get_exp_dt()
    flow_path = None

    ################
    MFCs = input_class.MFCs
    # step_dict = input_class.Steps
    timezone = input_class.Parameters.timezone

    TDF = TD_flow(
        MFCs.get_dict(),
        timezone,
        flow_path=flow_path,
        verbose=False,
        reprocess=True,
        run_num=1,
        start_datetimes=[start_datetime],
        start_dt=start_dt,
        end_dt=end_dt,
    )

    sequence, df_flow, dfg = TDF.get_sequence_data(sequence_series)
    ###############

    name = input_class.Paths.run_suffix
    timezone = input_class.Parameters.timezone

    (trap_start_datetime, trap_end_datetime, _, _) = calculate_trap_times(
        sequence_series
    )
    parts = update_parts_dict(
        trap_start_datetime,
        trap_end_datetime,
    )

    start_date_time = start_datetime.strftime("%Y%m%d_%H%M%S")
    (_, analysis_dir, _, figures_dir,) = input_class.Paths.set_file_paths(
        event_start=start_date_time, analysis_name="Markes"
    )

    parts_list = ["Unity", "Kori", "GC", "CIAAdvantage"]

    for part in parts_list:
        try:
            df_parts = parse_Markes_parts(
                sequence_series,
                start_datetime,
                temperature_name,
                timezone,
                part_name=part,
            )

            df_run, trap_start_datetime, trap_end_datetime = filter_parts_data(
                sequence_series, start_datetime, df_parts
            )

            parts = update_parts_dict(
                trap_start_datetime,
                trap_end_datetime,
                df_run=df_run,
                part_name=part,
                parts=parts,
            )
            if part == "Unity":
                plot_Markes_variable(
                    parts,
                    figures_dir,
                    f"{start_datetime.strftime('%Y%m%d_%H%M%S')}_{name}",
                    part_name="Unity",
                    var_2_plot="trap_C",
                )
        except:
            print(f"no {part} data available")

    markes_dict = {
        "start_datetime": start_datetime,
        "sequence": sequence,
        "parts": parts,
        "df_flow": df_flow,  # ini MFC designated flows
        "dfg": dfg,
    }

    filename = os.path.join(analysis_dir, f"{start_date_time}_{name}_parse_markes.pkl")
    with open(filename, "wb") as outpkl:
        pickle.dump(markes_dict, outpkl, 1)


def compile_picarro_TD_data(
    input_class: TdDataYaml,
    start_datetime: datetime,
    sequences: pd.DataFrame,
    TD_type="picarro",
):
    """
    Compile data from Picarro TD log files for run defined by sequences.

    Parameters:
        input_class: TdDataYaml
            input configuration information including:
                Parameters: YamlParameters
                Experiment_Times: List[BaseTimesSchema]
                Paths: YamlPaths
                Filters: Dict = None
                Variables_to_plot: List[str] = []
                MFCs: YamlMfcs
                Precon_timing: YamlPreconTiming
                Plot_y_axis_lim: Dict = None
                Steps: YamlTemperatureSteps = None
        start_datetime: datetime
            datetime at which the experiment begins
        sequences: pandas DataFrame
            Pandas dataframe containing sequence data.
            Each line is one run, indexed by a timezone aware datetime index.

            Common columns included:
            sample_volume_mL: volume of sample collected (mL)
            trap_flow: cold trap trapping flow (sccm)
            trap_time: cold trap trap time (min)
            post_sample_purge_time: post sample purge time (min)
            trap_purge_time: trap purge time (min)
            max_flow: maximum flow (sccm)
            min_flow: minimum flow (sccm)
            trap_low_temperature: trap low temperature (C)
            trap_heating_rate: trap heating rate (C/s)
            desorb_time_min: desorb time (min)

    Saves:
        return_dict = {
            "start_datetime": start_datetime,
            "sequence": sequence,
            "df_flow": df_flow,
            "dfg": dfg,
        }
        filename = os.path.join(
            analysis_dir, f"{start_str}_{name}_compile_picarro_TD.pkl"
        )

    """
    picarro_TD_path = input_class.Paths.temperature_name
    name = input_class.Paths.run_suffix
    timezone = input_class.Parameters.timezone
    MFCs = input_class.MFCs
    start_dt, end_dt = input_class.get_exp_dt()

    TDF = TD_flow(
        MFCs.get_dict(),
        timezone,
        flow_path=picarro_TD_path,
        verbose=False,
        reprocess=True,
        start_dt=start_dt,
        end_dt=end_dt,
    )

    if TD_type == "picarro":
        step_dict = input_class.Steps
        TDF.flow_group_stats(step_name="step_num")
        TDF.add_const_flows()
        for run_num, (ind, sequence_series) in enumerate(sequences.iterrows()):
            TDF.collect_relevant_flows(step_dict=step_dict.__dict__, run_num=run_num)
    elif TD_type == "picarroSAT":
        TDF.flow_group_stats(step_name="current_state")
        TDF.add_const_flows()

        for run_num, (ind, sequence_series) in enumerate(sequences.iterrows()):
            TDF.collect_relevant_flows_by_state(run_num=run_num)

    TDF.compile_relevant_flows()

    # parse other things for sequences
    for start_datetime, sequence_series in sequences.iterrows():
        start_str = start_datetime.strftime("%Y%m%d_%H%M%S")

        (_, analysis_dir, _, figures_dir,) = input_class.Paths.set_file_paths(
            event_start=start_str, analysis_name="Picarro TD"
        )

        sequence, df_flow, dfg = TDF.get_sequence_data(sequence_series)

        F = plot_flows(dfg)
        fname = f"{start_str}_{name}_flows"
        F.write_html(os.path.join(figures_dir, f"{fname}.html"))
        F.write_image(os.path.join(figures_dir, f"{fname}.png"))

        F = plot_TD_variable_timeseries(dfg, var_2_plot="TD_PID_C")
        fname = f"{start_str}_{name}_temperature_PID"
        F.write_html(os.path.join(figures_dir, f"{fname}.html"))
        F.write_image(os.path.join(figures_dir, f"{fname}.png"))

        return_dict = {
            "start_datetime": start_datetime,
            "sequence": sequence,
            "df_flow": df_flow,
            "dfg": dfg,
        }

        filename = os.path.join(
            analysis_dir, f"{start_str}_{name}_compile_{TD_type}_TD.pkl"
        )
        with open(filename, "wb") as outpkl:
            pickle.dump(return_dict, outpkl, 1)


def compile_picarro_td_data_no_yaml(
    
    start_datetime: datetime,
    sequences: pd.DataFrame,
    TD_type="picarro",
):
    """
    Compile data from Picarro TD log files for run defined by sequences.

    Parameters:
        input_class: TdDataYaml
            input configuration information including:
                Parameters: YamlParameters
                Experiment_Times: List[BaseTimesSchema]
                Paths: YamlPaths
                Filters: Dict = None
                Variables_to_plot: List[str] = []
                MFCs: YamlMfcs
                Precon_timing: YamlPreconTiming
                Plot_y_axis_lim: Dict = None
                Steps: YamlTemperatureSteps = None
        start_datetime: datetime
            datetime at which the experiment begins
        sequences: pandas DataFrame
            Pandas dataframe containing sequence data.
            Each line is one run, indexed by a timezone aware datetime index.

            Common columns included:
            sample_volume_mL: volume of sample collected (mL)
            trap_flow: cold trap trapping flow (sccm)
            trap_time: cold trap trap time (min)
            post_sample_purge_time: post sample purge time (min)
            trap_purge_time: trap purge time (min)
            max_flow: maximum flow (sccm)
            min_flow: minimum flow (sccm)
            trap_low_temperature: trap low temperature (C)
            trap_heating_rate: trap heating rate (C/s)
            desorb_time_min: desorb time (min)

    Saves:
        return_dict = {
            "start_datetime": start_datetime,
            "sequence": sequence,
            "df_flow": df_flow,
            "dfg": dfg,
        }
        filename = os.path.join(
            analysis_dir, f"{start_str}_{name}_compile_picarro_TD.pkl"
        )

    """
    picarro_TD_path = input_class.Paths.temperature_name
    name = input_class.Paths.run_suffix
    timezone = input_class.Parameters.timezone
    MFCs = input_class.MFCs
    start_dt, end_dt = input_class.get_exp_dt()

    TDF = TD_flow(
        MFCs.get_dict(),
        timezone,
        flow_path=picarro_TD_path,
        verbose=False,
        reprocess=True,
        start_dt=start_dt,
        end_dt=end_dt,
    )

    if TD_type == "picarro":
        step_dict = input_class.Steps
        TDF.flow_group_stats(step_name="step_num")
        TDF.add_const_flows()
        for run_num, (ind, sequence_series) in enumerate(sequences.iterrows()):
            TDF.collect_relevant_flows(step_dict=step_dict.__dict__, run_num=run_num)
    elif TD_type == "picarroSAT":
        TDF.flow_group_stats(step_name="current_state")
        TDF.add_const_flows()

        for run_num, (ind, sequence_series) in enumerate(sequences.iterrows()):
            TDF.collect_relevant_flows_by_state(run_num=run_num)

    TDF.compile_relevant_flows()

    # parse other things for sequences
    for start_datetime, sequence_series in sequences.iterrows():
        start_str = start_datetime.strftime("%Y%m%d_%H%M%S")

        (_, analysis_dir, _, figures_dir,) = input_class.Paths.set_file_paths(
            event_start=start_str, analysis_name="Picarro TD"
        )

        sequence, df_flow, dfg = TDF.get_sequence_data(sequence_series)

        F = plot_flows(dfg)
        fname = f"{start_str}_{name}_flows"
        F.write_html(os.path.join(figures_dir, f"{fname}.html"))
        F.write_image(os.path.join(figures_dir, f"{fname}.png"))

        F = plot_TD_variable_timeseries(dfg, var_2_plot="TD_PID_C")
        fname = f"{start_str}_{name}_temperature_PID"
        F.write_html(os.path.join(figures_dir, f"{fname}.html"))
        F.write_image(os.path.join(figures_dir, f"{fname}.png"))

        return_dict = {
            "start_datetime": start_datetime,
            "sequence": sequence,
            "df_flow": df_flow,
            "dfg": dfg,
        }

        filename = os.path.join(
            analysis_dir, f"{start_str}_{name}_compile_{TD_type}_TD.pkl"
        )
        with open(filename, "wb") as outpkl:
            pickle.dump(return_dict, outpkl, 1)
