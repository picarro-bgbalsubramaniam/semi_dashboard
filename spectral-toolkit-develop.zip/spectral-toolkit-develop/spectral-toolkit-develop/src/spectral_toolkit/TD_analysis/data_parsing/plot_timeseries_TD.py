import os
import pickle
import pytz
import pandas as pd

from spectral_toolkit.TD_analysis.data_models_TD.data_input import TdDataYaml
from spectral_toolkit.TD_analysis.TD_utilities.utilities_for_timeseries_TD import (
    find_name,
    good_times,
)
from spectral_toolkit.TD_analysis.TD_utilities.utilities_plotting import plot_variable


def plot_timeseries_data(
    input_class: TdDataYaml, comp_df: pd.DataFrame, sequences: pd.DataFrame
):
    """Plot Markes timeseries.

    Parameters:
        input_class: TdDataYaml
            input configuration information including:
                Parameters: YamlParameters
                Experiment_Times: List[BaseTimesSchema]
                Paths: YamlPaths
                Filters: Dict = None
                Variables_to_plot: List[str] = []
                MFCs: YamlMfcs
                Precon_timing: YamlPreconTiming
                Plot_y_axis_lim: Dict = None
                Steps: YamlTemperatureSteps = None
        comp_df: pandas DataFrame
            dataframe with a timezone aware datetimeindex
            columns contain timeseries data from private and combo logs
            additional columns containing filepath information for spectra
        sequences: pd.DataFrame
            Pandas dataframe containing sequence data.
            Each line is one run, indexed by a timezone aware datetime index.

            Common columns included:
                sample_volume_mL: volume of sample collected (mL)
                trap_flow: cold trap trapping flow (sccm)
                trap_time: cold trap trap time (min)
                post_sample_purge_time: post sample purge time (min)
                trap_purge_time: trap purge time (min)
                max_flow: maximum flow (sccm)
                min_flow: minimum flow (sccm)
                trap_low_temperature: trap low temperature (C)
                trap_heating_rate: trap heating rate (C/s)
                desorb_time_min: desorb time (min)


    Raises:


    """
    variable_list = input_class.Variables_to_plot
    time_name = input_class.Parameters.time_name

    for start_datetime, sequence_series in sequences.iterrows():
        start_str = start_datetime.strftime("%Y%m%d_%H%M%S")

        _, _, _, figures_dir = input_class.Paths.set_file_paths(
            event_start=start_str, analysis_name="timeseries"
        )

        ind_good = good_times(
            comp_df, start_dt=start_datetime, end_dt=sequence_series["end_datetime"]
        )
        for var_name in variable_list:
            var_lims = input_class.get_y_axis_lim(var_names=[var_name])
            new_name, _ = find_name(var_name, comp_df)
            if new_name in comp_df:
                prefix = f"{start_str}_{input_class.run_suffix}"
                plot_variable(
                    time_name,
                    var_name,
                    comp_df[ind_good],
                    prefix,
                    figures_dir,
                    label_ave=True,
                    var_lims=var_lims,
                )
