from __future__ import annotations
from typing import List, TypeVar

from spectral_toolkit.TD_analysis.data_models_TD.schema import (
    UnkTimesSchema,
    UnkUnknowns,
)

from spectral_toolkit.TD_analysis.data_models_TD.input import (
    load_yaml_config,
    CFG_DIR,
    TdSimpleYaml,
)

PandasDataFrame = TypeVar("pandas.core.frame.DataFrame")


CONFIG_FILE = "config_unks_hunt.yaml"


def get_unk_input(config_file=CONFIG_FILE, cfg_dir=CFG_DIR):
    yaml_dict = load_yaml_config(config_file, cfg_dir=cfg_dir)
    input_class = TdUnkYaml.parse_obj(yaml_dict)

    return input_class, config_file, yaml_dict


class TdUnkYaml(TdSimpleYaml):
    Analysis: list
    Events: List[UnkTimesSchema]
    Unknowns: UnkUnknowns = None

    def get_extra_cids_from_events_list(self):
        """Get extra cids if present"""
        extra_cids = []
        event_list = self.dict()["Events"]
        for list_element in event_list:
            extra_cids.append(dict(list_element)["extra_cids"])
        return extra_cids

    def get_event_output_prefix(self, event):
        return f"{self.Events[event].start_date_time}_{self.Paths.run_suffix}"
