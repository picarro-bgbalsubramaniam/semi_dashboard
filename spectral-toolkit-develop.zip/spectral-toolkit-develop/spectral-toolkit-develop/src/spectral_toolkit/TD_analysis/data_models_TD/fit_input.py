from __future__ import annotations
from typing import List, TypeVar

from spectral_toolkit.TD_analysis.data_models_TD.schema import (
    BaseTimesSchema,
    FitsSchema,
    InterpSchema,
)
from spectral_toolkit.TD_analysis.data_models_TD.input import (
    load_yaml_config,
    CFG_DIR,
    TdSimpleYaml,
)

PandasDataFrame = TypeVar("pandas.core.frame.DataFrame")

CONFIG_FILE = "config_fit.yaml"


def get_fit_input(config_file=CONFIG_FILE, cfg_dir=CFG_DIR):
    yaml_dict = load_yaml_config(config_file, cfg_dir=cfg_dir)
    input_class = TdFitYaml.parse_obj(yaml_dict)

    return input_class, config_file, yaml_dict


class TdFitYaml(TdSimpleYaml):
    Events: List[BaseTimesSchema]

    Fits: List[FitsSchema] = None
    Interp: List[InterpSchema] = None

    def get_event_output_prefix(self, event):
        return f"{self.Events[event].start_date_time}_{self.Paths.run_suffix}"
