from __future__ import annotations
from builtins import float
from typing import Dict, Optional, TypeVar
import numpy as np
import os
from pydantic import BaseModel, ConfigDict
import pandas as pd
from spectral_arithmetic.data_models.base import Array

PandasDataFrame = TypeVar("pandas.core.frame.DataFrame")


class SpectralData(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    fit_df: PandasDataFrame

    spectrum_df: Optional[PandasDataFrame]
    numean: Optional[np.ndarray]
    modes: Optional[np.ndarray]
    res_df: Optional[PandasDataFrame]
    good_fits: Optional[int]
    bad_fits: Optional[int]

    def set_fit_df(self, fit_df):
        self.fit_df = fit_df

    def set_res_df(self, res_df):
        self.res_df = res_df

    def set_good_fits(self, good_fits):
        self.good_fits = good_fits

    def set_bad_fits(self, bad_fits):
        self.bad_fits = bad_fits


class FomSpectralData(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    spectral_FOM: np.ndarray
    # 1D array of FOM values in time (n)
    fit_df: PandasDataFrame
    # dataframe containing spectral data (m, n)
    coef_df: PandasDataFrame
    # index: numean
    # slope: slope values for FOM vs spectra correlation (n) for FOM
    # offset: offset values for FOM vs spectra correlation (n) for FOM
    fom_integral: Optional[float] = None
    conc_scaling: Optional[float] = None

class PeakFitSchema(BaseModel):
    integral: float
    bad_fit: bool
    gaus_integral: float
    gaus_amp: float
    gaus_cen: float
    gaus_sigma: float
    gaus_height: float
    gaus_offset: float
    gaus_offset_slope: float

    cau_gaus_integral: float
    cau_gaus_amp: float
    cau_gaus_cen: float
    cau_gaus_sigma_left: float
    cau_gaus_sigma_right: float
    cau_gaus_f_left: float
    cau_gaus_f_right: float
    cau_gaus_height: float
    cau_gaus_offset: float
    cau_gaus_offset_slope: float


class PeakFitData(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    peak_fit: Dict[str, PeakFitSchema]
    gaus_result_dict: Dict  # [str, ModelResult]
    cau_gaus_result_dict: Dict  # [str, ModelResult]
    trap_data: dict
    # trap_data["%s_integral" % var_name]


class FlowPreconData(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    df_flow_precon: PandasDataFrame
    trap_dict: dict
