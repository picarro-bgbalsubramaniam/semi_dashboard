from __future__ import annotations
from typing import List, Optional, TypeVar, Any
import os
from pydantic import BaseModel
from copy import deepcopy

import re

from pathlib import Path
from ruamel.yaml import YAML

from spectral_toolkit.TD_analysis.data_models_TD.schema import (
    BaseTimesSchema,
)
from spectral_toolkit.TD_analysis.data_models_TD.schema_defaults import (
    analysis_default,
    peak_finding_default,
    create_unk_default,
    create_fits_default,
    create_interp_default,
    create_compounds_default,
    create_ica_default,
)
from spectral_toolkit.TD_analysis.TD_utilities.time_conversions import (
    timestr_to_datetimeindex,
)

PandasDataFrame = TypeVar("pandas.core.frame.DataFrame")

CUR_DIR = os.getcwd()
SRC_DIR = os.path.dirname(CUR_DIR)  # os.path.dirname(CUR_DIR))
CFG_DIR = os.path.join(SRC_DIR, "reg_config")


def load_yaml_config(ini_name: str, cfg_dir: Optional[Path] = CFG_DIR):
    """Load generic yaml config file.

    Parameters:
        ini_name: str
            file name of yaml config file
        cfg_dir: optional path, default CFG_DIR
            folder containing the yaml config file

    Returns:
        yaml_dict:
            dictionary containing data from the yaml file
    """
    yaml = YAML()

    config_path = os.path.join(cfg_dir, ini_name)
    with open(config_path, "r") as file:
        yaml_dict = yaml.load(file)

    return yaml_dict


def save_yaml(yaml_dict: dict, output_flnm: Path):
    """Save yaml file in the output folder.

    Parameters:
        yaml_dict: dict
            dictionary containing data for the yaml file
        output_flnm: path
            path, including file name ending in .yaml
            Location where the yaml file will be saved
    """
    yaml = YAML()
    with open(output_flnm, "w") as file:
        yaml.dump(yaml_dict, file)


def trim_yaml_dict(
    yaml_dict, drop_list, path_drop_list=None, parameters_drop_list=None
):
    for key in drop_list:
        if key in yaml_dict:
            del yaml_dict[key]

    # remove additional paths
    new_drop_list = ["output_path", "figure_path", "analysis_path", "event_path"]
    if path_drop_list is not None:
        for key in path_drop_list:
            new_drop_list.append(key)

    for key in new_drop_list:
        if key in yaml_dict["Paths"]:
            del yaml_dict["Paths"][key]

    # remove unnecessary parameters
    if parameters_drop_list is not None:
        for key in parameters_drop_list:
            if key in yaml_dict["Parameters"]:
                del yaml_dict["Parameters"][key]

    return yaml_dict


def initialize_yamls(yaml_dict, output_path: Path):
    compound_list = ["CO2", "CH4", "H2O"]  # yaml_dict["Variables_to_plot"]

    # INITIALIZE config_fit.yaml
    fit_yaml_dict = deepcopy(yaml_dict)
    # drop Filters, Variables_to_plot, MFCs, Precon_timing, Plot_y_axis_lim, Steps
    drop_list = [
        "Filters",
        "Variables_to_plot",
        "MFCs",
        "Precon_timing",
        "Plot_y_axis_lim",
        "Steps",
    ]
    fit_yaml_dict = trim_yaml_dict(
        fit_yaml_dict,
        drop_list,
        path_drop_list=["temperature_name", "pool_name"],
        parameters_drop_list=[
            "bin_width_min",
            "progress_bar_scale",
            "TD_type",
            "hr_offset",
            "new_fit_list",
        ],
    )

    # add Fits, Interp
    fit_yaml_dict["Fits"] = create_fits_default(compound_list)
    fit_yaml_dict["Interp"] = create_interp_default(compound_list)
    save_yaml(fit_yaml_dict, os.path.join(output_path, "config_fit_init.yaml"))

    # INITIALIZE config_precon.yaml
    precon_yaml_dict = deepcopy(yaml_dict)
    # drop Filters, Variables_to_plot, Plot_y_axis_lim, Steps
    drop_list = ["Filters", "Variables_to_plot", "Plot_y_axis_lim", "Steps"]
    precon_yaml_dict = trim_yaml_dict(
        precon_yaml_dict,
        drop_list,
        path_drop_list=["temperature_name", "pool_name"],
        parameters_drop_list=[
            "bin_width_min",
            "progress_bar_scale",
            "TD_type",
            "hr_offset",
            "new_fit_list",
        ],
    )

    # add Compounds
    precon_yaml_dict["Compounds"] = create_compounds_default(compound_list)
    save_yaml(precon_yaml_dict, os.path.join(output_path, "config_precon_init.yaml"))

    # INITIALIZE config_precon_report.yaml
    report_yaml_dict = deepcopy(yaml_dict)
    # drop Filters, Variables_to_plot, Plot_y_axis_lim
    drop_list = ["Filters", "Variables_to_plot", "Plot_y_axis_lim"]
    report_yaml_dict = trim_yaml_dict(
        report_yaml_dict,
        drop_list,
        path_drop_list=None,
        parameters_drop_list=[
            "bin_width_min",
            "progress_bar_scale",
            "TD_type",
            "hr_offset",
            "new_fit_list",
        ],
    )
    # add Compounds
    report_yaml_dict["Compounds"] = create_compounds_default(compound_list)
    save_yaml(
        report_yaml_dict, os.path.join(output_path, "config_precon_report_init.yaml")
    )

    # INITIALIZE config_spectral_isolation.yaml
    spec_yaml_dict = deepcopy(yaml_dict)
    # drop Filters, Variables_to_plot, MFCs, Precon_timing, Plot_y_axis_lim, Steps
    drop_list = [
        "Filters",
        "Variables_to_plot",
        "MFCs",
        "Precon_timing",
        "Plot_y_axis_lim",
        "Steps",
    ]
    spec_yaml_dict = trim_yaml_dict(
        spec_yaml_dict,
        drop_list,
        path_drop_list=["temperature_name", "pool_name"],
        parameters_drop_list=[
            "bin_width_min",
            "progress_bar_scale",
            "TD_type",
            "hr_offset",
            "new_fit_list",
        ],
    )

    # add Fits, Interp
    spec_yaml_dict["Analysis"] = analysis_default
    spec_yaml_dict["ICA"] = create_ica_default(compound_list)
    spec_yaml_dict["PeakFinding"] = dict(peak_finding_default)
    spec_yaml_dict["FigureOfMerit"] = ["broadband_simple_trapz_ppbC"]
    save_yaml(
        spec_yaml_dict, os.path.join(output_path, "config_spectral_isolation_init.yaml")
    )

    # INITIALIZE config_unks_hunt.yaml
    unks_yaml_dict = deepcopy(yaml_dict)
    # drop Filters, Variables_to_plot, MFCs, Precon_timing, Plot_y_axis_lim, Steps
    drop_list = [
        "Filters",
        "Variables_to_plot",
        "MFCs",
        "Precon_timing",
        "Plot_y_axis_lim",
        "Steps",
    ]
    unks_yaml_dict = trim_yaml_dict(
        unks_yaml_dict,
        drop_list,
        path_drop_list=["temperature_name", "pool_name"],
        parameters_drop_list=[
            "bin_width_min",
            "progress_bar_scale",
            "TD_type",
            "hr_offset",
            "new_fit_list",
        ],
    )

    # add Fits, Interp
    unks_yaml_dict["Analysis"] = analysis_default
    unks_yaml_dict["Unknowns"] = create_unk_default()
    save_yaml(unks_yaml_dict, os.path.join(output_path, "config_unks_hunt_init.yaml"))


def check_path(pathname):
    if not os.path.exists(pathname):
        os.mkdir(pathname)


class EventRunTimes(BaseModel):
    times_list: List[BaseTimesSchema]

    def get_times_dict(self) -> dict:
        """Get a times list as a dictionary.
        Args:
            list_name: optional str, default Times
        Returns:
            time_dict: dictionary
                [{time_num}]
                    time_num: int
                    start_date_time: str
                    end_date_time: str = datetime.now().strftime("%Y%m%d_%H%M%S")
                    rank_std_res: List[float] = []
                    rank_mf_rmse: List[float] = []
        """
        time_dict = {}
        if self.times_list is not None:
            for list_element in self.times_list:
                key = dict(list_element)["time_num"]
                time_dict[key] = list_element
        return time_dict

    def get_time_nums(self):
        """Get event numbers.
        Args:
            list_name: optional str, default Events
        """
        event_time_nums = []
        for list_element in self.times_list:
            event_time_nums.append(dict(list_element)["time_num"])
        return event_time_nums


class YamlMfcs(BaseModel):
    """Class containing input from yaml_dict[MFCs]."""

    sample_flow: Any = 0.0
    first_dilution_flow: Any = 0.0
    second_dilution_flow: Any = 0.0
    third_dilution_flow: Any = 0.0
    overflow_dilution_flow: Any = 0.0
    trap_flow: Any = 500.0
    instrument_flow: Any = 45.0
    concentration_scaler: Optional[float] = 1.0

    def pattern_flow(self, name):
        pattern = r"MFC(\d)"
        if isinstance(self.__dict__[name], str):
            match = re.search(pattern, self.__dict__[name])
            if match is None:
                return float(self.__dict__[name])
            else:
                return self.__dict__[name]
        else:
            return float(self.__dict__[name])

    def get_dict(self):
        MFC_dict = {}
        for name in self.__dict__.keys():
            MFC_dict[name] = self.pattern_flow(name)
        return MFC_dict


class YamlSimplePaths(BaseModel):
    """Class containing input from yaml_dict[Paths]."""

    base_name: Path
    output_path: Path = None
    figure_path: Path = None
    analysis_path: Path = None
    event_path: Path = None
    run_suffix: str

    def set_get_output_path(self):
        self.output_path = Path(os.path.join(self.base_name, "Output"))
        check_path(self.output_path)
        return self.output_path

    def set_analysis_path(
        self, analysis_name: str, parent_path_name: Optional[str] = "output_path"
    ):
        self.analysis_path = self.define_analysis_path(
            analysis_name, parent_path_name=parent_path_name, check=True
        )

    def define_analysis_path(
        self,
        analysis_name: str,
        parent_path_name: Optional[str] = "output_path",
        check: Optional[bool] = False,
    ):
        parent_path = self.__dict__[parent_path_name]
        analysis_path = os.path.join(parent_path, analysis_name)
        if check:
            check_path(analysis_path)

        return analysis_path

    def set_event_path(self, event_start: str):
        self.event_path = self.define_event_path(event_start, check=True)

    def define_event_path(
        self,
        event_start: str,
        check: Optional[bool] = False,
    ):
        event_path = os.path.join(self.output_path, event_start)
        if check:
            check_path(event_path)
        return event_path

    def set_figure_path(
        self, analysis_name: str, parent_path_name: Optional[str] = "event_path"
    ):
        self.figure_path = self.define_figure_path(
            analysis_name, parent_path_name=parent_path_name, check=True
        )

    def define_figure_path(
        self,
        analysis_name: str,
        parent_path_name: Optional[str] = "event_path",
        check: Optional[bool] = False,
    ):
        parent_path = self.__dict__[parent_path_name]
        figure_path = os.path.join(parent_path, analysis_name)
        if check:
            check_path(figure_path)

        return figure_path

    def set_file_paths(self, event_start=None, analysis_name=None):
        """Set output and figures paths."""
        _ = self.set_get_output_path()

        if analysis_name is not None:
            self.set_analysis_path(analysis_name, parent_path_name="output_path")

        if event_start is not None:
            self.set_event_path(event_start)

            if analysis_name is not None:
                self.set_figure_path(analysis_name, parent_path_name="event_path")

        return (
            self.output_path,
            self.analysis_path,
            self.event_path,
            self.figure_path,
        )


class YamlPaths(YamlSimplePaths):
    """Class containing input from yaml_dict[Paths]."""

    temperature_name: Path
    pool_name: Path


class YamlPreconTiming(BaseModel):
    """Class containing input from yaml_dict[Precon_timing]."""

    trap_time_min: float = 20.0
    desorb_time_min: float = 2.0


class YamlParameters(BaseModel):
    """Class containing input from yaml_dict[Parameters]."""

    time_name: str = "index"
    bin_width_min: float = 1.0
    analyzer_name: str = None
    timezone: str = "US/Pacific"
    progress_bar_scale: int = 1
    TD_type: str = "picarro"

    hr_offset: float = 0.0
    new_fit_list: list = ["broadband"]

    # TODO: limit the input options for time_name, analyzer_name, timezone, TD_type, and new_fit_list


class YamlTemperatureSteps(BaseModel):
    """Class containing input from yaml_dict[Steps]."""

    initial_cool: int = 0
    # step number for the initial cooling step, default 0
    pre_trap_pressurize: int = 1
    # step number for the pre trap pressurizing, default 1
    trap: int = 2
    # step number for the trap step, default 2
    post_trap_pressurize: int = 3
    # step number for the post trap pressureize step, default 3
    pressure_equilibration: int = 4
    # step number for the pressure equilibration step after the trap, default 4
    temperature_ramp: int = 5
    # step number for the temperature ramp step, default 5
    hold: int = 6
    # step number for the high temperature hold step, default 6
    final_cool: int = 7
    # step number for the final cooldown step, default 7

    # TODO: force some logic on the step values (initial_cool < trap < ramp < hold < final_cool)
    # TODO: force some logic prohibiting the same number twice


class TdSimpleYaml(BaseModel):
    Paths: YamlSimplePaths
    Parameters: YamlParameters
    Experiment_Times: List[BaseTimesSchema]
    FOM_Events: Optional[List[BaseTimesSchema]]

    def get_exp_date_time_str(self):
        exp_times_dict = self.get_times_dict(list_name="Experiment_Times")
        start_date_time_str = exp_times_dict[0]["start_date_time"]
        end_date_time_str = exp_times_dict[0]["end_date_time"]
        return start_date_time_str, end_date_time_str

    def get_exp_dt(self):
        start_date_time_str, end_date_time_str = self.get_exp_date_time_str()
        start_dt = timestr_to_datetimeindex(
            start_date_time_str, self.Parameters.timezone  # , local=True
        )
        end_dt = timestr_to_datetimeindex(
            end_date_time_str, self.Parameters.timezone  # , local=True
        )
        return start_dt, end_dt

    def get_times_dict(self, list_name: Optional[str] = "Experiment_Times") -> dict:
        """Get a times list as a dictionary.
        Args:
            list_name: optional str, default Times
        Returns:
            time_dict: dictionary
                [{time_num}]
                    time_num: int
                    start_date_time: str
                    end_date_time: str = datetime.now().strftime("%Y%m%d_%H%M%S")
                    rank_std_res: List[float] = []
                    rank_mf_rmse: List[float] = []
        """
        time_dict = {}
        times_list = self.dict()[list_name]
        if times_list is not None:
            for list_element in times_list:
                key = dict(list_element)["time_num"]
                time_dict[key] = list_element
                if key == "start_date_time":
                    time_dict["start_dt"] = timestr_to_datetimeindex(
                        list_element, self.Parameters.timezone
                    )
                if key == "end_date_time":
                    time_dict["end_dt"] = timestr_to_datetimeindex(
                        list_element, self.Parameters.timezone
                    )
        return time_dict

    def get_time_nums(self, list_name: Optional[str] = "Experiment_Times") -> list:
        """Get event numbers.
        Args:
            list_name: optional str, default Events
        """
        event_time_nums = []
        times_list = self.dict()[list_name]
        for list_element in times_list:
            event_time_nums.append(dict(list_element)["time_num"])
        return event_time_nums

    def get_time_starts(self, list_name: Optional[str] = "Experiment_Times") -> list:
        """Get event start datetime strings.
        Args:
            list_name: optional str, default Times
        """
        event_time_starts = []
        times_list = self.dict()[list_name]
        for list_element in times_list:
            event_time_starts.append(dict(list_element)["start_date_time"])
        return event_time_starts

    def get_dt_starts(self, list_name: Optional[str] = "Experiment_Times") -> list:
        """Get event start datetimes.
        Args:
            list_name: optional str, default Times
        """
        event_dt_starts = []
        times_list = self.dict()[list_name]
        for list_element in times_list:
            start_dt = timestr_to_datetimeindex(
                dict(list_element)["start_date_time"], self.Parameters.timezone
            )
            event_dt_starts.append(start_dt)
        return event_dt_starts

    @property
    def output_prefix(self):
        return f"{self.Experiment_Times[0].start_date_time}_{self.Paths.run_suffix}"

    @property
    def run_suffix(self):
        return self.Paths.run_suffix
