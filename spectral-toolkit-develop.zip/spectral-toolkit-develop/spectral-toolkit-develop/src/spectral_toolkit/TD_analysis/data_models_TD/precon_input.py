from __future__ import annotations
from typing import List, TypeVar

from spectral_toolkit.TD_analysis.data_models_TD.schema import (
    BaseTimesSchema,
    CompoundsSchema,
)
from spectral_toolkit.TD_analysis.data_models_TD.input import (
    load_yaml_config,
    YamlPreconTiming,
    CFG_DIR,
    TdSimpleYaml,
    YamlMfcs,
)

PandasDataFrame = TypeVar("pandas.core.frame.DataFrame")

CONFIG_FILE = "config_precon.yaml"


def get_precon_input(config_file=CONFIG_FILE, cfg_dir=CFG_DIR):
    yaml_dict = load_yaml_config(config_file, cfg_dir=cfg_dir)
    input_class = TdPreconYaml.parse_obj(yaml_dict)

    return input_class, config_file, yaml_dict


class TdPreconYaml(TdSimpleYaml):
    Events: List[BaseTimesSchema]

    MFCs: YamlMfcs
    Precon_timing: YamlPreconTiming

    Compounds: List[CompoundsSchema] = None

    def get_event_output_prefix(self, event):
        return f"{self.Events[event].start_date_time}_{self.Paths.run_suffix}"

    def get_input_concs(self):
        input_concs = {}
        for compound_element in self.Compounds:
            input_concs[
                compound_element.compound_name
            ] = compound_element.concentration_ppm
        return input_concs
