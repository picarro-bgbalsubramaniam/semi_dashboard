from pydantic import BaseModel
from typing import Dict, List, Optional

from datetime import datetime

from spectral_toolkit.TD_analysis.TD_utilities.defaults_dict import name_dict


class BaseTimesSchema(BaseModel):
    time_num: int
    start_date_time: str
    end_date_time: str = datetime.now().strftime("%Y%m%d_%H%M%S")

    # TODO: limit the format of start_date_time and end_date_time

    # @validator("start_date_time")
    # def start_format(cls, start_str):
    #     try:
    #         dt = datetime.strptime(start_str, "%Y%m%d_%H%M%S")
    #     except:
    #         dt = datetime.strptime(start_str, "%Y%m%d_%H%M")
    #     return dt

    # @validator("end_date_time")
    # def end_format(cls, end_str):
    #     try:
    #         dt = datetime.strptime(end_str, "%Y%m%d_%H%M%S")
    #     except:
    #         dt = datetime.strptime(end_str, "%Y%m%d_%H%M")
    #     return dt


class CompoundsSchema(BaseModel):
    compound_name: str
    concentration_ppm: float


class FitVarSchema(BaseModel):
    set: Optional[float] = None
    min: Optional[float] = None
    max: Optional[float] = None
    hold: Optional[float] = None

    # TODO: force logic on set vs hold


class FitsSchema(BaseModel):
    variable_name: str
    cen: FitVarSchema = None
    sigma: FitVarSchema = None
    sigma_left: FitVarSchema = None
    sigma_right: FitVarSchema = None
    f_left: FitVarSchema = None
    f_right: FitVarSchema = None
    offset: FitVarSchema = None
    offset_slope: FitVarSchema = None


class InterpSchema(BaseModel):
    variable_name: str
    cen: float = None
    sigma: float = None
    sigma_left: float = None
    sigma_right: float = None
    f_left: float = None
    f_right: float = None


class YamlIca(BaseModel):
    """Class containing input from yaml_dict[ICA]."""

    n_components: int = 3
    canary_names: List[str]
    precisions: Dict
    # TODO: make precisions have the same keys as canary_names


class YamlPeakFinding(BaseModel):
    """Class containg input from yaml_dict[PeakFinding]."""

    height: float = 5.0
    distance: float = 5.0
    prominence: float = 1.0
    width: List[float] = [4.0, 90.0]


class UnkTimesSchema(BaseModel):
    time_num: int
    start_date_time: str
    end_date_time: str = datetime.now().strftime("%Y%m%d_%H%M%S")
    extra_cids: List[int] = []


class UnkCidNamesSchema(BaseModel):
    list_num: int
    cid_names: List[str]


class UnkUnknowns(BaseModel):
    """Class containing input from yaml_dict[Unknowns]."""

    rejected_cids: List[int] = [280, 297, 962]
    cid_list: List[UnkCidNamesSchema] = []

    def get_cid_dict(self):
        cid_dict = {}

        for cid_now in self.cid_list:
            cids = []
            for name in cid_now.cid_names:
                if name.isnumeric():
                    cids.append(int(name))
                elif f"{name}_ppb" in name_dict["new"]:
                    cids.append(int(name_dict["new"][f"{name}_ppb"][2]))
                elif "{name}_ppm" in name_dict["new"]:
                    cids.append(int(name_dict["new"]["{name}_ppm"][2]))
                else:
                    warning_str = f"{name} not in default dictionary"
                    print(warning_str)
                    raise ValueError(warning_str)

            cid_dict[cid_now.list_num] = cids

        return cid_dict
