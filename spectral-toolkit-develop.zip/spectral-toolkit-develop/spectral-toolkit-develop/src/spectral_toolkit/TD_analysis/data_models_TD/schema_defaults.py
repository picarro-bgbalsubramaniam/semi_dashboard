from spectral_toolkit.TD_analysis.data_models_TD.schema import (
    CompoundsSchema,
    FitVarSchema,
    FitsSchema,
    InterpSchema,
    YamlIca,
    YamlPeakFinding,
    UnkCidNamesSchema,
    UnkUnknowns,
)


analysis_default = ["unknown_FOM", "unknown_canary_FOM"]
peak_finding_default = YamlPeakFinding()


def create_fits_default(compound_list):
    fits_default = []
    for compound in compound_list:
        fits_default.append(
            FitsSchema(
                variable_name=compound,
                cen=FitVarSchema(set=100, min=10, max=200),
                sigma_left=FitVarSchema(set=20, min=10, max=40),
                sigma_right=FitVarSchema(set=20, min=10, max=40),
                f_left=FitVarSchema(set=0.8, min=0, max=1),
                f_right=FitVarSchema(set=0.8, min=0, max=1),
                offset=FitVarSchema(set=0),
                offset_slope=FitVarSchema(set=0),
            )
        )

    fits_dict_list = []
    for fit_now in fits_default:
        fit_temp = dict(fit_now)
        for key, value in fit_temp.items():
            if key != "variable_name" and value is not None:
                fit_temp[key] = dict(value)
        fits_dict_list.append(fit_temp)

    return fits_dict_list


def create_interp_default(compound_list):
    interp_default = []
    for compound in compound_list:
        interp_default.append(dict(InterpSchema(variable_name=compound)))
    return interp_default


def create_compounds_default(compound_list):
    compounds_default = []
    for compound in compound_list:
        compounds_default.append(
            dict(CompoundsSchema(compound_name=compound, concentration_ppm=0))
        )
    return compounds_default


def create_ica_default(compound_list):
    precisions = {}
    for compound in compound_list:
        precisions[compound] = 0.0
    ica_default = YamlIca(
        n_components=3,
        canary_names=compound_list,
        precisions=precisions,
    )
    return dict(ica_default)


def create_unk_default():
    unknowns_default = dict(
        UnkUnknowns(
            cid_list=[
                UnkCidNamesSchema(
                    list_num=1,
                    cid_names=[
                        "nh3",
                        "n2o",
                        "difluoroethane",
                        "acetone",
                        "isopropyl_alcohol",
                    ],
                )
            ]
        )
    )
    for i, list_element in enumerate(unknowns_default["cid_list"]):
        unknowns_default["cid_list"][i] = dict(list_element)
    return unknowns_default
