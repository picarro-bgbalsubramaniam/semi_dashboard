from __future__ import annotations
from typing import Dict, List, Optional, TypeVar

from pathlib import Path

from spectral_toolkit.TD_analysis.data_models_TD.input import (
    load_yaml_config,
    YamlPaths,
    YamlPreconTiming,
    CFG_DIR,
    TdSimpleYaml,
    YamlTemperatureSteps,
    YamlMfcs,
)

PandasDataFrame = TypeVar("pandas.core.frame.DataFrame")

CONFIG_FILE = "config_data.yaml"


def get_data_input(config_file=CONFIG_FILE, cfg_dir: Optional[Path] = CFG_DIR):
    # cfg_dir = os.path.dirname(os.path.dirname(os.getcwd()))  # go up two folders
    yaml_dict = load_yaml_config(config_file, cfg_dir=cfg_dir)
    input_class = TdDataYaml.parse_obj(yaml_dict)

    return input_class, config_file, yaml_dict


class TdDataYaml(TdSimpleYaml):
    Paths: YamlPaths  # updated

    Filters: Dict = None
    Variables_to_plot: List[str] = []
    MFCs: YamlMfcs
    Precon_timing: YamlPreconTiming
    Plot_y_axis_lim: Dict = None
    Steps: YamlTemperatureSteps = None

    def get_filters(self) -> list:
        """Output filters list.

        Returns:
            filters: list
                List containing lines for each filter condition.
                Only minimum, maximum, and set value supported.
        """
        filters = list()
        # NOTE: filter removes data
        if self.Filters is not None:
            for key in self.Filters:
                if "var_" in key:
                    new_key = self.Filters[key]
                    condition_string = ""
                    # set condition for a minimum allowed value
                    if f"{new_key}_min" in self.Filters:
                        min_value = self.Filters[f"{new_key}_min"]
                        condition_string = f"y <= {min_value}"
                        print(f"set {new_key} minimum to {min_value}")
                    else:
                        min_value = None
                    # set condition for a maximum allowed value
                    if f"{new_key}_max" in self.Filters:
                        max_value = self.Filters[f"{new_key}_max"]
                        if len(condition_string) > 1:
                            condition_string += f" or y >= {max_value}"
                        else:
                            condition_string = f"y >= {max_value}"
                        print(f"set {new_key} maximum to {max_value}")
                    else:
                        max_value = None
                    # set condition for the only allowed value
                    if f"{new_key}_value" in self.Filters:
                        value = self.Filters[f"{new_key}_value"]
                        condition_string = f"y != {value}"
                        print(f"set {new_key} to {value}")

                    filters.append({"key": new_key, "condition": condition_string})
        return filters

    def get_y_axis_lim(self, var_names: Optional[list] = None) -> dict:
        """Collect y axis limit information.

            When the Plot_y_axis_lim section is present y axis limits are set for the variables
            within this section.

        Args:
            var_names: list
                list of variable names to be plotted as timeseries

        Returns:
            var_lims: dict
                dictionary containing y axis limits for specific variable timeseries plots.
                {var_name: {limit_type: float value}}
                limit types: min, max

        """
        if var_names is None:
            var_names = self.Variables_to_plot
        var_lims = {}
        if self.Plot_y_axis_lim is not None:
            for name in var_names:
                var_lims[name] = {}
                for lim_name in self.Plot_y_axis_lim:
                    if name in lim_name:
                        key_bits = lim_name.split("_")
                        suffix = key_bits[-1]
                        var_lims[name][suffix] = float(self.Plot_y_axis_lim[lim_name])
        return var_lims
