from __future__ import annotations
from typing import List, TypeVar, Optional

from spectral_toolkit.TD_analysis.data_models_TD.schema import (
    BaseTimesSchema,
    YamlIca,
    YamlPeakFinding,
)
from spectral_toolkit.TD_analysis.data_models_TD.input import (
    load_yaml_config,
    CFG_DIR,
    TdSimpleYaml,
    YamlPreconTiming,
    TdSimpleYaml,
    YamlMfcs,
)

PandasDataFrame = TypeVar("pandas.core.frame.DataFrame")

CONFIG_FILE = "config_spectral_isolation.yaml"


def get_spec_input(config_file=CONFIG_FILE, cfg_dir=CFG_DIR):
    yaml_dict = load_yaml_config(config_file, cfg_dir=cfg_dir)
    input_class = TdSpecYaml.parse_obj(yaml_dict)

    return input_class, config_file, yaml_dict


class TdSpecYaml(TdSimpleYaml):
    Analysis: list
    Events: List[BaseTimesSchema]

    FOM_Events: List[BaseTimesSchema] = None
    FigureOfMerit: List[str] = None

    MFCs: YamlMfcs
    Precon_timing: YamlPreconTiming

    ICA: Optional[YamlIca] = None
    PeakFinding: YamlPeakFinding

    def get_event_output_prefix(self, event):
        return f"{self.Events[event].start_date_time}_{self.Paths.run_suffix}"
