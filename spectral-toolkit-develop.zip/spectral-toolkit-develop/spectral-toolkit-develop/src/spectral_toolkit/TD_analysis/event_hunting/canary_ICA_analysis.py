import os
import pickle
import pandas as pd
from pathlib import Path
import pytz
from typing import Tuple

from spectral_toolkit.TD_analysis.data_models_TD.spectral_input import TdSpecYaml
from spectral_toolkit.TD_analysis.TD_utilities.utilities_plotting import (
    plot_variable,
    ICA_canary_function_plot,
)
from spectral_toolkit.TD_analysis.TD_utilities.utilities_for_timeseries_TD import (
    find_name,
    good_times,
)

from spectral_toolkit.TD_analysis.TD_utilities.utilities_ICA import (
    canary_ICA_analysis,
    create_canary_FOM,
)


def find_canary_FOM(
    input_class: TdSpecYaml,
    run_start: str,
    seq_prefix: str,
    spec_data_flnm: Path,
) -> Tuple[list, pd.DataFrame]:
    """Compile canary FOM.

    Parameters:
        input_class: TdSpecYaml
            Paths: YamlSimplePaths
            Parameters: YamlParameters
            Experiment_Times: List[BaseTimesSchema]
            Analysis: list
            Events: List[BaseTimesSchema]

            FOM_Events: List[BaseTimesSchema] = None
            FigureOfMerit: List[str] = None
            ICA: YamlIca = None
            PeakFinding: YamlPeakFinding
        run_start: str
            string indicating the start date time (YYYYMMDD_HHMMSS)
        seq_prefix: str
            string to append to file names
        spec_data_flnm: Path
            filename = os.path.join(
                analysis_dir,
                f"{start_date_time_str}_{input_class.run_suffix}_parse_combo_spectra.pkl",
            )

    Saves:
        dict_out = {
            "input_class": input_class,
            "start_datetime": start_datetime,
            "end_datetime": stop_datetime,
            "sequence_series": sequence_series,
            "spectra": spectra,
            "df": comp_df,
        }
        dict_out.update(
            {
                "df": df_updated,
                "ica_results": ica_results,
                "FOM_list": FOM_list,
            }
        )
        filename = os.path.join(
            analysis_dir, f"{run_start}_{seq_prefix}_ICA_canary_analysis.pkl"
        )

    Returns:
        FOM_list: list
            list of the names of FOM variables
        df_updated: pd.DataFrame
            pandas dataframe with timezone aware datetimeindex
            contains combined private and combo log data
            updated with canary timeseries data for FOM analysis

    """
    with open(spec_data_flnm, "rb") as f:
        pklfile_spectra = pickle.load(f)
        # spectra_dict = {
        #     "input_class": input_class,
        #     "start_datetime": start_datetime,
        #     "end_datetime": stop_datetime,
        #     "sequence_series": sequence_series,
        #     "spectra": spectra,
        #     "df": comp_df,
        # }
    start_all_dt = pklfile_spectra["start_datetime"]
    end_all_dt = pklfile_spectra["end_datetime"]

    df = pklfile_spectra["df"]

    ICA_dict = input_class.ICA.dict()
    time_name = input_class.Parameters.time_name
    tz = pytz.timezone(input_class.Parameters.timezone)

    _, analysis_dir, _, figures_dir = input_class.Paths.set_file_paths(
        event_start=run_start, analysis_name="canary ICA"
    )

    filename = os.path.join(
        analysis_dir, f"{run_start}_{seq_prefix}_ICA_canary_analysis.pkl"
    )

    # grab time appropriate data
    bool_keep = good_times(df, start_dt=start_all_dt, end_dt=end_all_dt, tz=tz)

    # get ICA results and plot them
    ica_results, ica_df = canary_ICA_analysis(
        df.iloc[bool_keep], ICA_dict, time_name=time_name
    )

    prefix = f"{run_start}_{seq_prefix}"
    ICA_canary_function_plot(ica_results, prefix, figures_dir)
    ####################################################################
    for var_name in ica_df.keys():
        new_name, _ = find_name(var_name, ica_df)
        if new_name in ica_df:
            prefix = f"{run_start}_{seq_prefix}"
            plot_variable(time_name, var_name, ica_df, prefix, figures_dir)
    ####################################################################

    df_updated = create_canary_FOM(
        ica_results, df.iloc[bool_keep], abs_thresh=3.0, rel_ratio=0.1
    )
    canary_names = []
    for unk_name in ica_df.keys():
        unk_split = unk_name.split("_")
        canary_names.append(f"canary_FOM_{unk_split[-1]}")
    df_updated.dropna(axis=0, subset=canary_names, inplace=True)

    FOM_list = []
    count = 0
    for var_name in canary_names:
        FOM_list.append(var_name)
        count += 1

        new_name, _ = find_name(var_name, df_updated)
        if new_name in df_updated:
            prefix = f"{run_start}_{seq_prefix}"
            plot_variable(time_name, var_name, df_updated, prefix, figures_dir)

    dict_out = pklfile_spectra
    dict_out.update(
        {
            "df": df_updated,
            "ica_results": ica_results,
            "FOM_list": FOM_list,
        }
    )

    with open(filename, "wb") as outpkl:
        pickle.dump(dict_out, outpkl, -1)

    return FOM_list, df_updated
