import os
import pickle
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Optional
import pytz
from datetime import datetime

from spectral_toolkit.TD_analysis.data_models_TD.input import EventRunTimes
from spectral_toolkit.TD_analysis.data_models_TD.spectral_input import TdSpecYaml
from spectral_toolkit.TD_analysis.data_models_TD.output_models import SpectralData
from spectral_toolkit.TD_analysis.TD_utilities.time_conversions import (
    timestr_to_datetime,
)
from spectral_toolkit.TD_analysis.TD_utilities.utilities_plotting import (
    plot_FOM_spectra,
)

from spectral_toolkit.TD_analysis.TD_utilities.utilities_FOM import (
    correlate_freq_FOM,
    convert_event_fit_slope_to_loss,
)


def create_FOM_correlation_spectra(
    input_class: TdSpecYaml,
    run_start: str,
    seq_prefix: str,
    FOM_name: str,
    spec_data_flnm: Path,
    events: EventRunTimes,
    folder_name: Optional[str] = "FOM",
    start_spec_dt: Optional[datetime] = None,
    end_spec_dt: Optional[datetime] = None,
    spectra: Optional[SpectralData] = None,
    df: Optional[pd.DataFrame] = None,
):
    """Compile FOM correlation based spectra.

    Parameters:
        input_class: TdSpecYaml
            Paths: YamlSimplePaths
            Parameters: YamlParameters
            Experiment_Times: List[BaseTimesSchema]
            Analysis: list
            Events: List[BaseTimesSchema]

            FOM_Events: List[BaseTimesSchema] = None
            FigureOfMerit: List[str] = None
            ICA: YamlIca = None
            PeakFinding: YamlPeakFinding
        run_start: str
            string indicating the start date time (YYYYMMDD_HHMMSS)
        seq_prefix: str
            string to append to file names
        FOM_name: str
            variable name of the figure of merit to be used to find peaks
        spec_data_flnm: Path
            filename = os.path.join(
                analysis_dir,
                f"{start_date_time_str}_{input_class.run_suffix}_parse_combo_spectra.pkl",
            )
        events: EventRunTimes object
            times_list: list of TimesSchema
                time_num: int
                start_date_time: str
                end_date_time: str = datetime.now().strftime("%Y%m%d_%H%M%S")
        folder_name: optional string, default FOM
            string used to define the output location file for this analysis.
            This string will be used as an input to the set_file_paths method in the input_class.
        df: optional pandas DataFrame, default None
            timeseries dataframe containing FOM variable data
            If None, the data will be collected from the spec_data file


    Raises:

    Saves:
        filename = os.path.join(
            analysis_dir, f"{run_start}_{seq_prefix}_{FOM_name}_FOM_correlation.pkl"
        )
        results_dict[(event_start, event_end)] = event_fit
            event_fit: FomSpectralData
                spectral_FOM: np.array
                    1D array of FOM values in time (n)
                fit_df: pd.DataFrame
                    dataframe containing spectral data (m, n)
                coef_df: pd.DataFrame
                    index: numean (m)
                    slope: slope values for FOM vs spectra correlation (m)
                    offset: offset values for FOM vs spectra correlation (m)
    """
    if start_spec_dt is None and end_spec_dt is None and spectra is None:
        with open(spec_data_flnm, "rb") as f:
            pklfile_spectra = pickle.load(f)
            # spectra_dict = {
            #     "input_class": input_class,
            #     "start_datetime": start_datetime,
            #     "end_datetime": stop_datetime,
            #     "sequence_series": sequence_series,
            #     "spectra": spectra,
            #     "df": comp_df,
            # }
        start_spec_dt = pklfile_spectra["start_datetime"]
        end_spec_dt = pklfile_spectra["end_datetime"]

        spectra = pklfile_spectra["spectra"]

        if df is None:
            df = pklfile_spectra["df"]

    FOM_event_dict = input_class.get_times_dict(list_name="FOM_Events")
    timezone = input_class.Parameters.timezone
    tz = pytz.timezone(timezone)

    _, analysis_dir, _, figures_dir = input_class.Paths.set_file_paths(
        event_start=run_start, analysis_name=folder_name
    )

    results_dict = {}  # dictionary for results

    time_nums = events.get_time_nums()
    times_dict = events.get_times_dict()

    if len(FOM_event_dict) > 0:
        e_count = max(time_nums) + 1
        for event in FOM_event_dict:  # cycle through found peaks
            times_dict.update(
                {
                    e_count: (
                        FOM_event_dict[event].start_date_time,
                        FOM_event_dict[event].end_date_time,
                    )
                }
            )
            e_count += 1
    for event in times_dict.values():  # cycle through run and peak events
        start_now_dt = timestr_to_datetime(event.start_date_time)
        end_now_dt = timestr_to_datetime(event.end_date_time)

        start_now_dt = tz.localize(start_now_dt)
        end_now_dt = tz.localize(end_now_dt)

        if start_now_dt >= start_spec_dt and end_now_dt <= end_spec_dt:
            # populate dictionary with spectra based on FOM
            event_fit = correlate_freq_FOM(
                FOM_name,
                df,
                spectra,
                start_dt=start_now_dt,
                end_dt=end_now_dt,
            )

            event_fit = convert_event_fit_slope_to_loss(input_class, event_fit)

            fname_prefix = f"{event.start_date_time}_{event.end_date_time}_{FOM_name}_{input_class.run_suffix}"
            plot_FOM_spectra(event_fit, fname_prefix, figures_dir)

            results_dict[
                (
                    event.start_date_time,
                    event.end_date_time,
                )
            ] = event_fit

    filename = os.path.join(
        analysis_dir, f"{run_start}_{seq_prefix}_{FOM_name}_FOM_correlation.pkl"
    )
    with open(filename, "wb") as outpkl:
        pickle.dump(results_dict, outpkl, 1)
