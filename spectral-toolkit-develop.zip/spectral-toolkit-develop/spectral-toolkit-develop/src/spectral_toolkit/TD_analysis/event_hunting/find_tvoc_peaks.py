from scipy.signal import find_peaks

import numpy as np
import os
import pickle
from pathlib import Path
from typing import Optional
import pandas as pd

from spectral_toolkit.TD_analysis.data_models_TD.input import EventRunTimes
from spectral_toolkit.TD_analysis.data_models_TD.spectral_input import TdSpecYaml
from spectral_toolkit.TD_analysis.TD_utilities.utilities_for_timeseries_TD import (
    get_all_data,
)
from spectral_toolkit.TD_analysis.TD_utilities.utilities_plotting import (
    plot_found_peaks,
)


def find_peak_events(
    input_class: TdSpecYaml,
    run_start: str,
    seq_prefix: str,
    FOM_name: str,
    spec_data_flnm: Path,
    df: Optional[pd.DataFrame] = None,
    folder_name: Optional[str] = "FOM",
) -> EventRunTimes:
    """Find peaks in total VOC timeseries.

    Parameters:
        input_class: TdSpecYaml
            Paths: YamlSimplePaths
            Parameters: YamlParameters
            Experiment_Times: List[BaseTimesSchema]
            Analysis: list
            Events: List[BaseTimesSchema]

            FOM_Events: List[BaseTimesSchema] = None
            FigureOfMerit: List[str] = None
            ICA: YamlIca = None
            PeakFinding: YamlPeakFinding
        run_start: str
            string indicating the start date time (YYYYMMDD_HHMMSS)
        seq_prefix: str
            string to append to file names
        FOM_name: str
            variable name of the figure of merit to be used to find peaks
        spec_data_flnm: Path
            filename = os.path.join(
                analysis_dir,
                f"{start_date_time_str}_{input_class.run_suffix}_parse_combo_spectra.pkl",
            )
        df: optional pandas DataFrame, default None
            timeseries dataframe containing FOM variable data
            If None, the data will be collected from the spec_data file
        folder_name: optional string, default FOM
            string used to define the output location file for this analysis.
            This string will be used as an input to the set_file_paths method in the input_class.

    Raises:

    Saves:
        filename = os.path.join(
            analysis_dir, f"{run_start}_{seq_prefix}_{FOM_name}_peak_finding_FOM.pkl"
        )
        events: EventRunTimes object
            times_list: list of Times_schema
                time_num: int
                start_date_time: str
                end_date_time: str = datetime.now().strftime("%Y%m%d_%H%M%S")

    Returns:
        events: EventRunTimes object
            times_list: list of Times_schema
                time_num: int
                start_date_time: str
                end_date_time: str = datetime.now().strftime("%Y%m%d_%H%M%S")
    """
    with open(spec_data_flnm, "rb") as f:
        pklfile_spectra = pickle.load(f)
        # spectra_dict = {
        #     "input_class": input_class,
        #     "start_datetime": start_datetime,
        #     "end_datetime": stop_datetime,
        #     "sequence_series": sequence_series,
        #     "spectra": spectra,
        #     "df": comp_df,
        # }
    start_dt = pklfile_spectra["start_datetime"]
    end_dt = pklfile_spectra["end_datetime"]
    if df is None:
        df = pklfile_spectra["df"]

    time_name = input_class.Parameters.time_name

    peak_finding_dict = input_class.PeakFinding.dict()

    _, analysis_dir, _, figures_dir = input_class.Paths.set_file_paths(
        event_start=run_start, analysis_name=folder_name
    )

    times_list = []

    print(f"parent run: {start_dt} to {end_dt}")

    time_vector = df.index
    y_vector = get_all_data(FOM_name, df)

    peaks, properties = find_peaks(y_vector, **peak_finding_dict)
    peak_widths = properties["widths"].astype(int)
    peaks_left = (peaks - np.round(peak_widths)).astype(int)
    peaks_right = (peaks + np.round(peak_widths)).astype(int)

    # Full run as event 0
    start_date_time = time_vector[0].strftime("%Y%m%d_%H%M%S")
    end_date_time = time_vector[-1].strftime("%Y%m%d_%H%M%S")

    times_list.append(
        {
            "time_num": 0,
            "start_date_time": start_date_time,
            "end_date_time": end_date_time,
        }
    )

    print(f"{FOM_name}, full run {start_date_time} to {end_date_time}")

    len_time = len(time_vector)

    if len(peaks_left) > 0:
        peaks_left = np.maximum(peaks_left, 0)
        peaks_left = np.minimum(peaks_left, len_time - 2)

    if len(peaks_right) > 0:
        peaks_right = np.minimum(peaks_right, len_time - 1)
        peaks_right = np.maximum(peaks_right, 1)

    # Each peak found
    for event, (p_l, p_r) in enumerate(zip(peaks_left, peaks_right)):
        start_date_time = time_vector[p_l].strftime("%Y%m%d_%H%M%S")
        end_date_time = time_vector[p_r].strftime("%Y%m%d_%H%M%S")

        times_list.append(
            {
                "time_num": event + 1,
                "start_date_time": start_date_time,
                "end_date_time": end_date_time,
            }
        )

        print(f"{FOM_name}, {start_date_time} to {end_date_time}")

    prefix = f"{run_start}_{seq_prefix}"
    plot_found_peaks(
        time_vector,
        y_vector,
        peaks,
        peaks_left,
        peaks_right,
        time_name,
        FOM_name,
        prefix,
        figures_dir,
    )

    events = EventRunTimes(times_list=times_list)

    filename = os.path.join(
        analysis_dir, f"{run_start}_{seq_prefix}_{FOM_name}_peak_finding_FOM.pkl"
    )
    with open(filename, "wb") as outpkl:
        pickle.dump(events, outpkl, 1)

    return events
