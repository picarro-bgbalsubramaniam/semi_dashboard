import os
import pickle
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Optional

from spectral_toolkit.TD_analysis.data_models_TD.unks_input import TdUnkYaml
from spectral_toolkit.sam_analysis.compound_identification import (
    perform_multicomponent_fit,
    _get_and_filter_model_functions,
    IsoType,
)
from spectral_toolkit.constants import identification_constants as ic
from spectral_toolkit.plotting.spectral_hunting_plot import get_spectral_hunting_plot
from spectral_toolkit.df_operations.spectral_fits_results_aggregation import (
    get_stacked_fit_solutions,
    define_solutions_spectral_dataset,
)
from spectral_toolkit.sam_analysis.unknown_stats import (
    make_unknown_results_stats,
    filter_and_summarize,
)

from spectral_toolkit.TD_analysis.TD_utilities.utilities_unknown_fitting import (
    _create_return_data_TD,
)

from spectral_toolkit.db_clients.mongo_spectral_library import (
    get_mongo_spectral_library_client,
)

from spectral_arithmetic.data_models.base import Array


def find_unknowns(
    input_class: TdUnkYaml,
    run_start: str,
    extra_cids: list,
    run_suffix: str,
    correlation_dict: dict,
    file_ending: str,
    folder_name: str,
    spectra_var: Optional[str] = "slope",
    nominal_pressure: Optional[float] = 140,
):
    """Analyze event unknowns with SAT tools.

    Args:
        input_class: TdUnkYaml
        run_start: str
            start date time of a given TD run (YYYYMMDD_HHMMSS or YYYYMMDD_HHMM)
        extra_cids: list
        run_suffix: str
        correlation_dict: dict
            results_dict[(event_start, event_end)] = event_fit

            event_fit: FOM_spectral_data
                spectral_FOM: np.array
                    1D array of FOM values in time (n)
                fit_df: pd.DataFrame
                    dataframe containing spectral data (m, n)
                coef_df: pd.DataFrame
                    index: numean
                    slope: slope values for FOM vs spectra correlation (n)
                    offset: offset values for FOM vs spectra correlation (n)
        file_ending: str
            String to append to the end of the file name to indicate analysis type
                unknown_FOM, unknown_ICA, etc.
        folder_name: str
            Name of the folder into which the analysis files will be saved.
            This folder will be in base_name/Output/
        spectra_var: optional string, default 'slope'
            Name of the variable saved in event_fit to be used as a spectra for fitting.
        nominal_pressure: optional float, default 140


    Raises:

    Saves:
        filename = os.path.join(analysis_dir, f"{run_start}_{run_suffix}_{file_ending}.pkl")

        all_results[(start_date_time, end_date_time)]["list_%s" % str(cid_key)]

            ["diff_data"] = diff_data
            ["fit_data"] = fit_data
            ["spec_data"] = spec_data
                spec_data[cid_list_num] = {
                    "nu": fit_results.nu,
                    "loss": fit_results.loss,
                    "err": fit_results.std_err,
                    "alist": fit_results.a_list,
                    "pnames": fit_results.parameter_names,
                    "fit_poly": fit_results.fit,
                }
            ["dfk_stats"] = dfk_stats
            ["events_list"] = events_list
    """
    cid_dict = input_class.Unknowns.get_cid_dict()

    _, analysis_dir, _, figures_dir = input_class.Paths.set_file_paths(
        event_start=run_start, analysis_name=folder_name
    )

    compounds_ignore = input_class.Unknowns.rejected_cids
    model_functions = _get_and_filter_model_functions(
        nominal_pressure, compounds_ignore
    )

    all_results = {}  # add run event to dictionary

    for (start_date_time, end_date_time), event_fit in correlation_dict.items():
        all_results[(start_date_time, end_date_time)] = {}

        for cid_key, default_required_cids in cid_dict.items():
            required_cids = list(set(default_required_cids) | set(extra_cids))

            nu = event_fit.coef_df.index
            spectra = event_fit.coef_df[spectra_var]
            run_name = f"{run_start}_{run_suffix}"
            event_name = (
                f"{start_date_time}_{end_date_time}_{run_suffix}_list_{str(cid_key)}"
            )
            unks_dict = unks_shell(
                nu,
                spectra,
                model_functions,
                required_cids,
                cid_key,
                run_name,
                event_name,
                file_ending,
                figures_dir,
            )

            save_tables(
                unks_dict,
                event_name,
                file_ending,
                analysis_dir,
            )

            all_results[(start_date_time, end_date_time)][f"list_{cid_key}"] = unks_dict

    filename = os.path.join(analysis_dir, f"{run_start}_{run_suffix}_{file_ending}.pkl")
    with open(filename, "wb") as outpkl:
        pickle.dump(all_results, outpkl, 1)


def unks_shell(
    nu: np.array,
    spectra: np.array,
    model_functions,
    required_cids: list,
    cid_key: int,
    run_name: str,
    event_name: str,
    file_ending: str,
    figures_dir: Path,
) -> dict:
    """Performs unknown compound hunting and creates figures and tables.

    Args:
        nu: array
            wavelength vector
        spectra: array
            loss vector to be fit
        model_functions:
        required_cids: list
            list of cids required to be in the fit
        cid_key: int
            integer key for the required cid list from the input
        run_name: str
        event_name: str
        figures_dir: Path
            path location to which figures will be saved
        analysis_dir:
            path location to which analyzed data will be saved

    Returns:
        results_dict: dict
            results_dict = {}
            results_dict["diff_data"] = diff_data
            results_dict["fit_data"] = fit_data
            results_dict["spec_data"] = spec_data
                spec_data[cid_list_num] = {
                    "nu": fit_results.nu,
                    "loss": fit_results.loss,
                    "err": fit_results.std_err,
                    "alist": fit_results.a_list,
                    "pnames": fit_results.parameter_names,
                    "fit_poly": fit_results.fit,
                }
            results_dict["dfk_stats"] = dfk_stats
            results_dict["events_list"] = events_list

    """
    min_nu = np.floor(np.nanmin(nu))
    max_nu = np.ceil(np.nanmax(nu))
    plotting_nu = np.linspace(min_nu, max_nu, 2000)

    fit_results, stats = perform_multicomponent_fit(
        nu,
        np.array(spectra),
        np.ones(len(spectra)),
        model_functions,
        ic.NUM_COMPOUNDS_DIFF,
        required_cids=required_cids,
    )

    diff_data, fit_data, spec_data = _create_return_data_TD(
        fit_results,
        stats,
        {},  # diff_data,
        {},  # fit_data,
        {},  # spec_data,
        str(cid_key),
        run_name,
        IsoType.CORRELATION,
    )

    experimental_datapoints = pd.Series(
        index=spec_data[str(cid_key)]["nu"],
        data=spec_data[str(cid_key)]["loss"],
    ).loc[min_nu:max_nu]

    available_fits = list(fit_data[str(cid_key)].keys())
    stacked_df = get_stacked_fit_solutions(
        fit_data[str(cid_key)][available_fits.pop(0)],
        [fit_data[str(cid_key)][fit].reset_index() for fit in available_fits],
    )
    db_client = get_mongo_spectral_library_client()
    solution_xrds = define_solutions_spectral_dataset(
        db_client=db_client,
        solutions_fit_df=stacked_df,
        experimental_datapoints=experimental_datapoints,
        evaluation_nu=plotting_nu,
        top_n=5,
    )
    db_client.client.close()
    fig = get_spectral_hunting_plot(
        solution_xrds,
        title_text=f"List {cid_key}",
        species_colormap={"offset": "black"},
    )
    fig.write_html(os.path.join(figures_dir, f"{event_name}_{file_ending}.html"))

    for fit in fit_data[str(cid_key)].keys():
        if "fit_0" in fit:
            break

    original_rmse = fit_data[str(cid_key)][fit].rmse

    dfk_stats = make_unknown_results_stats(
        stacked_df, 4, original_rmse, wrmse_range=0.02
    )

    events_list = filter_and_summarize(
        dfk_stats, str(cid_key), f"{event_name}_{file_ending}"
    )

    results_dict = {}
    results_dict["diff_data"] = diff_data
    results_dict["fit_data"] = fit_data
    results_dict["spec_data"] = spec_data
    results_dict["dfk_stats"] = dfk_stats
    results_dict["events_list"] = events_list

    return results_dict


def save_tables(
    unks_dict: dict,
    event_name: str,
    file_ending: str,
    analysis_dir: Path,
):

    # save full list as html and excel
    fname = f"{event_name}_{file_ending}_df"

    flnm = os.path.join(analysis_dir, f"{fname}.html")
    html = unks_dict["dfk_stats"].to_html()
    with open(flnm, "w") as f:
        f.write(html)

    flnm = os.path.join(analysis_dir, f"{fname}.xlsx")
    unks_dict["dfk_stats"].to_excel(flnm)

    # save filtered data as html and excel
    events_df = pd.DataFrame(unks_dict["events_list"])
    fname = f"{event_name}_{file_ending}_events_df"

    flnm = os.path.join(analysis_dir, f"{fname}.html")
    html = events_df.to_html()
    with open(flnm, "w") as f:
        f.write(html)

    flnm = os.path.join(analysis_dir, f"{fname}.xlsx")
    events_df.to_excel(flnm)
