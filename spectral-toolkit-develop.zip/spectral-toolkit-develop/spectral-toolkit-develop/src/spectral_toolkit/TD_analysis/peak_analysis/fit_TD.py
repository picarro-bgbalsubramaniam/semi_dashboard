import numpy as np
import os
import pickle
from pathlib import Path
from typing import Optional
import pandas as pd
import pytz

from spectral_toolkit.TD_analysis.data_models_TD.fit_input import TdFitYaml
from spectral_toolkit.TD_analysis.data_models_TD.output_models import PeakFitData

from spectral_toolkit.TD_analysis.TD_utilities.utilities_for_timeseries_TD import (
    good_times,
)

from spectral_toolkit.TD_analysis.TD_utilities.utilities_TD_fit import (
    fit_sources,
    integrate_trap,
)
from spectral_toolkit.TD_analysis.TD_utilities.TD_plotting import plot_fits


def fit_TD_peaks(
    input_class: TdFitYaml,
    run_start: str,
    seq_prefix: str,
    spec_data_flnm: Path,
    df: Optional[pd.DataFrame] = None,
) -> PeakFitData:
    """
    Fit concentrations as TD desorption peaks.

    Parameters:
        input_class: TdFitYaml
            Paths: YamlSimplePaths
            Parameters: YamlParameters
            Experiment_Times: List[BaseTimesSchema]
            Events: List[BaseTimesSchema]
            Fits: List[FitsSchema] = None
            Interp: List[InterpSchema] = None
        run_start: str
            string indicating the start date time (YYYYMMDD_HHMMSS)
        seq_prefix: str
            string to append to file names
        spec_data_flnm: Path
            filename = os.path.join(
                analysis_dir,
                f"{start_date_time_str}_{input_class.run_suffix}_parse_combo_spectra.pkl",
            )
        df: optional pandas DataFrame, default None
            timeseries dataframe containing FOM variable data
            If None, the data will be collected from the spec_data file

    Saves:
        pfd_out: PeakFitData
            peak_fit: Dict[str, PeakFitSchema]
            gaus_result_dict: Dict  # [str, ModelResult]
            cau_gaus_result_dict: Dict  # [str, ModelResult]
            trap_data: dict
            # trap_data["%s_integral" % var_name]
        filename = os.path.join(
            analysis_dir, f"{run_start}_{seq_prefix}_fit_compiled_TD_analysis.pkl"
        )

    Returns:
        pfd_out: PeakFitData
            peak_fit: Dict[str, PeakFitSchema]
            gaus_result_dict: Dict  # [str, ModelResult]
            cau_gaus_result_dict: Dict  # [str, ModelResult]
            trap_data: dict
            # trap_data["%s_integral" % var_name]
    """
    with open(spec_data_flnm, "rb") as f:
        pklfile_spectra = pickle.load(f)
        # spectra_dict = {
        #     "input_class": input_class,
        #     "start_datetime": start_datetime,
        #     "end_datetime": stop_datetime,
        #     "sequence_series": sequence_series,
        #     "spectra": spectra,
        #     "df": comp_df,
        # }
    start_all_dt = pklfile_spectra["start_datetime"]
    end_all_dt = pklfile_spectra["end_datetime"]
    if df is None:
        df = pklfile_spectra["df"]

    _, analysis_dir, _, figures_dir = input_class.Paths.set_file_paths(
        event_start=run_start, analysis_name="fit TD"
    )

    fits_list = input_class.Fits
    interp_list = input_class.Interp

    tz = pytz.timezone(input_class.Parameters.timezone)

    prefix = f"{run_start}_{seq_prefix}"

    # grab time appropriate data
    bool_keep = good_times(df, start_dt=start_all_dt, end_dt=end_all_dt, tz=tz)

    trap_data = integrate_trap(
        df[bool_keep], start_all_dt, end_all_dt, tz=tz, verbose=False
    )

    peak_fit, gaus_result_dict, cau_gaus_result_dict = fit_sources(
        df[bool_keep], start_all_dt, interp_list, fits_list, tz=tz
    )
    plot_fits(
        df[bool_keep],
        interp_list,
        peak_fit,
        figures_dir,
        prefix,
        gaus_result_dict=gaus_result_dict,
        cau_gaus_result_dict=cau_gaus_result_dict,
        tz=tz,
    )

    pfd_out = PeakFitData(
        peak_fit=peak_fit,
        gaus_result_dict=gaus_result_dict,
        cau_gaus_result_dict=cau_gaus_result_dict,
        trap_data=trap_data,
    )

    filename = os.path.join(
        analysis_dir, f"{run_start}_{seq_prefix}_fit_compiled_TD_analysis.pkl"
    )
    with open(filename, "wb") as outpkl:
        pickle.dump(pfd_out, outpkl, 1)
    return pfd_out
