import os
from copy import deepcopy
from pathlib import Path

from spectral_toolkit.TD_analysis.TD_utilities.utilities_TD import (
    calculate_TD_sample_dilution,
    calculate_flow_precon,
    calculate_trap_conc,
)
from spectral_toolkit.TD_analysis.data_models_TD.output_models import FlowPreconData
from spectral_toolkit.TD_analysis.data_models_TD.precon_input import TdPreconYaml

from spectral_toolkit.TD_analysis.TD_utilities.time_conversions import (
    timestr_to_datetimeindex,
)

import pickle


def flow_precon(
    input_class: TdPreconYaml,
    run_start: str,
    seq_prefix: str,
    TD_comp_flnm: Path,
) -> FlowPreconData:
    """
    Calculate flow base preconcentration values.

    Parameters:
        input_class: TdPreconYaml
            Paths: YamlSimplePaths
            Parameters: YamlParameters
            Experiment_Times: List[BaseTimesSchema]
            Events: List[BaseTimesSchema]
            MFCs: YamlMfcs
            Precon_timing: YamlPreconTiming
            Compounds: List[CompoundsSchema] = None
        run_start: str
            string indicating the start date time (YYYYMMDD_HHMMSS)
        seq_prefix: str
            string to append to file names
        TD_comp_flnm: Path
            path and filename of the compiled TD data
            filename = os.path.join(
                analysis_dir, f"{start_str}_{name}_compile_picarro_TD.pkl"
            )

    Saves:
        fpd_out: FlowPreconData
            df_flow_precon: PandasDataFrame
                df_flow updated with:
                    precon_dict = {
                        "flow_precon_factor": None,
                        "flow_precon_factor_error": None,
                        "trap_time_min": Precon_timing.trap_time_min,
                        "desorb_time_min": Precon_timing.desorb_time_min,
                    }
                    dilutions = {
                        "factor_1": value,  # direct
                        "factor_2": value,  # direct
                        "factor_3": value,  # overflow
                    }
            trap_dict: dict
                dictionary containing trap concentrations for analytes in ppm and ppb
                calculated from flows and tank concentrations
        filename = os.path.join(
            analysis_dir, f"{run_start}_{seq_prefix}_flow_precon_analysis.pkl"
        )

    Returns:
        fpd_out: FlowPreconData
            df_flow_precon: PandasDataFrame
                df_flow updated with:
                    precon_dict = {
                        "flow_precon_factor": None,
                        "flow_precon_factor_error": None,
                        "trap_time_min": Precon_timing.trap_time_min,
                        "desorb_time_min": Precon_timing.desorb_time_min,
                    }
                    dilutions = {
                        "factor_1": value,  # direct
                        "factor_2": value,  # direct
                        "factor_3": value,  # overflow
                    }
            trap_dict: dict
                dictionary containing trap concentrations for analytes in ppm and ppb
                calculated from flows and tank concentrations
    """
    with open(TD_comp_flnm, "rb") as f:
        pklfile_TD_comp = pickle.load(f)
        # return_dict = {
        #     "start_datetime": start_datetime,
        #     "sequence": sequence,
        #     "df_flow": df_flow,
        #     "dfg": dfg,
        # }
    start_all_dt = pklfile_TD_comp["start_datetime"]
    sequence = pklfile_TD_comp["sequence"]
    df_flow = pklfile_TD_comp["df_flow"]

    end_dt = sequence["end_datetime"]
    # end_dt = timestr_to_datetimeindex(end_str, timezone=input_class.Parameters.timezone)

    _, analysis_dir, _, _ = input_class.Paths.set_file_paths(
        event_start=run_start, analysis_name="preconcentration"
    )

    Precon_timing = input_class.Precon_timing

    if df_flow.empty != True:
        ind_2_use = (
            df_flow.loc[:, ("datetime", "nanmean")].to_numpy() >= start_all_dt
        ) & (df_flow.loc[:, ("datetime", "nanmean")].to_numpy() <= end_dt)

        df_flow = df_flow[ind_2_use.to_numpy()]

        dilutions = calculate_TD_sample_dilution(df_flow)

        precon_dict = calculate_flow_precon(
            df_flow,
            Precon_timing,
            sequence,
        )
    else:
        precon_dict = {
            "flow_precon_factor": None,
            "flow_precon_factor_error": None,
            "trap_time_min": Precon_timing.trap_time_min,
            "desorb_time_min": Precon_timing.desorb_time_min,
        }
        dilutions = {
            "factor_1": 1,  # direct
            "factor_2": 1,  # direct
            "factor_3": 1,  # overflow
        }

    input_concs = input_class.get_input_concs()
    trap_dict = calculate_trap_conc(dilutions, input_concs)

    df_return = df_flow
    for key, value in dilutions.items():
        df_return[key] = value
    for key, value in precon_dict.items():
        df_return[key] = value

    fpd_out = FlowPreconData(df_flow_precon=df_return, trap_dict=trap_dict)

    filename = os.path.join(
        analysis_dir, f"{run_start}_{seq_prefix}_flow_precon_analysis.pkl"
    )
    with open(filename, "wb") as outpkl:
        pickle.dump(fpd_out, outpkl, 1)

    return fpd_out
