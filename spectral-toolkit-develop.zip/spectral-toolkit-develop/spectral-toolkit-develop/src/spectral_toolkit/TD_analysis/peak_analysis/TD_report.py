import os
import pickle
import pytz
import glob

from spectral_toolkit.TD_analysis.data_models_TD.precon_input import TdPreconYaml

from spectral_toolkit.TD_analysis.TD_utilities.html_reporting_TD import (
    html_report_TD,
    collect_fitter_data_df,
)


def report_TD_results(input_class: TdPreconYaml):
    """Create TD report for experiment results.

    Parameters:
        input_class: TdPreconYaml
            Paths: YamlSimplePaths
            Parameters: YamlParameters
            Experiment_Times: List[BaseTimesSchema]
            Events: List[BaseTimesSchema]
            MFCs: YamlMfcs
            Precon_timing: YamlPreconTiming
            Compounds: List[CompoundsSchema] = None

    """
    exp_start, _ = input_class.get_exp_date_time_str()
    tz = pytz.timezone(input_class.Parameters.timezone)
    temperature_path = input_class.Paths.temperature_name

    _, analysis_dir, _, figures_dir = input_class.Paths.set_file_paths(
        event_start=exp_start, analysis_name="preconcentration"
    )
    TD_precon_flnm = os.path.join(
        analysis_dir, f"{input_class.output_prefix}_TD_precon_analysis.pkl"
    )
    with open(TD_precon_flnm, "rb") as f:
        pklfile_TD_precon = pickle.load(f)

    df_fits = pklfile_TD_precon["df_fits"]
    df_trap_int = pklfile_TD_precon["df_trap_int"]
    df_flow_precon = pklfile_TD_precon["df_flow_precon"]
    df_trap_conc = pklfile_TD_precon["df_trap_conc"]
    # concentrations based on flow
    compound_list = pklfile_TD_precon["compound_list"]
    df_conc_precon = pklfile_TD_precon["df_conc_precon"]
    df_input_conc_ppb = pklfile_TD_precon["df_input_conc_ppb"]
    # concentrations based on peak area
    df_normalized_data = pklfile_TD_precon["df_normalized_data"]
    run_type_flag = pklfile_TD_precon["run_type_flag"]

    H = html_report_TD(
        df_fits,
        df_trap_int,
        df_flow_precon,
        df_trap_conc,
        df_input_conc_ppb,
        run_type_flag,
        compound_list,
        analysis_dir,
        figures_dir,
        input_class.Paths.output_path,
        input_class.output_prefix,
        tz=tz,
    )

    H.test_analysis_tables()
    H.data_temperature_table()
    H.data_fitting_fig_table()

    compound_data = {}
    compound_settings = {}
    compound_multi_cau_gaus_temp = {}
    df_data_dict = {}

    (
        _,
        markes_dir,
        _,
        _,
    ) = input_class.Paths.set_file_paths(event_start=exp_start, analysis_name="Markes")

    markes_names = glob.glob(os.path.join(markes_dir, "*_parse_markes.pkl"))

    (_, picarro_dir, _, _,) = input_class.Paths.set_file_paths(
        event_start=exp_start, analysis_name="Picarro TD"
    )
    picarro_names = glob.glob(os.path.join(picarro_dir, "*_compile_picarro_TD.pkl"))

    all_names = markes_names + picarro_names
    # compile Markes parts data
    for filename in all_names:
        with open(filename, "rb") as f:
            pklfile = pickle.load(f)
        sequence = pklfile["sequence"]

        if "end_datetime" in sequence.index:
            start_str = sequence.name.strftime("%Y%m%d_%H%M%S")
            start_dt = sequence.name
            end_str = sequence["end_datetime"].strftime("%Y%m%d_%H%M%S")
        else:
            start_str = sequence.index[0].strftime("%Y%m%d_%H%M%S")
            start_dt = sequence.index[0]
            end_str = sequence["end_datetime"].iloc[0].strftime("%Y%m%d_%H%M%S")

        df_parts = None
        dfg = None
        # MARKES DATA
        if "parts" in pklfile:
            # markes_dict: dict
            # {
            # "start_datetime": start_datetime,
            # "sequence": sequence,
            # "parts": parts,
            # "df_flow": df_flow,  # ini MFC designated flows
            # "df_all": df_all,  # measured raw flows
            # "dfg_runs": dfg_runs,  # run average measured flows
            # "dfg_steps": dfg_steps,  # step average measured flows
            # }

            parts = pklfile["parts"]
            df_parts = parts["Unity"]["df"]
            # renaming = [['ColdTrap1.CurrentTemp', 'trap_C'],
            #         ['ColdTrap1.TargetTemp', 'trap_setpoint_C'],
            #         ['Unity Trap2.FlowRate', 'trap_sccm'],
            #         ['Unity Trap2.FlowRateSetpoint', 'trap_setpoint_sccm'],
            #         ['Instrument State', 'instrument_state']
            #         ]
        else:
            # return_dict = {
            #     "start_datetime": start_datetime,
            #     "sequence": sequence,
            #     "df_flow": df_flow,
            #     "dfg": dfg,
            # }

            dfg = pklfile["dfg"]

        df_ind = (start_str, end_str)
        # event_now = {'times':(start_date_time, end_date_time)}

        # RUN AND DATA FITTING TABLE
        for compound in compound_list:
            if compound not in compound_data:
                compound_data[compound] = None
                compound_settings[compound] = None
                compound_multi_cau_gaus_temp[compound] = None
                df_data_dict[compound] = None

            df_4_table = collect_fitter_data_df(
                compound,
                start_dt,
                df_ind,
                df_fits,
                df_flow_precon,
                df_trap_conc,
                df_trap_int,
                df_input_conc_ppb,
                df_parts=df_parts,
                dfg=dfg,
                df_return=df_data_dict[compound],
            )
            df_data_dict[compound] = df_4_table

            data, settings, multi_cau_gaus_temp = H.collect_fitter_data(
                compound,
                start_str,
                df_ind,
                df_parts=df_parts,
                dfg=dfg,
                data=compound_data[compound],
                settings=compound_settings[compound],
                multi_cau_gaus_temp=compound_multi_cau_gaus_temp[compound],
            )
            compound_data[compound] = data
            compound_settings[compound] = settings
            compound_multi_cau_gaus_temp[compound] = multi_cau_gaus_temp

    for compound in compound_list:
        H.create_fitter_table(
            compound,
            compound_data[compound],
            compound_settings[compound],
            compound_multi_cau_gaus_temp[compound],
        )
        flnm = os.path.join(H.analysis_path, f"{H.prefix}_{compound}_TD_report.csv")
        df_data_dict[compound].to_csv(flnm, sep=",")

    # from saved temperature parameter file(s) print the flow and temperature program information
    H.print_temperature_control(in_house_temperature_path=temperature_path)

    # save html report
    H.save_html()
