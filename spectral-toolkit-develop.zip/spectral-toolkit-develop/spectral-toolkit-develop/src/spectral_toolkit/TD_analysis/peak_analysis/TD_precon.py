import os
import pytz
import pandas as pd
from pathlib import Path
import pickle

from spectral_toolkit.TD_analysis.data_models_TD.precon_input import TdPreconYaml

from spectral_toolkit.TD_analysis.TD_utilities.utilities_TD import (
    calculate_input_concentration,
    get_compound_list_from_trap_df,
)
from spectral_toolkit.TD_analysis.TD_utilities.utilities_TD_fit import (
    compile_conc_precon,
    populate_normalization,
    set_blank,
)
from spectral_toolkit.TD_analysis.TD_utilities.TD_plotting import (
    plot_regular_timeseries,
    plot_conc_timeseries,
    plot_calibrated_timeseries,
    plot_precon_timeseries,
)

from spectral_toolkit.TD_analysis.TD_utilities.utilities_reg import (
    filepath_creator,
    run_filename_creator,
)


def calculate_peak_precon(
    input_class: TdPreconYaml,
    runs_starts: list,
):
    """
    Compile information on preconcentration based on concentrations and flows.

    Parameters:
        input_class: TdPreconYaml
            Paths: YamlSimplePaths
            Parameters: YamlParameters
            Experiment_Times: List[BaseTimesSchema]
            Events: List[BaseTimesSchema]
            MFCs: YamlMfcs
            Precon_timing: YamlPreconTiming
            Compounds: List[CompoundsSchema] = None
        runs_starts: list
            list of run_start strings (YYYYMMDD_HHMMSS)

    Saves:
        dict_out = {
            "exp_start": exp_start,
            "df_fits": df_fits,
            "df_trap_int": df_trap_int,
            "df_flow_precon": df_flow_precon,
            "df_trap_conc": df_trap_conc,
            "df_conc_precon": df_conc_precon,
            "df_input_conc_ppb": df_input_conc_ppb,
            "df_normalized_data": df_normalized_data,
            "compound_list": compound_list,
            "run_type_flag": run_type_flag,
        }

        filename = os.path.join(
            analysis_dir, f"{input_class.output_prefix}_TD_precon_analysis.pkl"
        )
    """
    exp_start, _ = input_class.get_exp_date_time_str()
    TD_type = input_class.Parameters.TD_type

    tz = pytz.timezone(input_class.Parameters.timezone)

    _, analysis_dir, _, figures_dir = input_class.Paths.set_file_paths(
        event_start=exp_start, analysis_name="preconcentration"
    )

    path_dict = filepath_creator(input_class)

    # compile event data
    df_fits = None
    df_trap_int = None
    df_flow_precon = None
    df_trap_conc = None

    gaus_result_list = []
    cau_gaus_result_list = []
    for run_start in runs_starts:
        if TD_type == "markes":
            TD_comp_flnm = run_filename_creator(
                input_class, path_dict, run_start, "parse_markes"
            )
        elif TD_type == "picarro":
            TD_comp_flnm = run_filename_creator(
                input_class, path_dict, run_start, "compile_picarro_TD"
            )

        with open(TD_comp_flnm, "rb") as f:
            pklfile_TD_comp = pickle.load(f)
            # return_dict = {
            #     "start_datetime": start_datetime,
            #     "sequence": sequence,
            #     "df_flow": df_flow,
            #     "dfg": dfg,
            # }
        sequence = pklfile_TD_comp["sequence"]

        if isinstance(sequence["end_datetime"], pd.DatetimeIndex):
            end_str = sequence["end_datetime"].iloc[0].strftime("%Y%m%d_%H%M%S")
        else:
            end_str = sequence["end_datetime"][0].strftime("%Y%m%d_%H%M%S")

        time_MI = pd.MultiIndex.from_tuples(
            [(run_start, end_str)], names=["start", "end"]
        )

        peak_fit_flnm = run_filename_creator(
            input_class, path_dict, run_start, "fit_compiled_TD_analysis"
        )
        with open(peak_fit_flnm, "rb") as f:
            pklfile_peak_fit = pickle.load(f)
        # pfd_out = PeakFitData(
        #     peak_fit=peak_fit,
        #     gaus_result_dict=gaus_result_dict,
        #     cau_gaus_result_dict=cau_gaus_result_dict,
        #     trap_data=trap_data,
        # )

        flow_precon_flnm = run_filename_creator(
            input_class, path_dict, run_start, "flow_precon_analysis"
        )
        with open(flow_precon_flnm, "rb") as f:
            pklfile_flow_precon = pickle.load(f)

        reformed_peak_fit_dict = {}
        for outer_key, inner_values in pklfile_peak_fit.peak_fit.items():
            for inner_key, values in inner_values.__dict__.items():
                reformed_peak_fit_dict[(outer_key, inner_key)] = values

        df = pd.DataFrame(reformed_peak_fit_dict, index=time_MI)
        if df_fits is None:
            df_fits = df
        else:
            df_fits = pd.concat((df_fits, df))

        df = pd.DataFrame(pklfile_peak_fit.trap_data, index=time_MI)
        if df_trap_int is None:
            df_trap_int = df
        else:
            df_trap_int = pd.concat((df_trap_int, df))

        gaus_result_list.append(pklfile_peak_fit.gaus_result_dict)
        cau_gaus_result_list.append(pklfile_peak_fit.cau_gaus_result_dict)

        # df = pd.DataFrame(data=pklfile_flow_precon.df_flow_precon.to_dict(), index=time_MI)
        df = pklfile_flow_precon.df_flow_precon
        df.index = pd.MultiIndex.from_tuples(time_MI, names=["start", "end"])
        if df_flow_precon is None:
            df_flow_precon = df
        else:
            df_flow_precon = pd.concat((df_flow_precon, df))

        df = pd.DataFrame(pklfile_flow_precon.trap_dict, index=time_MI)
        if df_trap_conc is None:
            df_trap_conc = df
        else:
            df_trap_conc = pd.concat((df_trap_conc, df))

    # concentrations based on flow
    compound_list = get_compound_list_from_trap_df(df_trap_conc)
    df_conc_precon = compile_conc_precon(df_fits, df_flow_precon, df_trap_conc)
    df_input_conc_ppb = calculate_input_concentration(df_fits, df_flow_precon)

    # concentrations based on peak area
    df_normalized_data = populate_normalization(df_fits, df_trap_int, df_conc_precon)
    run_type_flag = set_blank(df_flow_precon)

    #############################################################################
    plot_regular_timeseries(
        False,
        False,
        compound_list,
        figures_dir,
        input_class.output_prefix,
        df_fits,
        df_trap_int,
        tz=tz,
        mode="cauchy_gaussian_fit",
    )

    plot_regular_timeseries(
        False,
        True,
        compound_list,
        figures_dir,
        input_class.output_prefix,
        df_fits,
        df_trap_int,
        tz=tz,
        mode="cauchy_gaussian_fit",
    )

    plot_conc_timeseries(
        df_fits,
        df_trap_conc,
        df_input_conc_ppb,
        compound_list,
        figures_dir,
        input_class.output_prefix,
        tz=tz,
    )

    ################################################################################
    # plot calibrated timeseries
    plot_calibrated_timeseries(
        df_fits,
        df_trap_conc,
        df_trap_int,
        df_normalized_data,
        run_type_flag,
        compound_list,
        figures_dir,
        input_class.output_prefix,
        tz=tz,
        mode="cauchy_gaussian_fit",
        breakthrough_included=False,
    )

    ################################################################################
    # plot preconcentration factors timeseries
    plot_precon_timeseries(
        df_fits,
        df_flow_precon,
        df_conc_precon,
        df_input_conc_ppb,
        run_type_flag,
        compound_list,
        figures_dir,
        input_class.output_prefix,
        tz=tz,
    )

    dict_out = {
        "exp_start": exp_start,
        "df_fits": df_fits,
        "df_trap_int": df_trap_int,
        "df_flow_precon": df_flow_precon,
        "df_trap_conc": df_trap_conc,
        "df_conc_precon": df_conc_precon,
        "df_input_conc_ppb": df_input_conc_ppb,
        "df_normalized_data": df_normalized_data,
        "compound_list": compound_list,
        "run_type_flag": run_type_flag,
    }

    filename = os.path.join(
        analysis_dir, f"{input_class.output_prefix}_TD_precon_analysis.pkl"
    )
    with open(filename, "wb") as outpkl:
        pickle.dump(dict_out, outpkl, 1)
