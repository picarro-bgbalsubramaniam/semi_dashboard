# -*- coding: utf-8 -*-
from dominate import tags
import dominate
from dominate.tags import *
import os
import glob
import pandas as pd
import pickle
import numpy as np
from unidecode import unidecode
from scipy import interpolate

# import base64

from spectral_toolkit.TD_analysis.TD_utilities.time_conversions import (
    timestr_to_datetime,
)

param_convert_dict = {
    b"flow_MFC1_sccm": "MFC1 flow (sccm)",
    b"flow_MFC2_sccm": "MFC2 flow (sccm)",
    b"flow_MFC3_sccm": "MFC3 flow (sccm)",
    b"flow_MFC4_sccm": "MFC4 flow (sccm)",
    b"flow_MFC5_sccm": "MFC5 flow (sccm)",
    b"hold_temperature_PID1": "Temperature (C)",
    b"ramp_rate_PID1": "Temperature Ramp (C/min)",
    b"fan1_bit_value": "fan bit value",
    b"valve1_bit_value": "valve1 bit value",
    b"valve2_bit_value": "valve2 bit value",
    b"valve3_bit_value": "valve3 bit value",
    b"PID_value": "PID values",
    b"step_time_length_PID1": "step length (min)",
}


def set_image_path(image_path):
    ret_file = os.path.split(image_path)
    ret_analysis = os.path.split(ret_file[0])
    ret_date = os.path.split(ret_analysis[0])
    return_path = os.path.join("../", ret_date[1], ret_analysis[1], ret_file[1])
    return return_path


def create_event_figure_path(start_str, default_figure_folder, analysis=None):
    ret_analysis = os.path.split(default_figure_folder)
    ret_date = os.path.split(ret_analysis[0])
    if analysis is None:
        analysis = ret_analysis[1]
    other_path = os.path.join(ret_date[0], start_str, analysis)
    return other_path


def collect_fitter_data_df(
    compound,
    start_dt,
    df_ind,
    df_fits,
    df_flow_precon,
    df_trap_conc,
    df_trap_int,
    df_input_conc_ppb,
    df_parts=None,
    dfg=None,
    # data=None,
    # settings=None,
    # multi_cau_gaus_temp=None,
    df_return=None,
):
    """
    collects all of the processed data for a given compound in a dataframe
    """
    if df_return is None:
        df_return = pd.DataFrame(
            columns=[
                "trap_flow",
                "trap_conc",
                "trap_area",
                "elution_temp",
                "peak_cen",
                "peak_sigma_left",
                "peak_sigma_right",
                "peak_f_left",
                "peak_f_right",
                "peak_area",
                "desorption_flow",
                "back_calc_conc",
                "recovery",
            ]
        )

    if df_parts is not None:
        trap_C = df_parts["trap_C"]
        temperature_time = df_parts.index  # .values.astype(np.int64)/1e9
    elif dfg is not None:
        trap_C = dfg["PID1_C"].to_numpy()  # ["nanmean"]
        temperature_time = dfg.index.get_level_values(level="current time")

    temperature_time = (temperature_time - start_dt).seconds
    temperature_spline = interpolate.CubicSpline(temperature_time, trap_C)

    elution_temp = float(
        temperature_spline(df_fits.loc[df_ind][(compound, "cau_gaus_cen")])
    )

    trap_flow = df_flow_precon["trap_flow"]["nanmean"].loc[df_ind]
    trap_conc = df_trap_conc[f"{compound}_ppm"].loc[df_ind]
    trap_area = df_trap_int[f"{compound}_integral"].loc[df_ind]
    peak_cen = df_fits[(compound, "cau_gaus_cen")].loc[df_ind]
    peak_sigma_left = df_fits[(compound, "cau_gaus_sigma_left")].loc[df_ind]
    peak_sigma_right = df_fits[(compound, "cau_gaus_sigma_right")].loc[df_ind]
    peak_f_left = df_fits[(compound, "cau_gaus_f_left")].loc[df_ind]
    peak_f_right = df_fits[(compound, "cau_gaus_f_right")].loc[df_ind]
    peak_area = df_fits[(compound, "cau_gaus_integral")].loc[df_ind] / 1000  # ppm*s
    desorption_flow = df_flow_precon["instrument_flow"]["nanmean"].loc[df_ind]

    conc_calc = np.nan
    recovery_calc = np.nan
    if df_input_conc_ppb[compound].loc[df_ind] is not None:
        conc_calc = df_input_conc_ppb[compound].loc[df_ind]
        recovery_calc = (
            df_input_conc_ppb[compound].loc[df_ind]
            * 100.0
            / (1e3 * df_trap_conc[f"{compound}_ppm"].loc[df_ind])
        )

    dict_4_return = {
        "trap_flow": trap_flow,
        "trap_conc": trap_conc,
        "trap_area": trap_area,
        "elution_temp": elution_temp,
        "peak_cen": peak_cen,
        "peak_sigma_left": peak_sigma_left,
        "peak_sigma_right": peak_sigma_right,
        "peak_f_left": peak_f_left,
        "peak_f_right": peak_f_right,
        "peak_area": peak_area,
        "desorption_flow": desorption_flow,
        "back_calc_conc": conc_calc,
        "recovery": recovery_calc,
    }

    df_return = pd.concat((df_return, pd.DataFrame(dict_4_return, index=[df_ind])))

    return df_return


class html_report_TD(dominate.document):
    def __init__(
        self,
        df_fits,
        df_trap_int,
        df_flow_precon,
        df_trap_conc,
        df_input_conc_ppb,
        run_type_flag,
        compound_list,
        analysis_dir,
        figures_dir,
        base_dir,
        prefix,
        tz=None,
        doctype="<!DOCTYPE html>",
        **kwargs,
    ):
        self.base_path = base_dir
        # self.output_path = D.resultsDIR
        # self.markes_path = D.markes_path

        self.analysis_path = analysis_dir
        self.figure_path = figures_dir

        self.df_fits = df_fits
        self.df_trap_int = df_trap_int
        self.df_flow_precon = df_flow_precon
        self.df_trap_conc = df_trap_conc
        self.df_input_conc_ppb = df_input_conc_ppb
        self.run_type_flag = run_type_flag
        self.compound_list = compound_list
        self.prefix = prefix
        self.tz = tz

        start_list = []
        for start_str, end_str in self.df_fits.index:
            start_dt = self.tz.localize(timestr_to_datetime(start_str))
            end_dt = self.tz.localize(timestr_to_datetime(end_str))
            start_list.append(start_dt)
        self.start_dt = np.array(start_list)
        self.sort_ind = np.argsort(self.start_dt)

        start_date = self.prefix.split("_")[0]
        start_time = self.prefix.split("_")[1]
        title = f"{start_date} {start_time} Data Analysis"
        print(title)
        super(html_report_TD, self).__init__()
        self.doctype = doctype
        self.head = super(html_report_TD, self).add(tags.head())
        self.body = super(html_report_TD, self).add(tags.body())
        self.title_node = self.head.add(tags.title(title))
        self._entry = self.body

        with self.head:
            link(rel="stylesheet", href="style.css")
            script(type="text/javascript", src="script.js")
            style(
                """\
                  table, th, td {
                      border: 1px solid black;
                      border-collapse: collapse;
                  }
                  th,td {
                      padding: 10px;
                  }
                  """
            )

        _, page_name = os.path.split(self.base_path)

        with self.add(body()).add(div(id="reasoning")):
            h1(page_name)
            h2("Reason for this Page")
            reason_str = "This page is extended, detailed analysis of the data collected for runs of"
            for i, compound in enumerate(self.compound_list):
                if i == len(self.compound_list):
                    reason_str += f" and {compound}."
                else:
                    reason_str += f" {compound},"
            reason_str += f" taken {start_list[0]} to {end_dt}. This page is meant as a supplement and reference for higher level analysis."
            p(reason_str)

    def create_table(self, data, settings=dict(), header=True, height="200"):
        if "colspan" in settings:
            colspan = settings["colspan"]
        else:
            colspan = -np.ones(data.shape)
        if "color" in settings:
            color = settings["color"]
        else:
            color = np.empty((data.shape), dtype=list)
        if "unidecode" in settings:
            uni = settings["unidecode"]
        else:
            uni = np.empty((data.shape), dtype=list)

        with table().add(tbody()):
            for i, row in enumerate(data):
                tr()
                for j, item in enumerate(row):
                    if item is None:
                        td()
                        print("no available data or figure to print")
                    elif ".png" in item:  # item is an image path
                        item = set_image_path(item)
                        td(img(src=item, height=height))  #'300'))
                    elif ".html" in item:
                        item = set_image_path(item)
                        td(
                            iframe(
                                id="igraph",
                                scrolling="no",
                                style="border:none;",
                                seamless="seamless",
                                src=item,
                                # height=height,
                            )
                        )
                    elif item != -1 and item != "-1" and item != -1.0:
                        if (
                            colspan[i, j] != -1
                            and color[i, j] is not None
                            and uni[i, j] is not None
                        ):
                            th(
                                font(item, color=color[i, j]),
                                unidecode(uni[i, j]),
                                colspan=str(int(colspan[i, j])),
                            )
                        elif colspan[i, j] != -1 and color[i, j] is not None:
                            th(
                                font(item, color=color[i, j]),
                                colspan=str(int(colspan[i, j])),
                            )
                        elif colspan[i, j] != -1 and uni[i, j] is not None:
                            th(
                                font(item, color="000000"),
                                unidecode(uni[i, j]),
                                colspan=str(int(colspan[i, j])),
                            )
                        elif color[i, j] is not None and uni[i, j] is not None:
                            th(font(item, color=color[i, j]), unidecode(uni[i, j]))
                        elif colspan[i, j] != -1:
                            th(
                                font(item, color="000000"),
                                colspan=str(int(colspan[i, j])),
                            )
                        elif color[i, j] is not None:
                            th(font(item, color=color[i, j]))
                        elif uni[i, j] is not None:
                            th(font(item, color="000000"), unidecode(uni[i, j]))
                        else:
                            th(item)

    def print_temperature_control(
        self, in_house_temperature_path=None, markes_temperature_path=None
    ):
        """
        For all of the parameter.pkl files in the temperature path, print the variables in a new section
        """
        # TODO: update for markes temperature data?
        with self.add(body()).add(div(id="temperature")):
            h2("Temperature and Flow Parameters")

            if in_house_temperature_path is not None:
                for param_name in glob.glob(
                    os.path.join(in_house_temperature_path, "*parameters.pkl")
                ):
                    _, page_name = os.path.split(param_name)
                    h3(page_name)
                    with open(param_name, "rb") as f:
                        pklfile = pickle.load(f, encoding="bytes")  # open the pkl file

                    key_list = list(pklfile.keys())
                    key_list.sort()

                    for key in key_list:
                        if key in param_convert_dict:
                            prefix = param_convert_dict[key]
                        else:
                            prefix = ""

                        if len(pklfile[key].shape) > 1 and prefix != "":
                            p(prefix)
                            with table().add(tbody()):
                                tr()
                                for i in range(pklfile[key].shape[0]):
                                    th(f"Step {i}")
                                for j in range(pklfile[key].shape[1]):
                                    tr()
                                    for i in range(pklfile[key].shape[0]):
                                        td(pklfile[key][i, j])
                        elif prefix != "":
                            p(f"{prefix}: {pklfile[key]}")

    def test_analysis_tables(self):
        """
        collects the overall analysis figures and places them in a table
        """
        with self.add(body()).add(div(id="analysis")):
            h2("Test Analysis")
            try:
                figure_name = glob.glob(
                    os.path.join(self.figure_path, "*precon_timeseries.png")
                )
                figure_name = set_image_path(figure_name[0])
                img(src=figure_name, height="400")
            except:
                pass

            figure_name = glob.glob(
                os.path.join(self.figure_path, "*precon_anal_timeseries.png")
            )
            figure_name = set_image_path(figure_name[0])
            img(src=figure_name, height="400")

            integral_name = glob.glob(
                os.path.join(
                    self.figure_path, "*complex_cauchy_gaussian_fit_timeseries.png"
                )
            )
            relative_name = glob.glob(
                os.path.join(
                    self.figure_path,
                    "*complex_cauchy_gaussian_fit_relative_timeseries.png",
                )
            )
            bar_name = glob.glob(
                os.path.join(
                    self.figure_path, "*complex_cauchy_gaussian_fit_bar_timeseries.png"
                )
            )
            if len(bar_name) == 0:
                bar_name = None
            else:
                bar_name = bar_name[0]

            h3("Multi-Compound Fit")
            data = np.array(
                (
                    (
                        "Cauchy-Gaussian Integral",
                        "Relative Integral",
                        "Mass Conservation Analysis",
                    ),
                    (integral_name[0], relative_name[0], bar_name),
                )
            )
            self.create_table(data, height="300")

            for compound in self.compound_list:
                cau_gaus_conc_area = (
                    self.df_fits[(compound, "cau_gaus_integral")] / 1000.0
                )
                if len(np.where(self.run_type_flag)[0]) > 0:
                    desorbed_mean = np.nanmean(cau_gaus_conc_area[self.run_type_flag])
                    desorbed_std = np.nanstd(cau_gaus_conc_area[self.run_type_flag])
                    desorbed_txt = f"{compound} Desorbed: {desorbed_mean:.3e} +- {desorbed_std:.1e} ppm*s"
                else:
                    desorbed_txt = f"{compound} Desorbed: NA"
                if len(np.where(self.run_type_flag == False)[0]) > 0:
                    blank_mean = np.nanmean(
                        cau_gaus_conc_area[self.run_type_flag == False]
                    )
                    blank_std = np.nanstd(
                        cau_gaus_conc_area[self.run_type_flag == False]
                    )
                    blank_txt = f"blank {blank_mean:.2e} +- {blank_std:.2e} ppm*s"
                else:
                    blank_txt = "blank NA"
                txt = f"{desorbed_txt}, {blank_txt}"
                p(txt)

    def data_temperature_table(self):
        """
        collects all of the processed data and places each run in a row of a table
        """
        with self.add(body()).add(div(id="run")):
            h2("Run Data")
            data = np.array((("File", "Temperature Control", "Flow Control")))
            for start_str, end_str in self.df_fits.index:
                other_markes_path = create_event_figure_path(
                    start_str, self.figure_path, analysis="Markes"
                )
                other_in_house_path = create_event_figure_path(
                    start_str, self.figure_path, analysis="Picarro TD"
                )

                regular_markes_temp_path = glob.glob(
                    os.path.join(
                        self.figure_path, f"{start_str}_Unity_trap_C_timeseries.png"
                    )
                )
                other_markes_temp_path = glob.glob(
                    os.path.join(
                        other_markes_path, f"{start_str}_Unity_trap_C_timeseries.png"
                    )
                )
                regular_in_house_temp_path = glob.glob(
                    os.path.join(self.figure_path, f"{start_str}*temperature_PID.png")
                )
                other_in_house_temp_path = glob.glob(
                    os.path.join(
                        other_in_house_path, f"{start_str}*temperature_PID.png"
                    )
                )

                if len(regular_markes_temp_path) > 0:
                    temp_fig = regular_markes_temp_path[0]
                elif len(other_markes_temp_path) > 0:
                    temp_fig = other_markes_temp_path[0]
                elif len(regular_in_house_temp_path) > 0:
                    temp_fig = regular_in_house_temp_path[0]
                elif len(other_in_house_temp_path) > 0:
                    temp_fig = other_in_house_temp_path[0]
                else:
                    temp_fig = ""

                regular_flow_path = glob.glob(
                    os.path.join(self.figure_path, f"{start_str}_flows.png")
                )
                other_markes_flow_path = glob.glob(
                    os.path.join(
                        other_markes_path,
                        f"{start_str}_flows",
                    )
                )
                other_in_house_flow_path = glob.glob(
                    os.path.join(other_in_house_path, f"{start_str}*flows.png")
                )

                if len(regular_flow_path) > 0:
                    flow_fig = regular_flow_path[0]
                elif len(other_markes_flow_path) > 0:
                    flow_fig = other_markes_flow_path[0]
                elif len(other_in_house_flow_path) > 0:
                    flow_fig = other_in_house_flow_path[0]
                else:
                    flow_fig = ""

                data = np.vstack(
                    (data, np.array((start_str, temp_fig, flow_fig))[np.newaxis, :])
                )
            self.create_table(data, height="200")

    def data_fitting_fig_table(self):
        """
        collects all of the processed data and places each run in a row of a table
        """
        with self.add(body()).add(div(id="all")):
            h2("Fitting")
            data = np.array(
                (
                    ("File", "Multi-Compound Fit", -1),
                    ("", "Source Data", "Small Molecules"),
                )
            )
            settings = dict()
            settings["colspan"] = -np.ones((len(self.df_fits) + 2, 3))
            settings["colspan"][0, 1] = 2

            for start_str, end_str in self.df_fits.index:
                other_path = create_event_figure_path(
                    start_str, self.figure_path, analysis="fit TD"
                )
                try:
                    multi_source = glob.glob(
                        os.path.join(self.figure_path, f"{start_str}*complex_fit.png")
                    )[0]
                except:
                    try:
                        multi_source = glob.glob(
                            os.path.join(other_path, f"{start_str}*complex_fit.png")
                        )[0]
                    except:
                        multi_source = ""

                try:
                    molecule_source = glob.glob(
                        os.path.join(
                            self.figure_path, f"{start_str}*small_molecule_fit.png"
                        )
                    )[0]
                except:
                    try:
                        molecule_source = glob.glob(
                            os.path.join(
                                other_path, f"{start_str}*small_molecule_fit.png"
                            )
                        )[0]
                    except:
                        molecule_source = ""

                data = np.vstack(
                    (
                        data,
                        np.array((start_str, multi_source, molecule_source))[
                            np.newaxis, :
                        ],
                    )
                )
            self.create_table(data, settings=settings, height="150")

    def collect_fitter_data(
        self,
        compound,
        start_str,
        df_ind,
        df_parts=None,
        dfg=None,
        data=None,
        settings=None,
        multi_cau_gaus_temp=None,
    ):
        """
        collects all of the processed data and places each run in a row of a table
        """
        if multi_cau_gaus_temp is None:
            multi_cau_gaus_temp = pd.DataFrame(index=self.df_fits.index)
            multi_cau_gaus_temp["value"] = None
        if data is None:
            data = np.array(
                (
                    (
                        "File",
                        "Trap Input",
                        -1,
                        -1,
                        "Cauchy-Gaussian Fit",
                        -1,
                        -1,
                        -1,
                        -1,
                        "Back Calculation",
                        -1,
                        -1,
                    ),
                    (
                        "",
                        "Flow",
                        "Concentration",
                        "Area",
                        "",
                        "Elution Temperature",
                        "Center",
                        "Sigmas",
                        "Area",
                        "Desorption Flow",
                        "Concentration",
                        "Recovery",
                    ),
                )
            )
        if settings is None:
            settings = dict()
            settings["colspan"] = -np.ones((len(self.df_fits) + 2, 12))
            settings["colspan"][0, 1] = 3
            settings["colspan"][0, 4] = 5
            settings["colspan"][0, 9] = 3

            settings["color"] = np.empty((len(self.df_fits) + 2, 12), dtype=list)

            settings["unidecode"] = np.empty((len(self.df_fits) + 2, 12), dtype=list)
            settings["count"] = 1

        if df_parts is not None:
            trap_C = df_parts["trap_C"]
            temperature_time = df_parts.index  # .values.astype(np.int64)/1e9
        elif dfg is not None:
            trap_C = dfg["PID1_C"].to_numpy()  # ["nanmean"]
            temperature_time = dfg.index.get_level_values(level="current time")

        start_dt = self.tz.localize(timestr_to_datetime(start_str))  # ["times"][0]))
        temperature_time = (temperature_time - start_dt).seconds

        temperature_spline = interpolate.CubicSpline(temperature_time, trap_C)

        multi_cau_gaus_temp["value"].loc[df_ind] = temperature_spline(
            self.df_fits.loc[df_ind][(compound, "cau_gaus_cen")]
        )

        flow_txt = f"{self.df_flow_precon['trap_flow']['nanmean'].loc[df_ind]:.2f} sccm"
        conc_txt = f"{1e3 * self.df_trap_conc[f'{compound}_ppm'].loc[df_ind]:.3e} ppb"
        trap_area_txt = (
            f"{self.df_trap_int[f'{compound}_integral'].loc[df_ind]:.3e} ppm*s"
        )

        other_path = create_event_figure_path(
            start_str,
            self.figure_path,
            analysis="fit TD",
        )
        try:
            multi_fit = glob.glob(
                os.path.join(
                    self.figure_path,
                    f"{start_str}*{compound}*cau_gaus_fit.png",
                )
            )[0]
        except:
            try:
                multi_fit = glob.glob(
                    os.path.join(other_path, f"{start_str}*{compound}*cau_gaus_fit.png")
                )[0]
            except:
                multi_fit = ""

        elution_txt = f"{multi_cau_gaus_temp['value'].loc[df_ind]:.2f} C"
        cen_txt = f"{self.df_fits[(compound, 'cau_gaus_cen')].loc[df_ind]:.0f} s"
        sigma_txt = (
            f"{self.df_fits[(compound, 'cau_gaus_sigma_left')].loc[df_ind]:.1f} s/"
            f"{self.df_fits[(compound, 'cau_gaus_sigma_right')].loc[df_ind]:.1f} s"
        )
        multi_area_txt = f"{self.df_fits[(compound, 'cau_gaus_integral')].loc[df_ind] / 1000:.3e} ppm*s"
        desorb_flow_txt = (
            f"{self.df_flow_precon['instrument_flow']['nanmean'].loc[df_ind]:.2f} sccm"
        )

        conc_calc_txt = "NA"
        recovery_txt = "NA"
        if self.df_input_conc_ppb[compound].loc[df_ind] is not None:
            conc_calc = self.df_input_conc_ppb[compound].loc[df_ind]
            recovery_calc = (
                self.df_input_conc_ppb[compound].loc[df_ind]
                * 100.0
                / (1e3 * self.df_trap_conc[f"{compound}_ppm"].loc[df_ind])
            )
            conc_calc_txt = f"{conc_calc:0.3e} ppb"
            recovery_txt = f"{recovery_calc:.2f}"

        new_array = np.array(
            (
                start_str,
                flow_txt,
                conc_txt,
                trap_area_txt,
                multi_fit,
                elution_txt,
                cen_txt,
                sigma_txt,
                multi_area_txt,
                desorb_flow_txt,
                conc_calc_txt,
                recovery_txt,
            )
        )

        count = settings["count"] + 1
        settings["color"][count, 2] = "008000"
        settings["color"][count, 6] = "000080"
        settings["color"][count, 7] = "800000"
        settings["color"][count, 10] = "008000"
        settings["unidecode"][count, 11] = "\u0025"
        settings["count"] = count

        data = np.vstack((data, new_array[np.newaxis, :]))

        return data, settings, multi_cau_gaus_temp

    def create_fitter_table(self, compound, data, settings, multi_cau_gaus_temp):
        with self.add(body()).add(div(id=compound)):
            h3(f"{compound} Fitting")

            df_fits_agg = self.df_fits.agg(
                [np.nanmean, np.nanstd, np.nanmin, np.nanmax], skipna=True
            )

            multi_cau_gaus_temp_agg = multi_cau_gaus_temp.agg(
                [np.nanmean, np.nanstd, np.nanmin, np.nanmax], skipna=True
            )

            temp_ave = multi_cau_gaus_temp_agg.loc["nanmean"]
            temp_std = multi_cau_gaus_temp_agg.loc["nanstd"]
            temp_min = multi_cau_gaus_temp_agg.loc["nanmin"]
            temp_max = multi_cau_gaus_temp_agg.loc["nanmax"]
            p(
                "Elution Temperature: ",
                font("%.1f" % temp_ave, color="000000"),
                "+-",
                font("%.1f" % temp_std, color="000000"),
                " C",
            )
            p(
                "Elution Temperature Range: ",
                font("%.1f" % temp_min, color="000000"),
                " C to ",
                font("%.1f" % temp_max, color="000000"),
                " C",
            )

            cen_ave = df_fits_agg[(compound, "cau_gaus_cen")].loc["nanmean"]
            cen_std = df_fits_agg[(compound, "cau_gaus_cen")].loc["nanstd"]
            cen_min = df_fits_agg[(compound, "cau_gaus_cen")].loc["nanmin"]
            cen_max = df_fits_agg[(compound, "cau_gaus_cen")].loc["nanmax"]
            p(
                "Peak Center: ",
                font("%.1f" % cen_ave, color="000080"),
                "+-",
                font("%.1f" % cen_std, color="000080"),
                " s",
            )
            p(
                "Peak Center Range: ",
                font("%.1f" % cen_min, color="000080"),
                " s to ",
                font("%.1f" % cen_max, color="000080"),
                " s",
            )

            sigma_ave = df_fits_agg[(compound, "cau_gaus_sigma_left")].loc["nanmean"]
            sigma_std = df_fits_agg[(compound, "cau_gaus_sigma_left")].loc["nanstd"]
            sigma_min = df_fits_agg[(compound, "cau_gaus_sigma_left")].loc["nanmin"]
            sigma_max = df_fits_agg[(compound, "cau_gaus_sigma_left")].loc["nanmax"]
            p(
                "Peak Left Sigma: ",
                font("%.1f" % sigma_ave, color="800000"),
                "+-",
                font("%0.1f" % sigma_std, color="800000"),
                " s",
            )
            p(
                "Peak Left Sigma Range: ",
                font("%.1f" % sigma_min, color="800000"),
                " s to ",
                font("%.1f" % sigma_max, color="800000"),
                " s",
            )

            sigma_ave = df_fits_agg[(compound, "cau_gaus_sigma_right")].loc["nanmean"]
            sigma_std = df_fits_agg[(compound, "cau_gaus_sigma_right")].loc["nanstd"]
            sigma_min = df_fits_agg[(compound, "cau_gaus_sigma_right")].loc["nanmin"]
            sigma_max = df_fits_agg[(compound, "cau_gaus_sigma_right")].loc["nanmax"]
            p(
                "Peak Right Sigma: ",
                font("%.1f" % sigma_ave, color="800000"),
                "+-",
                font("%0.1f" % sigma_std, color="800000"),
                " s",
            )
            p(
                "Peak Right Sigma Range: ",
                font("%.1f" % sigma_min, color="800000"),
                " s to ",
                font("%.1f" % sigma_max, color="800000"),
                " s",
            )

            self.create_table(data, settings=settings, height="200")

    def save_html(self, prefix=None):
        if prefix is None:
            prefix = self.prefix
        out_file = os.path.join(self.analysis_path, f"{prefix}_TD_report.html")
        with open(out_file, "w") as HTML_file:
            HTML_file.write(str(self))
