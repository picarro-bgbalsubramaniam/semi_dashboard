# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import pytz
import datetime

# from pathlib import Path
from typing import Optional, Tuple

from spectral_toolkit.TD_analysis.TD_utilities.timestamp import unixTime

ORIGIN = datetime.datetime(datetime.MINYEAR, 1, 1, 0, 0, 0, 0)
UNIXORIGIN = datetime.datetime(1970, 1, 1, 0, 0, 0, 0)


def parse_time_date_to_fDOY(time_date) -> np.array:
    """convert an array of time and date ('%H:%M:%S.%f %Y-%m-%d') to fDOY.

    Parameters:
        time_date:
            array of time and date strings with format '%H:%M:%S.%f %Y-%m-%d'

    Raises:

    Returns:
        fDOY: np.array
            Array containing fractional day of year values for each time_date string.
    """
    fDOY = np.ndarray((len(time_date)))
    d = datetime.datetime.now()
    for i, time_date_now in enumerate(time_date):  # convert DateTime to fDOY
        if time_date_now != "NaN":
            d = d.strptime(time_date_now, "%H:%M:%S.%f %Y-%m-%d")
            if int(d.strftime("%H")) < 8:
                d = d + datetime.timedelta(hours=12)
            fDOY[i] = (
                int(d.strftime("%j"))
                + d.hour / 24.0
                + d.minute / 60.0 / 24
                + d.second / 60.0 / 60 / 24
                + d.microsecond / 1000000.0 / 60 / 60 / 24
            )

            if fDOY[i] - fDOY[i - 1] < 0 and i > 0:
                fDOY[i] += 12 / 24.0
            elif abs(fDOY[i] - fDOY[i - 1]) > 1 / 60.0 / 24 and i > 0:
                fDOY[i] -= 12 / 24.0
        else:
            fDOY[i] = np.nan

    return fDOY


def parse_Markes_sequence_date_time_to_fDOY(time_date) -> Tuple[np.array, list, list]:
    """convert an array of time and date ("%Y/%m/%d %H:%M:%S") to fDOY.

    Parameters:
        time_date:
            array of time and date strings with format "%Y/%m/%d %H:%M:%S"

    Raises:

    Returns:
        fDOY: np.array
            Array containing fractional day of year values for each time_date string.
        date_list: list
            list of datetime dates for each time_date string
        time_list: list
            list of datetime times for each time_date string
    """
    fDOY = np.ndarray((len(time_date)))
    date_list = list()
    time_list = list()
    d = datetime.datetime.now()
    if time_date != "NaN":
        d = d.strptime(time_date, "%Y/%m/%d %H:%M:%S")
        fDOY = (
            int(d.strftime("%j"))
            + d.hour / 24.0
            + d.minute / 60.0 / 24
            + d.second / 60.0 / 60 / 24
            + d.microsecond / 1000000.0 / 60 / 60 / 24
        )

        date_list.append(d.strftime("%Y%m%d"))
        time_list.append(d.strftime("%H%M%S"))
    else:
        fDOY = np.nan
        date_list.append(np.nan)
        time_list.append(np.nan)

    return (fDOY, date_list, time_list)


def parse_Markes_data_date_time_to_fDOY(time_date) -> np.array:
    """convert an array of time and date ('%d/%m/%Y-%H:%M:%S ') to fDOY.

    Parameters:
        time_date: str
            array of time and date strings with format %d/%m/%Y-%H:%M:%S

    Raises:

    Returns:
        fDOY: np.array
            Array containing fractional day of year values for each time_date string.
    """
    fDOY = np.ndarray((len(time_date)))
    d = datetime.datetime.now()
    for i, time_date_now in enumerate(time_date):  # convert DateTime to fDOY
        if time_date_now != "NaN":
            d = d.strptime(time_date_now, "%d/%m/%Y-%H:%M:%S ")
            fDOY[i] = (
                int(d.strftime("%j"))
                + d.hour / 24.0
                + d.minute / 60.0 / 24
                + d.second / 60.0 / 60 / 24
                + d.microsecond / 1000000.0 / 60 / 60 / 24
            )

            if fDOY[i] - fDOY[i - 1] < 0 and i > 0:
                fDOY[i] += 12 / 24.0
            elif abs(fDOY[i] - fDOY[i - 1]) > 1 / 60.0 / 24 and i > 0:
                fDOY[i] -= 12 / 24.0
        else:
            fDOY[i] = np.nan
    return fDOY


def datetime_to_fDOY(dt: datetime.datetime) -> float:
    """convert python datetime to fDOY.

    Parameters:
        dt: datetime
            python datetime value

    Raises:

    Returns:
        fDOY: float
            Fractional day of year value for datetime dt
    """
    fDOY = (
        int(dt.strftime("%j"))
        + dt.hour / 24.0
        + dt.minute / 60.0 / 24
        + dt.second / 60.0 / 60 / 24
        + dt.microsecond / 1000000.0 / 60 / 60 / 24
    )

    return fDOY


def timestamp_to_fDOY(timestamp: np.array) -> np.array:
    """convert timestamp (since 1970, or year 0) to fractional day of year.

    Parameters:
        timestamp: np.array
            array of str, int, or float timestamp values

    Raises:

    Returns:
        fDOY: np.array
            Array containing fractional day of year values for each timestamp.
    """
    try:
        if timestamp.dtype != float:
            timestamp = timestamp.astype(float)
        first_timestamp = timestamp[0]

        if first_timestamp > 5e13:
            for i in range(len(timestamp)):
                if timestamp[i] != "Nan" and timestamp[i] != "nan":
                    if not np.isnan(timestamp[i]):
                        timestamp[i] = unixTime(timestamp[i])
        timestamp_length = len(timestamp)
    except:
        if timestamp.dtype != float:
            timestamp = float(timestamp)

        if timestamp > 5e13 and not np.isnan(timestamp):
            timestamp = unixTime(timestamp)
        timestamp_length = 1

    if timestamp_length == 1:
        if not np.isnan(timestamp):
            dt = datetime.datetime.fromtimestamp(timestamp)
            fDOY = (
                int(dt.strftime("%j"))
                + dt.hour / 24.0
                + dt.minute / 60.0 / 24
                + dt.second / 60.0 / 60 / 24
                + dt.microsecond / 1000000.0 / 60 / 60 / 24
            )
    else:
        fDOY = np.ndarray((len(timestamp))) * np.nan
        for i, time_now in enumerate(timestamp):
            if not np.isnan(time_now):
                dt = datetime.datetime.fromtimestamp(time_now)
                fDOY[i] = (
                    int(dt.strftime("%j"))
                    + dt.hour / 24.0
                    + dt.minute / 60.0 / 24
                    + dt.second / 60.0 / 60 / 24
                    + dt.microsecond / 1000000.0 / 60 / 60 / 24
                )

    return fDOY


def fDOY_to_datetime(fDOY: float, year: int) -> datetime.datetime:
    """convert fractional day of year (float) and year (integer) into a datetime variable.

    Parameters:
        fDOY: float
            fractional day of year value
        year: int
            year

    Raises:

    Returns:
        dt: datetime.datetime
            datetime object determined from fDOY and year
    """
    dt = datetime.datetime.strptime("%03.0f%d" % (np.floor(fDOY), year), "%j%Y")
    hour = (fDOY - np.floor(fDOY)) * 24.0
    minute = (hour - np.floor(hour)) * 60.0
    second = (minute - np.floor(minute)) * 60.0
    microsecond = (second - np.floor(second)) * 1e6

    hour = np.floor(hour)
    minute = np.floor(minute)
    second = np.floor(second)
    microsecond = int(np.round(microsecond))

    dt = dt + datetime.timedelta(
        hours=hour, minutes=minute, seconds=second, microseconds=microsecond
    )

    return dt


def timestamp_to_datetime(timestamp: np.array) -> list:
    """convert timestamp (since 1970, or year 0) to datetime.

    Parameters:
        timestamp: np.array
            array of str, int, or float timestamp values

    Raises:

    Returns:
        dt_list: list
            list of datetime.datetime values corresponding to each timestamp
    """
    dt_list = []
    try:
        if timestamp.dtype != float:
            timestamp = timestamp.astype(float)
        first_timestamp = timestamp[0]

        if first_timestamp > 5e13:
            for i in range(len(timestamp)):
                if timestamp[i] != "Nan" and timestamp[i] != "nan":
                    if not np.isnan(timestamp[i]):
                        timestamp[i] = unixTime(timestamp[i])
        timestamp_length = len(timestamp)
    except:
        if timestamp.dtype != float:
            timestamp = float(timestamp)

        if timestamp > 5e13 and not np.isnan(timestamp):
            timestamp = unixTime(timestamp)
        timestamp_length = 1

    if timestamp_length == 1:
        if not np.isnan(timestamp):
            dt_list.append(datetime.datetime.fromtimestamp(timestamp))
    else:
        for i, time_now in enumerate(timestamp):
            if not np.isnan(time_now):
                dt_list.append(datetime.datetime.fromtimestamp(time_now))
    return dt_list


def timestr_to_fDOY(timestr: str) -> float:
    """convert date time string into fractional day of year.

    Parameters:
        timestr: str
            date time string with one of these formats
                %Y%m%d_%H%M
                %Y%m%d_%H%M%S
    Raises:

    Returns:
        fDOY: float
            fractional day of year value for the time string
    """
    # if len(timestr)<=13:
    #     utc_time = datetime.datetime.strptime(timestr, "%Y%m%d_%H%M")
    # else:
    #     utc_time = datetime.datetime.strptime(timestr, "%Y%m%d_%H%M%S")
    fDOY = datetime_to_fDOY(timestr_to_datetime(timestr))
    return fDOY


def timestr_to_datetime(timestr: str) -> datetime.datetime:
    """Convert time string to utc_time.

    Parameters:
        timestr: str
            date time string with one of these formats
                %Y%m%d_%H%M
                %Y%m%d_%H%M%S
    Raises:

    Returns:
        utc_time: datetime.datetime
            datetime value for the time string in UTC
    """
    if len(timestr) <= 13:
        utc_time = datetime.datetime.strptime(timestr, "%Y%m%d_%H%M")
    else:
        utc_time = datetime.datetime.strptime(timestr, "%Y%m%d_%H%M%S")
    return utc_time


def update_time(
    vector: np.array, hr_offset: float, name: Optional[str] = "JULIAN_DAYS"
) -> np.array:
    """update time (julian day, timestamp) with offset.

    Parameters:
        vector: np.array
            vector of time in Julian days or timestamps
        hr_offset: float
            offset in hours to be added to the vector data
        name: optional str, default JULIAN_DAYS
            name of the time variable
                JULIAN_DAYS: fractional day
                timestamp: timestamp in seconds
                index: timestamp in seconds

    Raises:

    Returns:
        vector: np.array
            vector of the time with the offset added
    """
    if name == "JULIAN_DAYS":
        factor = 1 / 24.0
    elif name == "timestamp" or name == "index":
        factor = 60.0 * 60.0

    vector = vector + hr_offset * factor

    return vector


def DTI_in_DTI_series(DTI: pd.DatetimeIndex, DTI_series: pd.Series) -> bool:
    """Find where a single DateTimeIndex occurs in a DateTimeIndex Series.

    Parameters:
        DTI: pd.DatetimeIndex
            single DatetimeIndex to be compared to the series
        DTI_sereis: pd.Series
            series of DatetimeIndex values for comparison

    Raises:

    Returns:
        DTI_bool: bool
            boolean value indicating if the single DatetimeIndex is in the series
    """
    DTI_bool = (
        (DTI.ceil("S") in DTI_series.round("S"))
        | (DTI.floor("S") in DTI_series.round("S"))
        | (DTI.round("S") in DTI_series.round("S"))
    )
    DTI_bool |= (
        (DTI.ceil("S") in DTI_series.floor("S"))
        | (DTI.floor("S") in DTI_series.floor("S"))
        | (DTI.round("S") in DTI_series.floor("S"))
    )
    DTI_bool |= (
        (DTI.ceil("S") in DTI_series.ceil("S"))
        | (DTI.floor("S") in DTI_series.ceil("S"))
        | (DTI.round("S") in DTI_series.ceil("S"))
    )

    return DTI_bool


def where_DTI_in_DTI_series(
    DTI: pd.DatetimeIndex, DTI_series: pd.Series, threshold: Optional[float] = 3
) -> np.array:
    """Find where a DatetimeIndex series contains a single DatetimeIndex value.

    Parameters:
        DTI: pd.DatetimeIndex
            single DatetimeIndex to be compared to the series
        DTI_series: pd.Series
            series of DatetimeIndex values to be compared to DTI
        threshold: optional float, default 3 s
            Allowed difference between DTI and DTI_series values.
            If the difference is smaller than the threshold, the index will be returned for that location.

    Raises:

    Returns:
        DTI_series_bool: np.array
            array of boolean values the same length as DTI_series.
            True where DTI_series is within threshold of DTI.

    """
    DTI_series_bool = np.zeros(len(DTI_series)).astype(bool)
    DTI_series_bool |= (
        (DTI_series.round("S") == DTI.ceil("S"))
        | (DTI_series.round("S") == DTI.floor("S"))
        | (DTI_series.round("S") == DTI.round("S"))
    )
    DTI_series_bool |= (
        (DTI_series.floor("S") == DTI.ceil("S"))
        | (DTI_series.floor("S") == DTI.floor("S"))
        | (DTI_series.floor("S") == DTI.round("S"))
    )
    DTI_series_bool |= (
        (DTI_series.ceil("S") == DTI.ceil("S"))
        | (DTI_series.ceil("S") == DTI.floor("S"))
        | (DTI_series.ceil("S") == DTI.round("S"))
    )

    if np.all(DTI_series_bool == False):
        DTI_diff = np.abs(DTI - DTI_series)
        ind_closest = np.argmin(DTI_diff)
        if DTI_diff[ind_closest].total_seconds() < threshold:
            DTI_series_bool[ind_closest] = True

    return DTI_series_bool


def timestamp_to_dateTimeIndex(
    timestamp: float,
    timezone: Optional[str] = "US/Pacific",
    local: Optional[bool] = False,
) -> pd.DatetimeIndex:
    """Convert timestamp into DatetimeIndex.

    Parameters:
        timestamp: float
            time since 1970, or year 0 in seconds
        timezone: optional str, default US/Pacific
            pytz timezone
        local: optional boolean, default False
            True: if timestamp is in local time
            False: if timestamp is in UTC

    Raises:

    Returns:
        DTI: pd.DatetimeIndex
            timezone aware DatetimeIndex value from timestamp

    """
    tz = pytz.timezone(timezone)
    if local:
        DTI = pd.DatetimeIndex(pd.to_datetime(timestamp, unit="s", utc=True))
        DTI = DTI.tz_convert(tz)
    else:
        DTI = pd.DatetimeIndex(pd.to_datetime(timestamp, unit="s"))
        DTI = DTI.tz_localize(tz)
    return DTI


def dateTimeIndex_to_s(DTI: pd.DatetimeIndex) -> np.array:
    """Convert from datetimeindex to seconds (unix timestamp in UTC).

    Args:
        DTI: pd.DatetimeIndex
            series of datetime indices

    Returns:
        new_values: np.array
            array of float value times in seconds
    """
    try:
        new_values = DTI.astype(np.int64) // 10**9
    except:
        new_values = DTI.values.astype(np.int64) // 10**9
    return new_values


# def timestamp_to_dateTimeIndex(timestamp, timezone="US/Pacific", local=False):
#     tz = pytz.timezone(timezone)
#     if local:
#         DTI = pd.DatetimeIndex(pd.to_datetime(timestamp, unit="s", utc=True))
#         DTI = DTI.tz_convert(tz)
#     else:
#         DTI = pd.DatetimeIndex(pd.to_datetime(timestamp, unit="s"))
#         DTI = DTI.tz_localize(tz)
#     return DTI


def timestamp_to_dateTime(
    timestamp: np.array,
    timezone: Optional[str] = "US/Pacific",
    local: Optional[bool] = False,
):
    """Convert timestamp to date time.

    Args:
        timstamp: np.array
            array of timestamp float values (s)
        timezone: optional string, default US/Pacific
            pytz timezone string
        local: optional boolean, default False

    Returns:
        DT: pd.datetime
            datetime array
    """
    tz = pytz.timezone(timezone)
    if local:
        DT = pd.to_datetime(timestamp, unit="s", utc=True)
        DT = DT.dt.tz_convert(tz)
    else:
        DT = pd.to_datetime(timestamp, unit="s")
        DT = DT.dt.tz_localize(tz)
    return DT


def timestr_to_datetimeindex(
    timestr: str, timezone: Optional[str] = "US/Pacific", local: Optional[bool] = False
) -> pd.DatetimeIndex:
    """Convert time string to utc_time.

    Parameters:
        timestr: str
            date time string with one of these formats
                %Y%m%d_%H%M
                %Y%m%d_%H%M%S
        timezone: optional string, default "US/Pacific"

        local: optional boolean, default False

    Raises:

    Returns:
        DT: pd.DatetimeIndex
            timezone aware datetimeIndex value for the time string
    """

    tz = pytz.timezone(timezone)

    if len(timestr) <= 13:
        format = "%Y%m%d_%H%M"
    else:
        format = "%Y%m%d_%H%M%S"

    if local:
        DTI = pd.DatetimeIndex([pd.to_datetime(timestr, format=format, utc=True)])
        DTI = DTI.tz_convert(tz)
    else:
        DTI = pd.DatetimeIndex([pd.to_datetime(timestr, format=format)])
        DTI = DTI.tz_localize(tz)
        DTI = DTI.tz_convert(tz)

    return DTI
