import numpy as np
import os
from typing import Optional, Tuple

import plotly.graph_objects as go
from plotly.subplots import make_subplots

from spectral_toolkit.TD_analysis.TD_utilities.time_conversions import (
    timestr_to_datetime,
    dateTimeIndex_to_s,
)

from spectral_toolkit.TD_analysis.TD_utilities.utilities_TD_fit import (
    parse_variable_names,
)


def plot_Markes_variable(
    parts, figures_dir, prefix, part_name="Unity", var_2_plot="trap_C"
):
    df_part = parts[part_name]["df"]
    time_2_plot = dateTimeIndex_to_s(df_part.index - df_part.index[0]) / 60.0
    signal = df_part[var_2_plot]

    F = go.Figure()
    F.add_trace(go.Scatter(x=time_2_plot, y=signal))
    try:
        start_ind = np.where(df_part.index >= parts[part_name]["trap_end_datetime"])[0][
            0
        ]
        F.add_vline(x=time_2_plot[start_ind], line_dash="dash", line_color="red")
    except:
        pass

    F.update_layout(xaxis_title="time", yaxis_title=var_2_plot)

    flnm = f"{prefix}_{part_name}_{var_2_plot}_timeseries"
    F.write_image(os.path.join(figures_dir, f"{flnm}.png"))
    F.write_html(os.path.join(figures_dir, f"{flnm}.html"))

    # return F


def plot_TD_variable_timeseries(
    df,
    var_2_plot="trap_C",
    trap_datetimes: Optional[list] = None,
    ramp_datetimes: Optional[list] = None,
    run_datetimes: Optional[list] = None,
):
    run_bool = np.ones(len(df)).astype(bool)
    datetime_name_list = ["_datetime", "datetime", "current time"]
    for datetime_name in datetime_name_list:
        if datetime_name in df.index.names:
            break

    if run_datetimes is not None:
        run_bool = (
            df.index.get_level_values(level=datetime_name) >= run_datetimes[0]
        ) & (df.index.get_level_values(level=datetime_name) <= run_datetimes[1])

    time_2_plot = (
        dateTimeIndex_to_s(
            df.index.get_level_values(level=datetime_name)
            - df.index.get_level_values(level=datetime_name)[0]
        )
        / 60.0
    )
    signal = df[var_2_plot]

    F = go.Figure()
    F.add_trace(go.Scatter(x=time_2_plot[run_bool], y=signal[run_bool]))
    if trap_datetimes is not None:
        trap_inds = np.intersect1d(
            np.where(
                df.index.get_level_values(level=datetime_name) >= trap_datetimes[0]
            ),
            np.where(
                df.index.get_level_values(level=datetime_name) < trap_datetimes[1]
            ),
        )
        F.add_vline(x=time_2_plot[trap_inds[0]], line_dash="dash", line_color="red")
        F.add_vline(x=time_2_plot[trap_inds[-1]], line_dash="dash", line_color="red")
    if ramp_datetimes is not None:
        ramp_inds = np.intersect1d(
            np.where(
                df.index.get_level_values(level=datetime_name) >= ramp_datetimes[0]
            ),
            np.where(
                df.index.get_level_values(level=datetime_name) < ramp_datetimes[1]
            ),
        )
        F.add_vline(x=time_2_plot[ramp_inds[0]], line_dash="dash", line_color="grey")
        F.add_vline(x=time_2_plot[ramp_inds[-1]], line_dash="dash", line_color="grey")

    F.update_layout(xaxis_title="time", yaxis_title=var_2_plot)
    return F


def plot_fits(
    df,
    interp_dict,
    peak_fit,
    figures_dir,
    prefix,
    gaus_result_dict=None,
    cau_gaus_result_dict=None,
    tz=None,
):
    # if interp_dict is not None:
    #     vars_2_reject = create_vars_to_reject_list(interp_dict)
    # else:
    #     vars_2_reject = []
    fit_names, complex_fit_names, small_fit_names = parse_variable_names(
        df,  # vars_2_reject=vars_2_reject
    )

    for j in range(2):
        if j == 0:
            fit_names_now = complex_fit_names
        elif j == 1:
            fit_names_now = small_fit_names

        for i, var_name in enumerate(fit_names_now):
            gaus_result = gaus_result_dict[var_name]
            cau_gaus_result = cau_gaus_result_dict[var_name]
            # ind_2_use = np.where(np.isnan(get_all_data(var_name,df))!=True)[0]
            # signal_now = get_all_data(var_name,df)

            # plot single compound fit with residual
            if gaus_result is not None:
                result = gaus_result
                title = (
                    f"{peak_fit[var_name].gaus_integral:1.2e}, "
                    f"{peak_fit[var_name].gaus_height:1.2e}, "
                    f"{result.best_values['cen']:1.2e}, "
                    f"{result.best_values['sigma']:1.2e}, "
                    f"{result.best_values['offset']:1.2e}, "
                    f"{result.best_values['offset_slope']:1.2e}"
                )

                F = make_subplots(
                    rows=3,
                    cols=1,
                    specs=[[{"rowspan": 2}], [None], [{}]],
                    shared_xaxes=True,
                )
                F.update_layout(height=10.0 * 100, width=12.8 * 100, title_text=title)
                F.update_yaxes(title="signal", row=1, col=1)
                F.update_yaxes(title="residual", row=3, col=1)
                F.update_xaxes(title=f"time [{tz}]", row=3, col=1)

                F.add_trace(
                    go.Scatter(  # x=time_now[ind_2_use],
                        # y=signal_now[ind_2_use],
                        x=result.userkws["x"],
                        y=result.data,
                        mode="markers",
                        marker=dict(color="black"),
                        name=var_name,
                    ),
                    row=1,
                    col=1,
                )
                F.add_trace(
                    go.Scatter(  # x=time_now[ind_2_use],
                        x=result.userkws["x"],
                        y=result.best_fit,
                        mode="lines",
                        line=dict(color="red", dash="dash"),
                        name="gaus",
                    ),
                    row=1,
                    col=1,
                )
                F.add_trace(
                    go.Scatter(  # x=time_now[ind_2_use],
                        # y=signal_now[ind_2_use] - result.best_fit,
                        x=result.userkws["x"],
                        y=result.data - result.best_fit,
                        mode="lines",
                        line=dict(color="red", dash="dash"),
                    ),
                    row=3,
                    col=1,
                )

                flnm = f"{prefix}_{var_name}_gaus_fit"
                F.write_image(os.path.join(figures_dir, f"{flnm}.png"))
                F.write_json(os.path.join(figures_dir, f"{flnm}.json"))

            if cau_gaus_result is not None:
                result = cau_gaus_result
                title = (
                    f"{peak_fit[var_name].cau_gaus_integral:1.2e}, "
                    f"{result.best_values['amp']:1.2e}, "
                    f"{result.best_values['cen']:1.2e}, "
                    f"{result.best_values['sigma_left']:1.2e}, "
                    f"{result.best_values['sigma_right']:1.2e}, "
                    f"{result.best_values['f_left']:1.2e}, "
                    f"{result.best_values['f_right']:1.2e}, "
                    f"{result.best_values['offset']:1.2e}, "
                    f"{result.best_values['offset_slope']:1.2e}"
                )

                F = make_subplots(
                    rows=3,
                    cols=1,
                    specs=[[{"rowspan": 2}], [None], [{}]],
                    shared_xaxes=True,
                )
                F.update_layout(height=10.0 * 100, width=12.8 * 100, title_text=title)
                F.update_yaxes(title="signal", row=1, col=1)
                F.update_yaxes(title="residual", row=3, col=1)
                F.update_xaxes(title=f"time [{tz}]", row=3, col=1)

                F.add_trace(
                    go.Scatter(  # x=time_now[ind_2_use],
                        # y=signal_now[ind_2_use],
                        x=result.userkws["x"],
                        y=result.data,
                        mode="markers",
                        marker=dict(color="black"),
                        name=var_name,
                    ),
                    row=1,
                    col=1,
                )
                F.add_trace(
                    go.Scatter(  # x=time_now[ind_2_use],
                        x=result.userkws["x"],
                        y=result.best_fit,
                        mode="lines",
                        line=dict(color="red", dash="dash"),
                        name="cau-gaus",
                    ),
                    row=1,
                    col=1,
                )
                F.add_trace(
                    go.Scatter(  # x=time_now[ind_2_use],
                        # y=signal_now[ind_2_use] - result.best_fit,
                        x=result.userkws["x"],
                        y=result.data - result.best_fit,
                        mode="lines",
                        line=dict(color="red", dash="dash"),
                    ),
                    row=3,
                    col=1,
                )

                flnm = f"{prefix}_{var_name}_cau_gaus_fit"
                F.write_image(os.path.join(figures_dir, f"{flnm}.png"))
                F.write_html(os.path.join(figures_dir, f"{flnm}.html"))

    for j in range(2):
        if j == 0:
            fit_names_now = complex_fit_names
        elif j == 1:
            fit_names_now = small_fit_names
        sub_max = len(fit_names_now)

        if len(fit_names_now) > 0:
            # plot all compounds in list as subplots
            F = make_subplots(rows=sub_max, cols=1, shared_xaxes=True)
            F.update_layout(height=len(fit_names_now) * 2 * 100, width=12.8 * 100)
            for i, var_name in enumerate(fit_names_now):
                gaus_result = gaus_result_dict[var_name]
                cau_gaus_result = cau_gaus_result_dict[var_name]

                F.add_trace(
                    go.Scatter(
                        x=gaus_result.userkws["x"],
                        y=gaus_result.data,
                        mode="markers",
                        marker=dict(color="black"),
                        name=var_name,
                    ),
                    row=i + 1,
                    col=1,
                )
                if gaus_result is not None:
                    F.add_trace(
                        go.Scatter(
                            x=gaus_result.userkws["x"],
                            y=gaus_result.best_fit,
                            mode="lines",
                            line=dict(color="red", dash="dash"),
                            name="Gaussian fit",
                        ),
                        row=i + 1,
                        col=1,
                    )
                if cau_gaus_result is not None:
                    F.add_trace(
                        go.Scatter(
                            x=cau_gaus_result.userkws["x"],
                            y=cau_gaus_result.best_fit,
                            mode="lines",
                            line=dict(color="blue", dash="dash"),
                            name="Cauchy-Gaussian fit",
                        ),
                        row=i + 1,
                        col=1,
                    )
            F.update_xaxes(title_text=f"time [{tz}]", row=i + 1, col=1)

            if j == 0:
                flnm = f"{prefix}_complex_fit"
            elif j == 1:
                flnm = f"{prefix}_small_molecule_fit"
            F.write_image(os.path.join(figures_dir, f"{flnm}.png"))
            F.write_html(os.path.join(figures_dir, f"{flnm}.html"))


def create_time_array(df_fits, tz):
    time_list = []
    for start_str in df_fits.index.get_level_values("start"):
        start_dt = tz.localize(timestr_to_datetime(start_str))
        time_list.append(start_dt)
    time_array = np.array(time_list)
    sort_ind = np.argsort(time_array)

    return time_array, sort_ind


def plot_regular_timeseries(
    log_scale,
    relative,
    compound_list,
    figures_dir,
    prefix,
    df_fits,
    df_trap_int,
    tz=None,
    mode="cauchy_gaussian_fit",
):
    """
    log_scale,
    relative,
    mode: integral (normal), gaussian_fit (data from gaussian fit), cauchy_gaussian_fit (data from cauchy-gaussian fit)
    """
    fit_names = list()
    for var_name in compound_list:
        fit_names.append(var_name)
    fit_names.sort()

    time_array, sort_ind = create_time_array(df_fits, tz)

    updated_run_suffix = f"{prefix}_complex"

    sub_max = len(fit_names)
    if sub_max > 0:
        F = make_subplots(rows=sub_max, cols=1)
        F.update_layout(height=10.0 * 100, width=12.8 * 100)
        for i, compound in enumerate(fit_names):
            if mode == "integral":
                desorb_values = df_trap_int[(compound, "integrated_breakthrough")]
            elif mode == "gaussian_fit":
                desorb_values = (
                    df_fits[(compound, "gaus_integral")] / 1000.0
                )  # convert from ppb*s to ppm*s
            elif mode == "cauchy_gaussian_fit":
                desorb_values = (
                    df_fits[(compound, "cau_gaus_integral")] / 1000.0
                )  # convert from ppb*s to ppm*s

            if relative:
                F.add_trace(
                    go.Scatter(
                        x=time_array[sort_ind],
                        y=desorb_values[sort_ind] * 100 / np.nanmax(desorb_values),
                        mode="markers+lines",
                        line=dict(dash="dash"),  # color='blue',
                        name=compound,
                    ),
                    row=i + 1,
                    col=1,
                )

                if i == int(round(sub_max / 2.0)) - 1 and log_scale:
                    F.update_yaxes(title=f"log(relative {mode})", row=i + 1, col=1)
                elif i == int(round(sub_max / 2.0)) - 1:
                    F.update_yaxes(title=f"relative {mode}", row=i + 1, col=1)
            else:
                F.add_trace(
                    go.Scatter(
                        x=time_array[sort_ind],
                        y=desorb_values[sort_ind],
                        mode="markers+lines",
                        line=dict(dash="dash"),  # color='blue',
                        name=compound,
                    ),
                    row=i + 1,
                    col=1,
                )

                if i == int(round(sub_max / 2.0)) - 1 and log_scale:
                    F.update_yaxes(title=f"log(integrated {mode})", row=i + 1, col=1)
                elif i == int(round(sub_max / 2.0)) - 1:
                    F.update_yaxes(title=f"integrated {mode}", row=i + 1, col=1)
            if log_scale:
                F.update_yaxes(type="log", range=[1e-5, 110], row=i + 1, col=1)
        F.update_xaxes(title="Time", row=i + 1, col=1)

        if log_scale:
            updated_run_suffix = f"{updated_run_suffix}_log"
        if relative:
            flnm = f"{updated_run_suffix}_{mode}_relative_timeseries"
        else:
            flnm = f"{updated_run_suffix}_{mode}_timeseries"
        F.write_image(os.path.join(figures_dir, f"{flnm}.png"))
        F.write_html(os.path.join(figures_dir, f"{flnm}.html"))


def plot_conc_timeseries(
    df_fits,
    df_trap_conc,
    df_input_conc_ppb,
    compound_list,
    figures_dir,
    prefix,
    tz=None,
):
    """ """
    time_array, sort_ind = create_time_array(df_fits, tz)
    for compound in compound_list:
        input_conc_ppb_now = df_input_conc_ppb[compound]
        trap_conc_ppb_now = df_trap_conc[f"{compound}_ppb"]

        F = go.Figure()
        F.add_trace(
            go.Scatter(
                x=time_array[sort_ind],
                y=input_conc_ppb_now[sort_ind],
                mode="markers+lines",
                line=dict(dash="dash"),  # color='blue',
                name="Measured Input",
            )
        )
        F.add_trace(
            go.Scatter(
                x=time_array[sort_ind],
                y=trap_conc_ppb_now[sort_ind],
                mode="markers+lines",
                line=dict(dash="dash"),  # color='blue',
                name="Actual Input",
            )
        )
        F.update_yaxes(title="Concentration (ppb)")
        F.update_xaxes(title="Time")

        flnm = f"{prefix}_{compound}_concentration_timeseries"
        F.write_image(os.path.join(figures_dir, f"{flnm}.png"))
        F.write_html(os.path.join(figures_dir, f"{flnm}.html"))


def get_annotation_txt(name, array, trap_run_ind, blank_ind):
    trap_mean = None
    trap_std = None
    blank_mean = None
    blank_std = None
    if len(trap_run_ind) > 0 and ~np.all(array[trap_run_ind].isna()):
        trap_mean = np.nanmean(array[trap_run_ind])
        trap_std = np.nanstd(array[trap_run_ind])
    if len(blank_ind) > 0 and ~np.all(array[blank_ind].isna()):
        blank_mean = np.nanmean(array[trap_run_ind])
        blank_std = np.nanstd(array[trap_run_ind])

    txt_str = f"{name} run:"
    if trap_mean is not None:
        txt_str += f" {trap_mean:.4e}"
    if trap_mean is not None and trap_std is not None:
        txt_str += f" ({trap_std:.1e})"
    if blank_mean is not None:
        txt_str += f", blank: {blank_mean:.4e}"
    if blank_mean is not None and blank_std is not None:
        txt_str += f" ({blank_std:.1e})"

    return txt_str


def plot_calibrated_timeseries(
    df_fits,
    df_trap_conc,
    df_trap_int,
    df_normalized_data,
    run_type_flag,
    compound_list,
    figures_dir,
    prefix,
    tz=None,
    mode="cauchy_gaussian_fit",
    breakthrough_included=False,
):
    """ """
    time_array, sort_ind = create_time_array(df_fits, tz)
    fit_names = compound_list

    updated_run_suffix = f"{prefix}_complex"
    ###################### MAKE SUBPLOTS???
    # plot calibrated timeseries
    for compound in fit_names:  # desorb:
        trap_run_ind = np.where(run_type_flag)[0]
        blank_ind = np.where(run_type_flag == False)[0]
        dt = np.nanmedian(np.diff(time_array[sort_ind]))

        xlim_min_set = time_array[sort_ind][0] - 0.05 * (
            time_array[sort_ind][-1] - time_array[sort_ind][0]
        )
        xlim_max_set = time_array[sort_ind][-1] + 0.05 * (
            time_array[sort_ind][-1] - time_array[sort_ind][0]
        )

        trapped = df_trap_conc[f"{compound}_ppm"]
        breakthrough = df_trap_int[f"{compound}_integral"]
        pct_breakthrough = df_normalized_data[(compound, "integrated_breakthrough_pct")]

        if mode == "integral":
            desorb = df_fits[(compound, "integral")]
            pct_desorb = df_normalized_data[(compound, "integral_pct")]
        elif mode == "gaussian_fit":
            desorb = df_fits[(compound, "gaus_conc_integral")]
            pct_desorb = df_normalized_data[(compound, "gaus_conc_area_pct")]
        elif mode == "cauchy_gaussian_fit":
            desorb = (
                df_fits[(compound, "cau_gaus_integral")] / 1000.0
            )  # convert from ppb*s to ppm*s
            pct_desorb = df_normalized_data[(compound, "cau_gaus_conc_area_pct")]

        if np.all(trapped == 0) != True:
            desorb_str = get_annotation_txt("desorbed", desorb, trap_run_ind, blank_ind)
            pct_desorb_str = get_annotation_txt(
                "pct desorbed", pct_desorb, trap_run_ind, blank_ind
            )
            if breakthrough_included:
                breakthrough_str = get_annotation_txt(
                    "breakthrough", breakthrough, trap_run_ind, blank_ind
                )
                pct_breakthrough_str = get_annotation_txt(
                    "pct breakthrough", pct_breakthrough, trap_run_ind, blank_ind
                )

            ylim_max_set = (
                np.nanmax(
                    np.append(
                        trapped[sort_ind], desorb[sort_ind] + breakthrough[sort_ind]
                    )
                )
                * 1.2
            )
            ylim_min_set = 0.0

            # plot concentration for each compound
            F = make_subplots(rows=2, cols=1)
            F.update_layout(height=10.0 * 100, width=12.8 * 100)
            F.add_trace(
                go.Bar(
                    x=time_array[sort_ind],
                    y=desorb[sort_ind],
                    width=0.9 * dt.seconds,
                    name="desorbed",
                ),
                row=1,
                col=1,
            )
            if breakthrough_included:
                F.add_trace(
                    go.Bar(
                        x=time_array[sort_ind],
                        y=breakthrough[sort_ind],
                        width=0.9 * dt.seconds,
                        name="breakthrough",
                    ),
                    row=1,
                    col=1,
                )
            F.update_layout(barmode="stack")  # , row=1, col=1)
            F.add_trace(
                go.Scatter(
                    x=time_array[sort_ind],
                    y=trapped[sort_ind],
                    mode="markers+lines",
                    line=dict(color="black", dash="dash"),
                    name="trapped",
                ),
                row=1,
                col=1,
            )

            F.add_annotation(
                x=0,
                y=1,
                text=desorb_str,
                row=1,
                col=1,
            )

            if breakthrough_included:
                F.add_annotation(
                    x=0,
                    y=2,
                    text=breakthrough_str,
                    row=1,
                    col=1,
                )
            F.update_yaxes(
                range=[ylim_min_set, ylim_max_set],
                title="Concentration (ppm*s)",
                row=1,
                col=1,
            )
            F.update_xaxes(range=[xlim_min_set, xlim_max_set], row=1, col=1)

            test = np.append(
                np.array(100.0), pct_desorb[sort_ind] + pct_breakthrough[sort_ind]
            )
            ind = np.where(test != np.inf)
            ylim_max_set = np.nanmax(test[ind]) * 1.2

            F.add_trace(
                go.Bar(
                    x=time_array[sort_ind],
                    y=pct_desorb[sort_ind],
                    width=0.9 * dt.seconds,
                    name="desorbed",
                ),
                row=2,
                col=1,
            )
            if breakthrough_included:
                F.add_trace(
                    go.Bar(
                        x=time_array[sort_ind],
                        y=pct_breakthrough[sort_ind],
                        width=0.9 * dt.seconds,
                        name="breakthrough",
                    ),
                    row=2,
                    col=1,
                )

            F.add_annotation(
                x=0,
                y=1,
                text=pct_desorb_str,
                row=2,
                col=1,
            )
            if breakthrough_included:
                F.add_annotation(
                    x=0,
                    y=2,
                    text=pct_breakthrough_str,
                    row=2,
                    col=1,
                )
            F.update_yaxes(
                range=[ylim_min_set, ylim_max_set],
                title="Fractional mass of AVX (%)",
                row=1,
                col=1,
            )
            F.update_xaxes(
                range=[xlim_min_set, xlim_max_set], title="time", row=1, col=1
            )

            flnm = f"{updated_run_suffix}_{mode}_bar_timeseries"
            F.write_image(os.path.join(figures_dir, f"{flnm}.png"))
            F.write_html(os.path.join(figures_dir, f"{flnm}.html"))


def plot_compound_mass_conservation_timeseries(
    df_fits,
    df_trap_conc,
    df_trap_int,
    df_normalized_data,
    run_type_flag,
    compound_list,
    figures_dir,
    prefix,
    tz=None,
    mode="cauchy_gaussian_fit",
    breakthrough_included=False,
):
    """ """
    time_array, sort_ind = create_time_array(df_fits, tz)

    # _, fit_names, _ = parse_variable_names(df)

    fit_names = compound_list

    updated_run_suffix = f"{prefix}_complex"

    # plot calibrated timeseries
    for compound in fit_names:  # desorb:
        trap_run_ind = np.where(run_type_flag)[0]
        blank_ind = np.where(run_type_flag == False)[0]
        dt = np.nanmedian(np.diff(time_array[sort_ind]))

        xlim_min_set = time_array[sort_ind][0] - 0.05 * (
            time_array[sort_ind][-1] - time_array[sort_ind][0]
        )
        xlim_max_set = time_array[sort_ind][-1] + 0.05 * (
            time_array[sort_ind][-1] - time_array[sort_ind][0]
        )

        trapped = df_trap_conc[f"{compound}_ppm"]
        breakthrough = df_trap_int[f"{compound}_integral"]
        pct_breakthrough = df_normalized_data[(compound, "integrated_breakthrough_pct")]
        if mode == "integral":
            desorb = df_fits[(compound, "integral")]
            pct_desorb = df_normalized_data[(compound, "integral_pct")]
        elif mode == "gaussian_fit":
            desorb = df_fits[(compound, "gaus_conc_integral")]
            pct_desorb = df_normalized_data[(compound, "gaus_conc_area_pct")]
        elif mode == "cauchy_gaussian_fit":
            desorb = (
                df_fits[(compound, "cau_gaus_integral")] / 1000.0
            )  # convert from ppb*s to ppm*s
            pct_desorb = df_normalized_data[(compound, "cau_gaus_conc_area_pct")]

        if np.all(trapped == 0) != True:
            ylim_max_set = (
                np.nanmax(
                    np.append(
                        trapped[sort_ind], desorb[sort_ind] + breakthrough[sort_ind]
                    )
                )
                * 1.2
            )
            ylim_min_set = 0.0

            # plot concentration for each compound
            F = make_subplots(rows=2, cols=1)
            F.update_layout(height=10.0 * 100, width=12.8 * 100)
            F.add_trace(
                go.Bar(
                    x=time_array[sort_ind],
                    y=desorb[sort_ind],
                    width=0.9 * dt,
                    name="desorbed",
                ),
                row=1,
                col=1,
            )
            if breakthrough_included:
                F.add_trace(
                    go.Bar(
                        x=time_array[sort_ind],
                        y=breakthrough[sort_ind],
                        width=0.9 * dt,
                        name="breakthrough",
                    ),
                    row=1,
                    col=1,
                )
            F.update_layout(barmode="stack")  # , row=1, col=1)
            F.add_trace(
                go.Scatter(
                    x=time_array[sort_ind],
                    y=trapped[sort_ind],
                    mode="markers+lines",
                    line=dict(color="black", dash="dash"),
                    name="trapped",
                ),
                row=1,
                col=1,
            )
            F.add_annotation(
                x=0,
                y=1,
                text=(
                    f"desorbed run: {np.nanmean(desorb[trap_run_ind]):.4e} "
                    f"({np.nanstd(desorb[trap_run_ind]):.1e}), "
                    f"blank: {np.nanmean(desorb[blank_ind]):.4e} "
                    f"({np.nanstd(desorb[blank_ind]):.1e})"
                ),
                row=1,
                col=1,
            )
            if breakthrough_included:
                F.add_annotation(
                    x=0,
                    y=2,
                    text=(
                        f"breakthrough run: {np.nanmean(breakthrough[trap_run_ind]):.4e} "
                        f"({np.nanstd(breakthrough[trap_run_ind]):.1e}), "
                        f"blank: {np.nanmean(breakthrough[blank_ind]):.4e} "
                        f"({np.nanstd(breakthrough[blank_ind]):.1e})"
                    ),
                    row=1,
                    col=1,
                )
            F.update_yaxes(
                range=[ylim_min_set, ylim_max_set],
                title="Concentration (ppm*s)",
                row=1,
                col=1,
            )
            F.update_xaxes(range=[xlim_min_set, xlim_max_set], row=1, col=1)

            test = np.append(
                np.array(100.0), pct_desorb[sort_ind] + pct_breakthrough[sort_ind]
            )
            ind = np.where(test != np.inf)
            ylim_max_set = np.nanmax(test[ind]) * 1.2

            F.add_trace(
                go.Bar(
                    x=time_array[sort_ind],
                    y=pct_desorb[sort_ind],
                    width=0.9 * dt,
                    name="desorbed",
                ),
                row=2,
                col=1,
            )
            if breakthrough_included:
                F.add_trace(
                    go.Bar(
                        x=time_array[sort_ind],
                        y=pct_breakthrough[sort_ind],
                        width=0.9 * dt,
                        name="breakthrough",
                    ),
                    row=2,
                    col=1,
                )
            F.add_annotation(
                x=0,
                y=1,
                text=(
                    f"desorbed run: {np.nanmean(pct_desorb[trap_run_ind]):.4e} "
                    f"({np.nanstd(pct_desorb[trap_run_ind]):.1e}), "
                    f"blank: {np.nanmean(pct_desorb[blank_ind]):.4e} "
                    f"({np.nanstd(pct_desorb[blank_ind]):.1e})"
                ),
                row=2,
                col=1,
            )
            if breakthrough_included:
                F.add_annotation(
                    x=0,
                    y=2,
                    text=(
                        f"breakthrough run: {np.nanmean(pct_breakthrough[trap_run_ind]):.4e} "
                        f"({np.nanstd(pct_breakthrough[trap_run_ind]):.1e}), "
                        f"blank: {np.nanmean(pct_breakthrough[blank_ind]):.4e} "
                        f"({np.nanstd(pct_breakthrough[blank_ind]):.1e})"
                    ),
                    row=2,
                    col=1,
                )
            F.update_yaxes(
                range=[ylim_min_set, ylim_max_set],
                title="Fractional mass of AVX (%)",
                row=2,
                col=1,
            )
            F.update_xaxes(
                range=[xlim_min_set, xlim_max_set], title="time", row=2, col=1
            )

            flnm = f"{updated_run_suffix}_{compound}_{mode}_bar_timeseries"
            F.write_image(os.path.join(figures_dir, f"{flnm}.png"))
            F.write_html(os.path.join(figures_dir, f"{flnm}.html"))


def plot_all_mass_conservation_timeseries(
    df_fits,
    df_trap_conc,
    df_trap_int,
    df_normalized_data,
    run_type_flag,
    compound_list,
    figures_dir,
    prefix,
    tz=None,
    mode="cauchy_gaussian_fit",
    breakthrough_included=False,
):
    """ """
    time_array, sort_ind = create_time_array(df_fits, tz)

    fit_names = compound_list

    updated_run_suffix = f"{prefix}_complex"

    compound_names = []
    for compound in fit_names:
        trapped = df_trap_conc[f"{compound}_ppm"]
        if np.all(trapped == 0) != True:
            compound_names.append(compound)

    if len(compound_names) > 0:
        F = make_subplots(rows=len(compound_names), cols=1)
        F.update_layout(height=len(compound_names) * 100, width=12.8 * 100)
        for i, compound in enumerate(compound_names):  # desorb:
            trap_run_ind = np.where(run_type_flag)[0]
            blank_ind = np.where(run_type_flag == False)[0]
            dt = np.nanmedian(np.diff(time_array[sort_ind]))

            xlim_min_set = time_array[sort_ind][0] - 0.05 * (
                time_array[sort_ind][-1] - time_array[sort_ind][0]
            )
            xlim_max_set = time_array[sort_ind][-1] + 0.05 * (
                time_array[sort_ind][-1] - time_array[sort_ind][0]
            )

            trapped = df_trap_conc["%s_ppm" % compound]
            pct_breakthrough = df_normalized_data[
                (compound, "integrated_breakthrough_pct")
            ]
            if mode == "integral":
                pct_desorb = df_normalized_data[(compound, "integral_pct")]
            elif mode == "gaussian_fit":
                pct_desorb = df_normalized_data[(compound, "gaus_conc_area_pct")]
            elif mode == "cauchy_gaussian_fit":
                pct_desorb = df_normalized_data[(compound, "cau_gaus_conc_area_pct")]

            test = np.append(
                np.array(100.0), pct_desorb[sort_ind] + pct_breakthrough[sort_ind]
            )
            ind = np.where(test != np.inf)
            ylim_max_set = np.nanmax(test[ind]) * 1.2
            ylim_min_set = 0.0

            F.add_trace(
                go.Bar(
                    x=time_array[sort_ind],
                    y=pct_desorb[sort_ind],
                    width=0.9 * dt,
                    name="desorbed",
                ),
                row=i,
                col=1,
            )
            if breakthrough_included:
                F.add_trace(
                    go.Bar(
                        x=time_array[sort_ind],
                        y=pct_breakthrough[sort_ind],
                        width=0.9 * dt,
                        name="breakthrough",
                    ),
                    row=i,
                    col=1,
                )
            F.add_annotation(
                x=0,
                y=1,
                text=(
                    f"desorbed run: {np.nanmean(pct_desorb[trap_run_ind]):.4e} "
                    f"({np.nanstd(pct_desorb[trap_run_ind]):.1e}), "
                    f"blank: {np.nanmean(pct_desorb[blank_ind]):.4e} "
                    f"({np.nanstd(pct_desorb[blank_ind]):.1e})"
                ),
                row=i,
                col=1,
            )
            if breakthrough_included:
                F.add_annotation(
                    x=0,
                    y=2,
                    text=(
                        f"breakthrough run: {np.nanmean(pct_breakthrough[trap_run_ind]):.4e} "
                        f"({np.nanstd(pct_breakthrough[trap_run_ind]):.1e}), "
                        f"blank: {np.nanmean(pct_breakthrough[blank_ind]):.4e} "
                        f"({np.nanstd(pct_breakthrough[blank_ind]):.1e})"
                    ),
                    row=i,
                    col=1,
                )
            F.update_yaxes(
                range=[ylim_min_set, ylim_max_set],
                title=f"Fractional mass of {compound} (%)",
                row=i,
                col=1,
            )
        F.update_xaxes(range=[xlim_min_set, xlim_max_set], title="time", row=i, col=1)

        flnm = f"{updated_run_suffix}_{mode}_bar_timeseries"
        F.write_image(os.path.join(figures_dir, f"{flnm}.png"))
        F.write_html(os.path.join(figures_dir, f"{flnm}.html"))


def plot_precon_timeseries(
    df_fits,
    df_flow_precon,
    df_conc_precon,
    df_input_conc_ppb,
    run_type_flag,
    compound_list,
    figures_dir,
    prefix,
    tz=None,
):
    time_array, sort_ind = create_time_array(df_fits, tz)
    time_array = time_array[sort_ind]

    flow_precon = df_flow_precon["flow_precon_factor"][sort_ind]
    trap_run_ind = np.where(run_type_flag[sort_ind])[0]

    F = go.Figure()
    F.add_trace(
        go.Scatter(
            x=time_array[trap_run_ind],
            y=flow_precon[trap_run_ind],
            name="Flow Calculation",
            mode="markers",
        )
    )
    for compound in compound_list:
        cau_gaus_area_precon = df_conc_precon[
            (compound, "cau_gaus_area_precon_factor")
        ][sort_ind]
        F.add_trace(
            go.Scatter(
                x=time_array[trap_run_ind],
                y=cau_gaus_area_precon[trap_run_ind],
                name=f"{compound} Fit Area",
                mode="markers",
            )
        )
    F.update_yaxes(title="Preconcentration Factor")
    F.update_xaxes(title="time")

    flnm = f"{prefix}_precon_timeseries"
    F.write_image(os.path.join(figures_dir, f"{flnm}.png"))
    F.write_json(os.path.join(figures_dir, f"{flnm}.json"))

    F = make_subplots(rows=3, cols=1)
    F.update_layout(height=8.0 * 100, width=6.0 * 100)
    for compound in compound_list:
        desorb = (
            df_fits[(compound, "cau_gaus_integral")][sort_ind] / 1000.0
        )  # convert from ppb*s to ppm*s
        F.add_trace(
            go.Scatter(
                x=time_array[trap_run_ind], y=desorb[trap_run_ind], name=compound
            ),
            row=1,
            col=1,
        )
    F.update_yaxes(title="Peak Fit Area", row=1, col=1)

    if "trap_flow" in df_flow_precon:
        trap_flow = df_flow_precon["trap_flow"]["nanmean"][sort_ind]

        F.add_trace(
            go.Scatter(
                x=time_array[trap_run_ind],
                y=trap_flow[trap_run_ind],
                name="Trap Flow (sccm)",
            ),
            row=2,
            col=1,
        )

    for compound in compound_list:
        trap_ppb = df_input_conc_ppb[compound][sort_ind]
        F.add_trace(
            go.Scatter(
                x=time_array[trap_run_ind],
                y=trap_ppb[trap_run_ind],
                name=compound,
            ),
            row=3,
            col=1,
        )
        F.update_yaxes(title="Trap Concentration (ppb)", row=3, col=1)
    F.update_xaxes(title="Time", row=3, col=1)

    flnm = f"{prefix}_precon_anal_timeseries"
    F.write_image(os.path.join(figures_dir, f"{flnm}.png"))
    F.write_html(os.path.join(figures_dir, f"{flnm}.html"))


def plot_flows(df_flows):

    MFCs = [
        "MFC1",
        "MFC2",
        "MFC3",
        "MFC4",
        "MFC5",
        "MFM6",
        "MFC7",
        "PC1",
        # "sample",
        # "first_dilution",
        # "second_dilution",
        # "trap",
        # "instrument",
        # "overflow_dilution",
        # "pump",
        # "analyte",
        # "third_dilution",
    ]
    MFCs_new = []
    for MFC in MFCs:
        if f"{MFC}_flow" in df_flows and f"{MFC}_flowset" in df_flows:
            MFCs_new = np.append(MFCs_new, MFC)
    MFCs = MFCs_new
    # print(MFCs)

    datetime_name_list = ["_datetime", "datetime", "current time"]
    for datetime_name in datetime_name_list:
        if datetime_name in df_flows.index.names:
            break

    fig = make_subplots(
        rows=len(MFCs), cols=1, shared_xaxes=True, vertical_spacing=0.05
    )
    for j, MFC in enumerate(MFCs):
        fig.add_trace(
            go.Scatter(
                x=df_flows.index.get_level_values(level=datetime_name),
                y=df_flows[f"{MFC}_flow"],
                marker_color="blue",
                mode="markers",
                name=f"{MFC} Reading",
            ),
            row=j + 1,
            col=1,
        )
        fig.add_trace(
            go.Scatter(
                x=df_flows.index.get_level_values(level=datetime_name),
                y=df_flows[f"{MFC}_flowset"],
                marker_color="green",
                mode="markers",
                name=f"{MFC} Setpoint",
            ),
            row=j + 1,
            col=1,
        )
    return fig
