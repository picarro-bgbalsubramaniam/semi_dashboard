# -*- coding: utf-8 -*-
"""
Open files generated while running the Markes system. Parse the data and save it.

Created on August 13 2020

@author: kskog
"""
from copy import copy, deepcopy
from datetime import timedelta
from pathlib import Path
from typing import Optional, Tuple

import pandas as pd
import numpy as np
import os
import glob
from datetime import timedelta, datetime
import pytz

import os

from spectral_toolkit.TD_analysis.TD_utilities.time_conversions import (
    timestamp_to_dateTimeIndex,
    timestamp_to_dateTime,
)
from spectral_toolkit.TD_analysis.TD_utilities.picarro_TD_utilities import (
    get_picarro_SAT_log_names,
)


def calculate_trap_times(sequence_series):
    start_datetime = sequence_series.name
    approximate_trap_start_delta = timedelta(seconds=0)
    approximate_trap_end_delta = timedelta(seconds=0)

    # get trap time
    if "min_flow" in sequence_series:
        min_flow = float(sequence_series["min_flow"])
        sample_volume_mL = float(sequence_series["sample_volume_mL"])
        trap_time = sample_volume_mL / min_flow
    elif "trap_time" in sequence_series:
        trap_time = float(sequence_series["trap_time"])

    post_sample_purge_time, trap_purge_time = np.nan, np.nan
    if "post_sample_purge_time" in sequence_series:
        post_sample_purge_time = float(sequence_series["post_sample_purge_time"])
    if "trap_purge_time" in sequence_series:
        trap_purge_time = float(sequence_series["trap_purge_time"])

    if not np.isnan(post_sample_purge_time):
        approximate_trap_end_delta -= timedelta(minutes=post_sample_purge_time)

    if not np.isnan(trap_purge_time):
        approximate_trap_start_delta -= timedelta(minutes=trap_purge_time)

    if not np.isnan(trap_time):
        approximate_trap_start_delta -= timedelta(minutes=trap_time)
    else:
        approximate_trap_start_delta -= timedelta(minutes=10.0)

    trap_end_datetime = start_datetime + approximate_trap_end_delta
    trap_start_datetime = copy(trap_end_datetime) + approximate_trap_start_delta

    return (
        trap_start_datetime,
        trap_end_datetime,
        approximate_trap_start_delta,
        approximate_trap_end_delta,
    )


def rename_variables(
    df: pd.DataFrame, initial_name: str, new_name: str
) -> pd.DataFrame:
    df = df.rename(columns={initial_name: new_name})
    return df


MFC_log_defaults = {
    "sample_flow": "MFC7",
    "first_dilution_flow": "MFC3",
    "second_dilution_flow": "MFC3",
    "third_dilution_flow": None,
    "overflow_dilution_flow": None,
    "instrument_flow": "MFC6",
    "trap_flow": None,
}
MFC_defaults = {
    "sample_flow": 0.0,
    "first_dilution_flow": 0.0,
    "second_dilution_flow": 0.0,
    "third_dilution_flow": 0.0,
    "overflow_dilution_flow": 0.0,
    "instrument_flow": 50.0,
    "trap_flow": 250.0,
}

flow_step_dict = {
    "trap_flow": ([2], "trap"),
    "sample_flow": ([2], "trap"),
    "first_dilution_flow": ([2], "trap"),
    "second_dilution_flow": ([2], "trap"),
    "overflow_dilution_flow": ([2], "trap"),
    "instrument_flow": ([4, 5], "run"),
}

flow_state_dict = {
    "trap_flow": "TRAPPING",
    "sample_flow": "TRAPPING",
    "first_dilution_flow": "TRAPPING",
    "second_dilution_flow": "TRAPPING",
    "overflow_dilution_flow": "TRAPPING",
    "instrument_flow": "desorb_flag",
}


class TD_flow:
    def __init__(
        self,
        MFC_dict: dict,
        timezone,
        flow_path: Optional[Path] = None,
        verbose: Optional[bool] = False,
        reprocess: Optional[bool] = True,
        run_num: Optional[int] = 1,
        start_datetimes: Optional[list] = [],
        start_dt: Optional[datetime] = None,
        end_dt: Optional[datetime] = None,
    ):

        self.MFC_dict = MFC_dict
        self.MFC_errors = {}
        self.timezone = timezone
        self.start_dt = start_dt
        self.end_dt = end_dt
        self.tz = pytz.timezone(timezone)
        self.flow_path = flow_path
        self.verbose = verbose
        self.reprocess = reprocess
        self.run_num = run_num
        self.start_datetimes = start_datetimes

        self.initialize_dfs()
        self.flow_dict_list = []
        self.set_MFC_defaults()
        # update MFC_dict, MFC_errors, and df_MFCs
        self.parse_flow_log()
        # collect data in df_all
        # self.flow_group_stats(step_name=step_name)
        # # group and calculate statistics based on run and step (dfg_runs, dfg_steps)
        # self.add_const_flows()

    def initialize_dfs(self):
        self.df_MFCs = None
        self.df_all = pd.DataFrame(
            index=range(self.run_num), columns=self.MFC_dict.keys()
        )
        self.dfg = pd.DataFrame(index=range(self.run_num), columns=self.MFC_dict.keys())
        self.df_temp = None

        columns = [("datetime", "nanmean")]
        columns = [("datetime", "nanstd")]
        columns = [("datetime", "nanmin")]
        columns = [("datetime", "nanmax")]
        for key in self.MFC_dict:
            columns.append((key, "nanmean"))
            columns.append((key, "nanstd"))
            columns.append((key, "nanmin"))
            columns.append((key, "nanmax"))

        self.df_flow = pd.DataFrame(
            index=range(self.run_num), columns=pd.MultiIndex.from_tuples(columns)
        )
        self.dfg_runs = pd.DataFrame(
            index=range(self.run_num), columns=pd.MultiIndex.from_tuples(columns)
        )
        self.dfg_steps = pd.DataFrame(
            index=range(self.run_num), columns=pd.MultiIndex.from_tuples(columns)
        )
        if len(self.start_datetimes) == self.run_num:
            self.df_flow.loc[:, ("datetime", "nanmean")] = self.start_datetimes
            self.dfg_runs.loc[:, ("datetime", "nanmean")] = self.start_datetimes
            self.dfg_steps.loc[:, ("datetime", "nanmean")] = self.start_datetimes

    def set_MFC_defaults(self):
        if self.flow_path is not None:
            for key, value in MFC_log_defaults.items():
                if key not in self.MFC_dict:
                    self.MFC_dict[key] = value

        for key, value in MFC_defaults.items():
            if key not in self.MFC_dict:
                self.MFC_dict[key] = value

        for key in self.MFC_dict:
            self.MFC_errors[f"{key}_error"] = 0.0

        self.df_MFCs = pd.concat(
            (pd.DataFrame([self.MFC_dict]), pd.DataFrame([self.MFC_errors])), axis=1
        )

    def parse_flow_log(self):
        if self.flow_path is not None:
            df_list = []
            log_name_list = get_picarro_SAT_log_names(
                self.flow_path, self.timezone, self.start_dt, self.end_dt
            )

            run_count = 0
            #%% Parse data saved by the Python logger controlling flow
            for log_name in log_name_list:
                df = pd.read_csv(log_name, sep=",")

                for key in df.keys():
                    if key[0] == " ":
                        df.rename(columns={key: key[1:]}, inplace=True)

                df.index = timestamp_to_dateTimeIndex(
                    df["current time"], self.timezone, local=True
                )

                for new_name, initial_MFC in self.MFC_dict.items():
                    df = rename_variables(df, f"{initial_MFC}_flow", new_name)
                    df = rename_variables(
                        df, f"{initial_MFC}_flowset", f"{new_name}set"
                    )

                if "run_count" not in df:
                    df["run_count"] = None
                df["run_count"] = run_count
                run_count += 1

                df_list.append(df)  # add full dataset to a list

            self.df_all = pd.concat(df_list)
        else:
            # self.df_all = pd.DataFrame()
            self.df_all = pd.DataFrame(
                index=range(self.run_num), columns=self.MFC_dict.keys()
            )

    def flow_group_stats(self, step_name="step_num"):
        if self.flow_path is not None:
            self.dfg_runs = self.df_all.groupby("run_count").agg(
                [np.nanmean, np.nanstd, np.nanmin, np.nanmax]
            )

            new_ind = pd.MultiIndex.from_tuples(
                (
                    ("datetime", "nanmean"),
                    ("datetime", "nanmax"),
                    ("datetime", "nanmin"),
                )
            )

            self.dfg_runs[new_ind] = None
            self.dfg_runs.loc[:, ("datetime", "nanmean")] = timestamp_to_dateTime(
                self.dfg_runs["current time"]["nanmean"], self.timezone, local=True
            )
            self.dfg_runs.loc[:, ("datetime", "nanmax")] = timestamp_to_dateTime(
                self.dfg_runs["current time"]["nanmax"], self.timezone, local=True
            )
            self.dfg_runs.loc[:, ("datetime", "nanmin")] = timestamp_to_dateTime(
                self.dfg_runs["current time"]["nanmin"], self.timezone, local=True
            )

            self.dfg_steps = self.df_all.groupby(["run_count", step_name]).agg(
                [np.nanmean, np.nanstd, np.nanmin, np.nanmax]
            )
            self.dfg_steps.sort_values(("current time", "nanmean"), inplace=True)

            self.dfg = self.df_all.groupby(
                ["run_count", step_name, self.df_all.index]
            ).agg(lambda x: x)
            self.dfg.sort_index(level="current time", inplace=True)

    def add_const_flows(self):
        for key, value in self.MFC_dict.items():
            if isinstance(value, float) or isinstance(value, int):
                self.df_all[key] = float(value)
                self.dfg[key] = float(value)
                self.dfg[f"{key}set"] = float(value)

                self.dfg_runs[(key, "nanmean")] = float(value)
                self.dfg_runs[(key, "nanstd")] = 0.0
                self.dfg_runs[(key, "nanmin")] = float(value)
                self.dfg_runs[(key, "nanmax")] = float(value)

                self.dfg_steps[(key, "nanmean")] = float(value)
                self.dfg_steps[(key, "nanstd")] = 0.0
                self.dfg_steps[(key, "nanmin")] = float(value)
                self.dfg_steps[(key, "nanmax")] = float(value)

                ###########NEW
                self.df_flow[(key, "nanmean")] = float(value)
                self.df_flow[(key, "nanstd")] = 0.0
                self.df_flow[(key, "nanmin")] = float(value)
                self.df_flow[(key, "nanmax")] = float(value)

    def collect_relevant_flows(
        self, step_dict: Optional[dict] = None, run_num: Optional[int] = None
    ):
        if run_num is not None:
            run_num_list = [run_num]
        else:
            run_num_list = list(range(len(self.dfg_runs)))

        if self.reprocess == True:
            for run_num in run_num_list:
                flow_dict = {}
                run_index = self.dfg_runs.index[run_num]
                flow_dict[("run_index", "run_num")] = run_index
                # populate flows
                for flow_name, values in flow_step_dict.items():
                    step_name = values[1]
                    if step_name in step_dict:
                        step_num_list = [step_dict[step_name]]
                    else:
                        step_num_list = values[0]
                    flow_dict.update(
                        self.get_flow_values(
                            flow_name,
                            run_index,
                            step_num_list=step_num_list,
                        )
                    )
                flow_dict.update(
                    {
                        ("datetime", "nanmean"): self.dfg_runs.loc[run_num]["datetime"][
                            "nanmean"
                        ],
                        ("datetime", "nanmin"): self.dfg_runs.loc[run_num]["datetime"][
                            "nanmin"
                        ],
                        ("datetime", "nanmax"): self.dfg_runs.loc[run_num]["datetime"][
                            "nanmax"
                        ],
                    }
                )
                self.flow_dict_list.append(flow_dict)

    def compile_relevant_flows(self):
        self.df_flow = pd.DataFrame(self.flow_dict_list)
        self.df_flow.columns = pd.MultiIndex.from_tuples(self.df_flow.columns)
        self.df_flow.set_index(("run_index", "run_num"), inplace=True)
        self.df_flow.index.rename("run", inplace=True)

    def get_flow_values(
        self, flow_name: str, run_index, step_num_list: Optional[list] = []
    ) -> dict:
        flow_dict = {}
        dfg_runs = self.dfg_runs.iloc[run_index]
        dfg_steps = self.dfg_steps.loc[
            self.dfg_steps.index.get_level_values(level="run_count") == run_index
        ]
        if len(step_num_list) > 0 and flow_name in self.dfg_steps:
            step_ind = np.zeros(len(dfg_steps)).astype(bool)
            for step_num in step_num_list:
                step_ind |= (
                    dfg_steps.index.get_level_values(level="step_num") == step_num
                )
            if len(step_num_list) > 1:
                (weighted_ave, weighted_std) = weighted_ave_std(
                    dfg_steps.loc[step_ind], flow_name
                )
                if flow_name in dfg_steps:
                    try:
                        flow_dict = {
                            (flow_name, "nanmean"): weighted_ave.to_numpy()[0],
                            (flow_name, "nanstd"): weighted_std.to_numpy()[0],
                        }
                    except:
                        flow_dict = {
                            (flow_name, "nanmean"): weighted_ave[0],
                            (flow_name, "nanstd"): weighted_std[0],
                        }
            else:
                try:
                    flow_dict = {
                        (flow_name, "nanmean"): dfg_steps.loc[step_ind][
                            (flow_name, "nanmean")
                        ].to_numpy()[0],
                        (flow_name, "nanstd"): dfg_steps.loc[step_ind][
                            (flow_name, "nanstd")
                        ].to_numpy()[0],
                    }
                except:
                    flow_dict = {
                        (flow_name, "nanmean"): dfg_steps.loc[step_ind][
                            (flow_name, "nanmean")
                        ][0],
                        (flow_name, "nanstd"): dfg_steps.loc[step_ind][
                            (flow_name, "nanstd")
                        ][0],
                    }
        elif flow_name in dfg_runs:
            try:
                flow_dict = {
                    (flow_name, "nanmean"): dfg_runs[(flow_name, "nanmean")].to_numpy()[
                        0
                    ],
                    (flow_name, "nanstd"): dfg_runs[(flow_name, "nanstd")].to_numpy()[
                        0
                    ],
                }
            except:
                flow_dict = {
                    (flow_name, "nanmean"): dfg_runs[(flow_name, "nanmean")][0],
                    (flow_name, "nanstd"): dfg_runs[(flow_name, "nanstd")][0],
                }
        elif flow_name in self.df_MFCs:
            flow_dict = {
                (flow_name, "nanmean"): self.df_MFCs[flow_name][0],
                (flow_name, "nanstd"): self.df_MFCs[f"{flow_name}_error"][0],
            }

        return flow_dict

    def collect_relevant_flows_by_state(self, run_num: Optional[int] = None):
        if run_num is not None:
            run_num_list = [run_num]
        else:
            run_num_list = list(range(len(self.dfg_runs)))

        if self.reprocess == True:
            for run_num in run_num_list:
                flow_dict = {}
                run_index = self.dfg_runs.index[run_num]
                flow_dict[("run_index", "run_num")] = run_index
                # populate flows
                for flow_name, state in flow_state_dict.items():
                    flow_dict.update(
                        self.get_flow_values_by_state(
                            flow_name,
                            run_index,
                            state=state,
                        )
                    )
                flow_dict.update(
                    {
                        ("datetime", "nanmean"): self.dfg_runs.loc[run_num]["datetime"][
                            "nanmean"
                        ],
                        ("datetime", "nanmin"): self.dfg_runs.loc[run_num]["datetime"][
                            "nanmin"
                        ],
                        ("datetime", "nanmax"): self.dfg_runs.loc[run_num]["datetime"][
                            "nanmax"
                        ],
                    }
                )
                self.flow_dict_list.append(flow_dict)

    def get_flow_values_by_state(self, flow_name: str, run_index, state=None) -> dict:
        flow_dict = {}
        dfg_runs = self.dfg_runs.iloc[run_index]
        dfg_steps = self.dfg_steps.loc[
            self.dfg_steps.index.get_level_values(level="run_count") == run_index
        ]
        if state is not None and flow_name in self.dfg_steps:
            if state == "desorb_flag":
                state_ind = dfg_steps[("desorb_flag", "nanmean")].astype(bool)
            else:
                state_ind = (
                    dfg_steps.index.get_level_values(level="current_state") == state
                )

            flow_dict = {
                (flow_name, "nanmean"): get_first(
                    dfg_steps.loc[state_ind][(flow_name, "nanmean")]
                ),
                (flow_name, "nanstd"): get_first(
                    dfg_steps.loc[state_ind][(flow_name, "nanstd")]
                ),
            }
        elif flow_name in dfg_runs:
            flow_dict = {
                (flow_name, "nanmean"): get_first(dfg_runs[(flow_name, "nanmean")]),
                (flow_name, "nanstd"): get_first(dfg_runs[(flow_name, "nanstd")]),
            }
        elif flow_name in self.df_MFCs:
            flow_dict = {
                (flow_name, "nanmean"): get_first(self.df_MFCs[flow_name]),
                (flow_name, "nanstd"): get_first(self.df_MFCs[f"{flow_name}_error"]),
            }

        return flow_dict

    def get_sequence_data(
        self, sequence_series
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        start_datetime = sequence_series.name
        end_datetime = sequence_series["end_datetime"]
        sequence_df = pd.DataFrame(sequence_series)

        end_datetime_list = list(self.dfg_runs["datetime"]["nanmax"])

        extra_data = pd.DataFrame(index=[sequence_series._name])
        # what else is needed in extra? Currently only flows
        extra_data["error_flag"] = 0

        if len(self.dfg_runs) > 1:
            ind_2_use = np.where(
                (self.dfg_runs.loc[:, ("datetime", "nanmean")] >= start_datetime)
                & (self.dfg_runs.loc[:, ("datetime", "nanmean")] <= end_datetime)
            )[0]

            for key, value in self.df_flow.items():
                if key[1] == "nanmean":
                    extra_data[key[0]] = deepcopy(value.iloc[ind_2_use])

            df_flow_out = deepcopy(self.df_flow.iloc[ind_2_use])

            ind_2_use_dfg = np.where(
                (
                    self.dfg.index.get_level_values(level="current time")
                    >= start_datetime
                )
                & (
                    self.dfg.index.get_level_values(level="current time")
                    <= end_datetime
                )
            )[0]
            dfg_out = deepcopy(self.dfg.iloc[ind_2_use_dfg])
        else:
            for key, value in self.df_flow.items():
                extra_data[key] = deepcopy(value)

            df_flow_out = deepcopy(self.df_flow)
            dfg_out = deepcopy(self.dfg)

        (_, _, approximate_trap_start_delta, _) = calculate_trap_times(sequence_series)

        for end_datetime in end_datetime_list:
            # if ~np.isnan(end_datetime):
            if isinstance(end_datetime, datetime):
                if (
                    end_datetime > start_datetime - approximate_trap_start_delta
                    and end_datetime < start_datetime
                ):
                    extra_data.iloc["error_flag"] = 1
        sequence_out = pd.concat((sequence_df, extra_data.T)).T

        return sequence_out, df_flow_out, dfg_out


def get_first(df_series):
    try:
        return df_series.to_numpy()[0]
    except:
        return df_series[0]


def parse_and_save_flows_for_sequences(
    sequence_series,
    ind,
    MFC_dict: dict,
    timezone,
    output_path: Path,
    flow_path: Optional[Path] = None,
    verbose: Optional[bool] = False,
    reprocess: Optional[bool] = True,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    df_flow, df_all, dfg_runs, dfg_steps = parse_and_save_flows(
        MFC_dict, timezone, flow_path, verbose=verbose
    )

    new_ind = pd.MultiIndex.from_tuples(
        (("datetime", "nanmean"), ("datetime", "nanmax"), ("datetime", "nanmin"))
    )
    dfg_runs[new_ind] = None
    dfg_runs.loc[:, ("datetime", "nanmean")] = timestamp_to_dateTime(
        dfg_runs["current time"]["nanmean"], timezone
    )
    dfg_runs.loc[:, ("datetime", "nanmax")] = timestamp_to_dateTime(
        dfg_runs["current time"]["nanmax"], timezone
    )
    dfg_runs.loc[:, ("datetime", "nanmin")] = timestamp_to_dateTime(
        dfg_runs["current time"]["nanmin"], timezone
    )

    end_datetime_list = list(dfg_runs["datetime"]["nanmax"])

    extra_data = pd.DataFrame()
    extra_data["error_flag"] = 0

    fname = f"{ind.strftime('%Y%m%d_%H%M%S')}_sequence_flow_times.pkl"
    fout = os.path.join(output_path, fname)

    if reprocess == True or os.path.isfile(fout) != True:
        if len(dfg_runs) > 1:
            ind_2_use = (dfg_runs.loc[:, ("datetime", "nanmean")] >= ind) & (
                dfg_runs.loc[:, ("datetime", "nanmean")]
                <= sequence_series["end_datetime"]
            )

            for key, value in dfg_runs.items():
                if key[1] == "nanmean":
                    extra_data[key] = value[ind_2_use]
        elif len(df_flow) > 1:
            ind_2_use = np.intersect1d(
                np.where(df_flow.index >= ind),
                np.where(df_flow.index <= sequence_series["end_datetime"]),
            )

            for key, value in df_flow.items():
                extra_data[key] = value[ind_2_use]

        else:
            for key, value in df_flow.items():
                extra_data[key] = value

        (_, _, approximate_trap_start_delta, _) = calculate_trap_times(
            sequence_series  # , ind
        )

        for end_datetime in end_datetime_list:
            if end_datetime > ind - approximate_trap_start_delta and end_datetime < ind:
                extra_data["error_flag"] = 1

        data_out = pd.concat((sequence_series, extra_data.T))
        data_out = data_out.rename(columns={0: ind}).T

    return df_flow, data_out, df_all, dfg_runs, dfg_steps


def parse_and_save_flows(
    MFC_dict: dict, timezone, flow_path: Path, verbose: Optional[bool] = False
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    df_all = None
    dfg_runs = None
    dfg_steps = None

    if flow_path is not None:
        for key, value in MFC_log_defaults.items():
            if key not in MFC_dict:
                MFC_dict[key] = value

        # dataframes for all the flow data
        df_all = parse_flow_log(MFC_dict, timezone, flow_path)

        dfg_runs = df_all.groupby("run_count").agg(
            [np.nanmean, np.nanstd, np.nanmin, np.nanmax]
        )
        dfg_steps = df_all.groupby(["run_count", "step_num"]).agg(
            [np.nanmean, np.nanstd, np.nanmin, np.nanmax]
        )

    for key, value in MFC_defaults.items():
        if key not in MFC_dict:
            MFC_dict[key] = value

    MFC_errors = {}
    for key in MFC_dict:
        MFC_errors[f"{key}_error"] = 0.0

    df_flow = pd.concat((pd.DataFrame([MFC_dict]), pd.DataFrame([MFC_errors])), axis=1)

    return df_flow, df_all, dfg_runs, dfg_steps


def parse_flow_log(MFC_dict: dict, timezone, flow_path: Path) -> pd.DataFrame:
    df_list = []
    log_name_list = glob.glob(os.path.join(flow_path, "*log.txt"))
    log_name_list.sort()

    run_count = 0
    #%% Parse data saved by the Python logger controlling flow
    for log_name in log_name_list:
        df = pd.read_csv(log_name, sep=",")

        for key in df.keys():
            if key[0] == " ":
                df.rename(columns={key: key[1:]}, inplace=True)

        # df.index = pd.to_datetime(df["current time"], unit="s")
        # tz = pytz.timezone(timezone)
        df.index = timestamp_to_dateTimeIndex(df["current time"], timezone)

        for new_name, initial_MFC in MFC_dict.items():
            df = rename_variables(df, f"{initial_MFC}_flow", new_name)

        if "run_count" not in df:
            df["run_count"] = None
        df["run_count"] = run_count
        run_count += 1

        df_list.append(df)  # add full dataset to a list

    df_all = pd.concat(df_list)
    return df_all  # , df_list


def calculate_precon_factor(
    peak_area: float, trap_ppm: float, peak_width_min: Optional[float] = 2.0
) -> float:
    return peak_area / trap_ppm / peak_width_min / 60.0


def calculate_desorb_conc(
    trap_ppm: float, trap_time_min: float, trap_flow: float, desorb_flow: float
) -> float:
    return trap_ppm * trap_time_min * 60.0 * trap_flow / desorb_flow


def calculate_input_concentration(
    df_fits: pd.DataFrame, df_flow_precon: pd.DataFrame
) -> pd.DataFrame:
    """
    using the flow_preconcentration_factor, calculate the input concentration
    """
    input_conc_ppb = pd.DataFrame(index=df_fits.index)
    for (compound_name, var_name) in df_fits.columns:
        if var_name == "cau_gaus_integral":
            integrated_signal_ppm_s = (
                df_fits[(compound_name, var_name)] / 1000.0
            )  # convert ppb*s to ppm*s
            input_conc_ppb[compound_name] = (
                integrated_signal_ppm_s
                * 1e3
                / df_flow_precon["flow_precon_factor"]
                / (df_flow_precon["desorb_time_min"] * 60.0)
            )  # ppm*s * (ppb/ppm) / (ppm/ppm) / (min*s/min)
    input_conc_ppb.replace(to_replace=np.inf, value=None, inplace=True)
    input_conc_ppb.replace(to_replace=-np.inf, value=None, inplace=True)
    return input_conc_ppb


def weighted_ave_std(df: pd.DataFrame, var_name: str) -> Tuple[float, float]:
    values = df[var_name]["nanmean"]
    if np.any(df[var_name]["nanstd"] != 0):
        weights = 1 / (df[var_name]["nanstd"] ** 2)
    else:
        weights = np.ones_like(values)
    weighted_ave = np.average(values, weights=weights)
    weighted_std = np.average((values - weighted_ave) ** 2, weights=weights)
    return (weighted_ave, weighted_std)


def calculate_TD_sample_dilution(df_flows: pd.DataFrame) -> dict:
    dilutions = {
        "factor_1": 1,  # direct
        "factor_2": 1,  # direct
        "factor_3": 1,  # overflow
    }
    df_flows = deepcopy(df_flows)

    # calculate the average flows during the trap step and the concentration during the trap step
    if (
        "nanmean" in df_flows["sample_flow"]
        and "nanmean" in df_flows["first_dilution_flow"]
    ):
        first_dilution = (
            df_flows["sample_flow"]["nanmean"].iloc[0]
            + df_flows["first_dilution_flow"]["nanmean"].iloc[0]
        )
        if first_dilution != 0:
            dilutions["factor_1"] = df_flows["sample_flow"]["nanmean"].iloc[0] / (
                df_flows["sample_flow"]["nanmean"].iloc[0]
                + df_flows["first_dilution_flow"]["nanmean"].iloc[0]
            )
        if "second_dilution_flow" in df_flows:
            second_dilution = (
                df_flows["sample_flow"]["nanmean"].iloc[0]
                + df_flows["first_dilution_flow"]["nanmean"].iloc[0]
                + df_flows["second_dilution_flow"]["nanmean"].iloc[0]
            )
            if second_dilution != 0:
                dilutions["factor_2"] = (
                    df_flows["sample_flow"]["nanmean"].iloc[0]
                    + df_flows["first_dilution_flow"]["nanmean"].iloc[0]
                ) / (
                    df_flows["sample_flow"]["nanmean"].iloc[0]
                    + df_flows["first_dilution_flow"]["nanmean"].iloc[0]
                    + df_flows["second_dilution_flow"]["nanmean"].iloc[0]
                )

        if "nanmean" in df_flows["overflow_dilution_flow"]:
            if df_flows["trap_flow"]["nanmean"].iloc[0] != 0:
                dilutions["factor_3"] = (
                    df_flows["trap_flow"]["nanmean"].iloc[0]
                    - df_flows["overflow_dilution_flow"]["nanmean"].iloc[0]
                ) / df_flows["trap_flow"]["nanmean"].iloc[0]

    return dilutions


def calculate_trap_conc(dilutions: dict, input_concs: dict) -> dict:
    trap_conc = {}
    for var_name, value in input_concs.items():
        if "ppm" in var_name:
            compound_name = "_".var_name.split("_")[:-1]
            trap_conc[f"{compound_name}_ppm"] = (
                value
                * dilutions["factor_1"]
                * dilutions["factor_2"]
                * dilutions["factor_3"]
            )
            trap_conc[f"{compound_name}_ppb"] = (
                value
                * dilutions["factor_1"]
                * dilutions["factor_2"]
                * dilutions["factor_3"]
                * 1000
            )
        elif "ppb" in var_name:
            compound_name = "_".var_name.split("_")[:-1]
            trap_conc[f"{compound_name}_ppm"] = (
                value
                * dilutions["factor_1"]
                * dilutions["factor_2"]
                * dilutions["factor_3"]
                / 1000
            )
            trap_conc[f"{compound_name}_ppb"] = (
                value
                * dilutions["factor_1"]
                * dilutions["factor_2"]
                * dilutions["factor_3"]
            )
        else:
            trap_conc[f"{var_name}_ppm"] = (
                value
                * dilutions["factor_1"]
                * dilutions["factor_2"]
                * dilutions["factor_3"]
            )
            trap_conc[f"{var_name}_ppb"] = (
                value
                * dilutions["factor_1"]
                * dilutions["factor_2"]
                * dilutions["factor_3"]
                * 1000
            )
    return trap_conc


def get_compound_list_from_trap_df(df_trap_conc: pd.DataFrame) -> list:
    compound_list = []
    for var_name in df_trap_conc:
        if "ppm" in var_name:
            compound_list.append("_".join(var_name.split("_")[:-1]))
    return compound_list


def calculate_flow_precon(df_flows: pd.DataFrame, precon_times, sequence) -> dict:
    df_flows = deepcopy(df_flows)
    desorb_time_min = precon_times.desorb_time_min

    if "sample_volume_mL" in sequence:
        sample_volume_mL = sequence["sample_volume_mL"].iloc[0]
        trap_time_min = sample_volume_mL / df_flows["trap_flow"]["nanmean"].iloc[0]
    elif "trap_time" in sequence:
        trap_time_min = sequence["trap_time"].iloc[0]
        sample_volume_mL = trap_time_min * df_flows["trap_flow"]["nanmean"].iloc[0]
    elif "trap_time_min" in precon_times:
        trap_time_min = precon_times.trap_time_min
        sample_volume_mL = trap_time_min * df_flows["trap_flow"]["nanmean"].iloc[0]
    else:
        sample_volume_mL = np.nan

    flow_precon_factor = (
        sample_volume_mL
        / df_flows["instrument_flow"]["nanmean"].iloc[0]
        / desorb_time_min
    )

    if df_flows["trap_flow"]["nanmean"].iloc[0] != 0.0:
        trap_flow_rsd = (
            df_flows["trap_flow"]["nanstd"].iloc[0]
            / df_flows["trap_flow"]["nanmean"].iloc[0]
        )
    else:
        trap_flow_rsd = np.nan
    if df_flows["instrument_flow"]["nanmean"].iloc[0] != 0.0:
        desorb_flow_rsd = (
            df_flows["instrument_flow"]["nanstd"].iloc[0]
            / df_flows["instrument_flow"]["nanmean"].iloc[0]
        )
    else:
        desorb_flow_rsd = np.nan
    flow_precon_factor_rsd = np.sqrt(trap_flow_rsd**2 + desorb_flow_rsd**2)
    flow_precon_factor_error = flow_precon_factor_rsd * flow_precon_factor

    dict_out = {
        "flow_precon_factor": flow_precon_factor,
        "flow_precon_factor_error": flow_precon_factor_error,
        "trap_time_min": trap_time_min,
        "desorb_time_min": desorb_time_min,
    }

    return dict_out
