import numpy as np
import pandas as pd
from copy import deepcopy
from typing import Optional

from spectral_toolkit.TD_analysis.TD_utilities.time_conversions import (
    dateTimeIndex_to_s,
)
from spectral_toolkit.TD_analysis.TD_utilities.defaults_dict import voc_list, name_dict
from spectral_toolkit.TD_analysis.TD_utilities.utilities_for_timeseries_TD import (
    get_all_data,
    find_name,
    good_times,
)

from spectral_toolkit.TD_analysis.TD_utilities.peak_model import optimize_fit_data
from spectral_toolkit.TD_analysis.TD_utilities.utilities_TD import (
    calculate_precon_factor,
    calculate_desorb_conc,
)
from spectral_toolkit.TD_analysis.data_models_TD.output_models import (
    PeakFitSchema,
)


def parse_variable_names(df: pd.DataFrame, vars_2_reject: Optional[list] = []):
    fit_names = []
    for key, value in voc_list.items():
        new_name, _ = find_name(value, df, verbose=False)
        if value in df:
            fit_names.append(value)
        elif new_name in df:
            fit_names.append(new_name)

    for key, value in name_dict["new"].items():
        new_name, _ = find_name(key, df, verbose=False)
        if key in df and key not in fit_names:
            fit_names.append(key)
        elif new_name in df and new_name not in fit_names:
            fit_names.append(new_name)

    other_names = [
        "CO2",
        "CH4",
        "H2O",
        "broadband_simple_sum",
        "CO2_VOC",
        "CH4_VOC",
        "H2O_VOC",
    ]
    for var_name in other_names:
        new_name, _ = find_name(var_name, df, verbose=False)
        if var_name in df:
            fit_names.append(var_name)
        elif new_name in df:
            fit_names.append(new_name)

    small_fit_names = list()
    complex_fit_names = list()
    for var_name in fit_names:
        short_var_name = var_name.replace("_ppm", "")
        if short_var_name not in vars_2_reject:
            if (
                var_name == "CO2"
                or var_name == "CH4"
                or var_name == "H2O"
                or var_name == "nh3_ppm"
                or var_name == "nh3_ppb"
                or var_name == "CO2_VOC"
                or var_name == "CH4_VOC"
                or var_name == "H2O_VOC"
            ):
                small_fit_names.append(var_name)
            elif (
                "co2" not in var_name
                and "ch4" not in var_name
                and "962" not in var_name
                and "280" not in var_name
                and "297" not in var_name
            ):
                complex_fit_names.append(var_name)
    complex_fit_names.sort()
    small_fit_names.sort()

    return fit_names, complex_fit_names, small_fit_names


def convert_fits_list(
    fits_list: list,
    var_name: str,
    hold: Optional[bool] = False,
    fits_dict: Optional[dict] = {},
):
    """
    convert fits_list to inputs for the fitting function

    fits_list
    #parameters for peak fitting. must have the same string name as in the ica_model.
    # i.e. acetic_acid, octene, toluene, benzene, H2O, CO2, acetophenone, ammonia, CH4
    #     -variable_name: 'ACETONE'
    #           center: #center, sigma_left, sigma_right, f_left, f_right
    #                 set or hold: float #optional values to set and then fit or hold this parameter
    #                 min: float #optional minimum allowed value for this parameter
    #                 max: float #optional maximum allowed value for this parameter
    """
    rerun = False
    for var_entry in fits_list:
        # compound in fit list
        fits_var_name = var_entry.variable_name
        if fits_var_name == var_name:
            # find the list element that corresponds to var_name
            for param_name, param_dict in var_entry.dict().items():
                # cycle through each variable (cen, sigma, etc.)
                if param_name != "variable_name" and param_dict is not None:
                    fits_dict[param_name] = {}
                    for param_var_name, value in param_dict.items():
                        # cycle through each parameter (set, hold, min, max)
                        if (
                            param_var_name == "set"
                            and hold
                            and ("cen" in param_name or "sigma" in param_name)
                        ):
                            # for cen or sigmas update set values to hold values
                            rerun = True
                            if value is not None:
                                fits_dict[param_name]["hold"] = float(value)
                                if "set" in fits_dict[param_name]:
                                    del fits_dict[param_name]["set"]
                        elif value is not None:
                            fits_dict[param_name][param_var_name] = float(value)

    return fits_dict, rerun


def convert_interp_list(
    interp_list: list, var_name: str, fits_dict: Optional[dict] = {}
):
    """
    convert fits_list to inputs for the fitting function

    fits_list
        parameters for peak fitting. must have the same string name as in the ica_model.
        i.e. acetic_acid, octene, toluene, benzene, H2O, CO2, acetophenone, ammonia, CH4
            -variable_name: 'ACETONE'
                center: #center, sigma_left, sigma_right, f_left, f_right
    """
    rerun = True
    if interp_list is not None:
        for var_entry in interp_list:
            fits_var_name = var_entry.variable_name
            if fits_var_name == var_name:
                for param_name, value in var_entry.dict().items():
                    if param_name != "variable_name":
                        fits_dict[param_name] = {}
                        if value is not None:
                            fits_dict[param_name]["hold"] = float(value)
                        if "set" in fits_dict[param_name]:
                            del fits_dict[param_name]["set"]

        return fits_dict, rerun
    else:
        return {}, rerun


def fit_sources(
    df: pd.DataFrame, start_dt, interp_list: list, fits_list: list, tz=None
):
    """
    fit each source to one gaussian peak with allowed zero offset

    INPUT

    **kwargs

    fits_list
    #parameters for peak fitting. must have the same string name as in the ica_model.
    # i.e. acetic_acid, octene, toluene, benzene, H2O, CO2, acetophenone, ammonia, CH4
    #     -variable_name: 'ACETONE'
    #           center: #center, sigma_left, sigma_right, f_left, f_right
    #                 set or hold: float #optional values to set and then fit or hold this parameter
    #                 min: float #optional minimum allowed value for this parameter
    #                 max: float #optional maximum allowed value for this parameter

    interp_list
    #parameters for peak fitting. must have the same string name as in the ica_model or fit.
    """
    # get a list of possible compounds to fit from default lists
    _, complex_fit_names, small_fit_names = parse_variable_names(
        df,
    )

    # get time data
    time_dt = df.index
    time_now = dateTimeIndex_to_s(time_dt - start_dt)

    peak_fit = {}
    gaus_result_dict = {}
    cau_gaus_result_dict = {}

    var_name_list_gaus = [
        "integral",
        "amp",
        "cen",
        "sigma",
        "height",
        "offset",
        "offset_slope",
    ]

    var_name_list_cau_gaus = [
        "integral",
        "amp",
        "cen",
        "sigma_left",
        "sigma_right",
        "f_left",
        "f_right",
        "height",
        "offset",
        "offset_slope",
    ]

    for j in range(2):
        if j == 0:
            fit_names_now = complex_fit_names
        elif j == 1:
            fit_names_now = small_fit_names

        for i, var_name in enumerate(fit_names_now):
            pf_dict = {}
            ind_2_use = np.where(get_all_data(var_name, df).notna())[0]

            signal_now = get_all_data(var_name, df).to_numpy(dtype=float)
            if "gasConcs" in var_name:
                signal_now *= 1e9  # convert from parts to ppb for broadband_gasConcs

            # convert fits_dict to inputs for the fitting function
            fits_dict, _ = convert_fits_list(fits_list, var_name, hold=False)
            print(f"fitting {var_name}")
            (
                gaus_result,
                cau_gaus_result,
                gaus_fit_int,
                cau_gaus_fit_int,
                gaus_int,
                _,
            ) = optimize_fit_data(
                time_now[ind_2_use],
                signal_now[ind_2_use],
                model_name="cauchy_gaussian",
                fits_dict=fits_dict,
                # **kwarg_fit
            )
            pf_dict["integral"] = gaus_int
            pf_dict["bad_fit"] = False

            gaus_height = (
                gaus_result.best_values["amp"]
                / np.sqrt(2 * np.pi)
                / gaus_result.best_values["sigma"]
            )
            if (
                gaus_height
                < np.nanstd(gaus_result.residual) * 3  # np.nanstd(signal_now) * 3
            ):  # reject fits smaller than the error of the measurement
                pf_dict["bad_fit"] = True
                fits_dict, rerun = convert_fits_list(
                    fits_list, var_name, hold=True, fits_dict=fits_dict
                )
                # set to interp_dict values instead where available
                fits_dict, _ = convert_interp_list(
                    interp_list, var_name, fits_dict=fits_dict
                )

                if rerun:
                    (
                        gaus_result,
                        cau_gaus_result,
                        gaus_fit_int,
                        cau_gaus_fit_int,
                        gaus_int,
                        _,
                    ) = optimize_fit_data(
                        time_now,
                        signal_now,
                        model_name="cauchy_gaussian",
                        fits_dict=fits_dict,
                    )

            # var_name_list_gaus = ['integral','amp','cen','sigma','height','offset','offset_slope']
            for fit_var_name in var_name_list_gaus:
                if fit_var_name == "integral":
                    pf_dict[f"gaus_{fit_var_name}"] = gaus_fit_int
                elif fit_var_name == "height":
                    pf_dict[f"gaus_{fit_var_name}"] = gaus_height
                else:
                    pf_dict[f"gaus_{fit_var_name}"] = gaus_result.best_values[
                        fit_var_name
                    ]
            # var_name_list_cau_gaus = ['integral','amp','cen','sigma_left','sigma_right', 'f_left','f_right','height','offset','offset_slope']
            for fit_var_name in var_name_list_cau_gaus:
                if fit_var_name == "integral":
                    pf_dict[f"cau_gaus_{fit_var_name}"] = cau_gaus_fit_int
                elif fit_var_name == "height":
                    pf_dict[f"cau_gaus_{fit_var_name}"] = cau_gaus_result.best_values[
                        "amp"
                    ]
                else:
                    pf_dict[f"cau_gaus_{fit_var_name}"] = cau_gaus_result.best_values[
                        fit_var_name
                    ]

            peak_fit[var_name] = PeakFitSchema(**pf_dict)
            gaus_result_dict[var_name] = gaus_result
            cau_gaus_result_dict[var_name] = cau_gaus_result

    return peak_fit, gaus_result_dict, cau_gaus_result_dict


def integrate_trap(
    df: pd.DataFrame, start_dt, end_dt, tz=None, verbose: Optional[bool] = False
):
    """
    integrate signal for a given run

    """
    time_s = get_all_data("index", df) / 1000.0
    good = good_times(df, start_dt=start_dt, end_dt=end_dt, tz=tz)

    trap_data = {}
    for var_name in df:
        if var_name != "spec_gen_file":
            # individual dts
            dx_median = np.median(np.diff(time_s))
            dx = np.diff(time_s)
            bin_edges = np.insert(time_s[:-1] + dx / 2, 0, time_s[0] - dx_median / 2)
            bin_edges = np.insert(bin_edges, -1, time_s[-1] + dx_median / 2)
            dx = np.diff(bin_edges)
            integral = np.nansum(
                get_all_data(var_name, df)[good] * dx[good]
            )  # integral in ppb*s

            trap_data[f"{var_name}_integral"] = integral / 1000.0  # convert to ppm*s

            if verbose:
                print(f"{var_name} trap integral: {integral:1.2e} ppm*s")
    return trap_data


def set_blank(df_flow_precon: pd.DataFrame):
    trap_length = df_flow_precon["trap_time_min"].to_numpy()
    run_type_flag = trap_length > 0.5  # arbitrary 30 second threshold to indicate a run

    if ("instrument_flow", "nanstd") in df_flow_precon:
        flow_over = deepcopy(df_flow_precon[("instrument_flow", "nanstd")])
    else:
        flow_over = pd.DataFrame(
            np.zeros(len(df_flow_precon)) * np.nan, index=df_flow_precon.index
        )
    flow_over[flow_over.isna()] = 2

    if ("overflow_dilution_flow", "nanmean") in df_flow_precon and (
        "instrument_flow",
        "nanmean",
    ) in df_flow_precon:
        run_type_flag |= (
            df_flow_precon[("overflow_dilution_flow", "nanmean")]
            > df_flow_precon[("instrument_flow", "nanmean")] + 3 * flow_over
        )
    elif (
        "overflow_dilution_flow",
        "nanmean",
    ) in df_flow_precon and "instrument_flow" in df_flow_precon:
        run_type_flag |= (
            df_flow_precon[("overflow_dilution_flow", "nanmean")]
            > df_flow_precon["instrument_flow"] + 3 * flow_over
        )
    elif (
        "instrument_flow",
        "nanmean",
    ) in df_flow_precon and "overflow_dilution_flow" in df_flow_precon:
        run_type_flag |= (
            df_flow_precon["overflow_dilution_flow"]
            > df_flow_precon[("instrument_flow", "nanmean")] + 3 * flow_over
        )
    elif (
        "overflow_dilution_flow" in df_flow_precon
        and "instrument_flow" in df_flow_precon
    ):
        run_type_flag |= (
            df_flow_precon["overflow_dilution_flow"]
            > df_flow_precon["instrument_flow"] + 3 * flow_over
        )

    return run_type_flag


def compile_conc_precon(
    df_fits: pd.DataFrame, df_flow_precon: pd.DataFrame, df_trap_conc: pd.DataFrame
):
    df_conc_precon = pd.DataFrame(index=df_fits.index)
    for var_name in df_trap_conc:
        if "ppm" in var_name:
            compound_name = "_".join(var_name.split("_")[:-1])
            df_conc_precon[(compound_name, "cau_gaus_area_precon_factor")] = None
            df_conc_precon[(compound_name, "desorb_prediction_ppm_s")] = None

            for ind in df_fits.index:
                if ("instrument_flow", "mean") in df_flow_precon.columns:
                    desorb_flow = df_flow_precon.loc[ind, ("instrument_flow", "mean")]
                if ("instrument_flow", "nanmean") in df_flow_precon.columns:
                    desorb_flow = df_flow_precon.loc[
                        ind, ("instrument_flow", "nanmean")
                    ]
                elif "instrument_flow" in df_flow_precon:
                    desorb_flow = df_flow_precon.loc[ind, "instrument_flow"]
                else:
                    desorb_flow = np.nan

                trap_time_min = df_flow_precon.loc[ind, "trap_time_min"]

                if ("trap_flow", "mean") in df_flow_precon:
                    trap_flow = df_flow_precon.loc[ind, ("trap_flow", "mean")]
                elif ("trap_flow", "nanmean") in df_flow_precon:
                    trap_flow = df_flow_precon.loc[ind, ("trap_flow", "nanmean")]
                elif "trap_flow" in df_flow_precon:
                    trap_flow = df_flow_precon.loc[ind, "trap_flow"]
                else:
                    trap_flow = np.nan

                if ~np.isnan(desorb_flow):
                    df_conc_precon.loc[
                        ind, (compound_name, "cau_gaus_area_precon_factor")
                    ] = calculate_precon_factor(
                        df_fits.loc[ind, (compound_name, "cau_gaus_integral")] / 1000.0,
                        df_trap_conc.loc[ind, var_name],
                    )  # convert peak fit from ppb*s to ppm*s
                    df_conc_precon.loc[
                        ind, (compound_name, "desorb_prediction_ppm_s")
                    ] = calculate_desorb_conc(
                        df_trap_conc.loc[ind, var_name],
                        trap_time_min,
                        trap_flow,
                        desorb_flow,
                    )
    return df_conc_precon


def populate_normalization(
    df_fits: pd.DataFrame, df_trap_int: pd.DataFrame, df_conc_precon: pd.DataFrame
):
    """
    calculate normalized concentrations
    """
    normalized_data = pd.DataFrame(index=df_fits.index)
    for var_name in df_trap_int:
        if "integral" in var_name:
            compound_name = "_".join(var_name.split("_")[:-1])
            if (compound_name, "desorb_prediction_ppm_s") in df_conc_precon:
                integrated_breakthrough = df_trap_int[var_name]
                desorb_ppm_s = df_conc_precon[
                    (compound_name, "desorb_prediction_ppm_s")
                ]
                cau_gaus_area = (
                    df_fits[(compound_name, "cau_gaus_integral")] / 1000.0
                )  # convert fit value from ppb*s to ppm*s
                gaus_area = (
                    df_fits[(compound_name, "gaus_integral")] / 1000.0
                )  # convert fit value from ppb*s to ppm*s
                int_area = (
                    df_fits[(compound_name, "integral")] / 1000.0
                )  # convert fit value from ppb*s to ppm*s

                normalized_data[(compound_name, "integrated_breakthrough_pct")] = (
                    integrated_breakthrough * 100 / desorb_ppm_s
                ).to_numpy()
                normalized_data[(compound_name, "cau_gaus_conc_area_pct")] = (
                    cau_gaus_area * 100 / desorb_ppm_s
                ).to_numpy()
                normalized_data[(compound_name, "gaus_conc_area_pct")] = (
                    gaus_area * 100 / desorb_ppm_s
                ).to_numpy()
                normalized_data[(compound_name, "integral_pct")] = (
                    int_area * 100 / desorb_ppm_s
                ).to_numpy()
    normalized_data.replace(to_replace=np.nan, value=None, inplace=True)

    return normalized_data
