from typing import Optional


def progress_bar(progress, total, scale: Optional[int] = 1):
    percent = 100 * (progress / float(total))
    bar = "█" * int(percent / scale) + "-" * (int(100 / scale) - int(percent / scale))
    if progress >= total - 1:
        bar = "█" * int(100 / scale)
        print(f"\r|{bar}| 100.00%")
    else:
        print(f"\r|{bar}| {percent: .2f}%", end="\r")
