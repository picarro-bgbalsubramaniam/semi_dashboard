from copy import deepcopy
import os
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Optional

# import semidataprocessing.datautilities3.RellaColor as RC

from spectral_toolkit.TD_analysis.TD_utilities.utilities_for_timeseries_TD import (
    good_times,
    get_all_data,
)
from spectral_toolkit.TD_analysis.data_models_TD.output_models import FomSpectralData

import plotly.graph_objects as go
from plotly.subplots import make_subplots

MATH = r"${%s}$"
wavenumbers = r"frequency " + MATH % r"[cm^{-1}]"


def save_fig(F, fname, figure_dir):
    F.write_image(os.path.join(figure_dir, f"{fname}.png"))
    # F.write_json(os.path.join(figure_dir, f"{fname}.json"))
    F.write_html(os.path.join(figure_dir, f"{fname}.html"))


def plot_variable(
    x_name: str,
    y_name: str,
    df: pd.DataFrame,
    prefix: str,
    figure_dir: Path,
    df_mean: Optional[pd.DataFrame] = None,
    label_ave: Optional[bool] = False,
    scatter: Optional[bool] = False,
    var_lims: Optional[dict] = {},
    start_date_time: Optional[str] = None,
    end_date_time: Optional[str] = None,
    save_figure: Optional[bool] = True,
):
    """Create plotly figure of scatter or line plot {x_name} by {y_name}.

    Parameters:
        x_name: str
            variable name for the independent variable
        y_name: str
            variable name for the dependent variable
        df: pd.DataFrame
            dataframe containing the data to be plotted

        prefix: str

        figure_dir: Path

        df_mean: optional pd.DataFrame, default None
            dataframe containing averaged data with the variables {x_name} and {y_name}
        label_ave: optional boolean, default False
            boolean indicating if the traces should be labeled with mean+-std
        scatter: optional boolean, default False
            boolean indicating if the plot should be scatter with markers only
        var_lims: optional dictionary, default {}
            dictionary containing limits for the y axis range
            var_lims[y_name]['min']: minimum
            var_lims[y_name]['max']: maximum
        start_date_time: optional str, default None
            start date time string with formatting YYYYMMDD_HHMMSS or YYYYMMDD_HHMM
        end_date_time: optional str, default None
            end date time string with formatting YYYYMMDD_HHMMSS or YYYYMMDD_HHMM
        extra_suffix: optional str, default None
            string to be appended to I.run_suffix in the file name

    Raises:

    Saves:
        plotly figure (.png, .json)
            flnm = "{prefix}_{x_name}_{y_name_appended}_ICA_timeseries".format(
                prefix=prefix, x_name=x_name, y_name_appended=y_name_appended
            )

    """
    good = good_times(df, start_date_time, end_date_time)

    data = get_all_data(y_name, df)[good]
    # plot the data.  You can use this interactive plot to select the time series you want in the step above
    # kolor = RC.CuteNordicKnit()
    F = go.Figure()

    if x_name == "index":
        x_val = df.index[good]
    else:
        x_val = get_all_data(x_name, df)[good]
    if not scatter:
        F.add_trace(
            go.Scatter(
                x=x_val,
                y=data,
                # marker_color=kolor.getNext(),
                line_width=1,
                name=f"{np.nanmean(data):0.4e} +- {np.nanstd(data):0.4e}",
            )
        )
    else:
        F.add_trace(
            go.Scatter(
                x=x_val,
                y=data,
                # marker_color=kolor.getNext()
            )
        )

    if df_mean is not None:
        good = good_times(df_mean, (start_date_time, end_date_time))
        if x_name == "index":
            x_val = df_mean.index[good]
        else:
            x_val = get_all_data(x_name, df_mean)[good]
        data = get_all_data(y_name, df_mean)[good]
        F.add_trace(
            go.Scatter(
                x=x_val,
                y=data,
                # marker_color=kolor.getNext(),
                line_width=1,
            )
        )

    y_name_appended = deepcopy(y_name)
    if y_name in var_lims:
        if "min" in var_lims[y_name]:
            F.update_yaxes(range_min=var_lims[y_name]["min"])
            y_name_appended += "_zoom"
        if "max" in var_lims[y_name]:
            F.update_yaxes(range_max=var_lims[y_name]["max"])
            if "zoom" not in y_name_appended:
                y_name_appended += "_zoom"
    F.update_layout(xaxis_title=x_name, yaxis_title=y_name)

    if save_figure:
        flnm = f"{prefix}_{x_name}_{y_name_appended}_timeseries"
        save_fig(F, flnm, figure_dir)
    else:
        return F, y_name_appended


def ICA_canary_function_plot(ica_results, prefix, figure_dir):
    """
    plot all of the unmixing matrices from the ICA analysis (pseudo model functions)
    """

    model_functions_dict = ica_results["model_functions"]

    sub_max = len(model_functions_dict)
    F = make_subplots(rows=sub_max, cols=1, shared_xaxes=True)
    F.update_layout(height=10.0 * 100, width=12.8 * 100)

    for i, (name, values) in enumerate(model_functions_dict.items()):
        F.add_trace(
            go.Scatter(x=ica_results["canary_names"], y=values, mode="markers"),
            row=i + 1,
            col=1,
        )
        F.update_yaxes(title_text=name, row=i + 1, col=1)
    F.update_xaxes(title_text="wavenumber", row=i + 1, col=1)

    flnm = f"{prefix}_canary_model_functions"
    save_fig(F, flnm, figure_dir)


def plot_spectrum(
    nu: np.array,
    loss: np.array,
    fit,
    figure_dir: Path,
    EXPT: str,
    std_res: Optional[float] = None,
    mf_rmse: Optional[float] = None,
    save_str: Optional[str] = None,
    cid_list: Optional[list] = [],
    title: Optional[str] = "",
):
    """Plot spectra with fit and model functions.

    Parameters:
        nu: np.array
        loss: np.array
        fit:
            Alist: list of model functions
            parameterNames: list of model function names
            result: fit values for the model functions
        figure_dir: Path
        EXPT: str
        std_res: optional float, default None
        mf_rmse: optional float, default None
        save_str: optional str, default None
        cid_list: optional list, default []
        title: optional str, default ""

    Raises:

    Saves:
        plotly figure (.png, .json)
            if save_str: fname = "%s_CID%s" % (EXPT, save_str)
            else: fname = EXPT
    """
    loss_integral = np.sum(loss)

    plots = []
    plots.append(((0, 2), (0, 1)))
    plots.append(((2, 3), (0, 1)))

    F = make_subplots(
        rows=3, cols=1, specs=[[{"rowspan": 2}], [None], [{}]], shared_xaxes=True
    )
    F.update_layout(height=10.0 * 100, width=12.8 * 100, title_text=title)

    # kol = RC.SeventiesFunk(brtValue=0.25)
    F.add_trace(
        go.Scatter(
            x=nu,
            y=loss,
            marker_size=5,
            marker_color="black",
            mode="markers",
            name="data",
        ),
        col=1,
        row=1,
    )
    F.add_trace(
        go.Scatter(
            x=nu,
            y=fit.fity,
            line_width=2,
            opacity=0.4,
            # marker_color=kol.getNext(),
            name="fit",
        ),
        col=1,
        row=1,
    )

    count = 0
    for mf, nm, val in zip(fit.Alist, fit.parameterNames, fit.result):
        mf_integral = np.sum(mf * val)
        if count <= len(cid_list) - 1:
            lw = 3
        else:
            lw = 0.7
        F.add_trace(
            go.Scatter(
                x=nu,
                y=mf * val,
                # marker_color=kol.getNext(),
                line_width=lw,
                name=(
                    f"{val:.2f} ppb, "
                    f"{100 * mf_integral / loss_integral:.2f} "
                    f"pct {nm}"
                ),
                textfont_size=8,
            ),
            row=1,
            col=1,
        )

        count += 1

    if std_res and mf_rmse:
        F.add_annotation(
            text=f"std. dev. res. = {std_res:.6f} | mf rmse = {mf_rmse:.6f}",
            font=dict(size=12, color="#4444ff"),
            xref="paper",
            yref="paper",
            x=0.03,
            y=0.03,
            showarrow=False,
        )
    F.add_trace(
        go.Scatter(x=nu, y=fit.residuals, marker_color="grey", name="residuals"),
        row=3,
        col=1,
    )

    F.update_xaxes(title_text=wavenumbers, row=1, col=1)
    F.update_yaxes(title_text="loss [wacky units]", row=1, col=1)
    F.update_xaxes(title_text=wavenumbers, row=3, col=1)
    F.update_yaxes(title_text="loss [wacky units]", row=3, col=1)
    if save_str:
        fname = f"{EXPT}_CID{save_str}"
    else:
        fname = EXPT
    save_fig(F, fname, figure_dir)

    return F


def plot_FOM_spectra(
    event_fit: FomSpectralData,
    fname_prefix: str,
    figure_dir: Path,
):
    """Plot FOM slopes against frequency.

    Parameters:
        FOM_name: str
        event_fit: FomSpectralData
            spectral_FOM: np.array
                1D array of FOM values in time (n)
            fit_df: pd.DataFrame
                dataframe containing spectral data (m, n)
            coef_df: pd.DataFrame
                index: numean
                slope: slope values for FOM vs spectra correlation (n)
                offset: offset values for FOM vs spectra correlation (n)
        fname_prefix: str
        figure_dir: Path
    Raises:

    Saves:
        plotly figures (.png, .json)
            fname = "%s_%s_%s_%s_%d_FOM_correlation" % (
                        start_date_time,
                        end_date_time,
                        FOM_name,
                        name,
                        i_figure,
                    )
            fname = "%s_%s_%s_%s_FOM_slope_spectra" % (
                        start_date_time,
                        end_date_time,
                        FOM_name,
                        name,
                    )

    """

    F = go.Figure()
    F.add_trace(go.Scatter(x=event_fit.coef_df.index, y=event_fit.coef_df["slope"]))
    F.update_layout(xaxis_title="nu mean")
    F.update_layout(yaxis_title="slope")
    fname = f"{fname_prefix}_FOM_slope_spectra"

    save_fig(F, fname, figure_dir)


def plot_normalized_signals(
    precision_dict: dict,
    df: pd.DataFrame,
    time_name: str,
    start_date_time: str,
    run_suffix: str,
    figure_dir: Path,
):
    """Plot normalized signals.

    Parameters:
        precision_dict: dict
        df: pd.DataFrame
        time_name: str
        start_date_time: str
        run_suffix: str
        figure_dir: Path

    Raises:

    Saves:
        plotly figure (.png, .json)
            fname = "%s_%s_normalized_series" % (start_date_time, run_suffix)
    """
    if precision_dict is not None:
        # kol2 = RC.PsychedelicChakra(brtValue=+0.15)
        F = go.Figure()
        if time_name == "index":
            time_now = df.index
        else:
            time_now = get_all_data(time_name, df)
        for var_name in precision_dict:
            try:
                name_now = f"normalized_{var_name}"
                data = get_all_data(name_now, df)
            except:
                try:
                    name_now = var_name
                    data = get_all_data(name_now, df)
                except:
                    break
            F.add_trace(
                go.Scatter(
                    x=time_now,
                    y=data,
                    # marker_color=kol2.getNext(),
                    name=name_now,
                )
            )
        F.add_hline(y=-1, line_color="grey", line_dash="dash")
        F.add_hline(y=-2, line_color="red", line_dash="dash")

        fname = f"{start_date_time}_{run_suffix}_normalized_series"
        save_fig(F, fname, figure_dir)


def plot_all(
    var_names: list,
    start_date_time: str,
    end_date_time: str,
    df: pd.DataFrame,
    time_name: str,
    run_suffix: str,
    figure_dir: Path,
):
    """Plot timeseries of all variables in var_names.

    Parameters:
        var_names: list
            list of variable names in df to be plotted
        start_date_time: str
            start date time string (YYYYMMDD_HHMMSS)
        end_date_time: str
            end date time string (YYYYMMDD_HHMMSS)
        df: pd.DataFrame
            dataframe containing timeseries data
        time_name: str
            name of the time variable saved in df
        run_suffix: str
        figure_dir: Path

    Raises:

    Saves:
        plotly figure (.png, .json)
            fname = "%s_%s_%s_%s_%s_timeseries" % (
                start_date_time,
                end_date_time,
                run_suffix,
                time_name,
                y_name_appended,
            )
    """
    prefix = f"{start_date_time}_{end_date_time}_{run_suffix}"
    for var_name in var_names:
        if var_name in df:
            F, y_name_appended = plot_variable(
                time_name,
                var_name,
                df,
                prefix,
                figure_dir,
                label_ave=True,
                save_figure=False,
            )
            fname = f"{prefix}_{time_name}_{y_name_appended}_timeseries"
            save_fig(F, fname, figure_dir)


def plot_found_peaks(
    time_vector: np.array,
    y_vector: np.array,
    peak_inds,
    peaks_left,
    peaks_right,
    time_name: str,
    y_name: str,
    prefix: str,
    figure_dir: Path,
):
    """Plot timeseries with identified peaks.

    Parameters:
        time_vector: np.array
            vector of time data
        y_vector: np.array
            vector of the dependent variable values
        peak_inds:
        peaks_left:
        peaks_right:
        time_name: str
            name of the time variable
        y_name: str
            name of the dependent variable
        prefix: str
        figure_dir: Path

    Raises:

    Saves:
        plotly figure (.png, .json)
            fname = "%s_%s_%s_found_peaks" % (prefix, time_name, y_name)
    """
    F = go.Figure()
    F.add_trace(go.Scatter(x=time_vector, y=y_vector, line_color="grey"))
    F.update_layout(xaxis_title="time", yaxis_title=y_name)

    for ind, p_l, p_r in zip(peak_inds, peaks_left, peaks_right):
        F.add_vline(x=time_vector[ind], line_dash="solid", line_color="black")
        F.add_vline(x=time_vector[p_l], line_dash="dash", line_color="green")
        F.add_vline(x=time_vector[p_r], line_dash="dash", line_color="green")

    fname = f"{prefix}_{time_name}_{y_name}_found_peaks"
    save_fig(F, fname, figure_dir)
