import numpy as np
import pandas as pd
from typing import Optional, Tuple
from pathlib import Path

from spectral_arithmetic.aggregate_operations import (
    transform_spectra,
    filter_spectral_data,
    bin_spectral_data,
)
from data_pooler.persist import get_combolog_from_zpickle

from scipy.interpolate import interp1d
from scipy.stats import binned_statistic
from typing import Optional, Tuple


def add_tvoc_df(
    comp_df: pd.DataFrame,
    nu_name: Optional[str] = "nu",
    abs_name: Optional[str] = "partial_fit",
    overwrite: Optional[bool] = False,
) -> pd.DataFrame:
    """Update dataframe with simple_sum and simple_trapz.

    Args:
        comp_df: pd.DataFrame
            Dataframe with a timzone aware DateTimeIndex and timeseries data.
        nu_name: optional string, default 'nu'
            name of the variable within the spectrum list for the frequency variable nu
        abs_name: optional string, default 'partial_fit'
            name of the variable within the spectrum list for the absorption or partial fit variable
        overwrite: optional boolean, default False
            If true, any existing simple_sum or simple_trapz will be overwritten with calculated values.
    Raises:

    Returns:
        df: pd.DataFrame
            pandas dataframe with total voc proxies.
            Index is timezone aware datetime index
    """

    if (
        "broadband_simple_sum" not in comp_df
        or "broadband_simple_trapz" not in comp_df
        or overwrite
    ):
        # collect total VOC proxy data, grouped by spectrum
        dfg_tvoc = simple_tvoc(
            comp_df,
            nu_name=nu_name,
            abs_name=abs_name,
            bin_width=5.0,
        )

    if "broadband_simple_sum" not in comp_df or overwrite:
        comp_df["broadband_simple_sum"] = dfg_tvoc["broadband_simple_sum"]
    if "broadband_simple_trapz" not in comp_df or overwrite:
        comp_df["broadband_simple_trapz"] = dfg_tvoc["broadband_simple_trapz"]

    return comp_df


# @profile
def one_spectral_array_set(
    t0,
    t_end,
    comp_df: pd.DataFrame,
    nu_name: Optional[str] = "nu",
    include_res: Optional[bool] = False,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """create a dictionary containing dataframes of the spectral data.

    Parameters:
        t0 (time-zone aware datetime):
            First datetime of interest
        t_end (time-zone aware datetime):
            Last datetime of interest
        comp_df: pd.DataFrames

        nu_name: optional string, default 'nu'
            name of the variable within the spectrum list for the frequency variable nu
        include_res: optional boolean, default False
            boolean indicating if the residual data should be included in the returned spectrum_list

    Raises:

    Returns:
        fit_df: pd.DataFrame
            pandas dataframe of interpolated spectral absorption.
            Columns are frequency. Index is timezone aware datetime index and spectrum_index.
        res_df: pd.DataFrame
            pandas dataframe of interpolated residuals.
            Columns are frequency. Index is timezone aware datetime index and spectrum_index.
    """
    # limit data to the time range specified
    uid_start = np.where(comp_df.index >= t0)[0][0]
    uid_end = np.where(comp_df.index <= t_end)[0][-1]

    # find the full frequency list for all of the data
    numean, modes = get_numean(t0, t_end, comp_df)

    tuples = list(zip(numean, modes))
    columns = pd.MultiIndex.from_tuples(tuples, names=["nu", "mode"])
    fit_df = pd.DataFrame(index=comp_df.index, columns=columns)
    if include_res:
        res_df = pd.DataFrame(index=comp_df.index, columns=columns)
    else:
        res_df = pd.DataFrame()

    for file_path in comp_df[uid_start:uid_end]["spec_gen_file"].unique():
        if isinstance(file_path, Path):
            with file_path.open("rb") as pp:
                gen = get_combolog_from_zpickle(pp)
                _ = next(gen)
                df = gen.send("fitdata")  # timeseries

                spec_ind = comp_df["spec_gen_id"][comp_df["spec_gen_file"] == file_path]

                for spectra_count in spec_ind:
                    spectra = gen.send(int(spectra_count))
                    spec_dict = convert_df_to_dict(spectra)

                    spec = create_single_binned_spectrum(spec_dict)
                    out_ind = np.where(comp_df["spec_gen_id"] == spectra_count)[0][0]
                    out_modes = np.array(spec.modes)

                    idx = pd.IndexSlice
                    fit_df.loc[
                        fit_df.index[out_ind], idx[:, out_modes]
                    ] = spec.partial_fit
                    if include_res:
                        res_df.loc[
                            res_df.index[out_ind], idx[:, out_modes]
                        ] = spec.residuals

    return fit_df, res_df


def simple_tvoc(
    comp_df: pd.DataFrame,
    nu_name: Optional[str] = "nu",
    abs_name: Optional[str] = "partial_fit",
    bin_width: Optional[float] = 5.0,
) -> pd.DataFrame:
    """calculate integral of absorbance using the trapezoidal rule and simple_sum.

    Args:
        comp_df: pd.DataFrame
            dataframe of spectral data
        nu_name: optional str, default 'nu'
            name of the frequency variable
        abs_name: optional str, default 'partial_fit'
            name of the absorbance variable
        bin_width: optional float, default 5.0
            width of the simple sum frequency bins

    Raises:

    Returns:
        dataframe
            dataframe containing information, including tvoc proxies
    """
    bin_range = (5800, 6200)
    bin_edges = np.arange(bin_range[0], bin_range[1] + bin_width / 2, bin_width)

    output_df = pd.DataFrame(
        index=comp_df.index, columns=["broadband_simple_trapz", "broadband_simple_sum"]
    )
    for file_path in comp_df["spec_gen_file"].unique():
        if isinstance(file_path, Path):
            with file_path.open("rb") as pp:
                gen = get_combolog_from_zpickle(pp)
                _ = next(gen)
                df = gen.send("fitdata")  # timeseries

                spec_ind = comp_df["spec_gen_id"][comp_df["spec_gen_file"] == file_path]

                for spectra_count in spec_ind:
                    spectra = gen.send(int(spectra_count))

                    total_trapz = np.trapz(spectra[abs_name], spectra[nu_name])

                    absorbance_mean, _, _ = binned_statistic(
                        spectra[nu_name],
                        spectra[abs_name],
                        statistic=np.nanmean,
                        bins=bin_edges,
                    )

                    out_ind = np.where(comp_df["spec_gen_id"] == spectra_count)[0]

                    output_df.iloc[
                        out_ind, output_df.columns.get_loc("broadband_simple_trapz")
                    ] = total_trapz
                    output_df.iloc[
                        out_ind, output_df.columns.get_loc("broadband_simple_sum")
                    ] = np.nansum(absorbance_mean)

    return output_df


def convert_df_to_dict(df, columns_to_remove=[]):
    df_dict = df.to_dict("series")

    out = {}
    for k, v in df_dict.items():
        if k not in columns_to_remove:
            out[k] = v.to_numpy()
    return out


def pick_f0(nu, usual_f0=6056.508):
    f0_index = (abs(nu - usual_f0)).argmin()
    return nu[f0_index]


TRANSFORM_KEYS = ["nu_shift", "nu_squish", "nu_center"]


def create_single_binned_spectrum(spectrum, f0=None, fsr_thresh=None, f0_thresh=None):
    if f0 is None:
        f0 = pick_f0(spectrum["nu"])
    spectrum.update({"f0": f0})
    transform_keys_present = set(TRANSFORM_KEYS) <= set(spectrum.keys())
    transformed = transform_spectra([spectrum], apply_transform=transform_keys_present)
    filtered = filter_spectral_data([next(transformed)])
    binned = bin_spectral_data(filtered)
    return binned


def get_numean(
    start_date_time,
    stop_date_time,
    comp_df: pd.DataFrame,
) -> Tuple[np.array, np.array]:
    """bin and average frequencies to numean array.

    Args:
        start_date_time (time-zone aware datetime):
            First datetime of interest
        stop_date_time (time-zone aware datetime):
            Last datetime of interest
        comp_df: pd.DataFrames

        testing: optional boolean, default False
            If True output intermediates for testing

    Raises:

    Returns:
        numean: np.array
            1D array of numean values for the entire dataset
        modes: np.array
            1D array of mode index values for the dataset
    """
    # limit data to the time range specified
    uid_start = np.where(comp_df.index >= start_date_time)[0][0]
    uid_end = np.where(comp_df.index <= stop_date_time)[0][-1]

    composite_spectrum = None
    for file_path in comp_df[uid_start:uid_end]["spec_gen_file"].unique():
        if isinstance(file_path, Path):
            with file_path.open("rb") as pp:
                gen = get_combolog_from_zpickle(pp)
                _ = next(gen)
                df = gen.send("fitdata")  # timeseries

                spec_ind = comp_df["spec_gen_id"][comp_df["spec_gen_file"] == file_path]

                for spectra_count in spec_ind:

                    spectra = gen.send(int(spectra_count))
                    spec_dict = convert_df_to_dict(spectra)

                    spec = create_single_binned_spectrum(spec_dict)
                    if composite_spectrum is None:
                        composite_spectrum = spec
                    else:
                        composite_spectrum = composite_spectrum.union_binned_spectra(
                            spec
                        )

    u = composite_spectrum.nu_prime.argsort()
    numean = composite_spectrum.nu_prime[u]

    modes = np.array(composite_spectrum.modes)[u]

    return numean, modes
