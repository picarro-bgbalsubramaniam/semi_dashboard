from datetime import datetime
import numpy as np
from scipy.interpolate import interp1d
import pandas as pd
from copy import deepcopy

from typing import Optional, Tuple
from spectral_toolkit.TD_analysis.TD_utilities.utilities_for_timeseries_TD import (
    get_all_data,
)

from spectral_toolkit.TD_analysis.data_models_TD.output_models import (
    SpectralData,
    FomSpectralData,
)


def interpolate_FOM(
    FOM_time: np.array, FOM_data: np.array, spectral_time: np.array
) -> np.array:
    """Interpolate FOM values to spectral timme.

    Args:
        FOM_time: np.array
            Time that corresponds to the measured FOM values.

        FOM_data: np.array
            Measured FOM values to be interpolated

        spectral_time: np.array
            Time onto which the FOM should be interpolated

    Returns:
        FOM_all: np.array
            Interpolated FOM in spectral time
    """
    FOM_interp = interp1d(
        FOM_time,
        FOM_data,
        kind="nearest",
        bounds_error=False,
        fill_value="extrapolate",
    )

    FOM_all = FOM_interp(spectral_time)

    return FOM_all


def correlate_one_freq_FOM(
    FOM_all: np.array,
    spectral_data: np.array,
) -> np.array:
    """Correlate FOM with spectral data at one frequency.

    Args:
        FOM_all: np.array
            Interpolated FOM in spectral time
        spectral_data: np.array
            Spectral data from one frequency.

    Returns:
        line_coef: np.array
            linear fit coefficients.
            line_coef[0]: slope
            line_coef[1]: offset
    """
    line_coef = np.polyfit(
        FOM_all,
        spectral_data,
        1,
    )

    return line_coef


def calculate_coef(
    numean: np.array, df_now: pd.DataFrame, FOM_all: np.array
) -> Tuple[pd.DataFrame, list]:
    """Calculate FOM versus signal linear coefficients.

    Args:
        numean: np.array
            Mean frequency values for the spectral data
        df_now: pd.DataFrame
            dataframe containing spectral data, indexed by nu.
        FOM_all: np.array
            Interpolated FOM in spectral time

    Returns:
        coef_df: pd.DataFrame
            index: numean
            slope: slope values for FOM vs spectra correlation (n)
            offset: offset values for FOM vs spectra correlation (n)
        ind_list: list

    """
    slope_list = []
    offset_list = []
    ind_list = []
    for key, nu in enumerate(numean):
        ind_2_use = np.where(df_now[nu].isna() != True)[0]
        if len(ind_2_use) > 0:
            spectral_data = df_now[nu].to_numpy(dtype=float)

            line_coef = correlate_one_freq_FOM(
                FOM_all[ind_2_use],
                spectral_data[ind_2_use],
            )
            slope_list.append(line_coef[0, 0])
            offset_list.append(line_coef[1, 0])
            ind_list.append(key)

    coef_df = pd.DataFrame(
        index=numean[ind_list], data={"slope": slope_list, "offset": offset_list}
    )

    return coef_df, ind_list


def flip_negative_mf(coef_df: pd.DataFrame) -> pd.DataFrame:
    """Flip the sign of all slope values if the mf is mostly negative.

    Args:
        coef_df: pd.dataframe
            index: numean
            slope: slope values for FOM vs spectra correlation (n)
            offset: offset values for FOM vs spectra correlation (n)

    Returns:
        coef_df: pd.dataframe
            updated for negative mf
    """
    overall_average = np.nanmean(coef_df["slope"])
    overall_median = np.nanmedian(coef_df["slope"])
    if (overall_average < -0.001 and overall_median < -0.001) or (
        overall_average < -np.nanmax(np.abs(coef_df["slope"])) * 0.1
        and overall_median < -np.nanmax(np.abs(coef_df["slope"])) * 0.1
    ):
        coef_df["slope"] *= -1

    return coef_df


def correlate_freq_FOM(
    FOM_name: str,
    df: pd.DataFrame,
    spectra: SpectralData,
    start_dt: Optional[datetime] = None,
    end_dt: Optional[datetime] = None,
) -> FomSpectralData:
    """Calculate correlation between FOM and spectral data for each frequency.

    Parameters:
        FOM_name: str
        df: pd.DataFrame
        spectra: SpectralData
            fit_df: PandasDataFrame
            spectrum_df: Optional[PandasDataFrame]
            numean: Optional[Array[float]]
            modes: Optional[Array[int]]
            res_df: Optional[PandasDataFrame]
            good_fits: Optional[int]
            bad_fits: Optional[int]
        start_dt
        end_dt

    Raises:

    Returns:
        event_fit: FomSpectralData
            spectral_FOM: np.array
                1D array of FOM values in time (n)
            fit_df: pd.DataFrame
                dataframe containing spectral data (m, n)
            coef_df: pd.DataFrame
                index: numean (m)
                slope: slope values for FOM vs spectra correlation (m)
                offset: offset values for FOM vs spectra correlation (m)

    """
    start_datetime = spectra.fit_df.index.get_level_values(level="_datetime")[0]
    end_datetime = spectra.fit_df.index.get_level_values(level="_datetime")[-1]
    if start_dt is not None:
        start_datetime = start_dt
    if end_dt is not None:
        end_datetime = end_dt

    FOM_data = get_all_data(FOM_name, df)
    FOM_time = df.index.astype(np.int64)

    FOM_ind = np.where(FOM_data.isna() != True)[0]

    spectral_time = spectra.fit_df.index.get_level_values(level="_datetime").astype(
        np.int64
    )
    numean = spectra.fit_df.columns.get_level_values(level="nu").to_numpy(dtype=float)

    ind_4_time = np.intersect1d(
        np.where(
            spectra.fit_df.index.get_level_values(level="_datetime") >= start_datetime
        ),
        np.where(
            spectra.fit_df.index.get_level_values(level="_datetime") <= end_datetime
        ),
    )

    df_now = deepcopy(spectra.fit_df.iloc[ind_4_time])

    FOM_all = interpolate_FOM(
        FOM_time[FOM_ind], FOM_data[FOM_ind], spectral_time[ind_4_time]
    )

    coef_df, ind_list = calculate_coef(numean, df_now, FOM_all)

    coef_df = flip_negative_mf(coef_df)

    event_fit = FomSpectralData(
        spectral_FOM=FOM_all,
        fit_df=df_now[numean[ind_list]],
        coef_df=coef_df,
    )

    return event_fit


def convert_event_fit_slope_to_loss(
    input_class, event_fit: FomSpectralData
) -> FomSpectralData:
    # convert compound hunting concentrations to measured concentrations in the fab
    # conc_in_fab = conc_from_fit * scaling_factor * FOM_Integral * instrument_flow / ( trap_flow * sampling_time)
    # the results probably only make sense when the full integral of the pulse is used.
    fom_integral = get_integral_from_time_series(event_fit)
    conc_scaling = fom_integral
    conc_scaling *= input_class.MFCs.instrument_flow
    conc_scaling *= (
        input_class.MFCs.concentration_scaler
    )  # set this to 1000 to go from ppb (the default) to ppt -- ppb doesn't have enough sig figs
    conc_scaling /= input_class.MFCs.trap_flow
    conc_scaling /= input_class.Precon_timing.trap_time_min * 60

    event_fit.coef_df["slope"] *= conc_scaling
    
    event_fit.fom_integral = fom_integral
    event_fit.conc_scaling = conc_scaling

    return event_fit


def get_integral_from_time_series(event_fit):
    """Takes the event fit dictionary for an event and returns an integral in [units_of_FOM] sec"""
    # extract time series from df
    index = event_fit.fit_df.index
    times = (index - index[0]).total_seconds()

    # extract y-values
    fom = event_fit.spectral_FOM
        
    zero_value = fom[times < 15].mean()

    # integrate
    integral = np.trapz(fom - zero_value, times)

    return integral
