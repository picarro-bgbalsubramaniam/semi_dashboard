from copy import copy
from datetime import timedelta
from pathlib import Path
from typing import Optional, Tuple

import pandas as pd
import numpy as np
import os
import glob
from datetime import timedelta, datetime
import pytz
import warnings

from spectral_toolkit.TD_analysis.TD_utilities.utilities_TD import (
    rename_variables,
    calculate_trap_times,
)


def parse_Markes_sequence(
    markes_path: Path,
    timezone: str,
    start_dt: datetime,  # pd.DateTimeIndex,
    end_dt: datetime,  # pd.DateTimeIndex,
    verbose: Optional[bool] = False,
) -> pd.DataFrame:
    """Parse Markes sequence logs.

    Args:
        markes_path: Path
            file path where the Markes sequence logs are saved
        timezone: str
            pytz timezone string
        start_dt: pd.DateTimeIndex
            start of the experiment as a pandas DateTimeIndex
        end_dt: pd.DateTimeIndex
            end of the experiment as a pandas DateTimeIndex
        verbose: optional boolean, default False
            no longer used...

    Raises:

    Returns:
        sequences: pd.DataFrame
            Pandas dataframe containing sequence data.
            Each line is one run, indexed by a timezone aware datetime index.

            Common columns included:
            sample_volume_mL: volume of sample collected (mL)
            trap_flow: cold trap trapping flow (sccm)
            trap_time: cold trap trap time (min)
            post_sample_purge_time: post sample purge time (min)
            trap_purge_time: trap purge time (min)
            max_flow: maximum flow (sccm)
            min_flow: minimum flow (sccm)
            trap_low_temperature: trap low temperature (C)
            trap_heating_rate: trap heating rate (C/s)
            desorb_time_min: desorb time (min)
    """
    sequence_name_list = glob.glob(os.path.join(markes_path, "*.csv"))
    sequence_name_list.sort()
    sequence_list = []
    for sequence_name in sequence_name_list:
        df = pd.read_csv(sequence_name, sep=",", index_col=False)

        if "Trap Fire Time" not in df:
            warning_str = f"Trap Fire Time not in {sequence_name}"
            print(warning_str)
            warnings.warn(warning_str, UserWarning)
            continue
        if df["Trap Fire Time"].isna().all():
            warning_str = f"Trap Fire Time is NaN, {sequence_name}"
            print(warning_str)
            warnings.warn(warning_str, UserWarning)
            continue

        # set index as the start of the "trap fire"
        df["index"] = copy(df["Trap Fire Time"])
        df = df.set_index("index")
        df.index = pd.to_datetime(df.index)
        tz = pytz.timezone(timezone)
        df.index = df.index.tz_localize(tz)

        if df.index < start_dt or df.index > end_dt:
            continue

        # determine the end of the run
        df["end_datetime"] = copy(pd.to_datetime(df["Trap Fire Time"]).tz_convert(tz))
        for key in range(len(df["end_datetime"])):
            time_to_add = calculate_end_datetime(df, key)
            df.iloc[key, df.columns.get_loc("end_datetime")] += time_to_add
            df.iloc[key, df.columns.get_loc("end_datetime")] = df.iloc[
                key, df.columns.get_loc("end_datetime")
            ].tz_localize(tz)

        # rename variables
        renaming = [
            ["Sample Volume (mL)", "sample_volume_mL"],
            ["Sampling flow", "trap_flow"],
            ["Sample time", "trap_time"],
            ["Post sample purge time", "post_sample_purge_time"],
            ["Trap purge time (min)", "trap_purge_time"],
            ["Maximum Flow", "max_flow"],
            ["Minimum Flow", "min_flow"],
            ["Trap low temperature (°C)", "trap_low_temperature"],
            ["Trap heating rate (°C/s)", "trap_heating_rate"],
            ["Trap desorb time (min)", "desorb_time_min"],
        ]
        for initial_name, new_name in renaming:
            df = rename_variables(df, initial_name, new_name)

        sequence_list.append(df)
    if len(sequence_list) > 0:
        sequences = pd.concat(sequence_list)
    else:
        sequences = pd.DataFrame()

    return sequences


def calculate_end_datetime(df: pd.DataFrame, key: int) -> timedelta:
    """Calculate run end datetime.

    The end of the run is calculating using trap temperatures, ramp rates, and desorb time.
    If the trap temperatures are not included, low and high are assumed to be 25 and 280, respectively.
    If the ramp rate is not included, no time is added for the ramp step.
    If the desorb time is not included or is NaN, 10 minutes is added.

    Args:
        df: pd.DataFrame
            dataframe containing run information including:
                "Trap low temperature (°C)" optional
                "Trap heating rate (°C/s)" or "Trap heat rate (°C/s)" optional
                "Trap desorb time (min)" optional
                "Peak Desorb Temp" optional
        key: int

    Raises:

    Returns:
        time_to_add: timedelta
            time to be added to the start time (datetime index) to calculate end time.
    """
    time_to_add = timedelta(seconds=0)

    # assume trap hot temperature is 280 C (THIS MAY NOT BE TRUE)
    trap_high_temp_C = 280.0
    trap_low_temp_C = 25.0  # default to 25C (THIS MAY NOT BE TRUE)
    if "Trap low temperature (°C)" in df:
        new_trap_temp_C = df["Trap low temperature (°C)"].iloc[key].astype(float)
        if not np.isnan(new_trap_temp_C):
            trap_low_temp_C = new_trap_temp_C
    if "Peak Desorb Temp" in df:
        # This value is the maximum temperature reached, so it will be a little high but more accurate than 280
        new_trap_temp_C = df["Peak Desorb Temp"].iloc[key].astype(float)
        if not np.isnan(new_trap_temp_C):
            trap_high_temp_C = new_trap_temp_C

    if "Trap heating rate (°C/s)" in df:
        trap_heating_rate = df["Trap heating rate (°C/s)"].iloc[key].astype(float)
        if not np.isnan(trap_heating_rate):
            trap_heating_time_s = (
                trap_high_temp_C - trap_low_temp_C
            ) / trap_heating_rate
        else:
            trap_heating_time_s = 0.0
        time_to_add += timedelta(seconds=trap_heating_time_s)
    elif "Trap heat rate (°C/s)" in df:
        trap_heating_rate = df["Trap heat rate (°C/s)"].iloc[key].astype(float)
        if not np.isnan(trap_heating_rate):
            trap_heating_time_s = (
                trap_high_temp_C - trap_low_temp_C
            ) / trap_heating_rate
        else:
            trap_heating_time_s = 0.0
        time_to_add += timedelta(seconds=trap_heating_time_s)

    if "Trap desorb time (min)" in df:
        desorb_time_min = df["Trap desorb time (min)"].iloc[key].astype(float)
        if not np.isnan(desorb_time_min):
            time_to_add += timedelta(minutes=desorb_time_min)
        else:
            time_to_add += timedelta(minutes=10.0)  # default to 10 minutes
    else:
        desorb_time_min = np.nan
        time_to_add += timedelta(minutes=10.0)  # default to 10 minutes

    return time_to_add


# functions that process one sequence at a time
def parse_Markes_parts(
    sequence_series,
    start_datetime: pd.DatetimeIndex,
    markes_path: Path,
    timezone: str,
    part_name: Optional[str] = "Unity",
) -> pd.DataFrame:
    """Parse Markes instrument files.

    Args:
        sequence_series
        start_datetime: pd.DatetimeIndex
            start of the experiment as a pandas DateTimeIndex
        markes_path: Path
            file path where the Markes sequence logs are saved
        timezone: str
            pytz timezone string
        part_name: optional string, default 'Unity'
            name of the instrument to be parsed.
            Options: 'Unity', 'CIA', 'Kori', 'GC'

    Raises:

    Returns:
        df_parts: pd.DataFrame
            timeseries data from one of the Markes systems with a timezone aware datetimeindex.
    """
    print(part_name)

    # collect list of file names within a few hours of the requested data
    previous_hrs_dt = start_datetime - timedelta(hours=2)
    name_list = []
    now_dt = copy(previous_hrs_dt + timedelta(hours=1))
    while now_dt < (sequence_series["end_datetime"]):
        now_date_hr = now_dt.strftime("%Y%m%d_%H")
        name_list.append(
            os.path.join(markes_path, f"statlog_{part_name}_{now_date_hr}.csf")
        )
        now_dt += timedelta(hours=1)

    # collect data and convert into a dataframe with timezone aware datetimeindex
    data_list = []
    for i, name in enumerate(name_list):
        if os.path.exists(name):
            df = pd.read_csv(name, sep="\t")

            df["Date"] = pd.to_datetime(df["Date"], dayfirst=True)
            tz = pytz.timezone(timezone)
            df.set_index("Date", inplace=True)
            df.index = df.index.tz_localize(tz)

            data_list.append(df)

    df_parts = pd.concat(data_list)

    return df_parts


def update_parts_dict(
    trap_start_datetime: pd.DatetimeIndex,
    trap_end_datetime: pd.DatetimeIndex,
    df_run: Optional[pd.DataFrame] = None,
    part_name: Optional[str] = "Unity",
    parts: Optional[dict] = None,
) -> dict:
    """Update parts dictionary.

    Args:
        trap_start_datetime: pd.DatetimeIndex
            start of the trapping step as a pandas DateTimeIndex
        trap_end_datetime: pd.DatetimeIndex
            end of the trapping step as a pandas DateTimeIndex
        df_run: optional pd.DataFrame, default None
        part_name: optional string, default 'Unity'
            name of the instrument to be parsed.
            Options: 'Unity', 'CIA', 'Kori', 'GC'
        parts: optional dict, default None

    Returns:
        parts: dict
            dictionary containing information for each instrument
            parts[part_name] = {"df": df_parts}
                pd.DataFrame with timezone aware datetime index
                A small number of variables are renamed:
                    renaming = [
                        ["ColdTrap1.CurrentTemp", "trap_C"], #trap temperature (C)
                        ["ColdTrap1.TargetTemp", "trap_setpoint_C"], #trap temperature setpoint (C)
                        ["Unity Trap2.FlowRate", "trap_sccm"], #trap flow (sccm)
                        ["Unity Trap2.FlowRateSetpoint", "trap_setpoint_sccm"], #trap flow setpoint (sccm)
                        ["Instrument State", "instrument_state"], #instrument state
                    ]
            if the part is 'Unity' parts[part_name] also includes:
                "trap_start_datetime": start datetime of the trap
                "trap_end_datetime": end datetime of the trap
    """
    if parts is None:
        parts = {}
    if part_name not in parts:
        parts[part_name] = {}

    # append data to parts dictionary
    if part_name == "Unity":
        parts[part_name].update(
            {
                "trap_start_datetime": trap_start_datetime,
                "trap_end_datetime": trap_end_datetime,
            }
        )

    if df_run is not None:
        # rename a few variables
        renaming = [
            ["ColdTrap1.CurrentTemp", "trap_C"],
            ["ColdTrap1.TargetTemp", "trap_setpoint_C"],
            ["Unity Trap2.FlowRate", "trap_sccm"],
            ["Unity Trap2.FlowRateSetpoint", "trap_setpoint_sccm"],
            ["Instrument State", "instrument_state"],
        ]
        for initial_name, new_name in renaming:
            df_run = rename_variables(df_run, initial_name, new_name)
        parts[part_name]["df"] = df_run

    return parts


def get_trap_inds(df_parts: pd.DataFrame, sequence_series) -> Tuple[np.array, np.array]:
    """Determine when trapping was occurring using flow or instrument state.

    Args:
        df_parts: pd.DataFrame
            timeseries data from one of the Markes systems with a timezone aware datetimeindex.
        sequence_series

    Returns
        traps_start_ind: array
        traps_end_ind: array
    """
    if "Sampling flow" in sequence_series:
        trap_flow = sequence_series["Sampling flow"]
        trap_setpoint_sccm = df_parts["Unity Trap2.FlowRateSetpoint"].astype(float)
        all_traps_ind = np.where(
            abs(trap_setpoint_sccm - trap_flow) < 0.05 * trap_flow
        )[0]
    else:
        # using Unity alone with a pre-sampled tube. Look at cold trap state to determine run timing
        all_traps_ind = np.where(
            (df_parts["State"] == "Trap Heating") | (df_parts["State"] == "Trap Desorb")
        )[0]

    return all_traps_ind


def get_start_and_end_inds(all_traps_ind: np.array) -> Tuple[np.array, np.array]:
    """Get start and end indices for all runs.

    Args:
        all_traps_ind: np.array
            vector of index values for trap runs
    Returns:
        traps_start_ind: array
        traps_end_ind: array
    """
    # get start and end indices for each run
    ind_diff = np.diff(all_traps_ind)
    traps_end_ind = np.append(
        all_traps_ind[np.where(ind_diff > 1)[0]], all_traps_ind[-1]
    )
    traps_start_ind = np.insert(
        all_traps_ind[np.where(ind_diff > 1)[0] + 1], 0, all_traps_ind[0]
    )

    return traps_start_ind, traps_end_ind


def filter_parts_data(
    sequence_series, start_datetime: pd.DatetimeIndex, df_parts: pd.DataFrame
) -> Tuple[pd.DataFrame, pd.DatetimeIndex, pd.DatetimeIndex]:
    """Filter parts data so that it only covers data from one run.

    Args:
        sequence_series

        start_datetime: pd.DatetimeIndex
            start date time value for the run
        df_parts: pd.DataFrame
            timeseries data from one of the Markes systems with a timezone aware datetimeindex.

    Returns
        df_run: pd.DataFrame
            Timeseries data for one run.
            from one of the Markes systems with a timezone aware datetimeindex.
        trap_start_datetime: pd.DatetimeIndex
            start datetimeindex for this run
        trap_end_datetime: pd.DatetimeIndex
            end datetimeindex for this run
    """
    # initial time range from trap fire, flows, and times
    data_4_fire = np.intersect1d(
        np.where(df_parts.index >= start_datetime),
        np.where(df_parts.index <= sequence_series["end_datetime"]),
    )
    ind_pad = 50
    data_2_try = np.arange(
        max(0, data_4_fire[0] - ind_pad), min(len(df_parts), data_4_fire[-1] + ind_pad)
    )

    (trap_start_datetime, trap_end_datetime, _, _) = calculate_trap_times(
        sequence_series
    )
    # determine when trapping was occurring using flow or instrument state
    if "Unity Trap2.FlowRateSetpoint" in df_parts:
        # get all trap indices
        all_traps_ind = get_trap_inds(df_parts, sequence_series)
        traps_start_ind, traps_end_ind = get_start_and_end_inds(all_traps_ind)

        # get current trap indices
        trap_start_ind = np.intersect1d(data_2_try, traps_start_ind)
        trap_end_ind = np.intersect1d(data_2_try, traps_end_ind)

        # get trap start and end time
        if len(trap_start_ind) == 1:  # and len(trap_end_ind) == 1:
            sequence_num = 0
            if len(trap_end_ind) == 0:
                trap_end_ind = traps_end_ind
        else:
            sequence_num = np.where(trap_end_ind < data_4_fire[0])[0][-1]

        trap_start_datetime = df_parts.index[trap_start_ind[sequence_num]]
        trap_end_datetime = df_parts.index[
            min(trap_end_ind[sequence_num] + 1, len(df_parts) - 1)
        ]

    # pare down data
    data_2_keep = np.intersect1d(
        np.where(df_parts.index >= trap_start_datetime),
        np.where(df_parts.index < sequence_series["end_datetime"]),
    )
    sort_ind = np.argsort(df_parts.index[data_2_keep])

    df_run = df_parts.iloc[data_2_keep[sort_ind], :]

    return df_run, trap_start_datetime, trap_end_datetime
