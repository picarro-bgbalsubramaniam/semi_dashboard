import numpy as np

# from lmfit import Model
from lmfit.model import Model, ModelResult
from scipy import stats
from copy import copy, deepcopy

from typing import Optional, Tuple, List, Dict

from spectral_toolkit.TD_analysis.TD_utilities.peak_fit_functions import (
    gaussian,
    gaussian_area,
    cauchy_gaussian,
    cauchy_gaussian_area,
    cauchy_gaussian_area_error_prop,
    rectangle,
    rectangle_area,
    rectangle_area_error_prop,
)


def parse_and_set_gaus_params(
    time: np.array,
    signal: np.array,
    bin_std: np.array,
    cen: float,
    gaus_amp_min: float,
    gaus_amp: float,
    fits_dict: Dict[str, float],
) -> dict:
    """Parse and set Gaussian fit parameters.

    Args:
        time: np.array
            1D vector of time values in seconds associated with the signal to be fit
        signal: np.array
            1D vector of signal values to be fit
        bin_std: np.array
        cen: float
            time value in seconds as the first estimate of the center of the peak to be fit
        gaus_amp_min: float
            approximate gaussian amplitude minimum (Gaussian amplitude is area, signal is height h = a/sigma/sqrt(2*pi))
        gaus_amp: float
            approximate gaussian amplitude (Gaussian amplitude is area, signal is height h = a/sigma/sqrt(2*pi))
        fits_dict: dict

    Returns:
        gaus_param_dict: dict of gaussian fit parameters
            Values get transfered from fits_dict into this dictionary.
            Otherwise defaults are set based on the other inputs.

            amp: {min: value, max: value, optional(mean: value)}
                min defaults to 10 * gaus_amp_min
                max defaults to 10 * gaus_amp
            sigma: {min: value, max: value, mean: value}
                min defaults to 2* median time difference
                max defaults to 200
                mean defaults to NaN
            cen: {min: value, max: value, optional(mean: value)}
                min: 0, cen-120, or sigma max / 2
                max: final time, cen + 120, or final time - sigma max / 2
            offset: {min: value, max: value, optional(mean: value)}
                min defaults to gaus_amp_min
                max defaults to gaus_amp
            offset_slope: {min: value, max: value, optional(mean: value)}
                min and max default to median bin_std/total time or 2 times the same
    """
    gaus_param_dict = {
        "amp": {"min": 10 * gaus_amp_min, "max": 10 * gaus_amp},
        "sigma": {"min": 2 * np.nanmedian(np.diff(time)), "max": 200, "mean": np.nan},
        "cen": {},
        "offset": {"min": gaus_amp_min, "max": gaus_amp},
    }
    if np.nanmax(signal) - np.nanmin(signal) > 10 * np.nanmedian(bin_std):
        factor = 2.0
    else:
        factor = 1.0
    if np.nanmedian(bin_std) == 0:
        gaus_param_dict.update({"offset_slope": {"min": -1e-4, "max": 1e-4}})
    else:
        gaus_param_dict.update(
            {
                "offset_slope": {
                    "min": -np.nanmedian(bin_std) * factor / (time[-1] - time[0]),
                    "max": np.nanmedian(bin_std) * factor / (time[-1] - time[0]),
                }
            }
        )

    key_list = ["amp", "sigma", "cen", "offset", "offset_slope"]
    for key in key_list:
        if key in fits_dict:
            if key == "amp":
                gaus_param_dict[key] = fits_dict[key]  # * 21 * np.sqrt(2 * np.pi)
                # No scaling because when amp min and max are added, they are from the model and already scaled
            elif len(fits_dict[key]) > 0:
                gaus_param_dict[key] = fits_dict[key]

    if "min" not in gaus_param_dict["cen"]:
        if cen - time[0] > 120:
            gaus_param_dict["cen"]["min"] = max(0, cen - 120)
        else:
            gaus_param_dict["cen"]["min"] = (
                time[0] + gaus_param_dict["sigma"]["max"] / 2.0
            )
    if "max" not in gaus_param_dict["cen"]:
        if time[-1] - cen > 120:
            gaus_param_dict["cen"]["max"] = cen + 120
        else:
            gaus_param_dict["cen"]["max"] = (
                time[-1] - gaus_param_dict["sigma"]["max"] / 2.0
            )

    return gaus_param_dict


def parse_and_set_cau_gaus_params(
    time: np.array,
    signal: np.array,
    bin_std,
    cen: float,
    reg_amp_min: float,
    reg_amp: float,
    fits_dict: Dict[str, float],
) -> dict:
    """Parse and set Cauchy-Gaussian fit parameters.

    Args:
        time: np.array
            1D vector of time values in seconds associated with the signal to be fit
        signal: np.array
            1D vector of signal values to be fit
        bin_std:
        cen: float
            time value in seconds as the first estimate of the center of the peak to be fit
        reg_amp_min: float
            approximate Cauchy-Gaussian amplitude minimum
        reg_amp: float
            approximate Cauchy-Gaussia amplitude
        fits_dict: dict

    Returns:
        reg_param_dict: dict of Cauchy-Gaussian fit parameters
            Values get transfered from fits_dict into this dictionary.
            Otherwise defaults are set based on the other inputs.

            amp: {min: value, max: value, optional(mean: value)}
                min: defaults to reg_amp_min
                max: defaults to 10 * reg_amp
            sigma_left sigma_right: {min: value, max: value, mean: value}
                min defaults to 2* median time difference
                max defaults to 200
                mean defaults to NaN
            f_left f_right: {min: value, max: value, optional(mean: value)}
                min defaults to 0
                max defaults to 1
                mean defaults to NaN
            cen: {min: value, max: value, optional(mean: value)}
                min: 0, cen-120, or sigma_left max / 2
                max: final time, cen + 120, or final time - sigma_right max / 2
            offset: {min: value, max: value, optional(mean: value)}
                min defaults to reg_amp_min
                max defaults to reg_amp
            offset_slope: {min: value, max: value, optional(mean: value)}
                min and max default to median bin_std/total time or 2 times the same
    """
    reg_param_dict = {
        "amp": {"min": reg_amp_min, "max": 10 * reg_amp},
        "sigma_left": {
            "min": 2 * np.nanmedian(np.diff(time)),
            "max": 200,
            "mean": np.nan,
        },
        "sigma_right": {
            "min": 2 * np.nanmedian(np.diff(time)),
            "max": 200,
            "mean": np.nan,
        },
        "f_left": {"min": 0, "max": 1.0, "mean": np.nan},
        "f_right": {"min": 0, "max": 1.0, "mean": np.nan},
        "cen": {},
        "offset": {"min": reg_amp_min, "max": reg_amp},
    }
    if np.nanmax(signal) - np.nanmin(signal) > 10 * np.nanmedian(bin_std):
        factor = 2.0
    else:
        factor = 1.0
    if np.nanmedian(bin_std) == 0:
        reg_param_dict.update({"offset_slope": {"min": -1e-4, "max": 1e-4}})
    else:
        reg_param_dict.update(
            {
                "offset_slope": {
                    "min": -np.nanmedian(bin_std) * factor / (time[-1] - time[0]),
                    "max": np.nanmedian(bin_std) * factor / (time[-1] - time[0]),
                }
            }
        )

    key_list = [
        "amp",
        "sigma_left",
        "sigma_right",
        "f_left",
        "f_right",
        "cen",
        "offset",
        "offset_slope",
    ]
    for key in key_list:
        if key in fits_dict:
            if len(fits_dict[key]) > 0:
                reg_param_dict[key].update(fits_dict[key])

    if "min" not in reg_param_dict["cen"]:
        if cen - time[0] > 120:
            reg_param_dict["cen"]["min"] = max(0.0, cen - 120)
        else:
            reg_param_dict["cen"]["min"] = (
                time[0] + reg_param_dict["sigma_left"]["max"] / 2.0
            )
    if "max" not in reg_param_dict["cen"]:
        if time[-1] - cen > 120:
            reg_param_dict["cen"]["max"] = cen + 120
        else:
            reg_param_dict["cen"]["max"] = (
                time[-1] - reg_param_dict["sigma_right"]["max"] / 2.0
            )

    return reg_param_dict


def update_param_dict(
    param_dict: dict, param_name: str, var_name: str, value: float
) -> dict:
    """Update parameter dictionary.

    Args:
        param_dict: dict
            dictionary containing fit parameters
        param_name: str
            name of the parameter to be updated
        var_name: str
            name of the value to be updated (min, max, mean)
        value: float
            value to be updated to

    Returns:
        param_dict: dict
            updated fit parameter dictionary
    """
    param_dict[param_name][var_name] = value
    return param_dict


def gaus_amp_estimate(signal: np.array) -> Tuple[float, float]:
    """Estimate Gaussian amplitude.

    Args:
        signal: np.array
            1D vector of signal values to be fit
    Returns
        gaus_amp: float
            maximum value of the signal converted to amp
        gaus_amp_min: float
            minimum allowed value of the signal
            min(-gaus_amp, min signal converted to amp, 0)
    """
    # approximate amplitude (Gaussian amplitude is area, signal is height h = a/sigma/sqrt(2*pi))
    amp = np.nanmax(signal) - np.nanmin(signal)
    gaus_amp = amp * 21 * np.sqrt(2 * np.pi)
    gaus_amp_min = np.nanmin(signal) * 21 * np.sqrt(2 * np.pi)
    gaus_amp_min = np.nanmin((-gaus_amp, gaus_amp_min, 0))
    return gaus_amp, gaus_amp_min


def cau_gaus_amp_estimate(signal: np.array) -> Tuple[float, float, float]:
    """Estimate Caughy-Gaussian amplitude.

    Args
        signal: np.array
            1D vector of signal values to be fit
    Returns
        amp: float
            Maximum value of the signal. Peak amplitude
        reg_amp: float
            Maximum value of the signal. Peak amplitude
        reg_amp_min: float
            Minimum allowed value of the signal
            min(-reg_amp, min signal, 0)
    """
    amp = np.nanmax(signal) - np.nanmin(signal)
    reg_amp = np.nanmax(signal) - np.nanmin(signal)
    reg_amp_min = np.nanmin(signal)
    reg_amp_min = np.nanmin((-reg_amp, reg_amp_min, 0))
    return amp, reg_amp, reg_amp_min


def assign_model_params(
    param_dict: dict, allowed_keys: list, signal: np.array, bin_std, **default_args
) -> Tuple[dict]:
    """Assign model parameters.

    Only the variables listed in allowed_keys will be used.
    Default mean values saved in output_dict are defined by default_args.
    Hold or set values are saved over their default in the output_dict.

    Args
        param_dict: dict
            dictionary containing fit parameters
        allowed_keys: list
            variable names to be updated in the model
        signal: np.array
            1D vector of signal values to be fit
        bin_std

        default_args:
            default values for model parameters
                amp=0.0,
                sigma=0.0,
                sigma_left=0.0,
                sigma_right=0.0,
                f_left=0.0,
                f_right=0.0,
                cen=0.0,
                offset=0.0,
                offset_slope=0.0
    Returns
        output_dict: dict
            dictionary containing fit parameters listed in allowed_keys.
            Default to values in default_args when available.
            Updated to set and hold values from param_dict when available.
    """
    output_dict = {}
    for key, val_dict in param_dict.items():
        if key in allowed_keys:
            if key in default_args:
                output_dict[key] = default_args[key]
            for param, p_value in val_dict.items():
                if param in ["hold", "set"]:
                    output_dict[key] = p_value

    if (
        (np.nanmax(signal) > np.nanmedian(bin_std) and np.nanmedian(bin_std) != 0)
        or np.nanmax(signal) > 0.1
    ) and "offset_slope" in allowed_keys:
        output_dict["offset_slope"] = 0.0

    return output_dict


def set_model_params(
    model: Model,
    param_dict: dict,
    allowed_keys: list,
    signal: np.array,
    bin_std,
) -> Tuple[Model, dict]:
    """Set model parameters.

    Only the variables listed in allowed_keys will be used.
    The code uses values in param_dict to update.
        min and max values are set within the model
        hold values are set and not allowed to vary within the model
        set values are set but allowed to vary within the model

    Args
        model: lmfit Model object
        param_dict: dict
            dictionary containing fit parameters
        allowed_keys: list
            variable names to be updated in the model
        signal: np.array
            1D vector of signal values to be fit
        bin_std

    Returns
        model: lmfit Model object
            Updated using parameter hints and the parameter dictionary.
        output_dict: dict
            dictionary containing fit parameters listed in allowed_keys.
            Default to values in default_args when available.
            Updated to set and hold values from param_dict when available.
    """
    for key, val_dict in param_dict.items():
        if key in allowed_keys:
            for param, p_value in val_dict.items():
                if param in ["min", "max"]:
                    model.set_param_hint(key, **{param: p_value})
                elif param == "hold":
                    model.set_param_hint(
                        key, value=p_value, vary=False, min=p_value - 1, max=p_value + 1
                    )
                elif param == "set":
                    model.set_param_hint(key, value=p_value, vary=True)

    if (
        (np.nanmax(signal) > np.nanmedian(bin_std) and np.nanmedian(bin_std) != 0)
        or np.nanmax(signal) > 0.1
    ) and "offset_slope" in allowed_keys:
        model.set_param_hint("offset_slope", value=0.0, vary=False)

    return model


def get_new_ingetral(
    result: ModelResult,
    time: np.array,
    signal: np.array,
    testing: Optional[bool] = False,
) -> Tuple[float, float]:
    """Get integral of raw peak data.

    Data to integrate is identified by peak widths.
    Assume that all of the area is within 8 sigma of the mean and use the rest of the data as a background.
    Baseline average and standard deviation are caluclated.
    Signal is corrected for a baseline offset using the baseline average (when available).
    Corrected peak signal is integrated.

    Args
        result: ModelResult
            Results from a peak fit, containing cen, and sigma or sigma_left and sigma_right.
        time: np.array
            1D array of times (s)
        signal: np.array
            1D array of the signal that was fit

    Returns
        new_integral: float
            Integral of baseline corrected signal over the peak
        baseline_std: float
            Standard deviation of signal that is not part of the peak
    """
    best_cen = result.best_values["cen"]
    if "sigma_left" in result.best_values:
        best_sigma_left = result.best_values["sigma_left"]
    else:
        best_sigma_left = result.best_values["sigma"]
    if "sigma_right" in result.best_values:
        best_sigma_right = result.best_values["sigma_right"]
    else:
        best_sigma_right = result.best_values["sigma"]

    peak_ind = np.intersect1d(
        np.where(time >= (best_cen - 8 * best_sigma_left / 2)),
        np.where(time <= (best_cen + 8 * best_sigma_right / 2)),
    )
    baseline_ind = np.concatenate(
        (
            np.where(time < (best_cen - 8 * best_sigma_left / 2))[0],
            np.where(time > (best_cen + 8 * best_sigma_right / 2))[0],
        )
    )

    if len(baseline_ind) > 0:
        baseline_ave = np.nanmean(signal[baseline_ind])
        baseline_std = np.nanstd(signal[baseline_ind])
        baseline_corrected_signal = signal - baseline_ave
    else:
        baseline_corrected_signal = signal
        baseline_std = np.nan
    if len(peak_ind) > 0:
        dx_median = np.median(np.diff(time))
        dx = np.diff(time)
        bin_edges = np.insert(time[:-1] + dx / 2, 0, time[0] - dx_median / 2)
        bin_edges = np.insert(bin_edges, -1, time[-1] + dx_median / 2)
        dx = np.diff(bin_edges)
        new_integral = sum(baseline_corrected_signal[peak_ind] * dx[peak_ind])
    else:
        new_integral = 0.0

    if testing:
        return (
            new_integral,
            baseline_std,
            peak_ind,
            baseline_ind,
            baseline_corrected_signal,
            dx_median,
            dx,
            bin_edges,
        )
    else:
        return new_integral, baseline_std


def create_bin_std(
    time: np.array, signal: np.array, testing: Optional[bool] = False
) -> np.array:
    """Create bin_std.

    Starting with 10 point wide bins, calculate standard deviation of signal.
    If the median of the stdandard deviation is 0, add 5 points to each bin and repeat.
    Stop if all of the data is included in one bin.

    Args:
        time: np.array
            1D array of times (s)
        signal: np.array
            1D array of the signal that was fit

    Returns:
        bin_std: np.array
            1D array of binned statistic std values
            len: len(time)/10 to len(time)/(len(time)-1)
    """
    bin_div = 10.0
    bin_std = 0.0
    while bin_div < len(time) / 10 and np.nanmedian(bin_std) == 0:
        bin_std, _, _ = stats.binned_statistic(
            signal, time, statistic="std", bins=int(len(time) / bin_div)
        )
        bin_div += 5
    if testing:
        return bin_std, bin_div
    else:
        return bin_std


def update_cen(
    fits_dict: dict,
    gaus_result: ModelResult,
    time: np.array,
    gaus_param_dict: dict,
    reg_param_dict: dict,
) -> Tuple[dict, dict]:
    """Update centering.

    Args:
        fits_dict: dict

        gaus_result: ModelResult
            Results from Gaussian peak fit.
        time: np.array
            1D vector of time data (s).
        gaus_param_dict: dict of gaussian fit parameters
            Values get transfered from fits_dict into this dictionary.
            Otherwise defaults are set based on the other inputs.

            amp: {min: value, max: value, optional(mean: value)}
                min defaults to 10 * gaus_amp_min
                max defaults to 10 * gaus_amp
            sigma: {min: value, max: value, mean: value}
                min defaults to 2* median time difference
                max defaults to 200
                mean defaults to NaN
            cen: {min: value, max: value, optional(mean: value)}
                min: 0, cen-120, or sigma max / 2
                max: final time, cen + 120, or final time - sigma max / 2
            offset: {min: value, max: value, optional(mean: value)}
                min defaults to gaus_amp_min
                max defaults to gaus_amp
            offset_slope: {min: value, max: value, optional(mean: value)}
                min and max default to median bin_std/total time or 2 times the same
        reg_param_dict: dict of Cauchy-Gaussian fit parameters
            Values get transfered from fits_dict into this dictionary.
            Otherwise defaults are set based on the other inputs.

            amp: {min: value, max: value, optional(mean: value)}
                min: defaults to reg_amp_min
                max: defaults to 10 * reg_amp
            sigma_left sigma_right: {min: value, max: value, mean: value}
                min defaults to 2* median time difference
                max defaults to 200
                mean defaults to NaN
            f_left f_right: {min: value, max: value, optional(mean: value)}
                min defaults to 0
                max defaults to 1
                mean defaults to NaN
            cen: {min: value, max: value, optional(mean: value)}
                min: 0, cen-120, or sigma_left max / 2
                max: final time, cen + 120, or final time - sigma_right max / 2
            offset: {min: value, max: value, optional(mean: value)}
                min defaults to reg_amp_min
                max defaults to reg_amp
            offset_slope: {min: value, max: value, optional(mean: value)}
                min and max default to median bin_std/total time or 2 times the same

    Returns:
        fits_dict: dict

        reg_param_dict: dict
            with updated cen min and cen max
    """
    if "cen" not in fits_dict:
        fits_dict["cen"] = {}
    if "min" not in fits_dict["cen"]:
        if gaus_result.best_values["cen"] - time[0] > 60:
            reg_param_dict = update_param_dict(
                reg_param_dict,
                "cen",
                "min",
                max(0, gaus_result.best_values["cen"] - 60),
            )
        else:
            reg_param_dict = update_param_dict(
                reg_param_dict,
                "cen",
                "min",
                time[0] + gaus_param_dict["sigma"]["max"] / 2.0,
            )
    if "max" not in fits_dict["cen"]:
        if time[-1] - gaus_result.best_values["cen"] > 60:
            reg_param_dict = update_param_dict(
                reg_param_dict, "cen", "max", gaus_result.best_values["cen"] + 60
            )
        else:
            reg_param_dict = update_param_dict(
                reg_param_dict,
                "cen",
                "max",
                time[-1] - gaus_param_dict["sigma"]["max"] / 2.0,
            )

    return fits_dict, reg_param_dict


def fit_integrate_data_single(
    time: np.array,
    signal: np.array,
    model_name: Optional[str] = "gaussian",
    fits_dict: Optional[dict] = None,
    **kwargs,
) -> Tuple[ModelResult, ModelResult, float, float, float, float, float, float]:
    """Fit each source to one gaussian peak with allowed zero offset.

    Args
        time: np.array
            vector of time data (s). Must be the same length as signal
        signal: np.array
            vector if signal data. Must be the same length as time
        model_name: optional string, default 'gaussian'
            name of the function to be used to fit the data.
            See above functions for other options.
        fits_dict: optional dict, default None
            dictionary of fit parameters
                fits_dict[param][hold] will be set a truth within the model
                fits_dict[param][set] will be set within the model but allowed to vary
                fits_dict[param][max] will have their maximum within the model set
                fits_dict[param][min] will have their minimum within the model set

        **kwargs
            gaus_result: previously calculated gaussian result from this function

    Returns
        gaus_result: ModelResult
            Results from Gaussian peak fit.
        new_result: ModelResult
            Results from peak fit. Model_name determines function.
        gaus_fit_integral: float
            Integral of Gaussian fit.
        new_fit_integral: float
            Integral of model_name fit.
        gaus_integral: float
            Integral of raw data based on Gaussian peak width.
        new_integral,: float
            Integral of raw data based on model_name peak width.
        baseline_std: float
            Standard deviation of signal that is not part of the peak.
            Based on model_name fit.
        new_fit_integral_error: float
            Error in peak area propigated through the model_name fit.
    """
    weights = None
    if "use_weights" in kwargs:
        if "instrument_error" in kwargs:
            weights = np.ones_like(time) / (kwargs["instrument_error"] ** 2)

    # approximate center and amplitude (Gaussian amplitude is area, signal is height h = a/sigma/sqrt(2*pi))
    gaus_amp, gaus_amp_min = gaus_amp_estimate(signal)
    amp, reg_amp, reg_amp_min = cau_gaus_amp_estimate(signal)
    cen = copy(time[np.nanargmax(signal)])

    bin_std = create_bin_std(time, signal)

    gaus_param_dict = parse_and_set_gaus_params(
        time, signal, bin_std, cen, gaus_amp_min, gaus_amp, fits_dict
    )

    reg_param_dict = parse_and_set_cau_gaus_params(
        time, signal, bin_std, cen, reg_amp_min, reg_amp, fits_dict
    )

    ####################################################################################
    # initial gaussian fit
    if "gaus_result" not in kwargs:
        fit_model = Model(gaussian)
        default_args = {
            "offset": 0.0,
            "offset_slope": 0.0,
            "cen": 0.0,
            "sigma": 60.0,
            "amp": amp,
        }
        allowed_keys = ["amp", "sigma", "cen", "offset", "offset_slope"]
        output_dict = assign_model_params(
            gaus_param_dict, allowed_keys, signal, bin_std, **default_args
        )
        fit_model = set_model_params(
            fit_model, gaus_param_dict, allowed_keys, signal, bin_std
        )

        params = fit_model.make_params(**output_dict)
        gaus_result = fit_model.fit(signal, params, x=time, weights=weights)
    else:
        gaus_result = kwargs["gaus_result"]
    ####################################################################################
    # calculate the peak height based on the gaussian fit
    gaus_fit_height = (
        gaus_result.best_values["amp"]
        / gaus_result.best_values["sigma"]
        / np.sqrt(2 * np.pi)
    )

    # second Gausian fit
    if (
        np.abs(gaus_fit_height) < 0.5
        and np.isnan(gaus_param_dict["sigma"]["mean"]) != True
    ):
        fit_model = Model(gaussian)
        # offset_slope = 0.0
        default_args = {
            "offset": 0.0,
            "offset_slope": 0.0,
            "cen": max(0, gaus_result.best_values["cen"]),
            "sigma": gaus_param_dict["sigma"]["mean"],
            "amp": amp,
        }
        allowed_keys = ["amp", "sigma", "cen", "offset"]
        output_dict = assign_model_params(
            gaus_param_dict, allowed_keys, signal, bin_std, **default_args
        )
        fit_model = set_model_params(
            fit_model, gaus_param_dict, allowed_keys, signal, bin_std
        )

        # set offset slope to 0
        fit_model.set_param_hint("offset_slope", value=0.0, vary=False)
        output_dict["offset_slope"] = 0.0
        params = fit_model.make_params(**output_dict)
        gaus_result = fit_model.fit(signal, params, x=time, weights=weights)
        gaus_fit_height = (
            gaus_result.best_values["amp"]
            / gaus_result.best_values["sigma"]
            / np.sqrt(2 * np.pi)
        )

    gaus_fit_integral = gaussian_area(gaus_fit_height, gaus_result.best_values["sigma"])
    gaus_integral, baseline_std = get_new_ingetral(gaus_result, time, signal)

    ################################################################################################################
    # update centering if guidance is not given in the configuration file
    _, reg_param_dict = update_cen(
        fits_dict,
        gaus_result,
        time,
        gaus_param_dict,
        reg_param_dict,
    )
    ####################################################################################
    if model_name == "gaussian":
        new_result = gaus_result
        new_fit_integral = gaus_fit_integral
        new_integral = gaus_integral
        new_fit_integral_error = None
    elif model_name == "cauchy_gaussian":
        fit_model = Model(cauchy_gaussian)
        default_args = {
            "offset": 0.0,
            "offset_slope": 0.0,
            "cen": max(0, gaus_result.best_values["cen"]),
            "sigma_left": gaus_result.best_values["sigma"],
            "sigma_right": gaus_result.best_values["sigma"],
            "f_left": 0.5,
            "f_right": 0.5,
            "amp": (
                gaus_result.best_values["amp"]
                / gaus_result.best_values["sigma"]
                / np.sqrt(2 * np.pi)
            ),
        }
        allowed_keys = [
            "amp",
            "sigma_left",
            "sigma_right",
            "f_left",
            "f_right",
            "cen",
            "offset",
            "offset_slope",
        ]
        output_dict = assign_model_params(
            reg_param_dict, allowed_keys, signal, bin_std, **default_args
        )
        fit_model = set_model_params(
            fit_model, reg_param_dict, allowed_keys, signal, bin_std
        )

        params = fit_model.make_params(**output_dict)
        new_result = fit_model.fit(signal, params, x=time, weights=weights)
        if model_name == "cauchy_gaussian":
            new_fit_integral = cauchy_gaussian_area(
                new_result.best_values["amp"],
                new_result.best_values["sigma_left"],
                new_result.best_values["sigma_right"],
                new_result.best_values["f_left"],
                new_result.best_values["f_right"],
            )
            error_dict = {
                "amp": new_result.params["amp"].stderr,
                "sigma_left": new_result.params["sigma_left"].stderr,
                "sigma_right": new_result.params["sigma_right"].stderr,
                "f_left": new_result.params["f_left"].stderr,
                "f_right": new_result.params["f_right"].stderr,
            }
            new_fit_integral_error = cauchy_gaussian_area_error_prop(
                new_result.best_values["amp"],
                new_result.best_values["sigma_left"],
                new_result.best_values["sigma_right"],
                new_result.best_values["f_left"],
                new_result.best_values["f_right"],
                error_dict,
            )

            new_integral, baseline_std = get_new_ingetral(new_result, time, signal)
    elif model_name == "rectangle":
        fit_model = Model(rectangle)
        default_args = {
            "offset": 0.0,
            "offset_slope": 0.0,
            "cen": max(0, gaus_result.best_values["cen"]),
            "sigma": gaus_result.best_values["sigma"],
            "amp": (
                gaus_result.best_values["amp"]
                / gaus_result.best_values["sigma"]
                / np.sqrt(2 * np.pi)
            ),
        }
        allowed_keys = ["cen", "offset", "offset_slope", "amp", "sigma", "offset_slope"]
        output_dict = assign_model_params(
            reg_param_dict, allowed_keys, signal, bin_std, **default_args
        )
        fit_model = set_model_params(
            fit_model, reg_param_dict, allowed_keys, signal, bin_std
        )

        params = fit_model.make_params(**output_dict)
        new_result = fit_model.fit(signal, params, x=time, weights=weights)
        if model_name == "rectangle":
            new_fit_integral = rectangle_area(
                new_result.best_values["amp"], new_result.best_values["sigma"]
            )
            new_fit_integral_error = rectangle_area_error_prop(
                new_result.best_values["amp"],
                new_result.best_values["sigma"],
                new_result.params["amp"].stderr,
                new_result.params["sigma"].stderr,
            )
        new_integral, baseline_std = get_new_ingetral(new_result, time, signal)

    return (
        gaus_result,
        new_result,
        gaus_fit_integral,
        new_fit_integral,
        gaus_integral,
        new_integral,
        baseline_std,
        new_fit_integral_error,
    )


def optimize_fit_data(
    time: np.array,
    signal: np.array,
    model_name: Optional[str] = "gaussian",
    fits_dict: Optional[dict] = {},
    **kwargs,
) -> Tuple[ModelResult, ModelResult, float, float, float, float]:
    """Optimize peak fit for each source with allowed zero offset.
    return fit integral and raw integral

    Args
        time: np.array
            vector of time data (s). Must be the same length as signal
        signal: np.array
            vector if signal data. Must be the same length as time
        model_name: optional string, default 'gaussian'
            name of the function to be used to fit the data.
            See above functions for other options.
        fits_dict: optional dict, default {}
            dictionary of fit parameters
                fits_dict[param][hold] will be set a truth within the model
                fits_dict[param][set] will be set within the model but allowed to vary
                fits_dict[param][max] will have their maximum within the model set
                fits_dict[param][min] will have their minimum within the model set

        **kwargs
            gaus_result: ModelResult
                previously calculated gaussian result from this function

    Returns
        gaus_result_final: ModelResult
        new_result_final: ModelResult
        gaus_fit_integral_final: float
        new_fit_integral_final: float
        gaus_integral_final: float
        new_integral_final: float
    """
    if np.any(np.isnan(signal)):
        ind = np.where(np.isnan(signal) != True)[0]
        signal = signal[ind]
        time = time[ind]
    if np.any(np.isnan(time)):
        ind = np.where(np.isnan(time) != True)[0]
        signal = signal[ind]
        time = time[ind]

    # run the model fit
    (
        gaus_result,
        new_result,
        gaus_fit_integral,
        new_fit_integral,
        gaus_integral,
        new_integral,
        _,
        _,
    ) = fit_integrate_data_single(
        time, signal, model_name=model_name, fits_dict=fits_dict, **kwargs
    )

    # compare the integrated fit to the integrated raw data
    if model_name == "gaussian":
        integral = gaus_integral
        fit_integral = gaus_fit_integral
        result = gaus_result
    else:
        integral = new_integral
        fit_integral = new_fit_integral
        result = new_result

    integral_difference = abs(integral - fit_integral)
    relative_integral_difference_previous = abs(integral_difference / integral)

    relative_integral_difference_final = relative_integral_difference_previous
    relative_integral_difference_new = relative_integral_difference_previous
    gaus_result_final = gaus_result
    new_result_final = new_result
    gaus_fit_integral_final = gaus_fit_integral
    new_fit_integral_final = new_fit_integral
    gaus_integral_final = gaus_integral
    new_integral_final = new_integral
    update_difference = 2 * relative_integral_difference_previous

    i = 0
    while (
        (relative_integral_difference_new > 0.2 or result.success == False)
        and i < 100
        and update_difference / relative_integral_difference_previous > 0.001
    ):
        relative_integral_difference_previous = relative_integral_difference_new
        # print('i: %d, relative difference: %0.2e, success: %r, normalized update difference: %1.3f'%(i,relative_integral_difference_new,result.success,update_difference/relative_integral_difference_previous))
        i += 1
        fits_dict = update_fits_dict(result, fits_dict)

        (
            gaus_result,
            new_result,
            gaus_fit_integral,
            new_fit_integral,
            gaus_integral,
            new_integral,
            _,
            _,
        ) = fit_integrate_data_single(
            time, signal, model_name=model_name, fits_dict=fits_dict, **kwargs
        )

        # compare the integrated fit to the integrated raw data
        if model_name == "gaussian":
            integral = gaus_integral
            fit_integral = gaus_fit_integral
            result = gaus_result
        else:
            integral = new_integral
            fit_integral = new_fit_integral
            result = new_result

        integral_difference = abs(integral - fit_integral)
        relative_integral_difference_new = integral_difference / integral
        update_difference = abs(
            relative_integral_difference_new - relative_integral_difference_previous
        )

        if (
            abs(relative_integral_difference_new)
            < abs(relative_integral_difference_final)
            and result.success == True
        ):
            relative_integral_difference_final = relative_integral_difference_new
            gaus_result_final = gaus_result
            new_result_final = new_result
            gaus_fit_integral_final = gaus_fit_integral
            new_fit_integral_final = new_fit_integral
            gaus_integral_final = gaus_integral
            new_integral_final = new_integral
    if gaus_result_final.success == False:
        gaus_fit_integral_final = np.nan
    if new_result_final.success == False:
        new_fit_integral_final = np.nan

    return (
        gaus_result_final,
        new_result_final,
        gaus_fit_integral_final,
        new_fit_integral_final,
        gaus_integral_final,
        new_integral_final,
    )


def update_fits_dict(result: ModelResult, fits_dict: dict) -> dict:
    """Update fits_dict from results value and stderr.

    Args:
        result: ModelResult

        fits_dict: dict

    Returns:
        fits_dict: dict
    """
    parameter_list = list(result.init_params.keys())
    for key in parameter_list:
        if result.init_params[key].vary and result.params[key].stderr != None:
            # if the variable was allowed to vary
            if (result.params[key].stderr + result.params[key].value) > result.params[
                key
            ].max:
                # update max if the stderr is high enough to exceed
                if key not in fits_dict:
                    fits_dict[key] = {}
                fits_dict[key]["max"] = (
                    result.params[key].value + 2 * result.params[key].stderr
                )
            else:
                fits_dict.update({key: {"max": result.params[key].max}})
            if (result.params[key].value - result.params[key].stderr) < result.params[
                key
            ].min:
                # update min if the stderr is high enough to exceed
                if key not in fits_dict:
                    fits_dict[key] = {}
                fits_dict[key]["min"] = (
                    result.params[key].value - 2 * result.params[key].stderr
                )
            else:
                fits_dict[key].update({"min": result.params[key].min})

    return fits_dict
