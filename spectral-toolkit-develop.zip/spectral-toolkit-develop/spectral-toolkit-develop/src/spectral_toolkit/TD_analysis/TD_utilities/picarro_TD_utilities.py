from copy import copy
import glob
import os
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Optional, Tuple
import warnings
from datetime import datetime
import pytz


def parse_picarro_sequence(
    picarro_TD_path: Path,
    timezone: str,
    start_dt: datetime,
    end_dt: datetime,
    step_dict: dict,
    verbose: Optional[bool] = False,
) -> pd.DataFrame:
    """Parse runs from Picarro temperature logs.

    Args:
        picarro_TD_path: Path
            file path where the Picarro run temperature logs are saved
        timezone: str
            pytz timezone string

        start_dt: pd.DataTimeIndex
            start of the experiment as a pandas DateTimeIndex
        end_dt: pd.DateTimeIndex
            end of the experiment as a pandas DateTimeIndex
        step_dict: dict

        verbose: optional boolean, default False
            no longer used...

    Returns:
        sequences: pd.DataFrame
            Pandas dataframe containing sequence data.
            Each line is one run, indexed by a timezone aware datetime index.

            Common columns included:
            sample_volume_mL: volume of sample collected (mL)
            trap_flow: cold trap trapping flow (sccm)
            trap_time: cold trap trap time (min)
            post_sample_purge_time: post sample purge time (min)
            trap_purge_time: trap purge time (min)
            max_flow: maximum flow (sccm)
            min_flow: minimum flow (sccm)
            trap_low_temperature: trap low temperature (C)
            trap_heating_rate: trap heating rate (C/s)
            desorb_time_min: desorb time (min)
    """
    log_name_list = glob.glob(os.path.join(picarro_TD_path, "*log.txt"))
    log_name_list.sort()

    sequence_list = []
    for log_name in log_name_list:
        df_temp = pd.read_csv(log_name, sep=",", index_col=False)

        df_temp.index = pd.to_datetime(1e9 * df_temp["current time"], utc=True)
        tz = pytz.timezone(timezone)
        df_temp.index = df_temp.index.tz_convert(tz)

        if np.all(df_temp.index < start_dt[0]) or np.all(df_temp.index > end_dt[0]):
            continue

        for key in df_temp.keys():
            if key[0] == " ":
                df_temp.rename(columns={key: key[1:]}, inplace=True)

        inds_dict = {}
        for name in step_dict:
            inds_dict[name] = np.where(df_temp["step_num"] == step_dict[name])[0]

        if len(inds_dict["trap"]) == 0:
            warning_str = f"trap step not in {log_name}"
            
            warnings.warn(warning_str, UserWarning)
            continue
        else:
            index_now = df_temp.index[inds_dict["trap"][-1]]  # start of run/end of trap

        dict_now = {}
        if len(inds_dict["final_cool"]) == 0:
            warning_str = f"final cool step not in {log_name}"
            
            warnings.warn(warning_str, UserWarning)
            continue
        else:
            dict_now["end_datetime"] = df_temp.index[
                inds_dict["final_cool"][0]
            ]  # end of last hold

        if len(inds_dict["trap"]) == 0:
            warning_str = f"trap step not in {log_name}"
            
            warnings.warn(warning_str, UserWarning)
            continue
        else:
            dict_now["trap_time"] = (
                df_temp.index[inds_dict["trap"][-1]]
                - df_temp.index[inds_dict["trap"][0]]
            ).total_seconds() / 60

        if "post_sample_purge" in step_dict:
            if len(inds_dict["post_sample_purge"]) == 0:
                warning_str = f"post sample purge step not in {log_name}"
                
                warnings.warn(warning_str, UserWarning)
                continue
            else:
                dict_now["post_sample_purge_time"] = (
                    df_temp.index[inds_dict["post_sample_purge"][-1]]
                    - df_temp.index[inds_dict["post_sample_purge"][0]]
                ).total_seconds() / 60

        if "trap_purge" in step_dict:
            if len(inds_dict["trap_purge"]) == 0:
                warning_str = f"trap purge step not in {log_name}"
                
                warnings.warn(warning_str, UserWarning)
                continue
            else:
                dict_now["trap_purge_time"] = (
                    df_temp.index[inds_dict["trap_purge"][-1]]
                    - df_temp.index[inds_dict["trap_purge"][0]]
                ).total_seconds / 60

        if len(dict_now) > 0:
            df_now = pd.DataFrame(dict_now, index=[index_now])
            sequence_list.append(df_now)

    if len(sequence_list) > 0:
        sequences = pd.concat(sequence_list)
        sequences.index.name = "index"
    else:
        sequences = None

        warning_str = "no sequences available"
        
        warnings.warn(warning_str, UserWarning)

    return sequences


def get_picarro_SAT_log_names(
    picarro_TD_path: Path,
    timezone: str,
    start_dt: datetime,
    end_dt: datetime,
):
    # only grab active run files, not idle files
    log_name_list = [
        f
        for f in glob.glob(os.path.join(picarro_TD_path, "*log.txt"))
        if "idle" not in f
    ]
    log_name_list.sort()
    return_logs = []
    for log_name in log_name_list:
        df_temp = pd.read_csv(log_name, sep=",", index_col=False)

        df_temp.index = pd.to_datetime(1e9 * df_temp["current time"], utc=True)
        tz = pytz.timezone(timezone)
        df_temp.index = df_temp.index.tz_convert(tz)

        if np.all(df_temp.index < start_dt[0]) or np.all(df_temp.index > end_dt[0]):
            continue

        for key in df_temp.keys():
            if key[0] == " ":
                df_temp.rename(columns={key: key[1:]}, inplace=True)

        # do not use a file that doesn't contain the appropriate steps and a desorb flag
        if ~(df_temp["current_state"] == "TRAPPING").any():
            warning_str = f"trap step not in {log_name}"
            
            warnings.warn(warning_str, UserWarning)
            continue
        if ~df_temp["desorb_flag"].astype(bool).any():
            warning_str = f"no active desorption in {log_name}"
            
            warnings.warn(warning_str, UserWarning)
            continue
        if ~(df_temp["current_state"] == "THERMAL_RAMP").any():
            warning_str = f"ramp step not in {log_name}"
            
            warnings.warn(warning_str, UserWarning)
            continue
        if ~(df_temp["current_state"] == "HOLDING").any():
            warning_str = f"hold step not in {log_name}"
            
            warnings.warn(warning_str, UserWarning)
            continue

        return_logs.append(log_name)

    return return_logs


def parse_picarro_SAT_sequence(
    picarro_TD_path: Path,
    timezone: str,
    start_dt: datetime,
    end_dt: datetime,
) -> pd.DataFrame:
    """Parse runs from Picarro temperature logs.

    Args:
        picarro_TD_path: Path
            file path where the Picarro run temperature logs are saved
        timezone: str
            pytz timezone string

        start_dt: pd.DataTimeIndex
            start of the experiment as a pandas DateTimeIndex
        end_dt: pd.DateTimeIndex
            end of the experiment as a pandas DateTimeIndex

    Returns:
        sequences: pd.DataFrame
            Pandas dataframe containing sequence data.
            Each line is one run, indexed by a timezone aware datetime index.

            Common columns included:
            trap_time: cold trap trap time (min)
            end_datetime: datetime index for the end of the desorbtion
            trap_start_datetime: datetime index for the start of the trap
            trap_end_datetime: datetime index for the end of the trap

            sample_volume_mL: volume of sample collected (mL)
            trap_flow: cold trap trapping flow (sccm)
            post_sample_purge_time: post sample purge time (min)
            trap_purge_time: trap purge time (min)
            max_flow: maximum flow (sccm)
            min_flow: minimum flow (sccm)
            trap_low_temperature: trap low temperature (C)
            trap_heating_rate: trap heating rate (C/s)
            desorb_time_min: desorb time (min)
    """
    log_name_list = get_picarro_SAT_log_names(
        picarro_TD_path, timezone, start_dt, end_dt
    )

    sequence_list = []
    for log_name in log_name_list:
        df_temp = pd.read_csv(log_name, sep=",", index_col=False)

        df_temp.index = pd.to_datetime(1e9 * df_temp["current time"], utc=True)
        tz = pytz.timezone(timezone)
        df_temp.index = df_temp.index.tz_convert(tz)

        for key in df_temp.keys():
            if key[0] == " ":
                df_temp.rename(columns={key: key[1:]}, inplace=True)

        dict_now = {}

        trapping_bool = df_temp["current_state"] == "TRAPPING"
        dict_now["trap_time"] = (
            df_temp.index[trapping_bool][-1] - df_temp.index[trapping_bool][0]
        ).total_seconds() / 60

        index_now = df_temp.index[df_temp["desorb_flag"].astype(bool)][
            0
        ]  # start of run/end of trap
        dict_now["end_datetime"] = df_temp.index[df_temp["desorb_flag"].astype(bool)][
            -1
        ]

        dict_now["trap_start_datetime"] = df_temp.index[
            df_temp["current_state"] == "TRAPPING"
        ][0]
        dict_now["trap_end_datetime"] = df_temp.index[
            df_temp["current_state"] == "TRAPPING"
        ][-1]

        if len(dict_now) > 0:
            df_now = pd.DataFrame(dict_now, index=[index_now])
            sequence_list.append(df_now)

    if len(sequence_list) > 0:
        sequences = pd.concat(sequence_list)
        sequences.index.name = "index"
    else:
        sequences = None

        warning_str = "no sequences available"
        
        warnings.warn(warning_str, UserWarning)

    return sequences
