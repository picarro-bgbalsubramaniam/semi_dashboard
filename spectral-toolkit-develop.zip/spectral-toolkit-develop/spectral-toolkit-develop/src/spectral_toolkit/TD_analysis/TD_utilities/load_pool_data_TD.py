import os
from pathlib import Path
from typing import Optional, Tuple, List

import numpy as np
import pandas as pd
import warnings

from data_pooler.persist import get_combolog_from_zpickle

from spectral_toolkit.TD_analysis.TD_utilities.defaults_dict import BLACKLIST_TIMESERIES
from spectral_toolkit.TD_analysis.TD_utilities.utilities_for_pool import progress_bar

from spectral_toolkit.TD_analysis.TD_utilities.TD_compactify import (
    pull_combo_results,
    generate_spectrum_groups,
)

INI_NAME = os.path.join(os.getcwd(), "load_pool_data.ini")


def get_spectra_from_comp(
    comp_df: pd.DataFrame,
    columns_to_drop: Optional[list] = [],
    progress=True,
) -> pd.DataFrame:
    """collect spectral data from combo logs.

    Parameters:
        comp_df: pandas DataFrame
            dataframe with a timezone aware datetimeindex
            columns contain timeseries data from private and combo logs
            additional columns containing filepath information for spectra
        columns_to_drop: optional list, default empty
            list of spectral columns to drop from the data before saving
        progress: optional bool, default True
            boolean indicating if a progress bar should be printed to the terminal

    Raises:

    Returns:
        spectrum_df: pd.DataFrames
            dataframe containing spectral absorbance, big3, model, npoints, nu, partial_fit, residuals, spectrum_index
            indexed by 'index' and 'spectrum_index'
    """
    spectrum_list = []
    spectrum_index = 0
    for i, file_path in enumerate(comp_df["spec_gen_file"]):
        if progress:
            progress_bar(i, len(comp_df))
        with file_path.open("rb") as pp:
            gen = get_combolog_from_zpickle(pp)
            _ = next(gen)
            df = gen.send("fitdata")  # timeseries

            for spectra_count in range(len(df)):
                spectrum_list.append(gen.send(int(spectra_count)))
                # list of dataframes with absorbance, big3, model, npoints, nu, partial_fit, residuals
                spectrum_list[-1]["spectrum_index"] = spectrum_index
                spectrum_list[-1]["broadband_spectrum_id"] = df["spectrum_id"].iloc[
                    spectra_count
                ]
                spectrum_list[-1]["broadband_row_id"] = df["row_id"].iloc[spectra_count]

                spectrum_index += 1

    spectrum_df = pd.concat(spectrum_list)

    spectrum_df["index"] = spectrum_df.index
    spectrum_df.set_index(["index", "spectrum_index"], inplace=True)
    spectrum_df.drop(columns=columns_to_drop, inplace=True)

    return spectrum_df


def remove_blacklist(
    all_col_names: list, blacklist: Optional[List[str]] = BLACKLIST_TIMESERIES
) -> list:
    """Remove black listed columns.

    Args:
    all_col_names: list
        initial list of column names.
    blacklist: optional list of strings
        list of variables to remove if in all_col_names

    Returns:
    col_names: list
        list of column names to keep.
    """
    col_names = []
    for col in all_col_names:
        DNU = False
        for black_list_name in blacklist:
            if black_list_name in col:
                DNU = True
                break
        if not DNU:
            col_names.append(col)
    return col_names


def create_spectral_data_block(
    dfg: pd.DataFrame,
    spectra: List[dict],
    progress_bar_scale: Optional[int] = 1,
    test_num: Optional[int] = None,
) -> Tuple[dict, list]:
    """Create data_block of spectra.

    Args:
        dfg: pd.DataFrame
            dataframe of clustered data consisting of the full time series with transitions removed but without aggregation.

        spectra: list of dictionaries

        progress_bar_scale: optional int, default 1

    Raises:

    Warnings:
        ignoring spectrum
        ignoring group


    Returns:
        data_block: dict
            spectral data
            data_block[{mode}][{group}, {variable}] = {value}
                mode: cavity mode from compactify
                group: concentration group number
                variable: order (nu, partial_fit, pstd, res, restd)
        grouper: list
            list of group values for spectral data
    """
    data_block = {}
    dfg_group_set = set(dfg["_group"])
    # test case: mimic missing groups present in spectral data but missing in dfg
    if test_num is not None:
        for k in range(test_num):
            u = dfg_group_set.pop()
            print(f" TEST: removing group = {u} from the set of possible groups")

    Ngroups = len(dfg_group_set)

    # note that the loop below creates a full array of data for every mode bin reported by the
    # compactify algorithm.  There may be some erratic mode bins that only have a couple valid modes
    # these should not be used for analysis

    j_count = 0
    bad_groups = []
    grouper = []
    for group, spec in spectra:
        # ignore compactified group values that do not exist in dfg (test with test case above)
        if group not in dfg_group_set:
            warning_str = (
                f"spectrum _group = {group} not in dfg.  Ignoring this spectrum."
            )
            print(warning_str)
            warnings.warn(warning_str, UserWarning)
            continue
        # ignore all spectra with duplicate group numbers
        if group in grouper:
            warning_str = f"incoming _group = {group} already in accumlated data.  Ignoring this _group entirely"
            print(warning_str)
            warnings.warn(warning_str, UserWarning)
            if group not in bad_groups:
                bad_groups.append(group)
            continue

        # add spectrum to data_block
        for spec_ind, (mode, partial_fit, pstd, res, restd, nu) in enumerate(
            zip(
                spec.modes,
                spec.partial_fit,
                spec.partial_fit_std,
                spec.residuals,
                spec.residuals_std,
                spec.nu_prime,
            )
        ):
            if mode not in data_block:
                data_block[mode] = np.ones((Ngroups, 5)) * np.nan

            for k, val in enumerate([nu, partial_fit, pstd, res, restd]):
                data_block[mode][j_count, k] = val
                # add the crosstalk vector back in to get "raw" partial fit
                if k == 1 and hasattr(spec, "xtalk"):
                    data_block[mode][j_count, k] += spec.xtalk[spec_ind]

        grouper.append(group)

        progress_bar(j_count + 1, Ngroups, scale=progress_bar_scale)
        j_count += 1

    # mark bad groups as nans to be eliminated during the fitting process
    for j, group in enumerate(grouper):
        if group in bad_groups:
            for mode in data_block.keys():
                data_block[mode][j, :] *= np.nan

    return data_block, grouper


def identify_bad_modes_to_remove(
    data_block: dict,
    grouper: list,
    bad_mode_thresh: Optional[float] = 0.05,
) -> list:
    """Identify the modes that do not contain enough data.

    Args:
        data_block: dict
            spectral data
            data_block[{mode}][{group}, {variable}] = {value}
                mode: cavity mode from compactify
                group: concentration group number
                variable: order (nu, partial_fit, pstd, res, restd)
        grouper: list
            list of group values for spectral data
        bad_mode_thresh: optional float, default 0.05
            fraction of missing data allowed for a particular mode

    Returns:
        bad_modes: list
    """
    bad_modes = []
    for mode in data_block.keys():
        data_block[mode] = data_block[mode][: len(grouper), :]
        bad_points = np.isnan(data_block[mode][:, 0])

        if sum(bad_points) / len(bad_points) >= bad_mode_thresh:
            bad_modes.append(mode)

    return bad_modes


def remove_modes(modes_to_remove: list, data_block: dict) -> dict:
    """Remove modes with insufficient data.

    Args:
        modes_to_remove: list
        data_block: dict
            spectral data
            data_block[{mode}][{group}, {variable}] = {value}
                mode: cavity mode from compactify
                group: concentration group number
                variable: order (nu, partial_fit, pstd, res, restd)

    Returns:
        data_block: dict
            updated spectral data
            data_block[{mode}][{group}, {variable}] = {value}
                mode: cavity mode from compactify
                group: concentration group number
                variable: order (nu, partial_fit, pstd, res, restd)
    """
    for bmode in modes_to_remove:
        bad_data = data_block.pop(bmode)
        nu_bad = bad_data[:, 0]
        bad_ones = np.isnan(nu_bad)
        frac_bad = sum(bad_ones) / len(bad_ones)
        nu_bad_mean = np.nanmean(nu_bad)
        print(
            f"Removing mode {bmode} at {nu_bad_mean:.2f} wavenumbers ({frac_bad * 100} % bad)"
        )
    return data_block


def construct_compact_spectra_dataframe(
    dfg_orig: pd.DataFrame,
    pool_dir: Path,
    include_res: Optional[bool] = False,
    bad_mode_thresh: Optional[float] = 0.05,
    progress_bar_scale: Optional[int] = 1,
):
    """Create compact spectra dataframe.

    This function creates compactified spectra for each clustered group, and then for each frequency
    bin reported, it creates an absorption time series with one data row for each compactified
    spectrum.  These mode bin absorption time series can then be used to fit against the concentration
    time series to determine correction coefficients on a per-bin basis.

    Args:
        dfg_orig: pd.DataFrame
            dataframe of clustered data consisting of the full time series with transitions
            removed but without aggregation
        pool_dir: Path
            location of pool directory
        include_res: optional boolean, default false
            whether to report the residual data frame
        bad_mode_thresh: optional float, default 0.05
            fraction of missing data allowed for a particular mode
        progress_bar_scale: optional int, default 1

    Returns:
        fit_dfg: pandas dataframe of average spectral data in time.
            Columns are frequencies. Indexed by timzone aware datetime index and group.
        res_dfg: optional pandas dataframe of average fit residual data in time.
            Columns are frequencies. Indexed by timzone aware datetime index and group.
    """
    # remove _group from index and rename _conc_group as _group
    # to match what spectral_arithmetic is expecting
    dfg = dfg_orig.reset_index(inplace=False)
    dfg.drop("_group", axis=1, inplace=True)
    dfg.rename(columns={"_conc_group": "_group"}, inplace=True)
    dfg.set_index("_datetime", inplace=True)

    # retrieve combologs results dataframe for full time range
    print("Retrieving combo results dataframe")
    datetimes = dfg.index
    start_time = min(datetimes).tz_localize(None)
    end_time = max(datetimes).tz_localize(None)
    tz = dfg.index.tz.zone

    dfc = pull_combo_results(pool_dir, start_time, end_time, time_zone=tz)

    # compactify spectra in each concentration group
    # the compactify algorithm uses the _group column to combine spectra
    #   it produces
    #     a set of `modes` (which correspond to the number of FSRs away from f0)
    #     a mean, std, and std_err for each bin in nu, partial_fit, and absorption, and residuals

    print("collecting compact spectra")
    # spectra = generate_spectrum_groups(dfg, dfc, max_spectra_count=1000)
    spectra = generate_spectrum_groups(
        dfg,
        dfc,
        keys=["absorbance", "nu_prime", "partial_fit", "residuals", "npoints", "xtalk"],
    )

    data_block, grouper = create_spectral_data_block(
        dfg,
        spectra,
        progress_bar_scale=progress_bar_scale,
    )

    # trim block to the right length in the event that the number of groups found from
    #  generate_spectrum_groups isn't the same as the unique groups in the incoming dataframe dfg_orig
    # identify modes with insufficient data for removal
    bad_modes = identify_bad_modes_to_remove(
        data_block, grouper, bad_mode_thresh=bad_mode_thresh
    )

    data_block = remove_modes(bad_modes, data_block)

    fit_dfg, res_dfg = make_fit_dfg_from_data_block(
        dfg, data_block, grouper, include_res=include_res
    )

    return fit_dfg, res_dfg


def make_fit_dfg_from_data_block(
    dfg: pd.DataFrame,
    data_block: dict,
    grouper: list,
    include_res: Optional[bool] = False,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Construct dataframe that looks like original fit_dfg dataframe.

    Args:
        dfg: pd.DataFrame
            dataframe of clustered data consisting of the full time series with transitions removed but without aggregation.
        data_block: dict
            spectral data
            data_block[{mode}][{group}, {variable}] = {value}
                mode: cavity mode from compactify
                group: concentration group number
                variable: order (nu, partial_fit, pstd, res, restd)
        grouper: list
            list of group values for spectral data
        include_res: optional boolean, default false
            whether to report the residual data frame

    Returns:
        fit_dfg: pandas dataframe of average spectral data in time.
            Columns are frequencies. Indexed by timzone aware datetime index and group.
        res_dfg: optional pandas dataframe of average fit residual data in time.
            Columns are frequencies. Indexed by timzone aware datetime index and group.
    """
    # create datetime lookup to group
    datetimes = {}
    for _group, dframe in dfg.groupby("_group"):
        datetimes[_group] = dframe.index.mean()

    # construct dataframe that looks like Kai's original dataframe
    # first make a list of FSR grid modes
    modes = list(data_block.keys())
    modes.sort()

    # create multiIndex for columns consisting of nu & nanmean, nanstd
    coltups = []
    indx = []
    for mode in modes:
        nu = np.nanmean(data_block[mode][:, 0])
        for label in ["nanmean", "nanstd"]:
            coltups.append((nu, label))

    cols = pd.MultiIndex.from_tuples(coltups)

    # create a row index consisting of _conc_group and _datetime
    indx = pd.MultiIndex.from_tuples(
        [(grp, datetimes[grp]) for grp in grouper], names=["_conc_group", "_datetime"]
    )

    # create 2D array data for partial_fit and for residuals and create dataframes for each
    print("Creating partial fit dataframe")
    data_array = np.zeros((len(indx), len(modes) * 2))

    for i, mode in enumerate(modes):
        data_array[:, i * 2] = data_block[mode][:, 1]
        data_array[:, i * 2 + 1] = data_block[mode][:, 2]

    fit_dfg = pd.DataFrame(data_array, columns=cols, index=indx)

    if include_res:
        print("Creating residuals dataframe")
        res_array = np.zeros((len(indx), len(modes) * 2))
        for i, mode in enumerate(modes):
            res_array[:, i * 2] = data_block[mode][:, 3]
            res_array[:, i * 2 + 1] = data_block[mode][:, 4]

        res_dfg = pd.DataFrame(res_array, columns=cols, index=indx)
    else:
        res_dfg = pd.DataFrame()

    return fit_dfg, res_dfg
