from copy import copy
import numpy as np
import pandas as pd
from typing import Tuple, Optional

from sklearn.decomposition import FastICA


def canary_ICA_analysis(
    df: pd.DataFrame, ICA_dict: dict, time_name: str
) -> Tuple[dict, pd.DataFrame]:
    """
    analyzes Canary compounds using independent component analysis

    Parameters:
        df: pd.DataFrame
        ICA_dict: dict
        time_name: str

    Returns:
        ica_results: dict
        ica_df: pd.DataFrame
    """
    ica = FastICA(n_components=ICA_dict["n_components"], whiten=True)

    df = copy(df)
    df.dropna(axis=0, inplace=True, subset=ICA_dict["canary_names"])

    signal = df[ICA_dict["canary_names"]].to_numpy(
        dtype=np.float
    )  # spectral_data['fit_array'].T
    #########NORMALIZE TO PRECISION
    for i, canary in enumerate(ICA_dict["canary_names"]):
        signal[:, i] /= np.sqrt(3.0 * ICA_dict["precisions"][f"{canary}_ppb"])
        if "broadband_gasConcs" in canary:  # scale if raw from fitter
            signal[:, i] *= 1e9 / (np.sqrt(1e9))
    #########NORMALIZE TO PRECISION

    ica_results = {}
    ica_results["sources"] = ica.fit_transform(signal)
    ica_results["mixing_matrix"] = ica.mixing_
    ica_results["canary_names"] = ICA_dict["canary_names"]

    # create model function dictionary
    ica_results["model_functions"] = {}
    colnames = []
    for i in range(ica_results["mixing_matrix"].shape[1]):
        ica_results["model_functions"][f"ica_unk_{i}"] = ica_results["mixing_matrix"][
            :, i
        ]
        colnames.append(f"ica_unk_{i}")
    ica_df = pd.DataFrame(data=ica_results["sources"], columns=colnames)

    if time_name == "index":
        ica_df[time_name] = df.index
    else:
        ica_df[time_name] = df.loc[time_name]
    ica_df.set_index(time_name, inplace=True)

    return ica_results, ica_df


def create_canary_FOM(
    ica_results: dict,
    df: pd.DataFrame,
    abs_thresh: Optional[float] = 3.0,
    rel_ratio: Optional[float] = 0.1,
) -> pd.DataFrame:
    """
    Create Canary figure of merit timeseries from known ratios and concentrations.

    Parameters:
        ica_results: dict
        df: pd.DataFrame
        abs_threshold: float
        rel_ratio: float

    Returns:
        df: pandas DataFrame
            updated dataframe containing canary_FOM timeseries
    """
    df = copy(df)
    for i, (unk_name, ratio_values) in enumerate(
        ica_results["model_functions"].items()
    ):
        df[f"canary_FOM_{i}"] = 0.0
        # sort canaries
        canary_names = ica_results["canary_names"]
        ranking = np.argsort(ratio_values)[::-1]
        rel_thresh = np.nanmax(np.abs(ratio_values)) * rel_ratio

        for rank in ranking:
            canary = canary_names[rank]
            ratio = ratio_values[rank]
            if np.abs(ratio) >= abs_thresh and np.abs(ratio) >= rel_thresh:
                df[f"canary_FOM_{i}"] += df[canary] * ratio

        overall_average = np.nanmean(df[f"canary_FOM_{i}"])
        overall_median = np.nanmedian(df[f"canary_FOM_{i}"])
        if overall_average < -0.001 and overall_median < -0.001:
            df[f"canary_FOM_{i}"] *= -1
    return df
