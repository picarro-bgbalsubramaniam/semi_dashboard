import os
import pandas as pd

from typing import Dict, Any, Tuple

os.environ["LOLOGGER_SERVERLESS"] = "1"  # put this above all

from spectral_toolkit.sam_analysis.compound_identification import (
    ProcessStepSpectrum,
    IsoType,
)

# from SAT, updated for TD
def _create_return_data_TD(
    fit_results: ProcessStepSpectrum,
    stats: Dict,
    corr_data: Dict,
    fit_data: Dict,
    spec_data: Dict,
    cid_list_num: int,
    exp_name: str,
    iso_type: IsoType,
) -> Tuple[
    Dict[str, pd.DataFrame],
    Dict[int, Dict[str, pd.DataFrame]],
    Dict[int, Dict[str, Any]],
]:
    """
    Convenience function to assemble all the needed metadata from recursive fitter.
    This will be refactored with data models after validation of functionality
    """
    score = [val for val in stats.values()]
    subset_df = pd.DataFrame(score, index=stats.keys(), columns=["frequency"])
    subset_df.sort_values("frequency", inplace=True, ascending=False)

    data_key_corr = f"{exp_name}_list_{cid_list_num}_{iso_type.value}"
    corr_data[data_key_corr] = subset_df
    fit_data[cid_list_num] = {}
    for num, fit_df in fit_results.dfs.items():
        data_key_fit = f"{exp_name}_list_{cid_list_num}_fit_{num}"
        fit_data[cid_list_num].update({data_key_fit: fit_df})

    spec_data[cid_list_num] = {
        "nu": fit_results.nu,
        "loss": fit_results.loss,
        "err": fit_results.std_err,
        "alist": fit_results.a_list,
        "pnames": fit_results.parameter_names,
        "fit_poly": fit_results.fit,
    }
    return (corr_data, fit_data, spec_data)
