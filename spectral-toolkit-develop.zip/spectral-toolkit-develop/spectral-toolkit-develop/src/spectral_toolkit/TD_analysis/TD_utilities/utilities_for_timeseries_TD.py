import numpy as np
import pandas as pd
from datetime import datetime

from pathlib import Path
import pytz
from scipy.interpolate import interp1d
from typing import Optional, Tuple

from spectral_toolkit.TD_analysis.TD_utilities.defaults_dict import name_dict
from spectral_toolkit.TD_analysis.TD_utilities.time_conversions import (
    timestr_to_datetime,
)

# @profile
def process_data(
    df: pd.DataFrame,
    start_dt: datetime,
    end_dt: datetime,
    # times_dict: dict,
    filters: list = [],
    timezone: str = "US/Pacific",
    tz: Optional[pytz.timezone] = None,
) -> pd.DataFrame:
    """Filter dataframe data based on time and other filters.

        The dataframe will be filtered for time and "SpectrumID" (if present in df) as well as any other filters
        defined in the filters list.

    Parameters:
        df: pd.DataFrame
            Dataframe with a timzone aware DateTimeIndex.
        times_dict: dictionary
            Dictionary containing numbered events. Keys are integers for each event.
            Each event contains: {'times':(start_date_time, end_date_time)}
            start_date_time and end_date_time are both strings with formatting YYYYMMDD_HHMMSS or YYYYMMDD_HHMM
        filters: list, optional, default empty
            List of filter conditions. Each list element is a dictionary containing the keys 'key' and 'condition'.
                filters.append({'key':new_key, 'condition':condition_string})
        timezone: string, optional, default "US/Pacific"
            String of the pytz timezone name.
        tz: pytz.timezone, optional, default None
            pytz timezone object. If it is not assigned, "timezone" will be used to set "tz"

    Raises:


    Returns:
        df: pd.DataFrame
            The new dataframe to be output has had all filters applied to it and unwanted data discarded.
    """
    if tz is None:
        tz = pytz.timezone(timezone)

    df = filterData(filters, df)

    good = (df.index - df.index[0]).total_seconds() >= 0
    if "SpectrumID" in df:
        use_100 = True
        for f in filters:
            if f["key"] == "SpectrumID":
                use_100 = False
        if use_100:
            good &= df["SpectrumID"] == 100

    # add mask for specific timing in parameters
    bool_keep = np.zeros(len(good), dtype=bool)

    # for event in times_dict:
    bool_keep |= good_times(df, start_dt=start_dt, end_dt=end_dt)
    good &= bool_keep

    df = df[good]

    return df


# @profile
def good_times(
    df: pd.DataFrame,
    start_dt: Optional[datetime] = None,
    end_dt: Optional[datetime] = None,
    event_times_dict: Optional[dict] = None,
    start_date_time: Optional[str] = None,
    end_date_time: Optional[str] = None,
    timezone: str = "US/Pacific",
    tz: Optional[pytz.timezone] = None,
) -> bool:
    """Filter dataframe data based on time.

        The start and end times are determined from the 0th and 1st entries in event_times_dict.
        The timezeone aware DateTimeIndex in df is compared to the start and end times and
        a boolean array is populated, indicating which data is within the time range.

    Parameters:
        df: pd.DataFrame
            Dataframe with a timzone aware DateTimeIndex.
        event_times_dict: dictionary
            Dictionary containing numbered events. Keys are integers for each event.
            Each event contains: {'times':(start_date_time, end_date_time)}
            start_date_time and end_date_time are both strings with formatting YYYYMMDD_HHMMSS or YYYYMMDD_HHMM
        timezone: string, optional, default "US/Pacific"
            String of the pytz timezone name.
        tz: pytz.timezone, optional, default None
            pytz timezone object. If it is not assigned, "timezone" will be used to set "tz"

    Raises:

    Returns:
        bool_keep: bool
            Array of boolean values corresponding to the data in df.
            An element is true if the DateTimeIndex of the df is between the start and end times.
    """
    if tz is None:
        tz = pytz.timezone(timezone)
    bool_keep = np.ones(len(df.index)).astype(bool)
    if start_date_time is None and event_times_dict is not None:
        start_date_time = event_times_dict[0]
    if end_date_time is None and event_times_dict is not None:
        end_date_time = event_times_dict[1]
    if start_dt is None and start_date_time is not None:
        start_dt = tz.localize(timestr_to_datetime(start_date_time))
    if end_dt is None and end_date_time is not None:
        end_dt = tz.localize(timestr_to_datetime(end_date_time))

    if start_dt is not None:
        bool_keep &= df.index >= start_dt
    if end_dt is not None:
        bool_keep &= df.index <= end_dt

    return bool_keep


# @profile
def find_name(name: str, df: pd.DataFrame, verbose=True) -> Tuple:
    """Identify the alternative name and multiplication factor for a give variable.

        name_dict from defaults_dict.py is searched for the variable name (name).
            If the variable is in name_dict, then the new name and factor are retrieved.
                Then the new name is compared to variables within the dataframe (df).
                If the new name, a short version of it, or the original name are within the dataframe
                the corresponding name and factor are returned.
            If the variable is not in name_dict, then the name and a short version of the name
                are compared to variables within the dataframe. If one is within the dataframe
                the corresponding name and a factor of 1 are returned.

    Parameters:
        name: str
            Variable name requested. All possible variables that have alternate names are defined in defaults_dict.py.
        df: pd.DataFrame
            Dataframe with a timzone aware DateTimeIndex and desired data.

    Raises:

    Returns:
        Tuple
            First value in the tuple return is the name of the variable as it is in the dataframe.
            Second value in the tuple return is the data factor or 'timestamp", which indicates that the conversion should be to timestamp.
    """
    if name in name_dict["new"]:
        data_name = name_dict["new"][name][0]
        data_factor = name_dict["new"][name][1]
        data_name_bits = data_name.split("_")
        short_data_name = "_".join(data_name_bits[1:])
        if data_name in df:
            return (data_name, data_factor)
        elif short_data_name in df:
            return (short_data_name, 1.0)
        elif name in df:
            return (name, 1.0)
        elif name == "JULIAN_DAYS":
            return (name, "timestamp")
        elif name == "index":
            return (name, "timestamp")
        elif verbose:
            print(f"\t {name} aka {data_name} is not in the data")
            return (None, None)
        else:
            return (None, None)
    else:
        name_bits = name.split("_")
        short_name = "_".join(name_bits[1:])
        if name in df:
            return (name, 1.0)
        elif short_name in df:
            return (short_name, 1.0)
        elif name == "JULIAN_DAYS":
            return (name, "timestamp")
        elif name == "index":
            return (name, "timestamp")
        elif verbose:
            print(f"{name} is not in the data")
            return (None, None)
        else:
            return (None, None)


# @profile
def get_all_data(name: str, df: pd.DataFrame, verbose=True) -> pd.Series:
    """Get and return the requested variable data from df.

        The appropriate variable name and factor are gotten from find_name.
        For time type data, the DateTimeIndex is converted to timestamp and returned.
        For all other data, the data is collected from the dataframe and scaled using the factor.

    Parameters:
        name: str
            Variable name requested. All possible variables that have alternate names are defined in defaults_dict.py.
        df: pd.DataFrame
            Dataframe with a timzone aware DateTimeIndex and desired data.

    Raises:

    Returns:
        pd.Series
            For time type variables, timestamp is returned based on df.index.
            For all other variables, a series of the data is returned.
    """
    new_name, data_factor = find_name(name, df, verbose=verbose)
    if name == "JULIAN_DAYS" and data_factor == "timestamp":
        df_dt = pd.DatetimeIndex(df.index)
        return (
            df_dt.dayofyear
            + df_dt.hour / 24.0
            + df_dt.minute / (24.0 * 60)
            + df_dt.second / (24.0 * 60 * 60)
        )
    elif data_factor == "timestamp":
        return df.index.values.astype(np.int64) // 10**9
    else:
        return df[new_name] * data_factor


# @profile
def filterData(filters: list, df: pd.DataFrame) -> pd.DataFrame:
    """take a filterDeck object and clean df.

        Each of the elements in the filters list is applied to remove
        data based on the conditions defined therein.

    Parameters:
        filters: list of dictionaries
            Each element of the filters list is a dictionary containing 'key' and 'condition'.
            'key' is the variable name on which to filter data.
            'condition' is a string of a logical statement indicating what data to exclude.
        df: pd.DataFrame
            Dataframe with a timzone aware DateTimeIndex and desired data.

    Raises:

    Returns:
        df: pd.DataFrame
            For time type variables, timestamp is returned based on df.index.
            For all other variables, a series of the data is returned.
    """

    for f in filters:
        df = cleaner(df, f["key"], f["condition"])
    return df


# @profile
def add_var_data(
    var_name: str,
    data_vector: np.array,
    df: pd.DataFrame,
    overwrite: Optional[bool] = False,
    index_vector: Optional[np.array] = None,
) -> pd.DataFrame:
    """Add additional data columns to a dataframe.

        A new variable with column header to be var_name and values in data_vector will be added to df.
        If overwrite is true, it will overwrite the same variable if it already exists.
        If the data_vector is not the right length, index_vector must also be input to indicate what indices the data correspond to.

    Parameters:
        var_name: str
            name of the variable to be added to the dataframe. This will be the column header within the dataframe.
        data_vector: np.array
            1D array of values of var_name. This must be the same length as df.index or index_vector must be provided.
        df: pd.DataFrame
            Dataframe with a timzone aware DateTimeIndex and desired data.
        overwrite: optional boolean, default False
            boolean to indicate if the variable should overwrite already existing data within the dataframe
        index_vector: optional np.array, default None
            1D array of df index values that correspond to each of the values in data_vector.


    Raises:

    Returns:
        df: pd.DataFrame
            Dataframe containing the original dataset plus the added column.
    """
    if index_vector is None:
        if len(data_vector) != len(df.index):
            print("Data length does not match internal data array.")
        elif var_name in df and overwrite == False:
            print("Variable is already in the dataset. Rename it.")
        elif var_name in df and overwrite == True:
            df[var_name] = data_vector
            print("Variable is already in the dataset. It was rewritten.")
        else:
            df[var_name] = data_vector
    else:
        if var_name not in df:
            df[var_name] = data_vector
        df.iloc[index_vector, df.columns.get_loc(var_name)] = data_vector
    return df


# @profile
def add_multiple_var_data(
    x_name: str,
    x_vector: np.array,
    df_from: pd.DataFrame,
    df_to: pd.DataFrame,
    overwrite: Optional[bool] = False,
) -> pd.DataFrame:
    """interpolate data from one dataset and copy it into a second dataset.

        Data from df_from is converted to the same index values as df_to and then copied into df_to.

    Parameters:
        x_name: str
            variable name of the independent index variable in both dataframes
        x_vector: np.array
            1D array of values of x_name from df_to. This is the independent index variable along which to interpolate
        df_from: pd.DataFrame
            Dataframe from which to copy data. Dataframe with a timzone aware DateTimeIndex and desired data.
        df_to: pd.DataFrame
            Dataframe into which data will be copied. Dataframe with a timzone aware DateTimeIndex and desired data.
        overwrite: optional boolean, default False
            boolean to indicate if the variable should overwrite already existing data within the dataframe


    Raises:

    Returns:
        df_to: pd.DataFrame
            Dataframe containing combined dataset
    """
    for var_name in df_from:
        data_interp = interp1d(
            x_vector,
            get_all_data(var_name, df_from),
            bounds_error=False,
            fill_value="extrapolate",
            kind="nearest",
        )
        data_vector = data_interp(get_all_data(x_name, df_to))
        df_to = add_var_data(var_name, data_vector, df_to, overwrite=overwrite)

    return df_to


# @profile
def cleaner(df: pd.DataFrame, key: str, condition: str) -> pd.DataFrame:
    """clean data based on a given column name & condition (in an eval statement, where y is the variable name to be evaluated).

    Parameters:
        df: pd.DataFrame
            Dataframe with a timzone aware DateTimeIndex and desired data.
        key: str
            variable name on which to filter data.
        condition: str
            logical statement indicating what data to exclude.

    Raises:

    Returns:
        df: pd.DataFrame
            filtered dataframe
            For time type variables, timestamp is returned based on df.index.
            For all other variables, a series of the data is returned.
    """

    # df = df.dropna()  # remove NaNs
    condition = condition.replace("y", "df[key]")
    eval(f"df.drop(index=df[{condition}].index, inplace=True)")
    # NOTE: mutates input df

    return df
