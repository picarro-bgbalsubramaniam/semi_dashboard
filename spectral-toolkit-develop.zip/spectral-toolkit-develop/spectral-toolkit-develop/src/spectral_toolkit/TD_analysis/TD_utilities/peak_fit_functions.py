# -*- coding: utf-8 -*-
"""
functions for various peak fitting

kmskog 5/29/19
"""
import numpy as np

from typing import Optional, Tuple, List, Dict


def gaussian(
    x: np.array,
    amp: float,
    cen: float,
    sigma: float,
    offset: float,
    offset_slope: float,
) -> np.array:
    """1-d gaussian: gaussian(x, amp, cen, sigma, offset)"""
    return (
        (amp / (np.sqrt(2 * np.pi) * sigma))
        * np.exp(-((x - cen) ** 2) / (2 * sigma**2))
        + offset
        + offset_slope * x
    )


def gaussian_area(height: float, sigma: float) -> float:
    """
    calculates the analytical solution for the area under a Gaussian

    INPUT
    height: height of the Gaussian peak. amp/sigma/np.sqrt(2*np.pi)
    sigma
    """

    return height * sigma * np.sqrt(2 * np.pi)


def cauchy_gaussian(
    x: np.array,
    amp: float,
    cen: float,
    sigma_left: float,
    sigma_right: float,
    f_left: float,
    f_right: float,
    offset: float,
    offset_slope: float,
) -> np.array:
    """
    calculate a peak based on the Cauchy-Gaussian equation

    INPUTS
    x: independent variable
    amp: amplitude of the peak
    cen: center of the peak in the same units as x
    sigma_left: standard deviation of the peak in x for the left side
    sigma_right: standard deviation of the peak in x for the right side
    f_left
    f_right
    offset: constant offset in the dependent variable
    """

    left_ind = np.where(x < cen)[0]
    right_ind = np.where(x > cen)[0]
    cen_ind = np.where(x == cen)[0]

    result = np.zeros(len(x))
    result[left_ind] = amp * (
        f_left * np.exp(-((x[left_ind] - cen) ** 2) / (2.0 * sigma_left**2))
        + (1 - f_left) * sigma_left**2 / (sigma_left**2 + (x[left_ind] - cen) ** 2)
    )

    result[right_ind] = amp * (
        f_right * np.exp(-((x[right_ind] - cen) ** 2) / (2.0 * sigma_right**2))
        + (1 - f_right)
        * sigma_right**2
        / (sigma_right**2 + (x[right_ind] - cen) ** 2)
    )

    result[cen_ind] = amp

    result += offset
    result += offset_slope * x

    return result


def cauchy_gaussian_area(
    amp: float, sigma_left: float, sigma_right: float, f_left: float, f_right: float
) -> float:
    """Calculates the analytical solution for the area under a Cauchy-Gaussian.

    Args
        amp: float
            amplitude of the peak
        sigma_left: float
            standard deviation of the peak in x for the left side
        sigma_right: float
            standard deviation of the peak in x for the right side
        f_left: float
            fraction of left side that is gaussian. Remainder is Cauchy
        f_right: float
            fraction of right side that is gaussian. Remainder is Cauchy

    Returns:
        area: float
            analytical solution for the area under the defined Cauchy-Gaussian peak.
    """

    return amp * (
        np.sqrt(np.pi / 2.0) * (f_left * sigma_left + f_right * sigma_right)
        + (np.pi / 2.0) * ((1 - f_left) * sigma_left + (1 - f_right) * sigma_right)
    )


def cauchy_gaussian_amp_partial_derivative(
    sigma_left: float,
    sigma_right: float,
    f_left: float,
    f_right: float,
):

    ddamp = (np.pi / 2.0) * (
        (1 - f_left) * sigma_left + (1 - f_right) * sigma_right
    ) + np.sqrt(np.pi / 2.0) * (f_left * sigma_left + f_right * sigma_right)

    return ddamp


def cauchy_gaussian_f_partial_derivative(amp: float, sigma_side: float):
    ddf = (amp / 2.0) * (np.sqrt(2.0 * np.pi) - np.pi) * sigma_side
    return ddf


def cauchy_gaussian_sigma_partial_derivative(amp: float, f_side: float):
    ddsigma = (amp / 2.0) * (np.sqrt(2.0 * np.pi) * f_side - np.pi * f_side + np.pi)
    return ddsigma


def cauchy_gaussian_area_error_prop(
    amp: float,
    sigma_left: float,
    sigma_right: float,
    f_left: float,
    f_right: float,
    error_dict: Dict[str, float],
) -> float:
    """Calculates the error in the area of a Cauchy-Gaussian peak based on the error in the fit.

    Args
        amp: amplitude of the peak
        sigma_left: standard deviation of the peak in x for the left side
        sigma_right: standard deviation of the peak in x for the right side
        f_left
        f_right
        error_dict:
            amp: error in the amplitude of the peak
            sigma_left: error in the standard deviation of the peak in x for the left side
            sigma_right: error in the standard deviation of the peak in x for the right side
            f_left
            f_right

    Returns:
        area_error: float
            Error in the calculated area under a Cauchy-Gaussian peak.
    """
    partial_deriv_dict = {}
    # partial derivatives
    partial_deriv_dict["amp"] = cauchy_gaussian_amp_partial_derivative(
        sigma_left,
        sigma_right,
        f_left,
        f_right,
    )
    partial_deriv_dict["f_left"] = cauchy_gaussian_f_partial_derivative(amp, sigma_left)
    partial_deriv_dict["sigma_left"] = cauchy_gaussian_sigma_partial_derivative(
        amp, f_left
    )
    partial_deriv_dict["f_right"] = cauchy_gaussian_f_partial_derivative(
        amp, sigma_right
    )
    partial_deriv_dict["sigma_right"] = cauchy_gaussian_sigma_partial_derivative(
        amp, f_right
    )

    variance_dict = {}
    for var, dd_var in partial_deriv_dict.items():
        if var in error_dict:
            var_error = error_dict[var]
            if dd_var is not None and var_error is not None:
                variance_dict[var] = (dd_var**2) * (var_error**2)
            else:
                variance_dict[var] = 0.0
        else:
            variance_dict[var] = 0.0

    variance = 0
    for var, value in variance_dict.items():
        variance += value

    if variance != 0.0:
        area_error = np.sqrt(variance)
    else:
        area_error = np.nan

    return area_error


def cauchy_gaussian_height(
    area: float, sigma_left: float, sigma_right: float, f_left: float, f_right: float
) -> float:
    """Calculates the height from analytical solution for the area under a Cauchy-Gaussian.

    Args
        area: area of the peak
        sigma_left: standard deviation of the peak in x for the left side
        sigma_right: standard deviation of the peak in x for the right side
        f_left
        f_right
    Returns:
        height: float
    """
    return area / (
        np.sqrt(np.pi / 2.0) * (f_left * sigma_left + f_right * sigma_right)
        + (np.pi / 2.0) * ((1 - f_left) * sigma_left + (1 - f_right) * sigma_right)
    )


def rectangle(
    x: np.array,
    amp: float,
    cen: float,
    sigma: float,
    offset: float,
    offset_slope: float,
) -> np.array:
    """Function that creates a binary pulse that is amp tall, centered on cen, and sigma wide. All offset by offset.

    Args
        x: independent variable (e.g. time)
        amp: amplitude of the pulse
        cen: center of the pulse in the same units as x
        sigmal: width of the pulse in the same units as x
        offset: constant offset in the dependent variable
        offset_slope:
    Returns:
        result: np.array
    """
    result = np.ones(len(x)) * 0.0
    ind = np.intersect1d(
        np.where(x >= (cen - sigma / 2.0)), np.where(x <= (cen + sigma / 2.0))
    )
    result[ind] = amp
    result += offset
    result += offset_slope * x
    return result


def rectangle_area(amp: float, sigma: float) -> float:
    """Calculate the area in a rectangular fit."""
    return amp * sigma


def rectangle_area_error_prop(
    amp: float, sigma: float, amp_error: float, sigma_error: float
) -> float:
    """
    calculate the error in rectangular area based on error in amplitude and width
    """
    if amp_error != None:
        amp_rsd = amp_error / amp
    else:
        amp_rsd = np.nan
    if sigma_error != None:
        sigma_rsd = sigma_error / sigma
    else:
        sigma_rsd = np.nan

    area_rsd = np.sqrt(amp_rsd**2 + sigma_rsd**2)
    area = rectangle_area(amp, sigma)

    return area_rsd * area
