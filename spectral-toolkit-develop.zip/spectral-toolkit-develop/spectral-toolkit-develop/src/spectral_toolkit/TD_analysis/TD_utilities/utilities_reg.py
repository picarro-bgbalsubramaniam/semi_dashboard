import os

CONFIG_FILE = "reg_config/config_unks_markes.yaml"

# Define directories for each analysis type
USE_DIR_DICT_KEYS = {
    "parse_markes_sequences": "MarkesDIR",
    # parsing markes sequence files
    "parse_markes": "MarkesDIR",
    # parsing markes instrument files
    "parse_picarro_TD_sequences": "PicarroDIR",
    # parsing Picarro TD sequence files
    "compile_picarro_TD": "PicarroDIR",
    # compile picarro TD files
    "parse_combo_spectra": "comboDIR",
    # parsing combo log spectral data
    "timeseries": "timeseriesDIR",
    # plot timeseries data
    "ICA_analysis": "ICADIR",
    # regular ICA analysis
    "unknown_ICA": "unknownICADIR",
    # unknown ID of ICA derived spectra
    "peak_finding_FOM": "FOMDIR",
    # PeakFinder on figure of merit analysis
    "FOM_correlation": "FOMDIR",
    # figure of merit correlation analysis
    "unknown_FOM": "unknownFOMDIR",
    # unknown ID of spectra derived from FOM peaks
    "ICA_canary_analysis": "canaryICADIR",
    # ICA analysis of canary compound concentrations
    "unknown_canary_FOM": "unknowncanaryFOMDIR",
    # unknown ID of canary derived spectra
    "fit_compiled_TD_analysis": "fitDIR",
    # fit TD data
    "flow_precon_analysis": "preconDIR",
    # calculate precon from flow
    "TD_precon_analysis": "preconDIR",
    # analyze TD data through preconcentration
    "TD_report": "preconDIR",
    # report TD data
    "other": "loadDIR"
    # mainly initial timeseries data from combo and private logs
}

# analyses that are done on a per-run basis
EVENT_ANALYSIS_LIST = [
    "parse_markes",
    "ICA_canary_analysis",
    "ICA_analysis",
    "unknown_FOM",
    "peak_finding_FOM",
    "FOM_correlation",
    "unknown_canary_FOM",
    "parse_combo_spectra",
    "timeseries",
    "fit_compiled_TD_analysis",
    "flow_precon_analysis",
    "compile_picarro_TD",
]
# analyses that are done on a per-run basis for n cid lists
EVENT_CID_LIST = ["unknown_ICA"]

EVENT_LIST = []

# def get_input(config_file=CONFIG_FILE):
#     cfg_dir = os.path.dirname(os.path.dirname(os.getcwd()))  # go up two folders
#     yaml_dict = load_yaml_config(config_file, cfg_dir=cfg_dir)
#     input_class = TD_yaml.parse_obj(yaml_dict)
#     input_class.validate_precision()

#     return input_class, config_file


def filepath_creator(input_class) -> dict:
    path_dict = {}
    path_dict["resultsDIR"] = input_class.Paths.set_get_output_path()
    path_dict["MarkesDIR"] = input_class.Paths.define_analysis_path(
        "Markes", parent_path_name="output_path", check=True
    )
    path_dict["PicarroDIR"] = input_class.Paths.define_analysis_path(
        "Picarro TD", parent_path_name="output_path", check=True
    )
    path_dict["ICADIR"] = input_class.Paths.define_analysis_path(
        "ICA", parent_path_name="output_path", check=True
    )
    path_dict["unknownICADIR"] = input_class.Paths.define_analysis_path(
        "unknown ICA", parent_path_name="output_path", check=True
    )
    path_dict["FOMDIR"] = input_class.Paths.define_analysis_path(
        "FOM", parent_path_name="output_path", check=True
    )
    path_dict["unknownFOMDIR"] = input_class.Paths.define_analysis_path(
        "unknown FOM", parent_path_name="output_path", check=True
    )
    path_dict["canaryICADIR"] = input_class.Paths.define_analysis_path(
        "canary ICA", parent_path_name="output_path", check=True
    )
    path_dict["unknowncanaryFOMDIR"] = input_class.Paths.define_analysis_path(
        "unknown canary FOM", parent_path_name="output_path", check=True
    )
    path_dict["comboDIR"] = input_class.Paths.define_analysis_path(
        "combo spectra", parent_path_name="output_path", check=True
    )
    path_dict["loadDIR"] = input_class.Paths.define_analysis_path(
        "raw data", parent_path_name="output_path", check=True
    )
    path_dict["timeseriesDIR"] = input_class.Paths.define_analysis_path(
        "timeseries", parent_path_name="output_path", check=True
    )
    path_dict["fitDIR"] = input_class.Paths.define_analysis_path(
        "fit TD", parent_path_name="output_path", check=True
    )
    path_dict["preconDIR"] = input_class.Paths.define_analysis_path(
        "preconcentration", parent_path_name="output_path", check=True
    )

    return path_dict


def run_filename_creator(input_class, path_dict, run_start, analysis, cid_list_num=0):
    prefix = input_class.output_prefix
    seq_prefix = "_".join(prefix.split("_")[2:])

    if analysis in USE_DIR_DICT_KEYS:
        path_dir = path_dict[USE_DIR_DICT_KEYS[analysis]]
    else:
        path_dir = path_dict[USE_DIR_DICT_KEYS["other"]]

    if analysis in EVENT_ANALYSIS_LIST:
        flnm = f"{run_start}_{seq_prefix}_{analysis}.pkl"
    elif analysis in EVENT_CID_LIST:
        flnm = f"{run_start}_{seq_prefix}_list_{cid_list_num}_{analysis}.pkl"
    else:
        flnm = f"{prefix}_{analysis}.pkl"

    flnm_path = os.path.join(path_dir, flnm)

    return flnm_path
