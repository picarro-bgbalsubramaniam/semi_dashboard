import enum
from itertools import combinations
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from scipy.signal import find_peaks

from spectral_arithmetic.linear_least_squares import least_squares
from spectral_toolkit.logger import get_logger

from spectral_toolkit.db_clients.mongo_spectral_library import (
    get_mongo_spectral_library_client,
)
from spectral_toolkit.logger import get_logger
from spectral_toolkit.model_function.mongodb import get_model_functions

LOGGER = get_logger(__name__)

# TODO: Once we finalize implementation add stats and make sorting/filtering them more generic

SCORE = "score"
RMSE = "rmse"
WRMSE = "wrmse"
CID = "cid"
CIDS = "cids"
FRACTION = "fraction"


GHOSTS = [222, 280, 297, 402, 6324, 6344, 8003, 948, 962]
IGNORE = [92831, 637513, 15133]

CHARS_REPLACE = ["(", ")", ","]


class StatsEnum(enum.Enum):
    score = SCORE
    rmse = RMSE
    wrmse = WRMSE

    @classmethod
    def list(cls):
        return list(map(lambda c: c.value, cls))


def weighted_rmse(fit_result: np.ndarray, partial_fit: np.ndarray, error: np.ndarray):
    """
    Computes weighted std of residuals.
    Args:
        fit_result: least squares fit results
        partial_fit: original partial_fit
        error: passed in error
    Returns:
        weighted std
    """
    residuals = partial_fit - fit_result
    weights = 1 / error
    var = np.sum(weights * residuals**2) / np.sum(weights)
    return np.sqrt(var)


def get_spectrum_score(
    measured_spectrum: np.ndarray, modeled_spectrum: np.ndarray
) -> float:
    """
    Get the dot product of two spectra for comparison.  Higher value is better match

    Args:
        measured_spectrum (np.ndarray): spectral values measured
        modeled_spectrum (np.ndarray): spectral values comparing to from model

    Returns:
        float: spectrum score
    """
    # TODO: use n points in weighting
    if measured_spectrum.size != modeled_spectrum.size:
        raise ValueError(
            "Spectrum lengths must be the same to calculate spectrum score"
        )

    normalized_data_vector = measured_spectrum / np.sqrt(np.sum(measured_spectrum**2))
    normalized_model_vector = modeled_spectrum / np.sqrt(np.sum(modeled_spectrum**2))
    spectrum_score = sum(normalized_data_vector * normalized_model_vector)
    spectrum_score = -1 * np.log10(1 - spectrum_score)

    return spectrum_score


def filter_spectrum_score(
    model_functions: Dict[int, np.ndarray],
    partial_fit: np.ndarray,
    max_keep: int = 40,
) -> pd.DataFrame:
    """
    Convenience for filtering out model functions based on spectrum score.  Good for initial search

    Args:
        model_functions (List[np.ndarray]): list of model functions evaluated at nu values
        partial_fit (np.ndarray): partial fit we are calculating score for
        top_fraction (float, optional): Top fraction to keep. Defaults to 0.2.

    Returns:
        pd.DataFrame: Returns top fraction of spectrum scores for provided modeul functions
    """
    scores = dict()
    for cid, model_function in model_functions.items():
        scores[cid] = get_spectrum_score(model_function, partial_fit)

    scores_df = pd.DataFrame(scores.items(), columns=[CID, SCORE])

    # sort by score highest first
    scores_df = scores_df.sort_values(by=[SCORE], ascending=False)
    scores_df = scores_df.head(max_keep)
    scores_df = scores_df.astype({CID: int})

    return scores_df


def evaluate_model_functions(
    nu_values: np.ndarray, nominal_pressure: float = 140
) -> Dict[int, np.ndarray]:
    """Convenience for getting all model functions and evaluating at given nu values

    Args:
        nu_values (np.ndarray): all the nu values
        nominal_pressure (float, optional): _description_. Defaults to 140.

    Returns:
        Dict[int, np.ndarray]: _description_
    """
    client = get_mongo_spectral_library_client()
    model_functions = get_model_functions(client, nominal_pressure=nominal_pressure)
    model_functions = {k: v(nu_values) for k, v in model_functions.items()}
    client.client.close()

    return model_functions


def get_fit_info(
    model_functions: Dict[int, np.ndarray], partial_fit: np.ndarray, error: np.ndarray
) -> Tuple[float, float, float, np.ndarray, np.ndarray]:
    """
    Take input model function dictionary and partial fit with calculated error and
    return certain fit information

    Args:
        model_functions (Dict[int, np.ndarray]): dictionary with cids and nu evaluated model functions
        partial_fit (np.ndarray): partial fit we're fitting to
        error (np.ndarray): error on partial fit measurement

    Returns:
        Tuple[float, float, float, np.ndarray, np.ndarray]: score, rmse, wrmse, fit coefficients, total spectrum with calcualted coeffs
    """
    model_function_values = list(model_functions.values())
    fit, stats = least_squares(
        np.vstack(tuple(model_function_values)).T, partial_fit, error
    )
    total = np.zeros(len(partial_fit))
    for coeff, base_f in zip(fit, model_function_values):
        total += coeff * base_f

    score = get_spectrum_score(total, partial_fit)
    rmse = np.std(stats.residual_error)
    wrmse = weighted_rmse(total, partial_fit, error)

    return (score, rmse, wrmse, fit, total)


def improvement_filter(
    base_model_funcs: Dict[int, np.ndarray],
    all_model_funcs: Dict[int, np.ndarray],
    partial_fit: np.ndarray,
    error: np.ndarray,
    minimum_improvement: float = 0.01,
    max_compounds: int = 40,
    sort_by: StatsEnum = StatsEnum.score.value,
) -> List[int]:
    """
    Iterate through all cids and only keep values that are an improvement on base set of model functions scores

    Args:
        base_model_funcs (Dict[int, np.ndarray]): dictionary of model funcs as baseline set
        all_model_funcs (Dict[int, np.ndarray]): dictionary of all model funcs evaluated at nu
        partial_fit (_type_): spectrum we're fitting to
        error (_type_): error of partial fit
        minimum_improvement (_type_): fraction of 1 as a percent improvement required

    Returns:
        List[int]: a list of cids that pass this filter.  Leaving out data as this is an intial filtering step
    """
    cids_keep = {CID: [], SCORE: [], RMSE: [], WRMSE: []}
    base_cids = list(base_model_funcs.keys())
    base_score, base_rmse, base_wrmse, _, _ = get_fit_info(
        base_model_funcs, partial_fit, error
    )
    improvement_factor = 1 + minimum_improvement
    for cid, model_function in all_model_funcs.items():
        if cid in base_cids:
            continue

        cur_model_funcs = base_model_funcs.copy()
        cur_model_funcs.update({cid: model_function})
        cur_score, cur_rmse, cur_wrmse, _, _ = get_fit_info(
            cur_model_funcs, partial_fit, error
        )

        # TODO: Normalize this check
        if (
            cur_score >= improvement_factor * base_score
            and cur_rmse <= improvement_factor * base_rmse
            and cur_wrmse <= improvement_factor * base_wrmse
        ):
            cids_keep[CID].append(cid)
            cids_keep[SCORE].append(cur_score)
            cids_keep[RMSE].append(cur_rmse)
            cids_keep[WRMSE].append(cur_wrmse)

    filter_df = pd.DataFrame(cids_keep)
    ascending = False
    if "rmse" in sort_by:
        ascending = True

    top_df = filter_df.sort_values(by=[sort_by], ascending=ascending)[0:max_compounds]

    return top_df


def fit_combinations(
    base_model_funcs: Dict[int, np.ndarray],
    all_model_funcs: Dict[int, np.ndarray],
    partial_fit: np.ndarray,
    error: np.ndarray,
    cids: List[int],
    number_to_fit: int = 3,
    fraction_to_keep: float = 0.2,
    sort_by: StatsEnum = StatsEnum.score.value,
):
    overlap = set(cids).intersection(set(base_model_funcs.keys()))
    if overlap:
        LOGGER.warning("Found duplicate cids in base and cid list")
        for cid in overlap:
            cids.remove(cid)

    if number_to_fit < 2 or number_to_fit > 5:
        raise ValueError(
            "CID combinations must be between greater than 1 and less than 6"
        )

    results_df = pd.DataFrame(columns=[CIDS, SCORE, RMSE, WRMSE])
    for cid_combination in combinations(cids, number_to_fit):
        current_model = base_model_funcs.copy()
        for cid in cid_combination:
            current_model.update({cid: all_model_funcs[cid]})

        row_data = dict()
        format_combo = str(cid_combination).replace(" ", "")
        for char in CHARS_REPLACE:
            format_combo = format_combo.replace(char, "$")
        row_data[CIDS] = format_combo

        row_data[SCORE], row_data[RMSE], row_data[WRMSE], _, _ = get_fit_info(
            current_model, partial_fit, error
        )

        results_df = pd.concat([results_df, pd.DataFrame(row_data, index=[0])])

    # Sort and filter
    total_rows = len(results_df.index)
    rows_to_keep = int(total_rows * fraction_to_keep)
    if rows_to_keep == 0:
        rows_to_keep = 1

    # Hack, clean up in next iteration
    ascending = False
    if "rmse" in sort_by:
        ascending = True

    top_df = results_df.sort_values(by=[sort_by], ascending=ascending)[0:rows_to_keep]
    fraction_dict = dict()
    for cid in cids:
        fraction_dict[cid] = (
            top_df[CIDS].str.contains(f"${cid}$", regex=False).sum() / rows_to_keep
        )

    fraction_frame = pd.DataFrame(
        fraction_dict.items(), columns=[CID, FRACTION]
    ).sort_values(by=[FRACTION], ascending=False)

    return (top_df, fraction_frame)


def check_peaks(mfs_nu, partial_fit):
    """
    Simple look at number of shared peaks for model functions evaluated with default args
    """
    p_peaks = find_peaks(partial_fit)[0]
    peak_dict = {k: find_peaks(v)[0] for k, v in mfs_nu.items()}
    peak_size = {}
    for k, v in peak_dict.items():
        peak_size[k] = len(np.intersect1d(p_peaks, v))
    peak_df = pd.DataFrame(peak_size.items(), columns=["cid", "shared_peaks"])
    peak_guess = peak_df.sort_values(by=["shared_peaks"], ascending = False).head(3)["cid"].tolist()

    return peak_guess


def adams_hunt(
    model_funcs,
    partial_fit,
    error,
    guess: List[int] = [],
    number_to_fit: int = 3,
    base_cids: List[int] = [],
    top_n: int = 10,
):
    """
    Should be called adam's curse.  An example of using the pieces.  Leaving
    things mostly hardcoded, this is an example that works ok-ish.  We can envision a
    depth first search starting from each of the top candidates.  Often you will find the
    same list of cids starting with any valid starting candidate

    model_funcs are already nu evaluated
    """
    for cid in IGNORE:
        if cid in model_funcs:
            del model_funcs[cid]
    peak_guess = check_peaks(model_funcs, partial_fit)
    guess.extend(peak_guess)
    score_df = filter_spectrum_score(model_funcs, partial_fit)
    cids = score_df.head(top_n)[CID].tolist()
    if guess and not base_cids:
        for c in cids:
            if c in guess:
                base_cids = [c]
                break
    if not base_cids:
        base_cids = [cids[0]]
    while True:
        base_model_function = {val: model_funcs[val] for val in base_cids}
        filtered = improvement_filter(
            base_model_function, model_funcs, partial_fit, error
        )
        new_filter = filtered[CID].tolist()
        if not new_filter:
            break
        if len(new_filter) < 3:
            number_to_fit = 1
        if len(new_filter) < 5:
            number_to_fit = 2
        _, fraction_df = fit_combinations(
            base_model_function,
            model_funcs,
            partial_fit,
            error,
            new_filter,
            number_to_fit=number_to_fit,
        )
        next_candidate = None
        if guess:
            for c in fraction_df.head(top_n)[CID].to_list():
                if c in guess:
                    next_candidate = c
                    break
            if not next_candidate:
                next_candidate = fraction_df["cid"].iloc[0]
        else:
            next_candidate = fraction_df["cid"].iloc[0]
        base_cids.append(next_candidate)

    check_model_funcs = {val: model_funcs[val] for val in base_cids}
    score, rmse, wrmse, fit, total = get_fit_info(check_model_funcs, partial_fit, error)
    check_list = []
    total_sum = np.sum(total)
    # Just do a single pass, this should be recursive
    for cid, fit_value in zip(base_cids, fit):
        contr = np.sum(fit_value * model_funcs[cid]) / total_sum
        if contr < 0.02 and cid not in GHOSTS:  # Add check of signal to noise
            continue
        check_list.append(cid)

    final_model_funcs = {val: model_funcs[val] for val in check_list}
    score, rmse, wrmse, fit, total = get_fit_info(final_model_funcs, partial_fit, error)

    return (check_list, score, rmse, wrmse, fit, total)
