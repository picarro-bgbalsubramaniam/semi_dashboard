"""
Contains the scheme optimizer routine.
"""
from itertools import chain, combinations
from typing import List, Sequence, Tuple

import numpy as np
import pandas as pd
from pydantic import validate_call

from spectral_toolkit.data_models.scheme_optimizer_models import OptimizerConstants
from spectral_toolkit.logger import get_logger
from spectral_toolkit.scheme_optimizer.cost_functions import (
    penalty_range,
    penalty_spacing,
    penalty_spread,
    q_error,
)
from spectral_toolkit.scheme_optimizer.reporting import (
    report_cost_function,
    report_results,
)

LOGGER = get_logger(__name__)


@validate_call()
def _comb_index(n: int, k: int) -> np.ndarray:
    """
    Creates an array of all
    the n-choose-k
    indexing options.

    Args:
        n (int):
            Number of all possible modes.
        k (int):
            Number of modes that
            I want to keep.

    Returns:
        np.ndarray:
            All indexing for the n-choose-k
            combinations.



    >>> _comb_index(3,2) # doctest: +NORMALIZE_WHITESPACE
    array([[0, 1],
       [0, 2],
       [1, 2]])

    >>> _comb_index(4,3) # doctest: +NORMALIZE_WHITESPACE
    array([[0, 1, 2],
     [0, 1, 3],
     [0, 2, 3],
     [1, 2, 3]])

    """
    index = np.fromiter(chain.from_iterable(combinations(range(n), k)), int)
    return index.reshape(-1, k)


def evaluate_cost_function(
    selected_mode_indexes: np.ndarray,
    schema_constants: OptimizerConstants,
) -> np.ndarray:
    """
    Evaluate the objective function for the minimization routine.
    Typically: chi square + some penalty terms.

    Args:
        selected_mode_indexes (np.ndarray):
            Evaluate the cost function for
            all different modes indexed by
            ``selected_mode_indexes``.
            Dimensions: [#tests x #modes]
        schema_constants (OptimizerConstants):
            Constants for the optimizer process.
    Returns:
        np.ndarray:
            Value of the cost function
            evaluated for every test in
            ``selected_mode_indexes``.
            Dimension: [#tests]
    """

    # If 1D, extend to 2D
    if len(selected_mode_indexes.shape) == 1:
        selected_mode_indexes = np.expand_dims(selected_mode_indexes, axis=0)

    results_df = q_error(
        schema_constants.model_functions,
        schema_constants.measurement_noise,
        schema_constants.cid_list,
        selected_mode_indexes,
    )

    results = results_df.to_numpy()

    results_reference = schema_constants.reference_performance.to_numpy()

    errors = results / results_reference / schema_constants.target_noise
    errors = np.power(errors, 2)
    chi_sqr = np.sum(errors, axis=1)
    chi_sqr /= len(schema_constants.cid_list)

    chi_sqr += penalty_range(
        selected_mode_indexes,
        schema_constants.allowed_wavenumbers,
        schema_constants.nu_span_min,
        schema_constants.min_spacing,
    )
    chi_sqr += penalty_spacing(
        selected_mode_indexes,
        schema_constants.allowed_wavenumbers,
        schema_constants.min_spacing,
        schema_constants.min_spacing_penalty,
    )
    chi_sqr += penalty_spread(
        selected_mode_indexes,
        schema_constants.allowed_wavenumbers,
        schema_constants.spread_points,
    )
    return chi_sqr


def remove_one_mode(
    starting_mode_idxs: np.ndarray, schema_constants: OptimizerConstants
) -> Tuple[np.ndarray, Tuple[float, int]]:
    """
    Given an array with n modes,
    returns an array with the
    n-1 most-informative modes
    (by evaluating which mode removal
    has the best/lowest cost function).
    Args:
        starting_mode_idxs (np.ndarray):
            Evaluate the cost function for
            all different modes indexed by
            ``selected_mode_indexes``.
            Dimensions: [#modes]
        schema_constants (OptimizerConstants):
            Constants for the optimizer process.

    Returns:
        Tuple with:
        - reduced_modes (np.ndarray):
            n-1 most informative modes indexes.
            Dimension: [#modes - 1]
        - least_effective_tuple (Tuple[float, int])
            Tuple with:
            - Jm (float): value of cost function J when
                mode index m is removed
            - m (int): removed mode index
    """
    (
        reduced_modes_options_idx,
        reduced_modes_dropped_options,
    ) = leave_one_out_combination_indexes(starting_mode_idxs.shape[0])
    reduced_modes_options = starting_mode_idxs[reduced_modes_options_idx]

    results_reduction = evaluate_cost_function(
        selected_mode_indexes=reduced_modes_options, schema_constants=schema_constants
    )

    least_effective_location = np.argmin(results_reduction)
    least_effective_result_value = results_reduction[least_effective_location]
    least_effective_mode_idx = reduced_modes_dropped_options[least_effective_location]
    least_effective_mode = starting_mode_idxs[least_effective_mode_idx]
    least_effective_tuple = (least_effective_result_value, least_effective_mode)
    reduced_modes_selected = reduced_modes_options[least_effective_location]
    return reduced_modes_selected, least_effective_tuple


def add_one_mode(
    starting_mode_idxs: np.ndarray, schema_constants: OptimizerConstants
) -> Tuple[np.ndarray, Tuple[float, int]]:
    """
    Given an array with n modes,
    returns an extended array with the
    n+1 most-informative modes.
    The extension procedure tests
    all combinations derived from adding
    each of the M available modes
    to the n starting modes.
    The most informative mode added is
    the one that minimize the cost function.

    Args:
        starting_mode_idxs (np.ndarray):
            Starting modes indexes array
            to be extended.
            Dimensions: [#modes]
        schema_constants (OptimizerConstants):
            Constants for the optimizer process.
            Includes ``allowed_wavenumbers``, a list
            of possible wavenumbers that the schema
            can use.

    Returns:
        Tuple with:
        - reduced_modes (np.ndarray):
            n+1 most informative modes indexes.
            Dimension: [#modes + 1]
        - most_effective_tuple (Tuple[float, int])
            Tuple with:
            - Jm (float): value of cost function J when
                mode index m is added
            - m (int): added mode index
    """
    allowed_modes = np.arange(0, schema_constants.allowed_wavenumbers.shape[0])
    extended_modes_options = np.c_[
        np.tile(starting_mode_idxs, (len(allowed_modes), 1)), allowed_modes
    ]

    results_extension = evaluate_cost_function(
        selected_mode_indexes=extended_modes_options, schema_constants=schema_constants
    )

    most_effective_location = np.argmin(results_extension)
    extended_modes_selection = extended_modes_options[most_effective_location]
    most_effective_result_value = results_extension[most_effective_location]
    most_effective_mode_idx = extended_modes_selection[-1]
    most_effective_tuple = (most_effective_result_value, most_effective_mode_idx)
    return extended_modes_selection, most_effective_tuple


def shuffle_one(
    starting_mode_idxs: np.ndarray, schema_constants: OptimizerConstants
) -> Tuple[np.ndarray, Sequence[Tuple[float, int]]]:
    """
    Given an array with n modes,
    returns an array with the
    n modes, where one of the modes
    have been swapped with another one
    (among the ones available for the schema
    to reach).
    The swapping procedure first removes the least
    informative mode, then adds a mode that adds
    information.
    Both removal and addition comes from
    minimizing the cost function.

    Args:
        starting_mode_idxs (np.ndarray):
            Starting modes indexes array
            Dimensions: [#modes]
        schema_constants (OptimizerConstants):
            Constants for the optimizer process.
            Includes ``allowed_wavenumbers``, a list
            of possible wavenumbers that the schema
            can use.

    Returns:
        Tuple with:
        - new_modes (np.ndarray):
            New modes indexes from the swap procedure.
            Dimension: [#modes]
        - shuffle (Tuple[float, int], Tuple[float, int])
            Nested tuple with, IN:
            - Jm (float): value of cost function J when m was added
            - m (int): added mode index
            OUT:
            - Jk (float): value of cost function J when k was removed
            - k (int): removed mode index
    """
    reduced_modes_selected, least_effective_tuple = remove_one_mode(
        starting_mode_idxs=starting_mode_idxs, schema_constants=schema_constants
    )

    extended_modes_selection, most_effective_tuple = add_one_mode(
        starting_mode_idxs=reduced_modes_selected, schema_constants=schema_constants
    )

    shuf = most_effective_tuple, least_effective_tuple

    return extended_modes_selection, shuf


@validate_call()
def leave_one_out_combination_indexes(data_len: int) -> Tuple[np.ndarray, np.ndarray]:
    """
    Create n-choose-(n-1) indexes list, to investigate
    all possibilities when removing a mode
    from a list of modes.

    Args:
        data_len (int):
            The length of the modes list.

    Returns:
        tuple containing

        - indexes (np.ndarray):
            All indexes for all combinations.
            Dimensions: [#n x #n-1]
        - dropped_index (np.ndarray):
            Discarded index.
            Dimensions: [#n]

    """
    idx = _comb_index(data_len, data_len - 1)
    idx = np.flipud(idx)
    mask = (np.arange(0, data_len) == idx[..., None]).any(axis=1).astype(int)
    dropped_index = np.argmin(mask, axis=0)
    return idx, dropped_index


def optimize_scheme(
    initial_modes_guess: List[int],
    schema_constants: OptimizerConstants,
    show_every: int = 20,
    max_iterations: int = 5000,
) -> Tuple[np.ndarray, pd.DataFrame]:
    """
    Scheme optimizer routine.
    Returns an array with
    optimal modes indexes from the minimization
    of a cost function and a dataframe
    with the results recorded at every iteration.

    Args:
        initial_modes_guess (List[int]):
            Initial guess for mode indexes.
            Dimensions: [#modes]
        schema_constants (OptimizerConstants):
            Constants for the optimizer process.
            Includes ``allowed_wavenumbers``, a list
            of possible wavenumbers that the schema
            can use.
        show_every (int):
            Display estimated standard error for every
            CID every ``show_every`` iteration.
        max_iterations (int):
            Maximum number of swap-one-mode iterations
            for the optimizer.

    Returns:
        Tuple with:
        - selected_modes (np.ndarray):
            Mode indexes array at the end
            of the optimizing procedure.
        - results_log (pd.DataFrame):
            Rows are iterations of the optimizer,
            columns are CIDs, values are estimated standard
            errors for CIDs at every iteration.

    """
    initial_guess = np.array(initial_modes_guess)

    j_cost = evaluate_cost_function(
        selected_mode_indexes=initial_guess, schema_constants=schema_constants
    )

    results_log = q_error(
        model_funcs=schema_constants.model_functions,
        measurement_noise=schema_constants.measurement_noise,
        cid_list=schema_constants.cid_list,
        selected_modes_indexes=initial_guess,
    )

    report = report_results(
        reference_results=schema_constants.reference_performance,
        logs_df=results_log,
        gas_sample=schema_constants.gas_sample,
        pubchem_df=schema_constants.pubchem_df,
    )
    LOGGER.info(f"Initial guess result\n{report}")

    count = 0
    current_guess = initial_guess

    for i in range(max_iterations):
        extended_modes_selection, shuffles = shuffle_one(
            starting_mode_idxs=current_guess, schema_constants=schema_constants
        )

        j_cost = np.append(j_cost, shuffles[0][0])
        percent_change = (j_cost[-2] - j_cost[-1]) / j_cost[-2]

        results_df = q_error(
            model_funcs=schema_constants.model_functions,
            measurement_noise=schema_constants.measurement_noise,
            cid_list=schema_constants.cid_list,
            selected_modes_indexes=extended_modes_selection,
        )
        current_guess = extended_modes_selection

        results_log = pd.concat([results_log, results_df], ignore_index=True)

        if i % show_every == 0:
            LOGGER.info(
                f"n={i:.0f} {report_cost_function(shuffles, schema_constants.allowed_wavenumbers)}"
                f" \u0394J = {percent_change:.8%}"
            )
        if i % (show_every * 5) == 0:
            report = report_results(
                reference_results=schema_constants.reference_performance,
                logs_df=results_log,
                gas_sample=schema_constants.gas_sample,
                pubchem_df=schema_constants.pubchem_df,
            )
            LOGGER.info(f"n={i:.0f}\n{report}")

        if shuffles[0][1] == shuffles[1][1]:
            count += 1
        else:
            count -= 1

        count = max(count, 0)

        if count >= 3:
            LOGGER.info("TERMINATED")
            LOGGER.info(
                f"i={i:.0f} {report_cost_function(shuffles, schema_constants.allowed_wavenumbers)}"
            )
            break

    report = report_results(
        reference_results=schema_constants.reference_performance,
        logs_df=results_log,
        gas_sample=schema_constants.gas_sample,
        pubchem_df=schema_constants.pubchem_df,
    )
    LOGGER.info(f"{report}")
    return extended_modes_selection, results_log


def random_modes_initialize(
    random_try_number: int,
    len_allowed: int,
    len_modes: int,
    schema_constants: OptimizerConstants,
) -> np.ndarray:
    """
    Returns an initial guess for
    the modes indexes for the start
    of the optimization routine.
    If ``random_try_number`` > 1,
    then multiple random combination
    of length #modes are tested,
    and only the best random modes
    initialization is returned.

    Args:
        random_try_number (int):
            Number of random combinations of
            modes to be tested (#tests).
        len_allowed (int):
            Number of modes that are available
            for the schema to pick from.
        len_modes (int):
            Number of schema points (#modes)
        schema_constants (OptimizerConstants):
            Constants for the optimizer process.
            Includes ``allowed_wavenumbers``, a list
            of possible wavenumbers that the schema
            can use.

    Returns:
        np.ndarray:
            Random modes indexes.
            Dimension: [#modes]

    """
    np.random.seed(1234)
    starting_modes = np.random.randint(0, len_allowed, (random_try_number, len_modes))
    j_cost_0 = evaluate_cost_function(
        selected_mode_indexes=starting_modes, schema_constants=schema_constants
    )
    most_effective_location = np.argmin(j_cost_0)
    best_starting_modes = starting_modes[most_effective_location]
    return best_starting_modes
