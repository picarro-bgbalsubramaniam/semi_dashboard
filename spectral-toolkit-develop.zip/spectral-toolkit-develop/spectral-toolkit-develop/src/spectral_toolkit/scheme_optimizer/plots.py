"""
Plots to visualize schema and model functions
"""

from typing import List

import numpy as np
import pandas as pd
import plotly.graph_objs as go
from plotly.subplots import make_subplots
from spectral_toolkit.plotting.colors_utils import get_full_colorscale


def plot_model_functions(
    model_functions: List[np.ndarray], gas_list: List[int], wavenumber_grid: pd.Series
) -> go.Figure:
    """
    Plot model functions for different CIDs,
    evaluated at different wavenumbers.

    Args:
        model_functions (List[np.ndarray]):
            List with #cids arrays.
            Each array is #wavenubers long.
            Dimensions: [#cids, #wavenumbers]

        gas_list (List[int]):
            List of CIDs.
            Dimensions: [#cids]

        wavenumber_grid (pd.Series):
            Series with wavenumber as values.
            Its length is #wavenumber.
            Dimensions: [#wavenumbers]

    Returns:
        go.Figure:
            Plotly figure.

    """
    fig = go.Figure()

    for cid, model_fun in zip(gas_list, model_functions):
        if cid == 222:
            model_fun = -model_fun

        fig.add_trace(
            go.Scattergl(
                x=wavenumber_grid,
                y=np.arcsinh(model_fun),
                mode="lines+markers",
                opacity=0.8,
                name=f"{cid}",
                showlegend=True,
            )
        )

    fig.update_yaxes(title="Symmetric-logarithmic Loss")
    fig.update_xaxes(title="Wavenumber [cm<sup>-1</sup>]")
    fig.update_layout(
        title="<b>Model functions</b><br>Arcsinh of loss - Similar to symlog visualization"
    )
    return fig


def plot_thumbnail_scheme(grid_stats: pd.DataFrame) -> go.Figure:
    """
    Create subplots with:
    - Number of ringdowns per wavenumber
    - Differences between consecutive wavenumbers
    - Count of distinct wavenumbers in a unit wavenumber
    - Count of ringdowns in a unit wavenumber

    Args:
        grid_stats (pd.DataFrame):
            Full grid from :py:func:`.process_mode_grid`.

    Returns:
        go.Figure:
            Plotly figure.

    """
    fig = make_subplots(
        rows=4,
        cols=1,
        subplot_titles=[
            "Dwell per wavenumber",
            "Frequency gaps (&#916;&#957;)",
            "Distinct wavenumbers in 1 cm<sup>-1</sup>",
            "Distinct ringdowns in 1 cm<sup>-1</sup>",
        ],
        vertical_spacing=0.06,
    )

    fig.add_trace(
        go.Scattergl(
            x=grid_stats.wavenumber,
            y=grid_stats.dwell,
            mode="markers",
            marker=dict(size=6 + grid_stats.excess_dwell),
            opacity=0.9,
            showlegend=False,
        ),
        row=1,
        col=1,
    )

    wn_gaps = grid_stats.wavenumber.diff()
    fig.add_trace(
        go.Scattergl(
            x=grid_stats.wavenumber,
            y=wn_gaps,
            mode="markers",
            marker=dict(size=6),
            opacity=0.9,
            showlegend=False,
        ),
        row=2,
        col=1,
    )

    # Bin wavenumbers in 5cm-1 bins
    # Use the mean of the bin interval as label
    bin_res = 5  # cm-1
    low_bound = np.floor(min(grid_stats.wavenumber) / bin_res) * bin_res
    high_bound = (np.ceil(max(grid_stats.wavenumber) / bin_res) + 1) * bin_res
    bins = np.arange(low_bound, high_bound, bin_res)
    binned_wavenumbers = pd.cut(
        grid_stats.wavenumber,
        bins=bins,
        labels=np.arange(
            low_bound + 0.5 * bin_res, high_bound - 0.5 * bin_res, bin_res
        ),
    )

    # Count occurrences in each bin
    # Then divide by bin_res to obtain the number of measured
    # frequencies per wavenumber
    scheme_rows_per_wavenumber = binned_wavenumbers.value_counts(sort=False) / bin_res
    fig.add_trace(
        go.Scattergl(
            x=scheme_rows_per_wavenumber.index,
            y=scheme_rows_per_wavenumber,
            mode="markers",
            marker=dict(size=10),
            opacity=0.9,
            showlegend=False,
        ),
        row=3,
        col=1,
    )

    # Get ringdowns_per_wavenumber
    idx, cols = pd.factorize(binned_wavenumbers)
    ringdowns_per_wavenumber = grid_stats["dwell"].groupby(idx).sum()
    ringdowns_per_wavenumber.index = cols
    ringdowns_per_wavenumber = ringdowns_per_wavenumber / bin_res

    fig.add_trace(
        go.Scattergl(
            x=ringdowns_per_wavenumber.index,
            y=ringdowns_per_wavenumber,
            mode="markers",
            marker=dict(size=10),
            opacity=0.9,
            showlegend=False,
        ),
        row=4,
        col=1,
    )

    for annotation in fig.layout.annotations:
        annotation.update(x=0, xanchor="left", font_color="gray", font_size=12)
    return fig


def plot_model_schema(
    model_functions: np.ndarray,
    gas_list: List[int],
    final_wavenumber_grid: pd.Series,
    full_grid: pd.Series,
) -> go.Figure:
    """
    Create a plot with model functions
    (evaluated at every point of the full
    grid) displayed as lines, with selected schema
    points overlaid as markers.

    Args:
        model_functions (List[np.ndarray]):
            List with #cids arrays.
            Each array is #wavenubers long.
            Dimensions: [#cids, #wavenumbers]

        gas_list (List[int]):
            List of CIDs.
            Dimensions: [#cids]

        final_wavenumber_grid (pd.Series):
            Series with wavenumber as values.
            It is the selected subset of
            ``full_grid`` derived by the
            optimization procedure.

        full_grid (pd.Series):
            Series with wavenumber as values.
            Its length is #wavenumber.
            Dimensions: [#wavenumbers]

    Returns:
        go.Figure:
            Plotly figure.
    """
    fig = go.Figure()

    cmap = get_full_colorscale(gas_list, {})

    for cid, model_fun in zip(gas_list, model_functions):
        fig.add_trace(
            go.Scattergl(
                x=full_grid,
                y=model_fun,
                mode="lines",
                opacity=0.2,
                line_width=2,
                line_color=cmap[f"{cid}"],
                name=f"{cid}_original",
                showlegend=False,
            )
        )

        fig.add_trace(
            go.Scattergl(
                x=final_wavenumber_grid,
                y=model_fun[final_wavenumber_grid.index.values.tolist()],
                mode="markers",
                marker_size=8,
                marker_color=cmap[f"{cid}"],
                opacity=1,
                name=f"{cid}",
                showlegend=True,
            )
        )

    fig.update_yaxes(title="Absorbance [ppb/cm] @ 1 ppm", type="log")
    fig.update_xaxes(title="Wavenumber [cm<sup>-1</sup>]")
    fig.update_layout(title="<b>Final scheme</b><br>Logarithmic scale")
    return fig
