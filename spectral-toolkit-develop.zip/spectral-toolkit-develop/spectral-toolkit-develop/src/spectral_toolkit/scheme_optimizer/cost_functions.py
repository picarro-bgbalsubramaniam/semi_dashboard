"""
Collection of cost functions and performance estimators
"""
from typing import List

import numpy as np
import pandas as pd


def covariance_matrix(design_matrix: np.ndarray) -> np.ndarray:
    """
    Calculates the covariance matrix of the design matrix.
    The covariance matrix is calculated as: covariance_matrix = (A' A)^-1.

    In a 2D case, design matrix has size
    [n_modes x n_cids], so that:
    A = [n_modes x n_cids]
    A' = [n_cids x n_modes]
    -> covariance_matrix = [n_cids x n_cids]

    In a 3D case, where multiple
    modes strategies (each of length n_modes)
    are tested out:
    A = [n_tests x n_modes x n_cids]
    A' = [n_tests x n_cids x n_modes]
    -> covariance_matrix = [n_tests x n_cids x n_cids]

    Args:
        design_matrix (np.ndarray):
            Design matrix of size
            [n_tests x n_modes x n_cids]

    Returns:
        np.ndarray:
            Covariance matrix of size
            [n_tests x n_cids x n_cids]

    Example:
    We have n_modes = 4 and n_cids = 3.
    We expect covariance_matrix to be 3x3.
    >>> A = np.array([[1, 2, 3], [3, 1, 4], [5, 1, 6], [9, 2, 2]])
    >>> Q = covariance_matrix(A)
    >>> Q # doctest: +NORMALIZE_WHITESPACE
    array([[[ 0.02805836, -0.06285073, -0.00785634],
        [-0.06285073,  0.40078563, -0.0624018 ],
        [-0.00785634, -0.0624018 ,  0.04219978]]])

    >>> Q.shape
    (1, 3, 3)

    Let's create a 3D matrix by just stacking
    the A matrix n_tests-times (say 2)
    >>> B = np.tile(A, (2, 1, 1))
    >>> np.allclose(B[0, :, :], A)
    True
    >>> np.allclose(B[1, :, :], A)
    True

    The covariance matrix will be (2, 3, 3)
    >>> Q2 = covariance_matrix(B)
    >>> Q2.shape
    (2, 3, 3)
    >>> Q2 # doctest: +NORMALIZE_WHITESPACE
    array([[[ 0.02805836, -0.06285073, -0.00785634],
            [-0.06285073,  0.40078563, -0.0624018 ],
            [-0.00785634, -0.0624018 ,  0.04219978]],
           [[ 0.02805836, -0.06285073, -0.00785634],
            [-0.06285073,  0.40078563, -0.0624018 ],
            [-0.00785634, -0.0624018 ,  0.04219978]]])

    As B was created by repeating A 2-times,
    then each of the two slices of Q2 will
    coincide with covariance_matrix.
    >>> np.allclose(Q2[0, :, :], Q)
    True
    >>> np.allclose(Q2[1, :, :], Q)
    True

    """

    # Extend to a third empty dimension if the input is 2D
    if len(design_matrix.shape) == 2:
        design_matrix = np.expand_dims(design_matrix, axis=0)

    path = np.einsum_path(
        "akj,akl->ajl", design_matrix, design_matrix, optimize="optimal"
    )[0]

    # A' A
    dot_prod = np.einsum("akj,akl->ajl", design_matrix, design_matrix, optimize=path)

    # inv(A'A)
    covariance_matrix = np.linalg.inv(dot_prod)

    return covariance_matrix


def q_error(
    model_funcs: List[np.ndarray],
    measurement_noise: np.ndarray,
    cid_list: List[int],
    selected_modes_indexes=None,
):
    """
    Provide standard error approximation from the covariance matrix
    for each CID.

    Args:
        model_funcs (List[np.ndarray]):
            List with #cids arrays.
            Each array is #wavenubers long.
            Dimensions: [#cids, #wavenumbers]

        measurement_noise (np.ndarray):
            Measurement noise.
            Dimensions: [#wavenumbers]

        cid_list (List[int]):
            List of CIDs.
            Dimensions: [#cids]

        selected_modes_indexes (np.ndarray):
            Subset of selected modes.
            Dimensions are:
            [#tests x #selected_wavenumbers]
            where #selected_wavenumbers <=
            # wavenumbers

    Returns:
        pd.DataFrame:
            Standard error approximation for CIDs.
            Each column is a CID, each row is a tested
            modes scheme.
            Dimensions:
            [#tests x #cids]
    """

    if isinstance(selected_modes_indexes, list):
        selected_modes_indexes = np.array(selected_modes_indexes)

    if len(selected_modes_indexes.shape) == 1:
        # 2d array, add an empty dimension in front
        selected_modes_indexes = np.expand_dims(selected_modes_indexes, axis=0)

    weights = measurement_noise[selected_modes_indexes]

    model_matrix = np.vstack(model_funcs)[:, selected_modes_indexes] / weights
    design = np.transpose(model_matrix, axes=(1, 2, 0))

    covariance_full = covariance_matrix(design)
    covariance_diagonals = np.diagonal(covariance_full, axis1=1, axis2=2)
    q_errors = np.sqrt(covariance_diagonals)

    df_errors = pd.DataFrame(data=q_errors, columns=cid_list)
    return df_errors


def penalty_range(
    selected_modes_indexes: np.ndarray,
    allowed_nu: np.ndarray,
    min_nu_span: np.float64,
    min_spacing: int,
) -> np.ndarray:
    """
    Give a penalty based on range.

    Args:
        selected_modes_indexes (np.ndarray):
            Subset of selected modes.
            Dimensions are:
            [#tests x #selected_wavenumbers]
            where #selected_wavenumbers <=
            # wavenumbers
        allowed_nu (np.ndarray):
            All possible wavenumbers that
            could be used by a scheme.
            Dimension is [#wavenumbers]
        min_nu_span (np.float64):
            Span parameters
        min_spacing (int):
            Min spacing.

    Returns:
        np.ndarray:
            Additive penalty of dimensions
            [#tests]

    """
    structure = allowed_nu[selected_modes_indexes]

    if min_spacing > 0:
        penalty = (
            min_nu_span - (np.max(structure, axis=1) - np.min(structure, axis=1))
        ) / min_spacing
        penalty = np.where(penalty > 0, penalty, 0)
    else:
        penalty = np.zeros(structure.shape[0])
    return penalty


def penalty_spacing(
    selected_modes_indexes: np.ndarray,
    allowed_nu: np.ndarray,
    min_spacing: int,
    min_spacing_penalty: float,
) -> np.ndarray:
    """
    Give a penalty for widely spaced points.
    Encourage points to be close together.

    Args:
        selected_modes_indexes (np.ndarray):
            Subset of selected modes.
            Dimensions are:
            [#tests x #selected_wavenumbers]
            where #selected_wavenumbers <=
            # wavenumbers
        allowed_nu (np.ndarray):
            All possible wavenumbers that
            could be used by a scheme.
            Dimension is [#wavenumbers]
        min_spacing (int):
            Min spacing between modes in wavenumbers
        min_spacing_penalty (float):
            Scale factor for penalty (larger
            numbers discourage gaps more strongly)

    Returns:
        np.ndarray:
            Additive penalty of dimensions
            [#tests]
    """
    penalty = np.zeros(selected_modes_indexes.shape[0])
    if min_spacing > 0:
        diffy = np.diff(np.sort(allowed_nu[selected_modes_indexes]))
        penalty = np.sum(np.where(diffy > min_spacing, diffy, 0), axis=1)
        penalty = penalty * min_spacing_penalty
    return penalty


def penalty_spread(
    selected_modes_indexes: np.ndarray, allowed_nu: np.ndarray, spread_points: int
) -> np.ndarray:
    """
    Penalty for heaping ringdowns on one frequency.

    Args:
        selected_modes_indexes (np.ndarray):
            Subset of selected modes.
            Dimensions are:
            [#tests x #selected_wavenumbers]
            where #selected_wavenumbers <=
            # wavenumbers
        allowed_nu (np.ndarray):
            All possible wavenumbers that
            could be used by a scheme.
            Dimension is [#wavenumbers]
        spread_points (int):
            Spread points.
    Returns:
        np.ndarray:
            Additive penalty of dimensions
            [#tests]
    """

    def _get_spread_penalty_row(row: np.ndarray):
        _, counts = np.unique(row, return_counts=True)
        return np.sum(np.power(counts, 2))

    spread_factor = np.zeros(selected_modes_indexes.shape[0])

    if spread_points > 0:
        structure = allowed_nu[selected_modes_indexes]
        spread_factor = np.apply_along_axis(
            _get_spread_penalty_row, axis=1, arr=structure
        )
        spread_factor = np.divide(spread_factor, 4 * spread_points**2.5)
    return spread_factor


def penalty_scale_factors(
    results: np.ndarray,
    result_target: np.ndarray,
    noise: np.ndarray,
    threshold: int = 50,
):
    """
    This is used to de-emphasize the optimization of a cid
    whose percent error
    is equal or less than the threshold value.

    Args:
        results (np.ndarray):
            CIDs uncertainties from :py:func:`.q_error`.
            Dimensions [#cids].
        result_target (np.ndarray):
            CIDs uncertainties from :py:func:`.q_error`
            using all available modes.
            Dimensions [#cids].
        noise (np.ndarray):
            Noise.
            Dimensions [#cids].
        threshold (int):
            Percent threshold value.
    Returns:
        np.ndarray:
            Penalizing scale factors.
            Dimensions [#cids].
    """
    percent_change = 100 * (results - result_target) / result_target
    noise = np.tile(noise, (results.shape[0], 1))

    factor = np.where(np.abs(percent_change) <= threshold, 1000, noise)
    return factor
