import datetime
import time
from datetime import date
from os import PathLike
from pathlib import Path
from typing import Union, Optional, Callable

import click
import numpy as np
import pandas as pd
from pydantic import validate_call, Field

from spectral_toolkit.data_models.scheme_optimizer_models import (
    OptimizerConstants,
    SchemeConfiguration,
)
from spectral_toolkit.logger import get_logger
from spectral_toolkit.scheme_optimizer import voc_fitter_functions
from spectral_toolkit.scheme_optimizer.cost_functions import q_error
from spectral_toolkit.scheme_optimizer.grid_setup import (
    create_full_grid,
    filter_grid,
    load_initial_modes,
)
from spectral_toolkit.scheme_optimizer.optimizer_routines import optimize_scheme
from spectral_toolkit.scheme_optimizer.plots import (
    plot_model_functions,
    plot_model_schema,
    plot_thumbnail_scheme,
)
from spectral_toolkit.scheme_optimizer.reporting import (
    display_grid,
    export_results_summary,
    export_schema,
    export_schema_yaml,
    get_pubchem_df,
    process_mode_grid,
)
from spectral_toolkit.scheme_optimizer.voc_fitter_functions import (
    create_gas_sample,
    gather_model_functions,
)

LOGGER = get_logger(__name__)


np.random.seed(1234)


@click.command()
@click.option("--input_yaml", prompt="Enter full path to SchemeConfiguration yaml")
@click.option("--save_name", prompt="Enter name to use for saving results")
@click.option(
    "--save_location",
    prompt="Enter full path to save results",
    default=Path(".").resolve(),
)
def main(input_yaml: str, save_name: str, save_location: Union[str, Path]):
    """main scheme optimization code
    Args:
        input_yaml (str): yaml file containing user inputs as defined in SchemeConfiguration
        save_name (str): name to include in report files
        save_location (str, Path): Location to save report files
    """
    click.echo(f"Loading Configuration From {input_yaml}")
    click.echo(f"Saving Results in {save_location}")
    run_optimizer(
        input_yaml=input_yaml,
        save_name=save_name,
        save_location=save_location,
        filename_prefix=None,
    )


def default_filename_prefix(config: SchemeConfiguration, save_name: str) -> str:
    today = date.today().strftime("%Y%m%d")
    return (
        f"{config.application_config.application_name}_{config.instrument_config.serial_number}_"
        f"{today}_{save_name}"
    )


@validate_call(config=dict(arbitrary_types_allowed=True))
def run_optimizer(
    input_yaml: Union[str, SchemeConfiguration],
    save_name: str = Field(description="Name to use for saving results"),
    save_location: Union[str, Path] = Field(
        description="Location to save report files"
    ),
    cached_model_functions: Optional[dict[int, Callable]] = None,
    filename_prefix: Optional[str] = None,
) -> Path:
    """
    Run the scheme optimizer.

    Example usage (please note that there are many more options available,
    and in this example we are using the default values for many of them.
    See the SchemeConfiguration class for more details)

    1. Define cids, nominal pressure, forbidden regions, allowed_modes

    .. code-block:: python
        cids = [176, 180]  # application-specific
        pressure = 450
        forbidden_regions_file = 'path/to/forbidden_regions.txt'  # usually provided
        allowed_modes_file = 'path/to/SelectFromModesList.txt'  # optional, usually provided

    2. Get model functions (optional)

    .. code-block:: python

        from spectral_toolkit.scheme_optimizer.voc_fitter_functions import gather_model_functions
        mfs = gather_model_functions(cids=cids, nominal_pressure=450)

    3. Get InstrumentConfig from path

    .. code-block:: python

        from spectral_toolkit.data_models.scheme_optimizer_models import InstrumentConfig
        inst_config = InstrumentConfig.from_yaml("path/to/instrument_config.yaml")  # instrument-specific


    4. Define ApplicationConfig

    .. code-block:: python

        from spectral_toolkit.data_models.scheme_optimizer_models import ApplicationConfig
        app_config = ApplicationConfig(gas_list=cids)  # application-specific, other configs possible

    5. Define SchemeConfiguration

    .. code-block:: python

        from spectral_toolkit.data_models.scheme_optimizer_models import SchemeConfiguration
        config = SchemeConfiguration(
            instrument_config=inst_config,
            application_config=app_config,
            forbidden_regions=forbidden_regions_file,
            allowed_modes=allowed_modes_file,
        )

    6. Run optimizer

    .. code-block:: python

        from spectral_toolkit.scheme_optimizer.scheme_optimizer import run_optimizer
        run_optimizer(config, save_name='test', save_location='path/to/save')


    Args:
        input_yaml (str | SchemeConfiguration):
            SchemeConfiguration as yaml file or SchemeConfiguration object
        save_name (str): name to include in report files
        save_location (str, Path): Location to save report files
        cached_model_functions (Optional[dict[int, Union[Spline1d, Spline2d, SplinePoly]]], optional):
            Cache of model functions. Defaults to None.
            If a desired CID is not in the cache, it will be queried from database.
        filename_prefix (Optional[str]):
            Filename prefix to use for output files and subdirectory.

            If None defaults to: {application_name}_{serial_number}_{YYYYMMDD}_{save_name}

            Creates a filestructure like:
                {save_location} /
                    {filename_prefix} /
                        {filename_prefix}_{filename.extension}
        tvoc_cal (Optional[dict[int, float]]): value to pass into yaml output, defaults to {241: 3, 3776: 2}
    """
    # Start timer
    start_time = time.perf_counter()

    # Load config files
    if isinstance(input_yaml, (str, PathLike)):
        config = SchemeConfiguration.from_yaml(input_yaml)
    else:
        config = input_yaml

    # Get export paths
    if filename_prefix is None:
        filename_prefix = default_filename_prefix(config, save_name)
    export_path = Path(save_location) / filename_prefix

    if not export_path.exists():
        export_path.mkdir(parents=True, exist_ok=True)

    # Generate grid
    grid = create_full_grid(
        f_tracking=config.application_config.f_tracking,
        fsr=config.instrument_config.fsr,
        nu_padding=config.application_config.nu_pad_grid,
        nu_range=config.nu_range,
    )

    # Filter forbidden regions and filter for allowed modes
    grid = filter_grid(
        frequency_grid=grid,
        forbidden_regions=config.forbidden_regions,
        laser_gaps=config.instrument_config.laser_gaps,
        allowed_modes=config.allowed_modes,
        nu_padding_laser=config.application_config.nu_pad_grid,
    )

    # create gas sample and get model functions
    broadband_gas_sample = create_gas_sample(
        cid_list=config.application_config.gas_list
    )
    model_functions_splines = gather_model_functions(
        cids=config.application_config.gas_list + config.tvoc_cal_cids,
        cached_model_functions=cached_model_functions,
        nominal_pressure=config.application_config.cavity_pressure,
        use_exact_pressure=False,
    )
    model_functions = [
        1e3 * model_functions_splines[cid](grid.values)
        for cid in config.application_config.gas_list
    ]

    # Plot model functions
    fig = plot_model_functions(
        model_functions=model_functions,
        gas_list=config.application_config.gas_list,
        wavenumber_grid=grid,
    )
    fig.write_image(
        export_path / "model_functions_used.png", width=1200, height=800, scale=2
    )

    # Add baseline offset and slope to model_functions
    base0 = np.ones(grid.values.shape)
    base1 = grid.values - grid.values.mean()
    model_functions += [base0, base1]
    cid_list = config.application_config.gas_list + [0, -1]
    target_noise = np.array(
        [config.application_config.target_uncertainties.get(cid) for cid in cid_list]
    )

    # Create noise vector from baseline and shot-to-shot
    base_loss = voc_fitter_functions.baseline_creator(
        config.instrument_config.baseline_set,
        config.instrument_config.nuc_baseline,
        grid.values,
    )

    if isinstance(config.instrument_config.shot_to_shot, pd.Series):
        sh2sh = config.instrument_config.shot_to_shot[grid.index]
        LOGGER.info("Using mode-specific shot-to-shot noise from instrument config file")
    else:
        sh2sh = pd.Series(config.instrument_config.shot_to_shot, index=grid.index)
        LOGGER.info("Using global shot-to-shot noise from instrument config file")

    noise_vector = sh2sh.values / np.sqrt(2) * base_loss

    # Adjust nu_span to use full range if needed
    nu_max, nu_min = max(grid), min(grid)
    if config.application_config.use_full_span:
        nu_span_min = nu_max - nu_min - 2 * config.application_config.min_spacing
    else:
        nu_span_min = 0

    # Max performance is obtained by using all available modes
    max_performance_guess = np.arange(0, len(noise_vector))
    max_performance_guess = np.expand_dims(max_performance_guess, axis=0)

    max_performance = q_error(
        model_funcs=model_functions,
        measurement_noise=noise_vector,
        cid_list=cid_list,
        selected_modes_indexes=max_performance_guess,
    )
    reference_performance = max_performance.iloc[0]

    # Get pubchem df
    pubchem_df = get_pubchem_df()

    # Define constants for the optimization process
    constants = OptimizerConstants(
        cid_list=cid_list,
        measurement_noise=noise_vector,
        target_noise=target_noise,
        allowed_wavenumbers=grid.values,
        model_functions=model_functions,
        gas_sample=broadband_gas_sample,
        reference_performance=reference_performance,
        nu_span_min=nu_span_min,
        min_spacing=config.application_config.min_spacing,
        min_spacing_penalty=config.application_config.min_spacing_penalty,
        spread_points=config.application_config.spread_points,
        pubchem_df=pubchem_df,
    )

    # Load starting modes: random modes or previously provided modes
    starting_modes = load_initial_modes(
        schema_constants=constants,
        allowed_modes_number=config.application_config.points_in_scheme,
        file_path=export_path / f"{filename_prefix}_OptModeNums.txt",
    )

    # Scheme optimization routine
    LOGGER.info(f"Running optimization routing with {config.max_iterations} iterations")
    selected_modes_idxs, results_df = optimize_scheme(
        initial_modes_guess=starting_modes,
        schema_constants=constants,
        show_every=1,
        max_iterations=config.max_iterations,
    )

    np.savetxt(
        export_path / f"{filename_prefix}_OptModeNums.txt",
        selected_modes_idxs,
        fmt="%d",
    )

    # Get the finalized mode grid
    final_grid = process_mode_grid(
        selected_modes_idxs=selected_modes_idxs, full_grid=grid
    )

    # Print grid in terminal
    display_grid(modes_df=final_grid)

    # Export the finalized schema to file
    export_schema(
        modes_df=final_grid, file_path=export_path / f"{filename_prefix}_Scheme.txt"
    )

    tvoc_cal = {}

    nus = final_grid["wavenumber"].values

    for cid in config.tvoc_cal_cids:
        tvoc_cal[cid] = 1 / float(np.trapz(model_functions_splines[cid](nus), x=nus))

    # Export the schema as yaml
    export_schema_yaml(
        modes_df=final_grid, file_path=export_path / f"{filename_prefix}_Scheme.yml", tvoc_cal=tvoc_cal
    )

    final_grid.to_pickle(export_path / f"{filename_prefix}_grid.pkl")

    end_time = time.perf_counter()
    elapsed_time = datetime.timedelta(seconds=end_time - start_time)

    # Export the result log with config information
    export_results_summary(
        reference_results=reference_performance,
        results_log=results_df,
        gas_sample=broadband_gas_sample,
        config=config,
        elapsed_time=elapsed_time,
        export_path=export_path / f"{filename_prefix}_Data.json",
    )

    fig = plot_thumbnail_scheme(grid_stats=final_grid)
    fig.write_image(
        export_path / f"{filename_prefix}_scheme_stats.png",
        width=1200,
        height=800,
        scale=2,
    )

    fig = plot_model_schema(
        model_functions=model_functions,
        gas_list=config.application_config.gas_list,
        final_wavenumber_grid=final_grid.wavenumber,
        full_grid=grid,
    )
    fig.write_image(
        export_path / f"{filename_prefix}_FinalPlot.png",
        width=1200,
        height=800,
        scale=2,
    )

    return export_path


if __name__ == "__main__":
    main()
