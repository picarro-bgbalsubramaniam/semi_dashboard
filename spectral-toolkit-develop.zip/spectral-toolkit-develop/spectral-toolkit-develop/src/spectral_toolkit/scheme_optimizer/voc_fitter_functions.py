from enum import Enum
from typing import Optional, Union

from pydantic import validate_call, Field
from voc_fitter.model.cavity import Baseline
from voc_fitter.model.model import GasSample, GasSampleType

from spectral_toolkit.data_models.model_function import Spline1d, Spline2d, SplinePoly
from spectral_toolkit.db_clients.mongo_spectral_library import (
    get_mongo_spectral_library_client,
)
from spectral_toolkit.logger import get_logger
from spectral_toolkit.model_function.mongodb import get_model_functions

LOGGER = get_logger(__name__)


class BackgroundType(Enum):
    ROOM_AIR = 1
    DRY_ROOM_AIR = 2
    SYNTHETIC_AIR = 3


background_argument_map = {
    BackgroundType.ROOM_AIR: {
        "trace_gases": {280: 0.0004, 297: 2.0e-6},
        "inert_gases": {947: 0.7812, 977: 0.2095, 23968: 0.0093},
        "abundant_absorbers": {962: 0.012},
    },
    BackgroundType.DRY_ROOM_AIR: {
        "trace_gases": {280: 0.0004, 297: 2.0e-6},
        "inert_gases": {947: 0.7812, 977: 0.2095, 23968: 0.0093},
        "abundant_absorbers": {962: 1e-4},
    },
    BackgroundType.SYNTHETIC_AIR: {
        "trace_gases": {},
        "inert_gases": {947: 0.7812, 977: 0.2095, 23968: 0.0093},
        "abundant_absorbers": {},
    },
}


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def create_gas_sample(
    cid_list: list[int],
    background_gas: BackgroundType = BackgroundType.ROOM_AIR,
    additional_cids: list[int] = Field(default=[297, 962]),
) -> GasSample:
    """
    Create a GasSample with the given cid_list and background_gas.

    Args:
        cid_list (list[int]): The list of compound ids to add to the GasSample.
        background_gas (BackgroundType, optional):
            The background gas to use. Defaults to BackgroundType.ROOM_AIR.
        additional_cids (list[int], optional):
            Additional cids to add to the GasSample. Defaults to [297, 962].

    Returns:
        GasSample: The GasSample with the given cid_list and background_gas.
    """
    gas_sample = GasSample.create_sample(**background_argument_map[background_gas])
    for cid in cid_list + additional_cids:
        gas_sample.set_compound(cid, GasSampleType.ABSORBER, 1e-6)

    if gas_sample.regularization_needed:
        gas_sample.regularize_matrix()

    return gas_sample


def gather_model_functions(
    cids: list[int],
    cached_model_functions: Optional[dict[int, Union[Spline1d, Spline2d, SplinePoly]]] = None,
    nu_min: int = 5800,
    nu_max: int = 6300,
    nominal_pressure: float = 450.0,
    use_exact_pressure: bool = False,
) -> dict[int, Union[Spline1d, Spline2d, SplinePoly]]:
    """
    Gather model functions for a list of cids.
    If a cid is present in the model_functions argument, will use the corresponding model function.
    Otherwise, will query the database for model function.

    Args:
        cids (list[int]): cids to get model functions for
        cached_model_functions (Optional[dict[int, Spline1d | Spline2d | SplinePoly]], optional):
            Model functions to use, if available.
            Think of this as a cache of model functions.
            Defaults to None.
        nu_min (int, optional): minimum nu value to evaluate spline. Defaults to 5800.
        nu_max (int, optional): maximum nu value to evaluate spline. Defaults to 6300.
        nominal_pressure (float, optional): operating nominal pressure. Defaults to 140.0.
        use_exact_pressure (bool, optional): if true will not generate a model function if pressure doesn't match
        query_cids (Optional[Tuple[int]], optional): cids to get model functions for. Defaults to ().
    Returns:
        Dict: cid as key and model function data model
    """
    query_cids = (
        tuple(cids)
        if cached_model_functions is None
        else tuple(set(cids) - set(cached_model_functions.keys()))
    )

    db_model_functions = {}
    model_functions_out = cached_model_functions or {}

    LOGGER.info(f"Provided number of model functions: {len(model_functions_out)}")

    if len(query_cids) > 0:
        LOGGER.info(
            f"Querying database for {len(query_cids)} remaining model functions for species: {query_cids}"
        )
        client = get_mongo_spectral_library_client()
        db_model_functions = get_model_functions(
            client,
            nominal_pressure=nominal_pressure,
            nu_min=nu_min,
            nu_max=nu_max,
            use_exact_pressure=use_exact_pressure,
            query_cids=query_cids,
        )
        client.client.close()
    else:
        LOGGER.info(
            "No need to query model functions from database. Using the provided ones."
        )

    return {**db_model_functions, **model_functions_out}


def baseline_creator(poly_coefficients, baseline_nu_center, allowed_nu):
    baseline = Baseline(nuc=baseline_nu_center, base_order=len(poly_coefficients) - 1)
    baseline._set_baseline_polynomial(poly_coefficients, baseline_nu_center)
    return baseline(allowed_nu)
