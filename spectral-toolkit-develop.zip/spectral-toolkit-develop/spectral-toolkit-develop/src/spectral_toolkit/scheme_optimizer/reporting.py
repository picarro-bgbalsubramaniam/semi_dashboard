"""
Functions to update the user about the ongoing optimization process
and to export final results
"""
import json
from datetime import timedelta
from pathlib import Path
from typing import Sequence, Tuple, Dict
import yaml

import numpy as np
import pandas as pd
import voc_fitter.model.gas_sample

from spectral_toolkit.data_models.scheme_optimizer_models import SchemeConfiguration
from spectral_toolkit.db_clients.mongo_spectral_library import (
    get_mongo_spectral_library_client,
)
from spectral_toolkit.logger import get_logger
from spectral_toolkit.model_function.mongodb import get_pubchem_info

LOGGER = get_logger(__name__)

CONSTANTS_MAPPING = {
    0: "baseline_ppb/cm",
    -1: "slope_ppb/cm per wvn",
    -2: "quad_ppb/cm per wvn^2",
}


def report_cost_function(
    shuffled: Sequence[Tuple[float, int]], frequencies_array: np.ndarray
) -> str:
    """
    Report cost function values
    for shuffled modes couple.

    Args:
        shuffled (Sequence[Tuple[float, int]]):
            Nested tuple with, IN:
            - Jm (float): value of cost function J when m was added
            - m (int): added mode index
            OUT:
            - Jk (float): value of cost function J when k was removed
            - k (int): removed mode index
        frequencies_array (np.ndarray):
            Array of selected wavenumbers.

    Returns:
        str: Reported string.

    """
    txt = (
        f"OUT #{shuffled[1][1]} "
        f"f={frequencies_array[shuffled[1][1]]:.4f} "
        f"(J = {shuffled[1][0]:.8f}). "
        f"IN #{shuffled[0][1]} "
        f"f={frequencies_array[shuffled[0][1]]:.4f} "
        f"(J = {shuffled[0][0]:.8f})."
    )
    return txt


def get_pubchem_df() -> pd.DataFrame:
    """
    Get a DataFrame with CID as rows,
    and information about CIDs
    (including commonName) as columns.

    Returns:
        pd.DataFrame: PubChem info dataframe.
    """
    df_pubchem = pd.DataFrame()

    try:
        client = get_mongo_spectral_library_client()
        pubchem_info = get_pubchem_info(client)
        client.client.close()
    except Exception as err:
        LOGGER.warning(f"Could not access the spectral library: {err}")
    else:
        df_pubchem = pd.DataFrame.from_dict(pubchem_info, orient="index")
        df_pubchem.commonName = df_pubchem.commonName.str.title()

    return df_pubchem


def report_results(
    reference_results: pd.Series,
    logs_df: pd.DataFrame,
    gas_sample: voc_fitter.model.gas_sample.GasSample,
    pubchem_df: pd.DataFrame,
) -> str:
    """
    Get a table with CIDs
    and their estimated standard
    errors.

    Args:
        reference_results (pd.Series):
            Results if all the available points
            were used by a schema.
        logs_df (pd.DataFrame):
            Log of optimization process,
            with estimated standard errors
            for every CID at each step of
            the procedure.
        gas_sample (voc_fitter.model.gas_sample.GasSample):
            Typical gas sample.
        pubchem_df (pd.DataFrame):
            Contains information, such as
            compound name, for every CID.
            From :py:func:`.get_pubchem_df`.

    Returns:
        str: Table in string format.
    """
    target_header = "Max:".ljust(11)
    value_header = "Current:".ljust(10)
    start_header = "Start:".ljust(10)
    output = f"{target_header}{start_header}{value_header}\n"

    for cid in logs_df.columns:
        multiplier = 1.0
        value = logs_df[cid].iloc[-1]
        ref_value = reference_results[cid]
        start_value = logs_df[cid].iloc[0]

        if cid == 0:
            name = "baseline"
            units = "ppb/cm"
        elif cid == -1:
            name = "slope"
            units = "ppb/cm per wvn"
        elif cid == -2:
            name = "quad"
            units = "ppb/cm per wvn^2"
        else:
            if cid in pubchem_df.index:
                name = f"{pubchem_df.loc[cid, 'commonName']} - {cid}"
            else:
                name = f"{cid}"
            conc = value * gas_sample.concentrations[cid]
            units, multiplier = get_units(conc)
            value = conc * multiplier
            ref_value = ref_value * gas_sample.concentrations[cid] * multiplier
            start_value = start_value * gas_sample.concentrations[cid] * multiplier

        current = f"{value:.4g}".ljust(10)
        start = f"{start_value:.4g}".ljust(10)
        target = f"{ref_value:.1f}".ljust(11)
        row = f"{target}{start}{current} {units} ({name})"
        output += row + "\r\n"
    return output


def get_units(conc: float) -> str:
    """
    Return units based on concentration:
    '%%' - reports conc in percent
    'ppm'- parts per million
    'ppb'- parts per billion

    Args:
        conc (float):
            Concentration value
    Returns:
        str: Concentration suffix
    """
    if conc > 0.005:
        return "%%", 100
    elif 1.5e-6 > conc >= 0.005:
        return "ppm", 1e6
    else:
        return "ppb", 1e9


def display_grid(modes_df: pd.DataFrame) -> None:
    """
    Display a table with selected modes,
    their wavenumbers, and the dwell
    (#ringdowns).

    Args:
        modes_df:
            Dataframe with
            ``"mode_idx", "wavenumber", "dwell"``.
            From :py:func:`.process_mode_grid`

    Returns:
        None

    """
    display_cols = ["mode_idx", "wavenumber", "dwell"]
    display_table = modes_df[display_cols].to_markdown(
        index=False, tablefmt="github", floatfmt=[".0f", ".6f", ".0f"]
    )
    LOGGER.info(f"\nGrid results:\n{display_table}")


def _forbidden_regions_export(forbidden_regions: np.ndarray) -> Dict:
    try:

        forbidden = {
            "start": forbidden_regions[:, 0].tolist(),
            "end": forbidden_regions[:, 1].tolist(),
        }
    except ValueError as err:
        LOGGER.error("Forbidden regions dimensions must be [n x 2]")
        forbidden = {"start": "", "end": ""}
    finally:
        return forbidden


def export_schema(modes_df: pd.DataFrame, file_path: Path) -> None:
    """
    Export a table with selected modes,
    their wavenumbers, and the dwell
    (#ringdowns). to a text file.

    Args:
        modes_df:
            Dataframe with
            ``"mode_idx", "wavenumber", "dwell"``.
            From :py:func:`.process_mode_grid`

        file_path (Path):
            Path to a ``.txt`` file to be written.

    Returns:
        None

    """
    display_cols = ["mode_idx", "wavenumber", "dwell"]
    modes_df[display_cols].to_markdown(
        buf=file_path,
        index=False,
        tablefmt="plain",
        floatfmt=[".0f", ".6f", ".0f"],
        numalign="right",
        headers=[],
    )


def export_schema_yaml(modes_df: pd.DataFrame, file_path: Path, tvoc_cal: dict[int, float]) -> None:
    """Exports the same data as `export_schema` but in a yaml format

    Args:
        modes_df:
            Dataframe with
            ``"mode_idx", "wavenumber", "dwell"``.
            From :py:func:`.process_mode_grid`

        file_path (Path):
            Path to a ``.yaml`` file to be written.

    Returns:
        None
    """
    display_cols = ["mode_idx", "wavenumber", "dwell"]
    selected_data = modes_df[display_cols]

    with file_path.open("w") as fp:
        yaml.dump({"freq_modes": selected_data.to_dict("records"), "tvoc_cal": tvoc_cal}, fp)


def export_results_summary(
    reference_results: pd.Series,
    results_log: pd.DataFrame,
    gas_sample: voc_fitter.model.gas_sample.GasSample,
    config: SchemeConfiguration,
    elapsed_time: timedelta,
    export_path: Path,
):
    """
    Export results and initial
    configs to a json file.

    Args:
        reference_results (pd.Series):
            Results if all the available points
            were used by a schema.
        results_log (pd.DataFrame):
            Log of optimization process,
            with estimated standard errors
            for every CID at each step of
            the procedure.
        gas_sample (voc_fitter.model.gas_sample.GasSample):
            Represents gas sample conditions.
        config (SchemeConfiguration):
            Configuration file content.
        elapsed_time (timedelta):
            Elapsed optimization time.
        export_path (Path):
            Path to json file to be written.

    Returns:
        None.

    """
    percent_error = {
        cid: 100
        * np.abs(
            (reference_results[cid] - results_log[cid].iloc[-1])
            / reference_results[cid]
        )
        for cid in results_log.columns
    }

    performance_ppb = logs_to_ppb(logs_df=results_log, gas_sample=gas_sample)
    target_ppb = logs_to_ppb(
        logs_df=reference_results.to_frame().T, gas_sample=gas_sample
    )

    forbidden_regions_dict = _forbidden_regions_export(config.forbidden_regions)

    export_keys = {
        "name",
        "time_created",
        "created_by",
        "forbidden_regions_file",
        "max_iterations",
        "instrument_config_file",
        "application_config_file",
        "allowed_modes_file",
    }

    optimizer_results = {
        "scheme_config": config.model_dump(include=export_keys),
        "app_params": config.application_config.model_dump(),
        "instr_params": config.instrument_config.model_dump(),
        "run_time": str(elapsed_time),
        "start": performance_ppb.iloc[0].to_dict(),
        "final": performance_ppb.iloc[-1].to_dict(),
        "target": target_ppb.iloc[-1].to_dict(),
        "percent_error": percent_error,
        "num_iterations": results_log.index[-1] + 1,
        "forbidden_regions": forbidden_regions_dict,
        "allowed_modes": config.allowed_modes.astype(int).tolist(),
    }
    with open(export_path, "w") as json_out:
        json.dump(optimizer_results, json_out, sort_keys=False, indent=4)

    LOGGER.info(f"Exported output JSON summary to {export_path}")


def logs_to_ppb(
    logs_df: pd.DataFrame, gas_sample: voc_fitter.model.gas_sample.GasSample
) -> pd.DataFrame:
    exclude_columns = [col for col in logs_df.columns if col in [-2, -1, 0]]
    columns_to_scale = [col for col in logs_df.columns if col not in exclude_columns]

    scaled_df = logs_df.copy(deep=True)
    multiplier = 1e9  # Scale to ppb

    for cid in columns_to_scale:
        scaled_df[cid] = logs_df[cid] * gas_sample.concentrations[cid] * multiplier
        scaled_df = scaled_df.rename(columns={cid: f"{cid}_ppb"})

    scaled_df = scaled_df.rename(columns=CONSTANTS_MAPPING)
    return scaled_df


def process_mode_grid(
    selected_modes_idxs: np.ndarray, full_grid: pd.Series
) -> pd.DataFrame:
    """
    Given a full list of modes/wavenumbers,
    and a list of selected mode indexes,
    returns a dataframe with the selected modes, wavenumbers,
    and dwell counts.

    Args:
        selected_modes_idxs (np.ndarray):
            Selected mode indexes from optimization
            procedure.
        full_grid (pd.Series):
            Full grid of allowed wavenumbers (values)
            and their modes (indexes).
            From :py:func: `.filter_grid`.

    Returns:
        pd.DataFrame:
            Dataframe with the selected modes, wavenumbers,
            and dwell counts.

    """
    # Count occurrences of each mode
    dwell = pd.Series(selected_modes_idxs).value_counts()

    # Given the selected mode indexes, return the grid
    selected_grid = full_grid.reset_index()
    selected_grid = selected_grid.iloc[dwell.index]
    selected_grid = selected_grid.sort_values(by="mode_idx", ascending=True)
    selected_grid["dwell"] = dwell
    selected_grid["excess_dwell"] = dwell - 1
    return selected_grid
