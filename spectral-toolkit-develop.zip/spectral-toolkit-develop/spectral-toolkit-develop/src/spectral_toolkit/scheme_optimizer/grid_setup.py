"""
Functions to create and filter the mode grid.
"""
from itertools import chain
from pathlib import Path
from typing import List, Tuple

import numpy as np
import pandas as pd
from pydantic import validate_call

from spectral_toolkit.data_models.scheme_optimizer_models import \
    OptimizerConstants
from spectral_toolkit.logger import get_logger
from spectral_toolkit.scheme_optimizer.optimizer_routines import \
    random_modes_initialize

LOGGER = get_logger(__name__)


@validate_call()
def wavenumber_to_mode_index(wavenumber: float, f_tracking: float, fsr: float) -> int:
    """
    Returns the mode index correspondent to a given wavenumber.

    Args:
        wavenumber (float):
            A wavenumber to be converted.

        f_tracking (float):
            The reference frequency
            (expressed as a wavenumber).
            Typically, 6056.507.

        fsr (float):
            Free spectral range of the cavity.
            Typically, a value around 0.0206.

    Returns:
        int:
            Corresponding mode index.
    """
    mode = (wavenumber - f_tracking) / fsr
    mode_idx = int(round(mode))

    return mode_idx


@validate_call(config=dict(arbitrary_types_allowed=True))
def indexes_between(
    start: np.ndarray, forbidden_min: np.ndarray, forbidden_max: np.ndarray
) -> List:
    """
    Return the row numbers of `start`
    where `start` has value that lie in
    between any of the
    (forbidden_min, forbidden_max) pairs.

    Args:
        start (np.ndarray):
            Array containing values to be filtered.

        forbidden_min (np.ndarray):
            Array containing lower bounds of
            the (forbidden_min, forbidden_max) pairs.
            Must have same length of `forbidden_max`.

        forbidden_max (np.ndarray):
            Array containing upper bounds of
            the (forbidden_min, forbidden_max) pairs.
            Must have same length of `forbidden_min`.
    Returns:
        List:
            Indexes of `start`
            where `start` has value that lie in
            between any of the
            (forbidden_min, forbidden_max) pairs.

    """

    if len(forbidden_min) != len(forbidden_max):
        raise IndexError("Forbidden regions must have the same length")

    left_index = pd.Series(np.searchsorted(start, forbidden_min))
    right_index = pd.Series(np.searchsorted(start, forbidden_max))

    is_forbidden = left_index != right_index

    left_index = left_index[is_forbidden]
    right_index = right_index[is_forbidden]

    forbidden_indexes = [
        np.arange(left, right) for left, right in zip(left_index, right_index)
    ]

    forbidden_indexes = list(set(chain.from_iterable(forbidden_indexes)))

    return forbidden_indexes


@validate_call()
def create_full_grid(
    nu_range: Tuple[float, float], nu_padding: float, f_tracking: float, fsr: float
) -> pd.Series:
    """
    Create a full mode/frequency grid.

    Args:
        nu_range (Tuple[float, float]):
            Lower and upper bound of the desired
            frequency range.

        nu_padding (float):
            Padding extending ``nu_range``.

        f_tracking (float):
            The reference frequency
            (expressed as a wavenumber).
            Typically, 6056.507.

        fsr (float):
            Free spectral range of the cavity.
            Typically, a value around 0.0206.
    Returns:
        pd.Series:
            Full grid with wavenumbers as
            values and modes as index.

    """
    # Get min and max modes associated with nu range
    mode_min = wavenumber_to_mode_index(nu_range[0] + nu_padding, f_tracking, fsr)
    mode_max = wavenumber_to_mode_index(nu_range[1] - nu_padding, f_tracking, fsr)

    # Define a full mode grid
    modes_grid = np.arange(mode_min, mode_max, 1)

    # Define a frequency grid, with modes as indexes
    frequency_grid = pd.Series(data=f_tracking + fsr * modes_grid, index=modes_grid)
    frequency_grid.name = "wavenumber"
    frequency_grid.index.name = "mode_idx"

    LOGGER.info(f"Created new frequency grid of length {len(frequency_grid):.0f}")
    return frequency_grid


def filter_grid(
    frequency_grid: pd.Series,
    forbidden_regions: np.ndarray,
    laser_gaps: np.ndarray,
    allowed_modes: np.ndarray,
    nu_padding_laser: float = 0.02,
) -> pd.Series:
    """
    Returns a frequency grid with
    allowed frequencies and modes.

    Args:
        frequency_grid (pd.Series):
            Full grid with wavenumbers as
            values and modes as index.
        forbidden_regions (np.ndarray):
            Forbidden regions given as min-max pairs.
            Dimensions: [#exclusion_regions x 2]
        laser_gaps (np.ndarray):
            Laser gaps regions given as min-max pairs.
            Dimensions: [#laser_gaps_regions x 2]
        allowed_modes (np.ndarray):
            The only modes allowed in the grid.
            Dimensions: [#modes_allowed]
        nu_padding_laser (float):
            Left and right padding for laser gaps.

    Returns:
        pd.Series:
            Filtered grid with wavenumbers as
            values and modes as index.
    """

    # Drop possible negative frequencies
    LOGGER.info(
        f"Dropped negative frequencies (excluded {np.count_nonzero(frequency_grid <= 0):.0f})"
    )
    frequency_grid = frequency_grid[frequency_grid > 0]

    # Exclude forbidden regions
    forbidden_indexes = indexes_between(
        frequency_grid.values, forbidden_regions[:, 0], forbidden_regions[:, 1]
    )
    LOGGER.info(f"Dropped forbidden regions (excluded {len(forbidden_indexes):.0f})")
    frequency_grid = frequency_grid.drop(frequency_grid.index[forbidden_indexes])

    # Exclude laser gaps
    if any(laser_gaps):
        laser_gaps_arr = np.array(laser_gaps)

        # Pad laser gaps left and right
        laser_gaps_arr[:, 0] -= nu_padding_laser
        laser_gaps_arr[:, 1] += nu_padding_laser

        forbidden_indexes = indexes_between(
            frequency_grid.values, laser_gaps_arr[:, 0], laser_gaps_arr[:, 1]
        )
        frequency_grid = frequency_grid.drop(frequency_grid.index[forbidden_indexes])
        LOGGER.info(f"Dropped laser gaps (excluded {len(forbidden_indexes):.0f})")

    # Exclude modes not in allowed_modes
    if any(allowed_modes):
        allowed_modes = allowed_modes.astype(int)
        is_mode_allowed = np.isin(frequency_grid.index, allowed_modes)
        exclude_modes_indexes = frequency_grid.index[~is_mode_allowed]

        LOGGER.info(
            f"Dropped individual modes (excluded"
            f" {len(exclude_modes_indexes):.0f}"
            f")"
        )

        frequency_grid = frequency_grid.drop(index=exclude_modes_indexes)

    LOGGER.info(f"Returning grid of {len(frequency_grid):.0f} modes")
    return frequency_grid


def load_initial_modes(
    schema_constants: OptimizerConstants,
    allowed_modes_number: int,
    file_path: Path = None,
) -> np.ndarray:
    """
    Load starting modes from file,
    or create a random set of modes
    to start with.

    Args:
        schema_constants (OptimizerConstants):
            Constants for the optimizer process.
        allowed_modes_number (int):
            Number of modes required.
        file_path (Path):
            Path of the initial schema file.
            Usually ends with `_OptModeNums.txt`.

    Returns:
        np.ndarray:
            Modes index array of
            length ``allowed_modes_number``.

    """
    starting_modes = None

    if file_path is not None:
        if file_path.is_file():
            LOGGER.info(f"Loading scheme file as initial condition ({file_path})")
            starting_modes = np.loadtxt(file_path, dtype=int)

    if starting_modes is None:
        starting_modes = random_modes_initialize(
            random_try_number=3000,
            len_allowed=len(schema_constants.allowed_wavenumbers),
            len_modes=allowed_modes_number,
            schema_constants=schema_constants,
        )
    return starting_modes
