from datetime import datetime as dt
from pathlib import Path
from typing import List
import pandas as pd
import numpy as np
import pytz
import glob
import math
import os
from typing import Dict, Tuple
from plotly.subplots import make_subplots
import plotly.express as px
import plotly.graph_objects as go
from data_pooler.persist import get_combolog_from_zpickle
from spectral_toolkit.logger import get_logger
from spectral_toolkit.constants.td_constants import TDPeakDataFOM
from spectral_toolkit.sam_analysis.compactify import (
    _combo_data_for_transform,
    _compactify_spectra,
)
from spectral_arithmetic.aggregate_operations import transform_spectra
from spectral_arithmetic.data_models.spectra import BinnedSpectra
from spectral_toolkit.plotting.spectral_hunting_plot import (
    _get_performance_string,
    fit_result_plot,
)

LOGGER = get_logger(__name__)
TD_LOG_EXT = "*log.txt"
COLUMNS = 3
REQUIRED_STEPS = ["TRAPPING", "THERMAL_RAMP", "HOLDING"]
BASE_FORMAT = "%Y-%m-%dT%H:%M"
ISOFORMAT = "%Y-%m-%dT%H:%M:%S%z"


def get_td_log_names(
    td_log_path: Path,
    timezone: str,
    start_dt: pd.DatetimeIndex,
    end_dt: pd.DatetimeIndex,
):
    """
    Get log files to parse for analysis based on time range
    Args:
        td_log_path: Path
            file path where the Picarro run temperature logs are saved
        timezone: str
            pytz timezone string
        start_dt: pd.DataTimeIndex
            start of the experiment as a pandas DateTimeIndex
        end_dt: pd.DateTimeIndex
            end of the experiment as a pandas DateTimeIndex
    """
    if not td_log_path.exists():
        raise ValueError(f"Could not find TD log path - {td_log_path}")

    td_logs = os.path.join(td_log_path, TD_LOG_EXT)
    # only grab active run files, not idle files
    log_name_list = [f for f in glob.glob(td_logs) if "idle" not in f]
    log_name_list.sort()
    return_logs = []
    for log_name in log_name_list:
        df_temp = get_td_log_frame(log_name, timezone)

        if np.any(df_temp.index < start_dt[0]) or np.any(df_temp.index > end_dt[0]):
            continue

        # do not use a file that doesn't contain the appropriate steps and a desorb flag
        if ~(df_temp["current_state"] == "TRAPPING").any():
            LOGGER.warning(f"trap step not in {log_name}")
            continue
        elif ~df_temp["desorb_flag"].astype(bool).any():
            LOGGER.warning(f"no active desorption in {log_name}")
            continue
        elif ~(df_temp["current_state"] == "THERMAL_RAMP").any():
            LOGGER.warning(f"ramp step not in {log_name}")
            continue
        elif ~(df_temp["current_state"] == "HOLDING").any():
            LOGGER.warning(f"hold step not in {log_name}")
            continue

        return_logs.append(log_name)

    return sorted(return_logs)


def parse_td_sequence(
    td_log_path: Path,
    timezone: str,
    start_dt: dt,
    end_dt: dt,
) -> pd.DataFrame:
    """Parse runs from Picarro temperature logs.

    Args:
        td_log_path: Path
            file path where the Picarro run temperature logs are saved
        timezone: str
            pytz timezone string
        start_dt: pd.DataTimeIndex
            start of the experiment as a pandas DateTimeIndex
        end_dt: pd.DateTimeIndex
            end of the experiment as a pandas DateTimeIndex

    Returns:
        sequences: pd.DataFrame
            Pandas dataframe containing sequence data.
            Each line is one run, indexed by a timezone aware datetime index.
    """
    log_name_list = get_td_log_names(td_log_path, timezone, start_dt, end_dt)

    sequence_list = []
    for log_name in log_name_list:
        df_temp = get_td_log_frame(log_name, timezone)

        dict_now = {}

        trapping_frame = df_temp[df_temp["current_state"] == "TRAPPING"]
        dict_now["trap_time"] = (
            trapping_frame.index[-1] - trapping_frame.index[0]
        ).total_seconds()
        dict_now["trap_start_datetime"] = trapping_frame.index[0]
        dict_now["trap_end_datetime"] = trapping_frame.index[-1]

        cooling_frame = df_temp[df_temp["current_state"] == "INITIAL_COOLING"]
        dict_now["cooling_start"] = cooling_frame.index[0]
        dict_now["cooling_end"] = cooling_frame.index[-1]

        index_now = df_temp.index[df_temp["desorb_flag"].astype(bool)][
            0
        ]  # start of run/end of trap
        dict_now["end_datetime"] = df_temp.index[df_temp["desorb_flag"].astype(bool)][
            -1
        ]
        dict_now["end_run"] = df_temp.index[-1]
        dict_now["start_run"] = df_temp.index[0]
        dict_now["file"] = log_name

        if len(dict_now) > 0:
            df_now = pd.DataFrame(dict_now, index=[index_now])
            sequence_list.append(df_now)

    if len(sequence_list) > 0:
        sequences = pd.concat(sequence_list)
        sequences.index.name = "index"
    else:
        sequences = None
        LOGGER.warning("Unable to Find Sequences")

    return sequences


def get_td_log_frame(td_log_file: str, timezone: str) -> pd.DataFrame:
    """
    Convenience method to get the td log data frame with correct dt index
    Args:
        td_log_file: log file to create frame from
        timezone: timezone to convert index to
    Returns:
        dataframe with td log data
    """
    if not Path(td_log_file).exists():
        raise FileNotFoundError(f"Unable to find TD log file {td_log_file}")

    # Error will raise if file is empty
    df_temp = pd.read_csv(td_log_file, sep=",", index_col=False)
    df_temp.index = pd.to_datetime(1e9 * df_temp["current time"])
    tz = pytz.timezone(timezone)
    df_temp.index = df_temp.index.floor("S")
    df_temp.index = df_temp.index.tz_localize("UTC")
    df_temp.index = df_temp.index.tz_convert(tz)

    return df_temp


def get_desorb_time_and_flows(log_frame: pd.DataFrame) -> Tuple[float, float, float]:
    """
    Get the flows and desorb time for a given TD run
    Args:
        log_frame: TD log data frame

    Returns:
        Tuple of floats with desorb time, desorb flow, and trap flow
    """
    try:
        desorb_flow = float(log_frame.filter(like="DESORB_flow").median())
    except:
        desorb_flow = 0

    try:
        trap_flow = float(log_frame.filter(like="TRAP_flow").median())
    except:
        trap_flow = 0

    desorb_df = log_frame[log_frame["current_state"] == "TRAPPING"]
    desorb_time = (desorb_df.index[-1] - desorb_df.index[0]).total_seconds()

    return (desorb_time, desorb_flow, trap_flow)


def find_fom_peaks(
    combo_df: pd.DataFrame,
    start_run: dt,
    end_run: dt,
    figure_of_merit: str,
    event_number: int,
    config_name: str,
) -> TDPeakDataFOM:
    """
    This finds the peak and 50% and 5% cuts on either side of figure of merit peak
    Args:
        combo_df - Combo logs dataframe generated from data pooler.api.combined_logs
        start_run - datetime object for start of desorption run
        end_run - datetime object for end of desorption run
        figure_of_merit - column value to find peaks from
        event_number - event number for config running
        config_name - configuration being run with associated event number
    Returns:
        TDPeakDataFOM model for all peak metadata tagged for desorption run
    """
    LOGGER.info(
        f"Analyzing Desorption peak for configuration {config_name} event {event_number}"
    )
    start = dt.strptime(start_run, ISOFORMAT)
    end = dt.strptime(end_run, ISOFORMAT)

    combo_df_event = combo_df[start:end]
    time_vector = combo_df_event.index
    y_vector_original = combo_df_event[figure_of_merit]

    # Get 50% below each side of peak and 5%
    peak_min = y_vector_original.min()
    # subtract baseline
    y_vector = y_vector_original - peak_min
    peak = y_vector.idxmax()
    peak_num = y_vector.index.get_loc(peak)
    peak_val = y_vector[peak]
    peak_r = y_vector.loc[peak:]
    peak_r_idx = peak_r.loc[peak_r > 0.5 * peak_val].idxmin()
    peak_r_idx_outer = peak_r.loc[peak_r > 0.05 * peak_val].idxmin()
    peak_r_num = y_vector.index.get_loc(peak_r_idx)
    peak_r_num_outer = y_vector.index.get_loc(peak_r_idx_outer)

    # Do it again from opposite direction
    reverse_y = y_vector.iloc[::-1]
    peak_l = reverse_y.loc[peak:]
    peak_l_idx = peak_l.loc[peak_l > 0.5 * peak_val].idxmin()
    peak_l_idx_outer = peak_l.loc[peak_l > 0.05 * peak_val].idxmin()
    peak_l_num = y_vector.index.get_loc(peak_l_idx)
    peak_l_num_outer = y_vector.index.get_loc(peak_l_idx_outer)

    peak_model = TDPeakDataFOM(
        figure_of_merit=figure_of_merit,
        signal_x=time_vector,
        signal_y=y_vector,
        start_run=start_run,
        start_time_inner=time_vector[peak_l_num],
        end_time_inner=time_vector[peak_r_num],
        start_time_outer=time_vector[peak_l_num_outer],
        end_time_outer=time_vector[peak_r_num_outer],
        peak_time=time_vector[peak_num],
    )
    return peak_model


def create_spectra(
    combo_df: pd.DataFrame,
    start: str,
    end: str,
    f0_thresh: float = 3e-3,
    fsr_thresh: float = 3e-5,
    apply_transform: bool = False,
) -> Tuple[List[BinnedSpectra], pd.DataFrame]:
    """
    Create a list of BinnedSpectra for use in either ICA or difference isolations
    Args:
        combo_df: combo data frame for event desorption peak,
        start: start of desorption
        end: end of desorption
        f0_thresh: f0 limit difference
        fsr_thresh: fsr limit difference
        apply_transform: Whether or not to perform nu squish and shift transorm
    Returns:
        Tuple of list of binned spectra and the dataframe containing just desorption peak data
    """
    temp_df = combo_df[start:end]
    spectra = []
    cur_file = temp_df["spec_gen_file"][0]
    combo_gen = get_combolog_from_zpickle(open(cur_file, "r"))
    _ = next(combo_gen)
    for row in temp_df.itertuples():
        if row.spec_gen_file != cur_file:
            cur_file = row.spec_gen_file
            combo_gen = get_combolog_from_zpickle(open(cur_file, "r"))
            _ = next(combo_gen)

        spec = combo_gen.send(int(row.spec_gen_id))
        spec_arr = dict(zip(spec.columns.values, spec.values.T))
        extra_info = _combo_data_for_transform(row)
        spec_arr.update(extra_info)
        binned_spectrum = _compactify_spectra(
            [spec_arr], f0_thresh, fsr_thresh, apply_transform
        )
        spectra.append(binned_spectrum)
    return (spectra, temp_df)


def create_mode_dict(
    combo_df: pd.DataFrame,
    start: str,
    end: str,
    reference_spectrum,
    apply_transform: bool = True,
):
    """
    This is needed to format time series partial fit for Andrea's regression
    """
    temp_df = combo_df[start:end]
    cur_file = temp_df["spec_gen_file"][0]
    combo_gen = get_combolog_from_zpickle(open(cur_file, "r"))
    _ = next(combo_gen)
    specs = []
    modes = set()
    idxs = []
    nu_values = []
    for row in temp_df.itertuples():
        if row.spec_gen_file != cur_file:
            cur_file = row.spec_gen_file
            combo_gen = get_combolog_from_zpickle(open(cur_file, "r"))
            _ = next(combo_gen)

        spec = combo_gen.send(int(row.spec_gen_id))
        spec_arr = dict(zip(spec.columns.values, spec.values.T))
        extra_info = _combo_data_for_transform(row)
        spec_arr.update(extra_info)
        transformed_spectra = next(transform_spectra([spec_arr], apply_transform))[0]
        transformed_modes = sorted(
            list(
                set(transformed_spectra.mode_idxs).intersection(
                    set(reference_spectrum.modes)
                )
            )
        )
        modes.update(transformed_modes)
        idxs_int = np.where(np.in1d(transformed_spectra.mode_idxs, transformed_modes))[
            0
        ]
        try:
            partial_fit = (
                transformed_spectra.partial_fit[idxs_int]
                - reference_spectrum.partial_fit
            )
            specs.append(dict(zip(transformed_modes, partial_fit)))
            nu_values.append(dict(zip(transformed_modes, transformed_spectra.nu_prime)))
            idxs.append(row.Index)
        except Exception as e:
            # TODO: align modes to fix this.
            LOGGER.warning("Skipping spectrum with missing data")

    df_partial = pd.DataFrame(columns=sorted(list(modes)))
    df_nus = pd.DataFrame(columns=sorted(list(modes)))
    for idx, spec, nu_value in zip(idxs, specs, nu_values):
        matrix_row = pd.DataFrame(spec, index=[idx])
        df_partial = pd.concat([df_partial, matrix_row])
        nu_row = pd.DataFrame(nu_value, index=[0])
        df_nus = pd.concat([df_nus, nu_row])

    return (df_partial, df_nus.median())


############## PLOTS ############


def make_event_summary_plots(
    log_frame: pd.DataFrame, event_number: int, name: str
) -> go.Figure:
    """
    Make a summary plot for all desorption sensor data for a given event
    Args:
        log_frame: TD log data frame
        event_number: event number for configuration analyzed
        name: td configuration name
    Returns:
        plotly graph obejct figure for summary plot
    """
    LOGGER.info(
        f"Creating td data summary plot for configuration {name} and event number {event_number}"
    )

    states = log_frame["current_state"].unique()
    plot_number = len(log_frame.columns)
    rows = math.ceil(plot_number / COLUMNS)
    columns = log_frame.columns.tolist()
    columns.remove("current_state")
    fig = make_subplots(
        rows=rows,
        cols=COLUMNS,
        horizontal_spacing=0.04,
        vertical_spacing=0.03,
        shared_xaxes=True,
        subplot_titles=columns,
    )
    for i, column in enumerate(columns):
        if column == "current_state":
            continue
        for j, state in enumerate(states):
            if i == 0:
                show_legend = True
            else:
                show_legend = False
            # TODO: This is inefficient...
            temp_log = log_frame[log_frame["current_state"] == state]
            fig.add_scatter(
                x=temp_log.index,
                y=temp_log[column],
                marker_color=px.colors.qualitative.Plotly[j],
                name=state,
                legendgroup=state,
                showlegend=show_legend,
                row=int(i / COLUMNS) + 1,
                col=(i % COLUMNS) + 1,
            )
    fig.update_xaxes(showticklabels=True)
    height = (math.ceil(len(columns) / 4)) * 370
    event_time = log_frame.index[0].tz_localize(None).strftime(BASE_FORMAT)
    title = f"Sensor Data for Event starting at {event_time}"
    fig.update_layout(width=1500, height=height, title_text=title)

    return fig


def plot_found_peaks(
    time_vector: np.array,
    y_vector: np.array,
    peak: int,
    peak_left: int,
    peak_right: int,
    peak_left_outer: int,
    peak_right_outer: int,
    time_name: str,
    y_name: str,
) -> go.Figure:
    """
    Plot figure of merit time series with marks at 5% and 50% and the peak

    Args:
        time_vector: np.array vector of time data
        y_vector: np.array vector of the figure of merit values
        peak_ind: location of peak
        peak_left: location of left 50% mark
        peak_right: location of right 50% mark
        peak_left_outer: location of left 5% mark
        peak_right_outer: location of right 5% mark
        time_name: str time of event
        y_name: str name of the figure of merit variable

    Returns:
        plotly go.Figure
    """
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=time_vector, y=y_vector, line_color="grey"))
    fig.update_layout(
        xaxis_title="time", yaxis_title=y_name, title=f"Event starting at {time_name}"
    )
    fig.add_vline(x=peak, line_dash="solid", line_color="black")
    fig.add_vline(x=peak_left, line_dash="dash", line_color="green")
    fig.add_vline(x=peak_right, line_dash="dash", line_color="green")
    fig.add_vline(x=peak_left_outer, line_dash="dash", line_color="red")
    fig.add_vline(x=peak_right_outer, line_dash="dash", line_color="red")

    return fig


def create_refit_plot(
    nus: np.array,
    partial_fit: np.array,
    cids: List[int],
    score: float,
    rmse: float,
    wrmse: float,
    refit: np.ndarray,
    mfs: Dict[int, np.ndarray],
    title: str,
) -> go.Figure:
    """
    Create a plot with results from an iterative compound hunting and save results
    Args:
        nus: nu values for spectrum to fit
        partial_fit: partial fit of spectrum we tried to fit
        cids: list of cids used to fit
        score: score of fit
        rmse: rmse of fit
        wrmse: wrmse of fit
        refit: array of refit points
        mfs: model functions evaluated at nu
        title: title of plot
        analyzer: analyzer name
        name: configuration name
        number: event number
        plot_type: the type of plot we're cahcing, used in name saved as
    Returns:
        plotly graph object figure
    """
    experimental_datapoints = pd.Series(index=nus, data=partial_fit)
    concentrations = pd.Series(index=cids, data=refit)

    perf = pd.Series(data={"score": score, "rmse": rmse, "wrmse": wrmse})
    score_str = _get_performance_string(perf)

    def _get_absorption(concentration: float, mfs_nu: Dict, cid: int):
        return mfs_nu[cid] * concentration

    absorption_df = pd.DataFrame(
        data={
            int(cid): _get_absorption(conc, mfs, cid)
            for cid, conc in zip(concentrations.index, concentrations.values)
        },
        index=nus,
    )

    fig = fit_result_plot(
        experimental_datapoints=experimental_datapoints,
        absorption_df=absorption_df,
        concentrations=concentrations,
        species_colormap=None,
        annotations=score_str,
        title_text=title,
    )

    return fig
