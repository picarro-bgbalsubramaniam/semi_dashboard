from dotenv import dotenv_values
from pymongo import MongoClient, database
from typing import Optional


def get_mongo_spectral_library_client(
    env_file: Optional[str] = ".env", server_timeout_ms: int = 3000
) -> database.Database:
    """
    Create a mongo client for the spectral library that has a collection named
    PicarroCompundLibrary. Lets users specify a dot-env file that has the following
    variables:

    DB_URL: The host IP address or url for the database
    DB_USER: The user name for the database
    DB_PASS: The password for the username
    DB_PORT: Port number used for connecting to the database

    If a dot-env file is not passed in, then the client will attempt to connect to localhost
    without any authentication.

    After connecting, if the ``PicarroCompoundLibrary`` is not present, or if the connection
    is not successful, then this function will raise a ValueError.

    Arguments:
        env_file (str): A dot-env file that contains
        server_timeout_ms (int):
            The timeout for the server in milliseconds
            (the argument serverSelectionTimeoutMS to MongoClient).
            Defaults to 3000 (3s).

    Returns:
        client (pymongo.database.Database): Database client for mongodb
    """
    env_config = dotenv_values(env_file)
    db_url = env_config.get("DB_URL", "localhost")
    db_user = env_config.get("DB_USER")
    db_pass = env_config.get("DB_PASS")
    db_port = env_config.get("DB_PORT")
    if all((db_user, db_pass)):
        host_string = f"mongodb://{db_user}:{db_pass}@{db_url}"
    else:
        host_string = db_url
    client = MongoClient(
        host=host_string, port=db_port, serverSelectionTimeoutMS=server_timeout_ms
    )
    validate = client.PicarroCompoundLibrary.command("ping")
    if not validate["ok"] == 1.0:
        raise ValueError(f"Not able to connect to database at {host_string}:{db_port}")
    elif (
        "EmpiricalSpectra" not in client.PicarroCompoundLibrary.list_collection_names()
    ):
        raise ValueError("EmpiricalSpectra collection not found in mongodb.")
    return client.PicarroCompoundLibrary
