from functools import lru_cache, wraps
from datetime import datetime, timedelta
from typing import Callable


def timed_lru_cache(seconds: int = 86400, maxsize: int = None) -> Callable:
    """
    Basic timeout lru cache decorator, at this point only desired for model functions
    access.  More at https://gist.github.com/Morreski/c1d08a3afa4040815eafd3891e16b945
    Arguments:
        seconds (int): timeout in seconds, defaults to one day
        maxsize (int): maxsize of the cache, defaults to None

    Returns:
        Callable: wrapper function to apply cache timeout to
    """
    def wrapper_cache(func):
        func = lru_cache(maxsize=maxsize)(func)
        func.lifetime = timedelta(seconds=seconds)
        func.expiration = datetime.utcnow() + func.lifetime

        @wraps(func)
        def wrapped_func(*args, **kwargs):
            if datetime.utcnow() >= func.expiration:
                func.cache_clear()
                func.expiration = datetime.utcnow() + func.lifetime

            return func(*args, **kwargs)

        return wrapped_func

    return wrapper_cache
