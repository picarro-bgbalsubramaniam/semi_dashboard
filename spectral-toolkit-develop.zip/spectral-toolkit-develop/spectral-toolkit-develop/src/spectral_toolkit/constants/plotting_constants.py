from collections import namedtuple
from enum import Enum


class AllanDeviationCalculator(Enum):
    """Solution to use when calculating Allan deviation"""

    ALLANTOOLS_ADEV = 0
    ALLANTOOLS_OADEV = 1
    RELLA = 2
    SZE_TAN = 3


class PlotFileFormat(Enum):
    """Enumerator for exporting graph objects into different
    image formats"""

    PDF = "pdf"
    HTML = "html"
    PNG = "png"
    JSON = "json"


class ConcentrationUnits(Enum):
    """Enumerator for graph axis labels"""

    PPM = "ppm"
    PPB = "ppb"
    PPT = "ppt"


class Averaging(Enum):
    """Enumerator to give the user different pre-established choices
    for the time-averages in the basic plot"""

    ORIGINAL = ""
    TEN_SECONDS = "10S"
    THIRTY_SECONDS = "30S"
    ONE_MINUTE = "1T"
    HUNDRED_SECONDS = "100S"
    FIVE_MINUTES = "5T"
    TEN_MINUTES = "10T"
    THIRTY_MINUTES = "30T"
    ONE_HOUR = "1H"
    FOUR_HOURS = "4H"
    SIX_HOURS = "6H"
    TWELVE_HOURS = "12H"
    ONE_DAY = "24H"
    ONE_WEEK = "1W"



class Orientation(Enum):
    """Enumerator for grid line orientation"""

    HORIZONTAL = "h"
    VERTICAL = "v"


# Named tuple AveragesSelection
# label: Label text for plot menu button
# value: Width of the time windows to display (in hours)
# display_traces: Averaging traces to show when the label is selected
AveragesSelection = namedtuple(
    "AveragesSelection", ["label", "value", "display_traces"]
)
