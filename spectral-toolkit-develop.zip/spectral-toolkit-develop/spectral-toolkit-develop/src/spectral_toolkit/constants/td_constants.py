from pydantic import BaseModel, ConfigDict
import pandas as pd


class TDPeakDataFOM(BaseModel):
    """
    Contains all information from peak finding
    for a given desorption run
    """
    model_config = ConfigDict(arbitrary_types_allowed=True)

    figure_of_merit: str
    signal_x: pd.DatetimeIndex
    signal_y: pd.Series
    start_run: str
    start_time_inner: pd.Timestamp
    end_time_inner: pd.Timestamp
    start_time_outer: pd.Timestamp
    end_time_outer: pd.Timestamp
    peak_time: pd.Timestamp

