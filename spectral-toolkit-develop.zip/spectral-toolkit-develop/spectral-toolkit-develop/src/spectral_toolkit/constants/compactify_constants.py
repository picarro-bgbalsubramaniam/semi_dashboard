BIG3 = ["gasConcs_962", "gasConcs_280", "gasConcs_297"]
FREQ = [
    "fitData_nu_transform_n0",
    "fitData_nu_transform_n1",
    "fitData_nu_transform_nnuc",
    "fitData_fitdata_params_nucenter",
    "f0",
    "f0_shift",
]
