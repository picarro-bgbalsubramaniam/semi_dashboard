NUM_COMPOUNDS_DIFF = [1, 2, 3, 4]
REQUIRED_DIFFS = [180, 3776, 948, 222, 6324, 6325, 1140]
COMPOUNDS_IGNORE = [92831, 637513, 102, 103, 104]
NAMES = ["port", "ica_component_num", "max_ica_components"]
ABBREVS = ["P", "n", "N"]
LOOKUP = {name: abbrev for name, abbrev in zip(NAMES, ABBREVS)}
STATS_COLS = [
    "new_comps",
    "wrmse",
    "allan_dev",
    "span",
    "relative_contribution",
    "relative_error",
]
CONFIDENCE_K = 0.8
