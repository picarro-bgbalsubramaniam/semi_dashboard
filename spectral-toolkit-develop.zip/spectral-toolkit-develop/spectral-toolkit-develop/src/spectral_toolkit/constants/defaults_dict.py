import numpy as np
import copy

cross_defaults = {
    "names": ["H2O", "CO2", "CH4"],
    "H2O": {"Fit_0": "2"},
    "CO2": {"Fit_0": "1"},
    "CH4": {"Fit_0": "1"},
    "H2O*CH4": {"Fit_0": "0"},
    "H2O*CO2": {"Fit_0": "0"},
    "CO2*CH4": {"Fit_0": "0"},
}
cross_compound_range = {
    "H2O": (0.1, 4),
    "CO2": (0, 5000),
    "CH4": (0, 40),
    "broadband_gasConcs_962": (0.1e-2, 4e-2),
    "broadband_gasConcs_280": (0, 5000e-6),
    "broadband_gasConcs_297": (0, 40e-6),
}

voc_list = {
    "176": "ACETIC_ACID",
    "180": "ACETONE",
    "3776": "ISOPROPYL_ALCOHOL",
    "7900": "PGME",
    "7946": "PGMEA",
    "222": "NH3",
    "6368": "DIFLUOROETHANE",
    "10914": "D3_SILOXANE",
    "10911": "D6_SILOXANE",
    "284": "FORMIC_ACID",
    "24764": "HMDSO",
    "66110": "TRIMETHYL_SILANOL",
    "13387": "NMP",
    "948": "N2O",
    "241": "BENZENE",
    "1140": "TOLUENE",
    "7500": "ETHYLBENZENE",
    "7929": "M_XYLENE",
    "7237": "O_XYLENE",
    "7809": "P_XYLENE",
    "7845": "1_3_BUTADIENE",
    "402": "H2S",
    "177": "ACETALDEHYDE",
    "7847": "ACROLEIN",
    "712": "FORMALDEHYDE",
    "6556": "ISOPENTANE",
    "7843": "BUTANE",
    "8003": "PENTANE",
    "6360": "ISOBUTANE",
    "8900": "HEPTANE",
    "6334": "PROPANE",
    "7282": "3_METHYLPENTANE",
    "6324": "ETHANE",
    "8058": "HEXANE",
    "6325": "ETHYLENE",
    "8078": "CYCLOHEXANE",
    "10686": "1_2_3_TRIMETHYLBENZENE",
    "8182": "DODECANE",
    "7962": "METHYLCYCLOHEXANE",
    "356": "OCTANE",
    "7296": "METHYLCYCLOPENTANE",
    "6403": "2_2_DIMETHYLBUTANE",
    "11582": "2_METHYLHEXANE",
    "11507": "3_METHYLHEXANE",
    "6557": "ISOPRENE",
    "7892": "2_METHYLPENTANE",
    "8252": "PROPENE",
    "15600": "DECANE",
    "9253": "CYCLOPENTANE",
    "62695": "E_2_BUTENE",
    "887": "METHANOL",
    "6343": "ETHANETHIOL",
    "10913": "D5_SILOXANE",
    "11597": "1_HEXENE",
}

species_list = copy.deepcopy(voc_list)
species_list["280"] = "CO2"
species_list["297"] = "CH4"
species_list["962"] = "H2O"

big3 = {
    "280": ("broadband_gasConcs_280", 1e6, "CO2"),
    "297": ("broadband_gasConcs_297", 1e6, "CH4"),
    "962": ("broadband_gasConcs_962", 1e2, "H2O"),
}

N2_cross = {
    "twoN2962": ("twoGasVarWidths_N2_962", 1, "twoGasVarWidths_N2_962"),
    "twoN2297": ("twoGasVarWidths_N2_297", 1, "twoGasVarWidths_N2_297"),
    "waterN2962": ("water6099VarWidth_N2_962", 1, "water6099VarWidth_N2_962"),
}

name_dict = {}
name_dict["G2000"] = {}
name_dict["new"] = {}
name_dict["G2000"] = {
    "H2O_2": ("H2O", 1.0, "H2O"),
    "CO2_2": ("CO2", 1.0, "CO2"),
    "CH4_2": ("CH4", 1.0, "CH4"),
    "H2O": ("H2O_G", 1.0, "H2O"),
    "CO2": ("CO2_G", 1.0, "CO2"),
    "CH4": ("CH4_G", 1.0, "CH4"),
    "aa_ppb": ("aa_ppm", 1000.0, "aa"),
    "acetic_acid_ppb": ("acetic_acid_ppm", 1000.0, "acetic_acid"),
    "acetone_ppb": ("acetone_ppm", 1000.0, "acetone"),
    "ipa_ppb": ("ipa_ppm", 1000.0, "ipa"),
    "isopropyl_alcohol_ppb": ("isopropyl_alcohol_ppm", 1000.0, "isopropyl_alcohol"),
    "pgme_ppb": ("pgme_ppm", 1000.0, "pgme"),
    "pgmea_ppb": ("pgmea_ppm", 1000.0, "pgmea"),
    "nh3_ppb": ("nh3_ppm", 1000.0, "nh3"),
    "c2f2h4_ppb": ("c2f2h4_ppm", 1000.0, "c2f2h4"),
    "difluoroethane_ppb": ("difluoroethane_ppm", 1000.0, "difluoroethane"),
    "aa_ppm": ("aa_ppm", 1.0, "aa"),
    "acetic_acid_ppm": ("acetic_acid_ppm", 1.0, "acetic_acid"),
    "acetone_ppm": ("acetone_ppm", 1.0, "acetone"),
    "ipa_ppm": ("ipa_ppm", 1.0, "ipa"),
    "isopropyl_alcohol_ppm": ("isopropyl_alcohol_ppm", 1.0, "isopropyl_alcohol"),
    "pgme_ppm": ("pgme_ppm", 1.0, "pgme"),
    "pgmea_ppm": ("pgmea_ppm", 1.0, "pgmea"),
    "nh3_ppm": ("nh3_ppm", 1.0, "nh3"),
    "c2f2h4_ppm": ("c2f2h4_ppm", 1.0, "c2f2h4"),
    "difluoroethane_ppm": ("difluoroethane_ppm", 1.0, "difluoroethane"),
    #   'ACETIC_ACID':('ACETIC_ACID',1.0),
    #   'ACETONE':('ACETONE',1.0),
    #   'ISOPROPYL_ALCOHOL':('ISOPROPYL_ALCOHOL',1.0),
    #   'PGME':('PGME',1.0),
    #   'PGMEA':('PGMEA',1.0),
    #   'NH3':('NH3',1.0),
    #   'DIFLUOROETHANE':('DIFLUOROETHANE',1.0)
    "ACETIC_ACID": ("ACETIC_ACID_G", 1.0),
    "ACETONE": ("ACETONE_G", 1.0),
    "ISOPROPYL_ALCOHOL": ("ISOPROPYL_ALCOHOL_G", 1.0),
    "PGME": ("PGME_G", 1.0),
    "PGMEA": ("PGMEA_G", 1.0),
    "NH3": ("NH3_G", 1.0),
    "DIFLUOROETHANE": ("DIFLUOROETHANE_G", 1.0),
}
name_dict["new"] = {
    "H2O": ("broadband_gasConcs_962", 1e2, "962"),
    "CO2": ("broadband_gasConcs_280", 1e6, "280"),
    "CH4": ("broadband_gasConcs_297", 1e6, "297"),
    "aa_ppb": ("broadband_gasConcs_176", 1e9, "176"),
    "aa_ppm": ("broadband_gasConcs_176", 1e6, "176"),
    "acetic_acid_ppb": ("broadband_gasConcs_176", 1e9, "176"),
    "acetic_acid_ppm": ("broadband_gasConcs_176", 1e6, "176"),
    "acetone_ppb": ("broadband_gasConcs_180", 1e9, "180"),
    "acetone_ppm": ("broadband_gasConcs_180", 1e6, "180"),
    "ipa_ppb": ("broadband_gasConcs_3776", 1e9, "3776"),
    "ipa_ppm": ("broadband_gasConcs_3776", 1e6, "3776"),
    "isopropyl_alcohol_ppb": ("broadband_gasConcs_3776", 1e9, "3776"),
    "isopropyl_alcohol_ppm": ("broadband_gasConcs_3776", 1e6, "3776"),
    "pgme_ppb": ("broadband_gasConcs_7900", 1e9, "7900"),
    "pgme_ppm": ("broadband_gasConcs_7900", 1e6, "7900"),
    "pgmea_ppb": ("broadband_gasConcs_7946", 1e9, "7946"),
    "pgmea_ppm": ("broadband_gasConcs_7946", 1e6, "7946"),
    "nh3_ppb": ("broadband_gasConcs_222", 1e9, "222"),
    "nh3_ppm": ("broadband_gasConcs_222", 1e6, "222"),
    "c2f2h4_ppb": ("broadband_gasConcs_6368", 1e9, "6368"),
    "c2f2h4_ppm": ("broadband_gasConcs_6368", 1e6, "6368"),
    "difluoroethane_ppb": ("broadband_gasConcs_6368", 1e9, "6368"),
    "difluoroethane_ppm": ("broadband_gasConcs_6368", 1e6, "6368"),
    "d3_siloxane_ppb": ("broadband_gasConcs_10914", 1e9, "10914"),
    "d6_siloxane_ppb": ("broadband_gasConcs_10911", 1e9, "10911"),
    "formic_acid_ppb": ("broadband_gasConcs_284", 1e9, "284"),
    "hmdso_ppb": ("broadband_gasConcs_24764", 1e9, "24764"),
    "trimethyl_silanol_ppb": ("broadband_gasConcs_66110", 1e9, "66110"),
    "nmp_ppb": ("broadband_gasConcs_13387", 1e9, "13387"),
    "n2o_ppb": ("broadband_gasConcs_948", 1e9, "948"),
    "formic_acid_ppm": ("broadband_gasConcs_284", 1e6, "284"),
    "benzene_ppm": ("broadband_gasConcs_241", 1e6, "241"),
    "benzene_ppb": ("broadband_gasConcs_241", 1e9, "241"),
    "toluene_ppm": ("broadband_gasConcs_1140", 1e6, "1140"),
    "toluene_ppb": ("broadband_gasConcs_1140", 1e9, "1140"),
    "ethylbenzene_ppm": ("broadband_gasConcs_7500", 1e6, "7500"),
    "ethylbenzene_ppb": ("broadband_gasConcs_7500", 1e9, "7500"),
    "m_xylene_ppm": ("broadband_gasConcs_7929", 1e6, "7929"),
    "m_xylene_ppb": ("broadband_gasConcs_7929", 1e9, "7929"),
    "o_xylene_ppm": ("broadband_gasConcs_7237", 1e6, "7237"),
    "o_xylene_ppb": ("broadband_gasConcs_7237", 1e9, "7237"),
    "p_xylene_ppm": ("broadband_gasConcs_7809", 1e6, "7809"),
    "p_xylene_ppb": ("broadband_gasConcs_7809", 1e9, "7809"),
    "ethanethiol_ppm": ("broadband_gasConcs_6343", 1e6, "6343"),
    "ethanethiol_ppb": ("broadband_gasConcs_6343", 1e9, "6343"),
    "methanol_ppm": ("broadband_gasConcs_887", 1e6, "887"),
    "methanol_ppb": ("broadband_gasConcs_887", 1e9, "887"),
    "d5_siloxane_ppm": ("broadband_gasConcs_10913", 1e6, "10913"),
    "d5_siloxane_ppb": ("broadband_gasConcs_10913", 1e9, "10913"),
    "acrolein_ppm": ("broadband_gasConcs_7847", 1e6, "7847"),
    "acrolein_ppb": ("broadband_gasConcs_7847", 1e9, "7847"),
    "acetaldehyde_ppm": ("broadband_gasConcs_177", 1e6, "177"),
    "acetaldehyde_ppb": ("broadband_gasConcs_177", 1e9, "177"),
    "propane_ppm": ("broadband_gasConcs_6334", 1e6, "6334"),
    "propane_ppb": ("broadband_gasConcs_6334", 1e9, "6334"),
    "ethane_ppm": ("broadband_gasConcs_6324", 1e6, "6324"),
    "ethane_ppb": ("broadband_gasConcs_6324", 1e9, "6324"),
    "ethylene_ppm": ("broadband_gasConcs_6325", 1e6, "6325"),
    "ethylene_ppb": ("broadband_gasConcs_6325", 1e9, "6325"),
    "hexane_ppm": ("broadband_gasConcs_8058", 1e6, "8058"),
    "hexane_ppb": ("broadband_gasConcs_8058", 1e9, "8058"),
    "1_hexene_ppm": ("broadband_gasConcs_11597", 1e6, "11597"),
    "1_hexene_ppb": ("broadband_gasConcs_11597", 1e9, "11597"),
    "ACETIC_ACID": ("ACETIC_ACID", 1.0),
    "ACETONE": ("ACETONE", 1.0),
    "ISOPROPYL_ALCOHOL": ("ISOPROPYL_ALCOHOL", 1.0),
    "PGME": ("PGME", 1.0),
    "PGMEA": ("PGMEA", 1.0),
    "NH3": ("NH3", 1.0),
    "DIFLUOROETHANE": ("DIFLUOROETHANE", 1.0),
    "D3_SILOXANE": ("D3_SILOXANE", 1.0),
    "D6_SILOXANE": ("D6_SILOXANE", 1.0),
    "FORMIC_ACID": ("FORMIC_ACID", 1.0),
    "HMDSO": ("HMDSO", 1.0),
    "TRIMETHYL_SILANOL": ("TRIMETHYL_SILANOL", 1.0),
    "NMP": ("NMP", 1.0),
    "N2O": ("N2O", 1.0),
    "BENZENE": ("BENZENE", 1.0),
    "TOLUENE": ("TOLUENE", 1.0),
    "ETHYLBENZENE": ("ETHYLBENZENE", 1.0),
    "M_XYLENE": ("M_XYLENE", 1.0),
    "O_XYLENE": ("O_XYLENE", 1.0),
    "P_XYLENE": ("P_XYLENE", 1.0),
    "twoGasVarWidths_N2_962": ("twoGasVarWidths_N2_962", 1, "twoN2962", "width"),
    "twoGasVarWidths_N2_297": ("twoGasVarWidths_N2_297", 1, "twoN2297", "width"),
    "water6099VarWidth_N2_962": ("water6099VarWidth_N2_962", 1, "waterN2962", "width"),
    "1_3_butadiene_ppm": ("broadband_gasConcs_7845", 1e6, "7845"),
    "1_3_butadiene_ppb": ("broadband_gasConcs_7845", 1e9, "7845"),
    "isopentane_ppm": ("broadband_gasConcs_6556", 1e6, "6556"),
    "isopentane_ppb": ("broadband_gasConcs_6556", 1e9, "6556"),
    "cyclopentane_ppm": ("broadband_gasConcs_9253", 1e6, "9253"),
    "cyclopentane_ppb": ("broadband_gasConcs_9253", 1e9, "9253"),
    "petane_ppm": ("broadband_gasConcs_8003", 1e6, "8003"),
    "pentane_ppb": ("broadband_gasConcs_8003", 1e9, "8003"),
    "h2s_ppm": ("broadband_gasConcs_402", 1e6, "402"),
    "h2s_ppb": ("broadband_gasConcs_402", 1e9, "402"),
    "broadband_gasConcs_241": ("broadband_gasConcs_241", 1, "241"),
    "broadband_gasConcs_1140": ("broadband_gasConcs_1140", 1, "1140"),
    "broadband_gasConcs_7500": ("broadband_gasConcs_7500", 1, "7500"),
    "broadband_gasConcs_7929": ("broadband_gasConcs_7929", 1, "7929"),
    "broadband_gasConcs_7237": ("broadband_gasConcs_7237", 1, "7237"),
    "broadband_gasConcs_7809": ("broadband_gasConcs_7809", 1, "7809"),
    "broadband_gasConcs_7845": ("broadband_gasConcs_7845", 1, "7845"),
    "broadband_gasConcs_7847": ("broadband_gasConcs_7847", 1, "7847"),
    "broadband_gasConcs_6556": ("broadband_gasConcs_6556", 1, "6556"),
    "broadband_gasConcs_9253": ("broadband_gasConcs_9253", 1, "9253"),
    "broadband_gasConcs_8003": ("broadband_gasConcs_8003", 1, "8003"),
    "broadband_gasConcs_180": ("broadband_gasConcs_180", 1, "180"),
    "broadband_gasConcs_3776": ("broadband_gasConcs_3776", 1, "3776"),
    "broadband_gasConcs_222": ("broadband_gasConcs_222", 1, "222"),
    "broadband_gasConcs_948": ("broadband_gasConcs_948", 1, "948"),
    "broadband_gasConcs_402": ("broadband_gasConcs_402", 1, "402"),
    "isobutane_ppm": ("broadband_gasConcs_6360", 1e6, "6360"),
    "isobutane_ppb": ("broadband_gasConcs_6360", 1e9, "6360"),
    "1_butene_ppm": ("broadband_gasConcs_7844", 1e6, "7844"),
    "1_butene_ppb": ("broadband_gasConcs_7844", 1e9, "7844"),
    "E_2_butene_ppm": ("broadband_gasConcs_62695", 1e6, "62695"),
    "E_2_butene_ppb": ("broadband_gasConcs_62695", 1e9, "62695"),
    "Z_2_butene_ppm": ("broadband_gasConcs_5287573", 1e6, "5287573"),
    "Z_2_butene_ppb": ("broadband_gasConcs_5287573", 1e9, "5287573"),
    "neopentane_ppm": ("broadband_gasConcs_10041", 1e6, "10041"),
    "neopentane_ppb": ("broadband_gasConcs_10041", 1e9, "10041"),
    "neopentane_ppm": ("broadband_gasConcs_10041", 1e6, "10041"),
    "neopentane_ppb": ("broadband_gasConcs_10041", 1e9, "10041"),
    "butane_ppm": ("broadband_gasConcs_7843", 1e6, "7843"),
    "butane_ppb": ("broadband_gasConcs_7843", 1e9, "7843"),
    "heptanal_ppm": ("broadband_gasConcs_8130", 1e6, "8130"),
    "heptanal_ppb": ("broadband_gasConcs_8130", 1e9, "8130"),
    "propyne_ppm": ("broadband_gasConcs_6335", 1e6, "6335"),
    "propyne_ppb": ("broadband_gasConcs_6335", 1e9, "6335"),
    "ethanol_ppm": ("broadband_gasConcs_702", 1e6, "702"),
    "ethanol_ppb": ("broadband_gasConcs_702", 1e9, "702"),
    "methylcyclopentane_ppm": ("broadband_gasConcs_7296", 1e6, "7296"),
    "methylcyclopentane_ppb": ("broadband_gasConcs_7296", 1e9, "7296"),
    "isobutylene_ppm": ("broadband_gasConcs_8255", 1e6, "8255"),
    "isobutylene_ppb": ("broadband_gasConcs_8255", 1e9, "8255"),
    "2_3_dihydrofuran_ppm": ("broadband_gasConcs_70934", 1e6, "70934"),
    "2_3_dihydrofuran_ppb": ("broadband_gasConcs_70934", 1e9, "70934"),
    "propylene_ppm": ("broadband_gasConcs_8252", 1e6, "8252"),
    "propylene_ppb": ("broadband_gasConcs_8252", 1e9, "8252"),
}

trigger_defaults = {
    "H2O": {"name": "H2O", "threshold": 300},
    "CO2": {"name": "CO2", "threshold": 500},
    "CH4": {"name": "CH4", "threshold": 250},
    "conc_ppm": {"name": np.nan, "trigger": np.nan, "threshold": 1},
    "conc_ppb": {"name": np.nan, "trigger": np.nan, "threshold": 1e3},
    "conc_parts": {"name": np.nan, "trigger": np.nan, "threshold": 1e-6},
    "other": {"name": np.nan, "trigger": np.nan, "threshold": 1},
}

for key in trigger_defaults:
    trigger_defaults[key]["N"] = 5
    trigger_defaults[key]["point_delay"] = 0
    trigger_defaults[key]["startFraction"] = 0.1
    trigger_defaults[key]["endFraction"] = 0.05
    trigger_defaults[key]["mindur"] = 180
    trigger_defaults[key]["maxdur"] = 7200
    trigger_defaults[key]["startAbs"] = None
    trigger_defaults[key]["endAbs"] = None
    trigger_defaults[key]["pull_clean_data"] = True


G2000_big3_names = ["H2O", "CO2", "CH4"]

fitter_defaults = {
    "offset": 0.0,
    "linear": 0.0,
    "quad": 0.0,
    "bilinear": 0.0,
    "quad_linear": 0.0,
    "R2": 0.0,
    "fit_res_std": 0.0,
    "res_range": 0.0,
    "res_std": 0.0,
}

fit_defaults = {
    "mindur_G2000": 30,
    "maxdur_G2000": 1200,
    "mindur_new": 30,
    "maxdur_new": 1200,
    "startFraction": 0.05,
    "endFraction": 0.05,
}


def constants(name, dict_input=None):
    defaults = {
        "time_name": "EPOCH_TIME",
        "v": "solenoid_valves",
        "MFC": None,
        "compound": None,
        "h": "H2O",
        "filters": [],
        "valve_states": {},
        "MFC_states": {},
        "prefix": 5,
        "average": None,
        "min_pulse": None,
        "instr_name": [],
        "min_pulse_length": 50,
    }
    const_dict = dict()
    const_dict["HF"] = copy.deepcopy(defaults)
    const_dict["HF"]["compound"] = "HF"
    const_dict["HF"]["filters"].append(
        {"name": "HF species", "key": "species", "condition": "y != 60"}
    )
    const_dict["HF"]["average"] = 1.01
    const_dict["HF"]["min_pulse"] = 1.5  # was 0.7 (Blanchet-20190418)
    const_dict["HF"]["instr_name"] = ["MADS", "MBDS", "MCDS"]
    const_dict["HF"]["min_pulse_length"] = 49

    const_dict["HF_AMADS"] = copy.deepcopy(defaults)
    const_dict["HF_AMADS"]["compound"] = "HF"
    const_dict["HF_AMADS"]["filters"].append(
        {"name": "HF species", "key": "species", "condition": "y != 60"}
    )
    const_dict["HF_AMADS"]["average"] = 1.01
    const_dict["HF_AMADS"]["min_pulse"] = 1.5  # was 0.7 (Blanchet-20190418)
    const_dict["HF_AMADS"]["instr_name"] = ["AMADS", "AMBDS"]

    const_dict["HCl"] = copy.deepcopy(defaults)
    const_dict["HCl"]["compound"] = "HCl"
    const_dict["HCl"]["filters"].append(
        {"name": "HCl species", "key": "species", "condition": "y != 63"}
    )
    const_dict["HCl"]["average"] = 1.03
    const_dict["HCl"]["min_pulse"] = 1
    const_dict["HCl"]["instr_name"] = ["SADS", "SBDS"]

    const_dict["H2O_SxDS"] = copy.deepcopy(defaults)
    const_dict["H2O_SxDS"]["compound"] = "H2O"
    const_dict["H2O_SxDS"]["average"] = 1.03
    const_dict["H2O_SxDS"]["min_pulse"] = 0.015
    const_dict["H2O_SxDS"]["instr_name"] = ["SADS", "SBDS"]

    const_dict["NH3"] = copy.deepcopy(defaults)
    const_dict["NH3"]["compound"] = "NH3"
    const_dict["NH3"]["filters"].append(
        {"name": "NH3 species", "key": "species", "condition": "y != 4"}
    )
    const_dict["NH3"]["average"] = 1.15
    const_dict["NH3"]["min_pulse"] = 5
    const_dict["NH3"]["instr_name"] = ["AKDS", "AJDS"]

    const_dict["NH3_AHDS"] = copy.deepcopy(defaults)
    const_dict["NH3_AHDS"]["compound"] = "NH3"
    const_dict["NH3_AHDS"]["filters"].append(
        {"name": "NH3 species", "key": "species", "condition": "y != 2"}
    )
    const_dict["NH3_AHDS"]["average"] = 1.15
    const_dict["NH3_AHDS"]["min_pulse"] = 5
    const_dict["NH3_AHDS"]["instr_name"] = ["AHDS", "AEDS"]

    const_dict["NH3_AMADS"] = copy.deepcopy(defaults)
    const_dict["NH3_AMADS"]["compound"] = "NH3"
    const_dict["NH3_AMADS"]["filters"].append(
        {"name": "NH3 species", "key": "species", "condition": "y != 4"}
    )
    const_dict["NH3_AMADS"]["average"] = 1.15
    const_dict["NH3_AMADS"]["min_pulse"] = 5.0
    const_dict["NH3_AMADS"]["instr_name"] = ["AMADS", "AMBDS"]

    const_dict["H2O2"] = copy.deepcopy(defaults)
    const_dict["H2O2"]["compound"] = "H2O2"
    const_dict["H2O2"]["filters"].append(
        {"name": "H2O2 species", "key": "species", "condition": "y != 65"}
    )
    const_dict["H2O2"]["average"] = 1.01  # almost no averaging
    const_dict["H2O2"]["min_pulse"] = 25  # the test data I looked at has 900 ppb pulses
    const_dict["H2O2"]["instr_name"] = ["NBDS", "NCDS", "NDDS"]
    const_dict["H2O2"]["min_pulse_length"] = 30

    # H2S is BDDS only
    const_dict["H2S"] = copy.deepcopy(defaults)
    const_dict["H2S"]["compound"] = "H2S"
    const_dict["H2S"]["h"] = "HDO_ref"
    const_dict["H2S"]["filters"].append(
        {"name": "H2S species", "key": "species", "condition": "y != 1"}
    )
    const_dict["H2S"]["average"] = 1.05  # moderate averaging
    const_dict["H2S"]["min_pulse"] = 10  # the test data I looked at has 100 ppb pulses
    const_dict["H2S"]["instr_name"] = ["BDDS"]
    const_dict["H2S"]["min_pulse_length"] = 30

    const_dict["H2S_BFADS"] = copy.deepcopy(defaults)
    const_dict["H2S_BFADS"]["compound"] = "H2S"
    const_dict["H2S_BFADS"]["filters"].append(
        {"name": "H2S species", "key": "species", "condition": "y != 1"}
    )
    const_dict["H2S_BFADS"]["average"] = 1.05  # moderate averaging
    const_dict["H2S_BFADS"][
        "min_pulse"
    ] = 10  # the test data I looked at has 100 ppb pulses
    const_dict["H2S_BFADS"]["instr_name"] = ["BFADS"]
    const_dict["H2S_BFADS"]["min_pulse_length"] = 30

    const_dict["SO2"] = copy.deepcopy(defaults)
    const_dict["SO2"]["v"] = "ValveMask"
    const_dict["SO2"]["compound"] = "SO2_raw"
    const_dict["SO2"]["filters"].append(
        {"name": "SO2 species", "key": "SpectrumID", "condition": "y != 210"}
    )
    const_dict["SO2"]["average"] = 1.15
    const_dict["SO2"]["min_pulse"] = 5
    const_dict["SO2"]["instr_name"] = ["UADS"]

    const_dict["ETO"] = copy.deepcopy(defaults)
    const_dict["ETO"]["v"] = "ValveMask"
    const_dict["ETO"]["compound"] = "EtO"
    const_dict["ETO"]["filters"].append(
        {"name": "ETO species", "key": "species", "condition": "y != 181"}
    )
    const_dict["ETO"]["average"] = 1.05
    const_dict["ETO"]["min_pulse"] = 5
    const_dict["ETO"]["instr_name"] = ["UV"]

    const_dict["PGMEA"] = copy.deepcopy(defaults)
    const_dict["PGMEA"]["time_name"] = "JULIAN_DAYS"
    const_dict["PGMEA"]["MFC"] = "MFC3_flowset"
    const_dict["PGMEA"]["compound"] = "PGMEA_G"
    const_dict["PGMEA"]["h"] = "H2O_G"
    const_dict["PGMEA"]["average"] = 1.05
    const_dict["PGMEA"]["min_pulse"] = 5
    const_dict["PGMEA"]["instr_name"] = ["UV"]

    const_dict["ACETIC_ACID"] = copy.deepcopy(defaults)
    const_dict["ACETIC_ACID"]["time_name"] = "JULIAN_DAYS"
    const_dict["ACETIC_ACID"]["MFC"] = "MFC3_flowset"
    const_dict["ACETIC_ACID"]["compound"] = "ACETIC_ACID_G"
    const_dict["ACETIC_ACID"]["h"] = "H2O_G"
    const_dict["ACETIC_ACID"]["average"] = 1.05
    const_dict["ACETIC_ACID"]["min_pulse"] = 5
    const_dict["ACETIC_ACID"]["instr_name"] = ["UV"]

    const_dict["PGMEA_G"] = copy.deepcopy(defaults)
    const_dict["PGMEA_G"]["time_name"] = "JULIAN_DAYS"
    const_dict["PGMEA_G"]["MFC"] = "MFC3_flowset"
    const_dict["PGMEA_G"]["compound"] = "PGMEA_G"
    const_dict["PGMEA_G"]["h"] = "H2O_G"
    const_dict["PGMEA_G"]["average"] = 1.05
    const_dict["PGMEA_G"]["min_pulse"] = 5
    const_dict["PGMEA_G"]["instr_name"] = ["UV"]

    const_dict["ACETIC_ACID_G"] = copy.deepcopy(defaults)
    const_dict["ACETIC_ACID_G"]["time_name"] = "JULIAN_DAYS"
    const_dict["ACETIC_ACID_G"]["MFC"] = "MFC3_flowset"
    const_dict["ACETIC_ACID_G"]["compound"] = "ACETIC_ACID_G"
    const_dict["ACETIC_ACID_G"]["h"] = "H2O_G"
    const_dict["ACETIC_ACID_G"]["average"] = 1.05
    const_dict["ACETIC_ACID_G"]["min_pulse"] = 5
    const_dict["ACETIC_ACID_G"]["instr_name"] = ["UV"]

    const_dict["VOC"] = copy.deepcopy(defaults)
    const_dict["VOC"]["time_name"] = "JULIAN_DAYS"
    const_dict["VOC"]["h"] = "H2O"
    const_dict["VOC"]["average"] = 1.05
    const_dict["VOC"]["min_pulse"] = 5
    const_dict["VOC"]["instr_name"] = ["UV"]

    if name in const_dict:
        return_dict = const_dict[name]
    else:
        return_dict = const_dict["VOC"]
        return_dict["compound"] = name
        print(name)

    for key in dict_input:
        return_dict[key] = dict_input[key]

    return return_dict
