# These are constants used in defining analysis
# in experiment.json file

RAW_CONCENTRATIONS = [
    "ACETIC_ACID_raw",
    "ACETONE_raw",
    "CH4_VOC_raw",
    "CO2_VOC_raw",
    "D3_SILOXANE_raw",
    "D6_SILOXANE_raw",
    "FORMIC_ACID_raw",
    "H2O_VOC_raw",
    "HMDSO_raw",
    "ISOPROPYL_ALCOHOL_raw",
    "N2O_raw",
    "NH3_VOC_raw",
    "NMP_raw",
    "PGMEA_raw",
    "PGME_raw",
    "TRIMETHYL_SILANOL_raw",
]

GAS_CONCENTRATIONS = [
    "broadband_gasConcs_10911",
    "broadband_gasConcs_10914",
    "broadband_gasConcs_13387",
    "broadband_gasConcs_176",
    "broadband_gasConcs_180",
    "broadband_gasConcs_222",
    "broadband_gasConcs_24764",
    "broadband_gasConcs_280",
    "broadband_gasConcs_284",
    "broadband_gasConcs_297",
    "broadband_gasConcs_3776",
    "broadband_gasConcs_66110",
    "broadband_gasConcs_7900",
    "broadband_gasConcs_7946",
    "broadband_gasConcs_948",
    "broadband_gasConcs_962",
]

CONTROLS = [
    "CavityTemp",
    "CavityTemp1",
    "CavityTemp2",
    "CavityTemp3",
    "CavityTemp4",
    "DasTemp",
    "EtalonTemp",
    "FilterHeaterTemp",
    "HotBoxHeatsinkTemp",
    "Laser1Temp",
    "Laser3Temp",
    "Laser4Temp",
    "WarmBoxHeatsinkTemp",
    "WarmBoxTemp",
    "AmbientPressure",
    "CavityPressure",
    "cavityPressureMax",
    "cavityPressureMean",
    "cavityPressureMin",
    "cavityPressureStd",
    "OutletValve",
    "ValveMask",
    "ValveMaskOld",
]

SPECTROSCOPIC = [
    "pztValueMean",
    "pztValueStd",
    "tunerValueMean",
    "tunerValueStd",
    "broadband_rmse",
    "threeGasVarP_rmse",
    "threeGas_rmse",
    "water5962_rmse",
    "water6099_rmse",
    "broadband_fitData_baseline_baselineCoeffs_0",
    "broadband_fitData_baseline_baselineCoeffs_1",
    "threeGasVarP_fitData_baseline_baselineCoeffs_0",
    "threeGasVarP_fitData_baseline_baselineCoeffs_1",
    "threeGas_fitData_baseline_baselineCoeffs_0",
    "threeGas_fitData_baseline_baselineCoeffs_1",
    "water5962_fitData_baseline_baselineCoeffs_0",
    "water5962_fitData_baseline_baselineCoeffs_1",
    "water6099_fitData_baseline_baselineCoeffs_0",
    "water6099_fitData_baseline_baselineCoeffs_1",
    "broadband_f0",
    "broadband_f0_shift",
    "broadband_fitData_nu_transform_n0",
    "broadband_fitData_nu_transform_n1",
]

SPECIAL = [
    "threeGasVarP_fitResults_2_P",
    "dm_latency",
    "numGroups",
    "numRingdowns",
    "broadband_fitTime",
    "_group",
]

CANARIES = [
    "ACETIC_ACID_raw",
    "D3_SILOXANE_raw",
    "D6_SILOXANE_raw",
    "FORMIC_ACID_raw",
    "HMDSO_raw",
    "NMP_raw",
    "TRIMETHYL_SILANOL_raw",
]

WORKHORSES = [
    "broadband_gasConcs_180",
    "broadband_gasConcs_3776",
    "broadband_gasConcs_1140",
    "broadband_gasConcs_7344",
]

GHOSTS = [
    "broadband_gasConcs_222",
    "broadband_gasConcs_280",
    "broadband_gasConcs_297",
    "broadband_gasConcs_402",
    "broadband_gasConcs_6324",
    "broadband_gasConcs_6344",
    "broadband_gasConcs_8003",
    "broadband_gasConcs_948",
    "broadband_gasConcs_962",
]
