from spectral_toolkit.data_models.allantools import oadev
from spectral_toolkit.logger import get_logger
from spectral_arithmetic.linear_least_squares import least_squares
from spectral_toolkit.db_clients.mongo_spectral_library import (
    get_mongo_spectral_library_client,
)
from spectral_toolkit.model_function.mongodb import model_function, get_model_functions
from spectral_toolkit.constants import identification_constants as ic
from spectral_toolkit.constants.mimics import mimics
import collections
import itertools
import scipy.interpolate
from enum import Enum
from math import factorial
import pandas as pd
import numpy as np
from typing import List, Dict, Any, Tuple
import copy


LOGGER = get_logger(__name__)


def _load_mimics(mimics=mimics):
    """
    Load the existing mimics from json file and create model
    """
    mimics_return = {}
    for cid in mimics.keys():
        mimics_return[int(cid)] = scipy.interpolate.interp1d(
            mimics[cid]["nu"], mimics[cid]["absorption"], fill_value="extrapolate"
        )
    return mimics_return


# The one function that uses mongo directly
def _get_model_functions(
    nu_min: int = 5800, nu_max: int = 6300, nominal_pressure: float = 140.0, cids: List[int]=None
):
    """
    Conveninece function to get all model functions for compounds in library
    """
    client = get_mongo_spectral_library_client()
    if cids is None:
        # I hope no one ever tried to do this in python
        cids = client.EmpiricalSpectra.distinct("cid")
    model_functions = {}
    for cid in cids:
        try:
            model_functions[cid] = model_function(
                client,
                cid=cid,
                nu_min=nu_min,
                nu_max=nu_max,
                nominal_pressure=nominal_pressure,
            )
        except Exception as e:
            LOGGER.warning(f"Unable to aquire model function for {cid}: {e}")
    client.client.close()
    return model_functions


class FitStat(Enum):
    RMSE = "rmse"
    NON_NEGATIVE = "negative_penalty"
    MODEL_FUNC_AMP = "span"
    WRMSE = "wrmse"
    RELATIVE_ERR = "relative_error"
    MF_STD = "mf_std"
    REL_CONTRIBUTION = "relative_contribution"
    ALLAN_DEV = "allan_dev"


class IsoType(Enum):
    DIFFERENCE = "difference"
    CORRELATION = "correlation"


# All of below are conveninece functions that
# can be refactored further for organization
def _compute_negative_penalty(
    fit: np.ndarray,
    a_list: List[np.ndarray],
    parameter_names: List[str],
    negative_exclude_list: List = [],
    use_short_names: bool = False,
):
    """
    Compute penalty for each parameter based on model
    function and poly coeffs
    Args:
        fit: fit poloynomial from least squares
        a_list: model function vector
        parameter_names: names of compounds
        negative_exclude_list: negative vocs to xclude
        use_short_names: use short naming
    Returns:
        penalty to report in statistics
    """
    var = 0
    for vect, coeff, pname in zip(a_list, fit, parameter_names):
        if pname != "offset":
            if use_short_names:
                cid = int(float(pname))
            else:
                cid = int(float(pname.split(":")[0]))
            if cid not in negative_exclude_list:
                if coeff < 0:
                    var += np.sum((vect * coeff) ** 2)
    return np.sqrt(var)


def _compute_model_func_std(
    fit: np.ndarray, a_list: List[np.ndarray], parameter_names: List[str]
) -> float:
    """
    Get std of vector times poly coeff
    Args:
        fit: fit poloynomial from least squares
        a_list: model function vector
        parameter_names: names of compounds
    Returns:
        std of vector times poly coeff
    """
    var = 0
    for vect, coeff, pname in zip(a_list, fit, parameter_names):
        var += np.mean((vect * coeff) ** 2)
    return np.sqrt(var)


def _compute_weighted_std(y_fit: np.ndarray, loss: np.ndarray, std_err: np.ndarray):
    """
    Computes weighted std of residuals.
    Args:
        y_fit: least squares fit results
        loss: original loss
        std_err: passed in std_err
    Returns:
        weighted std
    """
    residuals = loss - y_fit
    weights = 1 / std_err
    var = np.sum(weights * residuals**2) / np.sum(weights)
    return np.sqrt(var)


def _compute_relative_error(y_fit: np.ndarray, loss: np.ndarray, std_err: np.ndarray):
    """
    Computes relative error of residuals.
    Args:
        y_fit: least squares fit results
        loss: original loss
        std_err: passed in std_err
    Returns:
        weighted std
    """
    residuals = loss - y_fit
    relevance = np.sum(residuals**2 / std_err**2) / len(residuals)
    return np.sqrt(relevance)


def _compute_pos_neg_span(
    fit: np.ndarray, a_list: List[np.ndarray], parameter_names: List[str]
) -> float:
    """
    Computes the sum of the means of original vector and fit poly
    Args:
        fit: fit poloynomial from least squares
        a_list: model function vector
        parameter_names: names of compounds
    Returns:
        span of sum of average of coeff * vec
    """
    positive = 0
    negative = 0
    for vect, coeff in zip(a_list, fit):
        if coeff > 0:
            positive += np.mean(coeff * vect)
        else:
            negative += np.mean(-coeff * vect)
    return positive + negative


def _compute_relative_contribution(
    fit: np.ndarray,
    a_list: List[np.ndarray],
    extra_cids: List[str],
) -> float:
    """extra_cids are always first, contiburtion of signal over total"""
    total_signal = 0
    extra_signal = 0
    for j, (vect, coeff) in enumerate(zip(a_list, fit)):
        mean_loss = abs(np.mean(coeff * vect))
        if j < len(extra_cids):
            extra_signal += mean_loss
        total_signal += mean_loss

    return extra_signal / total_signal


def _get_default_error(nu: np.ndarray):
    """
    Default error array if not provided
    """
    return 500 * 2e-4 / np.sqrt(np.ones(nu.shape) * 2)


def _make_record(result_dict: Dict, names: Dict):
    """
    Makes a string record of CIDS used in fit
    Args:
        results_dict:
    """
    for ident, result in result_dict.items():
        row = {(f"CID_{i}"): val for i, val in enumerate(ident)}
        new_cids = " & ".join([names[val] for val in ident])
        row["new_comps"] = new_cids
        row.update(result)
        yield row


def _make_names(model_functions: Dict, use_short_names: bool) -> Dict:
    """
    Convenience to make names for the compounds model functions
    Args:
        model_functions: dicitonary of cids and model functions
        use_short_names: just use CID for name
    Returns:
        names dictionary with cid as lookup key
    """
    names = {}
    for cid in model_functions.keys():
        # TODO: Look at bringing in hitran names from db
        this_name = str(model_functions[cid])
        names[cid] = str(cid) if use_short_names else this_name
    return names


def _compute_allan(y_fit: np.ndarray, loss: np.ndarray):
    """
    Wrapper to perform allan dev on residuals
    Args:
        y_fit: least squares fit results
        loss: original loss
    Returns:
        First term of allan deviation
    """
    res = loss - y_fit
    (_, allan_devs, _, _) = oadev(res)
    return allan_devs[0]


class ProcessStepSpectrum:
    """
    This class refits a spectrum with defined vocs looking for best combination
    to find unknown(s)
    """

    parameter_names = None
    a_list = None
    fit = None
    stats = None

    def __init__(
        self,
        nu,
        loss,
        model_functions,
        required_cids,
        std_err=None,
        use_short_names=False,
        negative_exclude_list=[],
    ):
        self.nu = nu
        self.loss = loss
        self.required_cids = required_cids
        self.negative_exclude_list = negative_exclude_list
        self.use_short_names = use_short_names
        self.std_err = std_err if std_err is not None else _get_default_error()
        self.load_model_functions(model_functions)
        self.names = _make_names(model_functions, use_short_names)
        self.set_required(required_cids)

    def load_model_functions(self, model_functions_obj):
        self.model_functions_obj = model_functions_obj
        self.model_functions = {}
        for cid, EC in model_functions_obj.items():
            self.model_functions[cid] = EC(self.nu)

    def create_required_model_functions(self):
        self.default_model_functions = [np.ones(self.nu.shape)]
        self.default_names = ["offset"]
        for rcid in self.required_cids:
            self.default_model_functions.append(self.model_functions[rcid])
            self.default_names.append(self.names[rcid])

    def set_required(self, rcids):
        self.required_cids = rcids
        self.create_required_model_functions()
        self.results = {}
        self.process_spectrum_default()

    def execute_fit(self, new_model_functions, new_names):
        """
        Fit data with new model functions and update fit and stats
        """
        model_functions = new_model_functions + self.default_model_functions
        self.parameter_names = new_names + self.default_names
        self.a_list = model_functions
        self.fit, self.stats = least_squares(
            np.vstack(tuple(model_functions)).T, self.loss, self.std_err
        )

    def get_fit_statistics(self, extra_cids):
        """
        Gather all the statistic from latest leasts squares fit
        """
        stats = {}
        stats["rmse"] = np.std(self.stats.residual_error)
        stats["negative_penalty"] = _compute_negative_penalty(
            self.fit,
            self.a_list,
            self.parameter_names,
            self.negative_exclude_list,
            self.use_short_names,
        )
        stats["model_functions_std"] = _compute_model_func_std(
            self.fit, self.a_list, self.parameter_names
        )
        stats["wrmse"] = _compute_weighted_std(
            self.stats.model_estimate, self.loss, self.std_err
        )
        stats["relative_error"] = _compute_relative_error(
            self.stats.model_estimate, self.loss, self.std_err
        )
        stats["span"] = _compute_pos_neg_span(
            self.fit, self.a_list, self.parameter_names
        )
        stats["relative_contribution"] = _compute_relative_contribution(
            self.fit, self.a_list, extra_cids
        )
        stats["allan_dev"] = _compute_allan(self.stats.model_estimate, self.loss)
        stats["rmse_over_allan"] = stats["rmse"] / stats["allan_dev"]
        for j, (vect, val, nm) in enumerate(
            zip(self.a_list, self.fit, self.parameter_names)
        ):
            if j < len(extra_cids):
                keyname = "CID%d" % j
            elif j == len(extra_cids):
                keyname = "offset"
            else:
                keyname = "rcid%s" % nm
            if keyname == "offset":
                stats[keyname] = val
            else:
                stats["conc_" + keyname] = val
                stats["ampl_" + keyname] = val * abs(vect.max())
        return stats

    def process_spectrum_default(self):
        """
        Execute fit on original model functions
        """
        self.execute_fit([], [])
        self.results[0] = self.get_fit_statistics([])

    def fit_combination(self, choice):
        """
        Execute fit on new test model function combinations
        """
        these_model_functions = [self.model_functions[cid] for cid in choice]
        these_names = [self.names[cid] for cid in choice]
        self.execute_fit(these_model_functions, these_names)

    def process_spectrum(self, N_add, cid_subset=set()):
        """
        Process spectrum after adding new candidates and update stats
        """
        if N_add == 0:
            return
        self.results[N_add] = {}
        all_cids = set(self.model_functions.keys())
        default_cids = set(self.required_cids)
        if cid_subset:
            fit_cids = (cid_subset | default_cids) - default_cids
        else:
            fit_cids = all_cids - default_cids
        NCID = len(fit_cids)
        num_calcs = factorial(NCID) // factorial(N_add) // factorial(NCID - N_add)
        INTERVAL = int(round(num_calcs / 10))
        if INTERVAL > 5000:
            INTERVAL = 5000
        count = 0
        for choice in itertools.combinations(fit_cids, N_add):
            if count % INTERVAL == INTERVAL - 1 and N_add > 1:
                LOGGER.debug(f"{(count / num_calcs * 100):.1f} % complete")
            self.fit_combination(choice)
            self.results[N_add][choice] = self.get_fit_statistics(choice)
            count += 1
        self.make_dataframes()

    def make_dataframes(self):
        """
        Make dataframes from results of recursive fit
        most likely based on wrmse
        """
        self.dfs = {}
        for num in self.results.keys():
            if num == 0:
                df = pd.DataFrame(self.results[num], index=[0])
            else:
                df = pd.DataFrame(_make_record(self.results[num], self.names))
                cols = []
                for col in df.columns:
                    if "CID_" == col[:4]:
                        cols.append(col)
                df.set_index(cols, inplace=True, drop=True)
                df.sort_values("wrmse", inplace=True)
            self.dfs[num] = df

    def find_likely_fit_candidates(
        self, max_comps=10, max_iterations=50, max_subset=40, fixed_list=[]
    ):
        """
        This function uses repeated substitution of single compounds into a multicompound fit,
        creating a subset of model functions to be used in a full combinatoric multicompound fit
        """
        current_list = []
        likelies = set()
        count = 0
        stats = collections.defaultdict(int)
        np.random.seed(1)  # ensures a deterministic result on multiple runs
        while len(likelies) < max_subset and count < max_iterations:
            full_list = current_list + fixed_list
            LOGGER.debug(f"fitting with {full_list}")
            self.set_required(full_list)
            self.process_spectrum(1)
            _, cid_list = self.retrieve_fit(1, 0)
            TOP = self.dfs[1].index[:3]
            for j, top in enumerate(TOP):
                likelies.add(top)
                stats[top] += 3 - j
            if len(current_list) >= max_comps + len(fixed_list):
                signals = {}
                for cid, conc, model_functions in zip(
                    cid_list + full_list, self.fit, self.a_list
                ):
                    if cid in current_list:
                        signals[cid] = np.abs(conc * model_functions.max())
                skeys = list(signals.keys())
                skeys.sort(key=lambda cid: signals[cid])
                _ = current_list.pop(current_list.index(skeys[0]))

            roll_dice = np.random.randint(6) + 1
            if roll_dice in [1, 2, 3]:
                add = [TOP[0]]
            elif roll_dice in [4, 5]:
                add = [TOP[0]]
            elif roll_dice in [6]:
                add = [TOP[1]]
            current_list = add + current_list
            count += 1
        stats_keys = list(stats.keys())
        stats_keys.sort(key=lambda s: stats[s], reverse=True)
        for key in stats_keys:
            LOGGER.debug(key, stats[key])
        return likelies, stats

    def retrieve_fit(self, num_fits, rank, sortby=FitStat.WRMSE):
        """
        Get fit information from stored dataframes
        """
        df = self.dfs[num_fits].sort_values(sortby.value)
        cid_list = df.index[rank]
        row_data = df.iloc[rank]
        if num_fits == 0:
            cid_list = []
        elif num_fits == 1:
            cid_list = [cid_list]
        self.fit_combination(cid_list)
        return row_data, cid_list


def perform_multicomponent_fit(
    nu: np.ndarray,
    loss: np.ndarray,
    std_err: np.ndarray,
    model_functions: Dict,
    N_add_list: List,
    required_cids: List = [],
):
    """
    Wrapper for recursive least squares fit
        Args:
        nu: array of measured nu
        loss: original loss
        std_err: passed in std_err
        model_functions: dictionary of name (cid usually) and model function
        N_add_list: List of number of compounds to add [1, 2, 3, 4]. for 1 to 4 additional compounds
        required_cids: list of required cids to be used in unknown search
    Returns:
        ProcessStepSpectrum object
        stats from refitting (rmse, allan, etc...)
    """
    fit = ProcessStepSpectrum(
        nu,
        loss,
        model_functions,
        required_cids,
        std_err=std_err,
        use_short_names=True,
    )
    likely_compounds, stats = fit.find_likely_fit_candidates(fixed_list=required_cids)
    fit.set_required(required_cids)
    for N_add in N_add_list:
        LOGGER.info(f"Fitting {N_add} compounds from the library")
        fit.process_spectrum(N_add, cid_subset=likely_compounds)
    return fit, stats


def _get_and_filter_model_functions(nominal_pressure, compounds_ignore):
    """
    Function to get model functions and remove ignored compounds
    """
    client = get_mongo_spectral_library_client()
    model_functions = get_model_functions(client, nominal_pressure=nominal_pressure)
    client.client.close()
    model_functions.update(_load_mimics())
    for ignore in compounds_ignore:
        if ignore in model_functions:
            model_functions.pop(ignore)

    return model_functions


def _create_return_data(
    fit_results: ProcessStepSpectrum,
    stats: Dict,
    corr_data: Dict,
    fit_data: Dict,
    spec_data: Dict,
    port: int,
    exp_name: str,
    iso_type: IsoType,
) -> Tuple[
    Dict[str, pd.DataFrame],
    Dict[int, Dict[str, pd.DataFrame]],
    Dict[int, Dict[str, Any]],
]:
    """
    Convenience function to assemble all the needed metadata from recursive fitter.
    This will be refactored with data models after validation of functionality
    """
    score = [val for val in stats.values()]
    subset_df = pd.DataFrame(score, index=stats.keys(), columns=["frequency"])
    subset_df.sort_values("frequency", inplace=True, ascending=False)

    data_key_corr = f"{exp_name}_P{port}_{iso_type.value}"
    corr_data[data_key_corr] = subset_df
    fit_data[port] = {}
    for num, fit_df in fit_results.dfs.items():
        data_key_fit = f"{exp_name}_P{port}_fit_{num}"
        fit_data[port].update({data_key_fit: fit_df})

    spec_data[port] = {
        "nu": fit_results.nu,
        "loss": fit_results.loss,
        "err": fit_results.std_err,
        "alist": fit_results.a_list,
        "pnames": fit_results.parameter_names,
        "fit_poly": fit_results.fit,
    }
    return (corr_data, fit_data, spec_data)


def fit_corr_isolated_spectra_to_unknowns(
    canaries,
    nominal_pressure,
    compounds_ignore,
    signals,
    ref_port,
    required_diffs,
    signal_strength_thresh,
    exp_name,
    num_compounds: List[int] = ic.NUM_COMPOUNDS_DIFF,
):
    """
    Perform the recursive refitting for the ICA isolated spectra.  Very similar
    to the diff refitting, with different method for gathering spectra.
    """
    model_functions = _get_and_filter_model_functions(
        nominal_pressure, compounds_ignore
    )

    # move to metadata
    meta_data, spectra = _unpack_cor_signals(signals, canaries)
    df_corr = pd.DataFrame(meta_data)
    keep = df_corr["port"] != ref_port
    df_corr = df_corr[keep]
    msk = df_corr["signal_strength"] > signal_strength_thresh
    if sum(msk) == 0:
        LOGGER.info(f"No Significant Unknown Signals detected in {exp_name}")

    df = copy.deepcopy(df_corr[msk])
    corr_data = {}
    fit_data = {}
    spec_data = {}
    for _, port_expt in df.iterrows():
        port = port_expt["port"]
        nu, loss, loss_err = spectra[port]
        sort_idx = np.argsort(nu)
        nu = nu[sort_idx]
        loss = loss[sort_idx]
        loss_err = loss_err[sort_idx]
        fit_results, stats = perform_multicomponent_fit(
            nu,
            loss,
            loss_err,
            model_functions,
            num_compounds,
            required_cids=required_diffs,
        )

        corr_data, fit_data, spec_data = _create_return_data(
            fit_results,
            stats,
            corr_data,
            fit_data,
            spec_data,
            port,
            exp_name,
            IsoType.CORRELATION,
        )

    return (corr_data, fit_data, spec_data)


def _unpack_cor_signals(corr_signal_data: Dict, canaries: List):
    """
    Get the appropraite payload from isolation zpickle.
    """
    meta_list = []
    spectra = {}
    for (ncomp, port, comp), pspec in corr_signal_data.items():
        meta_data = {}
        nu, spec, spec_err, time_series, avect, amask = pspec
        meta_data["port"] = port
        meta_data["ica_component_num"] = comp
        meta_data["max_ica_components"] = ncomp
        meta_data["ica_vector_mask"] = amask
        for canary, vect_value in zip(canaries, avect):
            meta_data[canary] = vect_value
        meta_data["signal_strength"] = time_series.std()
        meta_data["4th_order"] = (
            np.sum((time_series - time_series.mean()) ** 4)
        ) ** 0.25
        spectra[port] = (nu, spec, spec_err)
        meta_list.append(meta_data)
    return (meta_list, spectra)


def get_diff_spectrum(port: int, ref_port: int, signals):
    """
    The pulls the compacted spectra over a port and subtracts from ref port
    Args:
        port: port we are interested in getting diff spectrum on
        ref_port: port for reference
        isolation_gen: generator with isolation data to get port/compacted spectra
    Returns:
        wavenumbers vector
        partial_fit vector
        std_error of spectrum
    """
    spectrum = signals[port]
    ref_spectrum = signals[ref_port]
    diff_spec = spectrum.subtract_binned_spectra(ref_spectrum)
    sort_idx = np.argsort(diff_spec.nu_prime)
    nu = diff_spec.nu_prime[sort_idx]
    partial_fit = diff_spec.partial_fit[sort_idx]
    std_err = diff_spec.partial_fit_std_err[sort_idx]

    return (nu, partial_fit, std_err)


def fit_diff_isolated_spectra_to_unknowns(
    nominal_pressure: float,
    compounds_ignore: List[int],
    signals,
    ref_port: int,
    required_diffs: List[int],
    exp_name: str,
    num_compounds: List[int] = ic.NUM_COMPOUNDS_DIFF,
):
    """
    Runs the iterative fitter on difference isolated spectra.  This can
    take about 8 minutes for 4 extra compounds.  This should only
    be run as a separate process and hopefully soon in a parallel fashion

    Args:
        nominal_pressure: expected pressure to run (140 Torr)
        compounds_ignore: compounds to ignore when looking for unknowns
        isolation_gen: Generator object with
        ref_port: integer ref port
        required_diffs: List of cids to always use when refitting
        exp_name: Name of sub experiment being analyzed
    """
    model_functions = _get_and_filter_model_functions(
        nominal_pressure, compounds_ignore
    )

    spectra = {}
    for (port, spectrum) in signals.items():
        spectra[port] = spectrum

    fit_data = {}
    diff_data = {}
    spec_data = {}
    # Iterate through all ports and averaged spectra
    for port, spectrum in spectra.items():
        if port in [ref_port, 62]:
            continue
        # Subtract ref spectrum, get needed properties for fit
        diff_spec = spectrum.subtract_binned_spectra(spectra[ref_port])
        sort_idx = np.argsort(diff_spec.nu_prime)
        nu = diff_spec.nu_prime[sort_idx]
        loss = diff_spec.partial_fit[sort_idx]
        loss_err = diff_spec.partial_fit_std_err[sort_idx]

        # replace any 0s with median value, not the best
        median_std_err = np.median(loss_err)
        loss_err[np.where(loss_err == 0)] = median_std_err
        fit_results, stats = perform_multicomponent_fit(
            nu,
            loss,
            loss_err,
            model_functions,
            num_compounds,
            required_cids=required_diffs,
        )
        score = [val for val in stats.values()]
        subset_df = pd.DataFrame(score, index=stats.keys(), columns=["frequency"])
        subset_df.sort_values("frequency", inplace=True, ascending=False)

        diff_data, fit_data, spec_data = _create_return_data(
            fit_results,
            stats,
            diff_data,
            fit_data,
            spec_data,
            port,
            exp_name,
            IsoType.DIFFERENCE,
        )

    return (diff_data, fit_data, spec_data)
