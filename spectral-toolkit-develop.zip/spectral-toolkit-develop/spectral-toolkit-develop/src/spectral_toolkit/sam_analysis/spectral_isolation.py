import numpy as np
import pandas as pd
import copy
from scipy.interpolate import interp1d
from typing import List, Dict
from datetime import timedelta
from sklearn.decomposition import FastICA
from spectral_arithmetic.linear_least_squares import least_squares
from spectral_arithmetic.data_models.spectra import BinnedSpectra
from spectral_toolkit.logger import get_logger
from spectral_toolkit.data_models.filters import Filter, FilterType


LOGGER = get_logger(__name__)


def _filter_mask(filters: List[Filter], df_grouped: pd.DataFrame, mask=True):
    """
    Apply filters on the grouped/average dataframe.  This throws out entire groups
    """
    for filter in filters:
        filter_data = df_grouped[filter.column].reset_index(drop=True)
        if filter.filter_type.value == FilterType.include.value:
            cur_mask = (filter_data >= filter.low) & (filter_data <= filter.high)
        elif filter.filter_type.value == FilterType.exclude.value:
            cur_mask = (filter_data <= filter.low) | (filter_data >= filter.high)

        mask = np.logical_and(cur_mask, mask)

    return mask



def _get_clean_spectra(mask, spectra: BinnedSpectra) -> List[BinnedSpectra]:
    """
    Iterate through a mask dataframe to keep spectra passing mask criteria
    Args:
        mask: pd.DataFrame with index and column of bools (mask)
        spectra: 
    Returns:
        Tuple of Dataframe with filter parameter columns and masks and list of BinnedSpectra
    """
    selected_spectra = []
    for j, keep in enumerate(mask):
        if keep:
            jspec = spectra[j]
            selected_spectra.append(jspec)

    return selected_spectra


def _unionize(spectra: List[BinnedSpectra]) -> BinnedSpectra:
    """
    Convenience to get the union of all the binned spectra
    Args:
        List of BinnedSpectra to perform union on
    Returns:
        BinnedSpectra after unions
    """
    agg = spectra[0]
    for i in range(1, len(spectra)):
        agg = agg.intersect_binned_spectra(spectra[i])
    return agg


def _assemble_spectrum(
    mask: pd.Series,
    spectra: List[BinnedSpectra],
):
    """
    This applies a mask and union of spectra based on json config filters
    """
    agg_spec = None
    for j, keep in enumerate(mask):
        if keep:
            jspec = spectra[j]
            if agg_spec is None:
                agg_spec = jspec
            else:
                agg_spec = agg_spec.intersect_binned_spectra(jspec)

    return agg_spec


def _create_2D_array(selected_spectra: List[BinnedSpectra], mode_list: List[int]):
    """
    Creates a convenient 2D array of spectral information from all compact spectra
    """
    specarray = np.zeros((len(selected_spectra), len(mode_list)))
    errarray = np.zeros(specarray.shape)
    resarray = np.zeros(specarray.shape)
    for i, spec in enumerate(selected_spectra):
        spec = spec.intersecting_spectrum(mode_list)
        specarray[i, :] = spec.partial_fit
        errarray[i, :] = spec.partial_fit_std_err
        resarray[i, :] = spec.residuals
    return (specarray, errarray, resarray)


def scale_by_noise(dfg_corr: pd.DataFrame, canaries: List[str], instrument):
    """
    Scale figure of merit based on voc LOD characteristic for analyzer
    """
    fom = copy.deepcopy(dfg_corr)
    LOD = instrument["LOD"]
    meta = instrument["meta_data"]
    duration = dfg_corr["duration"]
    for canary in canaries:
        try:
            fom[canary] /= LOD[canary] * np.sqrt(meta["ave_time"] / duration)
        except Exception as e:
            LOGGER.warning(
                f"Unable to get LOD information for {canary}, please add to JSON config: {e}"
            )
    return fom


def zero_reference_data(
    dfg: pd.DataFrame,
    canaries: List[str],
    t_range: int,
    ref_port: int,
    valve_key="ValveMask",
):
    """
    This corrects for reference port data.  To be replaced by Andrea's solution
    """
    dfg_corr = copy.deepcopy(dfg)
    V = dfg[valve_key]
    ref_data = V == ref_port
    T_ref = dfg["_datetime"][ref_data]
    for canary in canaries:
        Y_ref_raw = dfg[canary][ref_data].to_numpy()
        Y_ref = np.zeros(T_ref.shape)
        for j in range(len(T_ref)):
            t_j = T_ref.iloc[j]
            these = (T_ref >= t_j - timedelta(seconds=t_range)) & (
                T_ref < t_j + timedelta(seconds=t_range)
            )
            these = abs((T_ref - t_j).dt.total_seconds()) <= t_range
            if sum(these) == 0:
                these = T_ref == t_j

            Y_ref[j] = Y_ref_raw[these].mean()
        T0 = T_ref.iloc[0]
        spl = interp1d((T_ref - T0).dt.total_seconds(), Y_ref, fill_value="extrapolate")
        dfg_corr[canary] -= spl((dfg["_datetime"] - T0).dt.total_seconds())
    return dfg_corr


def correlation_fit(data, err, time_vect):
    """
    Run least squares to get the slope and error for each port spectra.
    Args:
        data: 2D array of time series partial fit data
        err: 2D array of stderr partial fit data
        time_vect: signal to optimize on
    Returns:
        slope terms of least squares fit
        slope std error of least squares fit
    """
    M, N = data.shape
    ones = np.ones(M)
    slope_err = np.zeros(N)
    slope = np.zeros(N)
    for J in range(N):
        Y = data[:, J]
        E = err[:, J]
        e = np.median(E)
        poly_fit, stats = least_squares(np.vstack((ones, time_vect)).T, Y, ones * e)
        slope[J] = poly_fit[1]
        slope_err[J] = stats.std_dev[1]
    return slope, slope_err


def difference_spectral_isolation(
    df_grouped: pd.DataFrame,
    spectra: List[BinnedSpectra],
    port_names: Dict[str, str],
    filters: List[Filter] = [],
    valve_key: str = "ValveMask",
) -> Dict[int, BinnedSpectra]:
    """
    This performs a basic isolation of compact spectra on a port basis
    df_grouped: This is the dataframe with the _group column defined, used for masking based on time series data
    spectra: list of all the binned spectra associated with a given port
    canaries: VOC columns to reference
    """
    spectrum_by_port = {}
    for port in port_names.keys():
        LOGGER.info(f"Assembling compactified spectrum for port {port}")
        valve_col = df_grouped[valve_key].reset_index(drop=True)
        mask = pd.Series(True, index=range(len(valve_col.index)))
        mask &= valve_col == int(port)

        if filters:
            # now filter through based on json def
            mask = _filter_mask(filters, df_grouped, mask)

        spectrum_by_port[int(port)] = _assemble_spectrum(mask, spectra)

    return spectrum_by_port


def ica_spectral_isolation(
    df_grouped: pd.DataFrame,
    spectra: List[BinnedSpectra],
    instrument_model: Dict,
    canaries: List[str],
    ref_port: int,
    port_names: Dict,
    ica_isolation: Dict,
    zero_reference_time_window: int,
    valve_key: str = "ValveMask",
):
    """
    This will run through the entire ICA isolation
    Args:
        exp_data_model: report model parsed from exp definition json
        exp_name: sub experiment (plan) name
        compact_gen: compactified data generator
    Returns:
        fom: figure of merrit from canaries
        fom_workhorse: figure of merit from workhorses
        ghost_df: dataframe after substracting zero reference baseline
        signals: dictionary of separated out unknonwn spectrum
    """
    apply_zero_reference = len(set(port_names.keys())) > 1
    lod_info = instrument_model["LOD"]

    # TODO: fix data model in spectral toolkit
    if not instrument_model:
        raise ValueError("There is no valid Instrument information in config file")

    if not lod_info:
        raise ValueError(
            f"There is no LOD information in Config file for {instrument_model}"
        )

    # Just use the overlap
    canaries = list(set(df_grouped.columns) & set(canaries) & set(lod_info.keys()))
    if not canaries:
        raise ValueError(
            f"There is no overlap between specified canaries {canaries} and LOD information {instrument_model.LOD.keys()}"
        )

    if apply_zero_reference:
        df_grouped = df_grouped.reset_index()
        df_grouped = zero_reference_data(df_grouped, canaries, zero_reference_time_window, ref_port)

    # Figure of merit
    fom = scale_by_noise(df_grouped, canaries, instrument_model)

    # group mask
    if ica_isolation["filters"]:
        filters = [Filter.model_validate(item) for item in ica_isolation["filters"]]
        mask = _filter_mask(filters, df_grouped)
    else:
        mask = pd.Series(True, index=range(len(df_grouped.index)))
    clean_spectra = _get_clean_spectra(mask, spectra)
    fom_mask = fom[mask]
    port_mask = fom_mask[valve_key]
    canary_df = copy.deepcopy(fom_mask[canaries])
    canary_arr = canary_df.to_numpy()
    ica_signals = {}  # TODO: model this data
    for n_components in range(1, ica_isolation["ica_components"] + 1):
        for port in port_names.keys():
            ica = FastICA(n_components=n_components)
            cur_mask = port_mask == int(port)

            # Fit the model
            S_recon = ica.fit_transform(canary_df[cur_mask])
            A_mix = ica.mixing_
            I_clean = np.arange(len(clean_spectra))
            port_spectra = [clean_spectra[i] for i in I_clean[cur_mask]]

            if not port_spectra:
                continue
            LOGGER.info(f"Processing ICA Isolation on Port {port}")

            aggregate_spectra = _unionize(port_spectra)
            for n in range(n_components):
                st = S_recon[:, n]
                # check if negative, flip
                if st.mean() < 0:
                    S_recon[:, n] = -S_recon[:, n]
                    A_mix[:, n] = -A_mix[:, n]

                A_mask = np.abs(A_mix[:, n]) > ica_isolation[
                    "keep_top_canaries_frac"
                ] * (abs(A_mix[:, n]).max())
                a_size = np.sqrt(np.sum(A_mix[:, n] ** 2))

                # derive the time series from the canary data directly, not the time series
                # reconstructed from ICA
                time_vect = 0
                for j, keep in enumerate(A_mask):
                    if keep:
                        time_vect += canary_arr[:, j] * A_mix[j, n] / a_size
                time_vect = time_vect[cur_mask]

                partfit, err, _ = _create_2D_array(
                    port_spectra, list(aggregate_spectra.binned_data.keys())
                )
                slope_fit, slope_fit_err = correlation_fit(partfit, err, time_vect)
                ica_signals[(n_components, int(port), n)] = (
                    aggregate_spectra.nu_prime,
                    slope_fit,
                    slope_fit_err,
                    time_vect,
                    A_mix[:, n] / a_size,
                    A_mask,
                )

    return ica_signals
