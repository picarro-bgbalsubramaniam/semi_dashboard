import copy
import numpy as np
import pandas as pd
import collections
from typing import Dict, List
from scipy.stats import norm
from spectral_toolkit.logger import get_logger
from spectral_toolkit.constants import identification_constants as ic


LOGGER = get_logger(__name__)
# Default thresh, expose in config json
THRESH = norm.cdf(ic.CONFIDENCE_K)
# TODO: This needs many data models


def make_unknown_results_stats(dfs: pd.DataFrame, num_compounds: int, original_rmse, wrmse_range=0.02):
    """
    This takes the results from the unknown refitting and sorts them based
    on the most freqeuntly seen to give top results
    Args:
        dfs: dataframe with all compound hunting stats
        num_compounds: number of compounds used for hunting
    Returns:
        dictionary with pertinent stats for given num compounds hunting results
    """
    dfs = dfs.reset_index()
    columns = copy.deepcopy(ic.STATS_COLS)
    columns += [f"ampl_CID{i}" for i in range(num_compounds)]
    cur_cid_columns = [f"CID_{i}" for i in range(num_compounds)]
    columns += cur_cid_columns
    cur_stats = copy.deepcopy(dfs[columns])
    cur_stats["rel_wrmse"] = cur_stats["wrmse"] / float(original_rmse)
    cur_stats.sort_values("rel_wrmse", ascending=True, inplace=True)
    msk = cur_stats["rel_wrmse"] <= cur_stats["rel_wrmse"].iloc[0] * (1 + wrmse_range)
    dfk = copy.deepcopy(cur_stats[msk])

    uniques = np.unique(dfk[cur_cid_columns].values)

    dfk_statlist = []
    for cid in uniques:
        amplitudes = np.array([])
        fmask = False
        for i in range(num_compounds):
            imask = dfk[f"CID_{i}"] == cid
            fmask |= imask
            z = dfk[f"ampl_CID{i}"][imask].to_numpy()
            amplitudes = np.append(amplitudes, z)

        if len(amplitudes) == 0:
            continue
        summary_stats = {}
        summary_stats["cid"] = cid
        summary_stats["mean"] = amplitudes.mean()
        summary_stats["std"] = amplitudes.std()
        summary_stats["num"] = len(amplitudes)
        summary_stats["fraction"] = len(amplitudes) / len(imask)
        summary_stats["rel_wrmse"] = dfk["rel_wrmse"][fmask].mean()
        for kcol in ic.STATS_COLS:
            if kcol != "new_comps":
                summary_stats[kcol] = dfk[fmask][kcol].mean()
        dfk_statlist.append(summary_stats)

    dfk_stats = pd.DataFrame(dfk_statlist)
    dfk_stats.sort_values("num", inplace=True, ascending=False)

    return dfk_stats


def filter_and_summarize(stats_df: pd.DataFrame, port: int, exp_name: str) -> List:
    """
    After calculating statistics we think should be useful, run
    through and pull out the likely unknowns based on below determinations
    Args:
        stats_df: The stats df from making_unknown_results_stats
        port: current port we're summarizing
        exp_name: experiment we're summarizing
    Returns:
        List of dictionaries.  Each dictionary contains the information of the row stats
        for compounds found to be possible unknowns
    """
    events = []
    columns = stats_df.columns
    for row in stats_df.itertuples():
        # Parameters from stats for checking if unknown found
        compound_detected = row.fraction >= THRESH
        fitable_residual = _compute_residual_confidence(row.rel_wrmse) >= THRESH
        significant_amplitude = (
            _compute_contribution_confidence(row.mean, row.span) >= THRESH
        )
        clean_sample = _compute_clean_sample_confidence(row.wrmse, row.span) >= THRESH

        # Now check the combinations for likely scenarios from refitting
        clean_detect = all(
            [compound_detected, fitable_residual, significant_amplitude, clean_sample]
        )
        should_have_but_didnt = fitable_residual and not compound_detected
        record = _create_record(columns, port, row, exp_name)
        if compound_detected:
            if clean_detect:
                record["type"] = "clean"
            else:
                record["type"] = "questionable"
            events.append(record)
            continue
        elif should_have_but_didnt:
            record["type"] = "shoulda"
            events.append(record)
            break

    return events


def _create_record(columns, port, row, exp_name):
    """
    Adds all the metadata for the final report presentation
    """
    record = {}
    record["expt_name"] = exp_name
    record["port"] = port
    for col in columns:
        if col == "cid":
            record[col] = int(getattr(row, col))
        else:
            record[col] = getattr(row, col)
    record["fitable_residual"] = _compute_residual_confidence(row.rel_wrmse)
    record["significant_signal"] = _compute_contribution_confidence(row.mean, row.span)
    record["clean_gas_mixture"] = _compute_clean_sample_confidence(row.wrmse, row.span)
    return record


def create_full_summary(events_df: pd.DataFrame):
    """
    This takes the output from the filter_and_summarize to create a list
    of the unknowns found and puts them into confidence bins
    """
    compound_lists = {}
    for _, dframe in events_df.groupby('expt_name'):
        cids_found = set(events_df['cid'])
        compounds = collections.defaultdict(list)
        for fcid in cids_found:
            msk = events_df['cid'] == fcid
            prob_not_present = np.prod(events_df[msk]['fraction']-1)
            prob_present = 1 - prob_not_present
            if 0.5 <= prob_present < 0.85:
                compounds['maybe'].append(fcid)
            elif 0.85 <= prob_present <= 0.95:
                compounds['likely'].append(fcid)
            elif 0.95 <= prob_present <= 1:
                compounds['certain'].append(fcid)
            else:
                compounds['seen'].append(fcid)
        compound_lists[dframe['expt_name'].iloc[0]] = compounds

    return compound_lists


def _compute_residual_confidence(rel_wrmse, npoints=300):
    y = 1 - rel_wrmse
    # scale by the number of points contributing to the RMSE
    # TODO: How do we get n points to this part of analysis?
    return norm.cdf(y * np.sqrt(npoints))


def _compute_contribution_confidence(mean, span, large_ratio=2e3):
    sr = mean / span
    return norm.cdf(sr * large_ratio)


def _compute_clean_sample_confidence(wrmse, span, large_signal=1e3):
    nr = wrmse / span
    return norm.cdf(nr * large_signal)
