from pandas import DataFrame
from spectral_toolkit.data_models.sam_models import Plan
from typing import Union, List
from pandas import DataFrame
import numpy as np
import pandas as pd


MAX_TRANSITION = 30


def _look_for_cycles(
    seq: Union[List, DataFrame],
    duration: List[float],
    max_cycle_len: int = 64,
    max_transition: int = MAX_TRANSITION,
) -> np.ndarray:
    """
    Function encodes repeating patterns for cycle lengths from 2 to max_cycle_len

    args:
      seq: sequence of valve session integers, where each integer represents a
           unique valve state and duration
      duration: list of duration of each valve state, used in comparing cycles
      max_cycle_len: maximum length of repeating cycle to search for
      max_transition: There is some slop in valve transition on duration,
                      keep everything under 30 s difference


    returns:
     2D numpy array encoded where
      each row represents the number of entries in the sequence
      each column represents the length of the test cycle
      the entry [i,j] equals:
         1: only seq[i] = seq[i+j]
         2: only seq[i] = seq[i-j]
         3: both of #1 and #2 are true
         0: neither #1 nor #2 are true
    """
    check = np.zeros((len(seq), max_cycle_len + 1), dtype=int)
    for current_length in range(2, max_cycle_len + 1, 1):
        for s in range(len(seq) - current_length):
            e = s + current_length
            if seq[s] == seq[e] and abs(duration[s] - duration[e]) < max_transition:
                # next state in cycle is the same
                check[s, current_length] += 1
                # previous state in cycle is the same
                check[e, current_length] += 2
    return check


def _add_score(dframe: pd.core.groupby.GroupBy, length) -> pd.core.groupby.GroupBy:
    """
    Score the pattern based on length and assign to column in dataframe
    Arguments:
        dframe: Gropuby Object to evaluate for patterns and assign score to
        length: Current length we're checking the score for
    Returns:
        pd.core.groupby.Groupby object with assigned score column
    """
    num_steps = len(dframe.index)
    code = dframe["series_code"]
    is_long_enough = num_steps >= length
    is_continuous = sum(code == 0) == 0
    starts_correctly = code.iloc[0] == 1
    ends_correctly = code.iloc[-1] == 2
    if is_long_enough and is_continuous and starts_correctly and ends_correctly:
        score = num_steps
    else:
        score = 0
    dframe["score"] = score * np.ones(num_steps, dtype=int)
    return dframe


def _rank_cycles(check: np.ndarray) -> DataFrame:
    """
    Takes the output of look_for_cycles and finds all the repeating patterns
    args:
     check: 2D numpy array with scores assigned
    returns:
     dataframe that scores each cycle length for repeating patterns, where the score is the
       length of the block of repeating elements
    """
    n, m = check.shape
    score_matrix = np.zeros((n, m))
    for current_length in range(2, m, 1):
        series_code = pd.Series(check[:, current_length])

        # create two series to indicate whether a given row is part of a leading or trailing sequence
        with_next = series_code & 1
        with_prev = series_code & 2
        # create an accumulator that jumps whenever either
        # a new sequence starts (with_next) or an old sequence ends (with_prev)
        start = ((with_next - with_next.shift(1)) == 1).cumsum()
        end = ((with_prev - with_prev.shift(1)) == -2).cumsum()
        jump = start + end

        df = pd.DataFrame(data={"series_code": series_code, "group": jump})
        dfg = df.groupby("group", group_keys=False).apply((lambda x: _add_score(x, current_length)))

        score_matrix[:, current_length] = dfg["score"].to_numpy()
    return pd.DataFrame(score_matrix)


def _find_sequences(df_score, seq):
    """
    takes the maximum cycle block length.  Where multiple cycle lengths have the same score, the
      shortes cycle is used
          e.g. a cycle of two valve states, repeating 10 times, will have
           - a score of 20 for cycle = 2, and
           - a score of 20 for cycle = 4
    """
    current_index = 0
    sequences = []
    while current_index < len(seq) - 1:
        row = df_score.iloc[current_index]
        # best cycle length
        cycle = int(row.to_numpy().argmax())
        if cycle >= 2:
            cycle_length = int(row[cycle])
            if cycle_length // cycle > 1:
                sequences.append(
                    (
                        seq[current_index : current_index + cycle],
                        cycle_length // cycle,
                        current_index,
                        current_index + cycle_length,
                    )
                )
            current_index += cycle_length
        else:
            current_index += 1
    return sequences


def detect_pattern(
    seq: DataFrame,
    max_cycle_len: int = 64,
    valve_key: str = "ValveMask",
    min_duration: int = 3600,
    max_transition: int = MAX_TRANSITION,
) -> List[Plan]:
    """
    args:
      seq: sequence of valve session integers, where each integer represents a unique valve state and duration
      max_cycle_len: maximum length of repeating cycle to search for

    returns list of Tuples, where each tuple is
        the repeating sequence unit cell
        the number of repeats
        the first row of the sequence
        the last row of the sequence

    """
    valves = seq[valve_key].tolist()
    durations = seq["time_delta"].tolist()
    cycle_check = _look_for_cycles(
        valves, durations, max_cycle_len=max_cycle_len, max_transition=max_transition
    )
    df_score = _rank_cycles(cycle_check)
    sequences = _find_sequences(df_score, seq)
    plans = []
    for s in sequences:
        plan = Plan(
            pattern=s[0][valve_key].tolist(),
            start_time=seq.index[s[2]],
            stop_time=seq["stop_time"][s[3] - 1],
            repeated=s[1],
            times=s[0]["time_delta"].tolist(),
        )
        if (plan.stop_time - plan.start_time).total_seconds() > min_duration:
            # Only add plan if it was long enough
            plans.append(plan)

    return plans
