import pandas as pd
import copy
import numpy as np
from typing import List, Dict, Any, Optional
from pathlib import Path
from datetime import datetime, timedelta
from spectral_toolkit.constants.compactify_constants import BIG3, FREQ
from spectral_toolkit.df_operations.sam_df import group_by_port, group_by_port_combined_logs
from spectral_arithmetic import spectrum_operations as so
from data_pooler.data_access_utils import get_file_paths_in_timerange
from data_pooler.persist import get_combolog_from_zpickle
from data_pooler.pool_utils import get_data_frame
from spectral_arithmetic.aggregate_operations import (
    transform_spectra,
    bin_spectral_data,
    filter_spectral_data,
)
from spectral_arithmetic.nu_operations import nu_operations as no
from spectral_arithmetic.data_models.spectra import BinnedSpectra
from spectral_toolkit.logger import get_logger
import pytz
from warnings import warn


LOGGER = get_logger(__name__)
DEFAULT_NU_CENTER = 6056.5

# NEWEST VERSION



def compact_data(
    grouped_df: pd.DataFrame,
    big3_correction: Dict[str, np.ndarray] = {},
    min_spectra_count: int = 25,
    f0_thresh: float = 3e-3,
    fsr_thresh: float = 3e-5,
    group_by_key: str = "_group",
    apply_transform: bool = True,
):
    """
    Given a dataframe produce by data_pooler.api.combined_logs.get_timeseries_with_combo_info,
    produce the compact dataframe and compact spectra.

    Args:
        grouped_df:  A data frame with some group_by key and spec_gen_file, spec_gen_id keys
        big3_correction: dictionary with big 3 correction vectors
        min_spectra_count: minimum spectra needed to produce compact results
        f0_thresh: do not include spectra with f0 shift from mean larger than this
        fsr_thresh: do not include spectra with fsr deviation greater than this
        apply_transform: specify whether to perform nu trasnform when compactifying
    Yields:
        tuple(group, spectrum, compact data row)
    """
    # Get first generator
    cur_file = grouped_df["spec_gen_file"][0]
    combo_gen = get_combolog_from_zpickle(open(cur_file, "r"))
    _ = next(combo_gen)
    for _group, valve_df in grouped_df.groupby(group_by_key):
        spectra = []
        # Generate the compact data row
        compact_df_row = valve_df._get_numeric_data().mean().to_frame().transpose()
        compact_df_row["_datetime"] = valve_df.index.mean()
        compact_df_row["duration"] = (valve_df.index[-1] - valve_df.index[0]).total_seconds()

        for var_name in ['port','ValveMask','MPVPosition']:
            if var_name in compact_df_row:
                compact_df_row[var_name] = int(round(compact_df_row[var_name]))

        for row in valve_df.itertuples():
            # Check if accessing a new file
            if row.spec_gen_file != cur_file:
                cur_file = row.spec_gen_file
                combo_gen = get_combolog_from_zpickle(open(cur_file, "r"))
                _ = next(combo_gen)

            spec = combo_gen.send(int(row.spec_gen_id))

            # Perform big 3 correction if defined
            if big3_correction:
                big_three_correction(row, spec, _group, big3_correction)

            # Convert to dict of numpy arrays
            spec_arr = dict(zip(spec.columns.values, spec.values.T))

            # Update with needed transform data
            extra_info = _combo_data_for_transform(row)
            spec_arr.update(extra_info)
            spectra.append(spec_arr)

        num_spectra = len(spectra)
        if not num_spectra >= min_spectra_count:
            LOGGER.info(
                f"Did not produce compact spectrum for group {_group} with {num_spectra} spectra"
            )
        else:
            binned_spectrum = _compactify_spectra(
                spectra, f0_thresh, fsr_thresh, apply_transform
            )
            yield (_group, binned_spectrum, compact_df_row)


def big_three_correction(
    row, spec_df, group, big3_correction: Dict[str, np.ndarray] = {}
):
    """
    Apply the big three correction
    """
    data_msk, corr_msk, good_result = so.get_common_mask_correction(
        spec_df["nu"],
        big3_correction["nu"],
        max_diff=0.004,
        verbose=False,
    )

    if not good_result:
        # Do we want to throw out reults?
        LOGGER.warning(f"Big Three data mask had a bad result for group {group}")

    # get correction concentrations
    H2O, CO2, CH4 = (row[compound] for compound in BIG3)

    # get error from correction
    big3_error = so.big3_correction(big3_correction, CO2, CH4, H2O)

    # mask data
    spec = copy.deepcopy(spec_df[data_msk])

    # correct partial fit data
    spec["partial_fit"] -= big3_error[corr_msk]

    return spec


def _combo_data_for_transform(results_row):
    """
    Takes the results time series data from a combo log row
    and retrieves the data needed to perform spectra arithmetic
    Args:
        results_row: Time series data row
    Returns:
        dictionary with the extra metadata needed to compact spectrum

    """
    if hasattr(results_row, "fitData_nu_transform_nnuc"):
        nu_center = results_row.fitData_nu_transform_nnuc
    elif hasattr(results_row, "fitData_fitdata_params_nucenter"):
        nu_center = results_row.fitData_fitdata_params_nucenter
    else:
        nu_center = DEFAULT_NU_CENTER
        LOGGER.warning(
            f"Combo logs did not contain Nu Center, default to {DEFAULT_NU_CENTER}"
        )

    extra_info = dict(
        nu_shift=results_row.fitData_nu_transform_n0,
        nu_squish=results_row.fitData_nu_transform_n1,
        nu_center=nu_center,
        f0=results_row.f0,
        f0_shift=results_row.f0_shift,
    )
    return extra_info


def _compactify_spectra(
    spectra: List[Dict],
    f0_thresh: float = 3e-3,
    fsr_thresh: float = 3e-5,
    apply_transform: bool = True,
) -> BinnedSpectra:
    """
    Convenience function to create a BinnedSpectrum from a list of spectra in Dict form.
    Args:
        spectra: list of spectral dictionaries (nu, big3, partial_fit, etc...)
        f0_thresh: do not include spectra with f0 shift from mean larger than this
        fsr_thresh: do not include spectra with fsr deviation greater than this
        apply_transfrom: Peform nu transfrom based on squish/shift/etc.. from logs
    Returns:
        Binned spectra object
    """

    transform_spectrum = transform_spectra(spectra, apply_transform)
    filtered_spectrum = filter_spectral_data(
        transform_spectrum, f0_thresh=f0_thresh, fsr_thresh=fsr_thresh
    )
    binned_spectrum = bin_spectral_data(filtered_spectrum)
    return binned_spectrum


# OLD VERSION BELOW  Leaving here until people don't need it


def pull_combo_results(
    base_path: Path,
    start_time: datetime,
    end_time: datetime,
    time_zone: str,
    cols: List = BIG3 + FREQ,
):
    """Pull just the results section of multiple pickle files in the pool, given a set of columns (cols)
    Args:
        base_path: path to pool/source
        start_time: pull data after this datetime object
        end_time: pull data before this datetime object
        cols: columns to pull
    Returns:
        pd.DataFrame with two new columns, file_path and zpickle_ordinal
    """
    warn(
        "Method pull_combo_results is deprecated and will be removed in a future relase.",
        DeprecationWarning,
        stacklevel=2,
    )
    tz = pytz.timezone(time_zone)
    start_local = tz.localize(start_time)
    stop_local = tz.localize(end_time)
    combo_files = get_file_paths_in_timerange(
        start_local, stop_local, base_path, ["ComboLog", "broadband"]
    )
    df_results = None
    for combo_fn in combo_files:
        LOGGER.debug(f"opening file {combo_fn.name}")
        with open(combo_fn, "rb") as pp:
            combo_gen = get_combolog_from_zpickle(pp, get_history=False, get_extra=True)
            # drop meta
            _ = next(combo_gen)
            # get the time series
            time_series_data = next(combo_gen)
        # drop the columns not in our list
        droppers = set(time_series_data.columns) - set(cols)
        time_series_data = time_series_data.reindex(
            time_series_data.index.tz_convert(time_zone)
        )
        time_series_data.drop(droppers, axis=1, inplace=True)
        # Add file path and location of spectrum blob
        time_series_data["file_path"] = combo_fn
        time_series_data["zpickle_ordinal"] = np.arange(len(time_series_data.index))
        if df_results is None:
            df_results = time_series_data
        else:
            df_results = pd.concat((df_results, time_series_data))
    return df_results


def _extra_data_for_spectral_arithmetic(results_row: pd.Series) -> Dict:
    """
    Takes the results time series data from a combo log row
    and retrieves the data needed to perform spectra arithmetic
    Args:
        results_row: Time series data row
    Returns:
        dictionary with the extra metadata needed to compact spectrum

    """
    nu_shift = results_row["fitData_nu_transform_n0"]
    nu_squish = results_row["fitData_nu_transform_n1"]
    nu_center = results_row.get("fitData_nu_transform_nnuc")
    if not nu_center:
        nu_center = results_row.get("fitData_fitdata_params_nucenter")
        if not nu_center:
            # We're missing this somehow name changing nu center data?
            return {}
    f0 = results_row["f0"]
    f0_shift = results_row["f0_shift"]

    extra_info = dict(
        nu_shift=nu_shift,
        nu_squish=nu_squish,
        nu_center=nu_center,
        f0=f0,
        f0_shift=f0_shift,
    )
    return extra_info


def dataframe_to_dict_of_numpy_arrays(df):
    """
    Function needed to format spectral data column as np.array.
    Args:
        df: dataframe of spectral data
    Returns:
        dictionary of spectral data with column as key and np.array for value
    """
    out = {}
    for col in df.columns:
        out[col] = df[col].to_numpy()
    return out


def generate_spectrum_groups(
    df_private: pd.DataFrame,
    df_combo_results: pd.DataFrame,
    big3_correction: Dict[str, np.ndarray] = {},
    min_spectra_count: int = 25,
    f0_thresh: float = 3e-3,
    fsr_thresh: float = 3e-5,
) -> List[Dict]:
    """
    Args:
        df_private: DataFrame grouped by valve state with transitions removed
        df_combo_results: single data frame with combo log results including Big3 Concentrations and
                          pickle file path and pickle spectrum ordinal
        big3_correction: dictionary with vectors of offset and linear/bilinear terms
        min_spectra_count: minimum spectra to include to group/compactify
        f0_thresh: do not include spectra with f0 shift from mean larger than this
        fsr_thresh: do not include spectra with fsr deviation greater than this
    Yields:
        dataframe with grouped data
        Binned spectra data
    """
    warn(
        "Method generate_spectrum_groups is deprecated and will be removed in a future relase.",
        DeprecationWarning,
        stacklevel=2,
    )
    # iteration through valve sessions
    good_count = 0
    bad_count = 0
    for _group, valve_df in df_private.groupby("_group"):
        # find combo results corresponding to the session time period
        msk = (df_combo_results.index >= valve_df.index[0]) & (
            df_combo_results.index <= valve_df.index[-1]
        )
        combo_session_df = df_combo_results[msk]
        spectra = []
        # iteration through rows in combo results
        for file, pick_frame in combo_session_df.groupby("file_path"):
            # open combo file
            with open(file, "rb") as pp:
                # instantiate generator
                combo_gen = get_combolog_from_zpickle(
                    pp, get_history=False, get_extra=False
                )
                _ = next(combo_gen)
                for _, row in pick_frame.iterrows():
                    # get spectrum
                    spec = combo_gen.send(row["zpickle_ordinal"])

                    if big3_correction:
                        # find common mask for data and correction
                        data_msk, corr_msk, good_result = so.get_common_mask_correction(
                            spec["nu"],
                            big3_correction["nu"],
                            max_diff=0.004,
                            verbose=False,
                        )

                        if not good_result:
                            bad_count += 1
                            LOGGER.debug(
                                f"_group {_group}: Bad Data masking ({bad_count}:{good_count})"
                            )
                            continue
                        else:
                            good_count += 1

                        # get correction concentrations
                        H2O, CO2, CH4 = (row[compound] for compound in BIG3)

                        # get error from correction
                        big3_error = so.big3_correction(big3_correction, CO2, CH4, H2O)

                        # mask data
                        spec = copy.deepcopy(spec[data_msk])

                        # correct partial fit data
                        spec["partial_fit"] -= big3_error[corr_msk]

                    # get other params needed for spectral arithmetic and convert dataframe to dictionary
                    extra_info = _extra_data_for_spectral_arithmetic(row)
                    spectrum = dataframe_to_dict_of_numpy_arrays(spec)
                    spectrum.update(extra_info)
                    spectra.append(spectrum)
        if len(spectra) >= min_spectra_count:
            yield _group, _compactify_spectra(spectra, f0_thresh, fsr_thresh)


def get_dataframes(
    base_path: str,
    campaign_start: datetime,
    campaign_end: datetime,
    time_zone: str,
    file_type: List[str] = ["PrivateLog"],
    valve_key: str = "ValveMask",
    broadband_key: str = "broadband_gasConcs_176",
    extra_columns: List[str] = [],
):
    """
    dataframe generator, using PrivateLogs as a data pool source.
    Args:
        base_path: path to pool/source
        campaign_start: pull data after this datetime object
        campaign_end: pull data before this datetime object
        file_type: log to pull from
        valve_key: key for valve mask
        broadband_key: key in logs to use
    Returns:
        dataframe grouped by valve position
    """
    tz = pytz.timezone(time_zone)
    campaign_start = tz.localize(campaign_start)
    campaign_end = tz.localize(campaign_end)

    def fmt_time(tme):
        return tme.strftime("%Y_%m_%d")

    LOGGER.info(
        f"loading data from {fmt_time(campaign_start)} to {fmt_time(campaign_end)}"
    )

    # identify the relevant pool files
    files = get_file_paths_in_timerange(campaign_start, campaign_end, base_path, file_type)
    variables = [valve_key, broadband_key] + extra_columns
    # get the data
    df = get_data_frame(files, sorted(variables))
    df = df.reindex(df.index.tz_convert(time_zone))
    # Group the data by port
    grouped_df = group_by_port(df, [broadband_key], campaign_start, campaign_end)

    if len(grouped_df.index) >= 1:
        return grouped_df
