from typing import Generator, List, Union

import numpy as np
import pandas as pd
import scipy
from spectral_arithmetic.data_models.model_function import ModelFunctions
from spectral_arithmetic.linear_least_squares import LinearLeastSquares

from data_pooler.persist import get_combolog_from_zpickle
from spectral_toolkit.constants.mimics import mimics
from spectral_toolkit.db_clients.mongo_spectral_library import (
    get_mongo_spectral_library_client,
)
from spectral_toolkit.logger import get_logger
from spectral_toolkit.model_function.mongodb import model_function
from spectral_toolkit.sam_analysis.compactify import DEFAULT_NU_CENTER

LOGGER = get_logger(__name__)
NUC1 = "fitData_nu_transform_nnuc"
NUC2 = "fitData_fitdata_params_nucenter"


# TODO: Move all db queries to central location
def _get_model_functions_by_cid(
    cid_list: List[int],
    nu_min: int = 5800,
    nu_max: int = 6300,
    nominal_pressure: float = 140.0,
):
    """
    Grab all the model functions for our list of cids including mimics
    """
    client = get_mongo_spectral_library_client()
    mimic_splines = {}
    library_splines = {}
    for cid in cid_list:
        if str(cid) in mimics.keys():
            # Get a mimic
            mimic_splines[int(cid)] = scipy.interpolate.interp1d(
                mimics[str(cid)]["nu"],
                mimics[str(cid)]["absorption"],
                fill_value="extrapolate",
            )
        else:
            try:
                # normal library spline
                library_splines[int(cid)] = model_function(
                    client,
                    cid,
                    nu_min,
                    nu_max,
                    nominal_pressure=nominal_pressure,
                    use_exact_pressure=False,
                )
            except Exception as e:
                LOGGER.warning(f"Unable to aquire model function for cid {cid}: {e}")

    client.client.close()
    library_splines.update(mimic_splines)
    model_functions = ModelFunctions(
        nu_min=nu_min, nu_max=nu_max, funcs=library_splines
    )

    return model_functions


def _get_nu_key(columns: List[str]):
    """
    Convenience to get whatever nu center key is available
    """
    if NUC1 in columns:
        nu_key = NUC1
    elif NUC2 in columns:
        nu_key = NUC2
    else:
        nu_key = None

    return nu_key


def reprocess_real_time(
    summary_gen: Generator,
    cids: List[int],
    port: Union[int, None] = None,
    valve_key="ValveMask",
    nominal_pressure: float = 140,
):
    """
    This function will iterate through a summary data generator dataframe and refit all
    the associated spectra with the list of cids.
    TODO: Look at merging this and compact reprocess
    Arguments:
        summary_gen: summary data with combo generator file and spec id
        cids: the cids we'd like to refit with when reprocessing
        port: if specified we will only reprocess the given port
        valve_key: You know what this is
        nominal_pressure: operating pressure
    Returns
        DataFrame with all the refit concentration data and original data
        of cids that match the list
    """

    model_functions = _get_model_functions_by_cid(
        cids, nominal_pressure=nominal_pressure
    )
    lsq = LinearLeastSquares(model_functions)

    # Only get gasConcs that exist in old fit that we refit
    check_concs = [f"broadband_gasConcs_{cid}" for cid in cids]
    _ = next(summary_gen)
    summary_df = next(summary_gen)
    cols_to_keep = list(set(check_concs).intersection(set(summary_df.columns)))
    # Make them all ppb
    temp_df = summary_df[cols_to_keep] * 1e9

    # Pull valve_keep
    temp_df[valve_key] = summary_df[valve_key]
    temp_df["spec_gen_file"] = summary_df["spec_gen_file"]
    temp_df["spec_gen_id"] = summary_df["spec_gen_id"]

    # Get the nu center data
    nu_key = _get_nu_key(summary_df.columns)
    if nu_key:
        temp_df[nu_key] = summary_df[nu_key]

    # Mask on port if specified
    if port:
        temp_df = temp_df.loc[temp_df[valve_key] == int(port)]

    # Refit for each row in average
    rows = []
    results = []
    cur_file = temp_df["spec_gen_file"][0]
    combo_gen = get_combolog_from_zpickle(open(cur_file, "r"))
    _ = next(combo_gen)
    for i, row in temp_df.iterrows():
        if row["spec_gen_file"] != cur_file:
            cur_file = row["spec_gen_file"]
            combo_gen = get_combolog_from_zpickle(open(cur_file, "r"))
            _ = next(combo_gen)

        spec = combo_gen.send(int(row["spec_gen_id"]))

        if nu_key:
            nu_center = row[nu_key]
        else:
            nu_center = DEFAULT_NU_CENTER

        res, stats = lsq.eval(
            spec["nu"].to_numpy(),
            spec["partial_fit"].to_numpy(),
            y_err=1 / np.sqrt(spec["npoints"].to_numpy()),
            nu_center=nu_center,
            baseline_order=1,
        )

        rows.append(row)

        # Add average timestamp
        res["lsq_rmse"] = np.std(stats.residual_error)
        res["_datetime"] = i
        results.append(res)

    # join the dateframes and reset index for dropped rows
    compact_refit = pd.concat(
        [pd.DataFrame(rows).reset_index(drop=True), pd.DataFrame(results)], axis=1
    ).set_index("_datetime")

    return compact_refit


def reprocess_compact(compact_gen: Generator, cids: List[int], valve_key="ValveMask", nominal_pressure: float = 140.0):
    """
    Refit compacted data with a list of cids.  Keep the intersection of
    cids refit in original data
    Arguments:
        compact_gen: Generator first is header, second is comapct time series, then spectra
        cids: list of cids to refit
        valve_key: sam valve key
        nominal_pressure: operating pressure
    Returns:
        pandas.DataFrame with all new concentrations, valve key, other results from refitter
    """
    # Get model functions
    # TODO: make a singleton or cache model functions
    model_functions = _get_model_functions_by_cid(cids, nominal_pressure=nominal_pressure)
    lsq = LinearLeastSquares(model_functions)

    _ = next(compact_gen)
    group_df = next(compact_gen)

    # Only get gasConcs that exist in old fit that we refit
    check_concs = [f"broadband_gasConcs_{cid}" for cid in cids]
    cols_to_keep = list(set(check_concs).intersection(set(group_df.columns)))

    # Make them all ppb
    temp_df = group_df[cols_to_keep] * 1e9

    # Pull valve_keep
    temp_df[valve_key] = group_df[valve_key]

    # Get the nu center data
    nu_key = _get_nu_key(group_df.columns)
    if nu_key:
        temp_df[nu_key] = group_df[nu_key]

    # Refit for each row in average
    rows = []
    results = []
    for i, row in temp_df.iterrows():
        _, spec = next(compact_gen)

        if nu_key:
            nu_center = row[nu_key]
        else:
            nu_center = DEFAULT_NU_CENTER

        res, stats = lsq.eval(
            spec.nu_prime,
            spec.partial_fit,
            y_err=1 / np.sqrt(spec.n_points),
            nu_center=nu_center,
            baseline_order=1,
        )

        rows.append(row)

        # Add average timestamp
        res["lsq_rmse"] = np.std(stats.residual_error)
        res["_datetime"] = i
        results.append(res)
    # join the dateframes and reset index for dropped rows
    compact_refit = pd.concat(
        [pd.DataFrame(rows).reset_index(drop=True), pd.DataFrame(results)], axis=1
    ).set_index("_datetime")

    return compact_refit
