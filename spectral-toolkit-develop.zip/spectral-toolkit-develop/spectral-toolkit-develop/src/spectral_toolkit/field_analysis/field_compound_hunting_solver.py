import numpy as np
import pandas as pd
import xarray as xr

from copy import deepcopy
from pathlib import Path
import time

import os
from typing import List, Optional, TypeVar, Tuple

from compound_hunting.transformers.r3_transformer import R3Transformer

from spectral_toolkit.scheme_optimizer.reporting import get_pubchem_df

from compound_hunting.assessment.regression_summary import regression_summary
from spectral_toolkit.plotting.spectral_hunting_plot import fit_result_plot
from spectral_toolkit.data_models.field_models import configYaml

# pubchem data to get common names from cids
pc_df = get_pubchem_df()

def perform_solve(
        solver, 
        X, 
        Y,
        correlation: bool
        ) -> Tuple[list, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, float]:
    results = solver.fit(X, Y).get_feature_names_out()
    results = [int(r) for r in results]
    Xt = solver.transform(X)
        
    if len(results)>0:
        coefs, scores = regression_summary(Xt, Y, multioutput_coefs="raw_values", multioutput_scores="raw_values")
        if correlation:
            coefs_mean = coefs
        else:
            coefs_mean = coefs.mean(axis=0)
            scores = scores.describe().T
            coefs = coefs.describe().T
        Xt.loc[:, 0] = np.ones(Xt.shape[0])
        spectral_contribution = Xt * coefs_mean

        Q_df = pd.DataFrame(
            solver.feature_importances_[solver._get_support_mask()], 
            index=solver.feature_names_in_[solver._get_support_mask()],
            columns=['Q']
            )
        
    else:
        # ToDo: updated for SFS
        Q_df = pd.DataFrame(columns=['Q'])
        coefs = None
        scores = None
        spectral_contribution = None
        coefs_mean = None

    return results, coefs, scores, Q_df, spectral_contribution, coefs_mean

def slice_it_up(
        df: pd.DataFrame, 
        exclude_list: List[int]
        ) -> pd.DataFrame:
    data_mask = df.index > 0
    for exclude in exclude_list:
        data_mask &= (df.index <= exclude[0]) | (df.index >= exclude[1])
    return df[data_mask]

def _process_peak(
        exp_subfolder: Path, 
        solver_name, 
        solver, 
        overwrite: bool = True,
        dont_fit: List[int] = [],
        exclude_list: List[int] = [],
        correlation: bool = False
        ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if not exp_subfolder.exists():
        raise ValueError("No data found")
    
    X = pd.read_parquet(exp_subfolder / "X.parquet")
    X.columns = X.columns.astype(int)
    column_list = X.columns.to_list()
    for ignore_cid in dont_fit:
        if ignore_cid in column_list:
            X.drop(columns=[ignore_cid], inplace=True)
    if correlation:
        Y = pd.read_parquet(exp_subfolder / "Y.parquet").squeeze()
    else:
        Y = pd.read_parquet(exp_subfolder / "Y.parquet")
    
    # count_na_by_mode = Y.isna().sum(axis=1)
    # bad = count_na_by_mode[count_na_by_mode>20].index
    # Y.drop(bad, inplace=True)
    # Y.dropna(axis=1)
    
    X = slice_it_up(X, exclude_list)
    Y = slice_it_up(Y, exclude_list)
    
    results_folder = exp_subfolder / "results"
    if results_folder.exists() and not overwrite:
        print('Analysis already performed.')
        return None, None, None
    results_folder.mkdir(exist_ok=True, parents=True)

    results_txt_file = results_folder / f"{solver_name}.txt"

    results, coefs, scores, Q_df, spectral_contribution, coefs_mean = perform_solve(solver, X, Y, correlation)

    if len(results) == 0:
        return None, None, None
        
    Q_df.index.rename('CID', inplace = True)
    Q_df['compound'] = [pc_df.loc[int(cid)]['commonName'] for cid in Q_df.index]
    Q_df['concentration_ppb'] = coefs_mean[Q_df.index.astype(int)].to_numpy()
    Q_df.sort_values('Q', ascending=False, inplace=True)

    Q_df.to_csv(results_folder / f'{solver_name}_Q_values.csv')

    if correlation:
        anny = scores.map(lambda x: format(x, '0.4g')).to_string().replace("\n", "<br>")
    else:
        anny = scores.loc[:, "mean"].map(lambda x: format(x, '0.4g')).to_string().replace("\n", "<br>")
        
    fig = fit_result_plot(
            experimental_datapoints=Y if correlation else Y.mean(axis=1) ,
            absorption_df=spectral_contribution,
            concentrations=coefs_mean,
            species_colormap=None,
            annotations=anny,
            title_text=f"{exp_subfolder.name} {solver_name}, {exp_subfolder.name}",
        )

    # write html and png
    fig_path = results_folder / f"{solver_name}.html"
    fig.write_html(fig_path)
    fig_path = results_folder / f"{solver_name}.png"
    fig.write_image(fig_path, width=1920, height=1080)
    
    with open(results_txt_file, 'w') as file:
        file.write(f"{results}\n")
        if len(results)>0:
            file.write("\nConcentrations\n")
            file.write(coefs.to_string())
            file.write("\n\nScores\n")
            file.write(scores.to_string())
        
    return coefs, scores, Q_df

def event_full_process(
        config: configYaml,
        subfolder: Path, 
        name = 'R3_Negs', 
        ban_negs = False, 
        corr_bool = True,
        STOP = False,
        OVERWRITE = True,
        ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, bool]:
    start = time.time()

    first_solver = R3Transformer(
        Q_threshold=1.2, 
        dont_fit=config.fitting.dont_fit, 
        ban_negatives=ban_negs, 
        max_cycles=5
        )
    print("  Solving %s" % name)
    print("   First Fit")
    try:
        coefs, scores, Q_df = _process_peak(
            Path(subfolder), 
            solver_name = f"R3_presolve_{name}", 
            solver = first_solver, 
            overwrite=OVERWRITE, 
            dont_fit=config.fitting.dont_fit, 
            exclude_list=config.fitting.exclude_list, 
            correlation=corr_bool
            )
    except Exception as e:
        print(e)
        print('*******'*3)
        print('Subfolder %s FAILED' % subfolder)
        print('*******'*3)
        return None, None, None, STOP

    if Q_df is not None:
        print(Q_df)

        reqd_cids = list(Q_df.index)
        reqd_cids = [int(c) for c in reqd_cids]
    else:
        reqd_cids = None
    print()
    print("   Final Fit")
    final_solver = R3Transformer(
        Q_threshold=0, 
        dont_fit=config.fitting.dont_fit, 
        ban_negatives=ban_negs, 
        initial_seed_cids=reqd_cids
        )
    try:
        coefs, scores, Q_df = _process_peak(
            Path(subfolder), 
            solver_name = f"R3_{name}", 
            solver = final_solver, 
            overwrite=OVERWRITE, 
            dont_fit=config.fitting.dont_fit, 
            exclude_list=config.fitting.exclude_list, 
            correlation=corr_bool
            )
    except Exception as e:
        print(e)
        print('*******'*3)
        print('Subfolder %s FAILED' % subfolder)
        print('*******'*3)

    if Q_df is not None:
        print(Q_df)

    try:
        pass
    except KeyboardInterrupt:
        print('Terminating Execution')
        STOP = True
        # break
    except Exception as e:
        print(e)
        print('*******'*3)
        print('Subfolder %s FAILED' % subfolder)
        print('*******'*3)
    print('Duration = %.0f secs' % (time.time() - start))

    return coefs, scores, Q_df, STOP