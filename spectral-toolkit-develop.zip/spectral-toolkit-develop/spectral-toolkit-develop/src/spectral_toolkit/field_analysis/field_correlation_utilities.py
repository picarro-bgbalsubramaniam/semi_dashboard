import numpy as np
import xarray as xr
from enum import Enum
from pydantic import Field
from typing import Union, List

from spectral_arithmetic.linear_least_squares import least_squares

from picarro_xarray.data_models.data_types import (
    TimeseriesDataArray,
    SpectralTimeseriesDataArray,
    CompactDataSet,
    ComboDataSet,
)

from picarro_xarray.data_models.constants import (
    TIME_DIM,
    MODE_DIM,
    FITTER_VARNAME,
    SPECTRA_VARNAME,
    NU_VARS,
    NPOINTS_KEY,
    TRANSITION_VAR,
)

class CorrelationType(str, Enum):
    SHORTTERM = "short_term"
    LONGTERM = "long_term"
    
    def slope_function(self):
        match self:
            case CorrelationType.SHORTTERM:
                return _slope_linear_trend
            case CorrelationType.LONGTERM:
                return _slope_lsq_fit_2D
            case _:
                raise ValueError(f"Unknown correlation type {self}")

def _lsq_fit(x: np.ndarray, y: np.ndarray, t: np.ndarray) -> float:
    """
    Using least_squares
    """
    Amatrix = np.vstack([np.ones_like(x), x, t]).T
    fit, _ = least_squares(Amatrix, y)
    return fit[1]


def _linear_trend(x: np.ndarray, y: np.ndarray) -> float:
    """
    Using numpy.polyfit to get a linear trend
    """
    trend = np.polyfit(x, y, 1)[0]
    return trend


def _detrend_dim(
    da: xr.DataArray,
    dim: str,
    deg: Field(default=1, ge=1),
) -> xr.DataArray:
    """
    detrend xarray DataArray along a single dimension
    """
    if dim not in da.dims:
        raise ValueError(f"Dimension {dim} not found in xarray DataArray")
    p = da.polyfit(dim=dim, deg=deg)
    fit = xr.polyval(da[dim], p.polyfit_coefficients)
    return da - fit


def _slope_linear_trend(
    da_spec: SpectralTimeseriesDataArray,
    da_timeseries: TimeseriesDataArray,
    detrend: bool = False,
) -> xr.DataArray:
    """
    Using numpy.polyfit and xr.apply_ufunc
    Can be optimized with dask
    """
    if detrend:
        da_spec = _detrend_dim(da_spec, dim=TIME_DIM, deg=1)
        da_timeseries = _detrend_dim(da_timeseries, dim=TIME_DIM, deg=1)
    out = xr.apply_ufunc(
        _linear_trend,
        da_timeseries,
        da_spec.dropna(dim=MODE_DIM),
        vectorize=True,
        input_core_dims=[[TIME_DIM], [TIME_DIM]],
    )
    return out


def _slope_lsq_fit_2D(
    da_spec: SpectralTimeseriesDataArray, 
    da_timeseries: TimeseriesDataArray
) -> xr.DataArray:
    """
    Using least_squares from spectral_arithmetic and xr.apply_ufunc
    Can be optimized with dask
    """
    times = da_timeseries[TIME_DIM]
    tmax = times.max()
    tmin = times.min()
    time_nondim = (times - tmin).astype(float) / (tmax - tmin).astype(float)
    da_time_itself = xr.DataArray(
        time_nondim, coords={TIME_DIM: times.values}, dims=[TIME_DIM]
    )
    out = xr.apply_ufunc(
        _lsq_fit,
        da_timeseries,
        da_spec.dropna(dim=MODE_DIM),
        da_time_itself,
        vectorize=True,
        input_core_dims=[[TIME_DIM], [TIME_DIM], [TIME_DIM]],
    )
    return out

def compute_correlation_spectrum(
    ds: Union[ComboDataSet, CompactDataSet],
    corr_key: str = 'partial_fit_integral',
    correlation_type: CorrelationType = CorrelationType.SHORTTERM,
) -> xr.Dataset:
    """
    Compute correlation spectrum
    Inputs :
        ds : (xr.Dataset)
        corr_key : (str) fitter_var with which to compute correlation
        correlation_type : (CorrelationType) short_term or long_term
    Returns :
        corrspec : (xr.Dataset) correlation spectrum centered at the middle of the event
    """
    da_spec = ds.spectral_values.dropna(dim=TIME_DIM, how='all').load()
    da_ts = ds.fitter_values.sel(fitter_var=corr_key).dropna(dim=TIME_DIM, how='all').load()
    tmid = (ds[TIME_DIM].max().values - ds[TIME_DIM].min().values) / 2 + ds[TIME_DIM].min().values
    fitter_val = (da_ts.max(TIME_DIM) - da_ts.min(TIME_DIM)).values
    corrspec = CorrelationType(correlation_type).slope_function()(da_spec, da_ts)
    spectral_var_indices = {k: i for i, k in enumerate(corrspec.spectral_var.values)}
    # Handle special treatment for "nu","nu_prime" and "npoints"
    for k in NU_VARS:
        corrspec[spectral_var_indices[k]] = da_spec.sel(
            spectral_var=k, mode=corrspec.mode
        ).isel({TIME_DIM: 0})
    corrspec[spectral_var_indices[NPOINTS_KEY]] = ds.spectral_values.sel(
        spectral_var=NPOINTS_KEY, mode=corrspec.mode
    ).sum(TIME_DIM)
    corrspec = corrspec.expand_dims({TIME_DIM: [tmid]})
    da_fitter = xr.DataArray(
        [fitter_val],
        coords={FITTER_VARNAME: [corr_key]},
        dims=[FITTER_VARNAME],
    )
    da_fitter = da_fitter.expand_dims({TIME_DIM: [tmid]})
    out = xr.merge(
        [
            da_fitter.to_dataset(name="fitter_values"),
            corrspec.to_dataset(name="spectral_values"),
        ]
    )
    return out

def compute_correlation_spectrum_list(
    ds: Union[ComboDataSet, CompactDataSet],
    corr_keys: List[str] = ['partial_fit_integral'],
    correlation_type: CorrelationType = CorrelationType.SHORTTERM,
) -> xr.Dataset:
    """
    Compute correlation spectrum
    Inputs :
        ds : (xr.Dataset)
        corr_keys: (list of str) fitter_vars with which to compute correlation
        correlation_type : (CorrelationType) short_term or long_term
    Returns :
        corrspec : (xr.Dataset) correlation spectrum centered at the middle of the event
    """
    da_spec = ds.spectral_values.dropna(dim=TIME_DIM, how='all').load()
    da_ts = ds.fitter_values.sel(fitter_var=corr_keys).dropna(dim=TIME_DIM, how='all').load()
    tmid = (ds[TIME_DIM].max().values - ds[TIME_DIM].min().values) / 2 + ds[TIME_DIM].min().values
    fitter_val = (da_ts.max(TIME_DIM) - da_ts.min(TIME_DIM)).values
    corrspec = CorrelationType(correlation_type).slope_function()(da_spec, da_ts)
    spectral_var_indices = {k: i for i, k in enumerate(corrspec.spectral_var.values)}
    # Handle special treatment for "nu","nu_prime" and "npoints"
    for k in NU_VARS:
        corrspec[spectral_var_indices[k]] = da_spec.sel(
            spectral_var=k, mode=corrspec.mode
        ).isel({TIME_DIM: 0})
    corrspec[spectral_var_indices[NPOINTS_KEY]] = ds.spectral_values.sel(
        spectral_var=NPOINTS_KEY, mode=corrspec.mode
    ).sum(TIME_DIM)
    corrspec = corrspec.expand_dims({TIME_DIM: [tmid]})
    da_fitter = xr.DataArray(
        [fitter_val],
        coords={FITTER_VARNAME: corr_keys},
        dims=[FITTER_VARNAME],
    )
    da_fitter = da_fitter.expand_dims({TIME_DIM: [tmid]})
    out = xr.merge(
        [
            da_fitter.to_dataset(name="fitter_values"),
            corrspec.to_dataset(name="spectral_values"),
        ]
    )
    return out