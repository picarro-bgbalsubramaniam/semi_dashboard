import pandas as pd
import numpy as np
from typing import Tuple

def weighted_average(ds):
    # std_now = ds.sel(stat='std')

    # weighted_now = ds.sel(stat='mean').weighted(std_now.fitter_values.fillna(0))

    # return weighted_now.mean(dim='_datetime', skipna = True)
    return ds.sel(stat='mean').weighted(ds.sel(stat='std').fitter_values.fillna(0)).mean(dim='_datetime', skipna = True)

def weighted_stdev(ds):
    # std_now = ds.sel(stat='std')

    # weighted_now = ds.sel(stat='mean').weighted(std_now.fitter_values.fillna(0))

    # return weighted_now.std(dim='_datetime', skipna = True)
    return ds.sel(stat='mean').weighted(ds.sel(stat='std').fitter_values.fillna(0)).std(dim='_datetime', skipna = True)

def weighted_quantile(ds, q = 0.25):
    std_now = ds.sel(stat='std')

    weighted_now = ds.sel(stat='mean').weighted(std_now.fitter_values.fillna(0))

    return weighted_now.quantile(q = q, dim = '_datetime', skipna = True)

def rename_variables(
    df: pd.DataFrame, initial_name: str, new_name: str
) -> pd.DataFrame:
    df = df.rename(columns={initial_name: new_name})
    return df

def get_first(df_series):
    try:
        return df_series.to_numpy()[0]
    except:
        return df_series[0]
    
def weighted_ave_std(df: pd.DataFrame, var_name: str) -> Tuple[float, float]:
    values = df[var_name]["nanmean"]
    if np.any(df[var_name]["nanstd"] != 0):
        weights = 1 / (df[var_name]["nanstd"] ** 2)
    else:
        weights = np.ones_like(values)
    weighted_ave = np.average(values, weights=weights)
    weighted_std = np.average((values - weighted_ave) ** 2, weights=weights)
    return (weighted_ave, weighted_std)


def error_prop_as(error_vector):
    return np.sqrt(np.sum(error_vector**2))

# from math import *
def yamartino(theta_da):
    s=0
    c=0
    n=0.0
    # for theta in thetalist:
    #     s=s+sin(radians(theta))
    #     c=c+cos(radians(theta))
    #     n+=1
    s = np.sin(np.radians(theta_da)).sum('_datetime')
    c = np.cos(np.radians(theta_da)).sum('_datetime')
    n = theta_da.count()
    s=s/n
    c=c/n
    eps=(1-(s**2+c**2))**0.5
    sigma=np.arcsin(eps)*(1+(2.0/3.0**0.5-1)*eps**3)
    return np.degrees(sigma)