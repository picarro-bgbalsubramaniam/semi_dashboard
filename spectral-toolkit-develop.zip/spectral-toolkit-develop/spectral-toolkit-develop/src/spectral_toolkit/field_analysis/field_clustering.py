"""
Functions to perform clustering
"""
import numpy as np
import pandas as pd
from pydantic import validate_call
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import MinMaxScaler

from spectral_toolkit.data_models.field_models import configYaml
# from data_models.logger import get_logger

# LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True))
def get_clusters(
    species_df: pd.DataFrame, eps: float = 0.03, min_samples: int = 3
) -> pd.Series:
    """
    Cluster data using all columns in the dataframe.
    Each column is normalized between 0 and 1 before clustering.

    Args:
        species_df (pd.DataFrame):
            Each column in the dataframe will be
            used as a clustering variable.
        eps (float):
            Eps for the cluestering algorithm.
        min_samples (int):
            Minimum number of samples (in a cluster).
            Used by the clustering algorithm.

    Returns:
        pd.Series:
            Series with same length and same index
            as species_df. The values in the series
            are the cluster numbers from the clustering
            algorithm.

    """
    # LOGGER.info(f"Clustering with {eps=}, {min_samples=}")

    scaler = MinMaxScaler().set_output(transform="pandas")
    scaled_species_df = scaler.fit_transform(species_df)
    clusters = _clustering_algo(
        scaled_species_df=scaled_species_df, eps=eps, min_samples=min_samples
    )
    return clusters


@validate_call(config=dict(arbitrary_types_allowed=True))
def _clustering_algo(
    scaled_species_df: pd.DataFrame, eps: float = 0.1, min_samples: int = 10
) -> pd.Series:
    """
    Performs clustering (without scaling).
    Returns a series with the same length and
    same index of the input dataframe, with cluster
    numbers as values.

    Args:
        scaled_species_df (pd.DataFrame):
            Each column in the dataframe will be
            used as a clustering variable.
            Please scale beforehand.
        eps (float):
            Eps for the cluestering algorithm.
        min_samples (int):
            Minimum number of samples (in a cluster).
            Used by the clustering algorithm.

    Returns:
        pd.Series:
            Series with same length and same index
            as species_df. The values in the series
            are the cluster numbers from the clustering
            algorithm.

    """
    db = DBSCAN(eps=eps, min_samples=min_samples)
    labels = pd.Series(data=db.fit_predict(scaled_species_df), index=scaled_species_df.index)
    return labels


# @validate_call(config=dict(arbitrary_types_allowed=True))
# def get_group_number_from_clusters(clusters: pd.Series) -> pd.Series:
#     """
#     Create a monotonic increasing cluster number
#     without gaps. This addresses the situation where
#     some clusters are dropped, leaving gaps in the cluster
#     numbering.

#     >>> a=pd.Series([0,0,0,2,2,5,6])
#     >>> b=get_group_number_from_clusters(a)
#     >>> print(b.values)
#     [1 1 1 2 2 3 4]


#     Args:
#         clusters (pd.Series):
#             Clustering values.

#     Returns:
#         pd.Series:
#             New clustering values
#             without numbering gaps.

#     """
#     different = clusters != clusters.shift(1)
#     groups = different.cumsum()
#     groups.name = "group"
#     return groups


# def get_populated_groups(
#     groups: pd.Series,
#     group_duration_min: int = 30,
#     group_duration_max: int = 3600,
#     min_points: int = 15,
# ):
#     """
#     Get groups that satisfy the population requirements.

#     Args:
#         groups (pd.Series):
#             Clusters from the clustering algorithms
#         group_duration_min (int):
#             Minimum cluster duration in seconds
#         group_duration_max (int):
#             Maximum cluster duration in seconds
#         min_points (int):
#             Minimum number of points required in
#             a cluster

#     Returns:
#         pd.Series: Groups to keep

#     """
#     # LOGGER.info(
#     #     f"Removing groups with bounds {group_duration_min=}, {group_duration_max=}, {min_points=}"
#     # )

#     populations_groups = (
#         groups.reset_index()
#         .groupby(by="group")
#         .agg(
#             duration=("_datetime", np.ptp),
#             start=("_datetime", "min"),
#             end=("_datetime", "max"),
#             occurrences=("group", "count"),
#         )
#     )

#     min_dur = pd.to_timedelta(group_duration_min, unit="s")
#     max_dur = pd.to_timedelta(group_duration_max, unit="s")

#     duration_ok = populations_groups.duration.between(min_dur, max_dur)
#     population_ok = populations_groups.occurrences >= min_points

#     keep_condition = duration_ok & population_ok

#     drop_groups = populations_groups[~keep_condition]

#     # LOGGER.warning(
#     #     f"Dropping {len(drop_groups)} groups (out of {len(populations_groups)})"
#     # )

#     # for row in drop_groups.itertuples():
#     #     LOGGER.info(
#     #         f"Dropped group {row.Index}, "
#     #         f"from {row.start} to {row.end}, "
#     #         f"duration {row.duration}"
#     #         f", {row.occurrences:,} occurrences"
#     #     )

#     # Filter groups
#     keep_groups = populations_groups[keep_condition]

#     return keep_groups.index


# def _drop_transitions(group: pd.Series, start: int, end: int) -> pd.Series:
#     """
#     Remove seconds at the start and the end of a series.

#     Args:
#         group (pd.Series):
#             Timeseries from which to remove
#             the starting and ending sections.
#         start (int):
#             Seconds to remove at the start of
#             a series.
#         end (int):
#             Seconds to remove at the end of
#             a series.

#     Returns:
#         pd.Series: Trimmed series

#     """
#     time_index = group.index
#     start = time_index[0] + pd.Timedelta(start, "s")
#     end = time_index[-1] - pd.Timedelta(end, "s")
#     filter_times = (time_index >= start) & (time_index <= end)
#     return group[filter_times]


# def remove_group_transitions(
#     group: pd.Series, trim_start: int = 30, trim_end: int = 10
# ):
#     """
#     Remove start and end seconds in correspondence
#     of a group transition.
#     A transition consists in a value change in
#     group from one time to the next.

#     Args:
#         group (pd.Series):
#             Clustering result timeseries
#         trim_start (int):
#             Seconds to remove at the start
#             of a transition
#         trim_end (int):
#             Seconds to remove at the end of
#             a transition.

#     Returns:
#         pd.Series: Trimmed series
#     """
#     # LOGGER.info(f"Removing group transitions with {trim_start=}s, {trim_end=}s")
#     port = group.to_frame()

#     filtered_df = port.groupby("group").apply(
#         lambda x: _drop_transitions(x, start=trim_start, end=trim_end)
#     )
#     filtered_df = filtered_df.reset_index(level="group", drop=True)

#     filtered = filtered_df["group"]

#     # LOGGER.info(
#     #     f"Trim groups start/end: dropped {len(port) - len(filtered):,} datapoints (out of {len(port):,})"
#     # )
#     return filtered


# def get_steps(species_df: pd.DataFrame, config: configYaml) -> pd.Series:
#     """
#     High level clustering sequence for crosstalk analysis.
#     From a timeseries dataset, extract the time axis and
#     incorporate it as a data column.
#     Perform clustering.
#     Drop outliers.
#     Get group number from clustering.
#     Drop group transition.
#     Keep only groups satisfying the duration requirements.

#     Args:
#         species_df (pd.DataFrame):
#             Dataframe with a DateTimeIndex.
#         config (configYaml):
#             Field Analysis configuration.

#     Returns:
#         pd.Series:
#             Group assignment for every time instant
#             of the input dataframe.
#             Some datetimes might have been dropped due
#             to outliers, lack of duration, or
#             corresponding to a transition.

#     """

#     timeseries_df = species_df.copy(deep=True)
#     timeseries_df = timeseries_df.reset_index()
#     timeseries_df["_datetime"] = timeseries_df["_datetime"].values.astype(int)

#     clusters = get_clusters(
#         timeseries_df,
#         eps=config.steps.clustering_eps,
#         min_samples=config.steps.min_clustering_samples,
#     )

#     clusters.index = species_df.index

#     # Remove outliers
#     updated_clusters = clusters[clusters != -1]

#     # LOGGER.info(
#     #     f"Removing {len(clusters)-len(updated_clusters):,} (out of {len(clusters):,})"
#     #     f" outlier datapoints during clustering"
#     # )

#     groups = get_group_number_from_clusters(updated_clusters)

#     return groups