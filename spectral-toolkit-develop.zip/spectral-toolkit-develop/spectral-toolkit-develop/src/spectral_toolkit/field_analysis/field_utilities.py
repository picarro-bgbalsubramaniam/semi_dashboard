import xarray as xr
import pandas as pd
import numpy as np
from scipy.stats import circmean, circstd
from pathlib import Path
from tqdm import tqdm
from sklearn.metrics import r2_score

from pydantic import validate_call, Field
from typing import List

import dask.array as da

from picarro_xarray.compute.zero_reference import get_transition_uid
from picarro_xarray.data_models.constants import TIME_DIM
from picarro_xarray.data_models.data_types import (
    TimeseriesDataArray,
    TimeseriesDataSet,
)
from picarro_xarray.time_utils.timeutils import _parse_grouper

from picarro_xarray.preprocess.trim_transition import get_groups_time_bounds, drop_short_transitions, trim_transitions_edges, _boolean_mask_datetime
import picarro_xarray.accessors.compound_search_accessor  # noqa

from spectral_toolkit.df_operations.timeline_process_df import (
    _get_default_resampling_min_count,
)

from spectral_toolkit.field_analysis.field_clustering import get_clusters
from spectral_toolkit.data_models.field_models import configYaml

from spectral_toolkit.field_analysis.basic_utilities import weighted_average, weighted_quantile, weighted_stdev, yamartino

TVOC_SCALE = 0.62

ACTION_LIMITS = {
    'Benzene': 2.8, #HON action level, RfC 9.4, ACGIH TLV 500, PEL 1000
    'Toluene': 1300, #AQMD Draft Rule 1180 #RfC, no risk, ACGIH TLV 20,000, PEL 10,000
    # 'Ethylbenzene': 230, #RfC, no risk, ACGIH 100,000, PEL 5000
    'M-Xylene': 5e3, #AQMD Draft Rule 1180 #1e5, #Cal-OSHA PEL
    'O-Xylene': 5e3, #AQMD Draft Rule 1180 #1e5, #Cal-OSHA PEL
    'P-Xylene': 5e3, #AQMD Draft Rule 1180 #1e5, #Cal-OSHA PEL
    '1,3-Butadiene': 1.4, #HON action level, RfC 0.9, ACGIH 1990, PEL 1000
    'Acrolein': 1.1, #AQMD Draft Rule 1180 #0.009, #RfC, no risk, EPA AEGL 31, PEL 100
    'Ethylene Oxide': 0.11, #HON action level, PEL 1000
    'Hydrogen Sulfide': 30, #AQMD Draft Rule 1180 #1, #?, PEL 10,000

    'Formaldehyde': 44, #AQMD Draft Rule 1180
    'Acetaldehyde': 260, #AQMD Draft Rule 1180
    'Styrene': 5000, #AQMD Draft Rule 1180
    'Ammonia': 4507, #AQMD Draft Rule 1180
}

ALKANE_SCALING_FACTORS = {
    'CH4': 1,
    'Ethane': 2,
    'Ethylene': 2,
    'Propane': 3,
    'Prolynene': 3,
    'Butane': 4,
    'Isobutane': 4,
    'Pentane': 5,
    'Isopentane': 5,
    'Neopentane': 5,
    'Hexane': 6,
    'Isohexane': 6,
    '2-Methylpentane': 6,
    '3-Methylpentane': 6,
    '2,2-Dimethylbutane': 6,
    '2,3-Dimethylbutane': 6,
    'Heptane': 7,
    'Octane': 8,
    'Nonane': 9,
    'Decane': 10,
    'Methylcyclohexane': 7,
}

def merge_refit_big3(refit_ds, big3_ds):
    '''
    refit_ds
        dataset with _datetime, fitter_var, and fitter_values
        fitter_values must have the shape (_datetime, fitter_var)
    
    big3_ds
        dataset with _datetime, fitter_var, and fitter_values
        fitter_values must have the shape (_datetime, fitter_var)
    
    '''
    ds = refit_ds.copy()
    shared_datetime, ind1, ind2 = np.intersect1d(refit_ds._datetime, big3_ds._datetime, return_indices=True)
    fitter_values = ds.fitter_values.values
    for var_name in ['CO2','CH4','H2O']:
        fitter_values[ind1, refit_ds.fitter_var==var_name] = big3_ds.isel(_datetime=ind2).sel(fitter_var=var_name).fitter_values.values
    
    return ds.fitter_values.to_numpy()

def bin_average_to_time(ave_ds, wind_ds, averaging_str, vars_to_save, other_list=['partial_fit_integral']):
    wind_ds = wind_ds.sortby('_datetime')

    # bin average data to averaging interval and combine with wind data
    resampler_obj = ave_ds.resample(
        _datetime=averaging_str, skipna=True, label="right", closed="right"
    )
    conc_wgtd_ave_ds = resampler_obj.mean()
    conc_wgtd_std_ds = resampler_obj.std()
    conc_ave_ds = xr.concat([conc_wgtd_ave_ds, conc_wgtd_std_ds], dim='stat').assign_coords(stat=['mean','std'])

    wind_gb_obj = wind_ds.resample(
        _datetime=averaging_str, skipna=True, label="right", closed="right"
    )

    wind_speed_weighted_ave_ds = wind_gb_obj.mean(skipna=True).sel(parameter = 'SWS')
    wind_speed_weighted_std_ds = wind_gb_obj.std(skipna=True).sel(parameter = 'SWS')

    wind_speed_weighted_ds = xr.concat([wind_speed_weighted_ave_ds, wind_speed_weighted_std_ds], dim='stat').assign_coords(stat=['mean','std'])

    wind_direction_weighted_ds = wind_gb_obj.apply(circ_stats)

    wind_ave_ds = xr.concat([
        wind_speed_weighted_ds, 
        wind_direction_weighted_ds
        ], 
        dim = 'parameter'
    )

    new_ave_ds = xr.concat([
        conc_ave_ds.sel(fitter_var = ['CO2','CH4','H2O'] + vars_to_save + other_list), 
        wind_ave_ds.sel(parameter = ['SWD', 'SWS'])
        ], dim='other').assign_coords(other=['concs','wind'])
    
    return new_ave_ds

def weighted_bin_average_to_time(ave_ds, wind_ds, averaging_str, vars_to_save, other_list=['partial_fit_integral']):
    wind_ds = wind_ds.sortby('_datetime')

    # bin average data to averaging interval and combine with wind data
    resampler_obj = ave_ds.resample(
        _datetime=averaging_str, skipna=True, label="right", closed="right"
    )
    conc_wgtd_ave_ds = resampler_obj.apply(weighted_average)
    conc_wgtd_std_ds = resampler_obj.apply(weighted_stdev)
    conc_ave_ds = xr.concat([conc_wgtd_ave_ds, conc_wgtd_std_ds], dim='stat').assign_coords(stat=['mean','std'])

    wind_gb_obj = wind_ds.resample(
        _datetime=averaging_str, skipna=True, label="right", closed="right"
    )

    wind_speed_weighted_ave_ds = wind_gb_obj.mean(skipna=True).sel(parameter = 'SWS')
    wind_speed_weighted_std_ds = wind_gb_obj.std(skipna=True).sel(parameter = 'SWS')

    wind_speed_weighted_ds = xr.concat([wind_speed_weighted_ave_ds, wind_speed_weighted_std_ds], dim='stat').assign_coords(stat=['mean','std'])

    wind_direction_weighted_ds = wind_gb_obj.apply(circ_stats)

    wind_ave_ds = xr.concat([
        wind_speed_weighted_ds, 
        wind_direction_weighted_ds
        ], 
        dim = 'parameter'
    )

    new_ave_ds = xr.concat([
        conc_ave_ds.sel(fitter_var = ['CO2','CH4','H2O'] + vars_to_save + other_list), 
        wind_ave_ds.sel(parameter = ['SWD', 'SWS'])
        ], dim='other').assign_coords(other=['concs','wind'])
    
    return new_ave_ds

def create_average_ds(port_split_ds, averaging):
    min_count = -1

    # remove attrs if they exist in port_split_ds
    if len(port_split_ds.attrs.keys()) > 0:
        port_split_ds = xr.Dataset(data_vars = port_split_ds.data_vars, coords = port_split_ds.coords)

    # Get a resampler object
    resampler_obj = port_split_ds.copy().resample(
        _datetime=averaging.value, skipna=True, label="right", closed="right"
    )
    port_split_ds.close()

    # Get mean and standard deviation from resampler
    rs_mean = resampler_obj.mean()
    rs_std = resampler_obj.std()
    resampled_xr = xr.concat([rs_mean, rs_std], dim='stat').assign_coords(stat=['mean','std'])


    # Get data points count from resampler
    count_xr = resampler_obj.count()
    count_xr = count_xr.astype(int)
    count_xr = count_xr.rename_vars({"fitter_values": "data_points"})
    if 'private_values' in count_xr:
        count_xr = count_xr.drop_vars(['private_var','private_values'])

    auto_mincount = min_count

    if min_count < 0:
        # Automatic min_count based on averaging
        auto_mincount = _get_default_resampling_min_count(
            requested_averaging=averaging
        )

    # Mask based on minimum requirement on data points
    mask = count_xr.data_points > auto_mincount

    return_xr = resampled_xr.where(mask, np.NaN)
    return_xr = return_xr.merge(count_xr)

    return return_xr

def latency_adjust(
        ds: TimeseriesDataArray | TimeseriesDataSet,
        group_var: str,
        latency_seconds: float = Field(default=0, ge=0),
        var_group: str = 'fitter',
        ):
    
    latency = pd.Timedelta(latency_seconds, 'sec') 

    valve_ds = xr.Dataset(
        data_vars = dict(
            valve_values = (['_datetime'], ds.sel({f'{var_group}_var': group_var})[f'{var_group}_values'].values)
        ),
        coords = dict(
            _datetime = ds._datetime + latency
        )
    )

    latency_adjusted_group = valve_ds.interp(_datetime = ds._datetime, method='linear').valve_values.values[:,np.newaxis]
    valve_ds.close()

    return latency_adjusted_group


@validate_call(config=dict(arbitrary_types_allowed=True), validate_return=True)
def trim_transitions_ref_sample(
    data: TimeseriesDataArray | TimeseriesDataSet,
    grouper_da: TimeseriesDataArray | str,
    group_arr,
    ref_value: float,
    min_ref_duration_seconds: int = Field(default=50, ge=0),
    min_sample_duration_seconds: int = Field(default=50, ge=0),
    trim_start_seconds: int = Field(default=30, ge=0),
    trim_end_seconds: int = Field(default=10, ge=0),
): 
    """
    Trim the transitions in time series data.
    - drop transitions with duration less than `min_duration_seconds`
    - trim `trim_start_seconds` from the start of each transition
    - trim `trim_end_seconds` from the end of each transition

    A transition is defined as a time range where the
    data is grouped by `grouper_da`.

    Args:
        data (TimeseriesDataArray | TimeseriesDataSet): Time series data to trim.
        grouper_da (TimeseriesDataArray | str):
            DataArray used for grouping time points.
            Can be a string representing a variable name in ``fitter_var`` in ``data``,
            or a custom 1D TimeseriesDataArray indicating how to form groups
            (must have the same time length as ``data``, and must be 1D).
            For example, ``grouper_da = get_transition_uid(ds.sel(fitter_var='ValveMask').fitter_values)``
            or ``grouper_da="ValveMask"``.
        min_duration_seconds (int): Minimum duration in seconds for a time range to be kept.
        trim_start_seconds (int): Number of seconds to trim from the start of each time range.
        trim_end_seconds (int): Number of seconds to trim from the end of each time range.

    Returns:
        TimeseriesDataArray | TimeseriesDataSet: Trimmed time series data.
    """
    groupby = _parse_grouper(data=data, grouper=grouper_da)
    groupby = get_transition_uid(transition_data=groupby)

    time_bounds_ref_da = get_groups_time_bounds(
        time_da=data[TIME_DIM][group_arr == ref_value], grouper_da=groupby[group_arr == ref_value]
    )

    time_bounds_ref_da = drop_short_transitions(
        time_bounds_da=time_bounds_ref_da, 
        min_duration_seconds=min_ref_duration_seconds
    )

    time_bounds_ref_da = trim_transitions_edges(
        time_bounds_da=time_bounds_ref_da,
        trim_start_seconds=trim_start_seconds,
        trim_end_seconds=trim_end_seconds,
    )
    datetime_ref_mask = _boolean_mask_datetime(
        datetime_np=data[TIME_DIM].values,
        datetime_mins=time_bounds_ref_da.sel(stats="min").values,
        datetime_maxs=time_bounds_ref_da.sel(stats="max").values,
    )


    time_bounds_sample_da = get_groups_time_bounds(
        time_da=data[TIME_DIM][group_arr != ref_value], grouper_da=groupby[group_arr != ref_value]
    )
    time_bounds_sample_da = drop_short_transitions(
        time_bounds_da=time_bounds_sample_da, 
        min_duration_seconds=min_sample_duration_seconds
    )
    time_bounds_sample_da = trim_transitions_edges(
        time_bounds_da=time_bounds_sample_da,
        trim_start_seconds=trim_start_seconds,
        trim_end_seconds=trim_end_seconds,
    )
    datetime_sample_mask = _boolean_mask_datetime(
        datetime_np=data[TIME_DIM].values,
        datetime_mins=time_bounds_sample_da.sel(stats="min").values,
        datetime_maxs=time_bounds_sample_da.sel(stats="max").values,
    )

    datetimes_keep = data[TIME_DIM].values[datetime_ref_mask | datetime_sample_mask]
    return data.sel({TIME_DIM: datetimes_keep}), time_bounds_ref_da, time_bounds_sample_da

def get_ref_name(config: configYaml):
    if config.valve_info.valve_var not in ['MPVPosition', 'PortId', 'ValveMask'] or config.valve_info.valve_data_flnm is not None:
        return 'group'
    else:
        return config.valve_info.valve_var

def save_daily_zero_ref_conc_data(
        ds: xr.Dataset, 
        date_obj, 
        config: configYaml, 
        refit: bool = False
        ):
    # gather statistics
    ref_var = get_ref_name(config)
    fitter_var = ds.fitter_var.values
    vars_list = config.variables.vars_to_save + [ref_var]
    
    stats = ds.stat.values
    mi_col = pd.MultiIndex.from_product([vars_list, stats], names=['fitter_var','stat'])

    data_now = ds.sum(dim='port', skipna=True)
    data_now = data_now.isel(
        _datetime=np.where((data_now.sel(fitter_var=ref_var,stat='mean')!=config.valve_info.ref_value)
                           .fitter_values.values)[0])
    
    # select requested day
    data_now = data_now.sel(_datetime = date_obj.strftime('%Y-%m-%d'))

    conc_stats_df = pd.DataFrame(index = data_now._datetime.values, columns=mi_col)

    for var in vars_list:
        for stat in stats:
            if var in fitter_var:
                conc_stats_df.loc[:,(var,stat)] = data_now.sel(fitter_var=var, stat=stat).fitter_values.values
    conc_stats_df.dropna(axis=0, inplace=True)

    conc_stats_df = conc_stats_df.replace(0.0, np.nan).dropna(axis=0, how='all')

    if refit:
        flnm = f"refit_conc_zero_referenced_stats_{config.variables.report_time_average.value}_{date_obj.strftime('%Y%m%d')}"
    else:
        flnm = f"conc_zero_referenced_stats_{config.variables.report_time_average.value}_{date_obj.strftime('%Y%m%d')}"
    conc_stats_df.to_csv(config.paths.output_path / f"{flnm}.csv")

def collect_max_and_corr(
        ave_ds: xr.Dataset, 
        compound_list: List[str], 
        tvoc_var: str, 
        tvoc_zero: float = 0, 
        ch4_zero: float = 2, 
        lod_df: pd.DataFrame = None
        ):
    df = pd.DataFrame(
        index = compound_list, 
        columns = [
            'max_conc', 
            'max_conc_ppbC', 
            'tvoc_corr_slope', 
            'tvoc_corr_offset', 
            'tvoc_corr_r2', 
            'ch4_corr_slope', 
            'ch4_corr_offset', 
            'ch4_corr_r2', 
            'mean_conc', 
            'mean_conc_ppbC',
            'error'
            ]
        )

    ds_now = ave_ds.dropna('_datetime', how='all')
    tvoc_corr_vector = ds_now.sel(fitter_var = tvoc_var).fitter_values * TVOC_SCALE - tvoc_zero
    ch4_corr_vector = ds_now.sel(fitter_var = 'CH4').fitter_values - ch4_zero
    for var_name in compound_list:
        data_vector = ds_now.sel(fitter_var=var_name).fitter_values.values

        if lod_df is not None:
            # add std from lod_df
            new_ave_time_s = int((ds_now._datetime[-1] - ds_now._datetime[0]).values / 1e9)
            scaling_factor = np.sqrt(4/new_ave_time_s)
            lod_df_now = lod_df['fitter_values'] * scaling_factor
        
        df.loc[var_name,'max_conc'] = np.nanmax(data_vector)
        df.loc[var_name,'mean_conc'] = np.nanmean(data_vector)
        if var_name in ALKANE_SCALING_FACTORS:
            df.loc[var_name,'max_conc_ppbC'] = df.loc[var_name]['max_conc'] * ALKANE_SCALING_FACTORS[var_name]
            df.loc[var_name,'mean_conc_ppbC'] = df.loc[var_name]['mean_conc'] * ALKANE_SCALING_FACTORS[var_name]
        
        if np.any(tvoc_corr_vector.notnull()):
            params = np.polyfit(tvoc_corr_vector, data_vector, 1)

            r2 = r2_score(data_vector, np.polyval(params, tvoc_corr_vector))

            df.loc[var_name,'tvoc_corr_slope'] = params[0]
            df.loc[var_name,'tvoc_corr_offset'] = params[1]
            df.loc[var_name,'tvoc_corr_r2'] = r2
        else:
            df.loc[var_name,'tvoc_corr_slope'] = np.nan
            df.loc[var_name,'tvoc_corr_offset'] = np.nan
            df.loc[var_name,'tvoc_corr_r2'] = np.nan

        params = np.polyfit(ch4_corr_vector, data_vector, 1)

        r2 = r2_score(data_vector, np.polyval(params, ch4_corr_vector))

        df.loc[var_name,'ch4_corr_slope'] = params[0]
        df.loc[var_name,'ch4_corr_offset'] = params[1]
        df.loc[var_name,'ch4_corr_r2'] = r2

        if lod_df is not None:
            if var_name in lod_df_now:
                df.loc[var_name, 'error'] = lod_df_now[var_name]
        
    return df

def collect_mean_and_corr(
        ave_ds: xr.Dataset, 
        compound_list: List[str], 
        tvoc_var: str, 
        tvoc_zero: float = 0, 
        ch4_zero: float = 2
        ):
    df = pd.DataFrame(
        index = compound_list, 
        columns = [
            'tvoc_corr_slope', 
            'tvoc_corr_offset', 
            'tvoc_corr_r2', 
            'ch4_corr_slope', 
            'ch4_corr_offset', 
            'ch4_corr_r2', 
            'mean_conc', 
            'mean_conc_ppbC',
            ]
        )

    ds_now = ave_ds.dropna('_datetime', how='all')
    tvoc_corr_vector = ds_now.sel(fitter_var = tvoc_var).fitter_values * TVOC_SCALE - tvoc_zero
    ch4_corr_vector = ds_now.sel(fitter_var = 'CH4').fitter_values - ch4_zero
    for var_name in compound_list:
        data_vector = ds_now.sel(fitter_var=var_name).fitter_values.values

        
        df.loc[var_name,'mean_conc'] = np.nanmean(data_vector)
        if var_name in ALKANE_SCALING_FACTORS:
            df.loc[var_name,'mean_conc_ppbC'] = df.loc[var_name]['mean_conc'] * ALKANE_SCALING_FACTORS[var_name]
        
        if np.any(tvoc_corr_vector.notnull()):
            params = np.polyfit(tvoc_corr_vector, data_vector, 1)

            r2 = r2_score(data_vector, np.polyval(params, tvoc_corr_vector))

            df.loc[var_name,'tvoc_corr_slope'] = params[0]
            df.loc[var_name,'tvoc_corr_offset'] = params[1]
            df.loc[var_name,'tvoc_corr_r2'] = r2
        else:
            df.loc[var_name,'tvoc_corr_slope'] = np.nan
            df.loc[var_name,'tvoc_corr_offset'] = np.nan
            df.loc[var_name,'tvoc_corr_r2'] = np.nan
        try:
            params = np.polyfit(ch4_corr_vector, data_vector, 1)

            r2 = r2_score(data_vector, np.polyval(params, ch4_corr_vector))

            df.loc[var_name,'ch4_corr_slope'] = params[0]
            df.loc[var_name,'ch4_corr_offset'] = params[1]
            df.loc[var_name,'ch4_corr_r2'] = r2
        except:
            df.loc[var_name,'ch4_corr_slope'] = 0
            df.loc[var_name,'ch4_corr_offset'] = 0
            df.loc[var_name,'ch4_corr_r2'] = 0
        
    return df

def circ_stats(wind_ds: xr.Dataset): 
    wind_direction = wind_ds.sel(parameter = 'SWD').ts_value 
    rad_wd = np.deg2rad(wind_direction)
    mean_wd = np.rad2deg(circmean(rad_wd, nan_policy='omit'))
    std_wd = np.rad2deg(circstd(rad_wd, nan_policy='omit'))
    ds = xr.Dataset(
        data_vars = dict(
            ts_value = (['parameter', 'stat'], np.array((mean_wd, std_wd))[np.newaxis,:]) 
        ),
        coords = dict(
            parameter = ['SWD'],
            stat = ['mean', 'std']
        ),

    )

    return ds

def get_diurnal_concs(
        ave_ds: xr.Dataset, 
        diurnal_averaging
        ):
    time_vector = np.arange(0, 24 + diurnal_averaging / 60 / 2, diurnal_averaging / 60)

    # bin average data to diurnal averaging interval
    frac_hours = ave_ds._datetime.dt.hour + ave_ds._datetime.dt.minute / 60 + ave_ds._datetime.dt.second / 60 / 60

    gb_obj = ave_ds.copy().groupby_bins(frac_hours, bins=time_vector, labels=time_vector[:-1]+diurnal_averaging / 60 / 2)

    weighted_median_ds = gb_obj.apply(weighted_quantile, q = 0.5)
    weighted_25_ds = gb_obj.apply(weighted_quantile, q = 0.25)
    weighted_75_ds = gb_obj.apply(weighted_quantile, q = 0.75)
    npoints_ds = gb_obj.count()
    diurnal_quant_ds = xr.concat([weighted_median_ds, weighted_25_ds, weighted_75_ds], dim='quantile')
    diurnal_quant_ds = diurnal_quant_ds.rename({'group_bins': 'time'})

    return diurnal_quant_ds, npoints_ds


def get_diurnal_wind(
        wind_ds: xr.Dataset, 
        diurnal_averaging
        ):
    time_vector = np.arange(0, 24 + diurnal_averaging / 60 / 2, diurnal_averaging / 60)

    # bin wind data to diurnal averaging interval
    frac_hours = wind_ds._datetime.dt.hour + wind_ds._datetime.dt.minute / 60 + wind_ds._datetime.dt.second / 60 / 60

    wind_gb_obj = wind_ds.groupby_bins(frac_hours, bins=time_vector, labels=time_vector[:-1]+diurnal_averaging / 60 / 2)

    wind_speed_weighted_ave_ds = wind_gb_obj.mean(skipna=True).sel(parameter = 'SWS')
    wind_speed_weighted_std_ds = wind_gb_obj.std(skipna=True).sel(parameter = 'SWS')

    wind_speed_weighted_ds = xr.concat([wind_speed_weighted_ave_ds, wind_speed_weighted_std_ds], dim='stat').assign_coords(stat=['mean','std'])

    wind_direction_weighted_ds = wind_gb_obj.apply(circ_stats)

    wind_dirunal_ds = xr.concat([
        wind_speed_weighted_ds, 
        wind_direction_weighted_ds
        ], 
        dim = 'parameter'
    ).rename({'group_bins': 'time'}) 

    return wind_dirunal_ds


def trim_times(
        ds: xr.Dataset,
        config: configYaml
        ):
    # # Subselect portion of data based on time 
    # # https://docs.xarray.dev/en/latest/user-guide/indexing.html
    time_ds = ds.sel(_datetime=slice(config.times.expt_start, config.times.expt_end))

    for time_now in config.data_to_drop:
        time_ds = time_ds.where((time_ds._datetime<np.datetime64(time_now.start)) | (time_ds._datetime>np.datetime64(time_now.end)), drop=True)

    return time_ds

def non_valve_trigger(
        time_ds: xr.Dataset, 
        var_group: str, 
        config: configYaml
        ):
    if var_group == 'private':
        ds = time_ds.drop_vars(['fitter_var', 'fitter_values'])

        if 'fitter_var' in ds.sel(private_var = 'CH4_VOC').private_values.dims:
            ds = ds.isel(fitter_var = 0)
    elif var_group == 'fitter' and 'private_var' in time_ds.coords:
        ds = time_ds.drop_vars(['private_var', 'private_values'])
    else:
        ds = time_ds


    species_df = ds.sel(
        {f'{var_group}_var': [config.valve_info.valve_var, config.variables.tvoc_var]}
    )[f'{var_group}_values'].to_pandas()
    
    species_df = species_df.drop(columns=config.variables.tvoc_var).dropna()

    
    # Cluster data to reference vs not reference
    timeseries_df = species_df.copy(deep=True)
    timeseries_df = timeseries_df.reset_index()
    timeseries_df["_datetime"] = timeseries_df["_datetime"].values.astype(int)

    clusters = get_clusters(
        timeseries_df,
        eps=config.steps.clustering_eps, 
        min_samples=config.steps.min_clustering_samples, 
    )

    clusters.index = species_df.index

    # Remove outliers
    updated_clusters = clusters[clusters != -1]

    med_list = []
    for i in np.unique(updated_clusters): 
        med_list.append(timeseries_df.loc[np.where(updated_clusters==i)[0], config.valve_info.valve_var].median())

    middle = np.mean(np.array(med_list))
    
    timeseries_df.set_index(pd.to_datetime(timeseries_df['_datetime']), inplace=True)

    data = np.zeros(len(updated_clusters))
    data[timeseries_df.loc[updated_clusters.index].iloc[:, 1] > middle] = 1

    new_binary_grouping = pd.DataFrame(index = updated_clusters.index, data = data)

    return new_binary_grouping[0]
        

def add_non_valve_trigger(
        time_ds: xr.Dataset, 
        new_group, 
        config: configYaml,
        var_group: str = 'fitter'
        ):
    # Drop transitions from original structure
    time_ds = time_ds.sel(_datetime=new_group.index.values)

    if var_group == 'private':
        new_private_values = np.hstack((time_ds.private_values, new_group.astype(int).to_numpy()[:, np.newaxis]))
        new_private_var = list(time_ds.private_var.values) + ['group']

        if config.variables.tvoc_var not in time_ds.fitter_var and config.variables.tvoc_var in time_ds.private_var:
            new_fitter_values = np.hstack((new_fitter_values, time_ds.sel(private_var = config.variables.tvoc_var).private_values.values[:, np.newaxis]))
            new_fitter_var = new_fitter_var + [config.variables.tvoc_var]


        grouped_ds = xr.Dataset(
            data_vars = dict(
                fitter_values = (['_datetime', 'fitter_var'], new_fitter_values),
                private_values = (['_datetime', 'private_var'], new_private_values),
                spectral_values = time_ds.spectral_values,
            ),
            coords = dict(
                _datetime = time_ds._datetime,
                fitter_var = new_fitter_var,
                private_var = new_private_var,
                mode = time_ds.mode,
                spectral_var = time_ds.spectral_var,
            ),
            attrs = time_ds.attrs
        )
    elif var_group == 'fitter':
        new_fitter_values = np.hstack((time_ds.fitter_values, new_group.astype(int).to_numpy()[:, np.newaxis]))
        new_fitter_var = list(time_ds.fitter_var.values) + ['group']

        grouped_ds = xr.Dataset(
            data_vars = dict(
                fitter_values = (['_datetime', 'fitter_var'], new_fitter_values),
                spectral_values = time_ds.spectral_values,
            ),
            coords = dict(
                _datetime = time_ds._datetime,
                fitter_var = new_fitter_var,
                mode = time_ds.mode,
                spectral_var = time_ds.spectral_var,
            ),
            attrs = time_ds.attrs
        )
    
    else:
        grouped_ds = None
    return grouped_ds


def create_port_split_ds(ds, valve_var, species = None):
    port_split_ds = ds.expand_dims(dim={'port': np.unique(ds.sel(fitter_var = valve_var).fitter_values.values)}, axis=-1)
    ds.close()

    _values = port_split_ds.fitter_values.copy().values
    for iport, port in enumerate(port_split_ds.port.values):
        ind_now = np.where(port_split_ds.sel(fitter_var = valve_var, port = port).fitter_values.values!=port)[0]
        _values[ind_now, :, iport] = np.nan
    port_split_ds['fitter_values'] = (['_datetime','fitter_var','port'], _values)

    if species is not None:
        port_split_ds = port_split_ds.assign_coords(
            species_var = ['all', 'matrix']
        )

        port_split_ds = port_split_ds.assign(
            species = species
        )

    return port_split_ds


def create_port_split_ds(ds, valve_var, species = None):
    port_split_ds = ds.expand_dims(dim={'port': np.unique(ds.sel(fitter_var = valve_var).fitter_values.values)}, axis=-1)
    ds.close()

    _values = port_split_ds.fitter_values.copy().values
    for iport, port in enumerate(port_split_ds.port.values):
        ind_now = np.where(port_split_ds.sel(fitter_var = valve_var, port = port).fitter_values.values!=port)[0]
        _values[ind_now, :, iport] = np.nan
    port_split_ds['fitter_values'] = (['_datetime','fitter_var','port'], _values)

    if species is not None:
        port_split_ds = port_split_ds.assign_coords(
            species_var = ['all', 'matrix']
        )

        port_split_ds = port_split_ds.assign(
            species = species
        )

    return port_split_ds
