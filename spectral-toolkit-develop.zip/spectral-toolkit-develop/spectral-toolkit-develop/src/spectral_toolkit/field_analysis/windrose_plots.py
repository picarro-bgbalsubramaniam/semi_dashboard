import xarray as xr
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from typing import List

from spectral_toolkit.field_analysis.field_utilities import TVOC_SCALE, ACTION_LIMITS


def plot_windrose_subplot(
    fig, 
    df: pd.DataFrame, 
    strength_name: str = 'wind_speed', 
    row: int = 1, 
    col: int = 1, 
    cb_len: float = 1, 
    cb_y_loc: float = 0,
    cb_x_loc: float = 1
    ):
    color_data = df[strength_name]

    fig.add_trace(
            go.Barpolar(
                r=df['npoints'],
                theta=df['wind_direction'],

                marker=dict(
                    cmin=0,
                    cmax=np.nanmax(color_data) * 1.1,
                    color = color_data,
                    colorbar=dict(
                        len=cb_len,
                        lenmode='fraction',
                        x=cb_x_loc,
                        y=cb_y_loc,
                    ),
                    colorscale = px.colors.sequential.Plasma_r,
                ),
                showlegend=False,
            ), 
        row=row,
        col=col
    )
    
    return fig

def wind_rose(
    fig, 
    wind_direction_data: np.array, 
    strength_data: np.array, 
    strength_name: str = 'SWS', 
    row: int = 1, 
    col: int = 1, 
    cb_len: float = 1, 
    cb_y_loc: float = 0,
    cb_x_loc: float = 1
    ):
    if np.nanmax(strength_data)>0:
        wind_bin, xedges, yedges = np.histogram2d(
            wind_direction_data, 
            strength_data, 
            bins=[16, 10], 
            range = [[0, 360],[0, np.nanmax(strength_data)]])

        data = np.vstack((
                    wind_bin.flatten(), 
                    np.tile(xedges[:-1, np.newaxis], (1, len(yedges)-1)).flatten(), 
                    np.tile(yedges[:-1], (len(xedges)-1))
                )).T
                
        df = pd.DataFrame(
            data = data,
            columns=['npoints', 'wind_direction',strength_name]
            )

        fig = plot_windrose_subplot(fig, df, strength_name=strength_name, row=row, col=col, cb_len=cb_len, cb_y_loc=cb_y_loc, cb_x_loc=cb_x_loc)

        return df, fig
    else:
        df = pd.DataFrame(columns = ['npoints', 'wind_direction',strength_name])
        return df, fig
    
def timeseries_with_windrose(
    ds: xr.Dataset, 
    tvoc_var: str = 'partial_fit_integral', 
    compound_list: List[str] = ['CH4','Ethane'], 
    add_limits: bool = True,
    mark_above_limit: bool = False, 
    lod_df: pd.DataFrame = None, 
    mark_above_lod: bool = False
    ):
    '''
    Plot timeseries for a set of compounds with windrose

    ds: xarray
        xarray dataset with coordinates _datetime, fitter_var, port, other (concs, wind) and data fitter_values
        The data must contain tvoc proxy, concentration, swd (wind direction), and sws (wind speed)
    tvoc_var: str
        string name of the variable in the ds dataset that is the tvoc proxy value
    compound_list: List[str]
        list of string names of compounds to be plotted
    add_limits: bool
        boolean indicating if the regulatory limits should be plotted
    mark_above_limit: bool
        boolean indicating if the data above the regulatory limit should be highlighted
    lod_df: pandas dataframe
        pandas dataframe containing the limit of detection for any of the compounds to be ploted    
    mark_above_lod: bool
        boolean indication if the data above the LOD should be highlighted
    '''
    swd = ds.sel(parameter='SWD', other='wind').ts_value #wind direction
    sws = ds.sel(parameter='SWS', other='wind').ts_value #wind speed
    
    rows_no = 1 + len(compound_list) + 2
    offset = 1 / (rows_no * 4)
    cb_len = (1 - offset * (rows_no+1))/ rows_no
    cb_locs = np.arange(start = cb_len, stop = 1, step = offset + cb_len)[::-1]
    cols_no = 2

    specs = []
    for row in range(rows_no):
        row_specs = []
        for col in range(cols_no):
            if col == 0:
                row_specs.append({}) #({'type': 'xy'})
            else:
                row_specs.append({'type': 'polar'})
        specs.append(row_specs)

    # Set up the subplot
    fig = make_subplots(
        rows=rows_no,
        cols=cols_no,
        horizontal_spacing=0.04,
        vertical_spacing=0.03,
        specs=specs,
        column_widths=[0.8, 0.2]
    )
    
    conc_bool = (ds.sel(other='concs').fitter_values.isnull().sum('fitter_var') < len(ds.fitter_var)).compute()
    conc_ds = ds.sel(other='concs').isel(_datetime=conc_bool)

    fig.add_trace(
        go.Scattergl(
            x=conc_ds._datetime,
            y=conc_ds.sel(fitter_var=tvoc_var).fitter_values.values * TVOC_SCALE,
            mode="markers",
            marker_color='grey',
            name='tvoc',
            opacity=0.2,
            showlegend=False,
        ),
        row=1,
        col=1,
    )

    
    # plot tvoc windrose
    df, fig = wind_rose(
        fig, 
        swd.isel(_datetime=conc_bool).values, 
        conc_ds.sel(fitter_var=tvoc_var).fitter_values.values * TVOC_SCALE, 
        strength_name='TVOC', 
        row=1, 
        col=2,
        cb_len=cb_len, 
        cb_y_loc=cb_locs[0],
        )

    for i, var_name in enumerate(compound_list):
        data_vector = conc_ds.sel(fitter_var=var_name).fitter_values.values
        fig.add_trace(
            go.Scattergl(
                x=conc_ds._datetime,
                y=data_vector,
                mode="markers",
                marker_color='grey',
                name=var_name,  
                opacity=0.2,
                showlegend=False,
            ),
            row=i+2,
            col=1,
        )

        data_min = np.nanmin(data_vector)
        data_max = np.nanmax(data_vector)
        update_bool = False
        if add_limits and var_name in ACTION_LIMITS:
            fig.add_trace(
                go.Scatter(
                    x=conc_ds._datetime, 
                    y=np.ones(len(conc_ds._datetime))*ACTION_LIMITS[var_name],
                    mode="lines",
                    line = dict(
                        color = 'red',
                        dash='dot',
                    ),
                    name=var_name,  
                    # opacity=0.5,
                    showlegend=False,
                ),
                row=i+2,
                col=1,
            )

            
            data_max = np.max((data_max, ACTION_LIMITS[var_name]))
            update_bool = True

            if mark_above_limit:
                fig.add_trace(
                    go.Scatter(
                        x=conc_ds._datetime[data_vector > ACTION_LIMITS[var_name]],
                        y=data_vector[data_vector > ACTION_LIMITS[var_name]],
                        mode='markers',
                        marker=dict(
                            symbol='circle',
                            color='pink',
                        ),
                        name=var_name,  
                        # opacity=0.5,
                        showlegend=False,
                    ),
                    row=i+2,
                    col=1,
                )

        if lod_df is not None:
            if var_name in lod_df:
                fig.add_trace(
                    go.Scatter(
                        x=conc_ds._datetime, 
                        y=np.ones(len(conc_ds._datetime))*lod_df[var_name]*2, #6 sigma
                        mode="lines",
                        line = dict(
                            color = 'blue',
                            dash='dot',
                        ),
                        name=var_name,  
                        # opacity=0.5,
                        showlegend=False,
                    ),
                    row=i+2,
                    col=1,
                )

                fig.add_trace(
                    go.Scatter(
                        x=conc_ds._datetime, 
                        y=np.ones(len(conc_ds._datetime))*lod_df[var_name]*3,
                        mode="lines",
                        line = dict(
                            color = 'lightsteelblue',
                            dash='dot',
                        ),
                        name=var_name,  
                        # opacity=0.5,
                        showlegend=False,
                    ),
                    row=i+2,
                    col=1,
                )


                data_max = np.max((data_max, lod_df[var_name]*3))
                update_bool = True

                if mark_above_lod:
                    fig.add_trace(
                        go.Scatter(
                            x=conc_ds._datetime[data_vector > lod_df[var_name]*2], #6 sigma
                            y=data_vector[data_vector > lod_df[var_name]*2], #6 sigma
                            mode='markers',
                            marker=dict(
                                symbol='circle',
                                color='green',
                            ),
                            name=var_name,  
                            showlegend=False,
                        ),
                        row=i+2,
                        col=1,
                    )

        if update_bool:
            data_range = data_max - data_min

            fig.update_yaxes(
                range = [data_min - 0.05*data_range, data_max + 0.05*data_range], 
                row=i+2, 
                col=1
                )
        
        # plot windrose
        df, fig = wind_rose(
            fig, 
            swd.isel(_datetime=conc_bool).values, 
            conc_ds.sel(fitter_var=var_name).fitter_values.values, 
            strength_name=var_name, 
            row=i+2, 
            col=2, 
            cb_len=cb_len, 
            cb_y_loc=cb_locs[i+1],
            )

    for i, (var, var_name) in enumerate([('SWD', 'wind direction'),('SWS', 'wind speed')]): #wind speed, wind direction
        fig.add_trace(
            go.Scattergl(
                x=ds._datetime,
                y=ds.sel(parameter=var, other='wind').ts_value,
                mode="markers",
                marker_color='green',
                name=var_name,
                showlegend=False,
                opacity=0.5,
            ),
            row=i+2+len(compound_list),
            col=1,
        )

        if i == 0:
            df, fig = wind_rose(
                fig, 
                swd.values, 
                sws.values, 
                strength_name='SWS', 
                row=i+2+len(compound_list), 
                col=2, 
                cb_len=cb_len, 
                cb_y_loc=cb_locs[i+1+len(compound_list)]
                )

    
    fig.update_yaxes(title_text='TVOC (ppb equiv. IPA)', type="linear", row=1, col=1)
    for i, var_name in enumerate(compound_list):
        if var_name in ['CO2','CH4']:
            fig.update_yaxes(title_text=f'{var_name} (ppm)', type="linear", row=i+2, col=1)
        elif var_name == 'H2O':
            fig.update_yaxes(title_text=f'{var_name} (%)', type="linear", row=i+2, col=1)
        else:
            fig.update_yaxes(title_text=f'{var_name} (ppb)', type="linear", row=i+2, col=1)
    
    fig.update_yaxes(title_text='Wind Direction', row=2+len(compound_list), col=1)
    fig.update_yaxes(title_text='Wind Speed', row=3+len(compound_list), col=1)

    return fig

def wind_rose_from_ds(fig, ds, wind_direction_name='SWD', strength_name='SWS', row=1, col=1):
    if 'other' in ds.coords:
        swd = ds.sel(parameter=wind_direction_name, other='wind').ts_value.values #wind direction
    else:
        swd = ds.sel(parameter=wind_direction_name).ts_value.values #wind direction

    if strength_name in ds.parameter:
        if 'other' in ds.coords:
            sws = ds.sel(parameter=strength_name, other='wind').ts_value.values #wind speed
        else:
            sws = ds.sel(parameter=strength_name).ts_value.values #wind speed
    elif strength_name in ds.fitter_var:
        sws = ds.sel(fitter_var=strength_name, other='concs').fitter_values.values #concentration

    return wind_rose(fig, swd, sws, strength_name=strength_name, row=row, col=col)

