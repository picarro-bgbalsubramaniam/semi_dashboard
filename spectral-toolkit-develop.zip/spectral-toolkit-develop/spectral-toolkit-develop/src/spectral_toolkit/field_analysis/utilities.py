import numpy as np
import pandas as pd

def get_Q_prob(Q,N,extend_to_Q_below_1=True):
    """args: 
      Q: Q for a given compound in a fit results 
      N: total number of compounds found 
      returns the probability that the found compound was really in the gas sample
      Valid for R3 (running four steps where the Q threshold is lowered with each step)"""
    N = np.clip(N, 1, 55)
    if extend_to_Q_below_1:
        lowQ = np.ones(Q.shape)
        lowQ[Q<1] = Q[Q<1]
        Q = np.clip(Q, 1, np.inf)
    else:
        print('Q less than 1 not allowed')
        return None
    A = 0.31407 + 0.202362 / N  - 0.00858516 * N + 0.000113417 * N**2
    B = 3.20283 - 0.0432235 * N + 0.00115416 * N**2
    C = 2.11314 - 0.0687511 * N + 0.000622635 * N**2
    rho = -B * (np.log10(Q - 1) + C)
    f = A + (1 - A) / (1 + np.exp(rho))
    if extend_to_Q_below_1:
        f = lowQ*f



# -*- coding: utf-8 -*-
"""
Created on Wed May 03 14:30:39 2017

@author: chris
"""

import colorsys
import numpy as np
# import matplotlib.pyplot as plt
import random

"""
https://computergraphics.stackexchange.com/questions/1748/function-to-convert-hsv-angle-to-ryb-angle
piecewise linear transformation
RYBstop HSVstop
60      35
122     60
165     120
218     180
275     240s
330     300
"""
def convert_to_hex(color_tuple):
    out = '#'
    for rgba in color_tuple:
        out += '%02x' % int(round((rgba*255) % 256))
    return out

class NaomiKuno(object):
    def __init__(self, brtValue=0.0):
        self.setup()
        self.count = None
        self.brtValue = brtValue
        self.createTable()
    
    def setup(self):
        self.name = 'Default'
        self.page = -1
        self.N = -1
        self.sourceColors = []
        
    def normalizeBookRGB(self, RGB):
        return tuple([x/255. for x in RGB])

    def createTable(self):
        self.colors = []
        for source in self.sourceColors:
            self.colors.append(self.adjustBrightness(self.normalizeBookRGB(source), self.brtValue))
        self.NC = len(self.colors)

    def getColor(self):
        self.count = self.count % self.NC
        return convert_to_hex(self.colors[self.count])

    def randomize(self, seed = None):
        if seed:
            random.seed(seed)
        random.shuffle(self.colors)
    
    def make_long(self, brt_list = [0, +0.35, -0.35]):
        self.colors = []
        for brt in brt_list:
            for source in self.sourceColors:
                self.colors.append(self.adjustBrightness(self.normalizeBookRGB(source), brt))
        self.NC = len(self.colors)
        
    def getNext(self):
        if self.count == None:
            self.count = 0
        else:
            self.count += 1    
        return self.getColor()
    
    def getCurrent(self):
        if self.count == None:
            self.count = 0 
        return self.getColor()

    def resetCycle(self):
        self.count = None
        
    def __getitem__ (self, i):
        return convert_to_hex(self.colors[i % self.NC])   

    def adjustBrightness(self, rgb, brt):
        """brt = +1 (goes to white) to -1 (goes to black)"""
        h, s, v = colorsys.rgb_to_hsv(*rgb)
        if brt < 0:
            v = v*(1 + brt) 
        elif brt > 0:
            spn = s + (1 - v)
            if brt*spn <= 1 - v:
                v += brt*spn
            else:                
                s -= brt*spn - (1 - v)
                v = 1.0
        return colorsys.hsv_to_rgb(h, s, v)
    
    def adjustColorTableBrightness(self, brt):
        self.brtValue = brt
        self.createTable()
        
    def demo (self):
        import seaborn as sns
        sz = 1 if len(self.colors) < 10 else 0.5
        sns.palplot([self.colors[j] for j in range(self.NC)], size=sz)

class CuteNordicKnit(NaomiKuno):
    def setup(self):
        self.name = 'CuteNordicKnit'
        self.page = 48
        self.N = 20
        
        self.sourceColors =   [(174, 218, 238),
                               (159, 157, 65), 
                               (244, 159, 58),
                               (237, 121, 139),
                               (104, 69, 99),
                               (219, 60, 53),
                               (229, 157, 161),
                               (248, 191, 136),
                               (133, 79, 63)]

class PsychedelicChakra(NaomiKuno):
    def setup(self):
        self.name = 'PsychedelicChakra'
        self.page = 72
        self.N = 31
        self.order = [0,4,1,5,2,6,3,7]
        self.sourceColors =   [(0, 163, 209),
                               (73, 108, 165), 
                               (134, 76, 148),
                               (0, 173, 174),
                               (236, 121, 33), 
                               (232, 66, 27),
                               (91, 182, 71),
                               (229, 230, 48)]
        self.sourceColors = [self.sourceColors[k] for k in self.order]

class GobelinTapestry(NaomiKuno):
    def setup(self):
        self.name = 'GobelinTapestry'
        self.page = 192
        self.N = 87
        self.order = [0,3,1,5,7,2,6,8,4]
        self.sourceColors =   [(171,106,105), 
                               (125,127,55),
                               (212,201,166),
                               (28,88,119),
                               (159,192,201),
                               (111,131,143),
                               (136, 59,61),
                               (69,71,32),
                               (210,186,123)]
        self.sourceColors = [self.sourceColors[k] for k in self.order]
        
class KawaiiPunchyCute(NaomiKuno):
    def setup(self):
        self.name = 'KawaiiPunchyCute'
        self.page = 64
        self.N = 27
        self.order = [0,4,1,5,2,6,8,7,3]
        self.sourceColors = [(222,46,139),
                             (86,93,168),
                             (238,126,124),
                             (255,255,0),
                             (0,182,221),
                             (124,189, 39),
                             (192,125,178),
                             (142,209,230),
                             (226,2,33)]
        self.sourceColors = [self.sourceColors[k] for k in self.order]

class SeventiesFunk(NaomiKuno):
    def setup(self):
        self.name = 'SeventiesFunk'
        self.page = 64
        self.N = 27
        self.order = [0,4,1,5,2,6,7,3]
        self.sourceColors = [(205,17,50),
                             (112,55,126),
                             (214,113,47),
                             (231,185,32),
                             (24,88,139),
                             (117,79,58),
                             (144,185,33),
                             (0,121,117)]
        self.sourceColors = [self.sourceColors[k] for k in self.order]


class NewColors1(NaomiKuno):
    def setup(self):
        self.name = 'NewColors1'
        # self.order = [0,4,1,5,2,6,8,7,3]
        self.sourceColors = [
                            (148,243,235), 
                            (53,136,209), 
                            (224,132,133), 
                            (164,20,21),
                            (253,89,37), 
                            (112,73,59), 
                            (106,144,18), 
                            (63,173,175), 
                            (124,98,222), 
                            (21,73,117), 
                            (240,192,70), 
                            (1,45,3), 
                            (55,196,84), 
                            (34,106,77), 
                            (194,223,125), 
                            (11,8,98), 
                            (202,211,250), 
                            (145,145,145), 
                            (240,155,241), 
                            (144,40,107), 
                            (222,12,163), 
                            (168,65,240), 
                            (21,14,24), 
                            (192,113,12), 
                            (43,0,194), 
                            (232,253,24)
                            ]

        # self.sourceColors = [self.sourceColors[k] for k in self.order]

class NewColors2(NaomiKuno):
    def setup(self):
        self.name = 'NewColors2'
        # self.order = [0,4,1,5,2,6,8,7,3]
        self.sourceColors = [(112,122,228), (100,212,253), (10,67,59), (117,234,182), (45,22,0), (8,132,144), (43,3,118), (255,152,204), (181,60,125), (204,193,226), (120,101,115), (99,129,35), (49,166,46), (209,31,11), (234,152,90), (160,88,28), (103,5,1), (227,198,11), (160,232,91), (155,62,200), (11,45,108), (219,233,168), (255,0,135), (9,245,76), (37,36,249), (250,43,235)]

        # self.sourceColors = [self.sourceColors[k] for k in self.order]

class NewColors3(NaomiKuno):
    def setup(self):
        self.name = 'NewColors3'
        # self.order = [0,4,1,5,2,6,8,7,3]
        self.sourceColors = [(53,136,209), (44,8,69), (193,134,230), (108,54,163), (69,222,178), (17,94,65), (138,225,249), (38,73,109), (193,194,245), (142,46,92), (117,154,118), (149,184,51), (118,72,13), (248,186,124), (65,0,2), (239,93,138), (241,67,48), (252,209,7), (5,19,17), (139,253,91), (55,181,31), (97,8,232)]

        # self.sourceColors = [self.sourceColors[k] for k in self.order]

class NewColors4(NaomiKuno):
    def setup(self):
        self.name = 'NewColors4'
        # self.order = [0,4,1,5,2,6,8,7,3]
        self.sourceColors = [(175,219,238), (158,157,65), (243,157,56), (238,122,140), (103,69,99), (219,59,53), (229,158,161), (248,190,134), (132,78,62), (29,54,33), (188,224,145), (101,139,251), (27,77,171), (36,153,215), (29,134,109), (250,229,55), (214,120,239), (162,47,128), (38,205,202), (55,136,17), (28,0,98), (179,230,28), (118,59,203), (55,9,35), (111,237,143), (246,18,168)]

        # self.sourceColors = [self.sourceColors[k] for k in self.order]

class NewColors5(NaomiKuno):
    def setup(self):
        self.name = 'NewColors5'
        # self.order = [0,4,1,5,2,6,8,7,3]
        self.sourceColors = [(175,219,238), (158,157,65), (243,157,56), (238,122,140), (103,69,99), (219,59,53), (229,158,161), (248,190,134), (132,78,62), (161,148,220), (69,83,194), (77,156,170), (123,3,142), (15,179,129), (241,231,54), (75,164,11), (2,83,29), (227,250,172), (5,19,17), (220,139,254), (28,88,114), (59,8,13), (168,249,79), (28,11,83), (104,251,206), (251,9,152)]

        # self.sourceColors = [self.sourceColors[k] for k in self.order]


def get_transition_df_from_csv(path, index_col='step_id'):
    df = pd.read_csv(path)
    df.set_index(index_col, inplace=True)
    col_list = ['center', 'start', 'end']
    if len(df.columns) > 4:
        col_list = ['center', 'start', 'end', 'zero_start', 'zero_end']
    for col in col_list:
        df[col] = pd.to_datetime(df[col])
    return df

if __name__ == '__main__':
    Test = CuteNordicKnit()
    print(Test.colors)
    
        
def mapcolor(value):
    bins = [0.9999, 0.99, 0.98, 0.97, 0.96, 0.94, 0.92, 0.85]
    kols = ['#ff0000', '#ff8800', '#aaaa00', '#88aa00', '#44aa00', '#00aa00', '#00aa44', '#00aa88']
    # kols = ['red', 'darkorange', 'yellow', 'yellowgreen', 'limegreen', 'forestgreen', 'mediumseagreen', 'mediumaquamarine']
    for j, (bin, kol) in enumerate(zip(bins, kols)):
        if j == 0:
            s = bin
            e = 1
        else:
            s = bin
            e = bins[j-1]
        if s < value <= e:
            return kol


    
        