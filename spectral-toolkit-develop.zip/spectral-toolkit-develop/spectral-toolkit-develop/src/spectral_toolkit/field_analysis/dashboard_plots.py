import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from functools import reduce
from copy import deepcopy
from typing import List, Optional, TypeVar, Tuple
import xarray as xr

from spectral_toolkit.field_analysis.field_utilities import TVOC_SCALE, collect_mean_and_corr
from spectral_toolkit.field_analysis.basic_utilities import error_prop_as
from spectral_toolkit.field_analysis.windrose_plots import wind_rose

import spectral_toolkit.field_analysis.utilities as UT

KOL = UT.CuteNordicKnit(brtValue=0.25)
KOL.make_long(brt_list=[0.25, -0.1])

KOL2 = UT.PsychedelicChakra(brtValue=0.25)
KOL2.make_long(brt_list=[0.25, -0.1])

KOL3 = UT.KawaiiPunchyCute(brtValue=0.25)
KOL3.make_long(brt_list=[0.25, -0.1])

KOL4 = UT.SeventiesFunk(brtValue=0.25)
KOL4.make_long(brt_list=[0.25, -0.1])

pos_values = np.array((0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 
                       0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 
                       1, 2, 3, 4, 5, 6, 7, 8, 9,
                       10, 20, 30, 40, 50, 60, 70, 80, 90,
                       100, 200, 300, 400, 500, 600, 700, 800, 900,
                       1e3, 2e3, 3e3, 4e3, 5e3, 6e3, 7e3, 8e3, 9e3,
                       1e4, 2e4, 3e4, 4e4, 5e4, 6e4, 7e4, 8e4, 9e4,
                       1e5
                       ))
RATIO_OPTIONS = np.concatenate((-pos_values[::-1], pos_values)) 


def plot_alk_collapsed_dashboard(
        ds_now: xr.Dataset, 
        lod_df: pd.DataFrame, 
        specs, 
        loc_dict: dict, 
        var_list: list, 
        all_compounds_list: list, 
        tvoc_var: str = 'partial_fit_integral', 
        top_vars: List = [('partial_fit_integral', 'TVOC')],
        lod_name: float = 2,
        color_dict: dict = None,
        ch4_zero: float = 2,
        ) -> go.Figure:    
    '''
    Plot a field data event dashboard with timeseries, windrose, correlation, and composition information.

    Args:
        ds_now: xarray dataset
            timeseries dataset with _datetime as a coordinate and all of the necessary concentrations and 
            wind data. This dataset must also contain a coordinate (other) that indicates data from either 
            the anemometer (wind) or the instrument (conc).
                ds = xr.concat([
                    conc_ave_ds.sel(fitter_var = ['CO2','CH4','H2O'] + vars_to_save + other_list), 
                    wind_ave_ds.sel(parameter = ['SWD', 'SWS'])
                    ], dim='other').assign_coords(other=['concs','wind'])
            
        lod_df: pandas dataframe
            Dataframe containing the LOD values for a list of compounds. Index must be cid.
        specs:

            specs, loc_dict = get_event_spec_list(top_timeseries_no = len(top_vars)) 

        loc_dict: dictionary

            specs, loc_dict = get_event_spec_list(top_timeseries_no = len(top_vars)) 

        var_list: list of strings
            Variable names of all of the compounds to be included in plots.
            Must be a subset of the all_compounds_list.
            Must be in the ds_now.fitter_var list.

        all_compounds_list: list of strings
            Variable names of all of the compounds in the fit.
            Must be in the ds_now.fitter_var list.

        tvoc_var: string
            Variable name of the TVOC value. Must be the same as the name in the ds_now.fitter_var list.

        top_vars: list of tuples of strings
            List of tuples containing the variable name (as in ds_now.fitter_var) and the variable name
            to be included on the figures (i.e. 'TVOC' or 'Methane (ppm')).
            The first element of each tuple must be in the ds_now.fitter_var list.

            [(config.variables.tvoc_var, 'TVOC'), ('CH4', 'Methane (ppm)')]

        lod_name
        
        color_dict: dictionary
            Dictionary with keys that are a subset of all_compounds_list. Values must be colors that can
            be interpreted by plotly.

        ch4_zero: float value
            Value of the methane zero. This value will be used to accurately calculate the correlation
            between compounds and methane enhancement above the background level.

    Returns:
        plotly figure object
    '''
    if color_dict is None:
        color_dict = dict()
        for i, var_name in enumerate(var_list):
            color_dict.update({var_name: KOL2[i]})

    # Set up the subplot
    fig = make_subplots(
        rows=loc_dict['rows_no'],
        cols=loc_dict['cols_no'],
        horizontal_spacing=0.04,
        vertical_spacing=0.05,
        specs=specs,
        subplot_titles = loc_dict['subplot_titles']
    )

    # plot TVOC timeseries (and other correlation type variables)
    for i,(top_var_name, top_var_axis) in enumerate(top_vars):
        corr_data = ds_now.sel(fitter_var = top_var_name, other='concs').fitter_values 
        if 'TVOC' in top_var_axis:
            corr_data *= TVOC_SCALE
        fig = make_timeseries_subplot(
            fig, 
            ds_now._datetime, 
            corr_data, 
            y_name = top_var_axis,
            update_y_axis = True,
            y_color = 'grey',
            row=i*loc_dict['timeseries_height']+1, 
            col=loc_dict['timeseries_col_start']
            )
    
    # plot compounds of interest timeseries in one subplot
    for i, var_name in enumerate(var_list):
        fig = make_timeseries_subplot(
            fig, 
            ds_now._datetime, 
            ds_now.sel(fitter_var = var_name, other='concs').fitter_values, 
            y_name = 'Concentrations (ppb)' if i == len(var_list) - 1 else None,
            update_y_axis = True if i == len(var_list) - 1 else False,
            y_color = color_dict[var_name],
            row = loc_dict['corr_row_start_list'][-1]+loc_dict['timeseries_height'], 
            col = loc_dict['timeseries_col_start']
            )
    
    # plot wind data timeseries
    for i, (var, var_name, y_range) in enumerate([('SWD', 'Wind Direction', [0, 360]),('SWS', 'Wind Speed', None)]): #wind speed, wind direction
        fig = make_timeseries_subplot(
            fig, 
            ds_now._datetime, 
            ds_now.sel(parameter = var, other='wind').ts_value, 
            y_name = var_name,
            update_y_axis = True,
            y_color = 'grey',
            y_range = y_range,
            tickmode = 'linear' if var == 'SWD' else None, 
            tick0 = 0 if var == 'SWD' else None, 
            dtick = 60 if var == 'SWD' else None,
            row = loc_dict['windrose_timeseries_row_start'] + i*loc_dict['timeseries_height'], 
            col = loc_dict['timeseries_col_start']
            )
    
    # collect mean concentrations and correlations
    # all_compounds_list #without big3
    df = collect_mean_and_corr(
        ds_now.sel(other='concs'), 
        all_compounds_list, 
        tvoc_var,
        tvoc_zero = 0,
        ch4_zero = ch4_zero,
        lod_df = lod_df,
        )
    # df = df.assign(error = lod_df[lod_name].loc[all_compounds_list])

    for i,(corr_var_name, corr_var_axis) in enumerate(top_vars):
        corr_data = ds_now.sel(fitter_var = corr_var_name, other='concs').fitter_values 
        if corr_var_name == 'partial_fit_integral':
            corr_lines = get_bounding_ratios(df['tvoc_corr_slope'].max(), df['tvoc_corr_slope'].min())
        elif corr_var_name == 'CH4':
            corr_lines = get_bounding_ratios(df['ch4_corr_slope'].max(), df['ch4_corr_slope'].min())

        fig = make_correlation_subplots(
            fig, 
            ds_now,
            corr_var_name,
            corr_var_axis,
            var_list,
            color_dict, 
            y_name = None, 
            x_name = corr_var_axis, 
            row=loc_dict['corr_row_start_list'][i], 
            col=loc_dict['correlation_col_start'], 
            corr_lines = corr_lines,
            corr_zero = ch4_zero if corr_var_name == 'CH4' else 0
            )

    # plot wind rose
    offset = 1 / (loc_dict['rows_no'] * 4)
    cb_len = (1 - offset * (loc_dict['rows_no']+1))/ loc_dict['rows_no']
    cb_locs = np.arange(start = cb_len, stop = 1, step = offset + cb_len)[::-1]

    wr_df, fig = wind_rose(
        fig, 
        ds_now.sel(parameter = 'SWD', other='wind').ts_value, 
        ds_now.sel(parameter = 'SWS', other='wind').ts_value, 
        strength_name='SWS', 
        row=loc_dict['windrose_row_start'], 
        col=loc_dict['windrose_col_start'],
        cb_len=cb_len * loc_dict['windrose_height'], 
        cb_y_loc = 2*offset, 
        cb_x_loc = (loc_dict['windrose_col_start'] + loc_dict['windrose_width'])/loc_dict['cols_no'],
        )
    

    # plot pie charts
    columns = ['tvoc_corr_slope', 'ch4_corr_slope', 'error', 'mean_conc']
    total_df = pd.DataFrame(index = ['all', 'subset'], columns = columns)
    for col_now in columns:
        if col_now != 'error':
            total_df.loc['all', col_now] = df[col_now].sum()
            total_df.loc['subset', col_now] = df.loc[var_list][col_now].sum()
    total_df.loc['all','error'] = error_prop_as(df['error'])
    total_df.loc['subset','error'] = error_prop_as(df.loc[var_list]['error'])
    
    subset_plus_names = var_list + ['other']
    df = df.loc[var_list].copy()
    df.loc['other'] = dict(
        tvoc_corr_slope = total_df.loc['all']['tvoc_corr_slope'] - total_df.loc['subset']['tvoc_corr_slope'],
        ch4_corr_slope = total_df.loc['all']['ch4_corr_slope'] - total_df.loc['subset']['ch4_corr_slope'],
        mean_conc = total_df.loc['all']['mean_conc'] - total_df.loc['subset']['mean_conc'],
    )
    
    all_marker_colors = [color_dict[compound] if compound in color_dict else 'grey' for compound in df.index]
    marker_colors = [color_dict[compound] if compound in color_dict else 'grey' for compound in var_list]
    
    col_dict = {
        0: 'tvoc_corr_slope', 
        1: 'ch4_corr_slope', 
        2: 'mean_conc',
    }
    for i_col in range(loc_dict['pie_no']):
        param_name = col_dict[i_col]
        if 'corr_slope' in param_name:
            sub_df = deepcopy(df[param_name].abs())
        else:
            sub_df = deepcopy(df[param_name])
            sub_df[sub_df < 0] = 0

        fig = make_pie_subplot(
            fig, 
            labels = subset_plus_names, 
            values = sub_df.values, 
            var_len = len(subset_plus_names), 
            marker_colors = all_marker_colors,
            row = loc_dict['pie_total_row_start'], 
            col = loc_dict['pie_col_start_list'][i_col]
            )

        # plot subset distribution
        fig = make_pie_subplot(
            fig, 
            labels = var_list, 
            values = sub_df.loc[var_list].values, 
            var_len = len(var_list), 
            marker_colors=marker_colors,
            row = loc_dict['pie_subset_row_start'], 
            col = loc_dict['pie_col_start_list'][i_col]
            )
        
    # Add methane to table data
    df.loc['CH4 enhancement', 'mean_conc'] = np.nanmean(ds_now.sel(fitter_var='CH4').fitter_values.values - ch4_zero) * 1000
    # df.loc['CH4 enhancement', 'error'] = lod_df[lod_name].loc['CH4'] * 1000

    # add table to figure with pie chart values
    # TVOC correlation
    tvoc_corr_data = [f'{i:.2e}' for i in df['tvoc_corr_slope']]
    tvoc_r2_data = [f'{i:.3f}' for i in df['tvoc_corr_r2']]
    tvoc_corr_list = reduce(lambda res, l: res + [l[0] + ', R2=' + l[1]], zip(tvoc_corr_data, tvoc_r2_data), [])

    # CH4 correlation
    ch4_corr_data = [f'{i:.2e}' for i in df['ch4_corr_slope']]
    ch4_r2_data = [f'{i:.3f}' for i in df['ch4_corr_r2']]
    ch4_corr_list = reduce(lambda res, l: res + [l[0] + ', R2=' + l[1]], zip(ch4_corr_data, ch4_r2_data), [])
   
    # mean concentration (ppb)
    mean_conc_value = [f'{i:.2f}' for i in df['mean_conc']]
    ave_s = lod_name * 60
    event_time_s = (ds_now._datetime[-1] - ds_now._datetime[0]).values.astype(float) / 1e9
    mean_conc_error = [f'{i:.1e}' for i in df['error']*np.sqrt(ave_s/event_time_s)]
    mean_conc_list = reduce(lambda res, l: res + [l[0] + ' +- ' + l[1]], zip(mean_conc_value, mean_conc_error), [])
    
    header_values = ['Compound','TVOC Correlation','Methane Correlation','Mean Concentration (ppb)']
    values = [list(df.index), tvoc_corr_list, ch4_corr_list, mean_conc_list]

    fig = add_table_to_fig(
        fig, 
        header_values = header_values, 
        values = values, 
        row = loc_dict['table_row_start'], 
        col = loc_dict['table_col_start']
        )
    
    return fig

def get_event_spec_list(
        top_timeseries_no: int = 2
        ) -> Tuple[list, dict]:
    '''
    Creates the plotly subplot specs and location information for a given event.

    Args:
        top_timeseries_no: int, default 2
            Number of correlation variables to plot as timeseries at the top left of the dashboard.
            All other compounds will be plotted against these variables.
            Typically TVOC and sometimes methane (1 or 2)

    Returns:
        specs: list of lists of dictionaries
            List of variables to define plotly subplot properties.
        loc_dict: dictionary
            loc_dict = dict(
                timeseries_col_start = timeseries_col_start, #column at which the timeseries plots start
                timeseries_row_list = timeseries_row_list, #row at which each timeseries plot start
                pie_total_row_start = pie_total_row_start, #row for total distribution pie charts
                pie_subset_row_start = pie_subset_row_start, #row for subset distribution pie charts
                pie_col_start_list = pie_col_start_list, #column start for the pie charts
                correlation_col_start = correlation_col_start, #column for the correlation plots
                corr_row_start_list = corr_row_start_list, #list of rows for the correlation plots
                windrose_col_start = windrose_col_start, #column for the windrose
                windrose_timeseries_row_start = windrose_timeseries_row_start, #starting row for the windrose timeseries
                windrose_row_start = windrose_row_start, #row for the windrose
                table_col_start = table_col_start, #starting column for the table
                table_row_start = table_row_start, #starting row for the table
                rows_no = rows_no, #number of rows
                cols_no = cols_no, #number of columns
                windrose_height = windrose_height, #height of the windrose (in rows)
                timeseries_height = timeseries_height, #height of the timeseries (in rows)
                correlation_height = correlation_height, #height of the correlation plots (in rows)
                windrose_width = windrose_width, #width of the windrose (in columns)
                pie_no = pie_no, #number of pie chart types
                subplot_titles = subplot_titles #subplot titles
            )
    '''
    # timeseries
    timeseries_col_start = 1
    timeseries_width = 5
    timeseries_height = 2
    analyte_no = 1

    # correlation plots
    correlation_width = 2
    correlation_height = 2

    # pie charts
    pie_rows_no = 2 #number of rows of pie charts (2: total, subset)
    pie_width = 2
    pie_height = 2
    pie_total_row_start = 1
    pie_no = 2
    
    # windrose
    windrose_width = 2
    windrose_height = 2
    windrose_no = 2 #number of windrose timeseries

    # overall size
    rows_no = timeseries_height * (top_timeseries_no + analyte_no + windrose_no) #top comps, analytes, wind
    cols_no = timeseries_width + correlation_width + pie_no * pie_width

    # compile list of rows for timeseries
    timeseries_row_list = []
    for i in range(top_timeseries_no + analyte_no + windrose_no):
        timeseries_row_list.append(i * timeseries_height + 1)

    # define correlation plot location
    correlation_col_start = timeseries_col_start + timeseries_width
    corr_row_start_list = []
    for i in range(2):
        corr_row_start_list.append(i * timeseries_height + 1)

    # define pie chart locations
    pie_subset_row_start = pie_total_row_start + pie_height
    pie_col_start_list = []
    for i in range(pie_no):
        pie_col_start_list.append(correlation_col_start + correlation_width + i * pie_width)
    
    # define windrose location
    windrose_timeseries_row_start = (top_timeseries_no + analyte_no) * timeseries_height + 1
    windrose_col_start = correlation_col_start 
    windrose_row_start = windrose_timeseries_row_start + timeseries_height #plot on the last row
    windrose_cols = np.arange(windrose_width) + windrose_col_start
    windrose_rows = np.arange(windrose_height) + windrose_row_start

    # pie chart data table
    table_col_start = correlation_col_start  
    table_row_start = pie_subset_row_start + pie_height
    table_height = rows_no - pie_height * pie_rows_no - windrose_height
    table_width = pie_width * pie_no + correlation_width

    table_rows = np.arange(table_height) + table_row_start
    table_cols = np.arange(table_width) + table_col_start

    loc_dict = dict(
        timeseries_col_start = timeseries_col_start,
        timeseries_row_list = timeseries_row_list,
        pie_total_row_start = pie_total_row_start,
        pie_subset_row_start = pie_subset_row_start,
        pie_col_start_list = pie_col_start_list,
        correlation_col_start = correlation_col_start,
        corr_row_start_list = corr_row_start_list,
        windrose_col_start = windrose_col_start,
        windrose_timeseries_row_start = windrose_timeseries_row_start,
        windrose_row_start = windrose_row_start,
        table_col_start = table_col_start,
        table_row_start = table_row_start,
        rows_no = rows_no,
        cols_no = cols_no,
        windrose_height = windrose_height,
        timeseries_height = timeseries_height,
        correlation_height = correlation_height,
        windrose_width = windrose_width,
        pie_no = pie_no,

       
    )

    pie_types_list = ['TVOC Correlation','Methane Correlation']
   
    specs = []
    subplot_titles = []
    for row in (np.arange(rows_no) + 1):
        row_specs = []

        for col in (np.arange(cols_no) + 1):
            if col == timeseries_col_start and row % timeseries_height == 1:
                row_specs.append({'rowspan': timeseries_height, 'colspan': timeseries_width}) #timeseries subplots

            elif col == correlation_col_start and row % timeseries_height == 1 and row < windrose_row_start and row in corr_row_start_list: #row >= correlation_row_start:
                row_specs.append({'rowspan': correlation_height, 'colspan': correlation_width}) #correlation plots

            elif col == windrose_col_start and row == windrose_row_start:
                row_specs.append({'rowspan': windrose_height, 'colspan': windrose_width, 'type': 'polar'}) #windrose
            elif col in windrose_cols and row in windrose_rows:
                row_specs.append({'type': 'polar'})

            elif (row == pie_total_row_start or row == pie_subset_row_start) and col in pie_col_start_list:
                row_specs.append({'rowspan': pie_height, 'colspan': pie_width, 'type': 'pie'}) #pie charts
                

            elif col == table_col_start and row == table_row_start:
                row_specs.append({'rowspan': table_height, 'colspan': table_width, 'type': 'table'})
            elif col in table_cols and row in table_rows:
                row_specs.append({'type': 'table'})
            
            else:
                row_specs.append({})

            updated = False
            if row == pie_total_row_start and col in pie_col_start_list:
                for i in range(pie_no):
                    if col == pie_col_start_list[i]:
                        subplot_titles.append(pie_types_list[i])
                        updated = True
            if updated == False:
                subplot_titles.append(None)
        
        specs.append(row_specs)

        loc_dict.update(dict(subplot_titles = subplot_titles))

    return specs, loc_dict


def make_timeseries_subplot(
        fig: go.Figure, 
        time_data, 
        y_data, 
        y_name: str, 
        update_y_axis: bool = False, 
        y_color: str = 'grey', 
        y_range = None, 
        tickmode: str = 'linear', 
        tick0: float = 0, 
        dtick: float = 10, 
        row: int = 1, 
        col: int = 1
        ) -> go.Figure:
    '''
    Creates a timeseries subplot in plotly figure "fig".

    Args:
        fig
        time_data: vector
            Time data as datetimes to be plotted
        y_data: vector
            y-axis data to be plotted
        y_name: string
            Name of the y variable to be used as the y-axis title
        update_y_axis: boolean, default False
            Boolean to enable updating the range and tick marks on the plot
        y_color: string, default grey
            Color of the plotted data markers. Must be interpretable by plotly.
        y_range:
            Range for the updated y-axis.
        tickmode: str
            Plotly tickmode for the y-axis.
        tick0: float
            Plotly tick0 for the y-axis.
        dtick: float
            Plotly dtick for the y-axis.
        row: int, default 1
            Plotly subplot row.
        col: int, default 1
            Plotly subplot column.

    Returns:
        fig:
            updated plotly figure object

    '''
    fig.add_trace(
        go.Scattergl(
            x = time_data,
            y = y_data,
            showlegend = False,
            mode = 'markers',
            marker_color = y_color, 
            opacity = 0.5,
            name = y_name
        ),
        row = row,
        col = col,
    )
    if update_y_axis:
        fig.update_yaxes(
            title = y_name,
            row = row,
            col = col
        )
    if y_range is not None:
        fig.update_yaxes(
            range = y_range,
            tickmode = tickmode,
            tick0 = tick0,
            dtick = dtick,
            row = row,
            col = col
        )

    return fig

def make_correlation_subplot(
        fig: go.Figure, 
        x_data, 
        y_data, 
        y_color: str = 'grey', 
        y_name: str = None, 
        x_name: str = None, 
        row: int = 1, 
        col: int = 2, 
        corr_lines: List[float] = [0.01, 0.02]
        ) -> go.Figure:
    '''
    Creates a correlation subplot in plotly figure "fig".

    Args:
        fig: plotly figure
        x_data: vector
            x-axis data
        y_data: vector
            y-axis data
        y_color: str, default 'grey'
            Color of the plotted data markers. Must be interpretable by plotly.
        y_name: string, default None
            Name of the y variable to be used as the y-axis title
        x_name: string, default None
            Name of the x variable to be used as the x-axis title
        row: int, default 1
            Plotly subplot row.
        col: int, default 2
            Plotly subplot column.
        corr_lines: List of floats, default [0.01, 0.02]
            List of slope values to bracket the dataset. Black dashed lines are added to the plot
            to indicate the upper and lower bounds of the correlation.
    Returns:
        fig:
            updated plotly figure object
    '''
    fig.add_trace(
        go.Scattergl(
            x = x_data,
            y = y_data,
            showlegend = False,
            mode = 'markers',
            marker_color = y_color, 
            opacity = 0.5,
        ),
        row = row,
        col = col,
    )

    for i, corr_line in enumerate(corr_lines):
        fig.add_trace(
            go.Scattergl(
                x = [0, np.nanmax(x_data)],
                y = [0, np.nanmax(x_data) * corr_line],
                mode = 'lines',
                line_color = 'black', #KOL[i],
                line_dash = 'dash',
                showlegend = False,
            ),
            row = row,
            col = col
        )
        fig.add_annotation(
            x=np.nanmax(x_data), y=np.nanmax(x_data) * corr_line,
            text=f"{corr_line * 100:.0f} %",
            showarrow=False,
            yshift=10,
            row = row,
            col = col,
            )
    
    if y_name is not None:
        fig.update_yaxes(
            title = y_name,
            row = row,
            col = col
        )
    
    if x_name is not None:
        fig.update_xaxes(
            title = x_name,
            row = row,
            col = col
        )


    return fig

def get_bounding_ratios(
        max_corr: float, 
        min_corr: float
        ) -> List[float]:
    '''
    Finds the closest correlation lines in RATIO_OPTIONS that represent the maximum and minimum correlations in a dataset.

    Args:
        max_corr: float
            Maximum correlation value for a dataset of x/y data
        min_corr: float
            Minimum correlation value for a dataset of x/y data
    Returns:
        corr_lines: list of floats
            List of slope values to bracket the dataset. Black dashed lines are added to the plot
            to indicate the upper and lower bounds of the correlation.
    '''
    max_diff = RATIO_OPTIONS - max_corr
    max_diff[max_diff<0] = np.nan
    max_ind = np.where(~np.isnan(max_diff))[0][0]
    
    min_diff = min_corr - RATIO_OPTIONS
    min_diff[min_diff<0] = np.nan
    min_ind = np.where(~np.isnan(min_diff))[0][-1]

    corr_lines = [RATIO_OPTIONS[min_ind], RATIO_OPTIONS[max_ind]]  

    return corr_lines

def make_correlation_subplots(
        fig: go.Figure, 
        ds: xr.Dataset,
        corr_var_name: str,
        corr_var_axis: str,
        var_list: List[str],
        color_dict: dict, 
        y_name: str = None, 
        x_name: str = None, 
        row: int = 1, 
        col: int = 2, 
        corr_lines: List[float] = [0.01, 0.02],
        corr_zero: float = 0
        ) -> go.Figure:
    '''
    Add multiple correlation subplots to the dashboard figure object.

    Args:
        fig: plotly figure
        ds: xarray dataset
        corr_var_name: string
            Variable name for the independent correlation value.
        corr_var_axis: string
            Label for the correlation value, used to scale TVOC values when necessary.
        var_list: list of strings
            List of dependent variables to be compared to the correlation variable.
        color_dict: dictionary
            Dictionary with keys that are a subset of all_compounds_list. Values must be colors that can
            be interpreted by plotly.
        y_name: string, default None
            Axis label for the dependent variables.
        x_name: string, default None
            Axis label for the correlation value.
        row: int, default 1
            Plotly subplot row.
        col: int, default 2
            Plotly subplot column.   
        corr_lines: List of floats, default [0.01, 0.02]
            List of slope values to bracket the dataset. Black dashed lines are added to the plot
            to indicate the upper and lower bounds of the correlation.
        corr_zero: float, default 0
            Value of the correlation variable zero. This value will be used to accurately calculate the correlation
            between dependent variables and the independent variable enhancement above the background level.

    Returns:
        fig:
            updated plotly figure object

    '''
    ds_now = ds.sel(other='concs').fitter_values.dropna(dim='_datetime', how='all')
    corr_data = ds_now.sel(fitter_var = corr_var_name)
    if 'TVOC' in corr_var_axis:
        corr_data *= TVOC_SCALE
        
    if len(corr_lines) == 0:
        max_corr = np.nan
        min_corr = np.nan
        for i, var_name in enumerate(var_list):
            data = ds_now.sel(fitter_var = var_name)
            max_corr = np.nanmax(((data / (corr_data-corr_zero)).median(), (data / (corr_data-corr_zero)).mean(), max_corr))
            min_corr = np.nanmin(((data / (corr_data-corr_zero)).median(), (data / (corr_data-corr_zero)).mean(), min_corr))   

        corr_lines = get_bounding_ratios(max_corr, min_corr)

    for i, var_name in enumerate(var_list):
        fig.add_trace(
            go.Scattergl(
                x = corr_data,
                y = ds_now.sel(fitter_var = var_name),
                showlegend = False,
                mode = 'markers',
                marker_color = color_dict[var_name], 
                opacity = 0.5,
            ),
            row = row,
            col = col,
        )

    for i, corr_line in enumerate(corr_lines):
        fig.add_trace(
            go.Scattergl(
                x = [corr_zero, np.nanmax(corr_data)],
                y = [0, (np.nanmax(corr_data) - corr_zero) * corr_line],
                mode = 'lines',
                line_color = 'black', #KOL[i],
                line_dash = 'dash',
                showlegend = False,
            ),
            row = row,
            col = col
        )
        fig.add_annotation(
            x=np.nanmax(corr_data), y=(np.nanmax(corr_data) - corr_zero) * corr_line,
            text=f"{corr_line:.0e}",
            showarrow=False,
            yshift=10,
            row = row,
            col = col,
            )
        
    if y_name is not None:
        fig.update_yaxes(
            title = y_name,
            row = row,
            col = col
        )
    
    if x_name is not None:
        fig.update_xaxes(
            title = x_name,
            row = row,
            col = col
        )


    return fig


def make_pie_subplot(
        fig: go.Figure, 
        labels: List[str], 
        values, 
        var_len: int, 
        marker_colors = None, 
        row: int = 1, 
        col: int = 3
        ) -> go.Figure:
    '''
    
    Args:
        fig: plotly figure object
        labels: list of strings
            Labels for each section of the pie chart
        values: vector
            Values to be plotted as a pie chart.
        var_len: int
            Length of the list of variables, used to index the colors.
        marker_colors = None
            Colors to be assigned to specific label/value pairs.
        row: int, default 1
            Plotly subplot row.
        col: int, default 3
            Plotly subplot column.

    Returns:
        fig:
            updated plotly figure object
    '''
    fig.add_trace(
        go.Pie(
            labels = labels,
            values = values,
            marker_colors = KOL2.colors[:var_len] if marker_colors is None else marker_colors,
            sort=False,
            textposition = 'inside'
        ),
        row = row,
        col = col
    )

    return fig

def add_table_to_fig(
        fig: go.Figure, 
        header_values, 
        values, 
        row = 1, 
        col = 1
        ) -> go.Figure:
    '''
    Adds a table as a subplot to a plotly figure.

    Args:
        fig: plotly figure object
        header_values: list of strings
            Header values for the table.
        values:
            Values to be added to the table
        row: int, default 1
            Plotly subplot row.
        col: int, default 1
            Plotly subplot column.

    Returns:
        fig:
            updated plotly figure object   

    '''
    fig.add_trace(
        go.Table(
            header = dict(
                values = header_values,
                # font = dict(size=10),
                align = 'left'
            ),
            cells = dict(
                values = values,
                align = 'left'
            ),
        ),
        row = row,
        col = col
    )

    return fig

# def get_spec_list(
#         var_list: List[str], 
#         collapse_ts: bool = False
#         ):
#     timeseries_col_start = 1
#     timeseries_width = 5
#     timeseries_height = 2

#     correlation_width = 2
#     correlation_height = 2

#     pie_width = 2
#     pie1_row_start = 1
#     pie_height = 2

#     if collapse_ts:
#         windrose_width = 2
#         windrose_height = 2
#     else:
#         windrose_width = 4
#         windrose_height = 4

#     table_width = pie_width * 2

    
#     correlation_col_start = timeseries_col_start + timeseries_width
#     pie1_col_start = correlation_col_start + correlation_width
#     pie2_col_start = pie1_col_start+ pie_width
#     pie2_row_start = pie1_row_start + pie_height

#     windrose_col_start = correlation_col_start #+ 1 
#     # windrose_col_start = timeseries_col_start + timeseries_width
#     if collapse_ts:
#         windrose_row_start = 3 * timeseries_height + 1
#     else:
#         windrose_row_start = (len(var_list) + 1) * timeseries_height + 1
    
#     windrose_cols = np.arange(windrose_width) + windrose_col_start
#     windrose_rows = np.arange(windrose_height) + windrose_row_start
#     table_col_start = correlation_col_start + correlation_width
#     table_row_start = pie2_row_start + pie_height
#     table_cols = np.arange(table_width) + table_col_start

#     if collapse_ts:
#         rows_no = timeseries_height * (1 + 1 + 2) #tvoc, analytes, wind
#     else:
#         rows_no = timeseries_height * (1 + len(var_list) + 2) #tvoc, analytes, wind
#     cols_no = timeseries_width + correlation_width + 2 * pie_width

#     table_height = rows_no - pie_height * 2 - windrose_height
#     table_rows = np.arange(table_height) + table_row_start


#     loc_dict = dict(
#         timeseries_col_start = timeseries_col_start,
#         pie1_row_start = pie1_row_start,
#         pie1_col_start = pie1_col_start,
#         pie2_row_start = pie2_row_start,
#         pie2_col_start = pie2_col_start,
#         correlation_col_start = correlation_col_start,
#         windrose_col_start = windrose_col_start,
#         windrose_row_start = windrose_row_start,
#         table_col_start = table_col_start,
#         table_row_start = table_row_start,
#         rows_no = rows_no,
#         cols_no = cols_no,
#         windrose_height = windrose_height,
#         timeseries_height = timeseries_height,
#         correlation_height = correlation_height,
#         windrose_width = windrose_width,
#     )


#     specs = []
#     for row in (np.arange(rows_no) + 1):
#         row_specs = []

#         for col in (np.arange(cols_no) + 1):
#             if col == timeseries_col_start and row % timeseries_height == 1:
#                 row_specs.append({'rowspan': timeseries_height, 'colspan': timeseries_width}) #timeseries subplots

#             elif col == correlation_col_start and row % timeseries_height == 1 and row < windrose_row_start:
#                 row_specs.append({'rowspan': correlation_height, 'colspan': correlation_width}) #correlation plots

#             elif col == windrose_col_start and row == windrose_row_start:
#                 row_specs.append({'rowspan': windrose_height, 'colspan': windrose_width, 'type': 'polar'}) #windrose
#             elif col in windrose_cols and row in windrose_rows:
#                 row_specs.append({'type': 'polar'})

#             elif (col == pie1_col_start or col == pie2_col_start) and (row == pie1_row_start or row == pie2_row_start):
#                 row_specs.append({'rowspan': pie_height, 'colspan': pie_width, 'type': 'pie'}) #pie charts

#             elif col == table_col_start and row == table_row_start:
#                 row_specs.append({'rowspan': table_height, 'colspan': table_width, 'type': 'table'})
#             elif col in table_cols and row in table_rows:
#                 row_specs.append({'type': 'table'})

#             else:
#                 row_specs.append({})
        
#         specs.append(row_specs)

#     return specs, loc_dict
