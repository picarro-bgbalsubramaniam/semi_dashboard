import xarray as xr
import numpy as np
from pathlib import Path
from tqdm import tqdm

from picarro_xarray.data_models.constants import TIME_DIM
import picarro_xarray.accessors.compound_search_accessor  # noqa
import picarro_xarray.accessors.zero_reference_accessor  # noqa

from spectral_toolkit.field_analysis.field_correlation_utilities import compute_correlation_spectrum, CorrelationType
from spectral_toolkit.data_models.field_models import configYaml
from spectral_toolkit.data_models.rnd_schema import event_timing


def trim_times(
        ds: xr.Dataset, 
        config: configYaml
        ):
    # # Subselect portion of data based on time 
    # # https://docs.xarray.dev/en/latest/user-guide/indexing.html
    time_ds = ds.sel(_datetime=slice(config.times.expt_start, config.times.expt_end))

    for time_now in config.data_to_drop:
        time_ds = time_ds.where((time_ds._datetime<np.datetime64(time_now.start)) | (time_ds._datetime>np.datetime64(time_now.end)), drop=True)

    return time_ds

def curate_difference_data_from_peak_obj(ds, peak):
    dt_bool = ((ds._datetime >= peak.zero_start) & (ds._datetime <= peak.zero_end)) | ((ds._datetime >= peak.start) & (ds._datetime <= peak.end))
    analysis_ds = ds.isel(_datetime=dt_bool).compute()    
    # analysis_ds = analysis_ds.dropna(dim='mode', subset=['spectral_values'])

    thresh = int(0.5 * analysis_ds.sizes['_datetime'])
    analysis_ds = analysis_ds.dropna(dim='mode', subset=['spectral_values'], thresh=thresh)

    grouper = xr.where(
        (analysis_ds._datetime >= peak.zero_start) & (analysis_ds._datetime <= peak.zero_end), 0, 
        xr.where((analysis_ds._datetime >= peak.start) & (analysis_ds._datetime <= peak.end), 1, 2)
        )

    relative_ref_ds = analysis_ds.zero_reference.zero_reference(
        transition_variable=grouper,
        reference_value=0,
    )

    return relative_ref_ds.sel(_datetime=slice(peak.start, peak.end))

def create_spectra_for_ch(
        spectra_ds: xr.Dataset, 
        sample_corr: xr.Dataset, 
        model_functions: dict, 
        time_periods: list, 
        save_path: Path, 
        config: configYaml, 
        corr_name: str, 
        corr_ave: str = 'corr', 
        valve_var: str = None
        ):
    peak_id = 0 # single peak version of correlation

    for left, center, right in tqdm(time_periods):
        # check that there is sample data in this time period:
        msk = (sample_corr._datetime >= left) & (sample_corr._datetime <= right)
        if ~msk.any(): # no data
            continue
            
        bin_name = center.strftime('%Y%m%d_%H%M%S')
        print(f'Computing {corr_name} for {bin_name}')
        timebin_dir = Path(save_path / bin_name)
        timebin_dir.mkdir(exist_ok=True, parents=True)
        if (timebin_dir / "X.parquet").exists(): pass
        
        analysis_ds = spectra_ds.sel(_datetime=slice(left,right))

        create_single_for_ch(analysis_ds, model_functions, config, corr_name, timebin_dir, peak_id = peak_id, corr_ave = corr_ave, valve_var = valve_var)

def create_spectra_for_ch_from_peak_obj(
        spectra_ds: xr.Dataset, 
        model_functions: dict, 
        peak_obj_list: list, 
        save_path: Path, 
        config: configYaml, 
        corr_name: str, 
        corr_ave: str = 'corr', 
        valve_var: str = None,
        zeroed_difference_spectra: bool = False
        ):
    peak_id = 0 # single peak version of correlation

    for peak in tqdm(peak_obj_list):
        if 'start_time' in peak.__dict__.keys():
            peak_event = event_timing(start = peak.start_time, end = peak.end_time)
        else:
            peak_event = peak
        bin_name = peak_event.cen.strftime('%Y%m%d_%H%M%S')
        print(f'Computing {corr_name} for {bin_name}')
        timebin_dir = Path(save_path / bin_name)
        timebin_dir.mkdir(exist_ok=True, parents=True)
        if (timebin_dir / "X.parquet").exists(): pass
        
        if zeroed_difference_spectra:
            analysis_ds = curate_difference_data_from_peak_obj(spectra_ds, peak_event)
            corr_ave = 'ave'
        else:
            analysis_ds = spectra_ds.sel(_datetime=slice(peak_event.start,peak_event.end))

        if len(analysis_ds._datetime)>0:
            create_single_for_ch(analysis_ds, model_functions, config, corr_name, timebin_dir, peak_id = peak_id, corr_ave = corr_ave, valve_var = valve_var)
            peak_event.save_single_peak_timing(save_path = save_path)



def create_single_for_ch(
        analysis_ds: xr.Dataset, 
        model_functions: dict, 
        config: configYaml, 
        corr_name: str, 
        timebin_dir: Path, 
        peak_id: int = 0, 
        corr_ave: str = 'corr', 
        valve_var: str = None,
        trigger_var: str = None
        ):
    if valve_var is not None:
        analysis_ds = analysis_ds.drop_isel(_datetime=analysis_ds.sel(fitter_var = valve_var).fitter_values==config.valve_info.ref_value)
    elif trigger_var is not None:
        analysis_ds = analysis_ds.drop_isel(_datetime=analysis_ds.sel(fitter_var = trigger_var).fitter_values==config.peak_detector.ref_value)

    # analysis_ds = analysis_ds.compute()
    thresh = int(0.5 * analysis_ds.sizes['_datetime'])
    analysis_ds = analysis_ds.dropna(dim='mode', subset=['spectral_values'], thresh=thresh) # why are we keeping nan?
    analysis_ds = analysis_ds.expand_dims({'peak_id' : [0]})

    if corr_ave == 'corr':
        #remove modes with lots of na (not sure why it didn't work above)
        partial_fit = analysis_ds.sel(spectral_var='partial_fit').spectral_values
        pf_na = partial_fit.isnull()
        N_dts = analysis_ds.sizes['_datetime']
        
        good = (pf_na.sum(axis=1)< N_dts * config.__dict__[corr_name].na_thresh)[0]
        analysis_ds = analysis_ds.sel(mode=good.values)

        analysis_ds  = analysis_ds.dropna(dim='_datetime')
        dslist = [analysis_ds]
        ds_peaks = xr.concat(dslist, dim='peak_id')

        ds_corr = ds_peaks.groupby('peak_id').apply(
            compute_correlation_spectrum, 
            corr_key=config.__dict__[corr_name].corr_key, 
            correlation_type=CorrelationType.SHORTTERM
        )

        test = ds_corr.sel(peak_id=peak_id).dropna(TIME_DIM, how='all')
        test.compound_search.set_model_functions(model_functions)
        Y = test.compound_search.Y.to_frame()
    elif corr_ave == 'ave':
        analysis_ds = analysis_ds.drop_vars(['fitter_var', 'fitter_values'])
        analysis_ds  = analysis_ds.dropna(dim='_datetime')
        try:
            analysis_ds  = analysis_ds.dropna(dim='mode')
            test = analysis_ds.sel(peak_id = peak_id)
            test.compound_search.set_model_functions(model_functions)
            Y = test.compound_search.Y
        except:
            pass

    try:
        X = test.compound_search.X
        bad_nu = Y.isna().sum(axis=1) == 1
        if bad_nu.sum() > 0:
            print(bad_nu.sum())
        X.to_parquet(timebin_dir / "X.parquet")
        Y.to_parquet(timebin_dir / "Y.parquet")
    except:
        print(f'could not save spectra data for {timebin_dir}')


def get_sorted_cids(best_cids):
    sorted_cids = {}
    count = 0
    for i in np.arange(best_cids.sort_index.min(), best_cids.sort_index.max()):
        tcid = best_cids.cid[np.where(best_cids.sort_index == i)[0]].values[0]
        if tcid not in sorted_cids.keys():
            sorted_cids[tcid] = count
            count += 1
    return sorted_cids