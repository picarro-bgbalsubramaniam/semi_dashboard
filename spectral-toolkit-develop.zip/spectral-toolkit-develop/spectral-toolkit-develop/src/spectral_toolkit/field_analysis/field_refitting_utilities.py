import xarray as xr
import pandas as pd
import numpy as np
from pathlib import Path 
import os

from datetime import datetime
from scipy.stats import norm

import picarro_xarray.accessors.zero_reference_accessor  # noqa
from picarro_xarray.compute.utils import _remove_dask_encoding
from dask.distributed import LocalCluster, Client

from spectral_toolkit.reprocess_combo import get_least_squares
import picarro_xarray.accessors.refit_accessor
import picarro_xarray.accessors.allan_accessor  # noqa

from picarro_xarray.compute.zero_reference import get_transition_uid, get_reference_transitions_uid
from picarro_xarray.compute.detection_limits import get_limits_of_detection

from picarro_xarray.io.combolog.combo_log_prescan import DEFAULT_NU_CENTER_KEYS

from spectral_toolkit.field_analysis.field_figures import plot_all_summaries
from spectral_toolkit.field_analysis.field_utilities import (
    create_average_ds, 
    trim_transitions_ref_sample, 
    latency_adjust, 
    save_daily_zero_ref_conc_data,
    get_ref_name,
    create_port_split_ds
)

from spectral_toolkit.scheme_optimizer.reporting import get_pubchem_df

pc_df = get_pubchem_df()


big3 = {
    '280': ('broadband_gasConcs_280', 1000000.0, 'CO2'),
    '297': ('broadband_gasConcs_297', 1000000.0, 'CH4'),
    '962': ('broadband_gasConcs_962', 100.0, 'H2O'),
    }


def rename_compounds(config, ds):
    # rename compounds
    fitter_var = ds.fitter_var.values
    raw_species = []
    non_analyte_species = []
    for i, var_name in enumerate(ds.fitter_var.values):
        if 'gasConcs' in var_name:
            var_bits = var_name.split('_')
            cid = var_bits[-1]
            compound_name = var_name
            if cid in big3:
                compound_name = big3[cid][2]
            elif int(cid) in pc_df.index:
                compound_name = pc_df.loc[int(cid)]['commonName']
            
            fitter_var[i] = compound_name
            raw_species.append(compound_name)
            if compound_name not in config.variables.vars_to_save:
                non_analyte_species.append(compound_name)
    ds['fitter_var'] = fitter_var
    
    return ds, raw_species, non_analyte_species


def get_cids_and_refit(config, time_ds, best_cids_df, Q_compounds_dict, sigma = 2):
    q_value = norm.cdf(sigma) - norm.cdf(-sigma)

    # only refit with the refitting_cids
    sigma_bool = best_cids_df['q_prob'] >= q_value

    if sigma_bool.any():
        list_set = set(best_cids_df['cid'][sigma_bool])
    else:
        print('no significant cid identifications')
        return None
    print(list_set)

    gas_concs_set = list_set
    for key, values in Q_compounds_dict.items():
        gas_concs_set |= values

    gas_concs_set |= set(config.fitting.analyte_cids)

    gas_concs = list(gas_concs_set)

    print(gas_concs)

    lsq = get_least_squares(gas_concs, nominal_pressure=config.fitting.nominal_pressure)

    with LocalCluster() as lc, Client(lc) as client:
        print(client.dashboard_link)
        result_lsq = time_ds.refit.llsq(lsq=lsq, fast=False).compute()  # compute will run the computation, you can run with fast=True for about a 150% speedup

    time_ds = time_ds.drop(['spectral_var', 'mode', 'spectral_values'])
    var_2_drop = []
    for fitter_var in time_ds.fitter_var.values:
        if 'gasConcs' in fitter_var:
            var_2_drop.append(fitter_var)

    time_ds = time_ds.drop_sel(fitter_var = var_2_drop)

    new_ds = xr.concat((time_ds, result_lsq.to_dataset(name='fitter_values')), dim='fitter_var', data_vars='all',coords='all')
    new_ds, raw_species, non_analyte_species = rename_compounds(config, new_ds)

    if 'private_var' in new_ds:
        new_ds = new_ds.drop_vars(['private_var', 'private_values', 'private_logs_origin'])

    return new_ds, raw_species, non_analyte_species

def set_cids_and_refit(config, time_ds):
    # only refit with the refitting_cids
    list_set = set(config.fitting.refitting_cids)
    list_set |= set(config.fitting.analyte_cids)
    gas_concs = (list(list_set))

    new_ds = refit(time_ds, gas_concs, config.fitting.nominal_pressure)

    new_ds, raw_species, non_analyte_species = rename_compounds(config, new_ds)

    return new_ds, raw_species, non_analyte_species


def refit(time_ds, gas_list, pressure):
    lsq = get_least_squares(gas_list, nominal_pressure=pressure)

    with LocalCluster() as lc, Client(lc) as client:
        print(client.dashboard_link)
        result_lsq = time_ds.refit.llsq(lsq=lsq, fast=False).compute()  # compute will run the computation, you can run with fast=True for about a 150% speedup

    time_ds = time_ds.drop(['spectral_var', 'mode', 'spectral_values'])
    var_2_drop = []
    for fitter_var in time_ds.fitter_var.values:
        if 'gasConcs' in fitter_var:
            var_2_drop.append(fitter_var)

    time_ds = time_ds.drop_sel(fitter_var = var_2_drop)

    new_ds = xr.concat((time_ds, result_lsq.to_dataset(name='fitter_values')), dim='fitter_var', data_vars='all',coords='all')
    

    return new_ds


def save_refit_data(config, ds, fn_suffix):
    with LocalCluster() as lc, Client(lc) as client:
        
        print(client.dashboard_link)
        
        # save refit data
        new_ds = ds.chunk({"_datetime": 1000, "fitter_var": 20}) 
        new_ds = _remove_dask_encoding(new_ds)
        new_ds.to_zarr(config.paths.output_path / f'refit_time_ds_{fn_suffix}.zarr', mode='w')

        ds.close()
        new_ds.close()

def filter_data(config, time_ds, fn_suffix):
    valve_var = get_ref_name(config)
    new_ds = xr.open_zarr(config.paths.output_path / f'refit_time_ds_{fn_suffix}.zarr')

    if 'private_values' in time_ds:
        new_ds['private_values'] = time_ds.sel(_datetime = new_ds._datetime).private_values

    latency_adjusted_group = latency_adjust(
        new_ds, 
        valve_var, 
        config.valve_info.latency,
        var_group='private' if 'private_var' in time_ds else 'fitter'
        ) 
    if 'private_values' in time_ds:
        new_ds['private_values'][:, new_ds['private_var'] == valve_var] = np.round(latency_adjusted_group)

    new_ds['fitter_values'][:, new_ds.fitter_var == valve_var] = np.round(latency_adjusted_group)
    new_ds = new_ds.dropna(dim='_datetime', how='any')

    # Find the transitions
    transition_uid = get_transition_uid(
        transition_data=new_ds.sel(fitter_var=valve_var).fitter_values
    )

    # Trim and remove short durations
    trimmed_ds, time_bounds_ref_da, time_bounds_sample_da = trim_transitions_ref_sample(
        data=new_ds,
        grouper_da=transition_uid,
        group_arr = new_ds.sel(fitter_var=valve_var).fitter_values.values,
        ref_value = config.valve_info.ref_value,
        min_ref_duration_seconds = config.valve_info.ref_min_duration,
        min_sample_duration_seconds = config.valve_info.sample_min_duration,
        trim_start_seconds = config.valve_info.start_trim,
        trim_end_seconds = config.valve_info.end_trim,
    )

    new_ds.close()
    return trimmed_ds

def get_lods(config, trimmed_ds, raw_species, fn_suffix):
    valve_var = get_ref_name(config)
    
    transition_data = trimmed_ds.sel(fitter_var=valve_var).fitter_values 
    reference_uid = get_reference_transitions_uid(transition_data, config.valve_info.ref_value)  

    reference_all = trimmed_ds.sel(_datetime=reference_uid["_datetime"].values)
    if 'private_var' in reference_all:
        reference_all.drop_vars(['private_var', 'private_values'])
    sigma_tau = reference_all.allan.allan_dev(complete=False)
    sigma_tau = sigma_tau.squeeze("_datetime")
    sigma_tau.sel(fitter_var=raw_species).to_pandas()

    lod_da = get_limits_of_detection(
        sigma_tau=sigma_tau.to_dataarray(),
        averaging_time_seconds=4,
        sigma_confidence_level=3
    )
    lod_df = lod_da.sel(fitter_var=raw_species).T.to_pandas()
    lod_da.close()
    lod_df

    lod_df.to_csv(config.paths.output_path / f'refit_trimmed_LOD_{fn_suffix}.csv')

def refit_zeroing(config, trimmed_ds, fn_suffix):
    valve_var = get_ref_name(config)

    with LocalCluster() as lc, Client(lc) as client:
        print(client.dashboard_link)

        zero_ref_ds = trimmed_ds.zero_reference.zero_reference(
            transition_variable=valve_var,
            reference_value=config.valve_info.ref_value,
            time_dim = '_datetime',
            passthrough_fitter_vars = DEFAULT_NU_CENTER_KEYS + [valve_var],
            temp_storage=config.paths.temp_path, #temp storage frees up RAM on some steps
            event_window_width = config.valve_info.num_reference_periods #NEW
        ) # zero reference the data

    trimmed_ds.close()

    # drop data from ports that are not included in port_map
    for i, (port_name, port) in enumerate(config.valve_info.port_map_dict.items()):
        if i == 0:
            mask = (zero_ref_ds.sel(fitter_var=valve_var).fitter_values == port)
        else:
            mask |= (zero_ref_ds.sel(fitter_var=valve_var).fitter_values == port)
    clean_ds = zero_ref_ds.where(mask.compute(), drop=False)
    clean_ds = clean_ds.dropna('_datetime')
    zero_ref_ds.close()
    
    with LocalCluster() as lc, Client(lc) as client:
        print(client.dashboard_link)
        
        clean_ds = clean_ds.chunk({"_datetime": 3000, "fitter_var": 20}) 
        clean_ds = _remove_dask_encoding(clean_ds) #erase physical memory history to update chunking

        clean_ds.to_zarr(config.paths.output_path / f'refit_zero_referenced_data_{fn_suffix}.zarr', mode='w') #save rechunked data

def refit_port_splitting(config, fn_suffix):
    valve_var = get_ref_name(config)
    clean_ds = xr.open_zarr(config.paths.output_path / f'refit_zero_referenced_data_{fn_suffix}.zarr')

    port_split_ds = create_port_split_ds(clean_ds, valve_var)

    with LocalCluster() as lc, Client(lc) as client:
        print(client.dashboard_link)
        
        port_split_ds = port_split_ds.chunk({"_datetime": 3000}) 
        port_split_ds = _remove_dask_encoding(port_split_ds) #erase physical memory history to update chunking

        port_split_ds.to_zarr(config.paths.output_path / f'refit_port_split_ds_{fn_suffix}.zarr', mode='w') #save rechunked data

def summary_plot_refit(config, raw_species, non_analyte_species, fn_suffix, port_split_ds = None, additional_suffix = None):
    valve_var = get_ref_name(config)
    if port_split_ds is None:
        port_split_ds = xr.open_zarr(config.paths.output_path / f'refit_port_split_ds_{fn_suffix}.zarr')
    clean_ds = xr.open_zarr(config.paths.output_path / f'refit_zero_referenced_data_{fn_suffix}.zarr')
    
    return_xr = create_average_ds(port_split_ds.compute(), config.variables.report_time_average)
    return_xr.to_netcdf(config.paths.output_path / f"refit_{config.variables.report_time_average.value}_averaged_ds_{fn_suffix}.nc")

    suffix = fn_suffix
    if additional_suffix is not None:
        suffix += additional_suffix

    plot_all_summaries(
        return_xr, 
        clean_ds, 
        config.variables.controls, 
        raw_species, 
        config.variables.vars_to_save, 
        non_analyte_species, 
        valve_var, 
        config.variables.report_time_average, 
        config.valve_info.port_map_dict, 
        config.paths.figures_path,
        fn_suffix = suffix
        )
    
def save_daily(config, fn_suffix):
    return_xr = xr.open_dataset(config.paths.output_path / f"refit_{config.variables.report_time_average.value}_averaged_ds_{fn_suffix}.nc")
    
    for date_obj in np.unique(return_xr._datetime.dt.date.values):
        save_daily_zero_ref_conc_data(return_xr, date_obj, config, refit=True)