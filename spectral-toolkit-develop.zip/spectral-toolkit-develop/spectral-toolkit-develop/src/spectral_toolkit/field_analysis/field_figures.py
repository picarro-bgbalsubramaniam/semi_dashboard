import xarray as xr
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import math

from typing import List

from spectral_toolkit.plotting.summary_plot import (
    _get_subplots_variables,
    _get_row_heights,
    _adjust_layout,
)
from spectral_toolkit.plotting.port_average_plot_plotly import rgb_to_rgba

import spectral_toolkit.field_analysis.utilities as UT

KOL = UT.CuteNordicKnit(brtValue=0.25)
KOL.make_long(brt_list=[0.25, -0.1])

KOL2 = UT.PsychedelicChakra(brtValue=0.25)
KOL2.make_long(brt_list=[0.25, -0.1])

def plot_event_stats(
    df: pd.DataFrame, 
    var_list: List[str], 
    stat_to_plot: str, 
    error_var: str = None,
    sizing_var: str = None, 
    abs_data: bool = False
    ):
    idx = pd.IndexSlice
    data_now = df.loc[idx[:], (idx[:], stat_to_plot)].abs().cumsum(axis=1) if abs_data else df.loc[idx[:], (idx[:], stat_to_plot)]
    fig = go.Figure()
    for j, var_name in enumerate(var_list):
        color_now = KOL2[j]
        fig.add_trace(
            go.Scattergl(
                x=df.index,
                y=data_now[(var_name, stat_to_plot)],
                name = var_name,
                line_dash='dot',
                marker_color = color_now,
                line_color = color_now,
                marker = {'size': df[(var_name, sizing_var)].values.astype(float) * 10} if sizing_var is not None else {},
                fill = 'tonexty' if abs_data else None,
                error_y=dict(
                    type='data', # value of error bar given in data coordinates
                    array=df[(var_name, error_var)],
                    visible=True,
                    width=2,
                ) if error_var is not None else {},
            )
        )
    
    return fig

def plot_event_bar_distribution(
    df: pd.DataFrame, 
    var_list: List[str], 
    stat_to_plot: str
    ):
    fig = go.Figure()

    for j, var_name in enumerate(var_list):
        color_now = KOL2[j]
        fig.add_trace(
            go.Bar(
                x=df.index,
                y=df[(var_name, stat_to_plot)].abs(),
                name = var_name,
                marker_color = color_now,
            )
        )
    return fig

def plot_stat_pie_chart(
    df: pd.DataFrame, 
    event_ind, 
    var_list: List[str], 
    stat_to_plot: str
    ):
    labels = df.columns.get_level_values(level='compound').unique()
    values = df.loc[event_ind, (labels, stat_to_plot)].abs().values

    fig = go.Figure()
    fig.add_trace(
        go.Pie(
            labels = labels,
            values = values,
            marker_colors = KOL2.colors[:len(var_list)],
            sort=False
        )
    )

    return fig


def plot_summary(
    ds: xr.Dataset, 
    colorscale_ports: dict, 
    port_map: dict,
    valve_var, 
    columns_no: int = 4, 
    sensor_vars: list=[], 
    species_vars: list=[]
):
    # Get variables to show in all subplots
    subplots_variables = _get_subplots_variables(
        sensor_vars=sensor_vars,
        species_vars=species_vars,
        columns_number=columns_no,
    )
    
    # Make sure that the viz order is sensor -> concentrations
    ds = ds.reindex(
        {
            "fitter_var": sensor_vars
            + species_vars
        }
    )
    
    # Evaluate number of rows needed to fit all subplots
    rows_no = math.ceil(len(subplots_variables) / columns_no)

    # Get rows heights
    rows_heights = _get_row_heights(
        rows_no=rows_no,
        cols_no=columns_no,
        concentration_vars_count=len(species_vars),
    )

    # Set up the subplot
    fig = make_subplots(
        rows=rows_no,
        cols=columns_no,
        horizontal_spacing=0.04,
        vertical_spacing=0.03,
        shared_xaxes=True,
        subplot_titles=subplots_variables,
        row_heights=rows_heights,
    )

    # Define hover template
    hov_template = (
        f"<b>%{{meta}}</b><br>"
        f"Value: <b>%{{y:.1f}}</b><br>"
        f"Time: %{{x|%Y/%m/%d %H:%M}}"
        # f"%{{hovertext}} data points"
    )

    # Plot every variable in a different subplot
    for index, variable in enumerate(subplots_variables):
        # Skip empty subplots
        if variable:
            # Add one trace for every port and every species
            for port_name, port in port_map.items():                
                plot_array = ds.sel(fitter_var=variable, port=port)
                
                
                fig.add_trace(
                    go.Scattergl(
                        x=plot_array._datetime,
                        y=plot_array.fitter_values,
                        mode="markers",
                        marker_color=rgb_to_rgba(colorscale_ports[port_name], 0.7),
                        name=port_name,
                        legendgroup=port_name,
                        hovertemplate=hov_template,
                        meta=variable,
                    ),
                    col=(index % columns_no) + 1,
                    row=(index // columns_no) + 1,
                )

    fig = _adjust_layout(fig, subplots_variables)

    # Synchronize all time axis if requested
    for col in range(columns_no):
        fig.update_xaxes(matches="x", col=1 + col)

    # Show time label for every subplot
    fig.update_xaxes(showticklabels=True)
    
    return fig

def plot_all_summaries(
        return_xr: xr.Dataset, 
        clean_ds: xr.Dataset, 
        controls, 
        raw_species, 
        vars_to_save, 
        non_analyte_species, 
        valve_var, 
        averaging, 
        port_map, 
        figures_path,
        refit_or_orig = 'refit',
        fn_suffix = None
        ):
    # Get columns actually in dataframe
    controls = list(set(controls).intersection(clean_ds.fitter_var.values))

    for flnm_sufix, var_list in zip(['all', 'analyte', 'matrix_gas'], [raw_species, vars_to_save, non_analyte_species]):

        # These are typically used for most plots, define here 
        if len(port_map) == 0:
            port_map = {k: f"port_{k}" for k in return_xr.port.astype(int).tolist()}
        
        colors_by_port = {
            port_name: px.colors.qualitative.Bold[port % len(px.colors.qualitative.Bold)]
            for port_name, port in port_map.items()
        }

        # calculate preferred height
        height = (math.ceil(len(var_list) / 4) + math.ceil(len(controls) / 4)) * 350

        fig = plot_summary(
            ds = return_xr.sel(stat='mean'),
            colorscale_ports=colors_by_port,
            port_map=port_map,
            valve_var=valve_var, 
            columns_no=4, 
            sensor_vars=controls, 
            species_vars=var_list
        ).update_layout(height=height, width=1400)
        
        fname = f'{refit_or_orig}_{flnm_sufix}_{averaging.value}_summary'
        if fn_suffix is not None:
            fname += f'_{fn_suffix}'
        fig.write_html(figures_path / f"{fname}.html")



