import xarray as xr
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from typing import List

from spectral_toolkit.field_analysis.field_utilities import TVOC_SCALE, ACTION_LIMITS


def time_conversion(
        ds: xr.Dataset, 
        time_name: str, 
        vars_name: str = 'fitter_values'
        ) -> xr.Dataset:
    if time_name == '_datetime':
        return ds.apply(lambda x: x._datetime.dt.hour + x._datetime.dt.minute/60 + x._datetime.dt.second/60/60)[vars_name]
    else:
        return ds.time    
        
# diurnal profiles
def plot_diurnal_profile(
    ds: xr.Dataset, 
    tvoc_var: str = 'partial_fit_integral', 
    compound_list: List[str] = ['CH4','Ethane','Propane','Butane'], 
    wind_ds: xr.Dataset = None, 
    time_name: str = '_datetime', 
    add_limits: bool = True, 
    lod_df: pd.DataFrame = None
    ) -> go.Figure:
    '''
    Plot diurnal profiles for a set of compounds

    ds: xarray
        xarray dataset with coordinates _datetime or time, fitter_var, port and data fitter_values
        The data must contain tvoc proxy and concentration.
    tvoc_var: str
        string name of the variable in the ds dataset that is the tvoc proxy value
    compound_list: List[str]
        list of string names of compounds to be plotted
    wind_ds: xarray
        xarray dataset with coordinates _datetime or time, parameter, instrument, model and data ts_value
        The data must contain SWD and SWS as wind direction and wind speed
    with_bigpeaks: bool
        boolean indicating if the big peak ranges should be plotted
    peak_loc_df: pandas dataframe
        pandas dataframe containing start and end times for the big peaks events
    add_limits: bool
        boolean indicating if the regulatory limits should be plotted
    lod_df: pandas dataframe
        pandas dataframe containing the limit of detection for any of the compounds to be ploted    
    '''
    
    # def time_conversion(ds, time_name, vars_name = 'fitter_values'):
    #     if time_name == '_datetime':
    #         return ds.apply(lambda x: x._datetime.dt.hour + x._datetime.dt.minute/60 + x._datetime.dt.second/60/60)[vars_name]
    #     else:
    #         return ds.time    
    
    # Set up the subplot
    fig = make_subplots(
        rows=1 + len(compound_list) if wind_ds is None else 1 + len(compound_list) + 2,
        cols=1,
        horizontal_spacing=0.04,
        vertical_spacing=0.03,
        shared_xaxes=True,
    )

    median_values = ds.sel(fitter_var=tvoc_var, port=1, quantile=0.5).fitter_values * TVOC_SCALE
    lower_quant_values = ds.sel(fitter_var=tvoc_var, port=1, quantile=0.25).fitter_values * TVOC_SCALE
    upper_quant_values = ds.sel(fitter_var=tvoc_var, port=1, quantile=0.75).fitter_values * TVOC_SCALE
    fig.add_trace(
        go.Scattergl(
            x=time_conversion(ds,time_name),
            # y=ds.sel(fitter_var=tvoc_var, port=1, stat='mean').fitter_values * TVOC_SCALE,
            y=median_values,
            mode="markers",
            marker_color='grey',
            name='tvoc',
            opacity=0.5,
            showlegend=False,
            error_y=dict(
                type='data', # value of error bar given in data coordinates
                symmetric = False,
                array=upper_quant_values - median_values,
                arrayminus=median_values - lower_quant_values,
                visible=True,
                width=2,
                ),
        ),
        row=1,
        col=1,
    )

    for i, var_name in enumerate(compound_list):
        median_values = ds.sel(fitter_var=var_name, port=1, quantile=0.5).fitter_values
        lower_quant_values = ds.sel(fitter_var=var_name, port=1, quantile=0.25).fitter_values
        upper_quant_values = ds.sel(fitter_var=var_name, port=1, quantile=0.75).fitter_values
        fig.add_trace(
            go.Scattergl(
                x=time_conversion(ds,time_name),
                y=median_values,
                mode="markers",
                marker_color='grey',
                name=var_name,  
                opacity=0.5,
                showlegend=False,
                error_y=dict(
                    type='data', # value of error bar given in data coordinates
                    symmetric = False,
                    array=upper_quant_values - median_values,
                    arrayminus = median_values - lower_quant_values,
                    visible=True,
                    width=2,
                ),
            ),
            row=i+2,
            col=1,
        )


        data_min = np.nanmin(lower_quant_values)
        data_max = np.nanmax(upper_quant_values)
        update_bool = False
        if add_limits and var_name in ACTION_LIMITS:
            fig.add_hline(
                y=ACTION_LIMITS[var_name],
                line_dash='dash',
                line_color='red',
                opacity=0.5,
                row=i+2,
                col=1
            )
            
            data_max = np.max((data_max, ACTION_LIMITS[var_name]))
            update_bool = True
            
        
        if lod_df is not None:
            if var_name in lod_df:
                fig.add_hline(
                    y=lod_df[var_name]*2, #6 sigma
                    line_dash='dash',
                    line_color='blue',
                    opacity=0.5,
                    row=i+2,
                    col=1
                )
                
                data_max = np.max((data_max, lod_df[var_name]*2)) #6 sigma
                update_bool = True

        if update_bool:
            data_range = data_max - data_min

            fig.update_yaxes(
                range = [data_min - 0.05*data_range, data_max + 0.05*data_range], 
                row=i+2, 
                col=1
                )
            

    if wind_ds is not None:
        if 'stat' not in wind_ds._coord_names:
            wind_subset = wind_ds 
            std_subset = None
        else:
            wind_subset = wind_ds.sel(stat='mean') 
            std_subset = wind_ds.sel(stat='std') 
        for i, (var, var_name) in enumerate([('SWD', 'wind direction'),('SWS', 'wind speed')]): #wind speed, wind direction
            fig.add_trace(
                go.Scattergl(
                    x=time_conversion(wind_ds, time_name, vars_name='ts_value'),
                    y=wind_subset.sel(parameter=var).ts_value,
                    mode="markers",
                    marker_color='green',
                    name=var_name,
                    showlegend=False,
                    opacity=0.5,
                    error_y=dict(
                        type='data', # value of error bar given in data coordinates
                        array=None if std_subset is None else std_subset.sel(parameter=var).ts_value,
                        visible=True if std_subset else False,
                        width=2,
                        ),
                ),
                row=i+2+len(compound_list),
                col=1,
            )
    
    fig.update_yaxes(title_text='TVOC (ppb equiv. IPA)', row=1, col=1)
    for i, var_name in enumerate(compound_list):
        if var_name in ['CO2','CH4']:
            fig.update_yaxes(title_text=f'{var_name} (ppm)', row=i+2, col=1)
        elif var_name == 'H2O':
            fig.update_yaxes(title_text=f'{var_name} (%)', row=i+2, col=1)
        else:
            fig.update_yaxes(title_text=f'{var_name} (ppb)', row=i+2, col=1)
    if wind_ds is not None:
        fig.update_yaxes(title_text='Wind Direction', row=2+len(compound_list), col=1, range=[0,360])
        fig.update_yaxes(title_text='Wind Speed', row=3+len(compound_list), col=1)

    return fig


def plot_single_diurnal_profile(
    ds: xr.Dataset, 
    compound_name: str = 'Ethane', 
    wind_ds: xr.Dataset = None, 
    time_name: str = '_datetime', 
    add_limits: bool = True, 
    lod_df: pd.DataFrame = None
    ) -> go.Figure:
    '''
    Plot diurnal profile for a single compound

    ds: xarray
        xarray dataset with coordinates _datetime or time, fitter_var, port and data fitter_values
        The data must contain tvoc proxy and concentration.
    compound_name: str
        name of compounds to be plotted
    wind_ds: xarray
        xarray dataset with coordinates _datetime or time, parameter, instrument, model and data ts_value
        The data must contain SWD and SWS as wind direction and wind speed
    time_name: str
        name of the time variable (_datetime or time)
    add_limits: bool
        boolean indicating if the regulatory limits should be plotted
    lod_df: pandas dataframe
        pandas dataframe containing the limit of detection for any of the compounds to be ploted    
    '''
    
    # def time_conversion(ds, time_name, vars_name = 'fitter_values'):
    #     if time_name == '_datetime':
    #         return ds.apply(lambda x: x._datetime.dt.hour + x._datetime.dt.minute/60 + x._datetime.dt.second/60/60)[vars_name]
    #     else:
    #         return ds.time    
    
    # Set up the subplot
    fig = make_subplots(
        rows=1 if wind_ds is None else 3,
        cols=1,
        horizontal_spacing=0.04,
        vertical_spacing=0.03,
        shared_xaxes=True,
    )

    median_values = ds.sel(fitter_var=compound_name, port=1, quantile=0.5).fitter_values
    lower_quant_values = ds.sel(fitter_var=compound_name, port=1, quantile=0.25).fitter_values
    upper_quant_values = ds.sel(fitter_var=compound_name, port=1, quantile=0.75).fitter_values
    fig.add_trace(
        go.Scattergl(
            x=time_conversion(ds,time_name),
            y=median_values,
            mode="markers",
            marker_color='grey',
            name=compound_name,  
            opacity=0.5,
            showlegend=False,
            error_y=dict(
                type='data', # value of error bar given in data coordinates
                symmetric = False,
                array=upper_quant_values - median_values,
                arrayminus = median_values - lower_quant_values,
                visible=True,
                width=2,
            ),
        ),
        row=1,
        col=1,
    )


    data_min = np.nanmin(lower_quant_values)
    data_max = np.nanmax(upper_quant_values)
    update_bool = False
    if add_limits and compound_name in ACTION_LIMITS:
        fig.add_hline(
            y=ACTION_LIMITS[compound_name],
            line_dash='dash',
            line_color='red',
            opacity=0.5,
            row=1,
            col=1
        )
        
        data_max = np.max((data_max, ACTION_LIMITS[compound_name]))
        update_bool = True
        
    
    if lod_df is not None:
        if compound_name in lod_df:
            fig.add_hline(
                y=lod_df[compound_name],
                line_dash='dash',
                line_color='blue',
                opacity=0.5,
                row=1,
                col=1
            )
            
            data_max = np.max((data_max, lod_df[compound_name]))
            update_bool = True

    if update_bool:
        data_range = data_max - data_min

        fig.update_yaxes(
            range = [data_min - 0.05*data_range, data_max + 0.05*data_range], 
            row=1, 
            col=1
            )
            

    if wind_ds is not None:
        if 'stat' not in wind_ds._coord_names:
            wind_subset = wind_ds 
            std_subset = None
        else:
            wind_subset = wind_ds.sel(stat='mean') 
            std_subset = wind_ds.sel(stat='std') 
        for i, (var, var_name) in enumerate([('SWD', 'wind direction'),('SWS', 'wind speed')]): #wind speed, wind direction
            fig.add_trace(
                go.Scattergl(
                    x=time_conversion(wind_ds, time_name, vars_name='ts_value'),
                    y=wind_subset.sel(parameter=var).ts_value,
                    mode="markers",
                    marker_color='green',
                    name=var_name,
                    showlegend=False,
                    opacity=0.5,
                    error_y=dict(
                        type='data', # value of error bar given in data coordinates
                        array=None if std_subset is None else std_subset.sel(parameter=var).ts_value,
                        visible=True if std_subset else False,
                        width=2,
                        ),
                ),
                row=i+2,
                col=1,
            )

    if compound_name in ['CO2','CH4']:
        fig.update_yaxes(title_text=f'{compound_name} (ppm)', row=1, col=1)
    elif compound_name == 'H2O':
        fig.update_yaxes(title_text=f'{compound_name} (%)', row=1, col=1)
    else:
        fig.update_yaxes(title_text=f'{compound_name} (ppb)', row=1, col=1)
    if wind_ds is not None:
        fig.update_yaxes(
            title_text='Wind Direction', 
            row=2, 
            col=1, 
            range=[0,360],
            tickmode = 'linear',
            tick0 = 0,
            dtick = 60
            )
        fig.update_yaxes(title_text='Wind Speed', row=3, col=1)

    return fig