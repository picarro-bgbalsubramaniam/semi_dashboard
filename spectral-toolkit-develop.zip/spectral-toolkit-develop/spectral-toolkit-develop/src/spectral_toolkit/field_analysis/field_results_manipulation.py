import pandas as pd
import numpy as np
from io import StringIO
import xarray as xr
import os
import collections
from sklearn.cluster import DBSCAN

from spectral_toolkit.scheme_optimizer.reporting import get_pubchem_df
# from spectral_toolkit.td_gc_analysis.utilities_TD import get_peak_time_list_df

# pubchem data to get common names from cids
pc_df = get_pubchem_df()

def retrieve_results(exp_subfolder, solver_name):
    if not exp_subfolder.exists():
        raise ValueError("No data found")
    
    results_folder = exp_subfolder / "results"

    results_txt_file = results_folder / f"{solver_name}.txt"
    
    convert_to_pd = lambda block: pd.read_table(StringIO(block), delimiter = '\s+')
    if results_txt_file.exists():
        #print("Reading existing results")
        with open(results_txt_file, 'r') as file:
            block = file.read()
        conc_table, score_table = block.split('Concentrations')[1].split('Scores')
        if 'mean' not in conc_table: # for correlation plot results
            conc_table = '        mean\n' + conc_table
        df_conc = convert_to_pd(conc_table)
        df_scores = convert_to_pd(score_table)
    else:
        return None, None
        
    q_file = results_folder / f"{solver_name}_Q_values.csv"
    if q_file.exists():
        df_q = pd.read_csv(q_file)
        df_q.set_index('CID', drop=True, inplace=True)
    df_conc['Q'] = 0
    for cid, qvalue in df_q.iterrows():
        df_conc.loc[cid, 'Q'] = qvalue.iloc[0]
    
    return df_conc, df_scores


def get_Q_prob(Q,N,extend_to_Q_below_1=True):
    """args: 
      Q: Q for a given compound in a fit results 
      N: total number of compounds found 
      returns the probability that the found compound was really in the gas sample

      Valid for R3 (running four steps where the Q threshold is lowered with each step)"""
    
    N = np.clip(N, 1, 55)
    
    if extend_to_Q_below_1:
        lowQ = np.ones(Q.shape)
        lowQ[Q<1] = Q[Q<1]
        
        Q = np.clip(Q, 1, np.inf)
    else:
        print('Q less than 1 not allowed')
        return None
        
    A = 0.31407 + 0.202362 / N  - 0.00858516 * N + 0.000113417 * N**2
    B = 3.20283 - 0.0432235 * N + 0.00115416 * N**2
    C = 2.11314 - 0.0687511 * N + 0.000622635 * N**2

    rho = -B * (np.log10(Q - 1) + C)
    f = A + (1 - A) / (1 + np.exp(rho))
    if extend_to_Q_below_1:
        f = lowQ*f
    return f

def weighted_mean(X, W):
    return (X*W).sum() / W.sum()

def calc_prob(dframe):
    for key in ['q_prob', 'peak_len', 'q_sum', 'pos_conc', 'mean_conc', 'T_center', 'T_width', 'T_start', 'T_end']:
        dframe[key] = 0
    
    for j, (_, row) in enumerate(dframe.iterrows()):
        Q = row['Q']
        find_count = row['find_count']
        T = row['T']
        conc = row['conc']
        prob = get_Q_prob(Q, find_count) 
        agg_prob = 0 if row['cluster'] == -1 else 1 - np.prod(1 - prob)
        dframe['q_prob'].iloc[j] = agg_prob
        dframe['peak_len'].iloc[j] = len(T)
        dframe['q_sum'].iloc[j] = (Q).sum()
        dframe['pos_conc'].iloc[j] = np.all(conc>=0)

        dframe['mean_conc'].iloc[j] = weighted_mean(conc, Q)
        T_0 = weighted_mean(T, Q)
        dframe['T_center'].iloc[j] = T_0
        dframe['T_width'].iloc[j] = 2*np.sqrt(weighted_mean((T - T_0)**2, Q))
        dframe['T_start'].iloc[j] = T.min()
        dframe['T_end'].iloc[j] = T.max()
        
    return dframe

def calc_prob_ds(ds):
    # for key in ['q_prob', 'peak_len', 'q_sum', 'pos_conc', 'mean_conc', 'T_center', 'T_width', 'T_start', 'T_end']:
    #     dframe[key] = 0
    
    # for j, (_, row) in enumerate(dframe.iterrows()):
    if ds.sum('expt').clusters_len > 0 and ds.sum(['expt','cluster']).events_len > 0:
        expt_bool = ds.clusters_len > 0
            
        for expt_ind in np.where(expt_bool)[0]:
            test_ds = ds.isel(expt = expt_ind)
            test_ds = test_ds.squeeze()
            cluster_bool = test_ds.events_len > 0
            test_ds = test_ds.isel(cluster = cluster_bool)
            # test_ds = test_ds.squeeze()
            

            for cluster_now in np.arange(-1, ds.clusters_len.max()):
                if cluster_now in test_ds.cluster:
                    ds_now = test_ds.sel(cluster = cluster_now).squeeze()
                    events_bool = ds_now.event_values.notnull().sum(dim='event_var').astype(bool)

                    Q = ds_now.isel(event_num = events_bool).sel(event_var = 'Q').event_values
                    find_count = ds_now.sel(event_num = slice(0, ds_now.events_len-1), event_var = 'find_count').event_values
                    T = ds_now.sel(event_num = slice(0, ds_now.events_len-1), event_var = 'T').event_values
                    conc = ds_now.sel(event_num = ds_now.events_len-1, event_var = 'conc').event_values
                    prob = get_Q_prob(Q, find_count) 

                    agg_prob = 0 if cluster_now == -1 else 1 - np.prod(1-prob)
                    ds['run_values'][expt_ind, ds.run_var == 'q_prob'] = agg_prob
                    ds['run_values'][expt_ind, ds.run_var == 'peak_len'] = len(T)
                    ds['run_values'][expt_ind, ds.run_var == 'q_sum'] = (Q).sum()
                    ds['run_values'][expt_ind, ds.run_var == 'pos_conc'] = np.all(conc>=0)

                    ds['run_values'][expt_ind, ds.run_var == 'mean_conc'] = weighted_mean(conc, Q)

                    T_0 = weighted_mean(T, Q)
                    ds['run_values'][expt_ind, ds.run_var == 'T_center'] = T_0
                    ds['run_values'][expt_ind, ds.run_var == 'T_width'] = 2*np.sqrt(weighted_mean((T - T_0)**2, Q))
                    ds['run_values'][expt_ind, ds.run_var == 'T_start'] = T.min()
                    ds['run_values'][expt_ind, ds.run_var == 'T_end'] = T.max()
        
    return ds

def q_prob_max(dframe):
    dframe.sort_values(['q_prob'], ascending=[False], inplace=True)
    return dframe.iloc[0]

def q_prob_max_ds(ds):
    if ds.expt.size==1:
        ds = ds.squeeze()
        return ds
    else:
        # test_ds = ds.sortby(ds.sel(run_var='q_prob'), ascending=False)
        ind = ds.sel(run_var='q_prob').run_values.argmax(dim='expt').values
        return ds.isel(expt = ind)
    
# def create_prob_ds(
#         ave_path,
#         corr_path,
#         event_start,
#         event_count = 100, 
#         cluster_count = 10
#         ):
#     event_var = ['T','dT','Q','conc','find_count','start_s','end_s']
#     run_var = ['q_prob','peak_len','q_sum','pos_conc','mean_conc','T_center','T_width','T_start','T_end']
    
#     # dfs = pd.DataFrame()    
#     prob_ds = xr.Dataset(
#         data_vars = dict(
#             event_values = (('expt', 'cid', 'event_num', 'cluster', 'event_var'), np.zeros((2, len(pc_df), event_count, cluster_count + 1, len(event_var)))*np.nan),
#             run_values = (('expt', 'cid', 'run_var'), np.zeros((2, len(pc_df), len(run_var)))*np.nan),
#             clusters_len = (('expt', 'cid'), np.zeros((2, len(pc_df)))),
#             events_len = (('expt', 'cid', 'cluster'), np.zeros((2, len(pc_df), cluster_count+1))),
#         ),
#         coords = dict(
#             cid = pc_df.index,
#             event_num = range(event_count),
#             expt = ['corr', 'ave'],
#             event_var = event_var,
#             run_var = run_var,
#             cluster = np.arange(-1, cluster_count)
#         ),
#     )
#     for data_folder, EXPT in zip([ave_path, corr_path],['ave', 'corr']):
#         if os.path.isdir(data_folder) != True:
#             continue
#         subfolders = ([p for p in (data_folder).iterdir() if p.is_dir()])
#         subfolders.sort(key = lambda s: s.name)

#         peaks_df = get_peak_time_list_df(subfolders)

#         plot_dict = {}
#         # mintime = None
#         # maxtime = None
#         if len(peaks_df) > 0:
#             for _, peaks_df_row in peaks_df.iterrows(): #peak_cen
#                 subfolder = peaks_df_row['folder']

#                 tdays = peaks_df_row['start'].timestamp()/3600/24 

#                 df_conc, _ = retrieve_results(subfolder, 'R3_Negs') #df_scores
#                 if df_conc is None: continue
#                 for cid, row in df_conc.iterrows():
#                     if cid not in plot_dict:
#                         plot_dict[cid] = collections.defaultdict(list)
#                     udata = plot_dict[cid]
#                     udata['time'].append(peaks_df_row['start']) 
#                     udata['tdays'].append(tdays)
#                     udata['Q'].append(row['Q'])
#                     udata['conc'].append(row['mean'])
#                     udata['find_count'].append(df_conc.shape[0] - 1)
#                     if EXPT != 'corr':
#                         udata['sigma'].append(row['std'])
#                     udata['start_s'].append((peaks_df_row['start'] - event_start).total_seconds())
#                     udata['end_s'].append((peaks_df_row['end'] - event_start).total_seconds())
   
#             # result_list = []
#             for cid, U in plot_dict.items():
#                 if cid == 0: print('huh')
#                 U2D = [[u, 0] for u in U['tdays']]
#                 CLUSTERING_THRESHOLD_TIME_DAYS = 2
#                 this_cluster = DBSCAN(eps=CLUSTERING_THRESHOLD_TIME_DAYS, min_samples=2).fit(U2D)
#                 prob_ds['clusters_len'][prob_ds.expt == EXPT, prob_ds.cid == cid] = len(set(this_cluster.labels_))
#                 for label in set(this_cluster.labels_):
#                     get_me = lambda name:  np.array(U[name])[this_cluster.labels_ == label]

#                     # prob_ds
#                     len_tdays = len(get_me('tdays'))
#                     prob_ds['event_values'][prob_ds.expt == EXPT, prob_ds.cid == cid, :len_tdays, prob_ds.cluster == label, prob_ds.event_var == 'T'] = get_me('tdays')[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
#                     prob_ds['event_values'][prob_ds.expt == EXPT, prob_ds.cid == cid, :len_tdays, prob_ds.cluster == label, prob_ds.event_var == 'dT'] = np.diff(get_me('tdays'), prepend=get_me('tdays')[0] - 0.5)[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
#                     prob_ds['event_values'][prob_ds.expt == EXPT, prob_ds.cid == cid, :len_tdays, prob_ds.cluster == label, prob_ds.event_var == 'Q'] = get_me('Q')[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
#                     prob_ds['event_values'][prob_ds.expt == EXPT, prob_ds.cid == cid, :len_tdays, prob_ds.cluster == label, prob_ds.event_var == 'conc'] = get_me('conc')[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
#                     prob_ds['event_values'][prob_ds.expt == EXPT, prob_ds.cid == cid, :len_tdays, prob_ds.cluster == label, prob_ds.event_var == 'find_count'] = get_me('find_count')[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
#                     prob_ds['events_len'][prob_ds.expt == EXPT, prob_ds.cid == cid, prob_ds.cluster == label] = len_tdays
#                     prob_ds['event_values'][prob_ds.expt == EXPT, prob_ds.cid == cid, :len_tdays, prob_ds.cluster == label, prob_ds.event_var == 'start_s'] = get_me('start_s')[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
#                     prob_ds['event_values'][prob_ds.expt == EXPT, prob_ds.cid == cid, :len_tdays, prob_ds.cluster == label, prob_ds.event_var == 'end_s'] = get_me('end_s')[np.newaxis, np.newaxis, :, np.newaxis, np.newaxis]
                    

#     prob_ds = prob_ds.drop_isel(cid = ((prob_ds.sum(dim=['cluster','expt']).clusters_len == 0) | (prob_ds.sum(dim=['cluster','expt']).events_len == 0)))
#     prob_ds = prob_ds.groupby('cid').apply(calc_prob_ds)

#     return prob_ds

def get_ds_subset(prob_ds):
    cluster_bool = (prob_ds.events_len > 0).any(dim=['cid','expt'])
    expt_bool = (prob_ds.clusters_len > 0).any(dim='cid')
    event_bool = prob_ds.event_values.notnull().sum(dim=['cid','expt','cluster','event_var'])>0

    return_ds = prob_ds.isel(
        cluster = cluster_bool,
        expt = expt_bool,
        event_num = event_bool
        )
    return return_ds