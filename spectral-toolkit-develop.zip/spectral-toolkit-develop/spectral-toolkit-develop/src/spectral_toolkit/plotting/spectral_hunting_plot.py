"""Create spectral hunting plot"""
from itertools import product
from typing import Dict, List, Optional, Union

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import xarray as xr
from pandas.core.dtypes.common import is_float_dtype, is_integer_dtype
from plotly.subplots import make_subplots
from pydantic import validate_call

from spectral_toolkit.plotting.colors_utils import get_full_colorscale


@validate_call(config=dict(arbitrary_types_allowed=True))
def get_spectral_hunting_plot(
    spectral_fits_ds: xr.Dataset,
    species_colormap: Optional[dict] = None,
    title_text: str = "",
) -> go.Figure:
    """
    Get a spectral hunting plot using Xarray Dataset ``spectral_fit_ds``
    from :py:func:`.define_solutions_spectral_dataset`.

    Args:
        spectral_fits_ds (xr.Dataset):
            Xarray Dataset from :py:func:`.define_solutions_spectral_dataset`.
            Coordinates requested: ``["ranking_by_cid_count",
            "fit_parameters", "wavenumber", "solution",
            "cid", "new_cids_count", "experimental_wavenumber"]``.
            Variable requested: ``["concentrations_cids", "loss_cids",
            "loss_scaled_cids", "summary_table", "new_cids", "new_cids_display",
            "experimental_loss", "experimental_loss_cids",
            "experimental_loss_scaled_cids", "residuals"]``

        species_colormap (dict):
            Dictionary using species CID as key, and color as value,
            for all or some of the CIDs in ``spectral_fits_ds``.
            CIDs that are not explicitly assigned to a color
            will be assigned one automatically.

        title_text (str):
            Title of the plot.

    Returns:
        go.Figure: Plotly spectral hunting Figure.

    """

    if species_colormap is None:
        species_colormap = {}

    check_coordinates = [
        "ranking_by_cid_count",
        "new_cids_count",
        "fit_parameters",
        "wavenumber",
        "solution",
        "cid",
        "experimental_wavenumber",
    ]
    if set(check_coordinates) != set(spectral_fits_ds.coords.variables.mapping):
        raise ValueError("Missing coordinates in spectral_fits_ds")

    check_variables = [
        "concentrations_cids",
        "loss_cids",
        "loss_scaled_cids",
        "summary_table",
        "new_cids",
        "new_cids_display",
        "experimental_loss",
        "experimental_loss_cids",
        "experimental_loss_scaled_cids",
        "residuals",
    ]
    if set(check_variables) != set(spectral_fits_ds.data_vars.variables.mapping):
        raise ValueError("Missing variables in spectral_fits_ds")

    # Create 2x2 grid to host: spectral plot (1,1),
    # residuals difference(2,1), summary table(2,2)
    fig = make_subplots(
        rows=2,
        cols=2,
        row_heights=[0.65, 0.35],
        column_widths=[0.65, 0.35],
        shared_xaxes=True,
        specs=[
            [{"type": "xy"}, None],
            [{"type": "xy"}, {"type": "domain"}],
        ],
        horizontal_spacing=0.01,
        vertical_spacing=0.1,
        subplot_titles=["Loss", "Residuals", "Summary Table"],
    )

    # colors for residuals and for sum of spectral contributions
    base_colors = {
        "Fit result": "rgba(255, 20, 147, 0.8)",
        "residual": "rgba(255, 20, 147, 0.8)",
        "reference": "rgba(30,144,255, 0.8)",
    }

    # Get a full colormap for all CIDs
    colormap_cid = get_full_colorscale(
        all_keys=spectral_fits_ds.cid.values.tolist(),
        discrete_color_map=species_colormap,
    )

    # For every fit solution provided
    for solution in spectral_fits_ds.solution.values:
        solution_xr = spectral_fits_ds.sel(solution=solution)
        current_ranking = solution_xr.ranking_by_cid_count.item()
        cids_count = solution_xr.new_cids_count.item()

        # Scatter trace that sums up all the different spectral contributions
        fig = _add_cumulated_spectra_trace(
            original_fig=fig, solution_xr=solution_xr, traces_color=base_colors
        )

        # Table that summarize the current fit result
        # with respect to the original fit and previous fit with
        # same new CIDs number
        comparison_df = _get_comparison_table(
            spectral_fits_ds,
            ranking_by_cid_count=current_ranking,
            new_cids_count=cids_count,
        )
        fig = _add_comparison_table_trace(
            original_fig=fig,
            comparison_df=comparison_df,
            current_ranking=current_ranking,
            new_cids_count=cids_count,
        )

        # Plot residuals and the original fit residual
        # The original fit residual is always_on
        fig = _add_residuals_trace(
            original_fig=fig,
            wavenumbers=solution_xr["experimental_wavenumber"].to_numpy(),
            residuals=solution_xr["residuals"].to_numpy(),
            current_ranking=current_ranking,
            new_cids_count=cids_count,
            traces_color=base_colors,
        )

        # Plot all the single species contributions
        # that are part of this
        # current fit solution
        for cid in solution_xr.cid.values:
            fig = _add_single_cid_spectrum(
                original_fig=fig,
                single_cid_xr=solution_xr.sel(cid=cid),
                colormap_cid=colormap_cid,
            )

    # Experimental data points
    fig.add_trace(
        go.Scattergl(
            x=spectral_fits_ds["experimental_wavenumber"],
            y=spectral_fits_ds["experimental_loss"],
            mode="markers",
            visible=True,
            name="Experimental",
            meta="always_on",
            marker=dict(size=8, color="rgba(83,104,114,0.8)"),
            showlegend=True,
            hovertemplate="Wavenumber: %{x:.2f}cm<sup>-1</sup><br>Loss: %{y:.6f}",
            legendgroup="Summary",
            legendgrouptitle_text="Summary",
        ),
        row=1,
        col=1,
    )

    # Add zero line
    fig.add_shape(
        x0=0,
        x1=1,
        y0=0,
        y1=0,
        xref="x domain",
        line=dict(color="rgba(169,169,169, 0.3)", width=3),
        row="all",
        col=1,
    )

    # Get all distinct rankings and new cids numbers
    # Exclude zero, as considered as special case and always present
    # (it is the original solution)
    ranks_counts = list(set(spectral_fits_ds.ranking_by_cid_count.values) - set([0]))
    new_cids_counts = list(set(spectral_fits_ds.new_cids_count.values) - set([0]))

    # Get fit sliders
    sliders = _get_fit_selector_slider(
        original_fig=fig, rankings_counts=ranks_counts, new_cids_counts=new_cids_counts
    )

    # Add sliders and adjust template
    fig.update_layout(
        sliders=sliders,
        showlegend=True,
        legend=dict(yanchor="top", y=1, xanchor="left", x=0.65, orientation="h"),
        template="plotly_white",
        xaxis_showticklabels=True,
        title=f"<b>{title_text}</b>",
        xaxis2_title="Wavenumber [cm<sup>-1</sup>]",
    )

    # Position annotations
    for annot in fig.layout.annotations:
        annot.update(x=0 if annot["x"] < 0.65 else 0.65)
        annot.font = dict(color="darkgray", size=14)
        annot.xanchor = "left"

    # Show only the original fit initially
    fig.for_each_trace(
        lambda tr: tr.update(visible=tr.meta in ["Rank 0 - CIDs 0", "always_on"])
    )

    return fig


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_fit_selector_slider(
    original_fig: go.Figure, rankings_counts: List[int], new_cids_counts: List[int]
) -> List[dict]:
    """
    Returns sliders for Plotly layout.
    Layout can be updated as:
    ``fig.update_layout(sliders=_get_fit_selector_slider(...))``

    Args:
        original_fig (go.Figure):
            Plotly figure used to map all the traces and their
            visibility based on slider position.

        rankings_counts (List[int]):
            All the different possible ranking values.

        new_cids_counts (List[int]):
            All the different possible values
            of newly added CIDs (typically 1 to 5).

    Returns:

        List[dict]: Sliders as list of dict for Plotly layout.

    """

    df_meta = _generate_rank_cid_meta_combinations(new_cids_counts, rankings_counts)

    # Create and add slider
    steps = [
        {
            "label": f"{row.meta_label}" if row.ranks in [0, 1] else f"#{row.ranks}",
            "args": [
                {
                    "visible": [
                        tr.meta in [row.meta, "always_on"] for tr in original_fig.data
                    ],
                },
            ],
            "method": "update",
        }
        for row in df_meta.itertuples()
    ]

    sliders = [
        dict(
            active=0,
            currentvalue={"prefix": "<br>", "suffix": "</b>", "visible": False},
            pad={"t": 50},
            steps=steps,
            transition={"duration": 300, "easing": "cubic-in-out"},
        )
    ]

    return sliders


@validate_call()
def _generate_rank_cid_meta_combinations(
    unique_cids_counts: List[int], unique_ranks_counts: List[int]
):
    """
    Generate a dataframe with all possible
    combination of ``unique_cids_counts`` and
    ``unique_ranks_counts``.
    Used to generate labels and data for the
    slider in the spectral hunting plot.

    Args:
        unique_cids_counts (List[int]):
            All the different possible values
            of newly added CIDs (typically 1 to 5).

        unique_ranks_counts (List[int]):
            All the different possible ranking values.

    Returns:
          pd.DataFrame: Dataframe with combinations
              ranked by ascending cids, ranks.

    >>> _generate_rank_cid_meta_combinations([1, 2, 3], [1, 2])
       ranks  cids             meta                  meta_label
    6      0     0  Rank 0 - CIDs 0  #0<br><b>0 new<br>CIDs</b>
    0      1     1  Rank 1 - CIDs 1  #1<br><b>1 new<br>CIDs</b>
    3      2     1  Rank 2 - CIDs 1  #2<br><b>1 new<br>CIDs</b>
    1      1     2  Rank 1 - CIDs 2  #1<br><b>2 new<br>CIDs</b>
    4      2     2  Rank 2 - CIDs 2  #2<br><b>2 new<br>CIDs</b>
    2      1     3  Rank 1 - CIDs 3  #1<br><b>3 new<br>CIDs</b>
    5      2     3  Rank 2 - CIDs 3  #2<br><b>3 new<br>CIDs</b>

    """

    df_combinations = pd.DataFrame(
        list(product(unique_ranks_counts, unique_cids_counts)),
        columns=["ranks", "cids"],
    )

    df_combinations = pd.concat(
        [df_combinations, pd.DataFrame(data={"ranks": [0], "cids": [0]})],
        ignore_index=True,
    )

    df_combinations = df_combinations.assign(
        meta="Rank "
        + df_combinations.ranks.astype(str)
        + " - CIDs "
        + df_combinations.cids.astype(str)
    )
    df_combinations = df_combinations.assign(
        meta_label="#"
        + df_combinations.ranks.astype(str)
        + "<br><b>"
        + df_combinations.cids.astype(str)
        + " new<br>CIDs</b>"
    )
    df_combinations = df_combinations.sort_values(by=["cids", "ranks"], ascending=True)

    return df_combinations


@validate_call()
def _assign_trace_metadata(ranking_by_cid_count: int, new_cids_count: int) -> str:
    """
    Generate a meta label for a plot trace,
    given its ranking (CID-based) and the number of
    new CIDs that were added.

    Args:
        ranking_by_cid_count (int):
            Ranking with respect to other solution
            with same number of newly added CIDs.

        new_cids_count (int):
            Number of new CIDs that were added
            in the current solution.

    Returns:
        str: Label to be used in ``meta`` Plotly
            trace argument.

    >>> _assign_trace_metadata(5, 3)
    'Rank 5 - CIDs 3'

    >>> _assign_trace_metadata(1, 4)
    'Rank 1 - CIDs 4'
    """

    return f"Rank {ranking_by_cid_count} - CIDs {new_cids_count}"


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_comparison_table(
    spectral_fits_ds: xr.Dataset, ranking_by_cid_count: int, new_cids_count: int
) -> pd.DataFrame:
    """
    Create a DataFrame representing a single comparison table
    in the spectral hunting plot.

    Args:

        spectral_fits_ds (xr.Dataset):
            Xarray Dataset from :py:func:`.define_solutions_spectral_dataset`.
            Coordinates requested: ``["ranking", "fit_parameters", "wavenumber",
            "cid", "experimental_wavenumber"]``.

        ranking_by_cid_count (int):
            Ranking with respect to other solution
            with same number of newly added CIDs.

        new_cids_count (int):
            Number of new CIDs that were added
            in the current solution.

    Returns:
        pd.DataFrame: comparison table.

    """

    check_coordinates = ["ranking_by_cid_count", "new_cids_count", "fit_parameters"]
    if not set(check_coordinates).issubset(
        set(spectral_fits_ds.coords.variables.mapping)
    ):
        raise ValueError(
            "Missing ranking/fit_parameters coordinates in spectral_fits_ds"
        )

    if not set(["summary_table"]).issubset(
        set(spectral_fits_ds.data_vars.variables.mapping)
    ):
        raise ValueError("Missing summary_table variable in spectral_fits_ds")

    if new_cids_count > spectral_fits_ds.new_cids_count.max().item():
        raise ValueError("No solutions with the selected number of new CIDs")

    if (
        ranking_by_cid_count
        > spectral_fits_ds["ranking_by_cid_count"]
        .where(spectral_fits_ds.new_cids_count == new_cids_count)
        .max()
        .item()
    ):
        raise ValueError("Selected ranking is larger than number of stored solutions")

    # Get parameter names without underscores to allow
    # word wrapping in table
    parameters = [
        parameter.replace("_", " ")
        for parameter in spectral_fits_ds.fit_parameters.values
    ]

    # Parameters values for current solutions
    current_values = (
        spectral_fits_ds["summary_table"]
        .where(
            (spectral_fits_ds.ranking_by_cid_count == ranking_by_cid_count)
            & (spectral_fits_ds.new_cids_count == new_cids_count),
            drop=True,
        )
        .values.ravel()
    )

    # Parameters values for original fit solution
    reference_values = spectral_fits_ds["summary_table"].sel(solution=0).values.ravel()

    # Parameters values for previous ranked solution
    if ranking_by_cid_count > 1:
        previous_values = (
            spectral_fits_ds["summary_table"]
            .where(
                (spectral_fits_ds.ranking_by_cid_count == ranking_by_cid_count - 1)
                & (spectral_fits_ds.new_cids_count == new_cids_count),
                drop=True,
            )
            .values.ravel()
        )
    else:
        previous_values = reference_values

    # Do not raise error for division by zero. Just set to NaN
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio_original = (reference_values - current_values) / reference_values
        ratio_last = (previous_values - current_values) / previous_values

    ret_df = pd.DataFrame(
        data={
            "parameters": parameters,
            "current_fit_values": current_values,
            "improvement_original": ratio_original,
            "improvement_previous": ratio_last,
        }
    )

    ret_df = ret_df.fillna(0)

    # Assign green for (+), red for (-), black for neutral improvements...
    # ... wrt original solution
    ret_df = ret_df.assign(
        color_original_improvement=[
            "seagreen" if val > 0 else ("darkslategray" if val == 0 else "darkred")
            for val in ret_df.improvement_original
        ]
    )

    # ... and wrt previous solution
    ret_df = ret_df.assign(
        color_previous_improvement=[
            "seagreen" if val > 0 else ("darkslategray" if val == 0 else "darkred")
            for val in ret_df.improvement_previous
        ]
    )

    return ret_df


@validate_call(config=dict(arbitrary_types_allowed=True))
def _add_comparison_table_trace(
    original_fig: go.Figure,
    comparison_df: pd.DataFrame,
    current_ranking: int,
    new_cids_count: int,
) -> go.Figure:
    """
    Add a summary table trace to a figure.

    Args:
        original_fig (go.Figure):
            Original Plotly figure.

        comparison_df (pd.DataFrame):
            Summary table dataframe from
            `._get_comparison_table()`.

        current_ranking (int):
            Ranking with respect to other solution
            with same number of newly added CIDs.

        new_cids_count (int):
            Number of new CIDs that were added
            in the current solution.


    Returns:
        go.Figure: Figure with added comparison table.

    """

    if not set(comparison_df.columns) == set(
        [
            "parameters",
            "current_fit_values",
            "improvement_original",
            "improvement_previous",
            "color_original_improvement",
            "color_previous_improvement",
        ]
    ):
        raise ValueError("comparison_df has missing columns")

    ret_fig = go.Figure(original_fig)
    ret_fig.add_trace(
        go.Table(
            columnwidth=[0.5, 0.25, 0.25],
            header=dict(
                values=[
                    "<b>param</b>",
                    "<b>value</b>",
                    "<b>[imp base]</b>",
                    "<b>[imp prev]</b>",
                ],
                fill_color="rgba(255,255,255,1)",
                align="left",
            ),
            cells=dict(
                values=[
                    comparison_df.parameters,
                    comparison_df.current_fit_values,
                    comparison_df.improvement_original,
                    comparison_df.improvement_previous,
                ],
                align=["left", "right", "right", "right"],
                format=["", ".5f", ">+7.2%", ">+7.2%"],
                fill_color="rgba(255,255,255,1)",
                line_color="rgba(255,255,255,1)",
                font_family="monospace",
                font_color=[
                    np.repeat("darkslategray", len(comparison_df)),
                    np.repeat("darkslategray", len(comparison_df)),
                    comparison_df.color_original_improvement,
                    comparison_df.color_previous_improvement,
                ],
            ),
            meta=_assign_trace_metadata(current_ranking, new_cids_count),
        ),
        row=2,
        col=2,
    )

    return ret_fig


@validate_call(config=dict(arbitrary_types_allowed=True))
def _add_residuals_trace(
    original_fig: go.Figure,
    wavenumbers: np.ndarray,
    residuals: np.ndarray,
    current_ranking: int,
    new_cids_count: int,
    traces_color: Dict[str, str],
) -> go.Figure:
    """
    Add a summary table trace to a figure.

    Args:
        original_fig (go.Figure):
            Original Plotly figure.

        wavenumbers (np.ndarray):
            Array of wavenumbers to be plotted
            on the x-axis.

        residuals (np.ndarray):
            Array of residuals to be plotted
            on the y-axis.

        current_ranking (int):
            Ranking with respect to other solution
            with same number of newly added CIDs.

        new_cids_count (int):
            Number of new CIDs that were added
            in the current solution.

        traces_color (Dict[str, str]):
            Dictionary with keys ``residual`` and
            ``reference``, and associated rgb colors
            as value.

    Returns:
        go.Figure: Figure with added spectral residuals trace.

    """

    if not all(trace_name in traces_color for trace_name in ["residual", "reference"]):
        raise ValueError("No `residual` or `reference` in trace_colors")

    ret_fig = go.Figure(original_fig)
    ret_fig.add_trace(
        go.Scattergl(
            x=wavenumbers,
            y=residuals,
            visible=False,
            name="residual",
            legendgroup=f"{current_ranking}",
            meta=f"{_assign_trace_metadata(current_ranking, new_cids_count)}"
            if current_ranking != 0
            else "always_on",
            mode="markers",
            marker_size=7,
            marker_color=traces_color["residual"]
            if current_ranking != 0
            else traces_color["reference"],
            showlegend=False,
            hovertemplate="<br>Wavenumber: %{x:.2f}cm<sup>-1</sup><br>Residual: %{y:.6f}",
        ),
        row=2,
        col=1,
    )

    return ret_fig


@validate_call(config=dict(arbitrary_types_allowed=True))
def _add_cumulated_spectra_trace(
    original_fig: go.Figure, solution_xr: xr.Dataset, traces_color: Dict[str, str]
) -> go.Figure:
    """
    Add a summary table trace to a figure.

    Args:
        original_fig (go.Figure):
            Original Plotly figure.

        solution_xr (xr.DataSet):
            Current solution to be plotted.

        traces_color (Dict[str, str]):
            Dictionary with keys ``Fit result`` and
            ``reference``, and associated rgb colors
            as value.

    Returns:
        go.Figure: Figure with added cumulative spectra trace.

    """

    if not all(
        trace_name in traces_color for trace_name in ["Fit result", "reference"]
    ):
        raise ValueError("No `Fit result` or `reference` in trace_colors")

    check_coordinates = [
        "solution",
        "cid",
        "ranking_by_cid_count",
        "new_cids_count",
        "wavenumber",
    ]
    if not set(check_coordinates).issubset(set(solution_xr.coords.variables.mapping)):
        raise ValueError(f"Missing {check_coordinates} coordinates in spectral_fits_ds")

    check_vars = [
        "concentrations_cids",
        "new_cids",
        "loss_scaled_cids",
        "new_cids_display",
    ]
    if not set(check_vars).issubset(set(solution_xr.data_vars.variables.mapping)):
        raise ValueError(f"Missing {check_vars} variable in single_cid_xr")

    ret_fig = go.Figure(original_fig)

    solution = solution_xr.solution.item()
    current_ranking = solution_xr.ranking_by_cid_count.item()
    cids_count = solution_xr.new_cids_count.item()

    # Line that sums up all the different spectral contributions
    ret_fig.add_trace(
        go.Scattergl(
            x=solution_xr["wavenumber"],
            y=solution_xr["loss_scaled_cids"].sum(dim="cid"),
            mode="lines",
            hovertemplate=f"New CIDs:<br><b>"
            f"{solution_xr['new_cids_display'].item()}"
            f"</b><br><br>Wavenumber: %{{x:.2f}}cm<sup>-1</sup>"
            f"<br>Loss: %{{y:.6f}}",
            visible=False,
            name="Fit result",
            meta=_assign_trace_metadata(current_ranking, cids_count),
            line_width=4.5,
            showlegend=True,
            line_color=traces_color["Fit result"]
            if solution != 0
            else traces_color["reference"],
            legendgroup="Summary",
            legendgrouptitle_text="Summary",
        ),
        row=1,
        col=1,
    )

    return ret_fig


@validate_call(config=dict(arbitrary_types_allowed=True))
def _add_single_cid_spectrum(
    original_fig: go.Figure, single_cid_xr: xr.Dataset, colormap_cid: Dict[str, str]
) -> go.Figure:
    """
    Add the species-specific absorbance contribution
    as a Plotly trace, if the concentration value
    is finite.

    Args:
        original_fig (go.Figure):
            Original Plotly figure.

        single_cid_xr (xr.DataSet):
            Current solution to be plotted for a single
            CID.

        colormap_cid (Dict[str,str]):
            Dict with CID as key, color as value.

    Returns:
        go.Figure: Figure with added species-specific absorbance contribution.

    """

    check_coordinates = ["cid", "ranking_by_cid_count", "new_cids_count", "wavenumber"]
    if not set(check_coordinates).issubset(set(single_cid_xr.coords.variables.mapping)):
        raise ValueError(
            "Missing ['cid', 'ranking_by_cid_count', "
            "'new_cids_count', 'wavenumber'] coordinates in spectral_fits_ds"
        )

    check_vars = ["concentrations_cids", "new_cids", "loss_scaled_cids"]
    if not set(check_vars).issubset(set(single_cid_xr.data_vars.variables.mapping)):
        raise ValueError(f"Missing {check_vars} variable in single_cid_xr")

    if single_cid_xr.cid.size != 1:
        raise ValueError(
            "_add_single_cid_spectrum shall have only"
            "one CID present. Use `.sel(cid=xyz)` to"
            "get a single cid dataset."
        )

    if not colormap_cid.get(str(single_cid_xr.cid.item()), None):
        raise ValueError("colormap_cid must contain the cid key")

    ret_fig = go.Figure(original_fig)

    concentration_value = single_cid_xr["concentrations_cids"].item()
    current_cid = single_cid_xr["cid"].item()
    current_ranking = single_cid_xr.ranking_by_cid_count.item()
    cids_count = single_cid_xr.new_cids_count.item()

    if np.isfinite(concentration_value):
        is_new_cid = str(current_cid) in str(single_cid_xr["new_cids"].item())

        ret_fig.add_trace(
            go.Scattergl(
                x=single_cid_xr["wavenumber"],
                y=single_cid_xr["loss_scaled_cids"],
                mode="lines",
                visible=False,
                name=f"{concentration_value:.3f}ppb {current_cid}",
                meta=_assign_trace_metadata(current_ranking, cids_count),
                line_color=colormap_cid[str(current_cid)],
                line_width=3.5 if is_new_cid else 2,
                opacity=0.65,
                hovertemplate=f"CID: {current_cid} {'(<b>NEW!</b>)' if is_new_cid else ''}<br>"
                f"Concentration: {concentration_value:.3f}ppb<br>"
                f"<br>Wavenumber: %{{x:.2f}}cm<sup>-1</sup><br>Loss: %{{y:.6f}}",
                legendgroup="New" if is_new_cid else "Original",
                legendgrouptitle_text="New CIDs:" if is_new_cid else "Original CIDs:",
            ),
            row=1,
            col=1,
        )

    return ret_fig


@validate_call(config=dict(arbitrary_types_allowed=True))
def fit_result_plot(
    experimental_datapoints: pd.Series,
    absorption_df: pd.DataFrame,
    concentrations: pd.Series,
    annotations: Optional[str] = None,
    species_colormap: Optional[dict] = None,
    title_text: str = "",
) -> go.Figure:
    """
    Spectral hunting plot for a single
    fit solution.

    Args:
        experimental_datapoints (pd.Series):
            Measured absorbtion/partial fit as values,
            wavenumbers as index.
            Dimensions: (#modes)

        absorption_df (pd.DataFrame):
            Result of the spectral fit.
            Each column is the individual contribution
            to the total spectral absorption/partial fit
            from every CID.
            In other words, each column is a CID
            basis function times its concentration
            (from fitting)
            CIDs as columns, wavenumbers as index.
            Must have wavenumbers (float) as index.
            Dimensions: (#modes x #cids)

        concentrations (pd.Series):
            Concentrations of each CID
            resulting from the fit.
            Concentrations as values,
            CID as index.
            Dimensions: (#cids)

        annotations (str):
             String to add as annotation.

        species_colormap (dict):
            Dictionary using species CID as key, and color as value,
            for all or some of the CIDs in ``spectral_fits_ds``.
            CIDs that are not explicitly assigned to a color
            will be assigned one automatically.

        title_text (str):
            Title of the plot.

    Returns:
        go.Figure: Plotly spectral hunting Figure.

    """

    if experimental_datapoints.shape[0] != absorption_df.shape[0]:
        raise ValueError(
            "Number of wave numbers must match between "
            "experimental_datapoints and"
            "absorption_df"
        )

    if concentrations.shape[0] != absorption_df.shape[1]:
        raise ValueError(
            "Number of CIDs must match between concentrations and absorption_df"
        )

    if not is_float_dtype(absorption_df.index.dtype):
        raise TypeError("Absorption_df index must contain wave numbers of float type")

    if not is_integer_dtype(absorption_df.columns.dtype):
        raise TypeError(
            "Columns of absorption_df contain" "CID numbers and must be integers"
        )

    if len(set(absorption_df.columns).symmetric_difference(concentrations.index)) > 0:
        raise ValueError(
            "Columns of absorption_df must match" "index of concentrations"
        )

    total_absorption = absorption_df.sum(axis=1)
    residuals = experimental_datapoints - total_absorption

    # Create 2x2 grid to host: spectral plot (1,1),
    # residuals difference(2,1), summary table(2,2)
    fig = make_subplots(
        rows=2,
        cols=2,
        row_heights=[0.65, 0.35],
        column_widths=[0.90, 0.1],
        shared_xaxes=True,
        specs=[
            [{"type": "xy"}, None],
            [{"type": "xy"}, {"type": "xy"}],
        ],
        horizontal_spacing=0.05,
        vertical_spacing=0.1,
        subplot_titles=["Loss", "Residuals", "Residuals Histogram"],
    )

    # colors for residuals and for sum of spectral contributions
    traces_color = {
        "Fit result": "rgba(255, 20, 147, 0.8)",
        "residual": "rgba(255, 20, 147, 0.8)",
        "reference": "rgba(30,144,255, 0.8)",
    }

    # Get a full colormap for all CIDs
    if species_colormap is None:
        species_colormap = {}

    colormap_cid = get_full_colorscale(
        all_keys=list(concentrations.index.astype(str)),
        discrete_color_map=species_colormap,
    )

    # Experimental data points
    fig.add_trace(
        go.Scattergl(
            x=experimental_datapoints.index,
            y=experimental_datapoints,
            mode="markers",
            visible=True,
            name="Experimental",
            marker=dict(size=8, color="rgba(83,104,114,0.8)"),
            showlegend=True,
            hovertemplate="Wavenumber: %{x:.2f}cm<sup>-1</sup><br>Loss: %{y:.6f}",
        ),
        row=1,
        col=1,
    )

    # Scatter trace that sums up all the different spectral contributions
    fig.add_trace(
        go.Scattergl(
            x=total_absorption.index,
            y=total_absorption,
            mode="lines",
            hovertemplate=f"</b><br><br>Wavenumber: %{{x:.2f}}cm<sup>-1</sup>"
            f"<br>Loss: %{{y:.6f}}",
            visible=True,
            name="Fit result",
            line_width=4.5,
            showlegend=True,
            line_color=traces_color["Fit result"],
        ),
        row=1,
        col=1,
    )

    # Plot residuals and the original fit residual
    fig.add_trace(
        go.Scattergl(
            x=residuals.index,
            y=residuals,
            visible=True,
            name="residual",
            mode="markers",
            marker_size=7,
            marker_color=traces_color["residual"],
            showlegend=False,
            hovertemplate="<br>Wavenumber: %{x:.2f}cm<sup>-1</sup><br>Residual: %{y:.6f}",
        ),
        row=2,
        col=1,
    )

    # Plot all the single species contributions
    # that are part of this
    # current fit solution
    for cid in absorption_df.columns:
        concentration_value = concentrations.loc[cid]
        fig.add_trace(
            go.Scattergl(
                x=absorption_df.index,
                y=absorption_df.loc[:, cid],
                mode="lines",
                visible=True,
                name=f"{concentration_value:.3f}ppb {cid}",
                line_color=colormap_cid[str(cid)],
                line_width=2,
                opacity=0.65,
                hovertemplate=f"CID: {cid}<br>"
                f"Concentration: {concentration_value:.3f}ppb<br>"
                f"<br>Wavenumber: %{{x:.2f}}cm<sup>-1</sup><br>Loss: %{{y:.6f}}",
            ),
            row=1,
            col=1,
        )

    # Residuals histogram
    fig.add_trace(
        go.Histogram(
            y=residuals,
            name="Residuals Hist",
            marker_color=traces_color["residual"],
            showlegend=False,
            histnorm="probability",
        ),
        row=2,
        col=2,
    )

    # Add zero line
    fig.update_yaxes(zeroline=True, zerolinewidth=3, zerolinecolor="rgba(169,169,169, 0.3)")


    # Add sliders and adjust template
    fig.update_layout(
        showlegend=True,
        legend=dict(yanchor="top", y=1, xanchor="right", x=1, orientation="v"),
        template="plotly_white",
        xaxis_showticklabels=True,
        title=f"<b>{title_text}</b>",
        xaxis2_title="Wavenumber [cm<sup>-1</sup>]",
    )

    # Position annotations
    for annot in fig.layout.annotations:
        annot.update(x=0 if annot["x"] < 0.9 else 0.9)
        annot.font = dict(color="darkgray", size=14)
        annot.xanchor = "left"

    if annotations:
        fig.add_annotation(
            x=0.9,
            y=0.55,
            xref="paper",
            yref="paper",
            yanchor="top",
            xanchor="left",
            text=annotations,
            align="left",
            font_family="monospace",
            yshift=10,
            showarrow=False,
        )

    return fig


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_performance_string(performance: pd.Series) -> str:
    """
    Given a series with performance indexes (as index)
    and their values (as values), generate a single
    string by concatenation.

    >>> test = pd.Series(data={"score": 1, "other": 2})
    >>> _get_performance_string(test)
    'score&nbsp;&nbsp;&nbsp;=&nbsp;1.00000<br>other&nbsp;&nbsp;&nbsp;=&nbsp;2.00000'

    >>> _get_performance_string(pd.Series([]))
    Traceback (most recent call last):
    ValueError: Performance series must be non-empty

    Args:
        performance (pd.Series):
            Performance indexes and their values.

    Returns:
        str: Summary string

    """
    if performance.empty:
        raise ValueError("Performance series must be non-empty")

    my_str = "<br>".join(
        [f"{name:8}= {val:.5f}" for name, val in zip(performance.index, performance)]
    )
    my_str = my_str.replace(" ", "&nbsp;")
    return my_str
