"""
Utils to create a summary plot with all variables and sensors data
"""
import math
from typing import List

import numpy as np
import plotly.graph_objects as go
import xarray as xr
from plotly.subplots import make_subplots
from pydantic import validate_call

from spectral_toolkit.constants.plotting_constants import Averaging
from spectral_toolkit.plotting.port_average_plot_plotly import rgb_to_rgba


@validate_call()
def _get_subplots_variables(
    sensor_vars: List[str], species_vars: List[str], columns_number: int
) -> List[str]:
    """
    Arrange subplots to have sensors data shown first
    on a separate row(s), and a blank row between
    sensors and species (padding with empty strings).

    Args:
        sensor_vars (List[str]):
            List of sensor measurement names.

        species_vars (List[str]):
            List of species measurement names.

        columns_number (int):
            Number of columns in the plot.

    Returns:
         List[str]: List of subplots variables/titles.

    Example:

    >>> _get_subplots_variables(["S1", "S2"], ["C1", "C2", "C3", "C4", "C5"], 4)
    ['C1', 'C2', 'C3', 'C4', 'C5', '', '', '', '', '', '', '', 'S1', 'S2']


    >>> _get_subplots_variables(["S1", "S2"], ["C1", "C2", "C3", "C4", "C5"], 3)
    ['C1', 'C2', 'C3', 'C4', 'C5', '', '', '', '', 'S1', 'S2']

    >>> _get_subplots_variables(["S1", "S2"], ["C1", "C2", "C3", "C4", "C5"], 5)
    ['C1', 'C2', 'C3', 'C4', 'C5', '', '', '', '', '', 'S1', 'S2']

    """

    nconcs = len(species_vars)
    pad_length = (
        0 if nconcs % columns_number == 0 else columns_number - nconcs % columns_number
    )

    subplots_list = np.pad(
        array=species_vars,
        pad_width=(
            0,
            pad_length + columns_number,
        ),
        mode="constant",
        constant_values="",
    ).tolist()
    subplots_list += sensor_vars

    return subplots_list


@validate_call(config=dict(arbitrary_types_allowed=True))
def _set_sections_annotations(
    original_fig: go.Figure, subplots_names: List[str]
) -> go.Figure:
    """
    Set `Sensor data` and `Concentration data` annotations
    in existing summary plot.

    Args:
        original_fig (go.Figure):
            Plotly summary plot figure.

        subplots_names (List[str]):
            List of variables/subplots present in ``original_fig``.

    Returns:
        go.Figure: New Plotly figure with added annotations.

    """

    return_fig = go.Figure(original_fig)

    return_fig.update_annotations(font_size=13)

    # Add sensor data label
    return_fig.add_annotation(
        text="<b>Concentration data</b>",
        x=0,
        xref="x domain",
        xanchor="left",
        y=1.02,
        yanchor="bottom",
        yref="paper",
        showarrow=False,
        font=dict(size=14.5, color="rgba(88,88,88, 0.8)"),
    )

    # Get the y-coordinate related to the first concentration subplot
    last_index_of = len(subplots_names) - subplots_names[::-1].index("") + 1
    y_concentration_row = return_fig.layout[f"yaxis{last_index_of}"].domain[1] + 0.03

    # Add concentration data label
    return_fig.add_annotation(
        text="<b>Sensor data</b>",
        x=0,
        xref="x domain",
        xanchor="left",
        y=y_concentration_row,
        yanchor="bottom",
        yref="paper",
        showarrow=False,
        font=dict(size=14.5, color="rgba(88,88,88, 0.8)"),
    )

    return return_fig


@validate_call(config=dict(arbitrary_types_allowed=True))
def _adjust_layout(original_fig: go.Figure, subplots_names: List[str]) -> go.Figure:
    """
    Visual adjustments to layout of summary plot.

    Args:
        original_fig (go.Figure):
            Plotly summary plot figure.

        subplots_names (List[str]):
            List of variables/subplots present in ``original_fig``.

    Returns:
        go.Figure: Plotly figure with adjusted layout.

    """
    return_fig = go.Figure(original_fig)

    # Show only first element of each legend-group
    names = set()
    return_fig.for_each_trace(
        lambda trace: trace.update(showlegend=False)
        if (trace.name in names)
        else names.add(trace.name)
    )

    # Set horizontal legend and title positions
    return_fig.update_layout(
        template="plotly_white",
        margin_t=120,
        legend=dict(
            orientation="h",
            y=1.06,
            yanchor="bottom",
            title="<b>Ports:</b>",
            font_size=14,
        ),
        title=dict(
            text="<b>Summary plot</b>",
            y=0.98,
            x=0,
            xref="paper",
            yanchor="bottom",
            yref="container",
        ),
    )

    # Add framing of subplots
    return_fig.update_xaxes(showline=True, linewidth=2, linecolor="black", mirror=True)
    return_fig.update_yaxes(showline=True, linewidth=2, linecolor="black", mirror=True)

    return_fig = _set_sections_annotations(
        original_fig=return_fig, subplots_names=subplots_names
    )

    return return_fig


@validate_call()
def _get_row_heights(rows_no: int, cols_no: int, concentration_vars_count: int) -> List[float]:
    """
    Set a thin empty row between sensors subplots
    and vars subplots,
    then divide the rest of the height
    among all other subplot rows.

    Args:
        rows_no (int): Number of subplot rows.

        cols_no (int): Number of subplot columns.

        concentration_vars_count (int): Number of concentration data variables.

    Returns:
        List[float]: List of row heights as fraction of plot area.
    """

    thin_row_height = 0.05
    rows_heights = [(1 - thin_row_height) / (rows_no - 1) for _ in range(rows_no)]
    index_thin = (
        concentration_vars_count // cols_no
        if concentration_vars_count % cols_no == 0
        else concentration_vars_count // cols_no + 1
    )
    rows_heights[index_thin] = thin_row_height

    return rows_heights


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_averaging_from_xray(resampled_xr: xr.Dataset) -> str:
    """
    Return the averaging value used
    if present as attribute in the
    xarray Dataset. If not, returns "NA".

    Args:
        resampled_xr (xr.Dataset): Resampled Xarray Dataset.

    Returns:
        str: Averaging value in text.
    """

    try:
        requested_avg_str = resampled_xr.attrs["requested_avg"].value.replace(
            "T", "min"
        )
    except KeyError:
        requested_avg_str = "NA"

    return requested_avg_str


@validate_call(config=dict(arbitrary_types_allowed=True))
def get_summary_plot(
    resampled_xr: xr.Dataset, colorscale_ports: dict, columns_no: int = 4
) -> go.Figure:
    """
    Returns a time-series summary plot including
    sensor data and concentration data.

    Args:
        resampled_xr (xr.Dataset):
            Resampled Xarray Dataset from :py:func:`.resample_dataset_xr`.
            It has an attributes ``requested_avg`` (containing a
            :py:data:`.Averaging` object), ``sensor_vars`` and
            species_vars (lists of sensor/species variables
            as they appear in ``resampled_xr["variable_name"]``).

        colorscale_ports (dict):
            Dictionary with variable name as ``key`` (as it appears
            in ``resampled_xr["port"]``) and a correspondent color as
            ``value``.

        columns_no (int):
            Number of subplots columns (>=1).


    Returns:
        go.Figure: Plotly Summary plot.

    """

    if not isinstance(resampled_xr.attrs.get("requested_avg", None), Averaging):
        raise ValueError("Missing requested_avg attribute in resampled_xr")

    if not isinstance(resampled_xr.attrs.get("sensor_vars", None), List):
        raise ValueError("Missing sensor_vars attribute in resampled_xr")

    if not isinstance(resampled_xr.attrs.get("species_vars", None), List):
        raise ValueError("Missing species_vars attribute in resampled_xr")

    if not {"port", "time", "variable_name"}.issubset(resampled_xr.dims.mapping.keys()):
        raise ValueError(
            "dataset_xr shall contain all {port, time, variable_name} coords"
        )

    # Check all ports in resampled_xr are mapped in the colormap
    if not all(port in colorscale_ports for port in resampled_xr.port.values):
        raise ValueError(
            "colorscale_ports shall contain all ports present in resampled_xr"
        )

    if columns_no < 1:
        raise ValueError("columns_no shall be greater or equal than 1")

    if not {"variable_value", "data_points"}.issubset(
        resampled_xr.data_vars.variables.mapping.keys()
    ):
        raise ValueError(
            "dataset_xr shall contain " "`variable_value`, `data_points` variables"
        )

    if not np.issubdtype(resampled_xr.time.dtype, np.datetime64):
        raise ValueError("resampled_xr time is not np.datetime64")

    # Get variables to show in all subplots
    subplots_variables = _get_subplots_variables(
        sensor_vars=resampled_xr.attrs["sensor_vars"],
        species_vars=resampled_xr.attrs["species_vars"],
        columns_number=columns_no,
    )

    # Make sure that the viz order is sensor -> concentrations
    resampled_xr = resampled_xr.reindex(
        {
            "variable_name": resampled_xr.attrs["sensor_vars"]
            + resampled_xr.attrs["species_vars"]
        }
    )

    # Evaluate number of rows needed to fit all subplots
    rows_no = math.ceil(len(subplots_variables) / columns_no)

    # Get rows heights
    rows_heights = _get_row_heights(
        rows_no=rows_no,
        cols_no=columns_no,
        concentration_vars_count=len(resampled_xr.attrs["species_vars"]),
    )

    # Set up the subplot
    fig = make_subplots(
        rows=rows_no,
        cols=columns_no,
        horizontal_spacing=0.04,
        vertical_spacing=0.03,
        shared_xaxes=True,
        subplot_titles=subplots_variables,
        row_heights=rows_heights,
    )

    # Define hover template
    hov_template = (
        f"<b>%{{meta}}</b><br>"
        f"Value: <b>%{{y:.1f}}</b><br>"
        f"Time: %{{x|%Y/%m/%d %H:%M}}"
        f" ({_get_averaging_from_xray(resampled_xr)} averaging)<br>"
        f"%{{hovertext}} data points"
    )

    # Plot every variable in a different subplot
    for index, variable in enumerate(subplots_variables):

        # Skip empty subplots
        if variable:

            # Add one trace for every port and every species
            for port in resampled_xr["port"].values:
                plot_array = resampled_xr.sel(port=port, variable_name=variable)

                fig.add_trace(
                    go.Scattergl(
                        x=plot_array.time,
                        y=plot_array.variable_value,
                        mode="markers",
                        marker_color=rgb_to_rgba(colorscale_ports[port], 0.7),
                        name=port,
                        legendgroup=port,
                        hovertext=plot_array.data_points,
                        hovertemplate=hov_template,
                        meta=variable,
                    ),
                    col=(index % columns_no) + 1,
                    row=(index // columns_no) + 1,
                )

    fig = _adjust_layout(fig, subplots_variables)

    # Synchronize all time axis if requested
    for col in range(columns_no):
        fig.update_xaxes(matches="x", col=1 + col)

    # Show time label for every subplot
    fig.update_xaxes(showticklabels=True)

    return fig
