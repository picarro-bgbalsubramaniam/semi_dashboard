"""This script provides the functions to create
a basic plot (time series with Allan deviation plot)
for the concentration values of one chemical species
across multiple different sampling ports
and save it to different formats (including json)."""
import os
from pathlib import Path
from typing import Tuple

import numpy as np
import pandas as pd
import plotly
import plotly.graph_objects as go
import plotly.io as pio
from plotly.subplots import make_subplots

from spectral_toolkit.constants.plotting_constants import (
    Averaging,
    ConcentrationUnits,
    Orientation,
    PlotFileFormat,
)
from spectral_toolkit.df_operations.timeline_process_df import (
    get_allan_deviation_dataframe,
    get_resampled_df_timeseries,
)

pio.kaleido.scope.mathjax = None


def get_default_basic_plot_averaging(
    time_duration: pd.Timedelta,
) -> Tuple[Averaging, Averaging]:
    """
    According to the duration of the
    experiment to be plotted, provide
    two averaging levels to be plot.

    Args:
        time_duration (pd.Timedelta):
            Time difference between the last
            data point and the first data point
            of an experiment.
    Returns:
        Tuple[Averaging, Averaging]:
            Averaging to request in the
            Allan deviation plot.

    >>> get_default_basic_plot_averaging(pd.Timedelta("1d 15h"))
    (<Averaging.ONE_MINUTE: '1T'>, <Averaging.FIVE_MINUTES: '5T'>)

    >>> get_default_basic_plot_averaging(pd.Timedelta("1d"))
    (<Averaging.TEN_SECONDS: '10S'>, <Averaging.HUNDRED_SECONDS: '100S'>)

    >>> get_default_basic_plot_averaging(pd.Timedelta("8d"))
    (<Averaging.THIRTY_MINUTES: '30T'>, <Averaging.FOUR_HOURS: '4H'>)

    >>> get_default_basic_plot_averaging(pd.Timedelta("25d"))
    (<Averaging.FOUR_HOURS: '4H'>, <Averaging.TWELVE_HOURS: '12H'>)

    >>> get_default_basic_plot_averaging(5)
    Traceback (most recent call last):
    ...
    TypeError: time duration must be a Pandas Timedelta

    """

    if not isinstance(time_duration, pd.Timedelta):
        raise TypeError("time duration must be a Pandas Timedelta")

    if time_duration > pd.Timedelta(days=160):
        # > 5 months
        plotting_requests = (Averaging.ONE_DAY, Averaging.ONE_WEEK)
    elif time_duration > pd.Timedelta(days=90):
        # > 3 month
        plotting_requests = (Averaging.TWELVE_HOURS, Averaging.ONE_DAY)
    elif time_duration > pd.Timedelta(days=24):
        # >24 days
        plotting_requests = (Averaging.FOUR_HOURS, Averaging.TWELVE_HOURS)
    elif time_duration > pd.Timedelta(days=7):
        # > 10 day
        plotting_requests = (Averaging.THIRTY_MINUTES, Averaging.FOUR_HOURS)
    elif time_duration > pd.Timedelta(days=4):
        # > 4 Day
        plotting_requests = (Averaging.FIVE_MINUTES, Averaging.THIRTY_MINUTES)
    elif time_duration > pd.Timedelta(days=1):
        # > 1 Day
        plotting_requests = (Averaging.ONE_MINUTE, Averaging.FIVE_MINUTES)
    elif time_duration > pd.Timedelta(hours=4):
        # > 4 Hrs
        plotting_requests = (Averaging.TEN_SECONDS, Averaging.HUNDRED_SECONDS)
    else:
        # < 4 Hrs
        plotting_requests = (Averaging.ORIGINAL, Averaging.HUNDRED_SECONDS)
    return plotting_requests


def _get_layout_ticks_info(values_series: pd.Series) -> dict:
    """
    Given a Pandas series, returns a dictionary with (tickvals, ticktext) for
    Allan deviation plot logarithmic layout.

    Args:
        values_series (pandas.Series): Starting values from which the
            logarithmic values and text labels are extracted.

    Returns:
        dict: (tickvals, ticktext) pairs.

    """

    if not isinstance(values_series, pd.Series):
        raise TypeError(f"{type(values_series)} is not a Pandas series")

    edges = [min(values_series), max(values_series)]
    decadic_edges = np.floor(np.log10(np.abs(edges))).astype(int)

    tickvals = []
    ticktext = []

    for i_exp in range(decadic_edges[0], decadic_edges[1] + 1, 1):
        tickvals.append(float(f"1E{i_exp}"))
        ticktext.append(f"10<sup>{i_exp}</sup>")

        for minor_tick in range(2, 10, 1):
            tickvals.append(float(f"{minor_tick}E{i_exp}"))
            ticktext.append(" ")

    return dict(zip(tickvals, ticktext))


def _get_layout_decadic_shapes(
    tick_info: dict, lines_orientation: Orientation
) -> tuple:
    """
    Given a (val, text) dictionary and desired shape orientation, returns a tuple with
    plotly.graph_object shapes. Shapes represent the major grid lines and major tick marks.

    Args:
        tick_info (dict): (val, text) dictionary from _get_layout_ticks_info.

        lines_orientation (Orientation): Vertical or Horizontal shapes are desired.

    Returns:
        tuple: Tuples of plotly.graph_object shapes.

    """

    if not isinstance(tick_info, dict):
        raise TypeError(f"{type(tick_info)} is not a dict")

    new_fig = go.Figure()

    major_tick_len_perc = 0.02
    for (tik_val, tik_txt) in tick_info.items():

        if tik_txt.strip():

            if lines_orientation is Orientation.VERTICAL:
                new_fig.add_vline(
                    x=tik_val,
                    line=dict(color="rgba(169,169,169, 0.5)", width=1),
                )

                new_fig.add_shape(
                    type="line",
                    x0=tik_val,
                    x1=tik_val,
                    xref="x",
                    y0=0,
                    y1=major_tick_len_perc,
                    yref="y domain",
                    line=dict(color="black", width=1),
                )

            else:
                new_fig.add_hline(
                    y=tik_val,
                    line=dict(color="rgba(169,169,169, 0.5)", width=1),
                )

                new_fig.add_shape(
                    type="line",
                    y0=tik_val,
                    y1=tik_val,
                    yref="y",
                    x0=1,
                    x1=1 - major_tick_len_perc,
                    xref="x domain",
                    line=dict(color="black", width=1),
                )

    return new_fig.layout.shapes


def _get_allan_factory_line(
    averaging_times_tau_scaled: pd.Series, instrument_sigma: float = np.NaN
) -> zip:
    """
    Given a Pandas series with scaled averaging times (from _get_Allan_deviation_dataframe),
    and an instrument_sigma (provided by Picarro), returns zipped pairs of (x_ref, y_ref) values
     representing the factory expected time response.

    Args:
        averaging_times_tau_scaled (pandas.Series): Scaled averaging times
            (from _get_Allan_deviation_dataframe).

        instrument_sigma (float): Factory instrument sigma provided by Picarro
            and specific to instrument and species.

    Returns:
        zip: (X, Y) coordinate pairs of factory Allan deviation line.

    """

    if not isinstance(averaging_times_tau_scaled, pd.Series):
        raise TypeError(f"{type(averaging_times_tau_scaled)} is not a Pandas series")

    ret_zip = zip()

    if np.isfinite(instrument_sigma):
        x_ref = np.geomspace(
            0.8 * averaging_times_tau_scaled.iloc[0],
            averaging_times_tau_scaled.iloc[-1],
            num=5,
            axis=0,
        ).flat

        y_ref = instrument_sigma / np.sqrt(x_ref)
        ret_zip = zip(x_ref, y_ref)

    return ret_zip


def _add_basic_plot_layout(
    starting_figure: plotly.graph_objects.Figure,
    synchronize_yaxis: bool,
    concentration_units: ConcentrationUnits,
    title_text: str,
    df_allan_dev: pd.DataFrame,
) -> plotly.graph_objects.Figure:
    """
    Returns a new plotly graph_object starting from an initial figure with data traces added,
    after adding titles, shapes, annotations, and tick marks.

    Args:
        starting_figure (plotly.graph_object.Figure): Initial figure.

        synchronize_yaxis (bool): If True, the two time-series subplots are
            synchronized on the y-axis (the x-axis, representing time,
            is always shared between the two subplots).

        concentration_units (ConcentrationUnits): Units for concentration in
            columns of dataframe df.

        title_text (str): Title text to be displayed.

        df_allan_dev (pandas.Dataframe): Pandas dataframe with averaging time
            in seconds and Allan deviation for each averaging time
            (from _get_Allan_deviation_dataframe).

    Returns:
        plotly.graph_object.Figure: Figure with added layout features.

    """

    if not isinstance(starting_figure, plotly.graph_objects.Figure):
        raise TypeError(f"{type(starting_figure)} is not a Figure")

    if not isinstance(df_allan_dev, pd.DataFrame):
        raise TypeError(f"{df_allan_dev} is not a DataFrame")

    fig_return = go.Figure(starting_figure)

    for an_index, annot in enumerate(fig_return.layout.annotations):
        annot.update(x=0.1)
        annot.xref = f"x{'' if an_index == 0 else an_index + 1} domain"
        annot.font = dict(color="darkgray", size=14)

    fig_return.update_layout(template="plotly_white")
    fig_return.update_layout(
        title=dict(text=f"{title_text}", xanchor="center", x=0.5),
    )

    fig_return.update_xaxes(matches="x", row=2, col=1)

    if synchronize_yaxis:
        fig_return.update_yaxes(matches="y", row=2, col=1)

    fig_return.update_yaxes(
        title=f"({concentration_units.value})",
        title_font_color="darkgray",
        row=1,
        col=1,
    )

    fig_return.update_yaxes(
        title=f"({concentration_units.value})",
        title_font_color="darkgray",
        row=2,
        col=1,
    )

    ticks_info_x = _get_layout_ticks_info(df_allan_dev.tau_scaled)
    ticks_info_y = _get_layout_ticks_info(df_allan_dev.allan_dev)
    shapes_y = _get_layout_decadic_shapes(
        ticks_info_y, lines_orientation=Orientation.HORIZONTAL
    )
    shapes_x = _get_layout_decadic_shapes(
        ticks_info_x, lines_orientation=Orientation.VERTICAL
    )

    grid_color = "rgb(250,246,238)"
    fig_return.update_xaxes(
        tickmode="array",
        tickvals=list(ticks_info_x.keys()),
        ticktext=list(ticks_info_x.values()),
        tickangle=0,
        type="log",
        ticks="inside",
        ticklen=3,
        showline=True,
        linecolor="black",
        gridwidth=1,
        gridcolor=grid_color,
        title="Averaging time (sec)",
        mirror="allticks",
        row=1,
        col=2,
    )

    fig_return.update_yaxes(
        tickmode="array",
        tickvals=list(ticks_info_y.keys()),
        ticktext=list(ticks_info_y.values()),
        tickangle=0,
        type="log",
        ticks="inside",
        ticklen=3,
        showline=True,
        linecolor="black",
        gridwidth=1,
        gridcolor=grid_color,
        title="Allan deviation",
        side="right",
        mirror="allticks",
        row=1,
        col=2,
    )

    fig_return.update_layout(
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )

    for shape in shapes_x[1:] + shapes_y:
        fig_return.add_shape(shape, row=1, col=2)

    return fig_return


def get_allan_single_frame(
    port_ts_data: pd.Series, color: str = "black", instrument_sigma: float = np.NaN
) -> plotly.graph_objects.Figure:
    """
    Returns a Plotly figure. It is used to compute an Allan deviation plot on one single port data.

    Args:
        port_ts_data (pandas.Series):
            Series with a ``DateTimeIndex``. Null values in each column are
            needed in order to separate time intervals where the port is not being sampled.
            Time averaging does not occur in regions where null values are present.

        color (str): Color assigned to the trace.

        instrument_sigma (float): Factory instrument sigma provided by Picarro
            and specific to instrument and species.

    Returns:
        plotly.graph_object.Figure: Plotly figure.

        |
    |
    Full usage example:

    df_original::

                                  _datetime  concentration  port
        0     1970-06-16 10:04:20.024999858     -20.774936     2
        1     1970-06-16 10:04:22.881999970       2.173202     2
        ...                             ...            ...   ...
        51263 1970-06-18 07:27:54.296000004      88.928290     2
        51264 1970-06-18 07:27:57.345999956      64.941164     2


    |
    Pivot to get one column (trace) per port:

    .. code-block:: python

        pivot_on = "port"
        df_pivot = df.pivot(
            index="_datetime", columns=pivot_on, values="concentration"
        ).add_prefix(pivot_on)
        df_pivot.columns = df_pivot.columns.get_level_values(0)

    df_pivot (used as input for get_allan_plot_plotly)::

        port                           port1      port2  port3  port4
        _datetime
        1970-06-16 10:04:20.024999858    NaN -20.774936    NaN    NaN
        1970-06-16 10:04:22.881999970    NaN   2.173202    NaN    NaN
        ...                              ...        ...    ...    ...
        1970-06-18 07:27:54.296000004    NaN  88.928290    NaN    NaN
        1970-06-18 07:27:57.345999956    NaN  64.941164    NaN    NaN

    |
    Get one single Series for this plot.

    df_pivot.port2::

        _datetime
        1970-06-16 10:04:20.024999858   -20.774936
        1970-06-16 10:04:22.881999970     2.173202
        1970-06-16 10:04:25.792999982     6.775390
                                           ...
        1970-06-18 07:27:54.296000004    88.928290
        1970-06-18 07:27:57.345999956    64.941164
        Name: port2, Length: 51265, dtype: float64

    |
    Get Plotly Figure.

    .. code-block:: python

        fig = get_allan_single_frame(df_pivot.port2, instrument_sigma=27.2)
        fig.show()

    """

    if not isinstance(port_ts_data.index, pd.DatetimeIndex):
        raise ValueError("Series does not have a DateTimeIndex")

    def _add_allan_single_frame_layout(
        starting_figure: plotly.graph_objects.Figure, df_allan_dev: pd.DataFrame
    ) -> plotly.graph_objects.Figure:
        """
        Returns a new Plotly Figure starting from an initial figure with data traces added,
        after adding titles, shapes, annotations, and tick marks.

        Args:
            starting_figure (plotly.graph_object.Figure): Initial figure.

            df_allan_dev (pandas.Dataframe): Pandas dataframe with averaging time in seconds
             and Allan deviation for each averaging time (from _get_Allan_deviation_dataframe).

        Returns:
            plotly.graph_object.Figure: Figure with added layout features.
        """

        fig_single_allan = go.Figure(starting_figure)

        fig_single_allan.update_layout(template="plotly_white")

        ticks_info_x = _get_layout_ticks_info(df_allan_dev.tau_scaled)
        ticks_info_y = _get_layout_ticks_info(df_allan_dev.allan_dev)
        shapes_y = _get_layout_decadic_shapes(
            ticks_info_y, lines_orientation=Orientation.HORIZONTAL
        )
        shapes_x = _get_layout_decadic_shapes(
            ticks_info_x, lines_orientation=Orientation.VERTICAL
        )

        grid_color = "rgb(250,246,238)"
        fig_single_allan.update_xaxes(
            tickmode="array",
            tickvals=list(ticks_info_x.keys()),
            ticktext=list(ticks_info_x.values()),
            tickangle=0,
            type="log",
            ticks="inside",
            ticklen=3,
            showline=True,
            linecolor="black",
            gridwidth=1,
            gridcolor=grid_color,
            title="Averaging time (sec)",
            mirror="allticks",
        )

        fig_single_allan.update_yaxes(
            tickmode="array",
            tickvals=list(ticks_info_y.keys()),
            ticktext=list(ticks_info_y.values()),
            tickangle=0,
            type="log",
            ticks="inside",
            ticklen=3,
            showline=True,
            linecolor="black",
            gridwidth=1,
            gridcolor=grid_color,
            title="Allan deviation",
            side="right",
            mirror="allticks",
        )

        fig_single_allan.update_layout(
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
        )

        for shape in shapes_x[1:] + shapes_y:
            fig_single_allan.add_shape(shape)

        return fig_single_allan

    fig_allan_dev = go.Figure()

    adev_hov_template = "Time average on %{x:.0f}s<br>Allan deviation: %{y:.2f}"

    df_allan = get_allan_deviation_dataframe(port_ts_data)

    fig_allan_dev.add_trace(
        go.Scatter(
            x=df_allan.tau_scaled,
            y=df_allan.allan_dev,
            name=f"{port_ts_data.name!s}",
            hovertemplate=adev_hov_template,
            mode="markers",
            marker=dict(size=10, color=color),
        )
    )

    # Add factory reference line if inst_sigma is provided
    if np.isfinite(instrument_sigma):
        x_ref_line, y_ref_line = zip(
            *_get_allan_factory_line(df_allan.tau_scaled, instrument_sigma)
        )
        if x_ref_line:
            fig_allan_dev.add_trace(
                go.Scattergl(
                    x=x_ref_line,
                    y=y_ref_line,
                    name="factory",
                    mode="lines",
                    line=dict(color="rgba(105,105,105, 0.8)"),
                )
            )

    fig_allan_dev = _add_allan_single_frame_layout(fig_allan_dev, df_allan_dev=df_allan)

    return fig_allan_dev


def get_allan_plot_plotly(
    data_frame: pd.DataFrame,
    traces_colorscale: dict,
    synchronize_yaxis=True,
    concentration_units=ConcentrationUnits.PPB,
    title_text: str = "",
    instrument_sigma: float = np.NaN,
    instrument_sigma_source: str = "factory",
) -> plotly.graph_objects.Figure:
    """
    Returns a Plotly figure, with three subplots: raw data, time-averaged data, and Allan deviation.

    Args:
        data_frame (pandas.DataFrame): Dataframe with ``DateTimeIndex`` and several other columns,
            each representing an experiment port. Null values in each column are needed in order
            to separate time intervals where the port is not being sampled.
            Time averaging does not occur in regions where null values are present.

        traces_colorscale (dict): Dictionary with column names (as present in df) as key,
            and associated trace color as value.

        requested_averaging (Averaging): Perform averaging of the time series
            at the requested scale. Default is 100 seconds.

        synchronize_yaxis (bool): If True, the two time-series subplots are
            synchronized on the y-axis (the x-axis, representing time, is always
            shared between the two subplots). Default is True.

        concentration_units (ConcentrationUnits): Units for concentration in columns
            of dataframe df. Default is ppb.

        title_text (str): Title text to be displayed.
            It is also used as prefix for exported figures filenames.
            Default is empty string.

        instrument_sigma (float): Factory instrument sigma provided by Picarro and
            specific to instrument and species.

        instrument_sigma_source (str):
            Source of LODs values.
            Provided in the
            experiment definition json file as
            ["MetaData"]["source"]. Default is "factory".

    Returns:
        plotly.graph_object.Figure: Plotly figure.

    |
    |
    Full usage example:

    df_original::

                                  _datetime  concentration  port
        0     1970-06-16 10:04:20.024999858     -20.774936     2
        1     1970-06-16 10:04:22.881999970       2.173202     2
        ...                             ...            ...   ...
        51263 1970-06-18 07:27:54.296000004      88.928290     2
        51264 1970-06-18 07:27:57.345999956      64.941164     2


    |
    Pivot to get one column (trace) per port:

    .. code-block:: python

        pivot_on = "port"
        df_pivot = df.pivot(
            index="_datetime", columns=pivot_on, values="concentration"
        ).add_prefix(pivot_on)
        df_pivot.columns = df_pivot.columns.get_level_values(0)

    df_pivot (used as input for get_allan_plot_plotly)::

        port                           port1      port2  port3  port4
        _datetime
        1970-06-16 10:04:20.024999858    NaN -20.774936    NaN    NaN
        1970-06-16 10:04:22.881999970    NaN   2.173202    NaN    NaN
        ...                              ...        ...    ...    ...
        1970-06-18 07:27:54.296000004    NaN  88.928290    NaN    NaN
        1970-06-18 07:27:57.345999956    NaN  64.941164    NaN    NaN

    |
    Add color assignments:

    .. code-block:: python

        color_assignment = {
            "port1": "rgb(255,255,255)",
            "port2": "#fafafa",
            "port3": "black",
            "port4": "rgba(255,0,0, 0.5)",
        }

    |
    Get Plotly Figure.

    .. code-block:: python

        fig = get_allan_plot_plotly(
            df_pivot, color_assignment, instrument_sigma=47.0, title_text="MySpecies"
        )
        fig.show()

    """

    if not isinstance(data_frame, pd.DataFrame):
        raise TypeError(f"{type(data_frame)} is not a DataFrame")

    if not isinstance(data_frame.index, pd.DatetimeIndex):
        raise ValueError("DataFrame does not have a DateTimeIndex")

    if not isinstance(traces_colorscale, dict):
        raise TypeError(f"{traces_colorscale} is not a dict")

    (average_top, average_bottom) = get_default_basic_plot_averaging(
        data_frame.index[-1] - data_frame.index[0]
    )

    # Create a 2x2 subplot grid. The R1C2 element extends to R2C2
    fig = make_subplots(
        rows=2,
        cols=2,
        column_widths=[0.7, 0.3],
        row_heights=[0.5, 0.5],
        specs=[
            [{"type": "scatter"}, {"type": "scatter", "rowspan": 2}],
            [{"type": "scatter"}, None],
        ],
        subplot_titles=(
            "Raw data"
            if average_top == Averaging.ORIGINAL
            else f"Time average ({average_top.value.replace('T', 'min')})",
            " ",
            f"Time average ({average_bottom.value.replace('T', 'min')})",
        ),
    )

    adev_hov_template = (
        "Time average on %{x:.2f}s<br>Allan deviation: %{y:.2f}<br><br>%{meta}"
    )

    resampling_hov_template = (
        f"Date: %{{x}}<br>Time average: %{{y:.1f}} {concentration_units.value}<br>"
        f"%{{hovertext:.0f}} data points"
    )

    resampled_top = get_resampled_df_timeseries(
        original_df=data_frame,
        averaging_time=average_top,
        min_count=-1,
    )

    resampled_bottom = get_resampled_df_timeseries(
        original_df=data_frame,
        averaging_time=average_bottom,
        min_count=-1,
    )

    # Store all ports allan_devs and tau_scaled together
    # Then will take max and min to define layout ticks
    storage_allan = {"allan_dev": [], "tau_scaled": []}

    # For each port (column) present in the dataframe, add 3 traces
    for port in data_frame.columns:
        # Top data trace
        fig.add_trace(
            go.Scattergl(
                x=resampled_top.index,
                y=resampled_top[(f"{port}", "mean")],
                name=port.title(),
                mode="markers",
                legendgroup=port,
                line=dict(color=traces_colorscale[port]),
                connectgaps=False,
                showlegend=True,
                hovertext=resampled_top[(f"{port}", "count")],
                hovertemplate=resampling_hov_template,
            ),
            row=1,
            col=1,
        )

        # Bottom trace
        fig.add_trace(
            go.Scattergl(
                x=resampled_bottom.index,
                y=resampled_bottom[(f"{port}", "mean")],
                name=port.title(),
                line=dict(color=traces_colorscale[port]),
                mode="markers",
                connectgaps=False,
                legendgroup=port,
                showlegend=False,
                hovertext=resampled_bottom[(f"{port}", "count")],
                hovertemplate=resampling_hov_template,
            ),
            row=2,
            col=1,
        )

        # Allan deviation trace
        df_allan = get_allan_deviation_dataframe(data_frame[f"{port}"])

        # Boolean flag to tag if the lowest averaging
        # is larger than the current Allan deviation tau_scaled
        df_allan = df_allan.assign(
            is_observed=np.where(
                pd.Timedelta(average_top.value)
                > pd.to_timedelta(df_allan.tau_scaled, unit="s"),
                False,
                True,
            )
        )

        storage_allan["allan_dev"].extend(df_allan.allan_dev.values)
        storage_allan["tau_scaled"].extend(df_allan.tau_scaled.values)

        fig.add_trace(
            go.Scattergl(
                x=df_allan.tau_scaled,
                y=df_allan.allan_dev,
                name=port.title(),
                hovertemplate=adev_hov_template,
                mode="markers",
                marker=dict(color=traces_colorscale[port]),
                marker_symbol=[
                    "circle" if observed else "circle-open"
                    for observed in df_allan.is_observed
                ],
                marker_line_width=[
                    1 if observed else 3 for observed in df_allan.is_observed
                ],
                marker_size=[
                    11 if observed else 8 for observed in df_allan.is_observed
                ],
                legendgroup=port,
                showlegend=False,
                meta=[
                    "&#9432; Early Allan deviation terms<br>"
                    "cannot be observed in left pane<br>"
                    "due to time averaging"
                    if not observed
                    else ""
                    for observed in df_allan.is_observed
                ],
            ),
            row=1,
            col=2,
        )

    # Move Allan values from storage to dataframe for layout calculations
    df_allan = pd.DataFrame(data=storage_allan)

    # Add factory reference line if inst_sigma is provided
    if np.isfinite(instrument_sigma):
        x_ref_line, y_ref_line = zip(
            *_get_allan_factory_line(df_allan.tau_scaled, instrument_sigma)
        )
        if x_ref_line:
            fig.add_trace(
                go.Scattergl(
                    x=x_ref_line,
                    y=y_ref_line,
                    name=f"{instrument_sigma_source}",
                    legendgroup=f"{instrument_sigma_source}",
                    mode="lines",
                    line=dict(color="rgba(105,105,105, 0.8)"),
                    hovertemplate="Time: %{x:.2f}s<br>Allan deviation: %{y:.2f}",
                ),
                row=1,
                col=2,
            )

    fig = _add_basic_plot_layout(
        fig,
        title_text=title_text,
        synchronize_yaxis=synchronize_yaxis,
        concentration_units=concentration_units,
        df_allan_dev=df_allan,
    )

    return fig


def export_graph_object_to_file(
    gr_obj_fig: plotly.graph_objects.Figure,
    file_format=PlotFileFormat.JSON,
    save_name="plot",
    export_path=Path.cwd().as_posix(),
) -> str:
    """
    Exports a Plotly graph object to file. Requires Kaleido package.

    Args:
        gr_obj_fig (plotly.graph_objects.Figure): Plotly Figure to be exported
        file_format (PlotFileFormat): Target format for the graph object export. Default is JSON.
        save_name (str): Target file name. Default is "plot".
        export_path (str): Local path where pdf/json/png/html file are exported.
            Default is current working dir.

    Returns:
        str: File path

    """
    ret_val = ""

    if Path(export_path).exists():
        fpath = os.path.join(export_path, save_name)

        if (file_format is PlotFileFormat.PNG) | (file_format is PlotFileFormat.PDF):
            gr_obj_fig.write_image(f"{fpath}_basic.{file_format.value}")
        elif file_format is PlotFileFormat.HTML:
            gr_obj_fig.write_html(f"{fpath}_basic.{file_format.value}")
        elif file_format is PlotFileFormat.JSON:
            gr_obj_fig.write_json(f"{fpath}_basic.{file_format.value}")
        else:
            raise ValueError("File format provided is not recognized")

        ret_val = f"{fpath}_basic.{file_format.value}"
    else:
        raise NotADirectoryError("Location export_path does not exist")

    return ret_val
