"""Utilities for color management and processing"""

from itertools import cycle
from typing import List, Union

import plotly.express as px
from pydantic import validate_call


@validate_call()
def get_full_colorscale(
    all_keys: List[Union[int, str]],
    discrete_color_map: dict,
) -> dict:
    """
    Create a dictionary ``{key: color}`` associating each
    and all keys (species or ports)
    to a different color, even the keys
    that were not explicitely assigned in
    ``discrete_color_map``.

    Args:
        all_keys (List[str]):
           List of all keys (species) required in the
           output dictionary.

        discrete_color_map (dict):
            Dictionary (``{key: color}``) associating
            some keys to their desired trace color.
            This map overrides the default color
            assignment.

    Returns:
        dict:
            ``{key: color}`` dictionary including
            all keys.

    """
    use_keys = [f"{k}" for k in all_keys]
    current_cmap = dict(discrete_color_map)
    palette = cycle(px.colors.qualitative.Bold)

    for current_key in use_keys:
        if current_key not in current_cmap:
            current_cmap[current_key] = next(palette)

    return current_cmap
