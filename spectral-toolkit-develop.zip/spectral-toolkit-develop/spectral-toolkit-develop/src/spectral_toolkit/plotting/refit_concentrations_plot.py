"""Summary of concentration as function of time
before and after refitting"""

from typing import List

import pandas as pd
import plotly.graph_objs as go
from pydantic import validate_call

from spectral_toolkit.plotting.colors_utils import get_full_colorscale


@validate_call()
def _get_species_list(
    original_columns: List[str],
    refit_columns: List[str],
    original_prefix: str = "broadband_gasConcs_",
    refit_prefix: str = "lsq_gasConcs_",
) -> List[str]:
    """
    Returns a list with CIDs present in original fit
    and/or refit. The species present in original fit
    are kept first.

    Args:
        original_columns (List[str]):
            Names of columns containing original
            fit concentration data.

        refit_columns (List[str]):
            Names of columns containing refit
            fit concentration data.

        original_prefix (str):
            Prefix in original fit columns,
            preceding species CID value.

        refit_prefix (str):
            Prefix in refit fit columns,
            preceding species CID value.

    Returns:
        List[str]:
            CIDs present in original fit
            and/or refit.

    >>> _get_species_list(
    ... original_columns=["orig_1A", "orig_2E", "orig_3J"],
    ... refit_columns=["new_1A", "new_2E", "new_3J", "new_3G"],
    ... original_prefix="orig_", refit_prefix="new_")
    ['1A', '2E', '3J', '3G']

    >>> _get_species_list(
    ... original_columns=["broadband_gasConcs_180"],
    ... refit_columns=["lsq_gasConcs_180", "lsq_gasConcs_276"],
    ... original_prefix="broadband_gasConcs_",
    ... refit_prefix="lsq_gasConcs_")
    ['180', '276']

    """

    if not all(original_prefix in col for col in original_columns):
        raise ValueError("original_prefix not found in all original_columns entries")

    if not all(refit_prefix in col for col in refit_columns):
        raise ValueError("refit_prefix not found in all refit_columns entries")

    all_species = [col.replace(original_prefix, "") for col in original_columns] + [
        col.replace(refit_prefix, "") for col in refit_columns
    ]
    seen = set()
    return [x for x in all_species if not (x in seen or seen.add(x))]


@validate_call(config=dict(arbitrary_types_allowed=True))
def get_refit_concentrations_plot(
    refit_df: pd.DataFrame,
    group_by: str = "ValveMask",
    group_by_selector_label: str = "Port",
    original_columns_prefix: str = "broadband_gasConcs_",
    refit_columns_prefix: str = "lsq_gasConcs_",
) -> go.Figure:
    """
    Generate Plotly refit concentration plot.

    Args:
        refit_df (pd.Dataframe):
            Dataframe with column ``_datetime`` and
            other concentration columns.

        group_by (str):
            Name of column of ``refit_df``
            used to group
            the concentration data.
            Default is "ValveMask".

        group_by_selector_label (str):
            Prefix label to
            dropdown selector.

        original_columns_prefix (str):
            Prefix in the columns of
            ``refit_df`` identifying
            the columns containing concentrations
            from the original fit.

        refit_columns_prefix (str):
            Prefix in the columns of
            ``refit_df`` identifying
            the columns containing concentrations
            from the refit.

    Returns:
        go.Figure: Plotly Figure.

    """

    if "_datetime" not in refit_df.columns:
        raise ValueError("_datetime not present in columns")

    if group_by not in refit_df.columns:
        raise ValueError("group_by not present in columns")

    if not any(col.startswith(original_columns_prefix) for col in refit_df.columns):
        raise ValueError("no column in refit_df starts with original_columns_prefix")

    if not any(col.startswith(refit_columns_prefix) for col in refit_df.columns):
        raise ValueError("no column in refit_df starts with refit_columns_prefix")

    # Get original and refit column names
    original_cols = [
        col for col in refit_df.columns if col.startswith(original_columns_prefix)
    ]
    refit_cols = [
        col for col in refit_df.columns if col.startswith(refit_columns_prefix)
    ]

    # Get groups. Data is filtered based on port in the plot dropdown
    groups = sorted(refit_df[group_by].unique().astype(int).tolist())

    # Get all species to be displayed
    all_species = _get_species_list(
        original_cols, refit_cols, original_columns_prefix, refit_columns_prefix
    )

    # Get colors
    cscale = get_full_colorscale(all_species, {})

    fig = go.Figure()

    for group in groups:

        df_port = refit_df[refit_df[group_by] == group]

        for species in all_species:

            is_new = ' (New)' \
                if f'{original_columns_prefix}{species}' not in original_cols \
                else ''

            if f"{refit_columns_prefix}{species}" in refit_cols:
                fig.add_trace(
                    go.Scattergl(
                        x=df_port["_datetime"],
                        y=df_port[f"{refit_columns_prefix}{species}"],
                        mode="lines+markers",
                        line_color=cscale[species],
                        line_width=3,
                        line_dash='dash',
                        meta=f"{group}",
                        name=f"{species}{is_new}",
                        legendgroup="CIDs Refit",
                        legendgrouptitle=dict(text="CIDs Refit"),
                        visible=False,
                        showlegend=False,
                        hovertemplate="%{y:.2f}ppb",
                        xhoverformat="%Y-%m-%d %I:%M:%S %p",
                    )
                )

            if f"{original_columns_prefix}{species}" in original_cols:
                fig.add_trace(
                    go.Scattergl(
                        x=df_port["_datetime"],
                        y=df_port[f"{original_columns_prefix}{species}"],
                        mode="lines+markers",
                        line_color=cscale[species],
                        line_width=2.5,
                        meta=f"{group}",
                        name=f"{species}",
                        legendgroup="CIDs Original",
                        legendgrouptitle=dict(text="CIDs Original"),
                        opacity=0.8,
                        showlegend=False,
                        visible=False,
                        hovertemplate="%{y:.2f}ppb",
                        xhoverformat="%Y-%m-%d %I:%M:%S %p",
                    )
                )

    fig.update_yaxes(title="Concentration")
    fig.update_layout(
        hovermode="x unified",
        title=f"<b>Original v. Refit concentration by "
        f"{group_by_selector_label.lower()}</b>",
    )
    fig.update_yaxes(zeroline=True, zerolinewidth=3, zerolinecolor="rgba(30,30,30,0.3)")

    # Add dropdown menu
    fig = _add_menu(fig, groups=groups, group_name=group_by_selector_label)

    return fig


@validate_call(config=dict(arbitrary_types_allowed=True))
def _add_menu(
    original_fig: go.Figure, groups: List[int], group_name: str = "Port"
) -> go.Figure:
    """
    Add dropdown selector to refit figure.
    It filters traces based on the ``meta`` attribute.

    Args:
        original_fig:
            Original Plotly figure.

        groups (List[int]):
            List of integers, containing
            all grouping values. For example,
            if grouping by port, and
            ``groups=[1,8]``, then the
            dropdown menu will have port 1
            and port 8 available.

        group_name (str):
            Prefix label to
            dropdown selector.

    Returns:
        go.Figure:
            Plotly figure with dropdown menus.

    """

    fig_menus = go.Figure(original_fig)

    # Add dynamic option to hide negative values
    fig_menus.update_layout(
        updatemenus=[
            dict(
                type="dropdown",
                direction="down",
                active=0,
                buttons=[
                    dict(
                        args=[
                            {
                                "visible": [
                                    tr.meta == f"{group}" for tr in fig_menus.data
                                ],
                                "showlegend": [
                                    tr.meta == f"{group}" for tr in fig_menus.data
                                ],
                            }
                        ],
                        label=f"{group_name.title()} {group}",
                        method="restyle",
                    )
                    for group in groups
                ],
                pad={"r": 0, "b": 10},
                showactive=True,
                x=1,
                xanchor="right",
                y=1,
                yanchor="bottom",
            ),
        ]
    )

    # Show only first group data
    fig_menus.for_each_trace(
        lambda tr: tr.update(
            visible=tr.meta == f"{groups[0]}", showlegend=tr.meta == f"{groups[0]}"
        )
    )

    return fig_menus
