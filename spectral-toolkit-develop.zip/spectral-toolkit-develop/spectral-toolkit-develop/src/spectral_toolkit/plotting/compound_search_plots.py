import numpy as np
import pandas as pd
import plotly.graph_objs as go
import xarray as xr
from plotly.subplots import make_subplots

from spectral_toolkit.compound_search.performance_evaluation import (
    get_quartile_dispersion,
)

UNSELECTED_RED = "rgba(214, 39, 40, 0.3)"
DISPERSION_ORANGE = "rgba(255, 172, 28, 0.5)"
SELECTED_GREEN = "rgba(80, 200, 120, 0.6)"


def decision_support_plot(
    models_ds: xr.Dataset,
    pvalue_df: pd.DataFrame,
    decision_df: pd.DataFrame,
    limit_pvalue_display: float = 0.1,
    title_text: str = "",
):
    """
    Summary plot to support spectral hunting decisions.

    Args:
        models_ds (xr.Dataset):
            Results from `.train_lars`
        pvalue_df (pd.DataFrame):
            Dataframe from `.pvalue_table`.
            Must have columns:
            occurrences, noise_pvalue
        decision_df (pd.DataFrame):
            Dataframe from `.run_decision`.
            Must have columns:
            keep_occurrences, keep_concentration_zero,
            keep_noise, keep_concentration_spread, suggested_use
        limit_pvalue_display (float):
            Limits CIDs to the ones with
            noise pvalue less than limit_pvalue_display
        title_text (str):
            Text to add to figure title

    Returns:
        go.Figure: Plotly figure

    """

    concentrations_df = (models_ds.coefficients / models_ds.scale).to_pandas()
    time_splits = len(concentrations_df)

    pvalue_df = pvalue_df[pvalue_df.noise_pvalue < limit_pvalue_display]
    pvalue_df = pvalue_df.sort_values(by="noise_pvalue", ascending=False)
    pvalue_df["occurrences"] = pvalue_df["occurrences"] / time_splits
    decision_df = decision_df.loc[pvalue_df.index]

    fig = make_subplots(
        rows=1,
        cols=3,
        column_titles=[
            f"<b>Occurrences in {time_splits} fitted models</b><br>Higher is better",
            "<b>Concentration proxy</b><br>Narrow and &#8800; 0 is better",
            "<b>Spectral noise confidence</b><br>Higher is better",
        ],
        shared_yaxes=True,
    )

    # Occurrences
    fig.add_trace(
        go.Bar(
            y=pvalue_df.index.values.astype(str),
            x=pvalue_df.occurrences,
            marker_color=np.where(
                decision_df.keep_occurrences, SELECTED_GREEN, UNSELECTED_RED
            ),
            orientation="h",
            showlegend=False,
        ),
        row=1,
        col=1,
    )
    fig.update_xaxes(
        tickformat=".0%",
        row=1,
        col=1,
        title=f"Percent of occurrences in {time_splits} fitted models",
    )

    # Concentration proxy
    for cid in pvalue_df.index.values:

        if decision_df.loc[cid].maybe_use:
            if decision_df.loc[cid].suggested_use:
                color = SELECTED_GREEN
            else:
                color = DISPERSION_ORANGE
        else:
            color = UNSELECTED_RED

        fig.add_trace(
            go.Box(
                x=concentrations_df[cid],
                name=f"{cid}",
                marker_color=color,
                showlegend=False,
            ),
            row=1,
            col=2,
        )
    fig.update_xaxes(
        showgrid=True,
        zeroline=True,
        zerolinewidth=2,
        zerolinecolor="rgba(37, 37, 37, 0.2)",
        rangemode="tozero",
        row=1,
        col=2,
        title=f"Concentrations in {time_splits} <i>full</i> models",
    )

    # Noise p-values
    fig.add_trace(
        go.Bar(
            y=pvalue_df.index.values.astype(str),
            x=1 - pvalue_df.noise_pvalue,
            marker_color=np.where(
                decision_df.keep_noise, SELECTED_GREEN, UNSELECTED_RED
            ),
            orientation="h",
            showlegend=False,
        ),
        row=1,
        col=3,
    )
    fig.update_xaxes(
        type="log",
        row=1,
        col=3,
        title="1 - pvalue with H<sub>0</sub> = signal is noise",
    )
    fig.update_yaxes(tickprefix="<b>", ticksuffix="</b>")

    fig.update_layout(
        template="plotly_white",
        title=dict(text=f"<b>Decision summary plot</b> {title_text}<br>Green highlights statistical significance. "
        f"Orange indicates uncertainty.", yanchor='bottom'),
        margin_t=180
    )
    return fig
