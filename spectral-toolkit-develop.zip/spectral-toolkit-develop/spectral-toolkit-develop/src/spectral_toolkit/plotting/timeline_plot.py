"""Generate interactive timeline plots in Plotly
"""
from math import ceil
from typing import List

import numpy as np
import pandas as pd
import plotly.graph_objs as go
from pydantic import validate_call

from spectral_toolkit.constants.plotting_constants import AveragesSelection, Averaging
from spectral_toolkit.df_operations.timeline_process_df import (
    _get_default_resampling_min_count,
    get_resampled_df_timeseries,
)
from spectral_toolkit.plotting.port_average_plot_plotly import (
    add_reference_three_sigma,
    add_three_sigma_instrument,
    rgb_to_rgba,
)


def get_default_timeseries_template(
    time_duration: pd.Timedelta,
) -> List[AveragesSelection]:
    """
    Create timeline plot template
    according to the duration of the
    experiment to be plotted.

    Args:
        time_duration (pd.Timedelta):
            Time difference between the last
            data point and the first data point
            of an experiment.
    Returns:
        List[AveragesSelection]:
            Timeline plot template request.

    Example:

    df

    ::

        port                         port1  port2     port3
        _datetime
        2022-04-18 00:00:00.000  -8.889313    NaN       NaN
        2022-04-18 00:00:01.450 -10.304097    NaN       NaN
        ...                            ...    ...       ...
        2022-04-18 00:23:48.250        NaN    NaN -7.595253
        2022-04-18 00:23:49.700        NaN    NaN -1.638299

    Get experiment length:

    .. code-block:: python

        experiment_length = df.index[-1] - df.index[0]
        experiment_length

    ::

        Timedelta('0 days 00:23:49.700000')


    Get template:

    .. code-block:: python

         get_default_timeseries_template(experiment_length)

    ::

        [AveragesSelection(label='6H', value=6, display_traces=['100S', '30S']),
         AveragesSelection(label='All', value=1, display_traces=['30T'])]

    Now you can use it as `plot_template_request` in
    :py:func:`get_timeseries_plot_plotly`.

    """

    if not isinstance(time_duration, pd.Timedelta):
        raise TypeError("time duration must be a Pandas Timedelta")

    total_duration = ceil(time_duration / pd.Timedelta(hours=1))

    if time_duration > pd.Timedelta(days=365):
        # > 1 year
        plotting_requests = [
            AveragesSelection("1D", 24, [Averaging.ONE_HOUR.value]),
            AveragesSelection("1W", 168, [Averaging.FOUR_HOURS.value]),
            AveragesSelection("All", total_duration, [Averaging.ONE_DAY.value]),
        ]
    elif time_duration > pd.Timedelta(days=160):
        # > 5 months
        plotting_requests = [
            AveragesSelection("6H", 6, [Averaging.THIRTY_MINUTES.value]),
            AveragesSelection("1D", 24, [Averaging.ONE_HOUR.value]),
            AveragesSelection("All", total_duration, [Averaging.ONE_DAY.value]),
        ]
    elif time_duration > pd.Timedelta(days=90):
        # > 3 month
        plotting_requests = [
            AveragesSelection("6H", 6, [Averaging.TEN_MINUTES.value]),
            AveragesSelection("1D", 24, [Averaging.ONE_HOUR.value]),
            AveragesSelection("All", total_duration, [Averaging.ONE_DAY.value]),
        ]
    elif time_duration > pd.Timedelta(days=24):
        # >24 days
        plotting_requests = [
            AveragesSelection("6H", 6, [Averaging.FIVE_MINUTES.value]),
            AveragesSelection("1D", 24, [Averaging.ONE_HOUR.value]),
            AveragesSelection("All", total_duration, [Averaging.ONE_DAY.value]),
        ]
    elif time_duration > pd.Timedelta(days=7):
        # > 7 day
        plotting_requests = [
            AveragesSelection(
                "6H", 6, [Averaging.FIVE_MINUTES.value, Averaging.HUNDRED_SECONDS.value]
            ),
            AveragesSelection("1D", 24, [Averaging.ONE_HOUR.value]),
            AveragesSelection("All", total_duration, [Averaging.ONE_DAY.value]),
        ]
    elif time_duration > pd.Timedelta(days=1):
        # > 1 Day
        plotting_requests = [
            AveragesSelection(
                "6H",
                6,
                [Averaging.HUNDRED_SECONDS.value, Averaging.THIRTY_SECONDS.value],
            ),
            AveragesSelection("1D", 24, [Averaging.THIRTY_MINUTES.value]),
            AveragesSelection("All", total_duration, [Averaging.FOUR_HOURS.value]),
        ]
    else:
        # < 1 Day
        plotting_requests = [
            AveragesSelection(
                "6H",
                6,
                [Averaging.HUNDRED_SECONDS.value, Averaging.THIRTY_SECONDS.value],
            ),
            AveragesSelection("All", total_duration, [Averaging.THIRTY_MINUTES.value]),
        ]
    return plotting_requests


def _get_averaging_line_style(requested_averaging=Averaging.HUNDRED_SECONDS) -> dict:
    """
    Returns a dict with Plotly line style parameters based on requested averaging.

        Args:
            requested_averaging (Averaging): Time averaging value.

        Returns:
            dict: Line style dictionary.
    """
    if not isinstance(requested_averaging, Averaging):
        raise TypeError(f"{requested_averaging} is not a valid Averaging value")

    color = "rgba(240,128,128, 0.4)"

    line_dict = {
        Averaging.ORIGINAL: {},
        Averaging.TEN_SECONDS: {},
        Averaging.THIRTY_SECONDS: dict(dash="dash"),
        Averaging.ONE_MINUTE: dict(dash="dashdot"),
        Averaging.HUNDRED_SECONDS: dict(dash="dot"),
        Averaging.FIVE_MINUTES: dict(dash="dash"),
        Averaging.TEN_MINUTES: dict(dash="dash"),
        Averaging.THIRTY_MINUTES: dict(dash="dash"),
        Averaging.ONE_HOUR: dict(dash="dash"),
        Averaging.FOUR_HOURS: dict(dash="dash"),
        Averaging.SIX_HOURS: dict(dash="dash"),
        Averaging.TWELVE_HOURS: dict(dash="dash"),
        Averaging.ONE_DAY: dict(dash="dash"),
    }

    line_ret = {}

    if requested_averaging in line_dict:
        line_ret = line_dict[requested_averaging]
        line_ret["color"] = color

    return line_ret


def _get_averaging_marker_style(requested_averaging=Averaging.HUNDRED_SECONDS) -> dict:
    """
    Returns a dict with Plotly marker style parameters based on requested averaging.

        Args:
            requested_averaging (Averaging): Time averaging value.

        Returns:
            dict: Marker style dictionary.
    """

    if not isinstance(requested_averaging, Averaging):
        raise TypeError(f"{requested_averaging} is not a valid Averaging value")

    markers_dict = {
        Averaging.ORIGINAL: {},
        Averaging.TEN_SECONDS: {},
        Averaging.THIRTY_SECONDS: dict(symbol="triangle-up"),
        Averaging.ONE_MINUTE: dict(symbol="star-triangle-up"),
        Averaging.HUNDRED_SECONDS: dict(symbol="circle"),
        Averaging.FIVE_MINUTES: dict(symbol="pentagon"),
        Averaging.TEN_MINUTES: dict(symbol="triangle-down"),
        Averaging.THIRTY_MINUTES: dict(symbol="diamond-tall"),
        Averaging.ONE_HOUR: dict(symbol="star-diamond"),
        Averaging.FOUR_HOURS: dict(symbol="diamond"),
        Averaging.SIX_HOURS: dict(symbol="hexagon"),
        Averaging.TWELVE_HOURS: dict(symbol="diamond"),
        Averaging.ONE_DAY: dict(symbol="square", size=12),
    }

    ret_marker = {}

    if requested_averaging in markers_dict:
        ret_marker = markers_dict[requested_averaging]

        if "size" not in ret_marker:
            ret_marker["size"] = 8

        ret_marker["line"] = dict(width=1, color="darkgray")

    return ret_marker


def _update_annotation_y_coord(annotations: List[dict]) -> List[dict]:
    """
    Given a list of Plotly annotation dicts, returns a new list of dicts
    altering the value of ``y`` (the y-coordinate for the three sigma
    annotations in ``get_timeseries_plot_plotly``) for each annotation
    to accommodate multiple annotations without overlapping.

        Args:
            annotations (List[dict]): Plotly annotation list (go.Figure.layout.annotations)

        Returns:
            List[dict]: Dictionary with adjusted value of ``y``.
    """

    @validate_call
    def _get_annotation_y_coord(annotation_index: int) -> float:
        """
        Lookup table/dict for the y-coordinate based on the current
        annotation index.

            Args:
                annotation_index (int): Index of current annotation (1-based).

            Returns:
                float: y-coordinate for the current annotation.
        """
        if annotation_index <= 0:
            raise ValueError("annotation_index shall be non-negative")

        annotations_dict = {
            1: 1.0,
            2: 1.05,
            3: 1.10,
            4: 1.15,
        }
        y_ret = annotations_dict.get(annotation_index, 0.0)

        return y_ret

    if not isinstance(annotations, list):
        raise TypeError(f"{annotations} is not list")

    new_annotations = annotations.copy()
    for i, annotation in enumerate(new_annotations):
        annotation["y"] = _get_annotation_y_coord(i + 1)

    return new_annotations


def _get_three_sigma_instrument_dict(
    interval_durations: pd.Series, provided_averaging: Averaging, instr_sigma: float
) -> dict:
    """
    Get the instrument 3-sigma at the provided averaging level. It is a wrapper function
    for ``add_three_sigma_instrument``, but it returns a dict that can be used for
    Plotly annotations.

        Args:
            interval_durations (pd.Series): Time series with duration of each sampling
                period (time delta).

            provided_averaging (Averaging): Provided averaging level for the time series.

            instr_sigma (float): Factory instrument sigma provided by Picarro and
                specific to instrument and species.

        Returns:
            dict: Plotly annotation dict.

    """

    if not isinstance(interval_durations, pd.Series):
        raise TypeError(f"{interval_durations} is not a Pandas Series")

    if interval_durations.dtype != "timedelta64[ns]":
        raise TypeError(f"{interval_durations} is not timedelta64[ns]")

    if not isinstance(provided_averaging, Averaging):
        raise TypeError(f"{provided_averaging} is not a valid Averaging")

    if not isinstance(instr_sigma, float):
        raise TypeError(f"{instr_sigma} is not a float")

    ret_dict = {}

    if np.isfinite(instr_sigma):
        temp_fig = add_three_sigma_instrument(
            go.Figure(), instr_sigma, interval_durations
        )

        ret_dict = temp_fig.layout.annotations[-1].to_plotly_json()
        ret_dict["text"] = ret_dict["text"].replace(
            "</sub> =", f"</sub> ({provided_averaging.value}) ="
        )

    return ret_dict


def _add_range_menus(
    original_fig: go.Figure,
    plotting_averages: List[AveragesSelection],
    max_time: pd.Timestamp,
    active: str = None,
) -> go.Figure:
    """
    Add button menus to Plotly timeline figure to allow range selector functionality
    coupled with traces and annotations selection. Default set at 6H window.

    |

    Explanation:

    |

    method = update (both Plotly data and layout are changed)

    |

    visible: set traces to visible if the trace averaging (flagged by its *text* attribute)
    corresponds to one of the requested averaging/s (plotting_averages.AveragesSelection).

    |

    annotations: get annotations from the *meta* attribute of the three sigma visible traces.

    |

    xaxis.range, rangeslider.range: 6H window selected by default.


        Args:
            original_fig (go.Figure): Starting Plotly Figure

            plotting_averages (List[AveragesSelection]):
                List of tuples ("label", "value", "display_traces").

                label: Label text for plot menu button.

                value: Width of the time windows
                to display (in hours).

                display_traces: Traces to be shown when the label is selected.

            max_time (pd.Timestamp): The last timestamp in the experiment data
                (i.e., the last element of the the DateTimeIndex column).

            active (str): Active range selector value

        Returns:
            go.Figure: Plotly figure with added menu.
    """

    if not isinstance(original_fig, go.Figure):
        raise TypeError(f"{original_fig} is not a Plotly Figure")

    if not isinstance(plotting_averages, list):
        raise TypeError(f"{plotting_averages} is not a list")

    if not isinstance(max_time, pd.Timestamp):
        raise TypeError(f"{max_time} is not a timestamp")

    if not active:
        active = next((el.value for el in plotting_averages), 0)

    ret_fig = go.Figure(original_fig)

    menu_averaging = [
        dict(
            active=next(
                (
                    i if el.value == active else 0
                    for i, el in enumerate(plotting_averages)
                ),
                0,
            ),
            type="buttons",
            direction="right",
            buttons=[
                {
                    "label": f"{lab}",
                    "args": [
                        {
                            "visible": [tr.text in include for tr in ret_fig.data],
                        },
                        {
                            "annotations": _update_annotation_y_coord(
                                [
                                    tr.meta
                                    for tr in ret_fig.data
                                    if tr.meta and tr.text in include
                                ]
                            ),
                            "xaxis.range": [
                                max_time - pd.DateOffset(hours=val),
                                max_time,
                            ],
                            "rangeslider.range": [
                                max_time - pd.DateOffset(hours=val),
                                max_time,
                            ],
                        },
                    ],
                    "method": "update",
                }
                for lab, val, include in plotting_averages
            ],
            pad={"r": 10, "t": 10},
            showactive=True,
            x=1,
            xanchor="right",
            y=1.04,
            yanchor="bottom",
        )
    ]
    ret_fig.update_layout(updatemenus=menu_averaging)
    return ret_fig


def _add_averaging_trace(
    fig_original: go.Figure,
    original_timeline_df: pd.DataFrame,
    traces_colorscale: dict,
    show_marker: bool = True,
    requested_averaging=Averaging.HUNDRED_SECONDS,
    reference_port_name: str = "Reference",
    instrument_sigma: float = np.NaN,
    scattergl_trace: bool = True,
) -> go.Figure:
    """
    Adds a timeline trace to a Plotly Figure. The data for the trace is extracted from
    ``original_timeline_df`` by performing averaging at ``requested_averaging`` level.

        Args:
            fig_original (go.Figure): Original Plotly Figure.

            original_timeline_df (pd.DataFrame): Original raw DataFrame,
                with one column per port.

            traces_colorscale (dict): Dictionary with column names (as present in
                ``original_timeline_df``) as key, and associated trace color as value.

            show_marker (bool): Whether the trace is plotted with markers or not.
                If ``show_marker=False``, the trace will not be visible in the legend.

            requested_averaging (Averaging): The averaging to be performed on
                ``original_timeline_df`` before adding the averaged trace to the Figure.

            reference_port_name (str): Name of the column of ``original_timeline_df``
                to be used as reference port (used to calculate the 3-sigma lines).

            instrument_sigma (float): Factory instrument sigma provided by Picarro and
                specific to instrument and species.

            scattergl_trace (bool): If True, load the trace as `scattergl` type. Else,
                use `scatter` type.

        Returns:
              go.Figure: Plotly Figure.


    |
    Trace explanation:
        - ``x=timeline_df.index``: Time index of the resampled series
        - ``y=timeline_df[(f"{port}", "mean")]``: Resampled time series concentration means
        - ``name=port.title()``: Name of the trace is the name of the port
              (columns of ``original_timeline_df``)
        - ``legendgroup=port``: Port name, used for grouping same-port data
        - ``mode=mode``: "lines", or "lines+markers" if ``show_markers=True``
        - ``text=requested_averaging.value``: Text field is used to filter traces using menu buttons
              in ``_add_range_menus``.
        - ``customdata=time_start_end_custom_data``: Array of (start, end) times of
              each resampled point.
        - ``connectgaps``: True only for long-running averages (not 30S or 100S)
        - ``showlegend=True if marker else False``: Do not show in legend traces without markers.
              Used to give less visibility and importance to the 30S time average.
        - ``hovertext=timeline_df[(f"{port}", "count")]``: Add in the hover box the number of
              data points used for averaging.
    """

    if not isinstance(fig_original, go.Figure):
        raise TypeError(f"{fig_original} is not a Figure")

    if not isinstance(original_timeline_df, pd.DataFrame):
        raise TypeError(f"{original_timeline_df} is not a DataFrame")

    if not isinstance(original_timeline_df.index, pd.DatetimeIndex):
        raise ValueError("DataFrame does not have a DateTimeIndex")

    if not isinstance(traces_colorscale, dict):
        raise TypeError(f"{traces_colorscale} is not a dict")

    if not isinstance(show_marker, bool):
        raise TypeError(f"{show_marker} is not a bool")

    if not isinstance(requested_averaging, Averaging):
        raise TypeError(f"{requested_averaging} is not a valid Averaging value")

    if not isinstance(reference_port_name, str):
        raise TypeError(f"{reference_port_name} is not a str")

    if reference_port_name not in original_timeline_df.columns:
        raise ValueError(f"{reference_port_name} not in original_timeline_df columns")

    if not isinstance(instrument_sigma, float):
        raise TypeError(f"{instrument_sigma} is not a float")

    fig_ret = go.Figure(fig_original)

    # Get the requested resampled dataframe
    timeline_df = get_resampled_df_timeseries(
        original_timeline_df,
        averaging_time=requested_averaging,
        min_count=_get_default_resampling_min_count(requested_averaging),
    )

    # Define hover template
    hov_template = (
        f"Concentration: <b>%{{y:.1f}} ppb</b><br>"
        f"Time: %{{x|%Y/%m/%d %H:%M}}"
        f" ({requested_averaging.value.replace('T', 'min')} averaging)<br>"
        f"From %{{customdata[0]}} to %{{customdata[1]}} (%{{hovertext}} data points)"
    )

    # Use start and end time for each period as custom data for the plot
    time_start_end_custom_data = np.stack(
        (
            timeline_df[("_timeline", "start")]
            .dt.strftime("%b %d, %Y %I:%M:%S%p")
            .values,
            timeline_df[("_timeline", "end")]
            .dt.strftime("%b %d, %Y %I:%M:%S%p")
            .values,
        ),
        axis=-1,
    )

    # Get marker style
    if show_marker:
        mode = "markers+lines"
        marker = _get_averaging_marker_style(requested_averaging)
    else:
        mode = "lines"
        marker = {}

    # Get all the port names (== dataframe columns, except underscore, reserved for timeline info)
    all_ports_columns = timeline_df.columns.levels[0]
    all_ports_columns = all_ports_columns[~all_ports_columns.str.startswith("_")]

    # Add the 3 sigma at this time averaging from the reference port concentration data
    fig_ret = add_reference_three_sigma(
        fig_ret, timeline_df[(reference_port_name, "mean")], requested_averaging
    )
    fig_ret.data[-1].line = _get_averaging_line_style(requested_averaging)

    # Add the 3 sigma instrument as metadata for the reference three sigma trace just added
    fig_ret.data[-1].meta = _get_three_sigma_instrument_dict(
        timeline_df[("_timeline", "duration")], requested_averaging, instrument_sigma
    )

    # For each port (column) present in the dataframe
    for port in all_ports_columns:

        if show_marker:
            selected_col = traces_colorscale[port]
            marker["color"] = selected_col
            line_col = rgb_to_rgba(traces_colorscale[port], 0.4)
        else:
            selected_col = rgb_to_rgba(traces_colorscale[port], 0.2)
            line_col = selected_col

        # Data trace
        fig_ret.add_trace(
            dict(
                x=timeline_df.index,
                y=timeline_df[(f"{port}", "mean")],
                name=port.title(),
                legendgroup=port,
                mode=mode,
                line=dict(color=line_col),
                text=requested_averaging.value,
                marker=marker,
                customdata=time_start_end_custom_data,
                connectgaps=requested_averaging
                not in [Averaging.THIRTY_SECONDS, Averaging.HUNDRED_SECONDS],
                showlegend=bool(marker),
                visible=True,
                hovertemplate=hov_template,
                hovertext=timeline_df[(f"{port}", "count")],
                type="scattergl" if scattergl_trace else "scatter",
            ),
        )

    return fig_ret


@validate_call
def _get_markers_visibility(traces_display: List[str]):
    """
    Do not display markers for the shortest
    averaging time when an AverageSelection
    has more than one display_traces

        Args:
            traces_display (list[str]): List of Averaging values

        Returns:
            list: Boolean show_markers mask.

    >>> traces_display = [Averaging.ONE_DAY.value, Averaging.ONE_MINUTE.value]
    >>> _get_markers_visibility(traces_display)
    array([ True, False])

    """

    averages_seconds = pd.to_timedelta(traces_display).total_seconds()
    show_markers = averages_seconds > min(averages_seconds)

    return show_markers if len(show_markers) > 1 else [True]


def get_timeseries_plot_plotly(
    original_df: pd.DataFrame,
    plot_template_request: List[AveragesSelection],
    traces_colorscale: dict,
    instrument_sigma: float,
    show_negative_values: bool = False,
    reference_port_name: str = "Reference",
    plot_title: str = "",
    show_thumbnail: bool = False,
) -> go.Figure:
    """
    Get a Plotly time series plot with 3-sigma references and range sliders.

    Args:

        original_df (pd.DataFrame):
            Original dataframe, with one
            column per port and a ``DateTimeIndex``.
            The columns name will act as ports name.

        plot_template_request (List[AveragesSelection]):
            List of tuples ``("label", "value", "display_traces")``
            used to set which buttons are available as range selectors, which time
            window is associated with each button, and which time averages should be
            computed and visualized when each range selector is selected.

            ``label``: Label text for range selector button.

            ``value``: width of the displayed time window (in hours).

            ``display_traces``:
                Averaging values to be computed and shown when
                the button is selected.

            See full example below.

        traces_colorscale (dict):
            Dictionary with column names (as present in
            ``df``) as key, and associated trace color as value.

        instrument_sigma (float):
            Factory instrument sigma provided by Picarro and
            specific to instrument and species. Used to add the 3-sigma line.

        show_negative_values (bool): If False, the y-axis range is set to non-negative.

        reference_port_name (str):
            Name of the column of ``df`` to be used as
            reference port (used to calculate the 3-sigma lines).

        plot_title (str): Plot title.

        show_thumbnail (bool):
            If True, load the longest averaged trace in
            `plot_template_request` (i.e., the one with the
            lease data points) as `scatter` type.
            This will load a trace preview in the thumbnail,
            but it will slow down interactivity with the plot.

    Returns:
        go.Figure: Plotly time series Figure.

    |

    Full example:

    |

    df::

                                 port  ACETIC_ACID_raw  ACETONE_raw
        _datetime
        2021-09-27 13:00:00.816    -2       262.520254   -28.899937
        2021-09-27 13:00:03.945    -2      -105.801745    22.008788
        2021-09-27 13:00:06.874    -2       -79.066432    20.063865
        2021-09-27 13:00:09.961    -2       -35.619847    27.684586
        2021-09-27 13:00:13.181    -2       -55.939807    17.768177
        2021-09-27 13:00:16.434    -2        25.437810    -4.840371
        2021-09-27 13:00:19.684    -2       -36.261404     8.943119
        2021-09-27 13:00:22.820    -2       -34.429862     7.839540
        2021-09-27 13:00:26.107    -2        -9.548980    15.270276
        2021-09-27 13:00:29.369    -2       -31.084856    12.343878
        ...                       ...              ...          ...
        2021-09-30 11:04:15.953     3        30.687055    78.328359
        2021-09-30 11:04:19.380     3        23.687977    54.323852
        2021-09-30 11:04:22.747     3       -16.996492    78.256280
        2021-09-30 11:04:25.936     4       -13.308029    45.781465
        2021-09-30 11:04:29.138     4        -6.567299    62.506441
        2021-09-30 11:04:32.385     4      -181.111476    55.100920
        2021-09-30 11:04:35.674     4       -29.385352   104.168220
        2021-09-30 11:04:38.983     4       -28.031896    97.828046
        2021-09-30 11:04:42.520     4        29.793274    86.402157
        2021-09-30 11:04:45.908     4       -44.076293    79.668124

    |

    Filter out the port transitions.

    .. code-block:: python

        df = filter_port_transitions(original_df=df, trim_start=30, trim_end=10)
        df

    ::

                                 port  ACETIC_ACID_raw  ACETONE_raw
        _datetime
        2021-09-27 13:00:00.816    -2       262.520254   -28.899937
        2021-09-27 13:00:03.945    -2      -105.801745    22.008788
        2021-09-27 13:00:06.874    -2       -79.066432    20.063865
        2021-09-27 13:00:09.961    -2       -35.619847    27.684586
        2021-09-27 13:00:13.181    -2       -55.939807    17.768177
        2021-09-27 13:00:16.434    -2        25.437810    -4.840371
        2021-09-27 13:00:19.684    -2       -36.261404     8.943119
        2021-09-27 13:00:22.820    -2       -34.429862     7.839540
        2021-09-27 13:00:26.107    -2        -9.548980    15.270276
        2021-09-27 13:00:29.369    -2       -31.084856    12.343878
        ...                       ...              ...          ...
        2021-09-30 11:03:50.517     3         5.403030    51.580964
        2021-09-30 11:03:53.750     3       -30.549183    88.601302
        2021-09-30 11:03:56.928     3       -15.499143    66.979679
        2021-09-30 11:04:00.051     3       -29.363206    86.863694
        2021-09-30 11:04:03.241     3       -29.469699    65.828965
        2021-09-30 11:04:06.470     3       -60.431989    78.355480
        2021-09-30 11:04:09.527     3        12.371210    79.308416
        2021-09-30 11:04:12.787     3       -14.001300    63.845310
        2021-09-30 11:04:15.953     3        30.687055    78.328359
        2021-09-30 11:04:19.380     3        23.687977    54.323852


    |

    Define port mappings and reference port.

    .. code-block:: python

        mappings =  {
                1: "FOTP52-4_C",
                2:"FOTP52-4_D",
                3:"FOTP52-4_I",
                4:"FOTP52-4_P1",
                5:"FOTP52-4_P2",
                6:"FOTP52-04_DC",
                7:"MUX1-17_CR",
                8:"PAIAC",
                -2: "CDA"
        }

        reference_port = "PAIAC"

    |

    Map sampling ports.

    .. code-block:: python

        df = map_sampling_ports_name(df, mappings)
        df

    ::

                                       port  ACETIC_ACID_raw  ACETONE_raw
        _datetime
        2021-09-27 13:00:00.816         CDA       262.520254   -28.899937
        2021-09-27 13:00:03.945         CDA      -105.801745    22.008788
        2021-09-27 13:00:06.874         CDA       -79.066432    20.063865
        2021-09-27 13:00:09.961         CDA       -35.619847    27.684586
        2021-09-27 13:00:13.181         CDA       -55.939807    17.768177
        2021-09-27 13:00:16.434         CDA        25.437810    -4.840371
        2021-09-27 13:00:19.684         CDA       -36.261404     8.943119
        2021-09-27 13:00:22.820         CDA       -34.429862     7.839540
        2021-09-27 13:00:26.107         CDA        -9.548980    15.270276
        2021-09-27 13:00:29.369         CDA       -31.084856    12.343878
        ...                             ...              ...          ...
        2021-09-30 11:03:50.517  FOTP52-4_I         5.403030    51.580964
        2021-09-30 11:03:53.750  FOTP52-4_I       -30.549183    88.601302
        2021-09-30 11:03:56.928  FOTP52-4_I       -15.499143    66.979679
        2021-09-30 11:04:00.051  FOTP52-4_I       -29.363206    86.863694
        2021-09-30 11:04:03.241  FOTP52-4_I       -29.469699    65.828965
        2021-09-30 11:04:06.470  FOTP52-4_I       -60.431989    78.355480
        2021-09-30 11:04:09.527  FOTP52-4_I        12.371210    79.308416
        2021-09-30 11:04:12.787  FOTP52-4_I       -14.001300    63.845310
        2021-09-30 11:04:15.953  FOTP52-4_I        30.687055    78.328359
        2021-09-30 11:04:19.380  FOTP52-4_I        23.687977    54.323852

    |

    Use the reference port to perform zero-referencing with a 4H reference
    window averaging width using the function
    :py:func:`.get_adjusted_dataframe_from_reference_line`.
    This function can also be used to perform species selection,
    by using the field ``target_cols``.
    In this case, I am keeping only ACETIC_ACID_raw.
    Say instrument_sigma for ACETIC_ACID_raw is 27.2.

    |

    .. code-block:: python

        selected_species = "ACETIC_ACID_raw"
        inst_sigma = 27.2

        df = get_adjusted_dataframe_from_reference_line(
            original_df=df,
            reference_column_name=reference_port,
            target_cols=[selected_species],
            ref_window_width=Averaging.FOUR_HOURS
        )

        df

    ::

                                       port  ACETIC_ACID_raw
        _datetime
        2021-09-27 13:00:00.816         CDA       302.313913
        2021-09-27 13:00:03.945         CDA       -66.007462
        2021-09-27 13:00:06.874         CDA       -39.271564
        2021-09-27 13:00:09.961         CDA         4.175637
        2021-09-27 13:00:13.181         CDA       -16.143681
        2021-09-27 13:00:16.434         CDA        65.234586
        2021-09-27 13:00:19.684         CDA         3.536020
        2021-09-27 13:00:22.820         CDA         5.368188
        2021-09-27 13:00:26.107         CDA        30.249726
        2021-09-27 13:00:29.369         CDA         8.714500
        ...                             ...              ...
        2021-09-30 11:03:50.517  FOTP52-4_I        39.733786
        2021-09-30 11:03:53.750  FOTP52-4_I         3.781572
        2021-09-30 11:03:56.928  FOTP52-4_I        18.831613
        2021-09-30 11:04:00.051  FOTP52-4_I         4.967550
        2021-09-30 11:04:03.241  FOTP52-4_I         4.861057
        2021-09-30 11:04:06.470  FOTP52-4_I       -26.101233
        2021-09-30 11:04:09.527  FOTP52-4_I        46.701965
        2021-09-30 11:04:12.787  FOTP52-4_I        20.329456
        2021-09-30 11:04:15.953  FOTP52-4_I        65.017810
        2021-09-30 11:04:19.380  FOTP52-4_I        58.018733

    |

    Pivot the dataframe to get ports as columns. The NaN values are expected,
    as each port is sampled at different times.

    .. code-block:: python

        df = df.reset_index().pivot(
            index="_datetime", columns="port", values=selected_species
        )
        df.columns = df.columns.get_level_values(0)
        df

    ::

        port                            CDA  PAIAC  FOTP52-4_I  FOTP52-4_C
        _datetime
        2021-09-27 13:00:00.816  302.313913    NaN         NaN         NaN
        2021-09-27 13:00:03.945  -66.007462    NaN         NaN         NaN
        2021-09-27 13:00:06.874  -39.271564    NaN         NaN         NaN
        2021-09-27 13:00:09.961    4.175637    NaN         NaN         NaN
        2021-09-27 13:00:13.181  -16.143681    NaN         NaN         NaN
        2021-09-27 13:00:16.434   65.234586    NaN         NaN         NaN
        2021-09-27 13:00:19.684    3.536020    NaN         NaN         NaN
        2021-09-27 13:00:22.820    5.368188    NaN         NaN         NaN
        2021-09-27 13:00:26.107   30.249726    NaN         NaN         NaN
        2021-09-27 13:00:29.369    8.714500    NaN         NaN         NaN
        ...                             ...    ...         ...         ...
        2021-09-30 11:03:50.517         NaN    NaN   39.733786         NaN
        2021-09-30 11:03:53.750         NaN    NaN    3.781572         NaN
        2021-09-30 11:03:56.928         NaN    NaN   18.831613         NaN
        2021-09-30 11:04:00.051         NaN    NaN    4.967550         NaN
        2021-09-30 11:04:03.241         NaN    NaN    4.861057         NaN
        2021-09-30 11:04:06.470         NaN    NaN  -26.101233         NaN
        2021-09-30 11:04:09.527         NaN    NaN   46.701965         NaN
        2021-09-30 11:04:12.787         NaN    NaN   20.329456         NaN
        2021-09-30 11:04:15.953         NaN    NaN   65.017810         NaN
        2021-09-30 11:04:19.380         NaN    NaN   58.018733         NaN

    |

    Define colorscale (one color per column).

    .. code-block:: python

        import plotly.express as px
        colorscale = px.colors.qualitative.Bold
        mappings_cols =  {
                "FOTP52-4_C": colorscale[3],
                "FOTP52-4_I": colorscale[2],
                "PAIAC": colorscale[7],
                "CDA": colorscale[8]
        }

    |

    Define plotting template (explanation follows).

    .. code-block:: python

        plotting_requests = [
            AveragesSelection("ALL", 72, [Averaging.FOUR_HOURS.value]),
            AveragesSelection("1D", 24, [Averaging.ONE_HOUR.value]),
            AveragesSelection(
                "6H",
                6,
                [Averaging.HUNDRED_SECONDS.value, Averaging.THIRTY_SECONDS.value]
            )
        ]

    The plotting_requests state that:

    - Four averaging traces (per port) needs to be added to the plot:

        FOUR_HOURS, ONE_HOUR, HUNDRED_SECONDS, THIRTY_SECONDS

    - Three buttons need to be added to the menu and act as range selectors:

        ALL (show 72 hours).
            When selected, display only traces: FOUR_HOURS

        1D (show 24 hours).
            When selected, display only traces: ONE_HOUR

        6H (show 6 hours).
            When selected, display only traces:
            HUNDRED_SECONDS, THIRTY_SECONDS

    |

    Finally, get the timeline plot:

    .. code-block:: python

        fig = get_timeseries_plot_plotly(
            original_df = df,
            plot_template_request=plotting_requests,
            traces_colorscale=mappings_cols,
            instrument_sigma=inst_sigma,
            show_negative_values=False,
            reference_port_name=reference_port,
            plot_title=selected_species
        )
        fig.show()

    """

    if not isinstance(original_df, pd.DataFrame):
        raise TypeError(f"{original_df} is not a DataFrame")

    if not isinstance(original_df.index, pd.DatetimeIndex):
        raise ValueError("DataFrame does not have a DateTimeIndex")

    if not isinstance(plot_template_request, list):
        raise TypeError(f"{plot_template_request} is not a list")

    if not isinstance(traces_colorscale, dict):
        raise TypeError(f"{traces_colorscale} is not a dict")

    if not isinstance(instrument_sigma, float):
        raise TypeError(f"{instrument_sigma} is not a float")

    if not isinstance(show_negative_values, bool):
        raise TypeError(f"{show_negative_values} is not a bool")

    if not isinstance(reference_port_name, str):
        raise TypeError(f"{reference_port_name} is not a str")

    if reference_port_name not in original_df.columns:
        raise ValueError(f"{reference_port_name} not in df columns")

    if not isinstance(plot_title, str):
        raise TypeError(f"{plot_title} is not a str")

    fig_ts = go.Figure()

    for button, range_selector_request in enumerate(plot_template_request):

        show_markers = _get_markers_visibility(range_selector_request.display_traces)

        for trace, request in enumerate(range_selector_request.display_traces):

            requested_avg = next((el for el in Averaging if el.value == request), None)

            if requested_avg:
                fig_ts = _add_averaging_trace(
                    fig_ts,
                    original_timeline_df=original_df,
                    traces_colorscale=traces_colorscale,
                    show_marker=bool(show_markers[trace]),
                    requested_averaging=requested_avg,
                    reference_port_name=reference_port_name,
                    instrument_sigma=instrument_sigma,
                    scattergl_trace=not (show_thumbnail & bool(show_markers[trace])),
                )

    # Add zero line
    fig_ts.add_hline(
        y=0,
        line=dict(color="rgba(169,169,169, 0.3)", width=3),
    )

    # Get time bounds
    min_t, max_t = min(original_df.index), max(original_df.index)

    # Legend and template. Adjust x-axis range slider on last 6 hours
    fig_ts.update_layout(
        template="plotly_white",
        showlegend=True,
        legend=dict(orientation="v"),
        title=dict(text=plot_title, x=0, xanchor="left", xref="paper"),
        height=600,
        xaxis=dict(
            rangeslider=dict(visible=True, range=[min_t, max_t]),
            type="date",
            range=[f"{max_t - pd.DateOffset(hours=6)}", max_t],
        ),
    )

    # Cap y-axis at zero to hide negative values if requested
    if not show_negative_values:
        fig_ts.update_yaxes(rangemode="nonnegative", title="(ppb)")

    # Get the shortest time window (in hours) in the range selector
    short_window_h = min([button.value for button in plot_template_request])
    selected_button = next(
        (button for button in plot_template_request if button.value == short_window_h),
        None,
    )

    # Add buttons for range selector
    fig_ts = _add_range_menus(fig_ts, plot_template_request, max_t, selected_button)

    if selected_button:
        fig_ts.for_each_trace(
            lambda tr: tr.update(visible=tr.text in selected_button.display_traces)
        )

        fig_ts.update_layout(
            annotations=_update_annotation_y_coord(
                [
                    tr.meta
                    for tr in fig_ts.data
                    if tr.meta and tr.text in selected_button.display_traces
                ]
            ),
            xaxis=dict(
                range=[f"{max_t - pd.DateOffset(hours=selected_button.value)}", max_t]
            ),
        )

    return fig_ts
