"""This script provides the functions to create
a port average plot for the concentration values of one chemical species
across multiple different sampling ports."""
from enum import Enum

import numpy as np
import plotly.graph_objects as go
import pandas as pd
from plotly.subplots import make_subplots
from plotly.colors import convert_colors_to_same_type
from typing import List

from spectral_toolkit.constants.plotting_constants import ConcentrationUnits, Averaging
from spectral_toolkit.df_operations.timeline_process_df import (
    get_allan_deviation_dataframe,
)


class PortAvgActiveButton(Enum):
    """Enumerator for selection of which traces are displayed"""

    REFERENCED_NONNEGATIVE = 0
    REFERENCED_ALL = 1
    UNREFERENCED_ALL = 2


def _get_plotly_make_subplots_specs(n_ports: int) -> List[dict]:
    """Create a 'specs' list for Plotly make_subplots function (see
    https://plotly.com/python-api-reference/generated/plotly.subplots.make_subplots.html).
    It is used to create a (n_ports x 2) subplot grid, with column 2 having rowspan=n_ports.

    Args:
        n_ports (int): Number of sampling ports.

    Returns:
        list[dict]: Per subplot specifications of subplot type,
           row/column spanning, and spacing.
    """

    if not isinstance(n_ports, int):
        raise TypeError(f"{n_ports} is not an integer")

    specs = [[{}, {"rowspan": n_ports}]]
    for _ in range(1, n_ports):
        specs.append([{}, None])
    return specs


def rgb_to_rgba(rgb_value: str, alpha: float):
    """Adds the alpha channel to an RGB Value and returns it as an RGBA Value

    Args:

        rgb_value (str): Input RGB Value as ``rgb(---,---,---)``

        alpha (float): Alpha Value in range ``[0,1]``

    Returns:
         str: RGBA Value
    """
    if not isinstance(rgb_value, str):
        raise TypeError(f"{rgb_value} is not a string")

    if not isinstance(alpha, float):
        raise TypeError(f"{alpha} is not a float")

    if not (0 <= alpha <= 1):
        raise ValueError(f"{alpha} is not between 0 and 1")

    return f"rgba{rgb_value[3:-1]}, {alpha})"


def get_ports_average_plot(
        data_frame: pd.DataFrame,
        traces_colorscale: dict,
        synchronize_yaxis: bool = True,
        concentration_units=ConcentrationUnits.PPB,
        title_text: str = "",
        show_negative_values: bool = False,
        show_data_points_confidence: bool = False,
        multiline_plot: bool = False,
        raw_data_suffix: str = "_raw"
) -> go.Figure:
    """
    Returns a Plotly figure.

    Args:
        data_frame (pandas.DataFrame): Dataframe with ``DateTimeIndex`` named ``_datetime``
            and several other columns,
            each representing an experiment port. Null values in each column are needed in order
            to separate time intervals where the port is not being sampled.
            Time averaging does not occur in regions where null values are present.

        traces_colorscale (dict): Dictionary with column names (as present in df) as key,
            and associated trace color as value.

        synchronize_yaxis (bool): If True, the two time-series subplots are
            synchronized on the y-axis (the x-axis, representing time, is always
            shared between the two subplots). Default is True.

        concentration_units (ConcentrationUnits): Units for concentration in columns
            of dataframe df. Default is ppb.

        title_text (str): Title text to be displayed.
            It is also used as prefix for exported figures filenames.
            Default is empty string.

        show_negative_values (bool): Hide or show negative values.

        show_data_points_confidence (bool): Hide or show 95% confidence interval error bars
           related to the average over a sampling period.

        multiline_plot (bool): If True, the port traces are shown on different subplots.
           If False, the port traces are shown on the same plot.

        raw_data_suffix (str): Suffix for species in the `species` column identifying
            whether the data is in raw format (unreferenced).

    Returns:
        plotly.graph_object.Figure: Plotly figure.

    """

    if not isinstance(data_frame, pd.DataFrame):
        raise TypeError(f"{type(data_frame)} is not a DataFrame")

    if "_datetime" not in data_frame.index.names:
        raise ValueError("Can't find _datetime in index")

    if not isinstance(data_frame.index.get_level_values("_datetime"), pd.DatetimeIndex):
        raise ValueError("DataFrame does not have a DateTimeIndex")

    if not isinstance(traces_colorscale, dict):
        raise TypeError(f"{traces_colorscale} is not a dict")

    # Get the ports that are available to plot from the data frame
    ports_avail = data_frame.port.value_counts().index

    # Generate (1x2) grid (if multiline_plot is False)
    # or (n_ports x 2) grid (if multiline_plot)
    fig_port_ave = make_subplots(
        rows=len(ports_avail) if multiline_plot else 1,
        cols=2,
        specs=_get_plotly_make_subplots_specs(len(ports_avail))
        if multiline_plot
        else _get_plotly_make_subplots_specs(1),
        shared_xaxes=True,
        column_widths=[0.8, 0.2],
    )

    fig_port_ave.update_layout(template="plotly_white")

    # Add a plot zero line
    fig_port_ave.update_yaxes(
        zeroline=True, zerolinewidth=3, zerolinecolor="rgba(30,30,30,0.3)"
    )

    # Opacity of the scatter lines connecting markers
    line_opacity = 0.25

    hov_template = (
        f"Concentration: %{{y:.2f}} {concentration_units.value}<br><br>"
        f"Time: %{{x}}<br>"
        f"Averaged over %{{hovertext:.2f}} minutes<br>"
    )

    # For each available port, add a scatter and a box
    for j, port in enumerate(ports_avail):
        row_assignment = j + 1 if multiline_plot else 1

        port_df = data_frame.loc[data_frame.port == port]
        port_df = port_df.reset_index()

        raw_data_mask = port_df.species.str.endswith(raw_data_suffix)
        unreferenced_df = port_df[raw_data_mask]
        referenced_df = port_df[~raw_data_mask]

        # Set negatives values to zero if requested (only for referenced data)
        nonnegative_concentrations = np.where(
            referenced_df.concentration_mean >= 0, referenced_df.concentration_mean, 0
        )

        # Plot timeline averages
        # All
        fig_port_ave.add_trace(
            go.Scattergl(
                x=referenced_df["_datetime"],
                y=referenced_df.concentration_mean,
                mode="markers+lines",
                name=f"{port}",
                legendgroup=f"{port}",
                hovertemplate=hov_template,
                hovertext=referenced_df.interval_duration.dt.total_seconds() / 60,
                marker=dict(color=traces_colorscale[f"{port}"], size=10),
                line_color=rgb_to_rgba(
                    convert_colors_to_same_type(traces_colorscale[f"{port}"])[0][0],
                    line_opacity,
                ),
                error_y=dict(
                    type="data",
                    symmetric=False,
                    array=referenced_df.upper_bound_ci_concentration.to_numpy(),
                    arrayminus=referenced_df.lower_bound_ci_concentration.to_numpy(),
                    visible=show_data_points_confidence,
                ),
                meta="corrected_all"
            ),
            row=row_assignment,
            col=1,
        )

        # Non-negatives
        fig_port_ave.add_trace(
            go.Scattergl(
                x=referenced_df["_datetime"],
                y=nonnegative_concentrations,
                mode="markers+lines",
                name=f"{port}",
                legendgroup=f"{port}",
                hovertemplate=hov_template,
                hovertext=referenced_df.interval_duration.dt.total_seconds() / 60,
                marker=dict(color=traces_colorscale[f"{port}"], size=10),
                line_color=rgb_to_rgba(
                    convert_colors_to_same_type(traces_colorscale[f"{port}"])[0][0],
                    line_opacity,
                ),
                error_y=dict(
                    type="data",
                    symmetric=False,
                    array=referenced_df.upper_bound_ci_concentration.to_numpy(),
                    arrayminus=referenced_df.lower_bound_ci_concentration.to_numpy(),
                    visible=show_data_points_confidence,
                ),
                meta="corrected_nonnegative",
                showlegend=False
            ),
            row=row_assignment,
            col=1,
        )

        # Unreferenced
        fig_port_ave.add_trace(
            go.Scattergl(
                x=unreferenced_df["_datetime"],
                y=unreferenced_df.concentration_mean,
                mode="markers+lines",
                name=f"{port}",
                legendgroup=f"{port}",
                hovertemplate=hov_template,
                hovertext=unreferenced_df.interval_duration.dt.total_seconds() / 60,
                marker=dict(color=traces_colorscale[f"{port}"], size=10, symbol="circle-open", line_width=4),
                line_color=rgb_to_rgba(
                    convert_colors_to_same_type(traces_colorscale[f"{port}"])[0][0],
                    line_opacity,
                ),
                error_y=dict(
                    type="data",
                    symmetric=False,
                    array=unreferenced_df.upper_bound_ci_concentration.to_numpy(),
                    arrayminus=referenced_df.lower_bound_ci_concentration.to_numpy(),
                    visible=show_data_points_confidence,
                ),
                meta="uncorrected_all",
                showlegend=False,
                visible=False
            ),
            row=row_assignment,
            col=1,
        )

        # Box and whiskers for the whole timeline for the selected port
        fig_port_ave.add_trace(
            go.Box(
                name=f"{port}",
                legendgroup=f"{port}",
                y=referenced_df.concentration_mean,
                marker_color=traces_colorscale[f"{port}"],
                showlegend=False,
                boxmean=True,
                hoveron="boxes",
                meta="corrected_box"
            ),
            row=1,
            col=2,
        )

        fig_port_ave.add_trace(
            go.Box(
                name=f"{port}",
                legendgroup=f"{port}",
                y=unreferenced_df.concentration_mean,
                marker_color=traces_colorscale[f"{port}"],
                showlegend=False,
                boxmean=True,
                hoveron="boxes",
                meta="uncorrected_box",
                visible=False
            ),
            row=1,
            col=2,
        )

    # Synchronize all y axis to the same scale
    if synchronize_yaxis:
        for j in range(len(ports_avail)):
            fig_port_ave.update_yaxes(matches="y", row=j + 1, col=1)

        if not multiline_plot:
            fig_port_ave.update_yaxes(matches="y", row=1, col=2)

    # Axis title
    fig_port_ave.update_yaxes(title=f"({concentration_units.value})")

    # Add title
    fig_port_ave.update_layout(
        title=dict(text=f"{title_text}", xanchor="left", x=0, xref="paper"),
    )

    # Place legend
    fig_port_ave.update_layout(
        legend=dict(orientation="h", yanchor="top", y=-0.2, xanchor="right", x=0.7)
    )

    # Cut the y axis at zero to hide negative values if requested
    if not show_negative_values:
        fig_port_ave.update_yaxes(rangemode="nonnegative")

    selected_button = PortAvgActiveButton.REFERENCED_ALL if show_negative_values else PortAvgActiveButton.REFERENCED_NONNEGATIVE
    fig_port_ave = _add_menu_dropdowns(fig_port_ave, selected_button)
    _toggle_initial_traces_visibility(fig_port_ave, selected_button)

    return fig_port_ave


def _add_menu_dropdowns(initial_fig: go.Figure,
                        selected_button: PortAvgActiveButton = PortAvgActiveButton.REFERENCED_NONNEGATIVE
                        ) -> go.Figure:
    """
    Add drop down menu items for referenced all, referenced nonnegative,
    unreferenced all data.

    Args:
        initial_fig (go.Figure):
            Initial Plotly figure.

        selected_button (PortAvgActiveButton):
            Button that should initially be selected.

    Returns:
        go.Figure: New Plotly figure with menu dropdowns.
    """

    fig_port_ave = go.Figure(initial_fig)

    # Add dynamic option to hide negative values
    fig_port_ave.update_layout(
        updatemenus=[
            dict(
                type="dropdown",
                direction="down",
                active=selected_button.value,
                buttons=[
                    dict(
                        args=[
                            {
                                "visible": [tr.meta in ["corrected_nonnegative", "corrected_box"] for tr in
                                            fig_port_ave.data],
                                "showlegend": [tr.meta in ["corrected_nonnegative"] for tr in fig_port_ave.data],
                            },
                            {
                                "yaxis.rangemode": "nonnegative"
                            }
                        ],
                        label="Corrected (>=0)",
                        method="update",
                    ),
                    dict(
                        args=[
                            {
                                "visible": [tr.meta in ["corrected_all", "corrected_box"] for tr in fig_port_ave.data],
                                "showlegend": [tr.meta in ["corrected_all"] for tr in fig_port_ave.data],
                            },
                            {
                                "yaxis.rangemode": "normal"
                            }
                        ],
                        label="Corrected (All)",
                        method="update",
                    ),
                    dict(
                        args=[
                            {
                                "visible": [tr.meta in ["uncorrected_all", "uncorrected_box"] for tr in
                                            fig_port_ave.data],
                                "showlegend": [tr.meta in ["uncorrected_all"] for tr in fig_port_ave.data],
                            },
                            {
                                "yaxis.rangemode": "normal"
                            }
                        ],
                        label="Uncorrected (All)",
                        method="update",
                    ),
                ],
                pad={"r": 10, "t": 10},
                showactive=True,
                x=1,
                xanchor="right",
                y=1.18,
                yanchor="bottom",
            ),
        ]
    )

    return fig_port_ave


def _toggle_initial_traces_visibility(fig: go.Figure,
                                      selected_button: PortAvgActiveButton = PortAvgActiveButton.REFERENCED_NONNEGATIVE
                                      ) -> None:
    """
    After adding a menu dropdown, I need to set
    the traces are to be displayed initially according
    to the selected button.

    Args:
        fig (go.Figure):
            Plotly figure which traces visibilty will be changed.

        selected_button (PortAvgActiveButton):
            Button that determines which traces are to be displayed.

    Returns:
        None

    """
    trace_filter = []
    if selected_button.value == PortAvgActiveButton.REFERENCED_ALL.value:
        trace_filter = ["corrected_all", "corrected_box"]
    elif selected_button.value == PortAvgActiveButton.REFERENCED_NONNEGATIVE.value:
        trace_filter = ["corrected_nonnegative", "corrected_box"]
    else:
        trace_filter = ["uncorrected_all", "uncorrected_box"]

    fig.for_each_trace(
        lambda trace: trace.update(visible=True)
        if (trace.meta in trace_filter)
        else trace.update(visible=False)
    )

    return None


def add_reference_three_sigma(
        original_fig: go.Figure,
        reference_port_ts: pd.Series,
        selected_averaging: Averaging = Averaging.HUNDRED_SECONDS,
) -> go.Figure:
    """
    Returns a Plotly figure with updated measurement three sigma trace.

    Args:
        original_fig (plotly.graph_objects.Figure): Original Plotly figure.

        reference_port_ts (pd.Series): Time series with mean concentration values
            for the reference port.

        selected_averaging (Averaging): The currently selected averaging value for which
            the reference line is computed

    Returns:
        plotly.graph_object.Figure: Plotly figure.

    |
    |
    Full Example:

    df_original::

                                       concentration  port
        _datetime
        1970-06-16 10:04:20.024999858     -20.774936     2
        1970-06-16 10:04:22.881999970       2.173202     2
        1970-06-16 10:04:25.792999982       6.775390     2
        ...                                      ...   ...
        1970-06-18 07:27:51.288000108      33.477997     2
        1970-06-18 07:27:54.296000004      88.928290     2
        1970-06-18 07:27:57.345999956      64.941164     2
    |
    Prepare data frame:

    .. code-block:: python

        port_maps = {1: "Reference", 2: "Inlet", 3: "Middle", 4: "Outlet"}
        df_mapped = map_sampling_ports_name(df_original, port_maps)
        df_referenced = get_adjusted_dataframe_from_reference_line(df_mapped, "Reference")
        df_ref_intervals = get_intervals_statistics(df_referenced)
        fig = get_ports_average_plot(
            df_ref_intervals,
            color_assignment,
            title_text=species,
            show_negative_values=False,
            show_data_points_confidence=False,
            multiline_plot=False,
        )

    |
    Add reference 3-sigma:

    .. code-block:: python

        fig_test = add_reference_three_sigma(
            fig, df_ref_intervals[df_ref_intervals.port == "Reference"].concentration_mean
        )
        fig_test.show()

    """
    fig_ret = go.Figure(original_fig)

    if not isinstance(original_fig, go.Figure):
        raise TypeError(f"{type(original_fig)} is not a Figure")

    if not isinstance(reference_port_ts, pd.Series):
        raise TypeError(f"{reference_port_ts} is not a Pandas series")

    if not isinstance(reference_port_ts.index, pd.DatetimeIndex):
        raise ValueError("Series does not have a DateTimeIndex")

    # Get the Allan deviation for the reference time series
    allan_deviation_df = get_allan_deviation_dataframe(
        reference_port_ts
    )

    # Approximate sigma as the first element of Allan deviation
    three_sigma_value = 3 * allan_deviation_df.allan_dev[0]

    fig_ret.add_trace(
        go.Scattergl(
            x=reference_port_ts.index,
            y=np.full(len(reference_port_ts.index), three_sigma_value),
            line_color="rgba(240,128,128, 0.4)",
            fill="tozeroy",
            fillcolor="rgba(240,128,128, 0.05)",
            text=selected_averaging.value,
            name=f"3&#x3C3;<sub>meas</sub> ({selected_averaging.value})",
            line_dash="solid",
            showlegend=False,
            mode="lines",
            hovertemplate="3&#x3C3;<sub>meas</sub> (%{hovertext}) = %{y:.1f} ppb<extra></extra>",
            hovertext=np.full(len(reference_port_ts.index), selected_averaging.value),
        )
    )

    return fig_ret


def add_three_sigma_instrument(
        original_fig: go.Figure, instrument_sigma: float, interval_durations: pd.Series
):
    """
    Returns a Plotly figure with updated instrument three sigma annotation.

    Args:
        original_fig (plotly.graph_objects.Figure): Original Plotly figure.

        instrument_sigma (float): Factory instrument sigma provided by Picarro and
            specific to instrument and species.

        interval_durations (pd.Series): Time series with duration of each sampling
           period.
           Extracted from column ``interval_duration`` of
           :py:func:`.get_intervals_statistics`.

    Returns:
        plotly.graph_object.Figure: Plotly figure.

    |
    |
    Full Example:

    df_original::

                                       concentration  port
        _datetime
        1970-06-16 10:04:20.024999858     -20.774936     2
        1970-06-16 10:04:22.881999970       2.173202     2
        1970-06-16 10:04:25.792999982       6.775390     2
        ...                                      ...   ...
        1970-06-18 07:27:51.288000108      33.477997     2
        1970-06-18 07:27:54.296000004      88.928290     2
        1970-06-18 07:27:57.345999956      64.941164     2

    |
    Prepare data frame:

    .. code-block:: python

        port_maps = {1: "Reference", 2: "Inlet", 3: "Middle", 4: "Outlet"}
        df_mapped = map_sampling_ports_name(df_original, port_maps)
        df_referenced = get_adjusted_dataframe_from_reference_line(df_mapped, "Reference")
        df_ref_intervals = get_intervals_statistics(df_referenced)
        fig = get_ports_average_plot(
            df_ref_intervals,
            color_assignment,
            title_text=species,
            show_negative_values=False,
            show_data_points_confidence=False,
            multiline_plot=False,
        )

    |
    Add instrument 3-sigma:

    .. code-block:: python

        fig_test = add_three_sigma_instrument(
            fig, instrument_sigma, df_ref_intervals[df_ref_intervals.port == "Reference"].interval_duration
        )
        fig_test.show()
    """

    if not isinstance(original_fig, go.Figure):
        raise TypeError(f"{type(original_fig)} is not a Figure")

    if not isinstance(interval_durations, pd.Series):
        raise TypeError(f"{interval_durations} is not a Pandas series")

    if interval_durations.dtype != "timedelta64[ns]":
        raise TypeError(f"{interval_durations} is not timedelta64[ns]")

    if not isinstance(instrument_sigma, float):
        raise TypeError(f"{instrument_sigma} is not a float")

    fig_ret = go.Figure(original_fig)

    # Median sampling time in seconds
    deltat = np.median(interval_durations) / np.timedelta64(1, "s")

    three_sigma_value = 3 * instrument_sigma / np.sqrt(deltat)

    fig_ret.add_annotation(
        x=0,
        xref="paper",
        xanchor="left",
        y=1,
        yanchor="bottom",
        yref="paper",
        text=f"3&#x3C3;<sub>inst</sub> = {three_sigma_value:.1f} ppb",
        showarrow=False,
        font_color="rgb(105,105,105)",
    )

    return fig_ret


def get_comparison_port_average_plot(
        fig_zero_referenced: go.Figure, fig_raw: go.Figure
) -> go.Figure:
    """
    Aggregate a zero-reference data figure and a raw data figure.

    Args:
        fig_zero_referenced (go.Figure): Figure with zero-referenced data

        fig_raw (go.Figure): Figure with raw data.

    Returns:
        go.Figure: Aggregated figure with ref/raw dropdown menu.
    |
    Example:

    .. code-block:: python

        fig_zero_ref = get_ports_average_plot(
            df_ref_intervals,
            color_assignment,
            title_text=species,
            show_negative_values=False,
            show_data_points_confidence=False,
            multiline_plot=False,
        )

        fig_zero_ref = add_three_sigma_instrument(
            fig_zero_ref, instrument_sigma, df_ref_intervals[df_ref_intervals.port == "Reference"].interval_duration
        )

        fig_raw = get_ports_average_plot(
            df_intervals,
            color_assignment,
            title_text="My_species",
            show_negative_values=True,
            show_data_points_confidence=False,
            multiline_plot=False
        )

    Get the aggregated figure:

    .. code-block:: python

        fig_ret = get_comparison_port_average_plot(fig_ref, fig_raw)
        fig_ret.show()
    """
    if not isinstance(fig_zero_referenced, go.Figure):
        raise TypeError(f"{type(fig_zero_referenced)} is not a Figure")

    if not isinstance(fig_raw, go.Figure):
        raise TypeError(f"{type(fig_raw)} is not a Figure")

    # Define output figure
    fig_ret = go.Figure(fig_zero_referenced)

    # Hide traces in raw figure
    fig_raw.for_each_trace(
        lambda t: t.update(name=t.name, legendgroup=t.name, visible=False)
    )

    # Add identifier for zero-referenced traces as legendgroup ending in "_0ref"
    fig_ret.for_each_trace(
        lambda t: t.update(name=t.name, legendgroup=t.name + "_0ref")
    )

    # Add the raw traces to the output
    for trace in fig_raw.data:
        fig_ret.add_trace(trace)

    # Add dynamic option to select raw or zero-referenced traces
    zero_ref_menu = [
        dict(
            type="dropdown",
            direction="down",
            active=1,
            buttons=list(
                [
                    dict(
                        args=[
                            {
                                "visible": [
                                    False if tr.legendgroup.endswith("_0ref") else True
                                    for tr in fig_ret.data
                                ]
                            }
                        ],
                        label="Raw",
                        method="update",
                    ),
                    dict(
                        args=[
                            {
                                "visible": [
                                    True if tr.legendgroup.endswith("_0ref") else False
                                    for tr in fig_ret.data
                                ]
                            }
                        ],
                        label="Ref",
                        method="update",
                    ),
                ]
            ),
            pad={"r": 10, "t": 10},
            showactive=True,
            x=0.9,
            xanchor="right",
            y=1.18,
            yanchor="bottom",
        )
    ]

    fig_ret.update_layout(
        updatemenus=fig_ret.layout.updatemenus
                    + go.Figure().update_layout(updatemenus=zero_ref_menu).layout.updatemenus
    )
    return fig_ret
