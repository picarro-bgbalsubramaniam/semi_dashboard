"""Creates a summary table in Plotly"""

import plotly.graph_objs as go
import pandas as pd


def get_summary_table(
    stats_df: pd.DataFrame, colormap: dict, title: str = "", subtitle: str = ""
) -> go.Figure:
    """
    Return a summary table plot from ``stats_df``.
    The DataFrame ``stats.df`` must originate from :py:func:`.get_statistics_on_all_intervals`.

    Args:

        stats_df (pd.DataFrame):
            DataFrame from :py:func:`.get_statistics_on_all_intervals`.

        colormap (dict):
            Colors dictionary for coloring based on port.
            Port is the key, a list of two colors (for even and odd rows) is the value.

            Example: ``cmap = {'PAIAC': ['black', 'gray']}``

        title (str): Title of the plot.

        subtitle (str):
            Subtitle of the plot.
            Suggestion (after running :py:func:`.get_intervals_statistics`)::

                subtitle =
                f"{df_intervals['interval_start'].dt.strftime('%b %d, %Y %I:%M%p').iloc[0]}"
                f" to "
                f"{df_intervals['interval_end'].dt.strftime('%b %d, %Y %I:%M%p')[-1]}")

    Returns:

        go.Figure: Plotly Figure.

    |

    Full example:

    |

    df::

                                 port  ACETONE_raw  D3_SILOXANE_raw
        _datetime
        2021-09-27 13:00:00.816    -2   -28.899937         7.739315
        2021-09-27 13:00:03.945    -2    22.008788       -10.727872
        2021-09-27 13:00:06.874    -2    20.063865        -4.031228
        ...                       ...          ...              ...
        2021-09-30 11:04:38.983     4    97.828046        -1.590447
        2021-09-30 11:04:42.520     4    86.402157         1.135383
        2021-09-30 11:04:45.908     4    79.668124       -10.479142

    |

    Filter out the port transitions.

    .. code-block:: python

        df = filter_port_transitions(original_df=df, trim_start=30, trim_end=10)
        df

    ::

                                 port  ACETONE_raw  D3_SILOXANE_raw
        _datetime
        2021-09-27 13:00:00.816    -2   -28.899937         7.739315
        2021-09-27 13:00:03.945    -2    22.008788       -10.727872
        2021-09-27 13:00:06.874    -2    20.063865        -4.031228
        ...                       ...          ...              ...
        2021-09-30 11:04:12.787     3    63.845310        -3.382576
        2021-09-30 11:04:15.953     3    78.328359        -0.827777
        2021-09-30 11:04:19.380     3    54.323852       -10.084526

    |

    Define port mappings and reference port.

    .. code-block:: python

        mappings =  {
                1:"FOTP52-4_C",
                2:"FOTP52-4_D",
                3:"FOTP52-4_I",
                4:"FOTP52-4_P1",
                5:"FOTP52-4_P2",
                6:"FOTP52-04_DC",
                7:"MUX1-17_CR",
                8:"PAIAC",
                -2: "CDA"
        }

        reference_port = "PAIAC"

    |

    Map sampling ports.

    .. code-block:: python

        df = map_sampling_ports_name(df, mappings)
        df

    ::

                                       port  ACETONE_raw  D3_SILOXANE_raw
        _datetime
        2021-09-27 13:00:00.816         CDA   -28.899937         7.739315
        2021-09-27 13:00:03.945         CDA    22.008788       -10.727872
        2021-09-27 13:00:06.874         CDA    20.063865        -4.031228
        ...                             ...          ...              ...
        2021-09-30 11:04:12.787  FOTP52-4_I    63.845310        -3.382576
        2021-09-30 11:04:15.953  FOTP52-4_I    78.328359        -0.827777
        2021-09-30 11:04:19.380  FOTP52-4_I    54.323852       -10.084526

    |

    Use the reference port to perform zero-referencing with a 4H reference
    window averaging width using
    :py:func:`.get_adjusted_dataframe_from_reference_line`.

    |

    .. code-block:: python

        selected_species = [col for col in df.columns if col != "port"]
        df = get_adjusted_dataframe_from_reference_line(
            original_df=df,
            reference_column_name=reference_port,
            target_cols=selected_species,
            ref_window_width=Averaging.FOUR_HOURS
        )
        df

    ::

                                       port  ACETONE_raw  D3_SILOXANE_raw
        _datetime
        2021-09-27 13:00:00.816         CDA   -35.954172        12.149368
        2021-09-27 13:00:03.945         CDA    14.954100        -6.318077
        2021-09-27 13:00:06.874         CDA    13.008754         0.378325
        ...                             ...          ...              ...
        2021-09-30 11:04:12.787  FOTP52-4_I    41.640254        -0.212276
        2021-09-30 11:04:15.953  FOTP52-4_I    56.123302         2.342524
        2021-09-30 11:04:19.380  FOTP52-4_I    32.118795        -6.914226

    |

    Get intervals statistics (means sampling periods).

    .. code-block:: python

        df_intervals=get_intervals_statistics(
                        original_unmarked_df = df,
                        target_cols = [col for col in df.columns if col != "port"]
        )

    Get statistics on intervals (mean of intervals).
    First, I need to define a mapping dict for instrument sigmas.

    .. code-block:: python

        instrument_sigmas =
            {
                "ACETONE_raw": 25.0,
                "D3_SILOXANE_raw": 7.0
        }

        stats_df = get_statistics_on_all_intervals(
                            df_intervals=df_intervals,
                            instrument_sigma_dict=instrument_sigmas
        )

    Define a colormap:

    .. code-block:: python

        from plotly.colors import colorbrewer as cb
        colorscale = px.colors.qualitative.Bold
        mappings_cols =  {
                "FOTP52-4_D":   [cb.Set2[7], cb.Pastel2[7]],
                "FOTP52-4_I":   [cb.Set2[6], cb.Pastel2[6]],
                "FOTP52-4_P1":  [cb.Set2[5], cb.Pastel2[5]],
                "FOTP52-4_P2":  [cb.Set2[4], cb.Pastel2[4]],
                "FOTP52-04_DC": [cb.Set2[3], cb.Pastel2[3]],
                "MUX1-17_CR":   [cb.Set2[2], cb.Pastel2[2]],
                "PAIAC":        [cb.Set2[1], cb.Pastel2[1]],
                "CDA":          [cb.Set2[0], cb.Pastel2[0]]
        }

    Get the table plot:

    .. code-block:: python

        fig = get_summary_table(
            stats_df=stats_df,
            colormap=mappings_cols,
            title="Experiment test"
        )
        fig.show()

    """

    if not isinstance(stats_df, pd.DataFrame):
        raise TypeError(f"{stats_df} is not a DataFrame")

    if not isinstance(colormap, dict):
        raise TypeError("colormap is not a dict")

    # Check all ports in stats_df are mapped in the colormap
    ports = stats_df.columns.get_level_values(0).unique().tolist()

    if not all(port in colormap for port in ports):
        raise ValueError("colormap shall contain all ports present in stats_df")

    # Check all ports have two colors available
    if not all(len(val) == 2 for key, val in colormap.items()):
        raise ValueError("colormap needs a list of two colors" "per key")

    # Check that all ports have a "display" field
    if not all("display" in stats_df[port].columns for port in ports):
        raise ValueError(
            "stats_df must contain a (port, 'display') pair for every port"
        )

    if not isinstance(title, str):
        raise TypeError("title shall be str")

    if not isinstance(subtitle, str):
        raise TypeError("subtitle shall be str")

    fig_ret = go.Figure(
        data=[
            go.Table(
                header=dict(
                    values=[
                        "<b>Species</b><br>&mu; &plusmn; &#x3C3;<sub>meas</sub>"
                        " (&#x3C3;<sub>inst</sub>)"
                    ]
                    + [f"<b>{port}</b>" for port in ports],
                    fill_color=["white"]
                    + [colormap.get(port, "white")[1] for port in ports],
                    line_color="black",
                    align="center",
                    font_size=14,
                ),
                cells=dict(
                    values=[stats_df.index.get_level_values("species_display").values]
                    + [stats_df[(port, "display")] for port in ports],
                    fill_color=["white"]
                    + [
                        [
                            colormap.get(port, "white")[i % 2]
                            for i in range(len(stats_df))
                        ]
                        for port in ports
                    ],
                    align="right",
                    line_color="black",
                ),
            )
        ],
        layout=dict(
            template="plotly_white", height=1500, title=f"<b>{title}</b><br>{subtitle}"
        ),
    )
    return fig_ret
