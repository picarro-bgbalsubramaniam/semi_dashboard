"""Create unknown identification plots"""

from typing import List, Tuple

import numpy as np
import pandas as pd
import plotly.graph_objs as go
import xarray as xr
from pandas.core.dtypes.common import is_bool_dtype
from plotly.subplots import make_subplots
from pydantic import validate_call

from spectral_toolkit.logger import get_logger

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True))
def add_port_menus(
    original_fig: go.Figure,
    ports: List[str],
) -> go.Figure:
    """
    Add menu with ``port`` selector on existing figure.
    The ``port`` menu filters the traces visibility based
    on the ``text`` attribute of each trace.

    Args:
        original_fig (go.Figure): Original Plotly Figure.

        ports:
            List of port names.

    Returns:
        go.Figure: New Plotly Figure.
    """

    ret_fig = go.Figure(original_fig)

    # Define and add dropdown menu to figure
    menu_port = [
        dict(
            active=0,
            type="dropdown",
            direction="down",
            buttons=[
                {
                    "label": f"{port}",
                    "args": [
                        {
                            "visible": [
                                (tr.text == port) | (tr.text == "always_on")
                                for tr in ret_fig.data
                            ],
                        },
                    ],
                    "method": "restyle",
                }
                for port in ports
            ],
            pad={"r": 10, "t": 10},
            showactive=True,
            x=1,
            xanchor="right",
            y=1.04,
            yanchor="bottom",
        )
    ]
    ret_fig.update_layout(updatemenus=menu_port)

    # Set traces for max FOM port as visible
    ret_fig.for_each_trace(
        lambda t: t.update(visible=True)
        if (t.text == next(iter(ports))) | (t.text == "always_on")
        else None
    )

    return ret_fig


@validate_call(config=dict(arbitrary_types_allowed=True))
def add_warning_lines(
    original_fig: go.Figure,
    warning_threshold: float = 1.0,
    error_threshold: float = 2.0,
) -> go.Figure:
    """
    Add warning and error lines and area shading.

    Args:
        original_fig (go.Figure): Original Plotly Figure.

        warning_threshold (float):
            Threshold for warning (yellow shading).
            Default is 1.0 (i.e., 3 sigma)

        error_threshold (float):
            Threshold for error (red shading).
            Default is 1.0 (i.e., 3 sigma)

    Returns:
        go.Figure: New Plotly Figure

    """
    ret_fig = go.Figure(original_fig)

    # Get current yaxis limits
    yaxes_range = ret_fig.layout.yaxis.range

    if not yaxes_range:
        yaxes_range = [0, 0]

    if np.isfinite(error_threshold) and np.isfinite(warning_threshold):
        # Error area up
        ret_fig.add_hrect(
            y0=error_threshold,
            y1=yaxes_range[1] if yaxes_range[1] > error_threshold else error_threshold,
            fillcolor="rgb(178,34,34)",
            line_width=0,
            opacity=0.05,
        )

        # Error area down
        ret_fig.add_hrect(
            y0=-error_threshold,
            y1=yaxes_range[0]
            if yaxes_range[0] < -error_threshold
            else -error_threshold,
            fillcolor="rgb(178,34,34)",
            line_width=0,
            opacity=0.05,
        )

        # Warning area up
        ret_fig.add_hrect(
            y0=error_threshold,
            y1=warning_threshold,
            fillcolor="rgb(230,204,0)",
            line_width=0,
            opacity=0.1,
        )

        # Warning area down
        ret_fig.add_hrect(
            y0=-error_threshold,
            y1=-warning_threshold,
            fillcolor="rgb(239,204,0)",
            line_width=0,
            opacity=0.1,
        )

        # Warning lines
        ret_fig.add_hline(
            y=warning_threshold,
            line=dict(color="rgba(239,204,0, 0.3)", width=2, dash="dash"),
        )
        ret_fig.add_hline(
            y=-warning_threshold,
            line=dict(color="rgba(239,204,0, 0.3)", width=2, dash="dash"),
        )

        # Error lines
        ret_fig.add_hline(
            y=error_threshold,
            line=dict(color="rgba(178,34,34,0.1)", width=2, dash="dash"),
        )

        ret_fig.add_hline(
            y=-error_threshold,
            line=dict(color="rgba(178,34,34,0.1)", width=2, dash="dash"),
        )

    return ret_fig


@validate_call(config=dict(arbitrary_types_allowed=True))
def get_unknowns_fom_plot(
    intervals_fom_xr: xr.Dataset,
    species_colormap: dict,
    show_boxplot: bool = True,
    legend_group: pd.Series = None,
) -> go.Figure:
    """
    Get unknown identification figure of merit (FOM) plot as Plotly Figure.

    Args:
        intervals_fom_xr (xr.Dataset):
            Figure of merit dataset from
            :py:func: `.intervals_figure_of_merit_xarray`

        species_colormap (dict):
            Dictionary with species name as ``key`` (as it appears
            in ``adjusted_df``) and a correspondent color as
            ``value``.

        show_boxplot (bool):
            Whether or not to show a cumulative summary
            box plot as subplot.

        legend_group (pd.Series):
            Series with ``species`` (as they appear in intervals_fom_xr)
            as index and ``legend_group`` as values.
            If ``None``, no legend group will be used.


    Returns:
        go.Figure: Plotly unknown identification FOM plot.

    |

    Working example:

    |

    df::

                                 port  ACETIC_ACID_raw  ACETONE_raw  D3_SILOXANE_raw
        _datetime
        2021-09-24 08:00:00.967     1       -25.821464    29.914481        -5.656820
        2021-09-24 08:00:04.063     1       -68.293837    40.670523         0.542039
        2021-09-24 08:00:07.046     1       -31.898199    16.230979        -8.761772
        2021-09-24 08:00:10.066     1       -11.994506    42.310831         4.931810
        2021-09-24 08:00:13.233     1       -57.677749    44.118723        -4.039450
        ...                       ...              ...          ...              ...
        2022-01-04 12:17:32.974     0       -33.198628    51.621855        -7.227335
        2022-01-04 12:17:36.369     0       -12.339654    44.279394         1.047129
        2022-01-04 12:17:39.838     0       -93.682196    94.731471        -1.583656
        2022-01-04 12:17:43.214     0       -80.398684    40.603501        -5.897146
        2022-01-04 12:17:46.609     0       -82.952727    21.785655        -0.951055


    Filter port transitions (10s and 30s) with :py:func:`.filter_port_transitions`:

    .. code-block:: python

        df = filter_port_transitions(original_df=df, trim_start=30, trim_end=10)

    Define port mappings::

        mappings = {
            1: "Port 1",
            2: "Port 2",
            ...
            8: "Reference",
            -2: "Port 9",
        }

    .. code-block:: python

        reference_port = "Reference"

    Map ports with :py:func:`.map_sampling_ports_name`.

    .. code-block:: python

        df = map_sampling_ports_name(df, mappings)

    Get adjusted dataframe with :py:func:`.get_adjusted_dataframe_from_reference_line`.

    .. code-block:: python

        df_adj = get_adjusted_dataframe_from_reference_line(
            original_df=df,
            reference_column_name=reference_port,
            target_cols=["ACETIC_ACID_raw", "ACETONE_raw"],
            ref_window_width=Averaging.FOUR_HOURS,
        )

    Define instrument sigma dictionary and colormap:

    .. code-block:: python

        inst_lods = {'ACETIC_ACID_raw': 47.0, 'ACETONE_raw': 25.0}

        species_cmap = dict(zip(["ACETIC_ACID_raw", "ACETONE_raw"],
         px.colors.qualitative.Light24))

    Define LOD time scales:

    .. code-block:: python

        lod_ave_time = 100
        lod_sigma = 3
        sigma_scale = 3

    Get FOMs:

     .. code-block:: python

        fom_xr = intervals_figure_of_merit_xarray(
            start_df=df_adj,
            instrument_lods=inst_lods,
            lod_ave_time=lod_ave_time,
            lod_sigma=lod_sigma,
            sigma_scale=sigma_scale,
            duration_thresholding_percentile = True
        )

    Get plot:

    .. code-block:: python

        fig = get_unknowns_fom_plot(
            intervals_fom_xr=fom_xr,
            species_colormap=species_cmap,
            show_boxplot= True,
            )

        fig = add_flags(fig, _get_flags_labels(flags_df))

        # Sort ports based on max FOM encountered for each port
        # so that the default selected port is the one presenting
        # more unknown interferences
        max_port_values = (
            fom_xr.max(dim=["_datetime", "species"])
                .sortby("fom", ascending=False)["port"]
                .values.tolist()
        )

        # Add menus to show one port at the time
        # sorted by decreasing max FOM
        fig = add_port_menus(fig, max_port_values)

        fig = add_warning_lines(
            original_fig=fig,
            error_threshold=2.0,
            warning_threshold=1.0
        )

        fig.show()

    If needed, species can be grouped. Otherwise, no species
    will be grouped.
    The ``legend_group`` parameter shall be a pandas Series with the species as
    index and the legend group as values.
    Example:

    .. code-block:: python
        def evaluate_some_condition(species: str):
            return "Group A" if len(species) > 5 else "Group B"

        legend_group_assignment = pd.Series({
            spec: evaluate_some_condition(spec)
            for spec in species
        })

    Then proceed with the plot as earlier, but provide the
    ``legend_group`` parameter:

    .. code-block:: python

        fig = get_unknowns_fom_plot(
            intervals_fom_xr=fom_xr,
            species_colormap=species_cmap,
            show_boxplot= True,
            legend_group=legend_group_assignment
            )

    """

    check_coordinates = ["species", "_datetime", "port"]
    if set(check_coordinates) != set(intervals_fom_xr.coords.variables.mapping):
        raise ValueError("Missing coordinates in intervals_fom_xr")

    all_species = intervals_fom_xr.species.values

    if not all(species in species_colormap for species in all_species):
        raise ValueError(
            "species_colormap shall contain all species present in adjusted_df"
        )

    # Create a subplot
    # If boxplot is requested, then use two cols
    # Otherwise, use a single 1x1 plot
    return_fig = make_subplots(
        rows=1,
        cols=2 if show_boxplot else 1,
        column_widths=[0.7, 0.3] if show_boxplot else [1],
        shared_yaxes=True,
        horizontal_spacing=0.01,
    )

    # Proceed one port at the time
    for port in intervals_fom_xr.port.values:
        # Proceed one species at the time
        for species in intervals_fom_xr.sel(port=port).species.values:
            # Add FOM to plot
            return_fig.add_trace(
                go.Scattergl(
                    x=intervals_fom_xr["_datetime"],
                    y=intervals_fom_xr["fom"].sel(port=port, species=species),
                    name=species,
                    line_color=species_colormap[species],
                    text=port,
                    hovertemplate=f"Port: <b>{port}</b><br>"
                    f"%{{x}}<br>"
                    f"FOM: %{{y:.2f}}<br>",
                    visible=False,
                    connectgaps=True,
                ),
                row=1,
                col=1,
            )

            if show_boxplot:
                return_fig.add_trace(
                    go.Box(
                        name=species,
                        text=port,
                        y=intervals_fom_xr["fom"].sel(port=port, species=species),
                        visible=False,
                        boxmean=True,
                        marker_color=species_colormap[species],
                        showlegend=False,
                    ),
                    row=1,
                    col=2,
                )

    # If a legend group is provided, then group species
    # with the same legend group and display a legend group title
    if legend_group is not None:
        # Check that every species belongs to a legend group
        if set(all_species) != set(legend_group.index):
            raise ValueError(
                "legend_group shall contain all species present in intervals_fom_xr"
            )

        # Based on trace name (species) get the legend group
        return_fig.for_each_trace(
            lambda t: t.update(
                legendgroup=legend_group[t.name],
                legendgrouptitle_text=legend_group[t.name],
            )
        )

    # Get maximum and minimum fom
    yaxis_range = {
        "max_y": intervals_fom_xr.max().fom.item(),
        "min_y": intervals_fom_xr.min().fom.item(),
    }

    # Axis title
    return_fig.update_yaxes(
        title="&mu;<sub>conc</sub> &#8260; 3&#963;<sub>instr</sub> [-]", col=1
    )

    return_fig.update_layout(
        template="plotly_white",
        yaxis_range=[yaxis_range["min_y"], yaxis_range["max_y"]],
        title="<b>Unknown species analysis<br>FOM by Port</b>",
    )

    return return_fig


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_figure_y_limits(target_fig: go.Figure) -> Tuple[float, float]:
    """
    Get y region limits to create vertical alarm lines.

    Args:
        target_fig (go.Figure):
            Plotly figure from which to extract
            the y axis limits.

    Returns:
        Tuple[float, float]:
            y-axis upper and lower limits.
    """
    full_fig = target_fig.full_figure_for_development(warn=False)
    y_bounds = full_fig.layout.yaxis.range
    return y_bounds


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_flags_labels(flags_df: pd.DataFrame) -> pd.Series:
    """
    Return rows of flags_df where at least
    one flag is active. The value for the row
    indicates which flag(s) (1+) is active.

    Args:
         flags_df (pd.DataFrame):
             Dataframe with DateTimeIndex, where each
             column represent a different flag. The
             data type for each column must be
             boolean.

    Returns:
          pd.Series:
              Each row represents a row of
              flags_df where at least one flag is
              active. The value for that row is set
              to a string containing the reference
              to which flag is active (1 or more).

    >>> test_df = pd.DataFrame(
    ...    data={
    ...        "flag_1": [True, False, False],
    ...        "flag_2": [True, True, False]
    ...    },
    ...    index=pd.date_range("2022-09-30 00:00", freq="1m", periods=3)
    ... )
    >>> print(test_df)
                flag_1  flag_2
    2022-09-30    True    True
    2022-10-31   False    True
    2022-11-30   False   False

    >>> print(_get_flags_labels(test_df))
    2022-09-30    flag_1<br>flag_2
    2022-10-31              flag_2
    Freq: ME, dtype: object

    """

    if not isinstance(flags_df.index, pd.DatetimeIndex):
        raise ValueError("DataFrame does not have a DateTimeIndex")

    if not all([is_bool_dtype(flags_df[col]) for col in flags_df.columns]):
        raise ValueError("Not all columns are boolean dtypes")

    flags_df_edit = flags_df.copy()
    flag_cols = flags_df_edit.columns

    # Replace each True value with the name of the corresponding column
    flags_df_edit.loc[:, flag_cols] = flags_df_edit.loc[:, flag_cols].replace(
        True, pd.Series(flags_df_edit.columns, flags_df_edit.columns)
    )

    # Replace each False value with empty string
    flags_df_edit = flags_df_edit.replace(False, "")

    # Group all columns into a single series by
    # concatenating flag values at each row
    labels = flags_df_edit[flag_cols].agg("<br>".join, axis=1)
    labels = labels.str.strip("<br>")

    # Keep only rows where flags are active
    labels = labels[labels.astype(bool)]

    return labels


@validate_call(config=dict(arbitrary_types_allowed=True))
def add_flags(
    starting_fig: go.Figure,
    flag_labels_timeseries: pd.Series,
) -> go.Figure:
    """
    Add health flags to plot.

    Args:
        starting_fig (go.Figure):
            Plotly original FOM figure.

        flag_labels_timeseries (pd.Series):
            Timeseries with text labels
            from :py:func: `.get_flags_labels`

    Return:
        go.Figure:
            Updated Plotly figure.
    """

    fig_ret = go.Figure(starting_fig)

    # Get y-axis limits
    bounds_y = _get_figure_y_limits(starting_fig)

    # Add a marker for each flagged row
    fig_ret.add_trace(
        go.Scattergl(
            x=flag_labels_timeseries.index,
            y=np.repeat(bounds_y[0], len(flag_labels_timeseries)),
            mode="markers",
            marker_color="rgba(222, 49, 99, 0.8)",
            marker_size=13,
            marker_symbol="triangle-up",
            showlegend=False,
            text="always_on",
            customdata=flag_labels_timeseries,
            hovertemplate=f"<b>&#9888; Health flags warning</b><br>"
            f"%{{x}}<br><br>"
            f"%{{customdata}}<br>"
            f"<extra></extra>",
        )
    )

    return fig_ret
