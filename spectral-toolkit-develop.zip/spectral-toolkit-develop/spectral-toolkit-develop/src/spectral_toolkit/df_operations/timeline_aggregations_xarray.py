"""
Provide time-series aggregations for Xarray Datasets.
"""

import numpy as np
import pandas as pd
import xarray as xr
from pydantic import validate_call

from spectral_toolkit.constants.plotting_constants import Averaging
from spectral_toolkit.df_operations.timeline_aggregations import (
    get_intervals_statistics,
)
from spectral_toolkit.df_operations.timeline_process_df import (
    _get_default_resampling_min_count,
)
from spectral_toolkit.logger import get_logger

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True))
def resample_dataset_xr(
    dataset_xr: xr.Dataset,
    data_variable: str = "variable_value",
    averaging_request: Averaging = Averaging.THIRTY_SECONDS,
    min_count: int = -1,
):
    """
    Wrapper for Xarray resample method, using mean and imposing a minimum number of data points
    for averaging to take place (otherwise, use ``NaN``). Arguments used in resample are
    ``label="right", closed="right"``.

    Args:
        dataset_xr (xr.DataSet):
            DataSet with time series coordinate named ``time``.

        data_variable (str):
            Name of the ``dataset_xr`` variable to perform aggregation on.
            Default is "variable_value"

        averaging_request (Averaging):
            Time window width for averaging.

        min_count (int):
            Minimum number of data points needed for the averaging.
            If ``-1``, use default minimum data-points count from
            :py:func:`._get_default_resampling_min_count`.
            If ``0``, no requirement is imposed on the minimum
            number of required data-points.

    Returns:

        xr.DataSet:
            New resampled Xarray DataSet with resampled ``time`` coordinate.
            The DataSet contains variables ``data_variable`` (resampled) and
            ``data_points`` (number of data points used in the averaging process).

    """

    if not {"port", "time", "variable_name"}.issubset(dataset_xr.dims.mapping.keys()):
        raise ValueError(
            "dataset_xr shall contain all {port, time, variable_name} coords"
        )

    if not {f"{data_variable}"}.issubset(dataset_xr.data_vars.variables.mapping.keys()):
        raise ValueError(f"dataset_xr shall contain {data_variable} variable")

    if not np.issubdtype(dataset_xr.time.dtype, np.datetime64):
        raise ValueError("dataset_xr time is not np.datetime64")

    # Get a resampler object
    resampler_obj = dataset_xr.resample(
        time=averaging_request.value, skipna=True, label="right", closed="right"
    )

    # Get mean from resampler
    resampled_xr = resampler_obj.mean()

    # Get data points count from resampler
    count_xr = resampler_obj.count()
    count_xr = count_xr.astype(int)
    count_xr = count_xr.rename_vars({f"{data_variable}": "data_points"})

    auto_mincount = min_count

    if min_count < 0:
        # Automatic min_count based on averaging
        auto_mincount = _get_default_resampling_min_count(
            requested_averaging=averaging_request
        )

    # Mask based on minimum requirement on data points
    mask = count_xr.data_points > auto_mincount

    return_xr = resampled_xr.where(mask, np.NaN)
    return_xr = return_xr.merge(count_xr)

    # Copy original attributes
    return_xr.attrs = dataset_xr.attrs

    # Add the selected averaging as metadata
    return_xr.attrs["requested_avg"] = averaging_request

    return return_xr


@validate_call(config=dict(arbitrary_types_allowed=True))
def intervals_figure_of_merit_xarray(
    start_df: pd.DataFrame,
    instrument_lods: dict,
    lod_ave_time: int = 100,
    lod_sigma: int = 3,
    sigma_scale: int = 3,
    duration_thresholding_percentile: bool = True,
) -> xr.Dataset:
    """
    Get unknown identification figure of merit (FOM)
    Xarray dataset.

    Args:
        start_df (pd.DataFrame):
            DataFrame with a ``DateTimeIndex``, a column named
            ``port``, and one column for every ``species``.

        instrument_lods (dict):
            Dictionary with species name as ``key`` (as it appears
            in ``adjusted_df``) and the limits of detection as
            ``value``. Provided by Picarro in the experiment
            definition json file as "LOD" (specific to
            instrument and species).

        lod_ave_time (int):
            In seconds, averaging level at which the LODs
            are provided. Provided in the
            experiment definition json file as
            ["MetaData"]["ave_time"]. Default is 100s.

        lod_sigma (int):
            Sigma at which LODs are provided. Provided in the
            experiment definition json file as
            ["MetaData"]["sigma"]. Default is 3.

        sigma_scale (int):
            Output scaling for the FOM. Default is 3, same as
            lod_sigma. When set to 3, ``FOM=+-1`` corresponds
            to a 3 sigma deviation from the mean.

        duration_thresholding_percentile (bool):
            If True, exclude intervals with reduced duration,
            based on the 1st percentile of interval
            durations.
            The threshold is determined as:
            `0.9 * quantile(quantile=0.01)`

    Returns:
        xr.Dataset:
            Figure of merit dataset with
            coordinates: _datetime, port, species

    """

    if not isinstance(start_df.index, pd.DatetimeIndex):
        raise ValueError("DataFrame does not have a DateTimeIndex")

    # Get all species
    all_species = [col for col in start_df.columns if col != "port"]

    # Check all species in adjusted_df are mapped in instrument_sigma
    if not all(species in instrument_lods for species in all_species):
        raise ValueError(
            "instrument_sigma shall contain all species present in adjusted_df"
        )

    # Get intervals statistics
    intervals_df = get_intervals_statistics(
        start_df, [col for col in start_df.columns if col != "port"]
    )

    # Remove half-steps by filtering time duration based on percentile
    if duration_thresholding_percentile:
        intervals_df = _quantile_duration_filtering(intervals_df, "port", 0.05, 0.9)

    # Determine limits of detection
    intervals_df = intervals_df.assign(lod=intervals_df.species.map(instrument_lods))

    # Instrument sigma
    intervals_df = intervals_df.assign(
        instrument_sigma=intervals_df.lod * np.sqrt(lod_ave_time) / lod_sigma
    )

    # Figure of merit (FOM)
    intervals_df = intervals_df.assign(
        fom=np.divide(
            intervals_df.concentration_mean,
            intervals_df.instrument_sigma
            * sigma_scale
            / np.sqrt(intervals_df.interval_duration.dt.total_seconds()),
        )
    )

    # Prepare for xarray
    intervals_df = intervals_df[["port", "species", "fom"]].set_index(
        ["port", "species"], append=True
    )

    # xarray with coordinates: _datetime, port, species
    intervals_fom_xr = xr.Dataset.from_dataframe(intervals_df)

    return intervals_fom_xr


@validate_call(config=dict(arbitrary_types_allowed=True))
def _quantile_duration_filtering(
    start_intervals_df: pd.DataFrame,
    group_by: str = "port",
    quantile: float = 0.03,
    fraction: float = 0.9,
) -> pd.DataFrame:
    """
    Remove short intervals from ``start_intervals_df``.

    An interval is removed if its duration
    is lower than a ``fraction`` of the ``q`` percentile
    of all the interval durations.

    The intervals calculation and filtering
    is applied using ``group_by``
    as grouper.

    .. math::
        \text{duration}_{i} < \text{fraction} * \text{quantile}(\text{durations}, q)

    Args:
        start_intervals_df (pd.DataFrame):
            Dataframe with intervals data,
            from :py:func:`.get_intervals_statistics`.

        group_by (str):
            Column name in ``start_intervals_df`` on
            which to perform grouping. For each
            ``group_by``-column values, a different
            minimum time duration will be computed.

        quantile (float):
            Desired duration quantile [0,1].

        fraction (float):
            Coefficient that scales the ``q`` quantile
            duration. If 1, then the ``q`` duration quantile
            is used for filtering. If 0.5, then the threshold
            will be 50% of the ``q`` duration quantile.

    Returns:
        pd.DataFrame:
            Same as ``start_intervals_df``, with low
            duration intervals removed.

    Example:

    Get the 1st percentile duration of intervals
    for each port. Filter out intervals
    whose duration is less than 90% of the
    1st percentile duration:

    .. code:: python
        _quantile_duration_filtering(df, q=0.01, fraction=0.9)


    """

    if any(
            col not in start_intervals_df.columns
            for col in [group_by, "interval_duration"]
    ):
        raise ValueError(
            "start_intervals_df shall contain columns"
            " `interval_duration` and `group_by`"
        )

    if not 0 <= quantile <= 1:
        raise ValueError("Quantile quantile is a number between 0 and 1")

    if not 0 <= fraction <= 1:
        raise ValueError("Fraction is a number between 0 and 1")

    # Group intervals_df by valve key
    grouped_df = start_intervals_df.groupby(group_by)["interval_duration"]

    # Get time duration thresholds
    percentile_thresholds = fraction * grouped_df.agg(lambda x: x.quantile(quantile))

    # Get ports counts in initial intervals_df
    initial_groups_counts = grouped_df.count()

    # For each row, find the corresponding lower bound based on port
    threshold_values = start_intervals_df[group_by].map(percentile_thresholds.to_dict())
    thresholding_indexes = start_intervals_df.interval_duration > threshold_values

    # Get stats of discarded intervals, by port
    mean_duration_excluded = start_intervals_df[~thresholding_indexes].groupby(group_by)

    # Show stats for every grouping key
    for name, group in mean_duration_excluded:
        LOGGER.info(f"intervals_FOM: {name}")

        LOGGER.info(f"Requested duration: > {percentile_thresholds.at[name]}")

        LOGGER.info(
            f"intervals_FOM: "
            f"removed {len(group)} "
            f"out of {initial_groups_counts.at[name]} intervals "
            f"(insufficient duration)"
        )

        LOGGER.info(
            f"intervals_FOM: "
            f"Excluded intervals stats:\n{group.interval_duration.describe()}"
        )

    return start_intervals_df[thresholding_indexes]
