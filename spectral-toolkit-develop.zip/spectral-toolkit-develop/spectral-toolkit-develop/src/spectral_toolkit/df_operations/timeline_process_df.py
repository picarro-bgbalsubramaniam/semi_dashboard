"""Define dataframe operations on concentration time series"""

import warnings
from typing import List, Optional
from warnings import warn

import numpy as np
import pandas as pd
from pydantic import ValidationError, validate_call
from scipy.interpolate import interp1d

from spectral_toolkit.constants.plotting_constants import Averaging
from spectral_toolkit.data_models.allantools import oadev
from spectral_toolkit.df_operations.remove_transitions import (
    get_trimmed_transitions_time_index,
)
from spectral_toolkit.logger import get_logger

LOGGER = get_logger(__name__)


def get_timeline_exclusion_mask(port_timeseries_data: pd.Series) -> pd.Series:
    """
    Given a Pandas series with ``DateTimeIndex``, returns a Pandas series with boolean masking
    values (``True`` = to be masked, ``False`` = values to keep).

    The masking values account for null values in the concentration time series or transition
    between different periods (which are separated by null values).

    Args:

        port_timeseries_data (pandas.Series):
            Series with ``DateTimeIndex`` representing
            an experiment port.

            Null values in each column are needed in order to separate time intervals
            where the port is not being sampled.

    Returns:

        pandas.Series: Boolean Pandas series.

    """

    if not isinstance(port_timeseries_data.index, pd.DatetimeIndex):
        raise ValueError("Series does not have a DateTimeIndex")

    shifted_port_ts = port_timeseries_data.shift(-1)
    transitions = port_timeseries_data.isna() != shifted_port_ts.isna()
    null_values = port_timeseries_data.isna()
    exclude_mask = (transitions) | (null_values)
    return exclude_mask


def get_median_dt(port_timeseries_data: pd.Series) -> float:
    """
    Given a Pandas series with ``DateTimeIndex``, returns the median time difference
    in seconds between consecutive data points, masking out the transitions
    where concentrations are ``NaN``.

    Args:
        port_timeseries_data (pandas.Series): Series with ``DateTimeIndex``
            representing an experiment port.

    Returns:
        float: Median time in seconds between unmasked ``DateTimeIndex`` entries.

    Example:

    Create a time series with block(s) of null values, with ``dt = 1.41`` seconds.

    >>> idx1 = pd.date_range("2022-04-18", periods=10, freq=f"1.41S")
    >>> values = np.full(10, 3.0)
    >>> values[3:7] = np.NaN
    >>> test_s = pd.Series(values, index=idx1)
    >>> test_s
    2022-04-18 00:00:00.000    3.0
    2022-04-18 00:00:01.410    3.0
    2022-04-18 00:00:02.820    3.0
    2022-04-18 00:00:04.230    NaN
    2022-04-18 00:00:05.640    NaN
    2022-04-18 00:00:07.050    NaN
    2022-04-18 00:00:08.460    NaN
    2022-04-18 00:00:09.870    3.0
    2022-04-18 00:00:11.280    3.0
    2022-04-18 00:00:12.690    3.0
    Freq: 1410ms, dtype: float64


    Output median dt in seconds:

    >>> print(f"{get_median_dt(test_s):.2f}")
    1.41

    """

    if not isinstance(port_timeseries_data.index, pd.DatetimeIndex):
        raise ValueError("Series does not have a DateTimeIndex")

    exclusion_mask = get_timeline_exclusion_mask(port_timeseries_data)

    delta_t_df = pd.DataFrame(
        data={
            "original": port_timeseries_data[:-1],
            "delta_t": np.diff(port_timeseries_data.index),
            "exclude_mask": exclusion_mask[:-1],
        }
    )
    delta_t_df = delta_t_df.loc[~delta_t_df.exclude_mask]

    median_dt = np.NaN

    if not delta_t_df.empty:
        seconds_dt = delta_t_df.delta_t.dt.total_seconds()
        median_dt = float(np.median(seconds_dt))

        if (seconds_dt.std() / seconds_dt.mean()) > 0.1:
            warnings.warn(
                "[WARNING] delta_t standard deviation "
                "is larger than 10% of the mean. Your "
                "median_dt result might be unreliable."
            )

    return median_dt


def get_allan_deviation_dataframe(port_timeseries_data: pd.Series) -> pd.DataFrame:
    """
    Given a Pandas series with ``DateTimeIndex``, returns a Pandas dataframe with averaging time
    in seconds and Overlapping Allan deviation for each averaging time.

    Args:
        port_timeseries_data (pd.Series): Series with ``DateTimeIndex`` representing
            an experiment port. Null values in each column are needed in order to
            separate time intervals where the port is not being sampled.
            Time averaging does not occur in regions where null values are present.

    Returns:
        pandas.Dataframe:
            Pandas dataframe with averaging time in seconds
            and Allan deviation for each averaging time.

    |

    Example:

    Input DataFrame (df_pivot)::

                                     port1      port2      port3
        _datetime
        2022-04-18 00:00:00.000  -8.889313        NaN        NaN
        2022-04-18 00:00:01.450 -10.304097        NaN        NaN
        2022-04-18 00:00:02.900  -8.541582        NaN        NaN
        2022-04-18 00:00:04.350  -6.579189        NaN        NaN
        2022-04-18 00:00:05.800 -10.503299        NaN        NaN
        2022-04-18 00:00:07.250 -10.498191        NaN        NaN
        2022-04-18 00:00:08.700  -6.438347        NaN        NaN
        2022-04-18 00:00:10.150  -8.248467        NaN        NaN
        2022-04-18 00:00:11.600 -11.009209        NaN        NaN
        ...
        2022-04-18 00:23:38.100        NaN        NaN  -8.582282
        2022-04-18 00:23:39.550        NaN        NaN  -3.335158
        2022-04-18 00:23:41.000        NaN        NaN  -3.273323
        2022-04-18 00:23:42.450        NaN        NaN  -4.074003
        2022-04-18 00:23:43.900        NaN        NaN  -7.182508
        2022-04-18 00:23:45.350        NaN        NaN  -5.121899
        2022-04-18 00:23:46.800        NaN        NaN  -5.018198
        2022-04-18 00:23:48.250        NaN        NaN  -7.595253
        2022-04-18 00:23:49.700        NaN        NaN  -1.638299

    |
    Output:

    .. code-block:: python

        get_allan_deviation_dataframe(df_pivot.port1)

    ::

            tau  allan_dev  tau_scaled
        0   1.0   2.287755        1.45
        1   2.0   1.696014        2.90
        2   4.0   1.175258        5.80
        3   8.0   0.931092       11.60
        4  16.0   0.936158       23.20
        5  32.0   0.771115       46.40
        6  64.0   0.963587       92.80

    """
    if not isinstance(port_timeseries_data.index, pd.DatetimeIndex):
        raise ValueError("Series does not have a DateTimeIndex")

    # Evaluate deltat strictly before performing the exclusion mask
    median_dt = get_median_dt(port_timeseries_data)

    exclude_values_mask = get_timeline_exclusion_mask(port_timeseries_data)
    data_ts = np.array(port_timeseries_data[~exclude_values_mask])

    taus = [np.NaN]
    allan_devs = [np.NaN]

    if np.isfinite(median_dt) and len(data_ts) > 1:
        try:
            (taus, allan_devs, _, _) = oadev(data_ts)

        except (UserWarning, RuntimeError):
            LOGGER.warning(
                "oadev: Issues with Allan deviation calculations - "
                "not enough consecutive data points "
            )
            taus = [np.NaN]
            allan_devs = [np.NaN]
    else:
        LOGGER.warning(
            "get_allan_deviation_dataframe: "
            "Issues with requesting Allan deviation - "
            "empty series or no consecutive data points"
        )

    df_allan = pd.DataFrame(data={"tau": taus, "allan_dev": allan_devs})
    df_allan = df_allan.assign(tau_scaled=df_allan.tau * median_dt)
    return df_allan


@validate_call()
def lod_to_instrument_sigma(
    instrument_lod: float = np.NaN, lod_ave_time: float = 100.0, sigma_lod: float = 3.0
) -> float:
    """
    Get instrument sigma from
    limit of detection, the averaging
    time and the sigma level
    at which it was calculated.

    Args:

        instrument_lod (float):
            Limits of detection value.
            Provided by Picarro in the experiment
            definition json file as "LOD" (specific to
            instrument and species).

        lod_ave_time (int):
            In seconds, averaging level at which the LODs
            are provided. Provided in the
            experiment definition json file as
            ["MetaData"]["ave_time"]. Default is 100s.

        sigma_lod (float):
            Sigma at which LODs are provided. Provided in the
            experiment definition json file as
            ["MetaData"]["sigma"]. Default is 3.

    Returns:
        float:
            Instrument sigma.
            Returns ``NaN`` if ``instrument_lod``
            is not a finite number.


    >>> lod_to_instrument_sigma(14.1, 100, 3)
    47.0

    >>> lod_to_instrument_sigma(1.8, 600, 3)
    14.696938456699067

    >>> lod_to_instrument_sigma(np.NaN, 600, 3)
    nan

    """

    if np.isfinite(instrument_lod):
        instrument_sigma = instrument_lod * np.sqrt(lod_ave_time) / sigma_lod
    else:
        instrument_sigma = np.NaN

    return instrument_sigma


@validate_call(config=dict(arbitrary_types_allowed=True))
def get_lods(
    timeseries_df: pd.DataFrame,
    reference_port: int,
    averaging_level: int = 100,
    lod_sigma: float = 3.0,
    port_column: str = "ValveMask",
) -> pd.DataFrame:
    """
    Get limits of detection for all species in a dataframe, at
    the specified averaging level and sigma level. The
    calculation is based on Allan Deviation of the data at
    a specific (reference) port.
    The species are present as columns of the dataframe.
    |
    The formula for the LOD calculation is:
    LOD = lod_sigma * ALLAN[0] * sqrt(dt / averaging level)
    |
    Args:
        timeseries_df (pd.Dataframe):
            DataFrame with a DateTimeIndex, where each column
            is a species that will be considered for LOD
            calculation.

        reference_port (int):
            Number id of the reference port, as it appears in the
            column ``port_column`` of the dataframe.

        averaging_level (int):
            Averaging level (in seconds) at which to perform
            LOD estimation.

        lod_sigma (float):
            Sigma level at which to perform LOD estimation.

        port_column (str):
            Name of the column of ``timeseries_df``
            containing port information.

    Returns:
        pd.DataFrame:
            Dataframe with species name as index,
            and LOD info as columns.

    """

    if not isinstance(timeseries_df.index, pd.DatetimeIndex):
        raise ValueError("DataFrame does not have a DateTimeIndex")

    if port_column not in timeseries_df.columns:
        raise ValueError("port_column not present in timeseries_df")

    if not pd.api.types.is_numeric_dtype(timeseries_df[port_column]):
        raise ValueError("port_column must be a numeric dtype")

    if not np.isfinite(lod_sigma):
        raise ValueError("lod_sigma must be a finite number")

    if averaging_level <= 0:
        raise ValueError("averaging_level must be nonnegative")

    if reference_port not in list(timeseries_df[port_column].unique()):
        raise ValueError("reference_port not present in port_column column")

    # Get all cols except the port column
    species_cols = [col for col in timeseries_df.columns if col != port_column]

    # Detect port change
    shifted_port_ts = timeseries_df.shift()[port_column]
    transitions = timeseries_df[port_column] != shifted_port_ts

    # Set the concentrations to NaN at port change
    # This will trigger their removal during
    # Allan deviation processing
    port_df = timeseries_df.copy()
    port_df.loc[transitions, species_cols] = np.NaN
    port_df = port_df[port_df[port_column] == reference_port]

    if len(port_df) < 10:
        raise ValueError("Not enough data points present for reference_port")

    species = []
    lods = []

    for col in species_cols:
        # Skip non-numeric columns
        if not pd.api.types.is_numeric_dtype(port_df[col]):
            warnings.warn(f"Skipped {col}: it is not numeric.")
            continue

        temp_adev_df = get_allan_deviation_dataframe(port_df[col])

        try:
            temp_adev_df = temp_adev_df.iloc[0]

            # Perform LOD = lod_sigma * ALLAN[0] * sqrt(dt / averaging level)
            lod = lod_to_instrument_sigma(
                instrument_lod=temp_adev_df.allan_dev,
                lod_ave_time=temp_adev_df.tau_scaled / averaging_level,
                sigma_lod=1 / lod_sigma,
            )

        except (IndexError, ValidationError):
            warnings.warn(f"Issues in accessing allan deviation for species {col}")
            lod = np.NaN

        species.append(col)
        lods.append(lod)

    df_allan = pd.DataFrame(
        data={"lod_value": lods, "ave_time": averaging_level, "lod_sigma": 3},
        index=species,
    )
    df_allan.index.name = "species"

    return df_allan


def assign_sampling_sections_marker(original_df: pd.DataFrame) -> pd.DataFrame:
    """
    Assign a unique identifier to each sampling period
    (period in which only one port is sampled).

    Args:
        original_df (pd.DataFrame): Original Pandas dataframe with a column named ``port``
            identifying the port being sampled.

    Returns:
        pandas.DataFrame: New Pandas DataFrame with the added column ``sampling_section_marker``


    Example:

    >>> conc = [10, 11, 2, 8, -2, 4, 6, 10]
    >>> port = ["a", "a", "a", 7, 7, 7, 0, 6]
    >>> dti = pd.date_range("2018-01-01", periods=8, freq="10S")
    >>> df_doc = pd.DataFrame(data={"concentration": conc, "port": port}, index=dti)
    >>> df_doc
                         concentration port
    2018-01-01 00:00:00             10    a
    2018-01-01 00:00:10             11    a
    2018-01-01 00:00:20              2    a
    2018-01-01 00:00:30              8    7
    2018-01-01 00:00:40             -2    7
    2018-01-01 00:00:50              4    7
    2018-01-01 00:01:00              6    0
    2018-01-01 00:01:10             10    6


    Output:

    >>> assign_sampling_sections_marker(df_doc)
                         concentration port  sampling_section_marker
    2018-01-01 00:00:00             10    a                        1
    2018-01-01 00:00:10             11    a                        1
    2018-01-01 00:00:20              2    a                        1
    2018-01-01 00:00:30              8    7                        2
    2018-01-01 00:00:40             -2    7                        2
    2018-01-01 00:00:50              4    7                        2
    2018-01-01 00:01:00              6    0                        3
    2018-01-01 00:01:10             10    6                        4

    """

    if not isinstance(original_df, pd.DataFrame):
        raise TypeError(f"{original_df} is not a DataFrame")

    if not isinstance(original_df.index, pd.DatetimeIndex):
        raise ValueError("DataFrame does not have a DateTimeIndex")

    if "port" not in original_df.columns:
        raise ValueError(
            f"{original_df} shall have a column named 'port' to"
            f"properly identify the sampling period"
        )

    result_df = original_df.copy()
    result_df = result_df.assign(
        sampling_section_marker=np.cumsum(original_df.port != original_df.port.shift(1))
    )
    return result_df


def map_sampling_ports_name(
    original_df: pd.DataFrame, port_mapping: dict
) -> pd.DataFrame:
    """Map ``port`` column values to new port identifier.

    Args:
        original_df (pd.DataFrame): Original Pandas dataframe with a column named ``port``
           identifying the port being sampled.

        port_mapping (dict): Port mapping dictionary, where keys are the current port names (or
           numbers), and values are the new port names to be assigned.

    Returns:
        pandas.DataFrame: New Pandas DataFrame with new port names under the ``port`` field.

    |
    |
    Example:

    .. code-block:: python

        conc = [10, 11, 2, 8, -2, 4, 6, 10]
        port = ["a", "a", "a", "a", 7, 7, 7, 7]
        dti = pd.date_range("2018-01-01", periods=8, freq="10S")
        df_doc = pd.DataFrame(data={"concentration": conc, "port": port}, index=dti)
        df_doc.index.name = '_datetime'
        df_doc

    |
    Input (df_doc)::

                             concentration port
        _datetime
        2018-01-01 00:00:00             10    a
        2018-01-01 00:00:10             11    a
        2018-01-01 00:00:20              2    a
        2018-01-01 00:00:30              8    a
        2018-01-01 00:00:40             -2    7
        2018-01-01 00:00:50              4    7
        2018-01-01 00:01:00              6    7
        2018-01-01 00:01:10             10    7

    |
    Mapping:

    .. code-block:: python

        map_dict = {"a": "Reference", 7: "Inlet"}
        map_sampling_ports_name(df_doc, map_dict)

    |
    Output::

                             concentration       port
        _datetime
        2018-01-01 00:00:00             10  Reference
        2018-01-01 00:00:10             11  Reference
        2018-01-01 00:00:20              2  Reference
        2018-01-01 00:00:30              8  Reference
        2018-01-01 00:00:40             -2      Inlet
        2018-01-01 00:00:50              4      Inlet
        2018-01-01 00:01:00              6      Inlet
        2018-01-01 00:01:10             10      Inlet
    """

    if not isinstance(original_df, pd.DataFrame):
        raise TypeError(f"{original_df} is not a DataFrame")

    if not isinstance(port_mapping, dict):
        raise TypeError(f"{port_mapping} is not a dict")

    if "port" not in original_df.columns:
        raise ValueError(f"{original_df} shall have a column named 'port'")

    result_df = original_df.copy()
    result_df.port = result_df.port.map(port_mapping)
    return result_df


def get_reference_spline(
    reference_port_ts_data: pd.Series, window_width: Averaging = Averaging.FOUR_HOURS
):
    """
    Returns a scipy function whose call method uses interpolation to
    find the value of new points.
    The new points values have to be provided in ``total_seconds`` with respect to
    the first data point of the reference series.
    The spline is generated by interpolating a rolling average
    of the reference trace, according to the selected time window width.

    Args:
        reference_port_ts_data (pandas.Series): Series with a ``DateTimeIndex``.

        window_width (Averaging): Rolling time window width for zero-referencing.

    Returns:
        plotly.graph_object.Figure: Plotly figure.

    """
    y_ref = reference_port_ts_data.rolling(window_width.value, center=True).mean()
    x_ref = (y_ref.index - y_ref.index[0]).total_seconds()

    ref_spline = interp1d(x_ref, y_ref, bounds_error=False, fill_value=(y_ref[0], y_ref[-1]))

    return ref_spline


def get_adjusted_dataframe_from_reference_line(
    original_df: pd.DataFrame,
    reference_column_name: str = "Reference",
    target_cols: List[str] = None,
    ref_window_width: Averaging = Averaging.FOUR_HOURS,
    raw_suffix: str = "_raw",
):
    """Adjust all concentration in the data frame by subtracting an offset provided
    by a spline interpolation of the reference line with selected rolling window width.
    Also known as zero-referencing.
    Columns not in ``target_cols`` (and not ``port``) are dropped, to make sure that all
    columns in the returned dataframe have been zero-referenced.
    The raw suffix is removed from the species name to account for the correction.

    Args:
        original_df (pd.DataFrame): Pandas dataframe, with
            columns ``target_cols``, ``port``, and a ``DateTimeIndex``.

        reference_column_name (str): Name of the reference port, as it appears in the column
            ``port`` of the intervals_df dataframe.

        target_cols (list[str]): Name of the target columns to be zero-referenced,
            as they appear in the original_df columns. It defaults to ``["concentration"]``.

        ref_window_width (Averaging): Rolling time window width for zero-referencing.
            Default is 4H.

        raw_suffix (str): Identifier for raw species concentration. Default is "_raw".

    Returns:
        pandas.DataFrame: New Pandas DataFrame zero-referenced on the reference line.

    |
    |
    Example:

    Input dataframe (df_original)::

                                 concentration       port
        _datetime
        2022-04-18 00:00:00.000      -8.889313  Reference
        2022-04-18 00:00:01.450     -10.304097  Reference
        2022-04-18 00:00:02.900      -8.541582  Reference
        ...
        2022-04-18 00:23:45.350      -5.121899     Middle
        2022-04-18 00:23:46.800      -5.018198     Middle
        2022-04-18 00:23:48.250      -7.595253     Middle
        2022-04-18 00:23:49.700      -1.638299     Middle

    |
    Run the function:

    .. code-block:: python

        df_res = get_adjusted_dataframe_from_reference_line(
            df_original,
            "Reference",
            ["concentration"],
            Averaging.FOUR_HOURS
        )


    |
    Look at the original columns 'concentration' and 'port':

    .. code-block:: python

        df_res[['concentration', 'port']]

    ::

                                 concentration       port
        _datetime
        2022-04-18 00:00:00.000      -1.093575  Reference
        2022-04-18 00:00:01.450      -2.508359  Reference
        2022-04-18 00:00:02.900      -0.745844  Reference
        ...
        2022-04-18 00:23:46.800       2.777541     Middle
        2022-04-18 00:23:48.250       0.200486     Middle
        2022-04-18 00:23:49.700       6.157440     Middle

    |
    Other example:

    Input dataframe (df_original)::

                                port  ACETIC_ACID_raw  ACETONE_raw  D6_SILOXANE_raw
        _datetime
        2021-09-27 13:00:00.816  CDA       262.520254   -28.899937         3.373896
        2021-09-27 13:00:03.945  CDA      -105.801745    22.008788         2.857333
        2021-09-27 13:00:06.874  CDA       -79.066432    20.063865        -4.549786
        2021-09-27 13:00:09.961  CDA       -35.619847    27.684586        -3.974159
        2021-09-27 13:00:13.181  CDA       -55.939807    17.768177         3.150024
        ...                      ...              ...          ...              ...
        2021-09-30 11:06:36.756  NaN      -116.955449    73.932377        -7.200639
        2021-09-30 11:06:39.956  NaN      -107.664145    75.617077        -4.904020
        2021-09-30 11:06:43.217  NaN      -105.517669    67.089051        -5.174019
        2021-09-30 11:06:46.433  NaN       -96.771336    63.470754        -4.601042
        2021-09-30 11:06:49.627  NaN      -108.603236    69.788056        -3.467922

    |
    Run the function:

    .. code-block:: python

        df_res = get_adjusted_dataframe_from_reference_line(
            df_original,
            "PAIAC",
            ["ACETIC_ACID_raw", "ACETONE_raw"],
            Averaging.SIX_HOURS
        )


    |
    Result (notice how D6_SILOXANE_raw is dropped)::

                                port      ACETIC_ACID  ACETONE
        _datetime
        2021-09-27 13:00:00.816  CDA       258.441403   -29.248333
        2021-09-27 13:00:03.945  CDA      -109.775510    21.652061
        2021-09-27 13:00:06.874  CDA       -82.941828    19.699339
        2021-09-27 13:00:09.961  CDA       -39.391568    27.311841
        2021-09-27 13:00:13.181  CDA       -59.603387    17.386858
        ...                      ...              ...          ...
        2021-09-30 11:06:36.756  NaN      -105.168197     2.814981
        2021-09-30 11:06:39.956  NaN       -95.905848     4.438851
        2021-09-30 11:06:43.217  NaN       -93.788879    -4.151166
        2021-09-30 11:06:46.433  NaN       -85.071646    -7.830598
        2021-09-30 11:06:49.627  NaN       -96.932447    -1.574012

    |
    """
    warn(
        "Function get_adjusted_dataframe_from_reference_line is deprecated "
        "and will be removed in a future release. Please use get_zero_referenced_df instead.",
        DeprecationWarning,
        stacklevel=2,
    )

    if not isinstance(original_df, pd.DataFrame):
        raise TypeError(f"{original_df} is not a DataFrame")

    if not isinstance(original_df.index, pd.DatetimeIndex):
        raise ValueError("DataFrame does not have a DateTimeIndex")

    target_species = target_cols if target_cols else ["concentration"]
    check_columns = pd.Series(["port"] + target_species)

    if not all(check_columns.isin(original_df.columns)):
        raise ValueError(
            f"{original_df} shall have all of these columns: {check_columns}"
        )

    if reference_column_name not in original_df.port.values:
        raise ValueError(
            f"{original_df} must contain reference column {reference_column_name}"
        )

    result_df = original_df.copy()
    result_df = result_df.drop(
        columns=[
            exclude_col
            for exclude_col in result_df.columns
            if exclude_col not in check_columns.values
        ]
    )

    # Only reference port data is present
    reference_df = result_df.loc[result_df.port == reference_column_name]

    # Get the first time at which reference port was sampled
    reference_time_origin = reference_df.index[0]

    # Get time data (in seconds) with respect to reference time origin
    ref_spline_x_eval = (result_df.index - reference_time_origin).total_seconds()

    # Do the zero-referencing for every target_cols column
    for single_species in target_species:
        # Get the concentration time series for a species measured at reference port
        ref_port_species_ts = reference_df[single_species]

        interpolating_spline = get_reference_spline(
            ref_port_species_ts, ref_window_width
        )

        ref_spline_y_eval = interpolating_spline(ref_spline_x_eval)

        # Subtract the offset from the concentration column
        result_df[single_species] -= ref_spline_y_eval

    # Remove the suffix raw, if present
    result_df.columns = [
        col.replace(raw_suffix, "") if col.endswith(raw_suffix) else col
        for col in result_df.columns
    ]

    return result_df


def filter_port_transitions(
    original_df: pd.DataFrame,
    trim_start: int,
    trim_end: int,
    transition_reference: str = "port",
    keep_initial_data: bool = True,
    keep_final_data: bool = True,
) -> pd.DataFrame:
    """
    Filter out data points recorded right before and right after a transition.
    A transition is defined as a change in the value of ``transition_reference``
    column from one row to the next.

    This function is useful to remove data points that are recorded when
    sampling lines are switched from one port to another.

    |
    Create a DataFrame with a transition in the "port" column

    >>> dt = pd.date_range('2021-09-27 13:00', freq=pd.Timedelta(3.1, "s"), periods=18)
    >>> rng = np.random.default_rng(12345)
    >>> df = pd.DataFrame(
    ...     {
    ...         "port": [-2] * 6 + [0] * 12,
    ...         "concentration": rng.random(18),
    ...     },
    ...     index=dt,
    ... )
    >>> df
                             port  concentration
    2021-09-27 13:00:00.000    -2       0.227336
    2021-09-27 13:00:03.100    -2       0.316758
    2021-09-27 13:00:06.200    -2       0.797365
    2021-09-27 13:00:09.300    -2       0.676255
    2021-09-27 13:00:12.400    -2       0.391110
    2021-09-27 13:00:15.500    -2       0.332814
    2021-09-27 13:00:18.600     0       0.598309
    2021-09-27 13:00:21.700     0       0.186734
    2021-09-27 13:00:24.800     0       0.672756
    2021-09-27 13:00:27.900     0       0.941803
    2021-09-27 13:00:31.000     0       0.248246
    2021-09-27 13:00:34.100     0       0.948881
    2021-09-27 13:00:37.200     0       0.667237
    2021-09-27 13:00:40.300     0       0.095898
    2021-09-27 13:00:43.400     0       0.441840
    2021-09-27 13:00:46.500     0       0.886480
    2021-09-27 13:00:49.600     0       0.697453
    2021-09-27 13:00:52.700     0       0.326473

    |
    The transition occurs between 13:00:15.500 and 13:00:18.600.
    It is expected that rows between 13:00:05.500 and 13:00:48.600 will be excluded from the output.

    >>> filter_port_transitions(df, trim_start=30, trim_end=10, transition_reference="port",
    ...                        keep_initial_data=True, keep_final_data=True)
                             port  concentration
    2021-09-27 13:00:00.000    -2       0.227336
    2021-09-27 13:00:03.100    -2       0.316758
    2021-09-27 13:00:49.600     0       0.697453
    2021-09-27 13:00:52.700     0       0.326473

    Args:
        original_df (pd.DataFrame):
            Pandas dataframe with a ``DateTimeIndex`` and a column
            with the same name indicated by ``transition_reference``.

        trim_start (int):
            Time window (in seconds) in which data points
            are excluded after a port transition.
            Must be non-negative.

        trim_end (int):
            Time window (in seconds) in which data points
            are excluded before a port transition. Must be non-negative.

        transition_reference (str):
            Name of the column to use to detect transitions.
            Defaults to ``port``.

        keep_initial_data (bool):
            If True, do not consider the start of the dataframe
            as a transition.
            If False, the first ``trim_start`` seconds of the
            dataframe are removed.

        keep_final_data (bool):
            If True, do not consider the end of the dataframe
            as a transition.
            If False, the last ``trim_end`` seconds of the
            dataframe are removed.

    Returns:
        pandas.DataFrame: New Pandas DataFrame without port transitions time windows.

    """
    if not isinstance(original_df, pd.DataFrame):
        raise TypeError(f"{original_df} is not a DataFrame")

    if not isinstance(original_df.index, pd.DatetimeIndex):
        raise ValueError("DataFrame does not have a DateTimeIndex")

    if transition_reference not in original_df.columns:
        raise ValueError(
            f"{original_df} shall have a column named {transition_reference} to"
            f"properly identify the sampling period"
        )

    if not isinstance(trim_start, int):
        raise TypeError("trim_start not an int")

    if not isinstance(trim_end, int):
        raise TypeError("trim_end not an int")

    if trim_start < 0:
        raise ValueError("trim_start shall be non negative")

    if trim_end < 0:
        raise ValueError("trim_end shall be non negative")

    df_temp = original_df.copy()
    transition_time_series = original_df[transition_reference]
    time_index_keep = get_trimmed_transitions_time_index(
        transition_flag=transition_time_series,
        trim_start=trim_start,
        trim_end=trim_end,
        keep_initial_data=keep_initial_data,
        keep_final_data=keep_final_data,
    )
    returned_df = df_temp.loc[time_index_keep]
    return returned_df


def _get_default_resampling_min_count(
    requested_averaging=Averaging.HUNDRED_SECONDS,
) -> int:
    """
    Returns the number of minimum elements required to successfully perform the
    Pandas resample mean() operation through the function
    ``get_resampled_timeseries_temp``. The number is somehow arbitrary, and can be
    determined as needed. This function is used for convenience and possibly
    standardization.

        Args:
            requested_averaging (Averaging): Time averaging value.

        Returns:
            int: Minimum number of data points needed for successful resampling.
    """

    if not isinstance(requested_averaging, Averaging):
        raise TypeError(f"{requested_averaging} is not a valid Averaging value")

    min_count_dict = {
        Averaging.ORIGINAL: 0,
        Averaging.TEN_SECONDS: 1,
        Averaging.THIRTY_SECONDS: 3,
        Averaging.ONE_MINUTE: 6,
        Averaging.HUNDRED_SECONDS: 10,
        Averaging.FIVE_MINUTES: 20,
        Averaging.TEN_MINUTES: 20,
        Averaging.THIRTY_MINUTES: 30,
        Averaging.ONE_HOUR: 30,
        Averaging.FOUR_HOURS: 200,
        Averaging.SIX_HOURS: 600,
        Averaging.TWELVE_HOURS: 800,
        Averaging.ONE_DAY: 1500,
        Averaging.ONE_WEEK: 4500,
    }

    min_count = min_count_dict.get(requested_averaging, 0)

    return min_count


def get_resampled_df_timeseries(
    original_df: pd.DataFrame,
    averaging_time: Averaging = Averaging.HUNDRED_SECONDS,
    min_count: int = -1,
) -> pd.DataFrame:
    """
    Wrapper for Pandas resample method, using mean and imposing a minimum number of data points
    for averaging to take place (otherwise, use ``NaN``). Arguments used in resample are
    ``label="right", closed="right"``.

    Args:
        original_df (pd.DataFrame): Original DataFrame with a ``DateTimeIndex`` column.

        averaging_time (Averaging): Time window width for averaging.

        min_count (int):
            Minimum number of data points needed for the averaging.
            If ``-1``, use default minimum data-points count from
            :py:func:`._get_default_resampling_min_count`.
            If ``0``, no requirement is imposed on the minimum
            number of required data-points.

    Returns:

        pd.DataFrame:
            New resampled DataFrame with MultiIndex columns.
            Columns are ``mean``, ``count`` for every column in original_df.
            Columns ``(_timeline, start)``, ``(_timeline, end)``, ``(_timeline, duration)``
            are added to
            characterize the sampling interval.

    |
    Full Example:

    Input (df):

    ::

                                      p1   p2
            _datetime
            2022-04-18 00:00:00.000  2.0  NaN
            2022-04-18 00:00:04.450  1.0  NaN
            2022-04-18 00:00:08.900  5.0  NaN
            2022-04-18 00:00:13.350  4.0  NaN
            2022-04-18 00:00:17.800  NaN  2.0
            2022-04-18 00:00:22.250  NaN  1.0
            2022-04-18 00:00:26.700  NaN  5.0
            2022-04-18 00:00:31.150  NaN  4.0
            2022-04-18 00:00:35.600  9.0  9.0
            2022-04-18 00:00:40.050  1.0  1.0
            2022-04-18 00:00:44.500  6.0  6.0
            2022-04-18 00:00:48.950  4.0  4.0
            2022-04-18 00:00:53.400  NaN  3.0
            2022-04-18 00:00:57.850  4.0  4.0
            2022-04-18 00:01:02.300  2.0  2.0
            2022-04-18 00:01:06.750  7.0  7.0
            2022-04-18 00:01:11.200  5.0  5.0
            2022-04-18 00:01:15.650  1.0  1.0
            2022-04-18 00:01:20.100  NaN  7.0
            2022-04-18 00:01:24.550  NaN  NaN

    |
    Command:

    .. code-block: python

        df_out = get_resampled_timeseries(
            original_df=df,
            averaging_time=Averaging.THIRTY_SECONDS,
            min_count=5
        )

    Expectations:
        - Up to 00:00:00: 1 data point -> all NaNs

        - From 00:00:00 to 00:00:30: 6 data points.

          p1: 3 non-null -> NaN.

          p2: 3 non-null -> NaN.

        - From 00:00:30 to 00:01:00: 7 data points.

          p1: 5 non-null -> mean(9, 1, 6, 4, 4)=4.80

          p2: 7 non-null -> mean(4, 9, 1, 6, 4, 3, 4)=4.43

        - From 00:01:00 to 00:01:30: 6 data points.

          p1: 4 non-null -> NaN

          p2: 5 non-null -> mean(2, 7, 5, 1, 7)=4.40
    |
    Output:

    .. code-block:: python

        df_resam.loc[:, ["p1", "p2"]]

    ::

                              p1              p2
                            mean count      mean count
        _datetime
        2022-04-18 00:00:00  NaN     1       NaN     0
        2022-04-18 00:00:30  NaN     3       NaN     3
        2022-04-18 00:01:00  4.8     5  4.428571     7
        2022-04-18 00:01:30  NaN     4  4.400000     5

    |

    .. code-block:: python

        df_resam.loc[:, "_timeline"]

    ::

                                          start                 end        duration
        _datetime
        2022-04-18 00:00:00 2022-04-17 23:59:30 2022-04-18 00:00:00 0 days 00:00:30
        2022-04-18 00:00:30 2022-04-18 00:00:00 2022-04-18 00:00:30 0 days 00:00:30
        2022-04-18 00:01:00 2022-04-18 00:00:30 2022-04-18 00:01:00 0 days 00:00:30
        2022-04-18 00:01:30 2022-04-18 00:01:00 2022-04-18 00:01:30 0 days 00:00:30

    """

    if not isinstance(original_df, pd.DataFrame):
        raise TypeError(f"{original_df} is not a DataFrame")

    if not isinstance(original_df.index, pd.DatetimeIndex):
        raise ValueError("DataFrame does not have a DateTimeIndex")

    if not isinstance(averaging_time, Averaging):
        raise TypeError(f"{averaging_time} is not a valid Averaging value")

    if not isinstance(min_count, int):
        raise TypeError(f"{min_count} is not an integer value")

    auto_mincount = min_count

    if min_count < 0:
        # Automatic min_count based on averaging
        auto_mincount = _get_default_resampling_min_count(
            requested_averaging=averaging_time
        )

    if averaging_time == Averaging.ORIGINAL:
        # Does not need resampling
        # Simulate structure of resampled data frame, with 'mean' and 'count'
        # as level_values for level 1
        count_df = original_df.groupby(original_df.columns, axis=1).count()
        count_df.columns = pd.MultiIndex.from_product([original_df.columns, ["count"]])
        df_resampled = original_df.copy()
        df_resampled.columns = pd.MultiIndex.from_product(
            [original_df.columns, ["mean"]]
        )
        df_resampled = df_resampled.join(count_df).sort_index(axis=1)

    else:
        # Resample the time series by taking the mean value of the interval
        df_resampled = original_df.resample(
            averaging_time.value, label="right", closed="right"
        ).agg(["mean", "count"])

    # Keep only mean values computed on at least min_count values
    for port_col in df_resampled.columns.levels[0]:
        df_resampled.loc[:, (port_col, "mean")] = np.where(
            df_resampled.loc[:, (port_col, "count")] >= auto_mincount,
            df_resampled.loc[:, (port_col, "mean")],
            np.NaN,
        )

    # Get time series start/end/duration
    df_resampled.loc[:, ("_timeline", "start")] = pd.DatetimeIndex(
        pd.Series(df_resampled.index).shift(1)
    )
    df_resampled.loc[:, ("_timeline", "end")] = df_resampled.index
    df_resampled.loc[:, ("_timeline", "duration")] = (
        df_resampled.loc[:, ("_timeline", "end")]
        - df_resampled.loc[:, ("_timeline", "start")]
    )
    df_resampled.loc[:, ("_timeline", "duration")] = df_resampled.loc[
        :, ("_timeline", "duration")
    ].bfill()

    return df_resampled


@validate_call(config=dict(arbitrary_types_allowed=True))
def get_zero_referenced_df(
    original_df: pd.DataFrame,
    target_cols: Optional[List[str]] = None,
    reference_name: str = "Reference",
    port_column_name: str = "port",
    event_window_width: int = 2,
    min_events: int = 1,
):
    """
    Zero-reference the time series dataframe original_df
    by removing data from the reference port.

    1. An average is computed for every port
    2. A rolling mean is computed for the reference port averages
    3. The rolling mean reference port averages are interpolated
        with a linear spline
    4. The spline is evaluated on the original time series index
    5. The spline values are subtracted from the original time series data

    Args:
        original_df (pd.DataFrame):
            Pandas dataframe with a DateTimeIndex,
            a column named ``port_column_name``, and
            columns ``target_cols`` to be zero-referenced.
        target_cols (List[str], optional):
            List of column names to be zero-referenced.
            All columns must be numeric to be zero-referenced.
            Defaults to None, in which case all numeric columns
            are zero-referenced.
        reference_name (str, optional):
            Name of the reference port.
            Examples: "Reference", "PAIAC".
            Defaults to "Reference".
        port_column_name (str, optional):
            Name of the column in ``original_df``
            containing the port names. Defaults to "port".
        event_window_width (int, optional):
            Width of the rolling window in number of events.
            Example: a value of 2 means that the rolling window
            will contain the current event, the previous 2 events,
            and the next two events.
            Example: a value of 3 means that the rolling window
            will contain the current event, the previous 3 events,
            and the next three events.
            Must be positive.
            Defaults to 2.
        min_events (int, optional):
            Minimum number of events in the rolling window.
            If min_events is 1, the rolling window operation
            will be valid as long as there is at least one
            reference port event.
            Must be positive and less than or equal to
            ``event_window_width``.
            Defaults to 1.

    Returns:
        pd.DataFrame:
            Pandas dataframe with the same index as ``original_df``,
            column ``port_column_name`` containing the port names,
            and columns ``target_cols`` zero-referenced.

    """
    # Checks
    if event_window_width < 1:
        raise ValueError("event_window_width must be positive")

    if min_events < 1:
        raise ValueError("min_events must be positive")

    if min_events > event_window_width:
        raise ValueError("min_events must be less than or equal to event_window_width")

    if not isinstance(original_df.index, pd.DatetimeIndex):
        raise ValueError("DataFrame original_df must have a DateTimeIndex")

    numeric_cols = original_df.select_dtypes(include=[np.number]).columns

    if target_cols is None:
        target_cols = list(numeric_cols)
        LOGGER.debug(f"Remove reference, using columns: {target_cols}")
    else:
        # Check all target_cols are numeric
        if not all(col in numeric_cols for col in target_cols):
            raise ValueError(f"target_cols must be numeric: {target_cols}")

    check_columns = pd.Series([f"{port_column_name}"] + target_cols)

    if not all(check_columns.isin(original_df.columns)):
        raise ValueError(
            f"original_df shall have all of these columns: {check_columns}"
        )

    # define rolling window
    window_width = 2 * event_window_width + 1

    result_df = original_df[target_cols].copy()

    # reference_name is str, convert port_column_name to str as well to compare them
    port_data = original_df[f"{port_column_name}"].astype(str)

    # Get the index of the reference port only
    index_reference_port = port_data[port_data == reference_name].index

    # Create a boolean mask to identify when the port data changes
    mask = port_data.ne(port_data.shift())

    # Port unique identifier
    port_id = mask.cumsum()

    # Keep only port id of the reference port
    port_id = port_id.loc[index_reference_port]

    # aggregations for the group by _port_id operation
    aggregator = {species: ["mean", "std"] for species in target_cols}
    aggregator.update({"_datetime": ["min", "max", "mean", "count"]})

    # Reference port data only
    reference_df = result_df.loc[index_reference_port, :]

    # Group reference port data by port_id and aggregate
    aggregate_df = reference_df.reset_index().groupby(port_id.values).agg(aggregator)

    if len(aggregate_df) < min_events:
        raise ValueError(
            f"Cannot zero-reference: not enough reference events are present in the time series"
            f" (requested {min_events}, found {len(aggregate_df)})"
        )

    # Remove the multi-index and keep only the mean values of the target columns
    rolled_df = aggregate_df[[(species, "mean") for species in target_cols]].droplevel(
        1, axis=1
    )
    rolled_df = rolled_df.rolling(
        window=window_width, center=True, min_periods=min_events
    ).mean()
    rolled_df.index = aggregate_df[("_datetime", "mean")]

    splines_time_start = rolled_df.index[0]
    splines_reference_times = (rolled_df.index - splines_time_start).total_seconds()
    splines = rolled_df.apply(
        lambda species_data: interp1d(
            x=splines_reference_times,
            y=species_data,
            bounds_error=False,
            fill_value="extrapolate",
        ),
        axis=0,
    )

    evaluation_times = (result_df.index - splines_time_start).total_seconds()
    interpolated_reference_df = pd.DataFrame(
        {species: spline(evaluation_times) for species, spline in splines.items()},
        index=result_df.index,
    )

    zero_referenced_df = result_df - interpolated_reference_df
    zero_referenced_df[f"{port_column_name}"] = original_df[f"{port_column_name}"]

    return zero_referenced_df
