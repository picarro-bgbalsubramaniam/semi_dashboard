"""Define dataframe operations to aggregate time series"""

from typing import List

import numpy as np
import pandas as pd
import scipy as sp
from scipy.stats import sem

from spectral_toolkit.df_operations.timeline_process_df import (
    assign_sampling_sections_marker,
)
from spectral_toolkit.logger import get_logger

LOGGER = get_logger(__name__)


def get_intervals_statistics(
    original_unmarked_df: pd.DataFrame,
    target_cols: List[str] = None,
    min_duration: pd.Timedelta = pd.Timedelta(value=0, unit="sec"),
) -> pd.DataFrame:
    """Given a DataFrame with columns named ``port`` and a list  of
    target species present in ``original_unmarked_df`` as columns ``[target_cols]``,
    and a ``DateTimeIndex`` column named ``_datetime``, identifies the sampling periods
    (period in which only one port is sampled)
    and provide statistical aggregates regarding that period for each species.
    Sampling period with only one data point will be dropped.

    The columns in the resulting dataframe are:

    - ``_datetime``: Mean DateTime of the sampling period (index)

    - ``port``: the port that was sampled during that period

    - ``species``: the chemical species being analyzed

    - ``interval_data_points_count``: Number of averaged data points

    - ``interval_start``: DateTime at which the sampling for 'port' started

    - ``interval_end``: DateTime at which the sampling for 'port' ended

    - ``interval_duration``: Duration of the sampling period

    - ``concentration_mean``: Mean value of the concentration during the sampling period

    - ``concentration_std``: Standard deviation (``ddof = 1``) of the concentration

    - ``concentration_sem``: Standard error of the concentration

    - ``lower_bound_ci_concentration``: Lower 95% confidence interval

    - ``upper_bound_ci_concentration``: Upper bound of the 95% confidence interval

    Args:

        original_unmarked_df (pd.DataFrame): Original Pandas dataframe with columns
            named ``port``, ``[target_cols]``, and a DateTimeIndex named ``_datetime``.

        target_cols (list[str]): List of strings, identifying the names of the target
            concentration columns (i.e., the chemical species)
            in ``original_unmarked_df``.

        min_duration (pd.Timedelta):
            Intervals shorter than `min_duration` are discarded.
            Default is 0s (no interval is discarded)

    Returns:

        pandas.DataFrame:
            New Pandas DataFrame aggregated on each sampling period,
            with a ``DateTimeIndex``.


    |
    |

    Example:

    .. code-block:: python

        concentration = [10, 11, 2, 8, -2, 4, 6, 10]
        port = ["a", "a", "a", "a", 7, 7, 7, 7]
        dti = pd.date_range("2018-01-01", periods=8, freq="10S")
        df_doc = pd.DataFrame(data={
                                "species1": concentration,
                                "species2": concentration[::-1],
                                "port": port
                                },
                            index=dti
        )
        df_doc.index.name = '_datetime'

    .. code-block:: python

        df_doc

    ::

                             species1  species2 port
        _datetime
        2018-01-01 00:00:00        10        10    a
        2018-01-01 00:00:10        11         6    a
        2018-01-01 00:00:20         2         4    a
        2018-01-01 00:00:30         8        -2    a
        2018-01-01 00:00:40        -2         8    7
        2018-01-01 00:00:50         4         2    7
        2018-01-01 00:01:00         6        11    7
        2018-01-01 00:01:10        10        10    7

    |
    Call the function, with concentrations of species 1
    and species 2 as target:

    .. code-block:: python

        df_intervals = get_intervals_statistics(
                        original_unmarked_df= df_doc,
                        target_cols = ["species1", "species2"]
                    )


    |
    .. code-block:: python

        df_intervals.info()

    ::

            DatetimeIndex: 4 entries, 2018-01-01 00:00:15 to 2018-01-01 00:00:55
            Data columns (total 11 columns):
             #   Column                        Non-Null Count  Dtype
            ---  ------                        --------------  -----
             0   species                       4 non-null      object
             1   interval_end                  4 non-null      datetime64[ns]
             2   interval_start                4 non-null      datetime64[ns]
             3   upper_bound_ci_concentration  4 non-null      float64
             4   lower_bound_ci_concentration  4 non-null      float64
             5   interval_data_points_count    4 non-null      int64
             6   concentration_mean            4 non-null      float64
             7   concentration_sem             4 non-null      float64
             8   concentration_std             4 non-null      float64
             9   port                          4 non-null      object
             10  interval_duration             4 non-null      timedelta64[ns]
            dtypes: datetime64[ns](2), float64(5), int64(1), object(2), timedelta64[ns](1)

    |

    Looking at the transpose result (for easier visualization):

    .. code-block:: python

        df_intervals.T

    ::

        _datetime                     2018-01-01 00:00:15  2018-01-01 00:00:55
        species                                  species1             species1
        interval_end                  2018-01-01 00:00:30  2018-01-01 00:01:10
        interval_start                2018-01-01 00:00:00  2018-01-01 00:00:40
        upper_bound_ci_concentration            11.700506                  9.4
        lower_bound_ci_concentration             3.799494                 -0.4
        interval_data_points_count                      4                    4
        concentration_mean                           7.75                  4.5
        concentration_sem                        2.015564                  2.5
        concentration_std                        4.031129                  5.0
        port                                            a                    7
        interval_duration                 0 days 00:00:30      0 days 00:00:30


        _datetime                     2018-01-01 00:00:15  2018-01-01 00:00:55
        species                                  species2             species2
        interval_end                  2018-01-01 00:00:30  2018-01-01 00:01:10
        interval_start                2018-01-01 00:00:00  2018-01-01 00:00:40
        upper_bound_ci_concentration                  9.4            11.700506
        lower_bound_ci_concentration                 -0.4             3.799494
        interval_data_points_count                      4                    4
        concentration_mean                            4.5                 7.75
        concentration_sem                             2.5             2.015564
        concentration_std                             5.0             4.031129
        port                                            a                    7
        interval_duration                 0 days 00:00:30      0 days 00:00:30

    """

    if not isinstance(original_unmarked_df, pd.DataFrame):
        raise TypeError(f"{original_unmarked_df} is not a DataFrame")

    if not isinstance(original_unmarked_df.index, pd.DatetimeIndex):
        raise ValueError("DataFrame does not have a DateTimeIndex")

    if any(
        forbidden_col_name in original_unmarked_df.columns
        for forbidden_col_name in ["species", "concentration"]
    ):
        raise ValueError(
            "original_unmarked_df shall not use column names 'values',"
            "'species', or 'concentration'"
        )

    target_species = target_cols if target_cols else ["values"]
    check_columns = pd.Series(["port"] + target_species)

    if not all(check_columns.isin(original_unmarked_df.columns)):
        raise ValueError(
            f"original_unmarked_df shall have all of these columns: {check_columns}"
        )

    # Check all cols except port are numeric
    numeric_cols = len(
        original_unmarked_df[target_species].select_dtypes(include=[np.number]).columns
    )
    all_columns = len(original_unmarked_df[target_species].columns)
    if numeric_cols < all_columns:
        raise ValueError("All columns except port must be numeric")

    def _interval_low(temp_series):
        """Return the lower bound of the 95% confidence interval for the array x."""
        return np.mean(temp_series) - 1.96 * sem(temp_series)

    def _interval_high(temp_series):
        """Return the upper bound of the 95% confidence interval for the array x."""
        return np.mean(temp_series) + 1.96 * sem(temp_series)

    # Drop unselected species
    result_df = original_unmarked_df[check_columns]

    # Mark each sampling port transition
    result_df = assign_sampling_sections_marker(result_df)

    # Drop transitions with only one data point
    unique_markers = result_df.sampling_section_marker.value_counts()
    unique_markers = unique_markers[unique_markers == 1]
    result_df = result_df[~result_df.sampling_section_marker.isin(unique_markers.index)]

    # Melt so that all columns except id_vars (i.e., the chemical species)
    # become attributes for a field named var_name and their value
    # become attributes for a field named concentration
    result_df = result_df.reset_index().melt(
        id_vars=["port", "_datetime", "sampling_section_marker"],
        var_name="species",
        value_name="concentration",
    )

    result_df = result_df.pivot_table(
        index=["species", "sampling_section_marker"],
        values=["concentration", "_datetime", "port"],
        aggfunc={
            "concentration": [
                "mean",
                "std",
                sem,
                _interval_low,
                len,
                _interval_high,
            ],
            "_datetime": ["mean", "max", "min"],
            "port": "min",
        },
    )

    # We do not need the sampling section marker anymore
    result_df = result_df.droplevel("sampling_section_marker")

    # Refactor column names
    result_df.columns = ["_".join(a) for a in result_df.columns.to_flat_index()]

    # Get the interval duration Timedelta
    result_df = result_df.assign(
        interval_duration=result_df["_datetime_max"] - result_df["_datetime_min"]
    )

    n_intervals = len(result_df)

    # Filter intervals with duration < min_duration
    result_df = result_df[result_df.interval_duration >= min_duration]

    # Log warning if excluding intervals
    if len(result_df) < n_intervals:
        LOGGER.info(
            f"Get_interval_statistics: excluding {n_intervals - len(result_df)}"
            f" out of {n_intervals} intervals "
            f"(intervals too short)"
        )

    # Refactor columns names
    result_df = result_df.rename(
        columns={
            "_datetime_mean": "_datetime",
            "port_min": "port",
            "_datetime_min": "interval_start",
            "_datetime_max": "interval_end",
            "concentration_len": "interval_data_points_count",
            "concentration__interval_high": "upper_bound_ci_concentration",
            "concentration__interval_low": "lower_bound_ci_concentration",
        }
    )

    # Move the current index ("species") to columns and bring back "_datetime"
    result_df = result_df.reset_index().set_index("_datetime")

    return result_df


def get_statistics_on_all_intervals(
    df_intervals: pd.DataFrame, instrument_sigma_dict: dict
) -> pd.DataFrame:
    """Given a DataFrame with intervals, from :py:func:`get_intervals_statistics`,
    creates a summary statistics by aggregating all intervals for every
    port.
    As the three sigma measurement and instrument are present in the
    summary, also a dict ``{species: instrument_sigma}`` is required.

    |

    Note: if a ``(species, port)`` pair contains only one single
    sampling interval, the standard deviation is not well
    defined, an it will be shown as ``NaN``.

    |

    The returned dataframe contains a ``MultiIndex`` index:
    ``(species, species_display)``

    |

    For every unique ``species`` value in ``df_intervals``, one MultiIndex
    column is created, with the name of the current species and different
    statistics in the sub-columns. Example, for ``port = "PAIAC"``::

        ('PAIAC',    'concentration_mean')
        ('PAIAC',     'concentration_std')
        ('PAIAC',               'display')
        ('PAIAC',         'duration_mean')
        ('PAIAC', 'inst_three_sigma_mean')
        ('PAIAC',            'points_max')
        ('PAIAC',           'points_mean')
        ('PAIAC',            'points_min')

    where:

    - ``concentration_mean``: Mean of intervals means

    - ``concentration_std``: Standard deviation of the intervals means

    - ``points_min``: Minimum number of data points in a single interval

    - ``points_max``: Maximum number of points in a single interval

    - ``points_mean``: Mean number of points of all intervals

    - ``inst_three_sigma_mean``: Mean instrument three sigma

    - ``duration_mean``: Mean time duration of sampling intervals

    - ``display``: Summary string for HTML table visualization

    Args:

        df_intervals (pd.DataFrame): Pandas dataframe with interval statistics
            from :py:func:`get_intervals_statistics`.

        instrument_sigma_dict (dict): Dict with species name/identifier
            as key, and its instrument sigma as value.

    Returns:

        pandas.DataFrame:
            New Pandas DataFrame summarizing the aggregation
            of each sampling period.

    |
    |

    Example:

    .. code-block:: python

        concentration = [10, 11, 2, 8, -2, 4, 6, 10]
        port = ["a", "a", "a", "a", 7, 7, 7, 7]
        dti = pd.date_range("2018-01-01", periods=8, freq="10S")
        df_doc = pd.DataFrame(data={
                                "species1": concentration,
                                "species2": concentration[::-1],
                                "port": port
                                },
                            index=dti
        )
        df_doc.index.name = '_datetime'

    Get intervals statistics first:

    .. code-block:: python

        df_intervals = get_intervals_statistics(
                        original_unmarked_df= df_doc,
                        target_cols = ["species1", "species2"]
                    )

    Get summary statistics:

    .. code-block:: python

        df_stats = get_statistics_on_all_intervals(
            df_intervals=int_df,
            instrument_sigma_dict={
                 "species1": 10.0,
                 "species2": 4.1
            }
        )

    """

    if not isinstance(df_intervals, pd.DataFrame):
        raise TypeError("df_intervals is not a DataFrame")

    if not isinstance(instrument_sigma_dict, dict):
        raise TypeError(f"{instrument_sigma_dict} is not a dict")

    if not isinstance(df_intervals.index, pd.DatetimeIndex):
        raise ValueError("DataFrame does not have a DateTimeIndex")

    check_columns = pd.Series(
        [
            "species",
            "interval_data_points_count",
            "concentration_mean",
            "port",
            "interval_duration",
        ]
    )

    if not all(check_columns.isin(df_intervals.columns)):
        raise ValueError(
            f"{df_intervals} shall have all of these columns: {check_columns}"
        )

    # Check all species in df_intervals are present in the instrument_sigma_dict
    if not all(
        species in instrument_sigma_dict for species in df_intervals.species.unique()
    ):
        raise ValueError(
            "instrument_sigma_dict shall contain all species present in df_intervals"
        )

    result_df = df_intervals.copy()

    # Duration in seconds
    duration_s = result_df.interval_duration.dt.total_seconds()

    # Get the instrument sigma for every species in result_df
    inst_sigma = result_df.species.map(instrument_sigma_dict)

    # Add 3 sigma to result_df
    result_df = result_df.assign(inst_three_sigma=inst_sigma / np.sqrt(duration_s))

    # Pivot to find statistics for all sampling periods
    result_df = result_df.pivot_table(
        index=["species", "port"],
        values=[
            "concentration_mean",
            "inst_three_sigma",
            "interval_duration",
            "interval_data_points_count",
        ],
        aggfunc={
            "concentration_mean": ["mean", "std"],
            "inst_three_sigma": "mean",
            "interval_duration": "mean",
            "interval_data_points_count": ["mean", "min", "max"],
        },
    )

    result_df = result_df.rename(columns={"concentration_mean": "concentration"})
    result_df.columns = ["_".join(col).strip() for col in result_df.columns.values]
    result_df = result_df.rename(
        columns={
            "interval_data_points_count_min": "points_min",
            "interval_data_points_count_max": "points_max",
            "interval_data_points_count_mean": "points_mean",
            "interval_duration_mean": "duration_mean",
        }
    )
    result_df = result_df.unstack()
    result_df.columns = result_df.columns.swaplevel(0, 1)

    table_cols = result_df.columns.get_level_values(0).unique().tolist()

    for port in table_cols:

        if (port, "concentration_std") not in result_df.columns:
            result_df[(port, "concentration_std")] = np.NaN

        result_df[(port, "display")] = (
            result_df[(port, "concentration_mean")].map("{:.3f}".format)
            + " &plusmn; "
            + result_df[(port, "concentration_std")].map("{:.2f}".format)
            + " ("
            + result_df[(port, "inst_three_sigma_mean")].map("{:.2f}".format)
            + ")"
        )

    result_df = result_df.assign(species_display=result_df.index)
    result_df.species_display = result_df.species_display.replace(
        to_replace={"(_raw)": "", r"(_)": " "}, regex=True
    )
    result_df = result_df.reset_index().set_index(["species", "species_display"])
    result_df.sort_index(axis=1, level=0, inplace=True)

    return result_df
