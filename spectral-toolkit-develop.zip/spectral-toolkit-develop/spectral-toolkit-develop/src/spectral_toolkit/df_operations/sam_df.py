import pandas as pd
import numpy as np
from datetime import datetime as dt
from spectral_toolkit.logger import get_logger
from typing import Union, List


LOGGER = get_logger(__name__)


def reduce_valve_sequence(
    df: pd.DataFrame, valve_mask_str: str = "ValveMask", jump_thresh: int = 100
) -> pd.DataFrame:
    """
    This function is to take private log data with ValveMask key
    and reduce to a simple data frame with the valve number and duration
    spent on that valve.  I'm sure someone with better pandas fu could
    simplify this
    """
    # Make a copy with only the information we need
    temp_df = df[[valve_mask_str]].copy()

    # Determine if analyzer was off, big jump in data point times
    temp_df["jump"] = temp_df.index.to_series().diff().dt.total_seconds() > jump_thresh

    # Remove all duplicate valve mask rows, just keep first row with new valve position
    new_df = (
        temp_df.ne(temp_df.shift())
        .filter(like=valve_mask_str)
        .apply(lambda x: x.index[x])
    )

    # reduce original df to just the index and valve mask position with new columns
    mask_df = temp_df[temp_df.index.isin(new_df[valve_mask_str].tolist())]

    # Get the time intervals for each valve valve position
    time_diff = mask_df.index.to_series().diff().dt.total_seconds()

    # convert from series
    final_df = mask_df.copy()

    # Grab time from next valve not equal to current valve
    final_df["stop_time"] = final_df.index.to_series().shift(-1)

    # add time_delta column, shift up for matching
    # valve duration with correct valve
    final_df["time_delta"] = time_diff.shift(-1)

    # Keep only integer rows, not the transition rows
    mask = final_df[valve_mask_str].apply(lambda x: x.is_integer())
    final_df = final_df[mask]

    # Drop first and last rows as they will have NA values
    final_df = final_df.iloc[:-1, :]

    return final_df


def replace_valve_key_with_median(
    dframe: pd.DataFrame, valve_key: str = "ValveMask"
) -> Union[None, pd.DataFrame]:
    """
    Replace valve_key row with median value of valve state

    Argumements:
        dframe (pd.DataFrame) - DataFrame indexed with timestamp and ValveMask
        valve_key (str) - The key for valve mask in dataframe

    Returns:
        Union[pd.DataFrame, None] - Returns dataframe with median valve position or None
                                    if there is a problem processing points

    >>> import numpy as np
    >>> from spectral_toolkit.df_operations.sam_df import replace_valve_key_with_median
    >>> dframe = pd.DataFrame(data={'ValveMask': np.array([1, 2, 2])})
    >>> replace_valve_key_with_median(dframe)
       ValveMask
    0          2
    1          2
    2          2
    >>> dframe = pd.DataFrame(data={'ValveMask': np.array([1, 2])})
    >>> replace_valve_key_with_median(dframe)
    >>> dframe = pd.DataFrame(data={'ValveMask': np.array([])})
    >>> replace_valve_key_with_median(dframe)
    """
    try:
        valve_states = dframe[valve_key]
        if valve_states.size == 0:
            # empty dataframe
            dframe = None
        elif valve_states.median() not in valve_states.unique():
            # We somehow got a median which is a mean of two states
            dframe = None
        else:
            dframe[valve_key] = np.ones(valve_states.shape, dtype=np.int32) * int(
                valve_states.median()
            )
    except Exception as e:
        LOGGER.warning(f" Unable to determine median value for {valve_key}: {e}")
        dframe = None

    return dframe


def group_by_port(
    df: pd.DataFrame, columns: List[str], start: dt, end: dt, valve_key="ValveMask"
) -> pd.DataFrame:
    """
    Group private log data by valve position
    Args:
        df: dataframe of time series with valve mask
        columns: columns to group
        start: datetime for start time/index
        end: datetime for stop time/index
        valve_key: key for valve mask
    Returns:
        dataframe with new group index
    """
    # apply time slice
    df = df[(df.index >= start) & (df.index < end)]

    # drop G2000 style private logs from combined dataframe
    df = df.dropna(subset=columns, inplace=False)

    # drop empty columns from remaining broadband dataframe
    df = df.dropna(axis=1, inplace=False)

    # find valve transitions
    df["_group"] = (
        (abs(df[valve_key] - df[valve_key].shift()) >= 0.5).cumsum().to_numpy()
    )

    # replace valve_key with integer of median value in each step
    df_grouped = df.groupby("_group", group_keys=False).apply(replace_valve_key_with_median)

    return df_grouped


def group_by_port_combined_logs(combined_df: pd.DataFrame, valve_key="ValveMask"):
    """
    Generate group based on port value and replace float value 
    transitions with median port value
    """
    combined_df["_group"] = (
        (abs(combined_df["ValveMask"] - combined_df["ValveMask"].shift()) >= 0.5)
        .cumsum()
        .to_numpy()
    )
    combined_df = combined_df.groupby("_group", group_keys=False).apply(replace_valve_key_with_median)

    return combined_df
