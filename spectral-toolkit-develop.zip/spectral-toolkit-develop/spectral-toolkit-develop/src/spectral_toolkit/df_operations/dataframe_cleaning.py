"""
Functions to manage
dataframe cleaning and
duplicates management
"""

import numpy as np
import pandas as pd
from pydantic import validate_call

from spectral_toolkit.logger import get_logger

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True))
def dedupe_rows(start_df: pd.DataFrame, time_threshold: float = 0.5) -> pd.DataFrame:
    """
    Merge rows with similar DateTimeIndex values.
    Useful to reduce number of rows
    with duplicate data in private logs.

    Args:
        start_df (pd.DataFFrame):
            Starting data frame, with a DateTimeIndex
            named ``_datetime``.

        time_threshold (float):
            Threshold below which consecutive
            rows time values
            are considered similar (in seconds).
            Must be positive.
            Default is 0.5 seconds.

    Returns:
        pd.DataFrame:
            Data Frame with reduced number of rows
            but unaltered initial information.

    """

    if (not np.isfinite(time_threshold)) | (time_threshold < 0):
        raise ValueError("time_threshold must be finite and positive")

    if not isinstance(start_df.index, pd.DatetimeIndex):
        raise ValueError("DataFrame does not have a DateTimeIndex")

    if start_df.index.name != "_datetime":
        raise ValueError("DataFrame DateTimeIndex must be named _datetime")

    # Time delta between consecutive rows in seconds
    copy_df = start_df.copy()
    copy_df.reset_index(inplace=True)
    copy_df = copy_df.assign(
        deltat=(copy_df["_datetime"] - copy_df.shift(1)["_datetime"]).dt.total_seconds()
    )

    # Left: normal rows
    # Right: rows temporally very close
    # to previous row
    mask_rows = copy_df.deltat < time_threshold
    left_df = copy_df.loc[~mask_rows]
    right_df = copy_df.loc[mask_rows]

    # Drop cols containing all null values
    left_df = left_df.dropna(axis=1, how="all")
    right_df = right_df.dropna(axis=1, how="all")

    # Merge with time tolerance
    merged_df = pd.merge_asof(
        left=left_df,
        right=right_df,
        on="_datetime",
        tolerance=pd.Timedelta(time_threshold, unit="s"),
        direction="nearest",
        suffixes=("_lhs", "_rhs"),
    )

    # Cleanup columns present in both left and right df
    # Take first non-null value between left and right df
    for left_col in merged_df.columns:
        if left_col.endswith("_lhs"):
            merged_df[left_col] = merged_df[left_col].combine_first(
                merged_df[left_col[:-4] + "_rhs"]
            )

    # Remove suffix from left columns
    merged_df = merged_df.rename(
        columns={col: col[:-4] for col in merged_df.columns if col.endswith("_lhs")}
    )

    # Drop deltat column
    merged_df = merged_df.drop(columns=["deltat"])

    # Drop duplicated right columns
    merged_df = merged_df.drop(
        columns=[col for col in merged_df.columns if col.endswith("_rhs")]
    )

    merged_df.set_index("_datetime", inplace=True)

    _verify_dedupe_data_loss(
        start_df.count().to_dict(),
        left_df.drop(columns=["deltat", "_datetime"]).count().to_dict(),
        right_df.drop(columns=["deltat", "_datetime"]).count().to_dict(),
    )

    return merged_df


@validate_call()
def _verify_dedupe_data_loss(
    start_values: dict, left_values: dict, right_values: dict
) -> dict:
    """
    Verify that no data is lost in  :py:func:`dedupe_rows`.

    Args:
        start_values (dict):
            Non-null counts for each column of the starting dataframe.
            Data frame column name is key, and non-null values count
            (for the selected key) is value.

        left_values (dict):
            Non-null counts for each column of the left dataframe
            of :py:func:`dedupe_rows`.
            Data frame column name is key, and non-null values count
            (for the selected key) is value.

        right_values (dict):
            Non-null counts for each column of the right dataframe
            of :py:func:`dedupe_rows`.
            Data frame column name is key, and non-null values count
            (for the selected key) is value.

    Returns:
        dict:
            Difference between original number of non-null
            values and final number of non-null values,
            per column. Expected value is ``0``
            for every key.


    ---

    Examples:
    Say the original dataframe has 3 columns:
    ``sensor, common_sensor, concentration`` with
    ``10, 15, 5`` non-null values respectively.
    If ``sensor`` and ``concentration`` are never
    recorded together, but they are recorded in different
    rows but with very similar timestamps, then ``sensor`` data
    will be assigned to ``left``data frame
    and ``concentration`` will be assigned to ``right`` data frame.
    Some columns are recorded for all timestamp, but the corresponding
    values are duplicated. In that case, they are split between
    ``left`` and ``right`` (such as the case of
    ``common_sensor``).

    Perfect split between ``left`` and ``right``:

    >>> diff = _verify_dedupe_data_loss(
    ...     start_values={'sensor': 10, 'common_sensor': 15, 'concentration': 5},
    ...     left_values={'sensor':10, 'common_sensor': 10},
    ...     right_values={'concentration':5, 'common_sensor': 5})
    >>> sorted(diff.items())
    [('common_sensor', 0), ('concentration', 0), ('sensor', 0)]

    Data loss in ``sensor`` (expected 10 values between
    ``left`` and ``right`` data frames combined):

    >>> diff = _verify_dedupe_data_loss(
    ...     start_values={'sensor': 10, 'common_sensor': 15, 'concentration': 5},
    ...     left_values={'sensor':8, 'common_sensor': 10},
    ...     right_values={'concentration':5, 'common_sensor': 5})
    >>> sorted(diff.items())
    [('common_sensor', 0), ('concentration', 0), ('sensor', 2)]

    Data loss in ``common_sensor`` (expected 15 values between
    ``left`` and ``right`` data frames combined):

    >>> diff = _verify_dedupe_data_loss(
    ...     start_values={'sensor': 10, 'common_sensor': 15, 'concentration': 5},
    ...     left_values={'sensor':10, 'common_sensor': 5},
    ...     right_values={'concentration':5, 'common_sensor': 5})
    >>> sorted(diff.items())
    [('common_sensor', 5), ('concentration', 0), ('sensor', 0)]

    Duplicate data in ``common_sensor`` (expected 15 values between
    ``left`` and ``right`` data frames combined):

    >>> diff = _verify_dedupe_data_loss(
    ...     start_values={'sensor': 10, 'common_sensor': 15, 'concentration': 5},
    ...     left_values={'sensor':10, 'common_sensor': 10},
    ...     right_values={'concentration':5, 'common_sensor': 6})
    >>> sorted(diff.items())
    [('common_sensor', -1), ('concentration', 0), ('sensor', 0)]

    """

    end_values = {
        k: left_values.get(k, 0) + right_values.get(k, 0)
        for k in set(left_values) | set(right_values)
    }

    difference_values = {
        k: start_values.get(k, 0) - end_values.get(k, 0)
        for k in set(start_values) | set(end_values)
    }

    for var, var_value in difference_values.items():
        if var_value != 0:
            LOGGER.warning(
                f"Possible data loss.\n"
                f"Key {var}: "
                f"expected {start_values.get(var, 0)}, "
                f"found {end_values.get(var, 0)}."
            )

    return difference_values
