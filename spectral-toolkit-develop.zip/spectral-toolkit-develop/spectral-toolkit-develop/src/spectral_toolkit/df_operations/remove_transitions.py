"""Module with functions to remove start and end seconds from a Pandas Series/DataFrame."""
from typing import Union

import pandas as pd
from pydantic import validate_call

from spectral_toolkit.logger import get_logger

LOGGER = get_logger(__name__)


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_unique_transition_id(transition_data: pd.Series) -> pd.Series:
    """
    Create a monotonic increasing transition count number
    without gaps.
    This addresses the situation where
    some transition values (i.e., port numbers) are recourring
    but not consecutive.

    >>> a=pd.Series([0,0,0,2,2,5,6])
    >>> b=_get_unique_transition_id(a)
    >>> print(b.values)
    [1 1 1 2 2 3 4]

    >>> a=pd.Series([0,0,1,2,2,1,1])
    >>> b=_get_unique_transition_id(a)
    >>> print(b.values)
    [1 1 2 3 3 4 4]


    Args:
        transition_data (pd.Series):
            Port transition data.

    Returns:
        pd.Series:
            unique id of a transition.

    """
    different = transition_data != transition_data.shift(1)
    unique_transition_id = different.cumsum()
    return unique_transition_id


@validate_call(config=dict(arbitrary_types_allowed=True))
def _drop_transitions(
    data: Union[pd.Series, pd.DataFrame], start: int, end: int
) -> Union[pd.Series, pd.DataFrame]:
    """
    Remove seconds at the start and the end of a Pandas Series/DataFrame.

    >>> dt = pd.date_range('2022-01-01 01:00', '2022-01-01 06:00', periods=6)
    >>> data = pd.Series([1, 2, 3, 4, 5, 6], index=dt)
    >>> _drop_transitions(data, 0, 0)
    2022-01-01 01:00:00    1
    2022-01-01 02:00:00    2
    2022-01-01 03:00:00    3
    2022-01-01 04:00:00    4
    2022-01-01 05:00:00    5
    2022-01-01 06:00:00    6
    dtype: int64

    >>> _drop_transitions(data, 1, 1)
    2022-01-01 02:00:00    2
    2022-01-01 03:00:00    3
    2022-01-01 04:00:00    4
    2022-01-01 05:00:00    5
    dtype: int64

    Boundaries are included.
    >>> _drop_transitions(data, 3600, 3600)
    2022-01-01 02:00:00    2
    2022-01-01 03:00:00    3
    2022-01-01 04:00:00    4
    2022-01-01 05:00:00    5
    dtype: int64

    >>> _drop_transitions(data, 3601, 3601)
    2022-01-01 03:00:00    3
    2022-01-01 04:00:00    4
    dtype: int64

    >>> print(_drop_transitions(data, 10000, 10000))
    Series([], dtype: int64)

    Also works with DataFrames:
    >>> df = pd.DataFrame(
    ... {'a': [1, 2, 3, 4, 5, 6], 'b': [10, 20, 30, 40, 50, 60]},
    ... index=dt)
    >>> _drop_transitions(df, 1, 1)
                         a   b
    2022-01-01 02:00:00  2  20
    2022-01-01 03:00:00  3  30
    2022-01-01 04:00:00  4  40
    2022-01-01 05:00:00  5  50

    >>> test_df = _drop_transitions(df, 10000, 10000)
    >>> print(test_df.empty)
    True

    Args:
        data (pd.Series | pd.DataFrame):
            Timeseries from which to remove
            the start and end sections.
        start (int):
            Seconds to remove at the start of
            a series.
        end (int):
            Seconds to remove at the end of
            a series.

    Returns:
        pd.Series | pd.DataFrame: Trimmed data

    """
    time_index = data.index
    start = time_index[0] + pd.Timedelta(start, "s")
    end = time_index[-1] - pd.Timedelta(end, "s")
    filter_times = (time_index >= start) & (time_index <= end)
    data_filtered = data[filter_times]
    return data_filtered


def get_trimmed_transitions_time_index(
    transition_flag: pd.Series,
    trim_start: int = 30,
    trim_end: int = 10,
    keep_initial_data: bool = True,
    keep_final_data: bool = True,
) -> pd.DatetimeIndex:
    """
    Remove start and end seconds in correspondence
    of a data transition, and returns the cropped datetimeindex.
    A transition consists in a value change in the timeseries
    ``transition_flag`` data from one time to the next.

    >>> dt = pd.date_range('2022-01-01 01:00', '2022-01-01 08:00', periods=8)
    >>> port = pd.Series(['a', 'a', 'a', 'a', 'b', 'b', 'b', 'b'], index=dt)
    >>> new_index = get_trimmed_transitions_time_index(port, 1, 1, keep_initial_data=False, keep_final_data=False)
    >>> new_index # doctest: +NORMALIZE_WHITESPACE
    DatetimeIndex(['2022-01-01 02:00:00', '2022-01-01 03:00:00',
                   '2022-01-01 06:00:00', '2022-01-01 07:00:00'],
                  dtype='datetime64[ns]', freq=None)

    >>> new_index = get_trimmed_transitions_time_index(port, 1, 1, keep_initial_data=True, keep_final_data=True)
    >>> new_index # doctest: +NORMALIZE_WHITESPACE
    DatetimeIndex(['2022-01-01 01:00:00', '2022-01-01 02:00:00', '2022-01-01 03:00:00',
                   '2022-01-01 06:00:00', '2022-01-01 07:00:00', '2022-01-01 08:00:00'],
                  dtype='datetime64[ns]', freq=None)

    >>> new_index = get_trimmed_transitions_time_index(port, 3601, 1, keep_initial_data=False, keep_final_data=False)
    >>> new_index # doctest: +NORMALIZE_WHITESPACE
    DatetimeIndex(['2022-01-01 03:00:00', '2022-01-01 07:00:00'],
                  dtype='datetime64[ns]', freq=None)

    >>> new_index = get_trimmed_transitions_time_index(port, 1, 3601, keep_initial_data=False, keep_final_data=False)
    >>> new_index # doctest: +NORMALIZE_WHITESPACE
    DatetimeIndex(['2022-01-01 02:00:00', '2022-01-01 06:00:00'],
                  dtype='datetime64[ns]', freq=None)

    >>> new_index = get_trimmed_transitions_time_index(port, 0, 1, keep_initial_data=False, keep_final_data=False)
    >>> new_index # doctest: +NORMALIZE_WHITESPACE
    DatetimeIndex(['2022-01-01 01:00:00', '2022-01-01 02:00:00', '2022-01-01 03:00:00',
                   '2022-01-01 05:00:00', '2022-01-01 06:00:00', '2022-01-01 07:00:00'],
                  dtype='datetime64[ns]', freq=None)


    Args:
        transition_flag (pd.Series):
            Data for which transitions are to be identified.
            Often it is the ``port`` column of a dataframe
        trim_start (int):
            Seconds to remove at the start
            of a transition
        trim_end (int):
            Seconds to remove at the end of
            a transition.
        keep_initial_data (bool):
            If True, do not consider the start of the dataframe
            as a transition.
            If False, the first ``trim_start`` seconds of the
            dataframe are removed.
        keep_final_data (bool):
            If True, do not consider the end of the dataframe
            as a transition.
            If False, the last ``trim_end`` seconds of the
            dataframe are removed.

    Returns:
        pd.DatetimeIndex: Trimmed datetimeindex
    """
    if not isinstance(transition_flag.index, pd.DatetimeIndex):
        IndexError("Transition data must have a datetimeindex")

    transition_id = _get_unique_transition_id(transition_data=transition_flag)
    transition_id.name = "data"

    transition_id = transition_id.to_frame()

    # Get first and last transition id to manage start and end of the dataframe
    first_id = transition_id["data"].iloc[0]
    last_id = transition_id["data"].iloc[-1]

    # First transition
    first_df = transition_id[transition_id.data == first_id].apply(
        lambda x: _drop_transitions(
            x, start=0 if keep_initial_data else trim_start, end=trim_end
        )
    )

    # Last transition
    last_df = transition_id[transition_id.data == last_id].apply(
        lambda x: _drop_transitions(
            x, start=trim_start, end=0 if keep_final_data else trim_end
        )
    )

    # Middle transitions
    middle_transitions = transition_id[~transition_id.data.isin([first_id, last_id])]
    middle_df = middle_transitions.groupby("data", group_keys=False).apply(
        lambda x: _drop_transitions(x, start=trim_start, end=trim_end)
    )

    # Concatenate all transitions
    filtered_df = pd.concat([first_df, middle_df, last_df])

    return filtered_df.index
