"""Take spectral fits results and stack them including spectral data"""
from typing import Final, List

import numpy as np
import pandas as pd
import xarray as xr
from pydantic import validate_call
from typing import Optional
from pymongo import database

from spectral_toolkit.model_function.mongodb import model_function
from spectral_toolkit.sam_analysis.compound_identification import _load_mimics

DEFAULT_FIT_INFO_COLUMNS: Final = [
    "rmse",
    "negative_penalty",
    "model_functions_std",
    "wrmse",
    "relative_error",
    "span",
    "relative_contribution",
    "allan_dev",
    "rmse_over_allan",
    "offset",
]


@validate_call(config=dict(arbitrary_types_allowed=True))
def _arrange_new_comps_column(starting_df: pd.DataFrame) -> pd.DataFrame:
    """
    Given a dataframe ``starting_df`` having columns
    with names starting with ``"CID"`` to indicate new compounds,
    fill a column ``new_comps`` with a list of the values of
    CIDs present in the current row.

    >>> test_df = pd.DataFrame(data={
    ...    'CID_0': [280, 281], 'CID_1': [281, np.NaN], 'new_comps': ["280&281", "281&283"]
    ...    })
    >>> _arrange_new_comps_column(test_df)
       CID_0  CID_1   new_comps new_comps_display
    0    280  281.0  [280, 281]        [280, 281]
    1    281    NaN    [281, 0]             [281]

    >>> test_df = pd.DataFrame(data={'CID_0': [280, 281], 'CID_1': [281, np.NaN]})
    >>> _arrange_new_comps_column(test_df)
       CID_0  CID_1   new_comps new_comps_display
    0    280  281.0  [280, 281]        [280, 281]
    1    281    NaN    [281, 0]             [281]

    Args:
        starting_df (pd.Dataframe):
            Pandas Dataframe, with some columns whose name start with ``CID``.
            Those columns identify new compounds added to the fit.
            The column ``new_comps`` might exist or not.

    Returns:
        pd.Dataframe:
            New DataFrame with added (or redefined) columns
            ``new_comps`` (containing list of CIDs, as integer), and
            ``new_comps_display``, which is equivalent to ``new_comps`` except
            with zeros dropped. Zeros in the ``CID``s columns indicate that no
            species was added there.
    """
    return_df = starting_df.copy()

    # Rearrange new compounds column
    return_df = return_df.assign(
        new_comps=return_df[[col for col in return_df.columns if col.startswith("CID")]]
        .fillna(0)
        .astype(int)
        .values.tolist()
    )

    # Remove zeros (no compounds)
    return_df = return_df.assign(
        new_comps_display=[
            [cid for cid in fit_cids if cid > 0] for fit_cids in return_df.new_comps
        ]
    )

    return return_df


@validate_call(config=dict(arbitrary_types_allowed=True))
def _assign_ranking(starting_df: pd.DataFrame, sort_by: str = "wrmse") -> pd.DataFrame:
    """
    Sort rows in ``starting_df`` by ``sort_by`` (ascending) and add
    a column ``ranking`` (starting from 1) according to the sorted rows.

    >>> test_df = pd.DataFrame(data={'sortme': [280, 281]})
    >>> _assign_ranking(starting_df=test_df, sort_by='sortme')
       sortme  ranking
    0     280        1
    1     281        2

    Args:
        starting_df (pd.Dataframe):
            Pandas dataframe containing a column ``sort_by``.

        sort_by (str):
            Column according to which the sorting is executed.

    Returns:
        pd.Dataframe:
            New sorted Dataframe with a column ``ranking`` starting
            from 1.
    """

    if sort_by not in starting_df.columns:
        raise ValueError("'starting_df' should contain the column 'by'")

    df_ret = starting_df.copy()
    df_ret = df_ret.sort_values(by=sort_by, ascending=True).reset_index(drop=True)
    df_ret = df_ret.assign(ranking=range(1, len(df_ret) + 1))
    return df_ret


@validate_call(config=dict(arbitrary_types_allowed=True))
def get_stacked_fit_solutions(
    original_fit_solution_df: pd.DataFrame,
    additional_fit_solutions: List[pd.DataFrame],
    sort_by: str = "wrmse",
) -> pd.DataFrame:
    """
    Stack fit solutions in a single dataframe,
    even if they have different numbers of new CIDs.

    |

    The resulting dataframe has a column ``ranking``,
    related to the overall ranking of the solution
    (based on ``sort_by``) among all others (even
    solutions with different new CIDs).

    |

    The column ``rank_by_cid_count`` ranks a solution
    with respect to other solutions
    with the same new CIDs
    number (based on ``sort_by``).

    |

    The original solution (no added new CIDs) is
    always ranked 0, both in ``ranking`` and
    ``rank_by_cid_count``.

    |

    Args:
        original_fit_solution_df (pd.Dataframe):
            Dataframe with one row only, the original
            fit for the experimental data.

        additional_fit_solutions (List[pd.Dataframe]):
            List of dataframes with additional
            species fits. Typically, one of these
            dataframes contains all the
            possible/tested combinations
            of 1/2/3/4/5+ additional CIDs.

        sort_by (str):
            Reorder the solutions based on
            ``sort_by`` ascending.

    Returns:
        (pd.Dataframe):
            New Dataframe with stacked solutions.

    .. code-block:: python

        original_df = pd.DataFrame(data={
           "rcid_1": [1], "rcid_2": [2], "performance": [4]
           })

        additional_df1 = pd.DataFrame(data={
           "rcid_1": [0.8, 0.9], "rcid_2": [1.6, 0.8], "CID_0": [180, 182],
           "conc_CID0": [4, 6], "performance": [3, 1]
           })

        get_stacked_fit_solutions(
           original_fit_solution_df=original_df,
           additional_fit_solutions=[additional_df1],
           sort_by="performance")


    """

    # Concatenate all new additional fits
    additionals_df = pd.concat(additional_fit_solutions)

    if sort_by not in additionals_df.columns:
        raise ValueError(
            "'additional_fit_solutions' should contain the column 'sort_by'"
        )

    # Rank the new fits
    additionals_df = _assign_ranking(additionals_df, sort_by=sort_by)

    # Give ranking 0 to the original fit to keep it always on top
    initial_temp_df = original_fit_solution_df.copy()
    initial_temp_df = initial_temp_df.assign(ranking=np.zeros(len(initial_temp_df)))

    # Stack original fit and new fits and sort by ranking
    stacked_df = pd.concat([additionals_df, initial_temp_df], ignore_index=True)
    stacked_df.ranking = stacked_df.ranking.astype(int)
    stacked_df = stacked_df.sort_values(by="ranking", ascending=True)
    stacked_df = stacked_df.reset_index(drop=True)

    # Get new compounds list per row
    stacked_df = _arrange_new_comps_column(stacked_df)

    # Get number of new compounds added in each fit
    stacked_df = stacked_df.assign(
        new_comps_count=[len(x) for x in stacked_df.new_comps_display]
    )

    # Add ranking partitioned by number of new compounds
    stacked_df = stacked_df.assign(
        rank_by_cid_count=stacked_df.groupby("new_comps_count")[sort_by]
        .rank(method="first", ascending=True)
        .astype(int)
    )
    stacked_df.loc[stacked_df.new_comps_count == 0, "rank_by_cid_count"] = 0

    return stacked_df


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_new_cids(solutions_fit_df: pd.DataFrame) -> List[str]:
    """
    Gets flat list of all new CIDs that were ever tested,
    from the ``solution_fit_df`` stacked solutions
    from :py:func:`.get_stacked_fit_solutions`.

    >>> test_df = pd.DataFrame(data={"new_comps": [[205, 601], [13, 205]]})
    >>> test_df
        new_comps
    0  [205, 601]
    1   [13, 205]

    >>> _get_new_cids(test_df)
    [13, 205, 601]

    Args:
        solutions_fit_df (pd.Dataframe):
            Stacked fit solutions from :py:func:`.get_stacked_fit_solutions`.
            It shall contain a column named ``new_comps``.

    Returns:
        List[int]: Flat list of new tested CIDs.

    """

    if "new_comps" not in solutions_fit_df.columns:
        raise ValueError("'solutions_fit_df' should contain the column 'new_comps'")

    new_comps_lists = np.unique(solutions_fit_df.new_comps.explode().values).tolist()

    if 0 in new_comps_lists:
        new_comps_lists.remove(0)

    return new_comps_lists


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_initial_species_cids(
    solutions_fit_df: pd.DataFrame, column_identifier: str = "conc"
) -> List[str]:
    """
    Get species that were present in the original fit,
    from the ``solution_fit_df`` stacked solutions
    from :py:func:`.get_stacked_fit_solutions`.
    The original fit CIDs are identified by the
    ``_rcid`` keyword.

    >>> test_df = pd.DataFrame(data={"conc_rcid180": [1], "conc_rcid1645": [10]})
    >>> test_df
       conc_rcid180  conc_rcid1645
    0             1             10

    >>> _get_initial_species_cids(test_df, column_identifier="conc")
    [180, 1645]

    Args:

        solutions_fit_df (pd.Dataframe):
            Stacked fit solutions from :py:func:`.get_stacked_fit_solutions`.
            It shall contain a column named ``new_comps``.

        column_identifier (str):
            Which prefix to look for before the
            ``_rcid`` keyword. Typically
            ``"conc"`` or ``"ampl``.

    Returns:
        List[str]: Flat list of the original fit CIDs.

    """
    id_ppm_column_prefix = f"{column_identifier}_rcid"
    species_initial_cids_list = [
        int(col[len(id_ppm_column_prefix) :])
        for col in solutions_fit_df.columns
        if col.startswith(id_ppm_column_prefix)
    ]
    return species_initial_cids_list


@validate_call(config=dict(arbitrary_types_allowed=True))
def get_all_cids_list(solutions_fit_df: pd.DataFrame, column_identifier: str = "conc"):
    """
    Get all CIDs ever tested in ``solution_fit_df``.
    ``solution_fit_df`` represents the stacked solutions
    from :py:func:`.get_stacked_fit_solutions`.

    >>> test_df = pd.DataFrame(data={
    ...    "conc_rcid180": [1], "conc_rcid1645": [10],
    ...    "new_comps": [[604, 13]]})
    >>> test_df
       conc_rcid180  conc_rcid1645  new_comps
    0             1             10  [604, 13]

    >>> get_all_cids_list(test_df, column_identifier="conc")
    [180, 1645, 13, 604]


    Args:

        solutions_fit_df (pd.Dataframe):
            Stacked fit solutions from :py:func:`.get_stacked_fit_solutions`.
            It shall contain a column named ``new_comps``.

        column_identifier (str):
            Which prefix to look for before the
            ``_rcid`` keyword. Typically
            ``"conc"`` or ``"ampl``.

    Returns:
        List[str]: Flat list of the original fit CIDs and the new tested CIDs.

    """
    starting_species = _get_initial_species_cids(
        solutions_fit_df, column_identifier=column_identifier
    )
    new_species = _get_new_cids(solutions_fit_df)
    return starting_species + new_species


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_new_cids_concentrations_df(
    solutions_fit_df: pd.DataFrame, column_identifier: str = "conc"
) -> pd.DataFrame:
    """
    For the newly added species in a fit,
    get a dataframe with the different fits that were tested as rows,
    all the new species tested as columns,
    and their concentrations as values.
    The returned dataframe can be stacked with another
    one (from
    :py:func:`._get_starting_cids_concentrations_df`)
    containing the species and concentrations
    of the basic species (species that were present during
    the initial fit).

    >>> idx = pd.Series(data=range(2), name="ranking")
    >>> data = {"CID_0": [180, 183], "conc_CID0": [0.9, 0.1],
    ...    "CID_1": [15, 180], "conc_CID1": [0.3, 0.7]}
    >>> test_df = pd.DataFrame(data=data, index=idx)
    >>> test_df.reset_index(inplace=True)
    >>> test_df
       ranking  CID_0  conc_CID0  CID_1  conc_CID1
    0        0    180        0.9     15        0.3
    1        1    183        0.1    180        0.7

    >>> res = _get_new_cids_concentrations_df(solutions_fit_df=test_df, column_identifier="conc")
    >>> res.reset_index(drop=True)
    CID_  15   180  183
    0     0.3  0.9  NaN
    1     NaN  0.7  0.1

    Args:
        solutions_fit_df (pd.Dataframe):
            Stacked fit solutions from :py:func:`.get_stacked_fit_solutions`.
            It contains column pairs ``{CID_n, conc_CIDn}``, and an
            index named ``ranking``.

        column_identifier (str):
            Which prefix to look for to extract the
            new species values. Typically
            ``"conc"`` or ``"ampl``.

    Returns:
        pd.DataFrame:
            Dataframe with species CIDs as columns, their concentrations
            as values, and different fits tested as rows.

    """

    # Columns with new species
    new_species_cols = [
        col for col in solutions_fit_df.columns if col.startswith("CID_")
    ]

    # Columns with new species concentrations
    new_species_conc = [
        f"{column_identifier}_{col.replace('_','')}" for col in new_species_cols
    ]

    # Keep only the columns related to new species
    process_df = solutions_fit_df[new_species_cols + new_species_conc].reset_index()

    # Reshape the dataframe so that
    # each new species has its own column
    # with its concentration (for every fit) as data
    long_df = pd.wide_to_long(
        process_df, ["CID_", f"{column_identifier}_CID"], i="index", j="number"
    )
    long_df = long_df.reset_index().drop(columns=["number"])

    long_df.CID_ = long_df.CID_.fillna(0).astype(int)

    stackable_df = long_df.pivot_table(
        index="index",
        columns="CID_",
        values=f"{column_identifier}_CID",
        aggfunc="first",
        dropna=False,
    )

    # Drop the zero-ranked column
    if 0 in stackable_df.columns:
        stackable_df = stackable_df.drop(columns=[0])

    return stackable_df


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_starting_cids_concentrations_df(
    solutions_fit_df: pd.DataFrame, column_identifier: str = "conc"
) -> pd.DataFrame:
    """
    For the original species in a fit,
    get a dataframe with the different fits
    that were tested as rows,
    all the original species tested as columns,
    and their concentrations as values.
    The returned dataframe can be stacked with another
    one containing the species and concentrations
    of the new species (from
    :py:func:`._get_new_cids_concentrations_df`).

    >>> idx = pd.Series(data=range(2), name="ranking")
    >>> data = {"conc_rcid180": [0.9, 0.1], "conc_rcid90": [0.3, 0.7]}
    >>> test_df = pd.DataFrame(data=data, index=idx)
    >>> test_df.reset_index(drop=True)
       conc_rcid180  conc_rcid90
    0           0.9          0.3
    1           0.1          0.7

    >>> res = _get_starting_cids_concentrations_df(test_df, column_identifier="conc")
    >>> res.reset_index(drop=True)
       180   90
    0  0.9  0.3
    1  0.1  0.7

    Args:
        solutions_fit_df (pd.Dataframe):
            Stacked fit solutions from :py:func:`.get_stacked_fit_solutions`.
            It contains columns ``conc_rcid<CID>``, and an
            index named ``ranking``.

        column_identifier (str):
            Which prefix to look for to extract the
            new species values. Typically
            ``"conc"`` or ``"ampl``.

    Returns:
        pd.DataFrame:
            Dataframe with species CIDs as columns, their concentrations
            as values, and different fits tested as rows.


    """
    # Concentration data for starting species (and offset)
    mask = [
        col
        for col in solutions_fit_df.columns
        if (col.startswith(f"{column_identifier}_rcid")) | (col == "offset")
    ]
    base_df = solutions_fit_df[mask]
    base_df.columns = base_df.columns.str.replace(f"{column_identifier}_rcid", "")
    return base_df


@validate_call(config=dict(arbitrary_types_allowed=True))
def get_stacked_cids_concentrations_df(
    stacked_fit_solutions_df: pd.DataFrame, column_identifier: str = "conc"
) -> pd.DataFrame:
    """
    Stack original fit species concentrations
    and new species concentrations in a single dataframe,
    even if the fit solutions have different CIDs.

    >>> idx = pd.Series(data=range(2), name="ranking")
    >>> data = {"conc_rcid180": [0.9, 0.1], "conc_rcid90": [0.3, 0.7],
    ...    "CID_0": [185, 31], "conc_CID0": [0.7, 3.1],
    ...    "CID_1": [185, 31], "conc_CID1": [0.9, -0.2]}
    >>> test_df = pd.DataFrame(data=data, index=idx)
    >>> test_df.reset_index(inplace=True)
    >>> test_df
       ranking  conc_rcid180  conc_rcid90  CID_0  conc_CID0  CID_1  conc_CID1
    0        0           0.9          0.3    185        0.7    185        0.9
    1        1           0.1          0.7     31        3.1     31       -0.2

    >>> res = get_stacked_cids_concentrations_df(stacked_fit_solutions_df=test_df,
    ...    column_identifier="conc")
    >>> res.reset_index(drop=True)
       180   90   31  185
    0  0.9  0.3  NaN  0.7
    1  0.1  0.7  3.1  NaN

    """
    new_comp_df = _get_new_cids_concentrations_df(
        solutions_fit_df=stacked_fit_solutions_df,
        column_identifier=column_identifier,
    )
    base_df = _get_starting_cids_concentrations_df(
        solutions_fit_df=stacked_fit_solutions_df,
        column_identifier=column_identifier,
    )

    # Concentration data for all species (with offset)
    complete_df = base_df.join(new_comp_df, how="outer")
    complete_df.columns = complete_df.columns.astype(str)

    return complete_df


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_cids_spectra(
    db_client: database.Database,
    compounds_list: List[int],
    wavenumber_nu: np.ndarray,
    nu_min: int = 5800,
    nu_max: int = 6300,
    nominal_pressure: float = 140.0,
    add_static_offset_compound: bool = True,
) -> np.ndarray:
    """
    Get a numpy matrix where rows
    are wavenumbers ``wavenumber_nu``,
    columns are compounds in ``compounds_list``,
    and values are the loss for
    a specific compound at a specific
    wavenumber.

    Args:
        db_client (database.Database):
            MongoDB client connection. See :py:func:`.get_mongo_spectral_library_client`.

        compounds_list (List[int]):
            List of CIDs for which the loss is queried.

        wavenumber_nu (np.ndarray):
            Wavenumbers at which the model function for each CID
            is evaluated.

        nu_min (int):
            Lower bound of wavenumber interval for
            :py:func:`.model_function`.

        nu_max (int):
            Upper bound of wavenumber interval for
            :py:func:`.model_function`.

        nominal_pressure (float):
            Nominal pressure for
            :py:func:`.model_function`.

        add_static_offset_compound (bool):
            If True, an array of ones is added as model
            function for the offset.

    Returns:
        np.ndarray:
            Matrix [``len(wavelength_nu`` x ``len(compounds_list)``] if
            ``add_static_offset_compound = False``, else
            [``len(wavelength_nu`` x ``len(compounds_list)+1``]
    """
    mimics = _load_mimics()
    wavefunctions = []
    for cid in compounds_list:
        if cid in mimics.keys():
            wavefunctions.append(mimics[cid](wavenumber_nu))
        else:
            wavefunctions.append(
                model_function(
                    db_client,
                    cid=int(cid),
                    nu_min=nu_min,
                    nu_max=nu_max,
                    nominal_pressure=nominal_pressure,
                    use_exact_pressure=False
                )(wavenumber_nu)
            )

    wavefunctions = np.array(wavefunctions)

    if add_static_offset_compound:
        wavefunctions = np.vstack((wavefunctions, np.ones(len(wavenumber_nu))))

    wavefunctions = wavefunctions.T
    return wavefunctions


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_wavefunction_per_fit(
    cids_spectra: np.ndarray, ranked_solutions_count: int
) -> np.ndarray:
    """
    Extend the 2D matrix (wavenumbers x CIDs)
    from :py:func:`._get_cids_spectra` to 3D
    (wavenumbers x CIDs x ranked_solutions_count).
    This is used so that we can store in a Xarray
    the loss for each CID for each ranked solution.

    >>> inp = np.random.RandomState(42).rand(3, 2)
    >>> inp.shape
    (3, 2)

    >>> _get_wavefunction_per_fit(inp, 5).shape
    (3, 2, 5)

    Args:
        cids_spectra (np.ndarray):
            2D Matrix (wavenumbers x CIDs) from
            :py:func:`._get_cids_spectra`.

        ranked_solutions_count:
            Number of elements for the third dimension,
            equal to the number of solutions that we
            want to plot.

    Returns:
        np.ndarray:
            3D block (wavenumbers x CIDs x ranked_solutions_count).
            The 2D blocks (wavenumbers x CIDs) are simply broadcasted
            ``ranked_solutions_count``-times on the 3rd axis.

    """
    wavefunctions_3d = np.broadcast_to(
        cids_spectra[..., None], cids_spectra.shape + (ranked_solutions_count,)
    )
    return wavefunctions_3d


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_fits_summary_table_xray(
    solutions_fit_df: pd.DataFrame,
    info_columns: Optional[List[str]] = None,
):
    """
    Returns a dataframe with the fit statistics.

    Args:
        solutions_fit_df (pd.Dataframe):
            Stacked fit solutions from :py:func:`.get_stacked_fit_solutions`.

        info_columns (List[str]):
            List of column names containing statistics.
            All ``info_columns`` shall be present
            in ``solutions_fit_df``.

    Returns:
        xr.DataArray: Fit statistics dataframe.

    """

    if info_columns is None:
        info_columns = DEFAULT_FIT_INFO_COLUMNS

    if not all(info in solutions_fit_df.columns for info in info_columns):
        raise ValueError(
            "solutions_fit_df shall contain all info present in info_columns"
        )

    table_df = solutions_fit_df[info_columns]
    table_df.index.name = "solution"
    table_df.columns.name = "fit_parameters"
    return xr.DataArray(table_df)


@validate_call(config=dict(arbitrary_types_allowed=True))
def _get_fits_new_cids_xray(solutions_fit_df: pd.DataFrame):
    """
    Get a DataArray containing the lists of the new
    compounds for every ranked fit solution
    (``solutions_fit_df.index``).

    Args:
        solutions_fit_df (pd.Dataframe):
            Stacked fit solutions from :py:func:`.get_stacked_fit_solutions`.

    Returns:
        xr.DataArray:
            DataArray with lists of new compounds for
            every ranked fit solution.
    """
    if "new_comps" not in solutions_fit_df.columns:
        raise ValueError("'solutions_fit_df' should contain the column 'new_comps'")

    return xr.DataArray(
        solutions_fit_df.new_comps, coords=[solutions_fit_df.index], dims=["solution"]
    )


@validate_call(config=dict(arbitrary_types_allowed=True))
def define_solutions_spectral_dataset(
    db_client: database.Database,
    solutions_fit_df: pd.DataFrame,
    experimental_datapoints: pd.Series,
    evaluation_nu: np.ndarray,
    top_n: int = 5,
    nominal_pressure: float = 140,
) -> xr.Dataset:
    """
    Create a xarray Dataset with the ``top_n`` fit solutions for
    each distinct ``new_cids_count``.

    |

    The dataset has coordinates:

    - ``solution``: Index of the solution. The original fit has solution zero.
    - ``fit_parameters``: Quality parameters of the fit (rmse, wrmse, ...)
    - ``wavenumber``: High resolution plotting wavenumbers used with model function.
    - ``CID``: Species CIDs.
    - ``experimental_wavenumber``: Wavenumbers from experimental data.
    - ``new_cids_count`` (``solution``): Count of New CIDs in every ranked fit solution.
    - ``ranking_by_cid_count`` (``solution``): Position in ranking
         (among solutions with same ``new_cids_count``).

    |

    Variables:

    - ``concentrations_cids`` (``solution, cid``): Concentrations in ppb.
    - ``loss_cids`` (``wavenumber, cid``): Species loss model function evaluated on ``wavenumber``.
    - ``loss_scaled_cids`` (``wavenumber, cid, solution``): Loss model function times concentration.
    - ``summary_table`` (``solution, fit_parameters``): Statistics summary per fit.
    - ``new_cids`` (``solution``): New CIDs in every ranked fit solution.
    - ``new_cids_display`` (``solution``): New CIDs in every ranked fit solution (zeros omitted).
    - ``experimental_loss`` (``experimental_wavenumber``): Experimental loss that was fitted for.
    - ``experimental_loss_cids`` (``experimental_wavenumber, cid``):
        Species loss model function evaluated on ``experimental_wavenumber``.
    - ``experimental_loss_scaled_cids`` (``experimental_wavenumber, cid, solution``):
        Loss model function evaluated on ``experimental_wavenumber`` times concentration .
    - ``residuals`` (``experimental_wavenumber, solution``):
        Residuals given by ``experimental_loss`` minus
        cumulative ``experimental_loss_scaled_cids`` (on ``experimental_wavenumber``).

    Args:
        db_client (database.Database):
            MongoDB client connection. See :py:func:`.get_mongo_spectral_library_client`.

        solutions_fit_df (pd.Dataframe):
            Stacked fit solutions from :py:func:`.get_stacked_fit_solutions`.

        experimental_datapoints (pd.Series):
            Series with ``wavenumber`` as index, and ``loss`` as data, for the measured data.

        evaluation_nu (np.ndarray):
           Wavenumber array used to evaluate the model functions for plotting.

        top_n (int):
            Number of top-ranked fit solution to keep for each unique ``new_cids_count``.

    Returns:
        xr.DataSet: Xarray Dataset.

    """

    # Keep only top N solutions
    solutions_df = solutions_fit_df.groupby(["new_comps_count"]).head(top_n)

    # Redefine global ranking
    solutions_df = solutions_df.assign(
        ranking=solutions_df["wrmse"].rank(method="first", ascending=True)
    )
    solutions_df.loc[solutions_df.new_comps_count == 0, "ranking"] = 0

    # Get cids list
    cids = get_all_cids_list(solutions_df)

    # Get spectrum for every cid
    cids_spectra = _get_cids_spectra(
        db_client=db_client,
        compounds_list=cids,
        wavenumber_nu=evaluation_nu,
        add_static_offset_compound=True,
        nominal_pressure=nominal_pressure,
    )

    # Extend spectra (wavenumber x cid) to 3D (wavenumber x cid x ranked_solution)
    spectra_3d = _get_wavefunction_per_fit(cids_spectra, len(solutions_df))

    # All cids and offset
    compounds = [f"{cid}" for cid in cids] + ["offset"]

    # Get concentrations for all cids and all ranked solutions
    concentrations_df = get_stacked_cids_concentrations_df(solutions_df)

    # Fit quality parameters
    summary_xray = _get_fits_summary_table_xray(solutions_df)

    # New compounds in every fit
    new_cids = _get_fits_new_cids_xray(solutions_df)

    # Residuals are calculated on the experimental wavenumbers
    cids_spectra_markers = _get_cids_spectra(
        db_client=db_client,
        compounds_list=cids,
        wavenumber_nu=experimental_datapoints.index.to_numpy(),
        nominal_pressure=nominal_pressure
    )

    solutions_fit_xrds = xr.Dataset(
        {
            "loss_scaled_cids": (["wavenumber", "cid", "solution"], spectra_3d),
            "loss_cids": (["wavenumber", "cid"], cids_spectra),
            "concentrations_cids": (["solution", "cid"], concentrations_df[compounds]),
            "summary_table": summary_xray,
            "new_cids": new_cids,
            "new_cids_display": (["solution"], solutions_df.new_comps_display),
            "experimental_loss_cids": (
                ["experimental_wavenumber", "cid"],
                cids_spectra_markers,
            ),
            "experimental_loss": (["experimental_wavenumber"], experimental_datapoints),
        },
        coords={
            "wavenumber": evaluation_nu,
            "cid": compounds,
            "solution": solutions_df.index.values,
            "new_cids_count": (["solution"], solutions_df.new_comps_count),
            "ranking_by_cid_count": (["solution"], solutions_df.rank_by_cid_count),
            "experimental_wavenumber": experimental_datapoints.index.to_numpy(),
        },
    )

    # Get scaled loss based on concentration of every cid in every ranked solution
    solutions_fit_xrds["loss_scaled_cids"] = (
        solutions_fit_xrds["loss_scaled_cids"]
        * solutions_fit_xrds["concentrations_cids"]
    )
    solutions_fit_xrds["experimental_loss_scaled_cids"] = (
        solutions_fit_xrds["experimental_loss_cids"]
        * solutions_fit_xrds["concentrations_cids"]
    )

    solutions_fit_xrds["residuals"] = solutions_fit_xrds[
        "experimental_loss"
    ] - solutions_fit_xrds["experimental_loss_scaled_cids"].sum(dim="cid")

    solutions_fit_xrds.attrs["top_n"] = top_n

    return solutions_fit_xrds
