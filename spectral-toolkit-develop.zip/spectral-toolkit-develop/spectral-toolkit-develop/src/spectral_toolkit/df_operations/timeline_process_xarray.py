"""
Read and process time-series data with Xarray.
"""
from typing import List

import pandas as pd
import xarray as xr
from pydantic import validate_call


@validate_call(config=dict(arbitrary_types_allowed=True))
def timeseries_df_to_xarray(
    timeseries_df: pd.DataFrame,
    port_col: str,
    sensor_cols: List[str],
    species_cols: List[str],
) -> xr.Dataset:
    """
    Get an Xarray Dataset with coordinates
    ``(time, port, variable_name)`` from
    a Pandas DataFrame.

    Args:
        timeseries_df (pd.DataFrame):
            Pandas DataFrame with a ``DateTimeIndex``
            named ``_datetime``.

        port_col (str):
            Port name as present as column name
            in ``timeseries_df``.

        sensor_cols (List[str]):
            List of column names in ``timeseries_df``
            corresponding to sensor data.

        species_cols (List[str]):
            List of column names in ``timeseries_df``
            corresponding to species
            concentration data.

    Returns:
        xr.Dataset:
            Xarray Dataset with coordinates
            ``(time, port, variable_name)``
            and attributes ``sensor_vars``
            (corresponding to ``sensor_cols``)
            and ``species_vars`` (corresponding
            to ``species_cols``).
            ``variable_name`` is a coordinate
            indexing ``sensor_cols`` and
            ``species_cols`` together.
    """

    if not set(sensor_cols).issubset(timeseries_df.columns):
        raise ValueError("df shall contain all sensor_cols")

    if not set(species_cols).issubset(timeseries_df.columns):
        raise ValueError("df shall contain all concentration_cols")

    if port_col not in timeseries_df.columns:
        raise ValueError("df shall contain port_col")

    if not isinstance(timeseries_df.index, pd.DatetimeIndex):
        raise ValueError("df does not have a DateTimeIndex")

    if timeseries_df.index.name != "_datetime":
        raise ValueError("df DateTimeIndex must be named `_datetime`")

    # Get columns that we want to keep
    filter_cols = [port_col] + sensor_cols + species_cols

    # Drop other columns
    copy_df = timeseries_df.copy()
    copy_df = copy_df[filter_cols]
    copy_df.columns.name = "variable_name"

    melted_df = copy_df.reset_index().melt(
        id_vars=[f"{port_col}", "_datetime"],
        var_name="variable_name",
        value_name="variable_value",
    )
    melted_df = melted_df.rename(columns={"_datetime": "time", f"{port_col}": "port"})
    melted_df.set_index(["time", "port", "variable_name"], inplace=True)

    dataset_xr = melted_df.to_xarray()
    dataset_xr.attrs["sensor_vars"] = sensor_cols
    dataset_xr.attrs["species_vars"] = species_cols

    return dataset_xr
