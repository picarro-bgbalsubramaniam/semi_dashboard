from os import getenv
from setuptools import setup, find_packages
from subprocess import check_output

with open("README.md", "r") as f:
    readme = f.read()

def get_version():
    # Check for these environment variables, set by the build system
    major = getenv('majorVersion')
    minor = getenv('minorVersion')
    patch = getenv('patchVersion')
    git_hash = ''
    if not all((major, minor, patch)):
        # No env variables set, so we got here by git checkout
        git_hash = '+' + check_output(['git',
                                       'rev-parse',
                                       '--verify',
                                       'HEAD',
                                       '--short'],
                                       encoding='utf-8')[:-1]
        major = minor = patch = '0'
    return ".".join((major, minor, patch)) + git_hash

version = get_version()

# Create a version number that is accessible from python runtime
with open('src/version.py', 'w') as f:
    f.write(f'__version__ = "{version}"\n')

setup(
    name='spectral-toolkit',
    version=version,
    license="Copyright Picarro internal use only",
    author="Cheyenne Nelson",
    author_email="cnelson@picarro.com",
    project_urls={
        "Code": "https://github.com/picarro/spectral-toolkit",
    },
    description="repository for commonly shared analysis and custom scripts",
    long_description=readme,
    long_description_content_type="text/markdown",
    maintainer="Picarro",
    packages=find_packages("src"),
    package_dir={"": "src"},
    install_requires=[
        "data-pooler>0.0.1",
        "numpy>=1.24.4",
        "pandas>=1.5.3",
        "plotly>=5.13.0",
        "python-dateutil>=2.8",
        "python-dotenv>=1.0.0",
        "pytz>=2021",
        "scipy>=1.9.3",
        "spectral-arithmetic>=0.4.20",
        "sortedcontainers>=2.4",
        "xarray>=2023",
        "voc-fitter>=5.8",
        "scikit-learn>=1.3.0",
    ],
    python_requires=">=3.9",
)
