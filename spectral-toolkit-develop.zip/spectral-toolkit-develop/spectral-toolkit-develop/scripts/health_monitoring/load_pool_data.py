from copy import copy
import datetime
import os
import pandas as pd
from pathlib import Path
import pickle
import pytz
from pytz import country_timezones

from plotly.subplots import make_subplots
from plotly import graph_objects as go
import plotly.express as px
from plotly.io import write_json

from configobj import ConfigObj

from data_pooler.data_access_utils import get_file_paths_in_timerange
from data_pooler.pool_utils import get_data_frame, get_data_columns
import data_pooler.processing_utils as pu

from spectral_toolkit.utilities_all.utilities_for_pool import get_all_data, add_multiple_var_data, find_name

from spectral_toolkit.utilities_all.time_conversions import timestr_to_datetime

ini_name = "load_pool_data.ini"
ini_flnm = os.path.join(os.getcwd(), ini_name)
config = ConfigObj(ini_flnm)

# paths
baseDIR = config["Paths"]["base_name"]
resultsDIR = os.path.join(baseDIR, "Output")
if not os.path.exists(resultsDIR):
    os.mkdir(resultsDIR)
figuresDIR = os.path.join(resultsDIR, "Figures")
if not os.path.exists(figuresDIR):
    os.mkdir(figuresDIR)

poolDIR = config["Paths"]["pool_name"]
name = config["Paths"]["run_suffix"]

# parameters
start_date_time_str = config["Parameters"]["start_date_time"]
end_date_time_str = config["Parameters"]["end_date_time"]
timezone = config["Parameters"]["timezone"]
analyzer_name = config["Parameters"]["analyzer_name"]
reference_valve_pos = config["Parameters"]["reference_valve_pos"]
log_names = config["LogNames"]

# variables to plot
variable_dict = config["Variables_to_plot"]

# trigger information
TriggerSpecies = config["TriggerSpecies"]

port_map = {int(i): name for i, name in config["port_names"].items()}
color_list = px.colors.qualitative.Plotly
colors_by_port = {port: color_list[port % len(color_list)] for port in port_map}

# gather timeseries data
base_path = Path(poolDIR) / analyzer_name
tz = pytz.timezone(timezone)
start_date_time = tz.localize(timestr_to_datetime(start_date_time_str))
start_now = copy(start_date_time)
stop_date_time = tz.localize(timestr_to_datetime(end_date_time_str))
times = []
while start_now < stop_date_time:
    end_of_day = (start_now + datetime.timedelta(days=1)).replace(
        hour=0, minute=0, second=0, microsecond=0
    )
    times.append((start_now, end_of_day))
    start_now = end_of_day

for start_date_time_now, end_date_time_now in times:
    # file naming
    start_date_time_str = start_date_time_now.strftime("%Y%m%d_%H%M%S")
    end_date_time_str = end_date_time_now.strftime("%Y%m%d_%H%M%S")
    flnm_suffix = "%s_%s_%s" % (start_date_time_str, end_date_time_str, name)

    # get requested data
    df_combo = None
    df_private = None
    df_SAM = None
    for key, log_name in log_names.items():
        files = get_file_paths_in_timerange(
            start_date_time_now, end_date_time_now, base_path, log_name
        )
        col_names = get_data_columns(files)
        df = get_data_frame(files, col_names)
        if "ComboLog" in log_name:
            df = df.rename(
                columns=lambda x: "%s_%s" % ("broadband", x) if x[0].islower() else x
            )
        df.index = df.index.tz_convert(tz)

        if "ComboLog" in log_name:
            df_combo = df
        elif "PrivateLog" in log_name:
            df_private = df
        elif "SAM" in log_name:
            df_SAM = df

    # start with SAM data
    df_from = None
    if df_SAM is not None:
        df_to = df_SAM
        if df_private is not None:
            df_from = df_private
        elif df_combo is not None:
            df_from = df_combo
    elif df_private is not None:
        df_to = df_private
        if df_combo is not None:
            df_from = df_combo
    else:
        df_to = df_combo
    del df_combo, df_private, df_SAM

    if df_from is not None and df_to is not None:
        if "timestamp" in df_from:
            tn_from = "timestamp"
        else:
            tn_from = "broadband_timestamp"

        tn_to = "JULIAN_DAYS"

        if df_from is not None:
            time_vector_from = get_all_data(tn_from, df_from)
            df = add_multiple_var_data(
                tn_to, time_vector_from, df_from, df_to, overwrite=True
            )
        else:
            df = df_to
        df = df.copy()
    elif df_from is not None:
        df = df_from.copy()
    elif df_to is not None:
        df = df_to.copy()
    del df_from, df_to

    # Rename the valve column as valve_pos
    df["valve_pos"] = df[TriggerSpecies["trigger"]]

    # Group the data, returning a dataframe with a multi-index
    dfg = pu.data_by_group_and_valve_pos(
        df,
        ignore_start=float(TriggerSpecies["startAbs"]),
        ignore_end=float(TriggerSpecies["endAbs"]),
    )

    dt = dfg.index.get_level_values("_datetime")
    dfg = dfg[(dt >= start_date_time) & (dt < stop_date_time)]
    dt = dfg.index.get_level_values("_datetime")

    # Calculate mean and standard deviation of port averaged data
    df_port_mean = dfg.groupby(level=("valve_pos", "_group")).mean()
    df_port_stats = df_port_mean.groupby(level="valve_pos").agg(["mean", "std"])

    for key, column in variable_dict.items():  # sorted(set(columns)):
        new_name, _ = find_name(column, df)
        if new_name is not None:
            print(f"Making uncorrected port average plot for {new_name}")
            # Make the annotation with mean and standard deviation of port average for each port
            legend_dict = {
                index: f"{row['mean']:.1f}" + "\u00B1" + f"{row['std']:.1f}"
                for index, row in df_port_stats[new_name].iterrows()
                if index in port_map
            }
            # Assemble the port averaged traces
            traces, annotations = pu.make_port_averaged_traces(
                dfg,
                port_map,
                colors_by_port,
                new_name,
                tz.zone,
                legend_dict=legend_dict,
            )
            # Construct the subplots
            fig = make_subplots(
                rows=len(traces),
                cols=1,
                shared_xaxes=True,
                shared_yaxes="all",
                vertical_spacing=0.05,
            )
            options = {}
            nplots = len(traces)
            for row, (trace, annotation) in enumerate(zip(traces, annotations)):
                fig.add_trace(trace, row=row + 1, col=1)
                fig.add_annotation(
                    row=row + 1,
                    col=1,
                    font={"size": 20},
                    x=0.99,
                    y=0.95,
                    xref="x domain",
                    yref="y domain",
                    showarrow=False,
                    borderpad=4,
                    borderwidth=1,
                    bordercolor="black",
                    **annotation,
                )
            options[f"xaxis{nplots if nplots>1 else ''}_title"] = f"Time [{tz.zone}]"
            fig.update_layout(
                title=dict(
                    text=f"{new_name}",
                    x=0.5,
                    y=0.99,
                    xanchor="center",
                    yanchor="top",
                    font_size=24,
                ),
                showlegend=False,
                margin=dict(t=50, b=50),
                height=200 * nplots,
                width=1200,
                **options,
            )

            if not os.path.exists("images"):
                os.mkdir("images")
            fig.write_image(
                f"{figuresDIR}/{flnm_suffix}_{new_name}_port_ave_uncorr.png"
            )
            write_json(
                fig, f"{figuresDIR}/{flnm_suffix}_{new_name}_port_ave_uncorr.json"
            )

    del df, dfg, dt, df_port_mean, df_port_stats, traces, legend_dict, fig
