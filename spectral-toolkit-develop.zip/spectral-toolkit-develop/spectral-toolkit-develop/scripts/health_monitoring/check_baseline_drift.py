from turtle import title
import plotly.graph_objects as go
import pandas as pd
import os
import sys
import time
import itertools
import threading
from configobj import ConfigObj

###Picarro Repositories
from voc_fitter.spectral_logger import SpectralLogReader as slog

def animate():

    '''animates a loading symbol to show the program is running'''

    for c in itertools.cycle(["|", "/", "-", "\\"]):
        if done:
            break
        sys.stdout.write("\rbuilding figures " + c)
        sys.stdout.flush()
        time.sleep(0.2)
    sys.stdout.write("\rDone   ")

if __name__ == '__main__':

    ##Load directory information from .ini file
    ##Try to load from config folder
    try:
        config_path = os.path.join(os.path.dirname(os.getcwd()), 'config')
        ini_filename = os.path.join(config_path, 'check_baseline_drift.ini')
        try_local = False
        with open(ini_filename, 'r') as file:
            print('------------------------------------------------------------------')
            print('Loading .ini from ' + config_path)
            print('------------------------------------------------------------------')
    except:
        print('------------------------------------------------------------------')
        print('Unable to load .ini file check_baseline_drift.ini from config folder')
        print('------------------------------------------------------------------')
        try_local = True
        pass
    #See if there is a config file in the local directory
    if try_local == True:
        try:
            local_config_path = os.getcwd()
            local_ini_filename = os.path.join(local_config_path, 'check_baseline_drift.ini')
            with open(local_ini_filename, 'r') as file:
                print('------------------------------------------------------------------')
                print('Loading .ini from' + local_config_path + '\n\nExpected config location: ' + config_path)
                print('------------------------------------------------------------------')
                ini_filename = local_ini_filename
        except:
            print('------------------------------------------------------------------')
            print('No local .ini file found')
            print('Aborting Program.  Place check_baseline_drift.ini into config folder or locally')
            print('------------------------------------------------------------------')
            sys.exit(1)

    #Start the loading symble and animate it in a different thread so it can run until done=True    
    done = False
    t = threading.Thread(target=animate)
    t.start()
    
    #Initialize variables
    combo_dirs = {}
    read_files_dict = {}
    bbdata_dict = {}
    T_dict = {}

    DF_nu = pd.DataFrame()
    DF_A = pd.DataFrame()

    #Load from the check_baseline_drift.ini
    report_config = ConfigObj(ini_filename)
    report_config.as_list('Pools')
    
    pool_paths = report_config['Pools']['pool_paths']
    pool_keys = report_config['Pools']['pool_keys']
    save_path = report_config['Paths']['save_path']

    for datapoolDIR, key in zip(pool_paths, pool_keys):
        combo_dirs[key] = datapoolDIR

    #this is calling the voc-fitter to read spectral data
    for key in combo_dirs:
        read_files_dict[key] = slog(combo_dirs[key], verbose=False)

    for key in read_files_dict:
        try:
            bbdata_dict[key] = read_files_dict[key].get_columns('broadband', ['timestamp'])
        except Exception as e:
            print(e)
            pass

    #creates a dict of time axis 'T' list for the fit results
    time_key = 'timestamp'# 'epochTime'
    for key in bbdata_dict:
        Tlist = []
        _bbdata = bbdata_dict[key]
        T = _bbdata[time_key]
        Tlist.append(T)
        T_dict[key] = T

    for key in read_files_dict:
        df_nu = pd.DataFrame()
        df_A = pd.DataFrame()

        df_dict = {}
        current_step = 0
        steps = 500
        
        _T = T_dict[key]
        for i in range(0, len(_T), steps):
            spec_test, results_unused = read_files_dict[key].get_spectra_row('broadband', i)
            step = str(current_step)

            _df_nu = pd.DataFrame(spec_test['nu'], columns=[step])
            
            #absorbance minus big3
            _df_A = pd.DataFrame((spec_test['absorbance']-spec_test['big3']), columns=[step])

            df_nu = pd.concat([df_nu, _df_nu], axis='columns')
            df_A = pd.concat([df_A, _df_A], axis='columns')
            current_step = steps + current_step
                
        df_nu['mean'] = df_nu.mean(axis='columns')
        df_nu['std'] = df_nu.std(axis='columns')
        DF_nu[(key + '_mean')] = df_nu['mean'] 
        DF_nu[(key + '_std')] = df_nu['std']
        df_A['mean'] = df_A.mean(axis='columns')
        df_A['std'] = df_A.std(axis='columns')
        DF_A[(key + '_mean')] = df_A['mean']
        DF_A[(key + '_std')] = df_A['std']
        
        fig = go.Figure()
        fig_title = key
        
        for key in df_nu.keys():
            if key != 'std':
                fig.add_traces(
                    go.Scatter(
                        x=df_nu[key],
                        y=df_A[key], 
                        mode='lines', 
                        name='row: ' + key, 
                        opacity = 0.5)
                    )
        fig.update_layout(title_text=fig_title, title_x=0.5)
        fig.update_xaxes(title='wavenumber (1/cm)')
        fig.update_yaxes(title='abs - big3 (arb.)')
        
        try: 
            staticDIR = os.path.join(save_path, 'baseline', 'static')
            if not os.path.exists(staticDIR):
                os.makedirs(staticDIR)
        except:
            print('Cant create staticDIR figure directory')

        try: 
            interactiveDIR = os.path.join(save_path, 'baseline', 'interactive')
            if not os.path.exists(interactiveDIR):
                os.makedirs(interactiveDIR)
        except:
            print('Cant create interactiveDIR figure directory')
        
        static_path = os.path.join(staticDIR, fig_title)
        static_path = static_path + '.png'
        plotly_path = os.path.join(interactiveDIR, fig_title)
        plotly_path = plotly_path + '.html'
        fig.write_html(plotly_path)
        fig.write_image(static_path)

    fig = go.Figure()
    DF_keys = list(DF_A.keys())
    DF_plot_keys = []

    for key in DF_keys:
        if 'std' not in key:
            DF_plot_keys.append(key)

    _DF_nu = DF_nu[DF_plot_keys]

    for i in range((len(DF_plot_keys)-1)):
        col_name = 'diff_' + str(i)
        DF_A[col_name] = DF_A[DF_plot_keys[i+1]] - DF_A[DF_keys[0]]
        DF_nu[col_name] = _DF_nu.mean(axis='columns')
        i+=1
        
    for key in DF_A:
        if 'std' not in key:
            name = 'date: ' + key
            if key >= 'diff':
                name = key
                fig.add_traces(
                            go.Scatter(
                                x=DF_nu[key],
                                y=DF_A[key],
                                mode='lines', 
                                name=name, 
                                opacity = 1),
                )
            else:
                std_key = key[:-4]
                std_key = std_key + 'std'
                fig.add_traces(
                    go.Scatter(
                        x=DF_nu[key],
                        y=DF_A[key],
                        mode='lines', 
                        name=name, 
                        opacity = 1
                    ))
                fig.add_traces(
                    go.Scatter(
                        name='Upper Bound',
                        x=DF_nu[key], 
                        y=(DF_A[key] + DF_A[std_key]*3), 
                        mode='lines',
                        marker=dict(color="#444"),
                        line=dict(width=0),
                        showlegend=False
                        ))
                fig.add_traces(
                    go.Scatter(
                        name='Lower Bound',
                        x=DF_nu[key], 
                        y=DF_A[key] - DF_A[std_key]*3, 
                        marker=dict(color="#444"),
                        line=dict(width=0),
                        mode='lines',
                        fillcolor='rgba(68, 68, 68, 0.3)',
                        fill='tonexty',
                        showlegend=False
                        ))
             

            fig.update_layout(title_text='Avg Spectrum', title_x=0.5)
            fig.update_xaxes(title='wavenumber (1/cm)')
            fig.update_yaxes(title='abs - big3 (arb.)')

        baselineDIR = os.path.join(save_path, 'baseline')
        b_static_path = os.path.join(baselineDIR, 'Difference')
        b_static_path = b_static_path + '.png'
        b_plotly_path = os.path.join(baselineDIR, 'Difference')
        b_plotly_path = b_plotly_path + '.html'
        fig.write_html(b_plotly_path)
        fig.write_image(b_static_path)

    time.sleep(10)
    done = True