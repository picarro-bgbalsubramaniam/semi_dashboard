import os
import pickle
import glob

from spectral_toolkit.TD_analysis.data_models_TD.input import save_yaml
from spectral_toolkit.TD_analysis.data_models_TD.unks_input import (
    get_unk_input,
    CONFIG_FILE,
)

from spectral_toolkit.TD_analysis.unknown_analysis.unknown_analysis_SAT import (
    find_unknowns,
)


def main(config_file):
    input_class, config_file, yaml_dict = get_unk_input(config_file=config_file)

    output_flnm = os.path.join(input_class.Paths.set_get_output_path(), CONFIG_FILE)
    save_yaml(yaml_dict, output_flnm)

    if "unknown_FOM" in input_class.Analysis:  # FOM
        file_ending = "unknown_FOM"
        folder_name = "unknown FOM"

        _, spectral_dir, _, _ = input_class.Paths.set_file_paths(analysis_name="FOM")

        files = glob.glob(os.path.join(spectral_dir, "*_FOM_correlation.pkl"))

        run_stuff(files, input_class, file_ending, folder_name)

    if "unknown_canary_FOM" in input_class.Analysis:
        file_ending = "unknown_canary_FOM"
        folder_name = "unknown canary FOM"

        _, spectral_dir, _, _ = input_class.Paths.set_file_paths(
            analysis_name="canary FOM"
        )

        files = glob.glob(os.path.join(spectral_dir, "*_FOM_correlation.pkl"))

        run_stuff(files, input_class, file_ending, folder_name)


def run_stuff(files, input_class, file_ending, folder_name):
    runs_dict = input_class.get_times_dict(list_name="Events")

    for spectral_flnm in files:
        flnm = os.path.basename(spectral_flnm)
        run_start = "_".join(flnm.split("_")[0:2])
        run_suffix = "_".join(flnm.split("_")[2:-2])

        run_num = None
        for num, run in runs_dict.items():
            if run_start == run["start_date_time"]:
                run_num = num

        if run_num is not None:
            extra_cids = runs_dict[run_num]["extra_cids"]

            with open(spectral_flnm, "rb") as f:
                correlation_dict = pickle.load(f)
            # results_dict[(event_start, event_end)] = event_fit
            #     event_fit: FOM_spectral_data
            #         spectral_FOM: np.array
            #             1D array of FOM values in time (n)
            #         fit_df: pd.DataFrame
            #             dataframe containing spectral data (m, n)
            #         coef_df: pd.DataFrame
            #             index: numean (m)
            #             slope: slope values for FOM vs spectra correlation (m)
            #             offset: offset values for FOM vs spectra correlation (m)

            find_unknowns(
                input_class,
                run_start,
                extra_cids,
                run_suffix,
                correlation_dict,
                file_ending,
                folder_name,
            )


if __name__ == "__main__":
    main(CONFIG_FILE)
