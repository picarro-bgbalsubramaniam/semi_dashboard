import os

from spectral_toolkit.TD_analysis.data_models_TD.input import save_yaml
from spectral_toolkit.TD_analysis.data_models_TD.report_input import (
    CONFIG_FILE,
    get_report_input,
)

from spectral_toolkit.TD_analysis.peak_analysis.TD_report import report_TD_results


def main(config_file):
    input_class, config_file, yaml_dict = get_report_input(config_file=config_file)

    output_flnm = os.path.join(input_class.Paths.set_get_output_path(), CONFIG_FILE)
    save_yaml(yaml_dict, output_flnm)

    report_TD_results(input_class)


if __name__ == "__main__":
    main(CONFIG_FILE)
