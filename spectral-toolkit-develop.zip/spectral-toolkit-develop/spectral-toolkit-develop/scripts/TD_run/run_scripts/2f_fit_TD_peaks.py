import os

from spectral_toolkit.TD_analysis.data_models_TD.input import save_yaml

from spectral_toolkit.TD_analysis.data_models_TD.fit_input import (
    CONFIG_FILE,
    get_fit_input,
)

from spectral_toolkit.TD_analysis.peak_analysis.fit_TD import fit_TD_peaks
from spectral_toolkit.TD_analysis.TD_utilities.utilities_reg import (
    filepath_creator,
    run_filename_creator,
)


def main(config_file):
    input_class, config_file, yaml_dict = get_fit_input(config_file=config_file)

    output_flnm = os.path.join(input_class.Paths.set_get_output_path(), CONFIG_FILE)
    save_yaml(yaml_dict, output_flnm)

    runs_starts = input_class.get_time_starts(list_name="Events")
    seq_prefix = input_class.Paths.run_suffix

    path_dict = filepath_creator(input_class)

    for run_start in runs_starts:
        spec_data_flnm = run_filename_creator(
            input_class, path_dict, run_start, "parse_combo_spectra"
        )

        pfd_out = fit_TD_peaks(
            input_class,
            run_start,
            seq_prefix,
            spec_data_flnm,
        )


if __name__ == "__main__":
    main(CONFIG_FILE)
