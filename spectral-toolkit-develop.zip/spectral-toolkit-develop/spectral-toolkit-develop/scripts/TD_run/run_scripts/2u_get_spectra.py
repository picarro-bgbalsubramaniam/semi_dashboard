import os

from spectral_toolkit.TD_analysis.data_models_TD.input import save_yaml
from spectral_toolkit.TD_analysis.data_models_TD.spectral_input import (
    CONFIG_FILE,
    get_spec_input,
)

from spectral_toolkit.TD_analysis.event_hunting.find_tvoc_peaks import find_peak_events
from spectral_toolkit.TD_analysis.event_hunting.FOM_correlation_analysis import (
    create_FOM_correlation_spectra,
)
from spectral_toolkit.TD_analysis.event_hunting.canary_ICA_analysis import (
    find_canary_FOM,
)

from spectral_toolkit.TD_analysis.TD_utilities.utilities_reg import (
    filepath_creator,
    run_filename_creator,
)


def main(config_file):
    input_class, config_file, yaml_dict = get_spec_input(config_file=config_file)

    output_flnm = os.path.join(input_class.Paths.set_get_output_path(), CONFIG_FILE)
    save_yaml(yaml_dict, output_flnm)

    runs_starts = input_class.get_time_starts(list_name="Events")
    seq_prefix = input_class.Paths.run_suffix

    path_dict = filepath_creator(input_class)

    if "unknown_FOM" in input_class.Analysis:
        FOM_list = input_class.FigureOfMerit
        for FOM_name in FOM_list:
            for run_start in runs_starts:
                spec_data_flnm = run_filename_creator(
                    input_class, path_dict, run_start, "parse_combo_spectra"
                )

                events = find_peak_events(
                    input_class, run_start, seq_prefix, FOM_name, spec_data_flnm
                )

                create_FOM_correlation_spectra(
                    input_class,
                    run_start,
                    seq_prefix,
                    FOM_name,
                    spec_data_flnm,
                    events,
                )

    if "unknown_canary_FOM" in input_class.Analysis:
        for run_start in runs_starts:
            spec_data_flnm = run_filename_creator(
                input_class, path_dict, run_start, "parse_combo_spectra"
            )

            FOM_list, df = find_canary_FOM(
                input_class,
                run_start,
                seq_prefix,
                spec_data_flnm,
            )

            for FOM_name in FOM_list:
                events = find_peak_events(
                    input_class,
                    run_start,
                    seq_prefix,
                    FOM_name,
                    spec_data_flnm,
                    folder_name="canary FOM",
                    df=df,
                )

                create_FOM_correlation_spectra(
                    input_class,
                    run_start,
                    seq_prefix,
                    FOM_name,
                    spec_data_flnm,
                    events,
                    folder_name="canary FOM",
                    df=df,
                )
                # Saves:
                #     filename = os.path.join(
                #         analysis_dir, "%s_%s_%s.pkl" % (run_start, seq_prefix, file_ending)
                #     )
                #     results_dict[(event_start, event_end)] = event_fit

                #         event_fit: FOM_spectral_data
                #             spectral_FOM: np.array
                #                 1D array of FOM values in time (n)
                #             fit_df: pd.DataFrame
                #                 dataframe containing spectral data (m, n)
                #             coef_df: pd.DataFrame
                #                 index: numean (m)
                #                 slope: slope values for FOM vs spectra correlation (m)
                #                 offset: offset values for FOM vs spectra correlation (m)


if __name__ == "__main__":
    main(CONFIG_FILE)
