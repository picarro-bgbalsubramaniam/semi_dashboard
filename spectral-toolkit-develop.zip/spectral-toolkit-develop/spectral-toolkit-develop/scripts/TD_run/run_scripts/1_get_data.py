import os

from spectral_toolkit.TD_analysis.data_models_TD.input import (
    save_yaml,
    initialize_yamls,
)
from spectral_toolkit.TD_analysis.data_models_TD.data_input import (
    CONFIG_FILE,
    get_data_input,
)
from spectral_toolkit.TD_analysis.data_parsing.data_parsing import (
    get_TD_sequences,
    compile_markes_data,
    load_compile_data,
    get_spectra,
    compile_picarro_TD_data,
)

from spectral_toolkit.TD_analysis.data_parsing.plot_timeseries_TD import (
    plot_timeseries_data,
)


def main(config_file, TD_type="markes"):
    input_class, config_file, _ = get_data_input(config_file=config_file)
    TD_type = input_class.Parameters.TD_type

    sequences = get_TD_sequences(input_class, config_file, TD_type=TD_type)
    # this first function updates the yaml --> reload
    input_class, config_file, yaml_dict = get_data_input(config_file=CONFIG_FILE)

    output_flnm = os.path.join(input_class.Paths.set_get_output_path(), CONFIG_FILE)
    save_yaml(yaml_dict, output_flnm)

    initialize_yamls(yaml_dict, input_class.Paths.set_get_output_path())

    comp_df = load_compile_data(input_class)
    plot_timeseries_data(input_class, comp_df, sequences)

    for start_datetime, sequence_series in sequences.iterrows():
        if TD_type == "markes":
            compile_markes_data(input_class, start_datetime, sequence_series)
        elif TD_type == "picarro" or TD_type == "picarroSAT":
            compile_picarro_TD_data(
                input_class, start_datetime, sequences, TD_type=TD_type
            )
        get_spectra(input_class, start_datetime, sequence_series, comp_df)


if __name__ == "__main__":
    main(CONFIG_FILE)
