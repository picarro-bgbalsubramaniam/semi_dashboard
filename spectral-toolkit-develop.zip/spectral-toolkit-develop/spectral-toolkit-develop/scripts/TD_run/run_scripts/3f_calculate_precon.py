import os

from spectral_toolkit.TD_analysis.data_models_TD.input import save_yaml
from spectral_toolkit.TD_analysis.data_models_TD.precon_input import (
    CONFIG_FILE,
    get_precon_input,
)

from spectral_toolkit.TD_analysis.peak_analysis.flow_precon import flow_precon
from spectral_toolkit.TD_analysis.peak_analysis.TD_precon import calculate_peak_precon

from spectral_toolkit.TD_analysis.TD_utilities.utilities_reg import (
    filepath_creator,
    run_filename_creator,
)


def main(config_file):
    input_class, config_file, yaml_dict = get_precon_input(config_file=config_file)

    output_flnm = os.path.join(input_class.Paths.set_get_output_path(), CONFIG_FILE)
    save_yaml(yaml_dict, output_flnm)

    runs_starts = input_class.get_time_starts(list_name="Events")
    seq_prefix = input_class.Paths.run_suffix
    TD_type = input_class.Parameters.TD_type

    path_dict = filepath_creator(input_class)

    for run_start in runs_starts:
        if TD_type == "markes":
            TD_comp_flnm = run_filename_creator(
                input_class, path_dict, run_start, "parse_markes"
            )
        elif TD_type == "picarro":
            TD_comp_flnm = run_filename_creator(
                input_class, path_dict, run_start, "compile_picarro_TD"
            )
        # return_dict = {
        #     "start_datetime": start_datetime,
        #     "sequence": sequence,
        #     "df_flow": df_flow,
        #     "dfg": dfg,
        # }

        _ = flow_precon(
            input_class,
            run_start,
            seq_prefix,
            TD_comp_flnm,
        )

    calculate_peak_precon(input_class, runs_starts)


if __name__ == "__main__":
    main(CONFIG_FILE)
