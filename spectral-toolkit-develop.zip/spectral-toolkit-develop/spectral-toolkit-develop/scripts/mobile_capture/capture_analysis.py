import os
from collections import namedtuple
from pathlib import Path
import numpy as np
import pandas as pd

pd.options.plotting.backend = "plotly"
import plotly.graph_objects as go
from copy import deepcopy
import pickle
from pydantic import BaseModel
from typing import Optional, List
from ruamel.yaml import YAML
from datetime import datetime

from spectral_toolkit.surveyor_analysis import btex_analysis
from data_pooler.api.combined_logs import get_combo_df

from spectral_toolkit.sam_analysis.compound_identification import (
    _get_model_functions,
)

from fitter.fit_kick_alone import fit_multi_kick


Filter = namedtuple("Filter", ["name", "min", "max"])


class TimesSchema(BaseModel):
    time_num: int
    start_date_time: str
    end_date_time: str = datetime.now().strftime("%Y%m%d_%H%M%S")
    extra_cids: List[int] = []
    required_cids: List[int] = []


class FilterSchema(BaseModel):
    var_name: str
    minimum: Optional[float] = -np.inf
    maximum: Optional[float] = np.inf


def load_yaml_config(ini_name: str, cfg_dir: Optional[Path] = None):
    yaml = YAML()

    config_path = os.path.join(cfg_dir, ini_name)
    with open(config_path, "r") as file:
        yaml_dict = yaml.load(file)

    return yaml_dict


def check_path(pathname):
    if not os.path.exists(pathname):
        os.mkdir(pathname)


class YamlPaths(BaseModel):
    """Class containing input from yaml_dict[Paths]."""

    base_name: Path
    pool_name: Path
    output_path: Path = None
    figure_path: Path = None
    analysis_path: Path = None
    event_path: Path = None
    run_suffix: str

    def set_output_path(self):
        self.output_path = Path(os.path.join(self.base_name, "Output"))
        check_path(self.output_path)

    def set_figure_path(self):
        self.figure_path = Path(os.path.join(self.output_path, "Figures"))
        check_path(self.output_path)

    def set_get_output_path(self):
        self.set_output_path()
        return self.get_output_path()

    def set_get_figure_path(self):
        self.set_output_path()
        self.set_figure_path()
        return self.get_figure_path()

    def get_output_path(self):
        return self.output_path

    def get_figure_path(self):
        return self.figure_path


class YamlParameters(BaseModel):
    """Class containing input from yaml_dict[Parameters]."""

    time_name: str
    analyzer_name: str
    timezone: str = "US/Pacific"
    p_op: Optional[float] = 140.0
    baseline_nu_center: Optional[float] = 6056.507
    kick_cid: Optional[int] = 241

DEFAULT_FILTERS = [
            Filter("cavityPressure", 146.5, 148.0),
            Filter("OutletValve", 0, 100),
            Filter("numGroups", 200, np.inf),
        ]
        
class ConfigYaml(BaseModel):
    Paths: YamlPaths
    Parameters: YamlParameters
    Experiment_Times: List[TimesSchema]
    Filters: List[FilterSchema] = None

    def get_filters(self, start_filters: List=DEFAULT_FILTERS) -> list:
        """Output filters list.

        Returns:
            filters: list
                List containing lines for each filter condition.

        """
        filters = start_filters

        for filter_obj in self.Filters:
            filters.append(
                Filter(filter_obj.var_name, filter_obj.minimum, filter_obj.maximum)
            )

        return filters

    def get_exp_date_time_str(self):
        exp_times_dict = self.get_times_dict(list_name="Experiment_Times")
        start_date_time_str = exp_times_dict[0]["start_date_time"]
        end_date_time_str = exp_times_dict[0]["end_date_time"]
        return start_date_time_str, end_date_time_str

    def get_exp(self, exp_num=0):
        exp_times_dict = self.get_times_dict(list_name="Experiment_Times")
        return exp_times_dict[exp_num]

    def get_times_dict(self, list_name: Optional[str] = "Experiment_Times") -> dict:
        """Get a times list as a dictionary.
        Args:
            list_name: optional str, default Times
        Returns:
            time_dict: dictionary
                [{time_num}]
                    time_num: int
                    start_date_time: str
                    end_date_time: str = datetime.now().strftime("%Y%m%d_%H%M%S")
                    rank_std_res: List[float] = []
                    rank_mf_rmse: List[float] = []
        """
        time_dict = {}
        times_list = self.dict()[list_name]
        if times_list is not None:
            for list_element in times_list:
                key = dict(list_element)["time_num"]
                time_dict[key] = list_element
        return time_dict

    def get_time_nums(self, list_name: Optional[str] = "Experiment_Times"):
        """Get event numbers.
        Args:
            list_name: optional str, default Events
        """
        event_time_nums = []
        times_list = self.dict()[list_name]
        for list_element in times_list:
            event_time_nums.append(dict(list_element)["time_num"])
        return event_time_nums

    def get_time_starts(self, list_name: Optional[str] = "Experiment_Times"):
        """Get event start datetime strings.
        Args:
            list_name: optional str, default Times
        """
        event_time_starts = []
        times_list = self.dict()[list_name]
        for list_element in times_list:
            event_time_starts.append(dict(list_element)["start_date_time"])
        return event_time_starts

    def get_output_prefix(self):
        return "%s_%s" % (
            self.Experiment_Times[0].start_date_time,
            self.Paths.run_suffix,
        )

    def get_run_suffix(self):
        return self.Paths.run_suffix


def run_sat(input_class):
    pool_path = input_class.Paths.pool_name
    output_path = input_class.Paths.get_output_path()
    filters = input_class.get_filters()
    suffix = input_class.Paths.run_suffix
    kick_cid = input_class.Parameters.kick_cid
    analyzer_name = input_class.Parameters.analyzer_name
    baseline_nu_center = input_class.Parameters.baseline_nu_center

    exp_dict = input_class.get_exp(exp_num=0)

    start_str, stop_str, required_cids = (
        exp_dict["start_date_time"],
        exp_dict["end_date_time"],
        exp_dict["required_cids"],
    )
    start_dt = datetime.strptime(start_str, "%Y%m%d_%H%M%S")
    stop_dt = datetime.strptime(stop_str, "%Y%m%d_%H%M%S")

    prefix = "%s_%s_%s" % (start_str, stop_str, suffix)

    cid_list = deepcopy(required_cids)  # [241, 222, 6324, 6325, 402, 948, 6368]
    cid_list.append(kick_cid)

    df_combo = get_combo_df(
        start_dt.strftime("%Y-%m-%d %H:%M:%S"),
        stop_dt.strftime("%Y-%m-%d %H:%M:%S"),
        # input_class.Parameters.timezone,
        "UTC",
        pool_path / analyzer_name,
    )
    df_combo.to_pickle(os.path.join(output_path, "%s_df_combo.pkl" % (prefix)))

    sequences = btex_analysis.find_transitions(
        start_dt.strftime("%Y-%m-%d %H:%M:%S"),
        stop_dt.strftime("%Y-%m-%d %H:%M:%S"),
        pool_path / analyzer_name,
    )

    diff_spec, ref_spec, holding_spec = btex_analysis.create_diff_spec(
        sequences, df_combo, trim_time=5
    )

    diff_flnm = os.path.join(output_path, "%s_diff_spec.pkl" % prefix)
    with open(diff_flnm, "wb") as file:
        pickle.dump(diff_spec, file)

    ref_flnm = os.path.join(output_path, "%s_ref_spec.pkl" % prefix)
    with open(ref_flnm, "wb") as file:
        pickle.dump(ref_spec, file)

    holding_flnm = os.path.join(output_path, "%s_holding_spec.pkl" % prefix)
    with open(holding_flnm, "wb") as file:
        pickle.dump(holding_spec, file)

    model_functions = _get_model_functions()  # ppb/cm/ppb

    results = {}
    for key, BS in diff_spec.items():
        print(key)
        results.update(
            {
                key: fit_multi_kick(
                    model_functions,  # ppb/cm/ppb
                    BS.nu_prime,
                    BS.partial_fit,  # ppb/cm
                    baseline_nu_center,
                    [kick_cid],
                    cid_list,
                    partial_fit_std=BS.partial_fit_std,  # ppb/cm
                )
            }
        )
    flnm = os.path.join(output_path, "%s_uncertainty.pkl" % prefix)
    with open(flnm, "wb") as file:
        pickle.dump(results, file)

    spec_plots = btex_analysis.create_spectra_plot(holding_spec, ref_spec)
    flnm = os.path.join(output_path, "%s_spec_plots.pkl" % prefix)
    with open(flnm, "wb") as file:
        pickle.dump(spec_plots, file)

    diff_data, fit_data, spec_data = btex_analysis.btex_compound_hunting(
        diff_spec, required_cids=required_cids, num_compounds=[1, 2, 3, 4]
    )

    stats = btex_analysis.get_unknown_summary(
        fit_data, output_path, suffix, save_tables=True
    )
    flnm = os.path.join(output_path, "%s_stats.pkl" % prefix)
    with open(flnm, "wb") as file:
        pickle.dump(stats, file)

    plots = btex_analysis.create_btex_compound_hunting_plot(fit_data, spec_data)
    flnm = os.path.join(output_path, "%s_hunting_plots.pkl" % prefix)
    with open(flnm, "wb") as file:
        pickle.dump(plots, file)

    for i, fig in enumerate(spec_plots):
        #         plot.show(renderer="browser")
        fname = str(i)
        fig.write_html(
            os.path.join(
                input_class.Paths.get_figure_path(), "%s_hold_ref_spectra.html" % fname
            )
        )
    for i, fig in enumerate(plots):
        #         plot.show(renderer="browser")
        fname = str(i)
        fig.write_html(
            os.path.join(
                input_class.Paths.get_figure_path(), f"{fname}_compound_hunting.html"
            )
        )


if __name__ == "__main__":
    yaml_flnm = "config.yaml"
    config = load_yaml_config(yaml_flnm, cfg_dir=os.path.join(os.getcwd()))
    input_class = ConfigYaml.parse_obj(config)
    input_class.Paths.set_output_path()
    input_class.Paths.set_figure_path()

    run_sat(input_class)
