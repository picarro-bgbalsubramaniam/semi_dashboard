from scipy.optimize import newton

import numpy as np
import pandas as pd
from typing import Optional
from copy import deepcopy

from scipy.optimize import lsq_linear

from spectral_arithmetic.linear_least_squares import least_squares


####################################
##### Fit processing functions #####
####################################


def calculate_chi_squared(weight, statistics):
    chi_squared = np.sum(weight * statistics.residual_error**2)

    return chi_squared


def fit_LSQ(
    nu, partial_fit, A_list, pnames, set_abs=None, y_err=None, npoints=None, kick=False
):
    A_matrix = np.array(A_list).T
    result = {"rmse": 0.0}
    for pname in pnames:
        result.update({pname: 0.0})
    if set_abs is None:
        set_abs = np.zeros_like(partial_fit)

    try:
        if y_err is None and npoints is not None:
            y_err = 1 / np.sqrt(npoints)
        elif y_err is None:
            y_err = np.ones_like(nu)

        solution, statistics = least_squares(A_matrix, partial_fit - set_abs, y_err)
        for pname, res in zip(pnames, solution):
            result[pname] = res
        rmse = np.sqrt(statistics.lsq_res / len(partial_fit))
        result.update({"rmse": rmse})

        chi_weight = 1 / (y_err**2)
        chi_squared = calculate_chi_squared(chi_weight, statistics)
        result.update({"chi_squared": chi_squared})

        # calculate spectrum score and update results
        spectrum_score = calculate_spectrum_score(
            partial_fit - set_abs, statistics.model_estimate
        )
        result.update({"spectrum_score": spectrum_score})
    except:
        breakpoint()
        pass

    if kick:
        return result
    else:
        return result, statistics


def calculate_zeroed_rmse(rmse, sigma_factor, initial_rmse):
    # When delta chi**2 == n, n sigma
    # delta chi**2 = chi**2 (v) - chi**2 (min)
    # following similar logic:
    # delta RMSE**2 = RMSE (v)**2 - RMSE (min)**2
    # with delta RMSE = n*RMSE (min), for n sigma. IS THIS THE RIGHT ASSUMPTION??
    # RMSE (v) = sqrt((n**2+1)*RMSE (min)**2)
    # to solve for RMSE (v) as zero, subtract it from measured RMSE
    # zeroed RMSE = current RMSE - sqrt((n**2+1)*RMSE (min)**2)
    rmse_zeroed = rmse - np.sqrt((1 + sigma_factor**2)) * initial_rmse
    return rmse_zeroed


def calculate_zeroed_chi_squared(chi_squared, sigma_factor, initial_chi_squared):
    # When delta chi**2 == n, n sigma
    # delta chi**2 = chi**2 (v) - chi**2 (min)
    # delta chi**2 = n, for n sigma
    # to solve for chi**2 (v) as zero, subtract it from the measured chi**2
    # chi**2 (zeroed) = chi**2 (now) - (n + chi**2 (min))

    chi_squared_zeroed = chi_squared - (sigma_factor + initial_chi_squared)

    return chi_squared_zeroed


def quadratic_formula(a, b, c):
    pos_x = np.nan
    neg_x = np.nan
    if a != 0 and (b**2 - 4 * a * c) >= 0:
        pos_x = (-b + np.sqrt(b**2 - 4 * a * c)) / 2 / a
        neg_x = (-b - np.sqrt(b**2 - 4 * a * c)) / 2 / a
    return (pos_x, neg_x)


def quad_kicking(
    nu,
    partial_fit,
    model_functions,
    A_list: list,
    pnames: list,
    conc_start: float,
    init_results,
    sigma_factor=1,
    kick_cid: Optional[int] = 241,
    partial_fit_std: Optional[np.array] = None,
):
    ########################################################################
    kick_range = np.arange(-100e-9, 100e-9, 4e-9) + conc_start
    kick_list = []
    kick_name_list = ["gasConcs_%d" % kick_cid, "rmse", "chi_squared"]
    kick_name_list.append(pnames)

    kick_dict = {
        "gasConcs_%d" % kick_cid: 0,
        "rmse": init_results["rmse"],
        "chi_squared": init_results["chi_squared"],
    }

    A_list = deepcopy(A_list)
    pnames = deepcopy(pnames)
    # ind_2_drop = pnames.index("gasConcs_%d" % kick_cid)
    # del A_list[ind_2_drop]
    # pnames.remove("gasConcs_%d" % kick_cid)

    for kick in kick_range:
        # ppb/cm/ppb * parts * 1e9 ppb/parts
        set_abs = model_functions[kick_cid](nu) * kick * 1e9

        results, _ = fit_LSQ(
            nu,
            partial_fit,
            A_list,
            pnames,
            y_err=partial_fit_std,
            set_abs=set_abs,
        )

        kick_dict = {
            "gasConcs_%d" % kick_cid: kick,
            "rmse": results["rmse"],
            "chi_squared": results["chi_squared"],
        }

        kick_list.append(kick_dict)
    kick_df = pd.DataFrame(kick_list)

    rmse_zeroed = calculate_zeroed_rmse(
        kick_df["rmse"], sigma_factor, init_results["rmse"]
    )

    quad_solutions = {}
    # find rmse zeros
    rmse_fit = np.polyfit(kick_df["gasConcs_%d" % kick_cid], rmse_zeroed, 2)
    quad_pos_x, quad_neg_x = quadratic_formula(
        rmse_fit[0], rmse_fit[1], -np.sqrt(2) * rmse_fit[2]
    )
    quad_solutions.update({"rmse_pos": quad_pos_x, "rmse_neg": quad_neg_x})

    # find chi^2 zeros
    chi_squared_zeroed = calculate_zeroed_chi_squared(
        kick_df["chi_squared"], sigma_factor, init_results["chi_squared"]
    )
    chi_squared_fit = np.polyfit(
        kick_df["gasConcs_%d" % kick_cid], chi_squared_zeroed, 2
    )
    quad_pos_x, quad_neg_x = quadratic_formula(
        chi_squared_fit[0], chi_squared_fit[1], -np.sqrt(2) * chi_squared_fit[2]
    )
    quad_solutions.update(
        {"chi_squared_pos": quad_pos_x, "chi_squared_neg": quad_neg_x}
    )

    return quad_solutions


def multi_kick_function(
    x_array,
    nu,
    partial_fit,
    mf_array,
    init_conc_array: np.array,
    A_list: list,
    pnames: list,
    start_qc_var: float,
    factor,
    qc_var_name: Optional[str] = "rmse",
    partial_fit_std: Optional[np.array] = None,
    sigma_factor: Optional[float] = 1,
):
    set_abs = np.matmul(mf_array, (init_conc_array + x_array))
    results_dict = fit_LSQ(
        nu,
        partial_fit,
        A_list,
        pnames,
        set_abs=set_abs,
        kick=True,
        y_err=partial_fit_std,
    )

    # calculate factor based on the number of kicked cids

    if qc_var_name == "rmse":
        qc_var_zeroed = calculate_zeroed_rmse(
            results_dict[qc_var_name], sigma_factor, start_qc_var
        )
    elif qc_var_name == "chi_squared":
        qc_var_zeroed = calculate_zeroed_chi_squared(
            results_dict[qc_var_name], sigma_factor, start_qc_var
        )

    conc_diff_array = x_array * factor

    if np.any(conc_diff_array > 0):  # and np.all(np.abs(conc_diff_array) <= 1):
        # print(x_array, qc_var_zeroed)
        return qc_var_zeroed
    else:
        print(f"failed at {x_array}, derate {qc_var_name}, {qc_var_zeroed}")
        derated_rmse_zeroed = qc_var_zeroed
        if np.any(conc_diff_array > 0):
            derated_rmse_zeroed *= 999999
        if np.any(np.abs(conc_diff_array) >= 1):
            derated_rmse_zeroed *= 999999

        return -999 * qc_var_zeroed  # derated_rmse_zeroed
        # force the values to be bad if x is on the wrong side of conc_start


def find_delta_Nvar(
    nu,
    partial_fit,
    mf_array,
    A_list: list,
    pnames: list,
    start_qc_var,
    init_conc_array: np.array,
    conc_estimate_array: np.array,
    qc_var_name: Optional[str] = "rmse",
    factor: Optional[float] = 1,
    partial_fit_std: Optional[np.array] = None,
    sigma_factor: Optional[float] = 1,
):
    kwargs = dict(
        nu=nu,
        partial_fit=partial_fit,
        mf_array=mf_array,
        init_conc_array=init_conc_array,
        A_list=A_list,
        pnames=pnames,
        start_qc_var=start_qc_var,
        factor=factor,
        qc_var_name=qc_var_name,
        partial_fit_std=partial_fit_std,
        sigma_factor=sigma_factor,
    )

    # x_diff_array = np.ones(len(init_conc_array)) * 5e-9 * factor
    # for i, (conc_estimate, start_conc) in enumerate(
    #     zip(conc_estimate_array, init_conc_array)
    # ):
    #     if (factor < 0 and conc_estimate - start_conc < 0) or (
    #         factor > 0 and conc_estimate - start_conc > 0
    #     ):
    #         x_diff_array[i] = conc_estimate - start_conc

    # x0_array = 2 * x_diff_array + init_conc_array

    x0_array = (
        init_conc_array + factor * np.abs(conc_estimate_array - init_conc_array) * 2
    )
    # init_conc_array + 2 * x_diff_array
    # print(f"x0_array: {x0_array}")
    conc_value_array = newton(
        multi_kick_function,
        x0_array,
        args=tuple(kwargs.values()),
        tol=1e-12,
        maxiter=1000,
    )

    return conc_value_array


def calculate_spectrum_score(signal, model):
    normalized_data_vector = signal / np.sqrt(np.sum(signal**2))
    normalized_model_vector = model / np.sqrt(np.sum(model**2))
    sum_norm_prod = sum(normalized_data_vector * normalized_model_vector)
    if sum_norm_prod < 1:
        spectrum_score = -1 * np.log10(1 - sum_norm_prod)
    else:
        spectrum_score = 0

    return spectrum_score


def simple_fit_LSQ(
    partial_fit: np.array,
    A_matrix: np.array,
    # y_err: np.array,
):
    # solution, _ = least_squares(A_matrix, partial_fit, y_err)
    solution = lsq_linear(A_matrix, partial_fit)

    return solution.x


def model_from_conc(A_matrix, conc_values):
    model_estimate = np.matmul(A_matrix, conc_values)
    return model_estimate
