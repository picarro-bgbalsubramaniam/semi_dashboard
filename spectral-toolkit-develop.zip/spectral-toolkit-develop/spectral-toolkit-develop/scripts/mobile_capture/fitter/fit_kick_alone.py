import numpy as np
from typing import List, Optional

from utilities.processing_utilities import (
    fit_LSQ,
    find_delta_Nvar,
    quad_kicking,
)


def get_A_list(
    nu: np.array,
    baseline_nu_center: float,
    model_functions,
    cid_list: List[int],
    kick_cid: Optional[int] = None,
    offset: Optional[bool] = True,
    slope: Optional[bool] = True,
):
    A_list = []
    pnames = []
    if offset:
        A_list.append(np.ones(nu.shape))
        pnames.append("lsq_offset")
    if slope:
        A_list.append(nu - baseline_nu_center)
        pnames.append("lsq_slope")

    for cid in cid_list:
        add_cid = False
        if cid in cid_list:
            if isinstance(kick_cid, list):
                if cid not in kick_cid:
                    add_cid = True
            elif cid != kick_cid:
                add_cid = True

        if add_cid:
            A_list.append(model_functions[cid](nu) * 1e9)
            # / model_functions[cid].conc)
            pnames.append("gasConcs_%d" % cid)

    return A_list, pnames


def fit_multi_kick(
    model_functions,
    nu: np.array,
    partial_fit: np.array,
    baseline_nu_center: float,
    kick_cid: List[int],
    cid_list: List[int],
    qc_var_name: Optional[str] = "rmse",
    partial_fit_std: Optional[np.array] = None,
    verbose: Optional[bool] = True,
):
    # initial fit
    A_list, pnames = get_A_list(nu, baseline_nu_center, model_functions, cid_list)

    # fit using linear least squares
    results, _ = fit_LSQ(nu, partial_fit, A_list, pnames, y_err=partial_fit_std)

    # kick fits
    init_conc_array = np.ndarray(len(kick_cid))
    for i, cid in enumerate(kick_cid):
        init_conc_array[i] = results["gasConcs_%d" % cid]

    mf_array = np.zeros((len(nu), len(kick_cid)))
    for i, cid in enumerate(kick_cid):
        mf_array[:, i] = model_functions[cid](nu) * 1e9
    start_qc_var = results[qc_var_name]

    A_list, pnames = get_A_list(
        nu, baseline_nu_center, model_functions, cid_list, kick_cid=kick_cid
    )

    for sigma_factor in [1, 2, 3]:
        neg_conc_estimate_array = -np.ones_like(init_conc_array)  # * 1e-3
        pos_conc_estimate_array = np.ones_like(init_conc_array)  # * 1e-3
        for i, cid in enumerate(kick_cid):
            quad_dict = quad_kicking(
                nu,
                partial_fit,
                model_functions,
                A_list,
                pnames,
                init_conc_array[i],
                results,
                sigma_factor=sigma_factor,
                kick_cid=cid,
                partial_fit_std=partial_fit_std,
            )
            if (
                ~np.isnan(quad_dict[f"{qc_var_name}_neg"])
                and np.abs(quad_dict[f"{qc_var_name}_neg"]) < 1
            ):
                neg_conc_estimate_array[i] = quad_dict[f"{qc_var_name}_neg"]
            if (
                ~np.isnan(quad_dict[f"{qc_var_name}_pos"])
                and np.abs(quad_dict[f"{qc_var_name}_pos"]) < 1
            ):
                pos_conc_estimate_array[i] = quad_dict[f"{qc_var_name}_pos"]

        neg_x_array = find_delta_Nvar(
            nu,
            partial_fit,
            mf_array,
            A_list,
            pnames,
            start_qc_var,
            init_conc_array,
            neg_conc_estimate_array,
            factor=-1,
            qc_var_name=qc_var_name,
            partial_fit_std=partial_fit_std,
            sigma_factor=sigma_factor,
        )

        for i, cid in enumerate(kick_cid):
            results[f"kick_neg_{int(sigma_factor)}_sigma_{int(cid)}"] = neg_x_array[i]

        pos_x_array = find_delta_Nvar(
            nu,
            partial_fit,
            mf_array,
            A_list,
            pnames,
            start_qc_var,
            init_conc_array,
            pos_conc_estimate_array,
            factor=1,
            qc_var_name=qc_var_name,
            partial_fit_std=partial_fit_std,
            sigma_factor=sigma_factor,
        )

        for i, cid in enumerate(kick_cid):
            results[f"kick_pos_{int(sigma_factor)}_sigma_{int(cid)}"] = pos_x_array[i]

        if verbose:
            # print(neg_conc_estimate_array, pos_conc_estimate_array)
            print(f"start {qc_var_name}: {start_qc_var:.4e}")
            for i, cid in enumerate(kick_cid):
                print(
                    "%d start conc: %.3f ppb, %d*sigma: %.4f, %.4f (%0.4f) ppb"
                    % (
                        cid,
                        init_conc_array[i] * 1e9,
                        int(sigma_factor),
                        neg_x_array[i] * 1e9,
                        pos_x_array[i] * 1e9,
                        (pos_x_array[i] + init_conc_array[i]) * 1e9,
                    )
                )

    return results
